#!/bin/sh
JAVA_HOME=/opt/java1.3

APPS=/bea/apps/beinter/ise

ISE_URL="t3://172.22.5.5,172.22.5.6:7105"
. /$APPS/bin/set-classpath-ise.sh


CLASSPATH=/app/a_por/PROC_GEN/ADDR/:$CLASSPATH
CLASSPATH=/app/a_por/PROC_GEN/ADDR/lib_client_Address.jar:$CLASSPATH



echo Starting Client Address Update ......

$JAVA_HOME/bin/java -classpath $CLASSPATH -DProviderUrl=$ISE_URL it.sella.address.ise.RemoveUnusedAddressClient BSISEAS 01011970

STATO=$?

echo Client Complete the Address update

exit $STATO
