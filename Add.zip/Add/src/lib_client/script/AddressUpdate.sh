#!/bin/sh
.	set-classpath-ise-81.sh

echo Starting Client Address Update ......

$JAVA_HOME/bin/java -classpath $CLASSPATH -DProviderUrl=$ISE_URL it.sella.address.ise.RemoveUnusedAddressClient BSISEAS 01011970

STATO=$?

echo Client Complete the address update

exit $STATO
