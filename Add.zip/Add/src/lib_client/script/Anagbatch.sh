JAVA_HOME=/opt/java1.3
APPS=/bea/apps/beinter/ise
. /$APPS/bin/set-classpath-ise.sh
CLASSPATH=/app/a_tol/OSC/ANAG:$CLASSPATH
CLASSPATH=/app/a_tol/OSC/ANAG/lib_Client_Address.jar:$CLASSPATH
$JAVA_HOME/bin/java -classpath $CLASSPATH -DProviderUrl=t3://192.50.51.155:7032 it.sella.address.ise.RemoveUnusedAddressClient ISEMUTUIBS 01011970