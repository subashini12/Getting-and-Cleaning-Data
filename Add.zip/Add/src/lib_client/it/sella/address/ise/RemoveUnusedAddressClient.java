/*
 * Created by IntelliJ IDEA.
 * User: SUGUMAR
 * Date: Oct 28, 2002
 * Time: 3:36:42 PM
 */

package it.sella.address.ise;

import it.sella.integrazione_sistemi_esterni.ServiceException;
import it.sella.integrazione_sistemi_esterni.ServiceFactory;
import it.sella.integrazione_sistemi_esterni.ServiceHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

public class RemoveUnusedAddressClient
{
    
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(RemoveUnusedAddressClient.class);

    public static void main(final String [] args) {
        try {
            final ServiceHandler serviceHandler = ServiceFactory.newInstance().getServiceHandler("AddressRemovalService");
            serviceHandler.login(args[0],args[1]);
            serviceHandler.invokeServiceNotTX("");
            serviceHandler.logout();
        } catch (final ServiceException e) {
            log4Debug.severeStackTrace(e);
        }
    }

}
