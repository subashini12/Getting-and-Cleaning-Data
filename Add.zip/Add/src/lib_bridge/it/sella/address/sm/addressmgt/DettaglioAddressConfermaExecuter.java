package it.sella.address.sm.addressmgt;

import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.AddressAdminFactory;
import it.sella.address.implementation.NormalizedAddressStatus;
import it.sella.address.implementation.util.AnagrafeHandler;
import it.sella.address.implementation.util.Helper;
import it.sella.address.sm.ExecuterHelper;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreAnagrafeFactory;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Map;

public class DettaglioAddressConfermaExecuter extends InputDetailsHandlerExecuter {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DettaglioAddressConfermaExecuter.class);
	private static final String SUBSYSTEMID = "SubSystemId";
	private static final String PRODUCTCONTOID = "productContoId";
	private static final String SOGGETTOID = "SoggettoId";
	private static final String ADDRESSVIEW = "ADDRESSVIEW";
	private static final String SELECTEDADDRESS = "selectedAddress";
	private static final String MANCANTE = "MANCANTE";
	private static final String NCH = "NCH";
	private static final String MODIFY_ALL_CLICKED = "MODIFY_ALL_CLICKED";
	private static final String ADMOTIV = "ADMOTIV";

	public it.sella.statemachine.ExecuteResult execute( final RequestEvent requestEvent ) {
		ExecuteResult executeResult = null;
		final StateMachineSession session = requestEvent.getStateMachineSession();
		final String selectedAddress = (String) requestEvent.getAttribute(SELECTEDADDRESS);
		final Long soggettoId = (Long)session.get(SOGGETTOID);
		final Map inputDetails = getInputDetails(requestEvent);
		Long internalId = null;
		try {
			final AddressView addressView = getAddressview(selectedAddress,soggettoId,session,inputDetails/*, requestEvent.getEventName()*/);
			internalId = Helper.validateInternalValue(addressView.getIndirizzo());
			addressView.setInternal(internalId);
			if ( MANCANTE.equals(addressView.getIndirizzo()) || MANCANTE.equals(addressView.getCitta()) ) {
				throw new AddressException(AddressErrorConstants.ERR18);
			}
			if ( "CREATE".equals(session.get(ADMOTIV)) ) {
				session.put(ADDRESSVIEW, addressView);
			} else {
				if ( session.get(MODIFY_ALL_CLICKED) != null ) {
					AddressAdminFactory.getInstance().getAddressAdmin().setAddress(true,addressView);
				} else {
					AddressAdminFactory.getInstance().getAddressAdmin().setAddress(false,addressView);
				}
			}
			executeResult = ExecuterHelper.getExecuteResult("TrConferma");
			clearSession(session);
		} catch (final Exception e) {
			log4Debug.warnStackTrace(e);
			executeResult = getNonConfermaTransition(e,inputDetails,soggettoId,session,internalId);
		}
		return executeResult;
	}

	private ExecuteResult getNonConfermaTransition( final Exception e, final Map details,
			final Long soggettoId, final StateMachineSession session, final Long internalId ) {
		final ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
		setCommonDetails(executeResult,soggettoId,session);
		executeResult.setAttribute("errorMessage", e.getMessage());
		setInputDetails(executeResult,details,internalId);
		return executeResult;
	}

	private AddressView getAddressview( final String selectedAddress, final Long soggettoId,
			final StateMachineSession session, final Map inputDetails/*, final String eventName*/ ) throws AddressException,SubSystemHandlerException,RemoteException{
		AddressView addressView = null;
		if(!"newaddress".equals(selectedAddress)) {
			addressView = getSelectedView(soggettoId,selectedAddress);
			addressView.setCausaleTipoIndirizzo("ANAG".equals(session.get(SUBSYSTEMID)) ? (String)inputDetails.get(TIPOINDIRIZZO) : "IPO");
			addressView.setCausaleSubsystem((String) session.get(SUBSYSTEMID));
			addressView.setTipoIndirrizo(null);
			addressView.setNch((String) session.get(NCH));
			addressView.setSoggettoId(soggettoId);
			if ( !"ANAG".equals(session.get(SUBSYSTEMID)) ) {
				addressView.setProductContoId(inputDetails.get(PRODUCTCONTOID) != null ? Long.valueOf((String) inputDetails.get(PRODUCTCONTOID)) : null);
				addressView.setFrequency(getClassificazioneView("GIORN","AN_FREQ").getId());
				addressView.setReserved(0L);
			}
		} else {
			addressView = getViewFromInput(inputDetails,session);
		}
		if(!"OK".equals(addressView.getNormStatus()) && "TRUE".equalsIgnoreCase((String)inputDetails.get("JNorm"))) {
			normalizeAddress(addressView, inputDetails);
		} else {
			addressView.setNormStatus("FORZATO");
		}
		
		
	   /*	if(!"OK".equals(addressView.getNormStatus()) && !"ConfermaJN".equals(eventName) ) {
			normalizeAddress(addressView,inputDetails);
		} */
		
		return addressView;
	}
	
	private AddressView getViewFromInput( final Map details, final StateMachineSession session ) throws AddressException,SubSystemHandlerException,RemoteException {
		final AddressView addressView = new AddressView();
		final AnagrafeHandler anagrafeHandler = new AnagrafeHandler();
		
		//checkForNullAndDummyValue((String)details.get("indirizzo"),ERR02);
		replaceCommaInsteadOfEmptySpace((String)details.get(INDIRIZZO),AddressErrorConstants.ERR02);
		checkForSpecialChar((String)details.get(INDIRIZZO),AddressErrorConstants.ERR19);
		checkForSpecialCharForIndirizzi((String)details.get(INDIRIZZO),AddressErrorConstants.ERR21);
		checkForNullAndDummyValue((String)details.get(CITTA),AddressErrorConstants.ERR03);
		checkForSpecialChar((String)details.get(CITTA),AddressErrorConstants.ERR19);
		checkForNullAndDummyValue((String)details.get(NAZIONE),AddressErrorConstants.ERR04);
		addressView.setNazioneView(getNazioneViewFromName((String)details.get(NAZIONE)));
		if ( addressView.getNazioneView() == null ) {
			throw new AddressException(AddressErrorConstants.ERR07);
		}
		if ("ITALIA".equalsIgnoreCase((String)details.get(NAZIONE))) {
			checkForNullAndDummyValue((String)details.get(CAP),AddressErrorConstants.ERR08);
			checkForNullAndDummyValue((String)details.get(PROVINCIA),AddressErrorConstants.ERR09);
			isValid(anagrafeHandler.isValidCittaCommune((String)details.get(CITTA)),AddressErrorConstants.ERR10);
			isValid(anagrafeHandler.isValidProvinciaSigla((String)details.get(PROVINCIA)),AddressErrorConstants.ERR11);

			isValid(anagrafeHandler.isValidProvinciaForSiglaAndCittaCommune((String)details.get(PROVINCIA), (String)details.get(CITTA)),AddressErrorConstants.ERR11);
			isValid(anagrafeHandler.isValidCittaForProvincia((String)details.get(CITTA), (String)details.get(PROVINCIA)),AddressErrorConstants.ERR11);
			addressView.setCittaView(anagrafeHandler.getCitta((String)details.get(CITTA), (String)details.get(PROVINCIA)));
			addressView.setProvinciaView(anagrafeHandler.getProvinciaViewForSigla((String)details.get(PROVINCIA)));

			isValid(((String)details.get(CAP)).length() == 5,AddressErrorConstants.ERR12);
			try {
				Long.valueOf((String)details.get(CAP));
			} catch (final NumberFormatException nx) {
				log4Debug.warnStackTrace(nx);
				throw new AddressException(AddressErrorConstants.ERR12);
			}
			isValid(anagrafeHandler.isValidCapForProvincia((String)details.get(CAP), (String)details.get(PROVINCIA)),AddressErrorConstants.ERR12);
			addressView.setCapView(anagrafeHandler.getCapviewForCapcodeAndCittacommune((String)details.get(CAP), (String)details.get(CITTA)));
		}
		if(((String)details.get(CAP)).length() > 0){
			addressView.setCap((String)details.get(CAP));
		}
		if (!"ANAG".equals(session.get(SUBSYSTEMID))) {
			addressView.setFrequency(getClassificazioneView("GIORN","AN_FREQ").getId());
			addressView.setTipoIndirrizo(getClassificazioneView("IPO", "IND").getId());
			addressView.setCausaleTipoIndirizzo("IPO");
			addressView.setReserved(0L);
		} else {
			addressView.setTipoIndirrizo(getClassificazioneView((String)details.get(TIPOINDIRIZZO), "IND").getId());
			addressView.setCausaleTipoIndirizzo((String)details.get(TIPOINDIRIZZO));
		}
		addressView.setCitta((String)details.get(CITTA));
		addressView.setIndirizzo((String)details.get(INDIRIZZO));
		addressView.setNazione((String)details.get(NAZIONE));
		addressView.setProvincia((String)details.get(PROVINCIA));
		addressView.setProductContoId(details.get(PRODUCTCONTOID) != null ? Long.valueOf((String)details.get(PRODUCTCONTOID)) : null);
		addressView.setSoggettoId((Long) session.get(SOGGETTOID));
		addressView.setCausaleSubsystem((String) session.get(SUBSYSTEMID));
		addressView.setNch((String)session.get(NCH));
		return addressView;
	}

	private void checkForNullAndDummyValue( final String value, final String errorMessage ) throws AddressException {
		if( value == null || value.length() == 0 ) {
			throw new AddressException(errorMessage);
		}
	}
	
	private void replaceCommaInsteadOfEmptySpace( final String value, final String errorMessage )throws AddressException { 
		if( value != null ) {
			checkForNullAndDummyValue(value.replace(',',' ').trim(),errorMessage); 
		}
	}
	
	private void checkForSpecialChar( final String value, final String errorMessage ) throws AddressException {
		if( value.indexOf('(') != -1 || value.indexOf(')') != -1 || value.indexOf('^') != -1 ) {
			throw new AddressException(errorMessage);
		}
	}

	private void checkForSpecialCharForIndirizzi( final String value, final String errorMessage) throws AddressException {
		if( value.indexOf('&') != -1 ) {
			throw new AddressException(errorMessage);
		}
	}
	
	// if given boolean is false exception will be thrown with given errorMessage
	private void isValid( final boolean isValid, final String errorMessage ) throws AddressException {
		if( !isValid ) {
			throw new AddressException(errorMessage);
		}
	}
	
	private void normalizeAddress( final AddressView addressView, final Map inputDetails ) throws AddressException, RemoteException{
		NormalizedAddressStatus normalizedAddressStatus = null;
		try {
			normalizedAddressStatus = AddressAdminFactory.getInstance().getAddressAdmin()
					.normalizeIndirrizo(addressView.getNazioneView().getNome(),
							getCittaCommune(addressView),
							addressView.getIndirizzo(),
							getProvincia(addressView), 
							getCap(addressView),
							Boolean.TRUE);
			
		} catch (final AddressException e) {
			log4Debug.warnStackTrace(e);
			log4Debug.warn("ADDR NORM : EXCEPTION SUPRESSED BCOS ANY EXCEPTION DURING NORMALISAZION MUST BE SKIPPED AND ADDR PERSISTANCE MUST BE PROCEEDED WITHOUT NORMALISATION !!!!");
			return;
		}
		if ( normalizedAddressStatus.getErrorMessage() != null ) {
			checkForNullAndSetInMap(inputDetails, NORM_AMBIGUI_COL, normalizedAddressStatus.getAmbigui());
			throw new AddressException(normalizedAddressStatus.getErrorMessage());
		} else {
			addressView.setCap(normalizedAddressStatus.getCap());
			try {
				addressView.setCapView(GestoreAnagrafeFactory.getInstance().getGestoreAnagrafe().getCap(normalizedAddressStatus.getCap(), addressView.getCittaView() != null ? addressView.getCittaView().getCommune() : 
					 addressView.getCitta()));
			} catch (final GestoreAnagrafeException e) {
				log4Debug.warnStackTrace(e);
				addressView.setCap(null);
				// cap returned from normalisation not found in cap master.
			} 
			addressView.setIndirizzo(normalizedAddressStatus.getIndirrizi());
			addressView.setNormStatus("OK");
		}
	}
	
	private String getCittaCommune(final AddressView addressView) {
		return addressView.getCittaView() != null ? addressView.getCittaView().getCommune() : addressView.getCitta();
	}
	
	private String getProvincia(final AddressView addressView){
		return addressView.getProvinciaView() != null ? addressView.getProvinciaView().getSigla() : addressView.getProvincia();
	}
	
	private String getCap(final AddressView addressView){
		return addressView.getCapView() != null ? addressView.getCapView().getCap() : addressView.getCap();
	}
	
	private void checkForNullAndSetInMap(final Map details,final String key,final Object value) {
		if(value != null) {
			details.put(key, value);
		}
	} 
}


