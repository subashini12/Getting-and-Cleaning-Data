/**
 * Created by IntelliJ IDEA.
 * User: ssili6
 * Date: Jun 27, 2005
 * Time: 2:36:58 PM
 * To change this template use Options | File Templates.
 */
package it.sella.address.sm.gestionedomko;

import it.sella.address.AddressConstants;
import it.sella.address.AddressException;
import it.sella.address.AddressManagerFactory;
import it.sella.address.IAddressManager;
import it.sella.address.implementation.util.Helper;
import it.sella.intestatazione.IntestatazioneManagerFactory;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Map;


public class DefaultExecuter extends GestioneDomkoBaseExecuter {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DefaultExecuter.class);

    public ExecuteResult execute(final RequestEvent requestEvent) {
        ExecuteResult executeResult = null;
        StateMachineSession session = null;
        final Map sessionTable = new Hashtable();
        try {
            session = requestEvent.getStateMachineSession();
            final Long soggettoId = (Long) session.get("MAIN_SOGGETTO_ID");
            if (soggettoId != null) {
                final String intestazioneString = IntestatazioneManagerFactory.getInstance().getIntestatazioneManager().getIntestatazioneString(soggettoId);
                sessionTable.put(AddressConstants.ADDR_SOGGETTO_ID, soggettoId);
                final Collection indirizzoViewCollection = getAddressCollection(soggettoId);
                sessionTable.put(AddressConstants.ADDR_COLL, indirizzoViewCollection);
                getNumeroAndTipoConto(indirizzoViewCollection, sessionTable);
                session.put(AddressConstants.ADDR_SESSION, sessionTable);
                executeResult = Helper.getExecuteResult("TrConferma");
                if (intestazioneString != null) {
                    sessionTable.put(AddressConstants.INTESTAZIONESTRING, intestazioneString);
                }
                sessionTable.put(AddressConstants.LOG_DATAS, getDatasForLog(soggettoId));
                sessionTable.put(AddressConstants.LOG_DOMKO,getDatasForDOMKOLog(soggettoId));
                Helper.setDataToElencoAddress(soggettoId, executeResult, indirizzoViewCollection, sessionTable);
            } else {
				executeResult = getNonConfermaExecuteResult(session);
			}
        } catch (final Exception e) {
            log4Debug.severeStackTrace(e);
            executeResult = getNonConfermaExecuteResult(session);
		}
        return executeResult;
    }

	private Collection getAddressCollection(final Long soggettoId) throws RemoteException, AddressException {
		final Collection output = new ArrayList();
		final IAddressManager addressManager = AddressManagerFactory.getInstance().getAddressManager();
		final Collection acfwAddress = addressManager.listAddress(soggettoId, "ACFW");
		if(acfwAddress != null && !acfwAddress.isEmpty()) {
			output.addAll(acfwAddress);
		}
		final Collection viaCardAddress = addressManager.listAddress(soggettoId,"VIACARD");
		if(viaCardAddress != null && !viaCardAddress.isEmpty()) {
			output.addAll(viaCardAddress);
		}
		final Collection bantelAddress = addressManager.listAddress(soggettoId,"BANTEL");
		if(bantelAddress != null && !bantelAddress.isEmpty()) {
			output.addAll(bantelAddress);
		}
		return output;
	}

}
