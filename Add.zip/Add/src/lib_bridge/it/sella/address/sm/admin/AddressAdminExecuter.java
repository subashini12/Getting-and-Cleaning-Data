package it.sella.address.sm.admin;

import it.sella.address.AddressException;
import it.sella.address.sm.ExecuterHelper;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

public class AddressAdminExecuter extends AddressAdminBaseExecuter {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAdminExecuter.class);

    public it.sella.statemachine.ExecuteResult execute(final RequestEvent requestEvent) {
        String errorMessage = null;
        Object output = null;
        String methodInvoked = null;
        ExecuteResult executeResult = null;
        final String eventName = requestEvent.getEventName();
        try {
            if ("Conferma".equals(eventName)) {
                validateAddressDetails(requestEvent);
            } else if ("CheckMethod".equals(eventName)) {
                validateInputForCheckingAddressAPI(requestEvent);
                output = invokeMethod((String)requestEvent.getAttribute("arguments"),(String)requestEvent.getAttribute("methodName"));
                methodInvoked = "true";
            } /*else if("DeleteAddress".equals(eventName)) {//Handled the commented logic in RemoveAddressConfermaExecuter
                AddressManagerServiceFactory.getInstance().getAddressServiceManager().removeUnusedAddress();
                output = "Unused Address successfully removed";
            }*/
        } catch (final AddressException e) {
            log4Debug.severeStackTrace(e);
            errorMessage = e.getMessage();
        } /*catch (final RemoteException e) {
            log4Debug.severeStackTrace(e);
            errorMessage = e.getMessage();
        }*/
        if ( "Conferma".equals(eventName) && errorMessage != null ) {
            executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
            checkForNullAndSetInExecuteResult(executeResult, errorMessage,"errorMessage");
            checkForNullAndSetInExecuteResult(executeResult, ((String) requestEvent.getAttribute("soggettoId")).trim(),"soggettoId");
            checkForNullAndSetInExecuteResult(executeResult, ((String) requestEvent.getAttribute("subSystemCausale")).trim().toUpperCase(),"subSystemCausale");
            checkForNullAndSetInExecuteResult(executeResult, ((String) requestEvent.getAttribute("motiv")).trim().toUpperCase(),"motiv");
            checkForNullAndSetInExecuteResult(executeResult, ((String) requestEvent.getAttribute("productContoID")).trim(),"productContoID");
            checkForNullAndSetInExecuteResult(executeResult, ((String) requestEvent.getAttribute("NCH")).trim(),"NCH");
        } else {
            executeResult = ExecuterHelper.getExecuteResult("TrConferma");
            if ( !"Conferma".equals(eventName) ) {
				checkForNullAndSetInExecuteResult(executeResult, requestEvent.getAttribute("methodName"),"methodName");
				checkForNullAndSetInExecuteResult(executeResult, requestEvent.getAttribute("arguments"),"arguments");
				checkForNullAndSetInExecuteResult(executeResult, output,"methodOutput");
				checkForNullAndSetInExecuteResult(executeResult, errorMessage,"errorMessage");
				checkForNullAndSetInExecuteResult(executeResult, methodInvoked,"methodInvoked");
			}
        }
        return executeResult;
    }

    private void checkForNullAndSetInExecuteResult(final ExecuteResult executeResult,final Object value,final String key) {
    	if( value != null ) {
    		executeResult.setAttribute(key,value);	
    	}
    }
}
