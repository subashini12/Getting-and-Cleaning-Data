package it.sella.address.sm.addressmgt;

import it.sella.address.AddressException;
import it.sella.address.sm.ExecuterHelper;
import it.sella.anagrafe.GestoreAnagrafeFactory;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Collection;
import java.util.Map;

public class AddressDefaultExecuter extends GestioneIndirizziExecuter {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressDefaultExecuter.class);

	public it.sella.statemachine.ExecuteResult execute( final RequestEvent requestEvent ) {
		ExecuteResult executeResult = null;
		final StateMachineSession session = requestEvent.getStateMachineSession();
		try {
			final Long soggettoId = (Long)session.get("SoggettoId");
			final Long accountId = (Long)session.get("PCID");
			final String subSystemCausale = (String)session.get("SubSystemId");
			final String motiv = (String)session.get("ADMOTIV");

			logInputParams(soggettoId, accountId, subSystemCausale, motiv);
			
			if ( soggettoId == null || subSystemCausale == null || motiv == null ) {
				final String errorMsg = "Pass Valid Input params !!";
				throw new AddressException(errorMsg);
			}
			Collection accountAddress = getAccountAddress(soggettoId,accountId,subSystemCausale);
			if ( accountId != null && "CREATE".equals(motiv) && !accountAddress.isEmpty() ) {
				throw new AddressException(AddressErrorConstants.ERR16);
			}
			if ( accountAddress.size() == 1 && "VARIA".equalsIgnoreCase(motiv) ) {
				executeResult = ExecuterHelper.getExecuteResult("TrIntermediate");
			} else {
				executeResult = ExecuterHelper.getExecuteResult("TrDettaglio");
				final String tipoSoggetto = GestoreAnagrafeFactory.getInstance().getGestoreAnagrafe(
						).getTipoSoggetto((Long)session.get("SoggettoId"));
				final Map anagraficAddress = getAnagraficAddress(soggettoId,tipoSoggetto);
				accountAddress = getAccountAddress(soggettoId, null, subSystemCausale);
				setCommonDetails(executeResult,session,anagraficAddress,accountAddress,soggettoId,tipoSoggetto);
			}
		} catch ( final Exception re ) {
			log4Debug.severeStackTrace(re);
			executeResult = getNonConfermaExecuteResult(session);
		}
		return executeResult;
	}


	private void logInputParams(final Long soggettoId, final Long accountId,
			final String subSystemCausale, final String motiv) {
		log4Debug.debug(" AddressDefaultExecuter : execute : soggettoId :===>>>",soggettoId);
		log4Debug.debug(" AddressDefaultExecuter : execute : accountId :===>>>",accountId);
		log4Debug.debug(" AddressDefaultExecuter : execute : subSystemCausale :===>>>",subSystemCausale);
		log4Debug.debug(" AddressDefaultExecuter : execute : motiv :===>>>",motiv);
	}

	
	private ExecuteResult getNonConfermaExecuteResult( final StateMachineSession session ) {
		final ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
		clearSession(session);
		return executeResult;
	}
}