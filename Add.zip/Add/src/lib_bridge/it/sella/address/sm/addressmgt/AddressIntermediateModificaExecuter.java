package it.sella.address.sm.addressmgt;

import it.sella.address.AddressView;
import it.sella.address.sm.ExecuterHelper;
import it.sella.anagrafe.GestoreAnagrafeFactory;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Collection;

public class AddressIntermediateModificaExecuter extends GestioneIndirizziExecuter {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(
			AddressIntermediateModificaExecuter.class);
	
	public it.sella.statemachine.ExecuteResult execute( final RequestEvent requestEvent ) {
		ExecuteResult executeResult = null;
		final StateMachineSession session = requestEvent.getStateMachineSession();
		final Long soggettoId = (Long)session.get("SoggettoId");
		try {
			final String tipoSoggetto = GestoreAnagrafeFactory.getInstance().getGestoreAnagrafe(
					).getTipoSoggetto((Long)session.get("SoggettoId"));
			final Collection accountAddress = getAccountAddress(soggettoId,(Long)session.get("PCID"),
					(String)session.get("SubSystemId"));
			final AddressView addressView = (AddressView)accountAddress.iterator().next();
			executeResult = ExecuterHelper.getExecuteResult("TrConferma");
			setCommonDetails(executeResult,session,getAnagraficAddress(soggettoId,tipoSoggetto),
					accountAddress,soggettoId,tipoSoggetto);
			executeResult.setAttribute("tipoIndirizzo", addressView.getCausaleTipoIndirizzo());
			executeResult.setAttribute("ONLY_ONE_POSTALE_ADDRESS","YES") ;
			setInExecuteResultFromView(executeResult,addressView);
		} catch (final Exception e) {
			log4Debug.warnStackTrace(e);
			executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
			executeResult.setAttribute("errorMessage",e.getMessage());
		} 
		return executeResult;
	}
}
