
package it.sella.address.sm.gestionedomko;

import it.sella.address.AddressConstants;
import it.sella.address.AddressException;
import it.sella.address.AddressManagerFactory;
import it.sella.address.AddressView;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.dbhelper.AddressLogHelper;
import it.sella.address.implementation.util.ClassificazioneHandler;
import it.sella.address.implementation.util.Helper;
import it.sella.address.implementation.util.StringHandler;
import it.sella.statemachine.EventExecuter;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;

public class ConfermaExecuter implements EventExecuter {
    
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(ConfermaExecuter.class);

    public ExecuteResult execute(final RequestEvent requestEvent) {
        ExecuteResult executeResult = null;
        final StateMachineSession session = requestEvent.getStateMachineSession();
        final Map sessionTable = (Map) session.get(AddressConstants.ADDR_SESSION);
        Collection addressCollection = null;
        Long opId = null;
        String errorMessage = null;
        final AddressLogHelper addressLogHelper = new AddressLogHelper();
        try {
            String values[] = null;
            final Object selectedValue = requestEvent.getAttribute("domkoCheck");
            if (selectedValue != null) {
				values = selectedValue instanceof String ? new String[]{(String) selectedValue} : (String[]) selectedValue;
			}
            addressCollection = (Collection) sessionTable.get(AddressConstants.ADDR_COLL);
            final Map statusContos = (Map) sessionTable.get(AddressConstants.ADDR_STATUS_CONTOS);
            final AddressView addressView = new AddressView();
            addressView.setSoggettoId((Long)sessionTable.get(AddressConstants.ADDR_SOGGETTO_ID));
            opId = addressLogHelper.logAddressOperation("ADDR-GDOM", addressView, null, false);
            log4Debug.debug(" ConfermaExecuter: execute: opId :===>>>",opId);
            processDOMKO(opId, addressCollection, statusContos, selectedAddress(values));
            executeResult = Helper.getExecuteResult("TrConferma");
            session.remove(AddressConstants.ADDR_SESSION);
        } catch (final Exception e) {
            log4Debug.warnStackTrace(e);
            errorMessage = e.getMessage();
            executeResult = getNonConfermaExecuteResult(errorMessage);
            Helper.setDataToElencoAddress((Long)sessionTable.get(AddressConstants.ADDR_SOGGETTO_ID),executeResult,addressCollection,sessionTable);
        }  finally {
       	 	try {
       	 		addressLogHelper.updateAddressLog(opId, (Long)sessionTable.get(AddressConstants.ADDR_SOGGETTO_ID), errorMessage);
			} catch (final Exception e) {
				log4Debug.severe("This exception is just caught not to affect the parent transaction !!!!!");
				log4Debug.warnStackTrace(e);
			}
     }
        return executeResult;
    }

    private void processDOMKO(final Long opId, final Collection oldValueCollection, final Map statusContos, final Collection selectedContos) throws AddressException {
        try {
            AddressView addressView = null;
            final int size = oldValueCollection.size();
            final Iterator oldIterator = oldValueCollection.iterator();
			final Long domcpId = ClassificazioneHandler.getClassificazioneView("DOMCP","AEADD").getId();
			final Long domkoId = ClassificazioneHandler.getClassificazioneView("DOMKO","AEADD").getId();
			//Db change
			final Map oldContoDetails = new Hashtable();
			final Map newContoDetails = new Hashtable();
			final Map contoViews	= new Hashtable();
			//
            for (int i = 0; i < size; i++) {
                addressView = (AddressView) oldIterator.next();
                oldContoDetails.put(addressView.getProductContoId(),addressView.getInternal());
                contoViews.put(addressView.getProductContoId(),addressView);
                if(!"chiuso".equalsIgnoreCase((String) statusContos.get(addressView.getProductContoId()))) {
                    if (selectedContos.contains(addressView.getProductContoId().toString())) {
						addressView.setInternal(domkoId);
                    } else if (!domcpId.equals(addressView.getInternal())) {
						addressView.setInternal(getInternalId(addressView.getIndirizzo()));
                    }
                    newContoDetails.put(addressView.getProductContoId(),addressView.getInternal());
                }
            }
            //            
            final Collection updateCollection = getChangedAddressView(oldContoDetails,newContoDetails,contoViews,opId);
            if(!updateCollection.isEmpty()) {
            	AddressManagerFactory.getInstance().getAddressManager().modificaInternal(updateCollection);
            	logAddressOperationDetails(opId,"","");
            }
           // 
        } catch (final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            final String errorMsg = "Enter a valid causale value for DOMCP / DOMKO !!!";
			throw new AddressException(errorMsg);
        } catch (final Exception e) {
            log4Debug.warnStackTrace(e);
            throw new AddressException(e.getMessage());
        } 
    }
    
    private Collection getChangedAddressView(final Map oldConto, final Map newConto, final Map contoViews,final Long opId) {
    	final Collection output = new ArrayList();
    	final Enumeration enumeration = ((Hashtable)newConto).keys();
    	Long contoId = null;
    	final StringHandler stringHandler = new StringHandler();
    	AddressView addressView = null;
    	while(enumeration.hasMoreElements()) {
    		contoId = (Long)enumeration.nextElement();
    		if(!stringHandler.checkForEquality(oldConto.get(contoId),newConto.get(contoId))) {
    			addressView = (AddressView)contoViews.get(contoId);
    			addressView.setOpId(opId);
    			output.add(addressView);
    		}
    	}
    	return output;
    }

    private Collection selectedAddress(final String[] values) {
    	
        Collection outCollection = new ArrayList();
        if (values != null) {
        	outCollection = Arrays.asList(values);
//            for (int i = 0; i < values.length; i++) {
//				outCollection.add(values[i]);
//			}
        }
        return outCollection;
    }

    private Long getInternalId(final String indirizzo) throws AddressException {
    	String internalCausale = null;
        try {
            internalCausale = Helper.getInternalBasedOnIndirizzo(indirizzo);
            return ClassificazioneHandler.getClassificazioneView(internalCausale,"AEADD").getId();
        } catch (final SubSystemHandlerException e) {
            log4Debug.warnStackTrace(e);
            final String errorMsg = "Causale for Address AE Internal:"+internalCausale+" is invalid !!!";
			throw new AddressException(errorMsg);
        } catch (final Exception e) {
            log4Debug.warnStackTrace(e);
            throw new AddressException(e.getMessage());
        }
    }

    private ExecuteResult getNonConfermaExecuteResult(final String errorMessage) {
        final ExecuteResult executeResult = Helper.getExecuteResult("TrNonConferma");
        executeResult.setAttribute("errorMessage",errorMessage);
        return executeResult;
    }
    
    private static void logAddressOperationDetails(final Long opId, final String mapperMessage, final String addressData) {
    	try {
        	new AddressLogHelper().logAddressOpDetails(opId, mapperMessage, addressData);
		} catch (final Exception e) {
			log4Debug.severe("This exception is just caught not to affect the parent transaction !!!!!");
			log4Debug.warnStackTrace(e);
		}
    }

}
