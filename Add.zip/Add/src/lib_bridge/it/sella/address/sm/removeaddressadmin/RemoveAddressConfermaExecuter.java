package it.sella.address.sm.removeaddressadmin;

import it.sella.address.AddressException;
import it.sella.address.AddressManagerServiceFactory;
import it.sella.address.sm.ExecuterHelper;
import it.sella.statemachine.EventExecuter;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.Serializable;
import java.rmi.RemoteException;

public class RemoveAddressConfermaExecuter implements EventExecuter {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(RemoveAddressConfermaExecuter.class);
	public it.sella.statemachine.ExecuteResult execute( final RequestEvent requestEvent ) {
		String errorMessage = null;
		ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrConferma");
		final StateMachineSession session = requestEvent.getStateMachineSession();
		try {
        	AddressManagerServiceFactory.getInstance().getAddressServiceManager().removeUnusedAddress();
			session.put("removeAddressOutput","Unused address successfully removed");
			log4Debug.debug("Unused Address successfully removed");
        } catch ( final AddressException e ) {
            errorMessage = e.getMessage();
        } catch (final RemoteException e) {
            errorMessage = e.getMessage();
        }
		if ( errorMessage != null ) {
			executeResult = ExecuterHelper.getExecuteResult("TrError");
			executeResult.setAttribute("ERRORMESSAGE",(Serializable)errorMessage);
			log4Debug.debug("ERRORMESSAGE",errorMessage);
		} 
		return executeResult;
	}
}
