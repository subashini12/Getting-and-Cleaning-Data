package it.sella.address.sm.addressmgt;

import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.util.AnagrafeHandler;
import it.sella.anagrafe.INazioneView;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Map;

public abstract class InputDetailsHandlerExecuter extends GestioneIndirizziExecuter {
	
	protected static final String INDIRIZZO = "indirizzo";
	protected static final String CAP = "cap";
	protected static final String CITTA = "citta";
	protected static final String PROVINCIA = "provincia";
	protected static final String NAZIONE = "nazione";
	private static final String INTERNAL_ADDR = "INTERNAL_ADDR";
	protected static final String TIPOINDIRIZZO = "tipoIndirizzo";
	private static final String PRODUCTCONTOID = "productContoId";
	private static final String ONLY_ONE_POSTALE_ADDRESS = "ONLY_ONE_POSTALE_ADDRESS";
	private static final String IS_MODIFY_ALL_CLICKED = "IS_MODIFY_ALL_CLICKED";
	private static final String JNORM = "JNorm";
	protected static final String NORM_AMBIGUI_COL = "Norm_Ambigui_Col";
	private static final String NA_NOME = "NA_NOME";
	

	private void checkForNullAndSet(final RequestEvent requestEvent,final String keyRetrieve,final Map details,final String keyStore) {
		if(requestEvent.getAttribute(keyRetrieve) != null) {
			details.put(keyStore,((String)requestEvent.getAttribute(keyRetrieve)).trim().toUpperCase());
		}
	}

	Map getInputDetails(final RequestEvent requestEvent) {
		final Map details = new Hashtable();
		details.put(INDIRIZZO,((String) requestEvent.getAttribute(INDIRIZZO)).trim().toUpperCase());
		details.put(CAP,((String) requestEvent.getAttribute(CAP)).trim());
		details.put(CITTA,((String) requestEvent.getAttribute(CITTA)).trim().toUpperCase());
		details.put(PROVINCIA,((String) requestEvent.getAttribute(PROVINCIA)).trim().toUpperCase());
		details.put(NAZIONE,((String) requestEvent.getAttribute(NAZIONE)).trim().toUpperCase());
		details.put(INTERNAL_ADDR,((String) requestEvent.getAttribute(INTERNAL_ADDR)).trim());
		checkForNullAndSet(requestEvent,TIPOINDIRIZZO,details,TIPOINDIRIZZO);
		checkForNullAndSet(requestEvent,PRODUCTCONTOID,details,PRODUCTCONTOID);
		checkForNullAndSet(requestEvent,ONLY_ONE_POSTALE_ADDRESS,details,ONLY_ONE_POSTALE_ADDRESS);
		checkForNullAndSet(requestEvent,IS_MODIFY_ALL_CLICKED,details,IS_MODIFY_ALL_CLICKED);
		checkForNullAndSet(requestEvent,JNORM,details,JNORM);
		return details;
	}

	void setInputDetails(final ExecuteResult executeResult,final Map details,final Long internalId) {
		executeResult.setAttribute(INDIRIZZO, (Serializable)details.get(INDIRIZZO));
		executeResult.setAttribute(CAP, (Serializable)details.get(CAP));
		executeResult.setAttribute(CITTA, (Serializable)details.get(CITTA));
		executeResult.setAttribute(PROVINCIA, (Serializable)details.get(PROVINCIA));
		executeResult.setAttribute(NAZIONE, (Serializable)details.get(NAZIONE));
		executeResult.setAttribute(INTERNAL_ADDR,internalId != null ? internalId.toString() : (Serializable)details.get(INTERNAL_ADDR));
		checkForNullAndSetValue(details,TIPOINDIRIZZO,executeResult,TIPOINDIRIZZO);
		checkForNullAndSetValue(details,PRODUCTCONTOID,executeResult,PRODUCTCONTOID);
		checkForNullAndSetValue(details,IS_MODIFY_ALL_CLICKED,executeResult,IS_MODIFY_ALL_CLICKED);
		checkForNullAndSetValue(details,ONLY_ONE_POSTALE_ADDRESS,executeResult,ONLY_ONE_POSTALE_ADDRESS);
		checkForNullAndSetValue(details,NORM_AMBIGUI_COL,executeResult,NORM_AMBIGUI_COL);
		checkForNullAndSetValue(details,JNORM,executeResult,JNORM);
	}

	INazioneView getNazioneViewFromName(final String nazione) throws SubSystemHandlerException,RemoteException  {
		INazioneView nazioneView = null;
		final Map searchCriteria = new Hashtable();
		searchCriteria.put(NA_NOME, nazione);
		final Collection naziones = new AnagrafeHandler().getNazione(searchCriteria);
		if(naziones != null && !naziones.isEmpty()){
			nazioneView = (INazioneView)naziones.iterator().next();
		}
		return nazioneView;
	}

}
