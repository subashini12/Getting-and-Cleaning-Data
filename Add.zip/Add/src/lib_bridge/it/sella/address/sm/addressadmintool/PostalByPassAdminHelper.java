package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressException;
import it.sella.address.HelperException;
import it.sella.address.PostalByPassView;
import it.sella.address.implementation.util.DateHandler;
import it.sella.address.implementation.util.Helper;
import it.sella.statemachine.RequestEvent;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Timestamp;
import java.util.Map;

public class PostalByPassAdminHelper extends AdminHelper {
	
	private static final Log4Debug log4Debug  = Log4DebugFactory.getLog4Debug(PostalByPassAdminHelper.class);
	private static final String DATE_FORMAT = "dd/MM/yyyy";
	
	public void validateAllFields( final RequestEvent requestEvent, 
			final boolean isRqByPassCode ) throws AddressException, HelperException {
		if (isRqByPassCode) {
			isEmptyThrowException("ByPassCode",((String)requestEvent.getAttribute("byPassCode")).trim());
		}
		final String startDate = ((String)requestEvent.getAttribute("startDate")).trim();
		if (startDate == null || startDate.length() < 1) {
			final String errorMessage = "StartDate ";
			throw new AddressException(errorMessage+Helper.getMessage("ANAG-1264"));
		}
		isNotEmptyValidDateDateFormat(startDate);
		final String endDate = ((String)requestEvent.getAttribute("endDate")).trim();
		isNotEmptyValidDateDateFormat(endDate);
		if (endDate != null && endDate.length() > 0) {
			final DateHandler dateHandler = new DateHandler();
			final Timestamp endDateStamp = dateHandler.getTimestampFromDateString(endDate, DATE_FORMAT);
			final Timestamp sydate = dateHandler.getTimestampFromDateString(
					dateHandler.formatDate(dateHandler.getCurrentDateInTimeStampFormat(), DATE_FORMAT), DATE_FORMAT);
			if ( endDateStamp.compareTo(sydate) < 0 ) {
				final String errorMessage = "Endate ";
				throw new AddressException(errorMessage+Helper.getMessage("ANAG-1570"));
			}
		}
	}

	
	public PostalByPassView getPostalByPassView( final RequestEvent requestEvent, String byPassCode ) throws HelperException {
		final Map postalByPassDetails = (Map) requestEvent.getStateMachineSession().get("POSTALBYBASSDETAILS");
		final PostalByPassView postalByPassView = new PostalByPassView();
		byPassCode = (byPassCode == null ? (String)postalByPassDetails.get("BYBASSCODE") : byPassCode);
		postalByPassView.setBypassCode(byPassCode);
		postalByPassView.setDescription(getValue(requestEvent, "descrizione"));
		final String strStartDate = getValue(requestEvent, "startDate");
		final String strEndDate = getValue(requestEvent, "endDate");
    	log4Debug.debug(" PostalByPassAdminHelper: getPostalByPassView: strStartDate: ===>>",strStartDate);
	    log4Debug.debug(" PostalByPassAdminHelper: getPostalByPassView: strEndDate: ===>>",strEndDate);

		if (strStartDate != null) {
			postalByPassView.setStartDate(new DateHandler().getTimestampFromDateString(strStartDate, DATE_FORMAT));	
		}
		if (strEndDate != null) {
			postalByPassView.setEndDate(new DateHandler().getTimestampFromDateString(strEndDate, DATE_FORMAT));
		}
		postalByPassView.setNotes(getValue(requestEvent, "notes"));
		
		log4Debug.debug(" PostalByPassAdminHelper: getPostalByPassView: byPassCode :===>>",postalByPassView.getBypassCode());
    	log4Debug.debug(" PostalByPassAdminHelper: getPostalByPassView: descrizione : ===>>",postalByPassView.getDescription());
	    log4Debug.debug(" PostalByPassAdminHelper: getPostalByPassView: startDate :===>>",postalByPassView.getStartDate());
	    log4Debug.debug(" PostalByPassAdminHelper: getPostalByPassView: endDate :===>>",postalByPassView.getEndDate());
	    log4Debug.debug(" PostalByPassAdminHelper: getPostalByPassView: notes :===>>",postalByPassView.getNotes());
	    return postalByPassView;
	}
	
	private String getValue(final RequestEvent requestEvent, final String key) {
		String value = null;
		if(requestEvent.getAttribute(key) != null &&  ((String)requestEvent.getAttribute(key)).trim().length() > 0){
			value =  ((String)requestEvent.getAttribute(key)).trim();
		}
		return value;
	}
}