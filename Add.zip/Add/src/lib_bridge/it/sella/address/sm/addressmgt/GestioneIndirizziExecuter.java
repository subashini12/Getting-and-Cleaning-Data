package it.sella.address.sm.addressmgt;

import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.dbhelper.LogDBAccessHelper;
import it.sella.address.implementation.dbhelper.MUCAHelper;
import it.sella.address.implementation.util.AcfwHandler;
import it.sella.address.implementation.util.CPHandler;
import it.sella.address.implementation.util.CasiHandler;
import it.sella.address.implementation.util.SecurityHandler;
import it.sella.address.log.LogView;
import it.sella.anagrafe.GestoreAnagrafeFactory;
import it.sella.anagrafe.GestoreCollegamentoException;
import it.sella.carte.BridgeCarte;
import it.sella.carte.util.CarteException;
import it.sella.carte.view.DatiVisualizzazioneCartaForAddress;
import it.sella.casellariopostale.implementation.view.CasellarioContractView;
import it.sella.intestatazione.IntestatazioneException;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;

public abstract class GestioneIndirizziExecuter extends GestioneIndirizziBaseExecuter {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(GestioneIndirizziExecuter.class);

	void setCommonDetails( final ExecuteResult executeResult, final Long soggettoId, final StateMachineSession session ) {
		try {
			final String tipoSoggetto = GestoreAnagrafeFactory.getInstance().getGestoreAnagrafe().getTipoSoggetto(soggettoId);
			final Map anagAddress = getAnagraficAddress(soggettoId,tipoSoggetto);
			final Collection accountAddress = getAccountAddress(soggettoId,null,(String)session.get("SubSystemId"));
			setCommonDetails(executeResult,session,anagAddress,accountAddress,soggettoId,tipoSoggetto);
		} catch (final Exception e) {
			log4Debug.warnStackTrace(e);
			executeResult.setAttribute("errorMessage",e.getMessage());
		}
	}

	void setCommonDetails(final ExecuteResult executeResult,final StateMachineSession session,
			final Map anagraficAddress,final Collection accountAddress,
			final Long soggettoId,final String tipoSoggetto) throws AddressException,
			GestoreCollegamentoException,SubSystemHandlerException,IntestatazioneException,RemoteException {
		executeResult.setAttribute(AddressMgtConstants.ADDR_MOTIV, session.get("ADMOTIV"));
		executeResult.setAttribute(AddressMgtConstants.ADDR_SUBSYSTEM_CAUSALE, session.get("SubSystemId"));
		executeResult.setAttribute(AddressMgtConstants.ANAG_ADDR_COLL, anagraficAddress);
		executeResult.setAttribute(AddressMgtConstants.PROD_ADDR_COLL,accountAddress);
		final Map contoDetails = getNumeroAndTipoConto(accountAddress);
		checkForNullAndSetValue(contoDetails,"NUMERO_CONTOS",executeResult,AddressMgtConstants.ADDR_NUMERO_CONTOS);
		checkForNullAndSetValue(contoDetails,"TIPO_CONTOS",executeResult,AddressMgtConstants.ADDR_TIPO_CONTOS);
		checkForNullAndSetValue(contoDetails,"STATUS_CONTOS",executeResult,AddressMgtConstants.ADDR_STATUS_CONTOS);
		executeResult.setAttribute("logDatas",getDatasForLog(soggettoId));
		executeResult.setAttribute("intestazioneString","Plurintestazione".equals(tipoSoggetto) ? getIntestatariNames(soggettoId) : getIntestazioneString(soggettoId));
		executeResult.setAttribute("DOMCP_ID",getClassificazioneView("DOMCP","AEADD").getId());
		executeResult.setAttribute(AddressMgtConstants.ADDR_SOGGETTO_ID,soggettoId);
	}

	void clearSession(final StateMachineSession session) {
		session.remove("SoggettoId");
		session.remove("SubSystemId");
		session.remove("ADMOTIV");
		session.remove("PCID");
		session.remove("NCH");
		session.remove("MODIFY_ALL_CLICKED");
		session.remove("BEFORE_NORM_ADDR_VIEW");
		session.remove("FORZARE_DISPLAY");
	}

	void setInExecuteResultFromView(final ExecuteResult executeResult, final AddressView addressView) {
		notNullSetInExecuteResult(executeResult, addressView.getIndirizzo(), "indirizzo");
		if( addressView.getProductContoId() != null ) {
			executeResult.setAttribute("productContoId", addressView.getProductContoId());
		}
		notNullSetInExecuteResult(executeResult, addressView.getCitta(), "citta");
		notNullSetInExecuteResult(executeResult, addressView.getCap(), "cap");
		notNullSetInExecuteResult(executeResult, addressView.getProvincia(), "provincia");
		notNullSetInExecuteResult(executeResult, addressView.getNazione(), "nazione");
		executeResult.setAttribute("INTERNAL_ADDR",addressView.getInternal() != null ? addressView.getInternal().toString() : "");
	}
	
	private void notNullSetInExecuteResult(final ExecuteResult executeResult, final String value, final String key){
		executeResult.setAttribute(key, value != null ? value : "");
	}

	private Map getNumeroAndTipoConto(final Collection accountAddress) {
		final Map output = new Hashtable();
		if (accountAddress != null && !accountAddress.isEmpty()) {
			final int size = accountAddress.size();
			final Map numeroContos = new Hashtable(size);
			final Map tipoContos = new Hashtable(size);
			final Map statusContos = new Hashtable(size);
			final Iterator iterator = accountAddress.iterator();
			AddressView addressView = null;
			Map custodiaDetailMap = null;
			Map custodiaDetailTable = null;
			CasiHandler casiHandler = null;
			for (int i = 0 ; i < size ; i++) {
				addressView = (AddressView) iterator.next();
				String numeroConto = null;
				String tipoConto = null;
				String statusConto = null;
				if ("ACFW".equals(addressView.getCausaleSubsystem())) {
					try {
						final Map contoCharacteristics = AcfwHandler.getContoCharacteristics(addressView.getProductContoId(),"NC");
						tipoConto = (String)contoCharacteristics.get("TIPOCONTO_CAUSALE");
						boolean isAllowedForNumerati = false;
						try {
							isAllowedForNumerati = SecurityHandler.isOperationAllowedForNumerati((String)contoCharacteristics.get("SUCCURSALE"));
						} catch (final Exception e) {
							log4Debug.info("!!!!!!!!!!!!!!!! Exception caught just not to interuppt the flow");
						}
						numeroConto = ((Boolean)contoCharacteristics.get("IS_NUMERATO")).booleanValue() && !isAllowedForNumerati ?
										"Conto Numerato" : (String)contoCharacteristics.get("CODICE_ESTERNO");
						statusConto = contoCharacteristics.get("DATA_CHIUSURA") != null ? "chiuso" : "aperto";
					} catch (final Exception e) {
						log4Debug.info("!!!!!!!!!!!!!!!! Exception caught just not to interuppt the flow");
					}
				} else if ("CARTE".equals(addressView.getCausaleSubsystem())) {
                	try {
						final DatiVisualizzazioneCartaForAddress datiCarta = BridgeCarte.getInstance().getDatiVisualizzazioneCarta(addressView.getProductContoId());
						numeroConto = datiCarta != null && datiCarta.getDescrizioneFormattata() != null ? datiCarta.getDescrizioneFormattata() : ""  ;
					} catch (final CarteException e) {
						log4Debug.warnStackTrace(e);
					} 
				} else if("VIACARD".equals(addressView.getCausaleSubsystem())) {
					numeroConto = addressView.getProductContoId() != null ? addressView.getProductContoId().toString() : null;
				} else if("BANTEL".equals(addressView.getCausaleSubsystem())) {
					numeroConto = addressView.getProductContoId() != null ? addressView.getProductContoId().toString() : null;
					if(numeroConto != null && numeroConto.length() < 8) {
						numeroConto = get8DigitNumeroConto(numeroConto);
					}
				} else if("MUCA".equals(addressView.getCausaleSubsystem())) {
					numeroConto = new MUCAHelper().getMucaDisplayDetails(addressView.getProductContoId());
				}else if("MUCA".equals(addressView.getCausaleSubsystem())) {
					numeroConto = new MUCAHelper().getMucaDisplayDetails(addressView.getProductContoId());
				}else if("CASI".equals(addressView.getCausaleSubsystem())){
					if(casiHandler == null){
						casiHandler = new CasiHandler();
					}
					if(custodiaDetailMap == null){
						custodiaDetailMap = casiHandler.getCustodiaDetail(addressView.getSoggettoId());
					}
					if(custodiaDetailMap != null && !casiHandler.isEmptyCustodiaDeatail(custodiaDetailMap)){
						custodiaDetailTable = casiHandler.getCustodiaDetailForProductId(
								custodiaDetailMap, addressView.getProductContoId());
						if(custodiaDetailTable != null ){
							numeroConto = (String)custodiaDetailTable.get("cassettaLebel");
							statusConto = (String)custodiaDetailTable.get("cassettaStatus");
							tipoConto   = (String)custodiaDetailTable.get("cassettaType");
						}
					}
				}else if("CPDER".equals(addressView.getCausaleSubsystem())){
					final CasellarioContractView casellarioContractView = new CPHandler()
							.getCPNumero(addressView.getProductContoId());
					if(casellarioContractView != null){
						numeroConto = casellarioContractView.getCasellaNr();
						statusConto = ("Non Disponibile".equals(casellarioContractView.getState()) ||
								"Disponibile".equals(casellarioContractView.getState())) ? "chiuso"
								: casellarioContractView.getState();
					}
				}
				numeroContos.put(addressView.getProductContoId(), numeroConto != null ? numeroConto : "");
				tipoContos.put(addressView.getProductContoId(), tipoConto != null ? tipoConto : "");
				statusContos.put(addressView.getProductContoId(),statusConto != null ? statusConto : "");
			}
			output.put("NUMERO_CONTOS",numeroContos);
			output.put("TIPO_CONTOS",tipoContos);
			output.put("STATUS_CONTOS",statusContos);
		}
		return output;
	}

	private Map getDatasForLog(final Long soggettoId) throws AddressException {
		final Map logDataHash = new Hashtable();
		final Collection logDataCollection = new LogDBAccessHelper().getLogForSoggettoAndProductID(soggettoId);
		final int size = logDataCollection.size();
		final Iterator iterator = logDataCollection.iterator();
		for( int i=0;i<size;i++ ) {
			final LogView logView = (LogView) iterator.next();
			logDataHash.put(logView.getAccountId(),logView);
		}
		return logDataHash;
	}

	private String get8DigitNumeroConto(final String inputNumeroConto) {
		final StringBuffer output = new StringBuffer();
		final int length = inputNumeroConto.length();
		for (int i=length; i<8 ; i++) {
			output.append("0");
		}
		return output.append(inputNumeroConto).toString();
	}

}
