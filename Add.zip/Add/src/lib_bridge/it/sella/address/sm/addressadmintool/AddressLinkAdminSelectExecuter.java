/**
 * Created by IntelliJ IDEA.
 * User: ssile6
 * Date: Jan 18, 2005
 * Time: 6:18:27 PM
 * To change this template use Options | File Templates.
 */
package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressConstants;
import it.sella.address.AddressException;
import it.sella.address.HelperException;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.addresslink.AddressLink;
import it.sella.address.implementation.addresslink.IAddressLinkBeanManager;
import it.sella.address.implementation.factory.ReflectionUtil;
import it.sella.address.implementation.util.ClassificazioneHandler;
import it.sella.address.sm.ExecuterHelper;
import it.sella.address.sm.addressmgt.AddressMgtConstants;
import it.sella.statemachine.EventExecuter;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Map;

import javax.ejb.FinderException;

public class AddressLinkAdminSelectExecuter implements EventExecuter {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressLinkAdminSelectExecuter.class);
	private static final String TR_NONCONFERMA = "TrNonConferma";
	private static final String RDADDRESSLINKID = "rdAddressLinkId";
	private static final String SOGGETTOID = "soggettoId";
	private static final String SUBSYSTEM = "subSystem";
	private static final String ADDRESSTYPE = "addressType";
	private static final String PRODUCTID = "productId";
	private static final String ADDRESSID = "addressId";
	private static final String EVENTNAME = "eventName";
	private static final String ERRORMESSAGE = "errorMessage";
	

    public ExecuteResult execute(final RequestEvent requestEvent) {
        ExecuteResult executeResult = null;
        final StateMachineSession session = requestEvent.getStateMachineSession();
        String errorMessage = null;
        Map addressLinkDetails = null;
        final String addressLinkId = (String)requestEvent.getAttribute(RDADDRESSLINKID);
        try {
            validateAddressLinkId(addressLinkId);
            final IAddressLinkBeanManager addressLinkBeanManager  = (IAddressLinkBeanManager) ReflectionUtil.createServiceImplInstance(AddressConstants.BUNDLE_KEY, AddressConstants.DAOIMPL_KEY_FOR_ADDRESSLINK);
            final AddressLink addressLink = addressLinkBeanManager.findByPrimaryKey(Long.valueOf(addressLinkId));
            addressLinkDetails = new Hashtable();
            addressLinkDetails.put(SOGGETTOID, addressLink.getSoggettoId().toString());
            addressLinkDetails.put(AddressMgtConstants.ADRESSLINKID, addressLink.getAddressLinkId());
            setSubsytemInAddressLinkDetail(addressLinkDetails, addressLink.getSubSystem());
            setAddressTypeInAddressLinkDetail(addressLinkDetails, addressLink.getAddressType());
            isNotNullSetInMap(addressLinkDetails, PRODUCTID, addressLink.getLinkedId());
            isNotNullSetInMap(addressLinkDetails, ADDRESSID, addressLink.getAddressId());
            
            session.put(AddressMgtConstants.ADRESSLINKID, addressLinkId);
            session.put(AddressMgtConstants.OLDADDRESSLINKDETAILS, (Serializable)addressLinkDetails);
            final String eventName = (String) session.remove(EVENTNAME);
            executeResult = getExecuteResult(session, eventName);
            isNotNullSetInExecuteResultSet(executeResult, AddressMgtConstants.OLDADDRESSLINKDETAILS, addressLinkDetails);
            isNotNullSetInExecuteResultSet(executeResult, AddressMgtConstants.ADDRESSLINKDETAILS, addressLinkDetails);
            
        } catch (final HelperException e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult(TR_NONCONFERMA);
            errorMessage = e.getMessage();
        } catch(final NumberFormatException e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult(TR_NONCONFERMA);
            errorMessage = "Enter a valid Address Link Id !!!";
        } catch (final RemoteException e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult(TR_NONCONFERMA);
            errorMessage = "Enter a valid causale for Sub System / Address Type !!!";
        } catch (final FinderException e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult(TR_NONCONFERMA);
            errorMessage = "Record does not exists !!!";
        } catch (final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult(TR_NONCONFERMA);
            errorMessage = "Enter a valid causale for Sub System / Address Type !!!";
		}catch (final AddressException e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult(TR_NONCONFERMA);
            errorMessage = e.getMessage();
        }
        if(errorMessage != null) {
            executeResult.setAttribute(ERRORMESSAGE, errorMessage);
            isNotNullSetInExecuteResultSet(executeResult, AddressMgtConstants.ADRESSLINKID, addressLinkId);
            isNotNullSetInExecuteResultSet(executeResult, AddressMgtConstants.OLDADDRESSLINKDETAILS, session.get(AddressMgtConstants.OLDADDRESSLINKDETAILS));
            isNotNullSetInExecuteResultSet(executeResult, AddressMgtConstants.ADDRESSLINKDETAILS, session.get(AddressMgtConstants.ADDRESSLINKDETAILS));
        }
        return executeResult;
    }

	private void validateAddressLinkId(final String addressLinkId) throws HelperException {
		if(addressLinkId == null || addressLinkId.length() == 0) {
			throw new HelperException("Select a record");
		}
	}

	private ExecuteResult getExecuteResult(final StateMachineSession session, final String eventName) {
		ExecuteResult executeResult = null;
		if(eventName != null && "Modify".equals(eventName)) {
		    session.put(AddressMgtConstants.OPERATION, "MODIFY");
		    executeResult = ExecuterHelper.getExecuteResult("TrModifyConferma");
		} else if(eventName != null && "Remove".equals(eventName)) {
		    session.put(AddressMgtConstants.OPERATION, "DELETE");
		    executeResult = ExecuterHelper.getExecuteResult("TrDeleteConferma");
		}
		return executeResult;
	}

	private void setAddressTypeInAddressLinkDetail(Map addressLinkDetails, final Long addressType) throws SubSystemHandlerException, RemoteException {
		if(addressType != null) {
		    addressLinkDetails.put(ADDRESSTYPE, ClassificazioneHandler.getClassificazioneView(addressType).getCausale());
		}
	}

	private void setSubsytemInAddressLinkDetail(Map addressLinkDetails,	final Long subSystem) throws SubSystemHandlerException, RemoteException {
		if(subSystem != null) {
		    addressLinkDetails.put(SUBSYSTEM, ClassificazioneHandler.getClassificazioneView(subSystem).getCausale());
		}
	}
    
    public void isNotNullSetInExecuteResultSet( final ExecuteResult executeResult, final String key, final Object value) {
    	if( executeResult != null && key != null && value != null) {
    		executeResult.setAttribute(key,(Serializable)value);
    	}
    }
    
    public void isNotNullSetInMap( final Map table, final String key, final Object value) {
    	if( table != null && key != null && value != null) {
    		table.put(key,value.toString());
    	}
    }

}
