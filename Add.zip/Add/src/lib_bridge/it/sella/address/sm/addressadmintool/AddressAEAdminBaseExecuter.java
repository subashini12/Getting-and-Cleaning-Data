package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressException;
import it.sella.address.HelperException;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.ae.AEAddress;
import it.sella.address.implementation.ae.IAEAddressBeanManager;
import it.sella.address.implementation.factory.ReflectionUtil;
import it.sella.address.implementation.util.ClassificazioneHandler;
import it.sella.classificazione.ClassificazioneView;
import it.sella.statemachine.EventExecuter;
import it.sella.statemachine.RequestEvent;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Map;

import javax.ejb.FinderException;

public abstract class AddressAEAdminBaseExecuter implements EventExecuter {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAEAdminBaseExecuter.class);

    protected Map getAddressAEDetails(final RequestEvent requestEvent) throws AddressException, HelperException {
        final String addressLinkId = (String)requestEvent.getAttribute("txtAddressAELinkId");
        if(addressLinkId == null || addressLinkId.length() == 0) {
			final String errorMsg = "Enter Address Link Id";
			throw new HelperException(errorMsg);
		}
        final Map addressAEDetails = new Hashtable();
        try {
            final Long addressAELinkId = Long.valueOf(addressLinkId);
            final IAEAddressBeanManager aeAddressBeanManager = (IAEAddressBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.AEAddress");
	        final AEAddress aeAddress = aeAddressBeanManager.findByLinkedId(addressAELinkId);
            addressAEDetails.put("aeLinkId", addressLinkId);
            if(aeAddress.getReserved() != null) {
				addressAEDetails.put("aeReserved", aeAddress.getReserved().toString());
			}
            setClassificazioneViewDetails(aeAddress.getFrequency(),"aeFrequencyId","aeFrequency",addressAEDetails);
            setClassificazioneViewDetails(aeAddress.getInternal(),"aeInternalId","aeInternal",addressAEDetails);
        } catch (final FinderException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        } catch (final NumberFormatException e) {
            log4Debug.severeStackTrace(e);
            final String errorMsg = "Enter Valid Address Link Id";
			throw new AddressException(errorMsg);
        }
        return addressAEDetails;
    }

    private void setClassificazioneViewDetails(final Long id,final String keyId,final String keyCausale,final Map details) {
    	try {
    		if(id != null) {
	    		final ClassificazioneView clView = ClassificazioneHandler.getClassificazioneView(id);
	    		if(clView != null) {
	    			details.put(keyId,clView.getId().toString());
	    			details.put(keyCausale,clView.getCausale());
	    		}
    		}
		} catch (final RemoteException e) {
			log4Debug.warnStackTrace(e);
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
		}
    }
}
