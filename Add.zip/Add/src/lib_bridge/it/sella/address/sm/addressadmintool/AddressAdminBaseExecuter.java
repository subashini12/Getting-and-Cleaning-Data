package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressConstants;
import it.sella.address.AddressException;
import it.sella.address.HelperException;
import it.sella.address.implementation.addr.Address;
import it.sella.address.implementation.addr.IAddressBeanManager;
import it.sella.address.implementation.factory.ReflectionUtil;
import it.sella.address.sm.ExecuterHelper;
import it.sella.address.sm.addressmgt.AddressMgtConstants;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreAnagrafeFactory;
import it.sella.anagrafe.GestoreCittaException;
import it.sella.anagrafe.GestoreNazioneException;
import it.sella.anagrafe.GestoreProvinciaException;
import it.sella.anagrafe.ICittaView;
import it.sella.anagrafe.IGestoreAnagrafe;
import it.sella.anagrafe.IProvinciaView;
import it.sella.statemachine.EventExecuter;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.ExecuteResultFactory;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Map;

import javax.ejb.FinderException;

public abstract class AddressAdminBaseExecuter implements EventExecuter {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAdminBaseExecuter.class);
	private static final String CITTA = "citta";
	private static final String PROVINCIA = "provincia";
	private static final String NAZIONE = "nazione";
	private static final String INDIRIZZO = "indirizzo";
	private static final String CAP = "cap";

    public Map getAddressDetails(final RequestEvent requestEvent) throws AddressException {
        Long addressPrimaryKey = null;
        //AddressHome addressHome = null;
        Address address = null;
        Map addressDetails = null;
        IGestoreAnagrafe iGestoreAnagrafe = null;
        final String addressId = (String) requestEvent.getAttribute("txtAddressPkId");
        try {
	        validateAddressId(addressId);
	        addressPrimaryKey = Long.valueOf(addressId);
	        //addressHome = (AddressHome) Helper.getHomeObject("ADDRESSHOMENAME", "it.sella.address.implementation.addr.AddressHome");
	        final IAddressBeanManager manager =  (IAddressBeanManager) ReflectionUtil.createServiceImplInstance(AddressConstants.BUNDLE_KEY,AddressConstants.DAOIMPL_KEY_FOR_ADDRESS);
			address = manager.findByPrimaryKey(addressPrimaryKey);
			addressDetails = new Hashtable();
			addressDetails.put(AddressMgtConstants.ADDRESSPRIMARYKEY, addressPrimaryKey);
			iGestoreAnagrafe = GestoreAnagrafeFactory.getInstance().getGestoreAnagrafe();
			isNotNullSetInMap(addressDetails, INDIRIZZO, address.getIndirizzo());
			
			setCapInAddressDetailMap(address, addressDetails, iGestoreAnagrafe);
			setCittaInAddressDetailMap(address, addressDetails,iGestoreAnagrafe);
			setProvinciaInAddressDeatilMap(address, addressDetails,	iGestoreAnagrafe);
			if(address.getNazione() != null) {
				addressDetails.put(NAZIONE,iGestoreAnagrafe.getNazione(address.getNazione()).getNome());
			}
		} catch (final RemoteException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		} catch (final GestoreNazioneException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		} catch (final FinderException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		} catch (final GestoreAnagrafeException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		} catch (final HelperException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		} catch (final NumberFormatException e) {
			log4Debug.warnStackTrace(e);
			final String errorMsg = "Enter valid primary key of Address";
			throw new AddressException(errorMsg);
		}
		return addressDetails;
    }

	private void setProvinciaInAddressDeatilMap(Address address, Map addressDetails, IGestoreAnagrafe iGestoreAnagrafe) throws RemoteException {
		IProvinciaView provinciaView = null;
		try {
		    provinciaView = iGestoreAnagrafe.getProvincia(Long.valueOf(address.getProvincia()));
		    if(provinciaView == null) {
				throw new GestoreProvinciaException();
			}
		    addressDetails.put(PROVINCIA, provinciaView.getSigla());
		} catch (final NumberFormatException e) {
		    addressDetails.put(PROVINCIA, address.getProvincia() != null ? address.getProvincia() : "");
		} catch (final GestoreProvinciaException e) {
		    addressDetails.put(PROVINCIA, address.getProvincia() != null ? address.getProvincia() : "");
		}
	}

	private void setCittaInAddressDetailMap(Address address, Map addressDetails, IGestoreAnagrafe iGestoreAnagrafe)	throws RemoteException {
		ICittaView cittaView = null;
		try {
		    cittaView = iGestoreAnagrafe.getCitta(Long.valueOf(address.getCitta()));
		    if(cittaView == null) {
				throw new GestoreCittaException();
			}
		    addressDetails.put(CITTA, cittaView.getCommune());
		} catch (final NumberFormatException e) {
		    // addressDetails.put(CITTA, address.getCitta());
			addressDetails.put(CITTA, address.getCitta() !=null ? address.getCitta() : "");
		} catch (final GestoreCittaException e) {
			//addressDetails.put(CITTA, address.getCitta());
		    addressDetails.put(CITTA, address.getCitta() !=null ? address.getCitta() : "" );
		}
	}

	private void setCapInAddressDetailMap(Address address, Map addressDetails, IGestoreAnagrafe iGestoreAnagrafe) throws GestoreAnagrafeException,RemoteException {
		if(address.getCapId() != null) {
			addressDetails.put(CAP, (iGestoreAnagrafe.getCap(address.getCapId())).getCap());
		} else if(address.getCapValue() != null) {
			addressDetails.put(CAP, address.getCapValue());
		}
	}

	private void validateAddressId(final String addressId)
			throws HelperException {
		if(addressId == null || addressId.length() == 0) {
			final String errorMsg = "Enter a primary key of Address";
			throw new HelperException(errorMsg);
		}
	}
    
    protected void setAddressDetails(final RequestEvent requestEvent, final Map addressDetails) {
    	setValueInHashtable(INDIRIZZO, (String) requestEvent.getAttribute("txtIndirizzo"), addressDetails);
    	setValueInHashtable(CAP, (String) requestEvent.getAttribute("txtCap"), addressDetails);
    	setValueInHashtable(CITTA,(String) requestEvent.getAttribute("txtCitta"), addressDetails);
    	setValueInHashtable(PROVINCIA, (String) requestEvent.getAttribute("txtProvincia"), addressDetails);
    	setValueInHashtable(NAZIONE, (String) requestEvent.getAttribute("txtNazione"), addressDetails);
    }
    
    private void setValueInHashtable(final String key, final String value, final Map addressDetails) {
    	if(value != null) {
			addressDetails.put(key, value.trim().toUpperCase());
		}
    }
    
	public static ExecuteResult getExecuteResult( final String transition ) {
		return ExecuteResultFactory.getInstance().getExecuteResult(transition);
	}

    public ExecuteResult getNonConfermaExecuteResult( final String keyName, final String errorMessage ) {
        final ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
        executeResult.setAttribute(keyName, errorMessage);
        return executeResult;
    }
    
    public void isNotNullSetInExecuteResultSet( final ExecuteResult executeResult, final String key, final Object value) {
    	if( executeResult != null && key != null && value != null) {
    		executeResult.setAttribute(key,(Serializable)value);
    	}
    }
    
    public void isNotNullSetInSession( final StateMachineSession session, final String key, final Object value) {
    	if( session != null && key != null && value != null) {
    		session.put(key, (Serializable)value);
    	}
    }

    public void isNotNullSetInMap( final Map table, final String key, final Object value) {
    	if( table != null && key != null && value != null) {
    		table.put(key,value);
    	}
    }
    
    public String getLogForGivenTag( final String tagName, final String value ) {
        final StringBuffer output = new StringBuffer();
        return output.append("<").append(tagName).append(">").append(value).append("</").append(tagName).append(">").toString();
    }
}
