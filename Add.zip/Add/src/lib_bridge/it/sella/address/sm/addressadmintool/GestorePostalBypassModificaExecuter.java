package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressException;
import it.sella.address.PostalByPassView;
import it.sella.address.implementation.dbhelper.PostalFormatBypassHelper;
import it.sella.address.implementation.util.Helper;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineException;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Hashtable;
import java.util.Map;

public class GestorePostalBypassModificaExecuter extends AddressAdminBaseExecuter {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(GestorePostalBypassRicercaExecuter.class);

	public ExecuteResult execute(final RequestEvent requestEvent)	throws StateMachineException {
		ExecuteResult executeResult = null;
		final StateMachineSession session = requestEvent.getStateMachineSession();
		final Map postalByPassDetails = session.get("POSTALBYBASSDETAILS") != null ?
				(Map) session.get("POSTALBYBASSDETAILS") :  new Hashtable(1);
		final String byPassId = ((String)requestEvent.getAttribute("byPassId")).trim();
		PostalByPassView postalBypassView = null;
		try {
			log4Debug.debug("GestorePostalBypassModificaExecuter : execute : byPassId :===>>",byPassId);
			postalBypassView = new PostalFormatBypassHelper().getPostalFormatBypass(Long.valueOf(byPassId));
			log4Debug.debug("GestorePostalBypassModificaExecuter : execute : postalBypassView :===>>",postalBypassView);
			executeResult = Helper.getExecuteResult("TrConferma");
			isNotNullSetInMap(postalByPassDetails, "PostalBypassViewOld", postalBypassView);
			isNotNullSetInMap(postalByPassDetails, "PostalBypassViewNew", postalBypassView);
		} catch (final AddressException e) {
			log4Debug.severeStackTrace(e);
			executeResult = getNonConfermaExecuteResult("ErrorMessage", e.getMessage());
	    	final String byPassCode = (String) postalByPassDetails.get("BYBASSCODE");
	    	log4Debug.debug("GestorePostalBypassModificaExecuter : execute : byPassCode :===>>",byPassCode);
			try {
				isNotNullSetInExecuteResultSet(executeResult, "postalByPassList", new PostalFormatBypassHelper().getPostalFormatBypass(byPassCode));
			} catch (final Exception e1) {
				log4Debug.severeStackTrace(e1);
			}
		}
		isNotNullSetInMap(postalByPassDetails, "OPERATION","MODIFY");
		return executeResult;
	}	
}
