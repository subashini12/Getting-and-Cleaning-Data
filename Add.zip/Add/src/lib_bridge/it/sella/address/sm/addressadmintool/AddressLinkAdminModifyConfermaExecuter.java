/**
 * Created by IntelliJ IDEA.
 * User: ssile6
 * Date: Jan 18, 2005
 * Time: 4:01:02 PM
 * To change this template use Options | File Templates.
 */
package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressConstants;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.util.ClassificazioneHandler;
import it.sella.address.sm.ExecuterHelper;
import it.sella.address.sm.addressmgt.AddressMgtConstants;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.statemachine.EventExecuter;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Map;

public class AddressLinkAdminModifyConfermaExecuter implements EventExecuter {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressLinkAdminModifyConfermaExecuter.class);
	private static final String PRODUCTID = "productId";
	private static final String IS_MODIFY = "IS_MODIFY";
	private static final String SOGGETTOID = "soggettoId";
	private static final String SUBSYSTEM = "subSystem";
	private static final String ADDRESSTYPE = "addressType";
	private static final String ADDRESSID = "addressId";
	private static final String SOGGETTO_ID = "SOGGETTO_ID";
	private static final String ADDRESS_ID = "ADDRESS_ID";
	private static final String SUBSYS_ID = "SUBSYS_ID";
	private static final String PRODUCT_ID = "PRODUCT_ID";

    public ExecuteResult execute(final RequestEvent requestEvent) {
		ExecuteResult executeResult = null;
		Map addressLinkDetails = null;
        final StateMachineSession session = requestEvent.getStateMachineSession();
        try {
			addressLinkDetails = getInputDetails(requestEvent);
			validateInputDetails(addressLinkDetails);
			session.put(AddressMgtConstants.ADDRESSLINKDETAILS, (Serializable)addressLinkDetails);
			executeResult = ExecuterHelper.getExecuteResult("TrConferma");
			executeResult.setAttribute(IS_MODIFY,"TRUE");
			session.put(AddressMgtConstants.OPERATION,"MODIFY");
        } catch (final ControlloDatiException e) {
			log4Debug.severeStackTrace(e);
			executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
			executeResult.setAttribute("errorMessage", e.getMessage());
		}
        executeResult.setAttribute(AddressMgtConstants.ADDRESSLINKDETAILS, (Serializable)addressLinkDetails);
        executeResult.setAttribute(AddressMgtConstants.OLDADDRESSLINKDETAILS, session.get(AddressMgtConstants.OLDADDRESSLINKDETAILS));
        return executeResult;
    }

	private Map getInputDetails(final RequestEvent requestEvent) {
		final Map addressLinkDetails = new Hashtable();
		setDetails(requestEvent,"txtSoggettoId",SOGGETTOID,addressLinkDetails);
		setDetails(requestEvent,"txtSubsystem",SUBSYSTEM,addressLinkDetails);
		setDetails(requestEvent,"txtAddressType",ADDRESSTYPE,addressLinkDetails);
		setDetails(requestEvent,"txtProductId",PRODUCTID,addressLinkDetails);
		setDetails(requestEvent,"txtAddressId",ADDRESSID,addressLinkDetails);
		return addressLinkDetails;
	}

	private void setDetails(final RequestEvent requestEvent,final String retrieveKey,final String putKey,final Map addressLinkDetails) {
		if(((String)requestEvent.getAttribute(retrieveKey)).trim().length() > 0) {
			final String soggettoId = ((String) requestEvent.getAttribute(retrieveKey)).trim();
			addressLinkDetails.put(putKey, soggettoId);
		}
	}

	private void validateInputDetails(final Map addressLinkDetails) throws ControlloDatiException {
		addressLinkDetails.put(SOGGETTO_ID,isValidNumber(addressLinkDetails,SOGGETTOID));
		addressLinkDetails.put(ADDRESS_ID,isValidNumber(addressLinkDetails,ADDRESSID));
		addressLinkDetails.put(SUBSYS_ID,isValidCausale(addressLinkDetails,SUBSYSTEM,AddressConstants.SUBSYS));
		if(!"ANAG".equals(addressLinkDetails.get(SUBSYSTEM))) {
			addressLinkDetails.put(PRODUCT_ID,isValidNumber(addressLinkDetails,PRODUCTID));
		} else if(addressLinkDetails.get(PRODUCTID) != null && ((String)addressLinkDetails.get(PRODUCTID)).trim().length() > 0) {
			final String errorMsg = "ProductId must be null";
			throw new ControlloDatiException(errorMsg);
		}
		addressLinkDetails.put("TIPO_IND_ID",isValidCausale(addressLinkDetails,ADDRESSTYPE,"IND"));
	}

	private Long isValidNumber(final Map addressLinkDetails,final String key) throws ControlloDatiException {
		try {
			if(addressLinkDetails.get(key) == null) {
				throw new ControlloDatiException(key+" is mandatory !");
			}
			return Long.valueOf((String)addressLinkDetails.get(key));
		} catch (final NumberFormatException e) {
			log4Debug.warnStackTrace(e);
			throw new ControlloDatiException(key+ " is invalid !");
		}
	}

	private Long isValidCausale(final Map addressLinkDetails,final String key,final String parentCausale) throws ControlloDatiException {
		try {
			if(addressLinkDetails.get(key) == null) {
				throw new ControlloDatiException(key+" is mandatory !");
			}
			return ClassificazioneHandler.getClassificazioneView((String)addressLinkDetails.get(key),parentCausale).getId();
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new ControlloDatiException(key+" causale is invalid !");
		} catch (final RemoteException e) {
			log4Debug.warnStackTrace(e);
			throw new ControlloDatiException(key+" causale is invalid !");
		}
	}
}
