package it.sella.address.sm;

import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.address.sm.addressmgt.AddressErrorConstants;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.ExecuteResultFactory;

import java.util.Map;

public class ExecuterHelper extends ExecuterBaseHelper {
	
	public static ExecuteResult getExecuteResult(final String transition) {
		return ExecuteResultFactory.getInstance().getExecuteResult(transition);
	}

    public static AddressView validateIndirizzo(final Map addressDetails) throws AddressException {
    	final String indirizzo = (String)addressDetails.get("indirizzo");
    	final String cap  = (String)addressDetails.get("cap");
    	final String citta = (String)addressDetails.get("citta");
    	final String provincia = (String)addressDetails.get("provincia");
    	final String nazione = (String)addressDetails.get("nazione");
        AddressView addressView = null;
        checkForDummyString(indirizzo, AddressErrorConstants.ERR02);
        if(indirizzo.indexOf('(') != -1 || indirizzo.indexOf(')') != -1 || indirizzo.indexOf('^') != -1) {
			throw new AddressException(AddressErrorConstants.ERR19);
		}
        checkForDummyString(citta, AddressErrorConstants.ERR03);
        if(citta.indexOf('(') != -1 || citta.indexOf(')') != -1 || citta.indexOf('^') != -1) {
			throw new AddressException(AddressErrorConstants.ERR19);
		}
        checkForDummyString(nazione, AddressErrorConstants.ERR04);
        addressView = getAddressView(indirizzo, cap, citta, provincia, nazione);
        return addressView;
    }

}
