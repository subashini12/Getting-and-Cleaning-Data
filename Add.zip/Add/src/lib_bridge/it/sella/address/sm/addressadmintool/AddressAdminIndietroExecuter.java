/**
 * Created by IntelliJ IDEA.
 * User: ssile6
 * Date: Jan 5, 2005
 * Time: 3:29:16 PM
 * To change this template use Options | File Templates.
 */
package it.sella.address.sm.addressadmintool;

import it.sella.address.sm.ExecuterHelper;
import it.sella.address.sm.addressmgt.AddressMgtConstants;
import it.sella.statemachine.EventExecuter;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;

import java.io.Serializable;
import java.util.Map;

public class AddressAdminIndietroExecuter implements EventExecuter {
	
	private static final String CITTA = "citta";
	private static final String PROVINCIA = "provincia";
	private static final String NAZIONE = "nazione";
	private static final String INDIRIZZO = "indirizzo";
	private static final String CAP = "cap";
	private static final String ADD = "ADD";
	private static final String MODIFY = "MODIFY";
	private static final String DELETE = "DELETE";
	
	public ExecuteResult execute(final RequestEvent requestEvent) {
        ExecuteResult executeResult = null;
        final StateMachineSession session = requestEvent.getStateMachineSession();
        final String operation = (String) session.get(AddressMgtConstants.OPERATION);
        if(ADD.equals(operation)) {
            executeResult = ExecuterHelper.getExecuteResult("TrAddIndietro");
            final Map addressDetails = (Map) session.get(AddressMgtConstants.ADDRESSDETAILS);
            if(addressDetails != null) {
                executeResult.setAttribute(INDIRIZZO, (Serializable)addressDetails.get(INDIRIZZO));
                executeResult.setAttribute(CAP, (Serializable)addressDetails.get(CAP));
                executeResult.setAttribute(CITTA, (Serializable)addressDetails.get(CITTA));
                executeResult.setAttribute(PROVINCIA, (Serializable)addressDetails.get(PROVINCIA));
                executeResult.setAttribute(NAZIONE, (Serializable)addressDetails.get(NAZIONE));
            }
        } else if(MODIFY.equals(operation)) {
            executeResult = ExecuterHelper.getExecuteResult("TrModifyIndietro");
            if(session.get(AddressMgtConstants.OLDADDRESSDETAILS) != null) {
				executeResult.setAttribute(AddressMgtConstants.OLDADDRESSDETAILS,session.get(AddressMgtConstants.OLDADDRESSDETAILS));
			}
            if(session.get(AddressMgtConstants.ADDRESSDETAILS) != null) {
				executeResult.setAttribute(AddressMgtConstants.ADDRESSDETAILS, session.get(AddressMgtConstants.ADDRESSDETAILS));
			}
            if(session.get(AddressMgtConstants.ADDRESSPRIMARYKEY) != null) {
				executeResult.setAttribute(AddressMgtConstants.ADDRESSPKID, session.get(AddressMgtConstants.ADDRESSPRIMARYKEY));
			}
        } else if(DELETE.equals(operation)) {
            executeResult = ExecuterHelper.getExecuteResult("TrDeleteIndietro");
            if(session.get(AddressMgtConstants.ADDRESSPKID) != null) {
				executeResult.setAttribute(AddressMgtConstants.ADDRESSPKID, session.get(AddressMgtConstants.ADDRESSPKID));
			}
        }
        return executeResult;
    }
}
