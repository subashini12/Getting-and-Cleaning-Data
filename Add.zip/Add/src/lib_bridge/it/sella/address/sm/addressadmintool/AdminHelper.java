package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressException;
import it.sella.address.HelperException;
import it.sella.address.implementation.util.DateHandler;
import it.sella.address.implementation.util.Helper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.StringTokenizer;

public class AdminHelper {

	private static final Log4Debug log4Debug  = Log4DebugFactory.getLog4Debug(AdminHelper.class);
	
	public boolean isEmpty( final String fieldValue ) {
		boolean emptyValue = false;
		if ( fieldValue == null || "".equals(fieldValue)) {
			emptyValue = true;
		}
		return emptyValue;
	}

	public void isEmptyThrowException( final String fieldName, final String fieldValue ) throws AddressException {
		if (isEmpty(fieldValue)) {
			throw new AddressException(fieldName+" "+Helper.getMessage("ANAG-1264"));
		}
	}
	
	public void isNotNumericThrowException( final String fieldName, final String fieldValue) throws AddressException {
		try {
			log4Debug.debug(" AdminHelper : isNotNumericThrowException : fieldName :===>>",fieldName);
			log4Debug.debug(" AdminHelper : isNotNumericThrowException : fieldValue :===>>",fieldValue);
			isEmptyThrowException(fieldName,fieldValue);
			Long.parseLong(fieldValue);
		} catch (final NumberFormatException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(Helper.getMessage("ANAG-1383")+ " for " + fieldName);
		} 
	}
	
	public void isNotEmptyValidDateDateFormat( final String fieldValue ) throws AddressException {
		if (!isEmpty(fieldValue)) {
			final StringTokenizer dataInizioTokens = new StringTokenizer(fieldValue,"/");
			try {
				if(!(dataInizioTokens.countTokens()==3)) {
					throw new AddressException(Helper.getMessage("ANAG-1320"));
				}
				new DateHandler().getTimestampFromDateString(fieldValue,"dd/MM/yyyy");
			} catch (final HelperException e) {
				log4Debug.warnStackTrace(e);
				throw new AddressException(e.getMessage());
			}
		}
	}
}
