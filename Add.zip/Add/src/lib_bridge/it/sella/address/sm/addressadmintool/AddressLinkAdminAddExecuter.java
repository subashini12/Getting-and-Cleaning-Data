package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressException;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.util.ClassificazioneHandler;
import it.sella.address.sm.ExecuterHelper;
import it.sella.statemachine.EventExecuter;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Map;

public class AddressLinkAdminAddExecuter implements EventExecuter {
    
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressLinkAdminAddExecuter.class);

    public ExecuteResult execute(final RequestEvent requestEvent) {
        ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrConferma");
        final StateMachineSession session = requestEvent.getStateMachineSession();
        final Map addressLinkDetails = new Hashtable();
        try {
            final String soggettoId = (String) requestEvent.getAttribute("txtSoggettoId");
            final String subSystem = ((String) requestEvent.getAttribute("txtSubsystem")).toUpperCase();
            final String addressType = ((String) requestEvent.getAttribute("txtAddressType")).toUpperCase();
            final String productId = (String) requestEvent.getAttribute("txtProductId");
            final String addressId = (String) requestEvent.getAttribute("txtAddressId");
            
            addressLinkDetails.put("soggettoId", soggettoId);
            addressLinkDetails.put("subSystem", subSystem);
            addressLinkDetails.put("productId", productId);
            addressLinkDetails.put("addressId", addressId);
            addressLinkDetails.put("addressType", addressType);
            
            addressLinkDetails.put("longSoggettoId", Long.valueOf(soggettoId));
            addressLinkDetails.put("longSubsystem", ClassificazioneHandler.getClassificazioneView(subSystem,"SUBSYS").getId());
            addressLinkDetails.put("longAddressType", ClassificazioneHandler.getClassificazioneView(addressType,"IND").getId());
            if(!"ANAG".equals(subSystem)) {
	            addressLinkDetails.put("longProductId", Long.valueOf(productId));
            } else if(productId != null && productId.trim().length() > 0) {
				final String errorMsg = "Product Id must be null";
				throw new AddressException(errorMsg);
			}
            addressLinkDetails.put("longAddressId", Long.valueOf(addressId));
            executeResult.setAttribute("addressLinkDetails", (Serializable)addressLinkDetails);
        } catch (final NumberFormatException e) {
            log4Debug.severeStackTrace(e);
            executeResult = getNonConfermaTransition(addressLinkDetails,"Enter a valid Soggetto Id / Product Id / Address Id !!!");
        } catch (final RemoteException e) {
            log4Debug.severeStackTrace(e);
            executeResult = getNonConfermaTransition(addressLinkDetails,"Enter valid causale for type Sub System / Address Type");
        } catch (final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            executeResult = getNonConfermaTransition(addressLinkDetails,"Enter valid causale for type Sub System / Address Type");
		} catch (final Exception e) {
            log4Debug.severeStackTrace(e);
            executeResult = getNonConfermaTransition(addressLinkDetails,e.getMessage());
		}
        session.put("addressLinkDetails", (Serializable)addressLinkDetails);
        session.put("OPERATION", "ADD");
        return executeResult;
    }

    private ExecuteResult getNonConfermaTransition(final Map addressLinkDetails,final String errorMessage) {
    	final ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
        executeResult.setAttribute("errorMessage", errorMessage);
        setDatasOnError(addressLinkDetails, executeResult);
        return executeResult;
    }
    
    private void setDatasOnError(final Map addressDetails, final ExecuteResult executeResult) {
    	setInExecuteResultAfterNullCheck(executeResult,addressDetails.get("soggettoId"),"soggettoId");
    	setInExecuteResultAfterNullCheck(executeResult,addressDetails.get("subSystem"),"subSystem");
    	setInExecuteResultAfterNullCheck(executeResult,addressDetails.get("addressType"),"addressType");
    	setInExecuteResultAfterNullCheck(executeResult,addressDetails.get("productId"),"productId");
    	setInExecuteResultAfterNullCheck(executeResult,addressDetails.get("addressId"),"addressId");
    }
    
    private void setInExecuteResultAfterNullCheck(final ExecuteResult executeResult,final Object value,final String key) {
    	if(value != null) {
			executeResult.setAttribute(key,(Serializable)value);
		}
    }
}
