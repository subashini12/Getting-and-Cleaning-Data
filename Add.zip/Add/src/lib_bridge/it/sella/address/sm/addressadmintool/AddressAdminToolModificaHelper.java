package it.sella.address.sm.addressadmintool;


import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.address.implementation.AddressAdminFactory;
import it.sella.address.implementation.addresslink.AddressLinkView;
import it.sella.address.implementation.dbhelper.AddressLogHelper;
import it.sella.address.implementation.util.UtilHelper;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Map;

public class AddressAdminToolModificaHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAdminToolModificaHelper.class);

    public static void modifyAddress(final Long opId, final AddressView addressView, final Long addressPrimaryKey, final StateMachineSession session) throws AddressException {
        String loggerOperation = "FAILURE";
        final StringBuffer logData = new StringBuffer();
        try {
        	addressView.setOpId(opId);
        	AddressAdminFactory.getInstance().getAddressAdmin().updateAddressAdmin(addressPrimaryKey, addressView);
        	loggerOperation = "SUCCESS";
            final Map addressDetails = (Map) session.get("addressDetails");
            final Map oldAddressDetails = (Map) session.get("oldAddressDetails");
            logData.append(UtilHelper.getTag("OLD_ADDRESS_DETAILS", AddressAdminToolLogger.getAddressDetailsForLog(oldAddressDetails)));
            logData.append(UtilHelper.getTag("NEW_ADDRESS_DETAILS", AddressAdminToolLogger.getAddressDetailsForLog(addressDetails)));
            AddressAdminToolLogger.logMessage("ADDRESS ADMIN MODIFY", logData.toString(), "ADDR-MOD", loggerOperation);
            logAddressOperationDetails(opId,"","");
        } catch (final Exception e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        } 
    }

    public static void modifyAddressLink(final Long opId, final StateMachineSession session) throws AddressException {
        String loggerOperation = "FAILURE";
        final StringBuffer logData = new StringBuffer();
        try {
            final Map addressLinkDetails = (Map) session.get("addressLinkDetails");
            final Long addressLinkId = Long.valueOf((String) session.get("addressLinkId"));
            
            final AddressLinkView addressLinkView = new AddressLinkView();
            
            addressLinkView.setSoggettoId((Long)addressLinkDetails.get("SOGGETTO_ID"));
            addressLinkView.setSubSystem((Long)addressLinkDetails.get("SUBSYS_ID"));
            addressLinkView.setAddressType((Long) addressLinkDetails.get("TIPO_IND_ID"));
            addressLinkView.setLinkedId((Long) addressLinkDetails.get("PRODUCT_ID"));
            addressLinkView.setAddressId((Long) addressLinkDetails.get("ADDRESS_ID"));
            addressLinkView.setOpId(opId);
            AddressAdminFactory.getInstance().getAddressAdmin().updateAddressLinkAdmin(addressLinkId, addressLinkView);
            
            loggerOperation = "SUCCESS";
            final Map oldAddressLinkDetails = (Map) session.get("oldAddressLinkDetails");
            logData.append(UtilHelper.getTag("OLD_ADDRESSLINK_DETAILS", AddressAdminToolLogger.getAddressLinkDetailsForLog(oldAddressLinkDetails)));
            logData.append(UtilHelper.getTag("NEW_ADDRESSLINK_DETAILS", AddressAdminToolLogger.getAddressLinkDetailsForLog(addressLinkDetails)));
            AddressAdminToolLogger.logMessage("ADDRESS ADMIN MODIFY", logData.toString(), "ADLK-MOD", loggerOperation);
            logAddressOperationDetails(opId,"","");
        } catch (final NumberFormatException e) {
            log4Debug.severeStackTrace(e);
            final String errorMsg = "Enter a valid Address Link Id !!!";
			throw new AddressException(errorMsg);
        } catch (final Exception e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        }
    }

    public static void modifyAddressAE(final Long opId, final StateMachineSession session) throws AddressException {
        String loggerOperation = "FAILURE";
        final StringBuffer logData = new StringBuffer();
        try {
            final Long addressAELinkId = (Long) session.get("addressAELinkId");
            final Map addressAEDetails = (Map) session.get("addressAEDetails");
            final AddressView addressView = new AddressView();
            if(addressAEDetails != null) {
            	addressView.setReserved(Long.valueOf((String) addressAEDetails.get("aeReserved")));
            	addressView.setFrequency((Long) addressAEDetails.get("aeFrequencyId"));
            	addressView.setInternal((Long) addressAEDetails.get("aeInternalId"));
            	addressView.setOpId(opId);
            	AddressAdminFactory.getInstance().getAddressAdmin().updateAddressAEAdmin(addressAELinkId, addressView);
            }	
            final Map oldAddressAEDetails = (Map) session.get("oldAddressAEDetails");
            loggerOperation = "SUCCESS";
            logData.append(UtilHelper.getTag("OLD_ADDRESSAE_DETAILS", AddressAdminToolLogger.getAddressAEDetailsForLog(oldAddressAEDetails)));
            logData.append(UtilHelper.getTag("NEW_ADDRESSAE_DETAILS", AddressAdminToolLogger.getAddressAEDetailsForLog(addressAEDetails)));
            AddressAdminToolLogger.logMessage("ADDRESS ADMIN MODIFY", logData.toString(), "ADAE-MOD", loggerOperation);
            logAddressOperationDetails(opId,"","");
        } catch (final NumberFormatException e) {
            log4Debug.severeStackTrace(e);
            final String errorMsg = "Enter valid Address AE Reserved !!!";
			throw new AddressException(errorMsg);
        } catch (final Exception e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        } 
    }
    
    private static void logAddressOperationDetails(final Long opId, final String mapperMessage, final String addressData) {
    	try {
        	new AddressLogHelper().logAddressOpDetails(opId, mapperMessage, addressData);
		} catch (final Exception e) {
			log4Debug.severe("This exception is just caught not to affect the parent transaction !!!!!");
			log4Debug.warnStackTrace(e);
		}
    }
}
