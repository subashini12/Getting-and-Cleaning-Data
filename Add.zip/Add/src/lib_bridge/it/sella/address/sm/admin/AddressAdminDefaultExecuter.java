package it.sella.address.sm.admin;

import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.address.implementation.AddressAdminFactory;
import it.sella.address.sm.ExecuterHelper;
import it.sella.statemachine.EventExecuter;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;

public class AddressAdminDefaultExecuter implements EventExecuter {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAdminDefaultExecuter.class);
	private static final String PRODUCTCONTOID = "ProductContoId";
	private static final String NCH = "NCH";
	private static final String ADDRESSVIEW = "ADDRESSVIEW";
	private static final String ERRORMESSAGE = "errorMessage";
    
    public it.sella.statemachine.ExecuteResult execute( final RequestEvent requestEvent ) {
        String errorMessage = null;
        final ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrConferma");
        final StateMachineSession session = requestEvent.getStateMachineSession();
        try {
            if ( session.get(ADDRESSVIEW) != null ) {
            	final AddressView addressView = (AddressView) session.remove(ADDRESSVIEW);

            	log4Debug.debug(" AddressAdminDefaultExecuter : execute : addressView :===>>>",addressView);
            	log4Debug.debug(" AddressAdminDefaultExecuter : execute : ProductContoId :===>>>",session.get(PRODUCTCONTOID));
            	log4Debug.debug(" AddressAdminDefaultExecuter : execute : NCH :===>>>",session.get(NCH));
            	
                if ( !"ANAG".equals(addressView.getCausaleSubsystem()) && session.get(PRODUCTCONTOID) != null && 
                	  !"".equals(session.get(PRODUCTCONTOID))) {
                    addressView.setProductContoId((Long)session.get(PRODUCTCONTOID));
					if( session.get(NCH) != null && ((String)session.get(NCH)).trim().length() > 0 ) {
						addressView.setNch((String)session.get(NCH));	
					}
                }
                AddressAdminFactory.getInstance().getAddressAdmin().createAddress(addressView);
            }
            if (session.get("removeAddressOutput") != null ) {
            	executeResult.setAttribute("removeAddressOutput", session.remove("removeAddressOutput"));
            }
        } catch ( final AddressException e ) {
            errorMessage = e.getMessage();
        } catch (final RemoteException e) {
            errorMessage = e.getMessage();
        }
        if ( errorMessage != null ) {
        	executeResult.setAttribute(ERRORMESSAGE, errorMessage);	
        }
        return executeResult;
    }
}
