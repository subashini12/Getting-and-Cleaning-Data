
package it.sella.address.sm.addressadmintool;



import it.sella.address.implementation.dbhelper.AddressLogHelper;
import it.sella.address.sm.ExecuterHelper;
import it.sella.statemachine.EventExecuter;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

public class AddressAEAdminConfermaExecuter implements EventExecuter {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAEAdminConfermaExecuter.class);

    public ExecuteResult execute(final RequestEvent requestEvent) {
        String errorMessage = null;
        Long opId = null;
        final AddressLogHelper addressLogHelper = new AddressLogHelper();
        ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrConferma");
        final StateMachineSession session = requestEvent.getStateMachineSession();
        final String operation = (String) session.get("OPERATION");
        try {
            if("MODIFY".equals(operation)) {
        		opId = addressLogHelper.logAddressOperation("ADAE-MOD", null, null, false);
        		AddressAdminToolHelper.modifyAddressAE(opId, session);
            } else if("DELETE".equals(operation)) {
            	opId = addressLogHelper.logAddressOperation("ADAE-DEL", null, null, false);
                AddressAdminToolHelper.deleteAddressAE(opId, session);
            } else if("ADD".equals(operation)){
            	opId = addressLogHelper.logAddressOperation("ADAE-INST", null, null, false);
                final Long primaryKey = AddressAdminToolHelper.createAddressAE(opId, session);
                if(primaryKey != null) {
					session.put("PRIMARY_KEY", primaryKey);
				}
            }
        } catch (final Exception e) {
            log4Debug.warnStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
            errorMessage = e.getMessage();
            executeResult.setAttribute("errorMessage", errorMessage);
            if(session.get("addressDetails") != null) {
                executeResult.setAttribute("addressDetails", session.get("addressDetails"));
            }
        } finally {
       	 	try {
       	 		addressLogHelper.updateAddressLog(opId, null, errorMessage);
			} catch (final Exception e) {
				log4Debug.severe("This exception is just caught not to affect the parent transaction !!!!!");
				log4Debug.warnStackTrace(e);
			}
     }
     return executeResult;
   }
    
}
