/**
 * Created by IntelliJ IDEA.
 * User: ssile6
 * Date: Feb 1, 2005
 * Time: 9:38:15 AM
 * To change this template use Options | File Templates.
 */
package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressException;
import it.sella.address.implementation.util.UtilHelper;
import it.sella.logserver.LoggerClient;
import it.sella.logserver.LoggerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Map;

public class AddressAdminToolLogger {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAdminToolLogger.class);

    public static String getAddressDetailsForLog(final Map addressDetails) {
        final StringBuffer logBuffer = new StringBuffer();
        UtilHelper.addLog(logBuffer, "INDIRIZZO", (String) addressDetails.get("indirizzo"));
        UtilHelper.addLog(logBuffer, "CAP", (String) addressDetails.get("cap"));
        UtilHelper.addLog(logBuffer, "CITTA", (String) addressDetails.get("citta"));
        UtilHelper.addLog(logBuffer, "PROVINCIA", (String) addressDetails.get("provincia"));
        UtilHelper.addLog(logBuffer, "NAZIONE", (String) addressDetails.get("nazione"));
        UtilHelper.addLog(logBuffer, "CAPVALUE", (String) addressDetails.get("capValue"));
        return logBuffer.toString();
    }

    public static String getAddressLinkDetailsForLog(final Map addressLinkDetails) {
        final StringBuffer logBuffer = new StringBuffer();
        UtilHelper.addLog(logBuffer, "SOGGETTOID", (String) addressLinkDetails.get("soggettoId"));
        UtilHelper.addLog(logBuffer, "SUBSYSTEM", (String) addressLinkDetails.get("subSystem"));
        UtilHelper.addLog(logBuffer, "ADDRESSTYPE", (String) addressLinkDetails.get("addressType"));
        UtilHelper.addLog(logBuffer, "PRODUCTID", (String) addressLinkDetails.get("productId"));
        UtilHelper.addLog(logBuffer, "ADDRESSID", (String) addressLinkDetails.get("addressId"));
        
        return logBuffer.toString();
    }

    public static String getAddressAEDetailsForLog(final Map addressAEDetails) {
        final StringBuffer logBuffer = new StringBuffer();
        UtilHelper.addLog(logBuffer, "AELINKEDID", (String) addressAEDetails.get("aeLinkId"));
        UtilHelper.addLog(logBuffer, "AERESERVED", (String) addressAEDetails.get("aeReserved"));
        UtilHelper.addLog(logBuffer, "AEFREQUENCY", (String) addressAEDetails.get("aeFrequency"));
        UtilHelper.addLog(logBuffer, "AEINTERNAL", (String) addressAEDetails.get("aeInternal"));
        
        return logBuffer.toString();
    }

    public static void logMessage(final String operation, final String data, final String operationCode, final String operationResult) throws AddressException {
        try {
            final LoggerClient logggerClient = LoggerClient.getInstance();
            final StringBuffer variableTag = new StringBuffer();
            UtilHelper.getOpenTag(variableTag, "LOG_OPTIONAL_SECTION");
            variableTag.append(UtilHelper.getTag("OPERATION_CODE", operationCode));
            variableTag.append("<NUMERO_CONTO_PARTENZA/><DIVISA_PARTENZA/><IMPORTO_PARTENZA/><NUMERO_CONTO_ARRIVO/><VALUTA_OPERAZIONE/><ID_AUTORIZZANTE/>");
            variableTag.append(UtilHelper.getTag("OPERATION_RESULT", operationResult));
            UtilHelper.getCloseTag(variableTag, "LOG_OPTIONAL_SECTION");
            
            UtilHelper.getOpenTag(variableTag, "LOG_VARIABLE_SECTION");
            UtilHelper.getOpenTag(variableTag, "XML_DATA");
            UtilHelper.getOpenTag(variableTag, "ADDRESSADMINTOOL");
            variableTag.append(UtilHelper.getTag("OPERATION", operation));
            variableTag.append(UtilHelper.getTagWithValueCheck("DATA", data));
            UtilHelper.getCloseTag(variableTag, "ADDRESSADMINTOOL");
            UtilHelper.getCloseTag(variableTag, "XML_DATA");
            UtilHelper.getCloseTag(variableTag, "LOG_VARIABLE_SECTION");

            logggerClient.log(variableTag.toString());
        } catch(final LoggerException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        }
    }

}
