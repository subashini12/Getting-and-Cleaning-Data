package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressException;
import it.sella.address.HelperException;
import it.sella.address.sm.ExecuterHelper;
import it.sella.address.sm.addressmgt.AddressMgtConstants;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.Serializable;
import java.util.Map;

public class AddressAEAdminDeleteExecuter extends AddressAEAdminBaseExecuter {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAEAdminDeleteExecuter.class);
	private static final String IS_DELETE = "IS_DELETE";

    public ExecuteResult execute(final RequestEvent requestEvent) {
        ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrConferma");
        final StateMachineSession session = requestEvent.getStateMachineSession();
        String errorMessage = null;
        Map addressAEDetails = null;
        try {
	        	addressAEDetails = getAddressAEDetails(requestEvent);
	            executeResult.setAttribute(AddressMgtConstants.ADDRESSAEDETAILS, (Serializable)addressAEDetails);
	            executeResult.setAttribute(IS_DELETE, "TRUE");
	            session.put(AddressMgtConstants.ADDRESSAEDETAILS, (Serializable)addressAEDetails);
	            session.put(AddressMgtConstants.OPERATION,"DELETE");
	            if(addressAEDetails.get(AddressMgtConstants.AELINKID) != null) {
					session.put(AddressMgtConstants.ADRESSAELINKID, Long.valueOf((String)addressAEDetails.get(AddressMgtConstants.AELINKID)));
				}
            } catch (final AddressException e) {
                log4Debug.severeStackTrace(e);
                executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
                errorMessage = e.getMessage();
            } catch (final HelperException e) {
                log4Debug.severeStackTrace(e);
                executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
                errorMessage = e.getMessage();
			}
        if(errorMessage != null) {
            executeResult.setAttribute("errorMessage", errorMessage);
            if(addressAEDetails != null && addressAEDetails.get(AddressMgtConstants.AELINKID) != null) {
				executeResult.setAttribute(AddressMgtConstants.ADRESSAELINKID, (Serializable)addressAEDetails.get(AddressMgtConstants.AELINKID));
			}
            if(session.get(AddressMgtConstants.ADDRESSAEDETAILS) != null) {
				executeResult.setAttribute(AddressMgtConstants.ADDRESSAEDETAILS, session.get(AddressMgtConstants.ADDRESSAEDETAILS));
			}
        }
        return executeResult;
    }
}
