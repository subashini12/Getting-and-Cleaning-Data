package it.sella.address.sm.addressadmintool;

import it.sella.address.implementation.dbhelper.PostalFormatBypassHelper;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Hashtable;
import java.util.Map;

public class GestorePostalBypassConfermaIndietroExecuter extends AddressAdminBaseExecuter {
	
	private static final Log4Debug log4Debug  = Log4DebugFactory.getLog4Debug(
			GestorePostalBypassConfermaIndietroExecuter.class);

	public ExecuteResult execute( final RequestEvent requestEvent ) {
		ExecuteResult executeResult = null;
		final StateMachineSession session = requestEvent.getStateMachineSession();
		final Map postalByPassDetails = session.get("POSTALBYBASSDETAILS") != null ?
				(Map) session.get("POSTALBYBASSDETAILS") :  new Hashtable(1);
		final String byPassCode = (String) postalByPassDetails.get("BYBASSCODE");
		final String operation = (String) postalByPassDetails.get("OPERATION");
		log4Debug.debug("GestorePostalBypassConfermaIndietroExecuter: execute: byPassCode:===>>",byPassCode);
		log4Debug.debug("GestorePostalBypassConfermaIndietroExecuter: execute: operation:===>>",operation);
		if ("INSERT".equals(operation)) {
			executeResult = getExecuteResult("TrInsert");
		} else if ("DELETE".equals(operation)) {
			executeResult = getExecuteResult("TrElecno");
			try {
				isNotNullSetInExecuteResultSet(executeResult, "postalByPassList", 
						new PostalFormatBypassHelper().getPostalFormatBypass(byPassCode));
			} catch (final Exception e1) {
				log4Debug.severeStackTrace(e1);
			}
		}  else {
			executeResult = getExecuteResult("TrDetta");
		}
		log4Debug.debug("GestorePostalBypassConfermaIndietroExecuter: execute: executeResult:===>>",executeResult);
		return executeResult;
	}	
}
