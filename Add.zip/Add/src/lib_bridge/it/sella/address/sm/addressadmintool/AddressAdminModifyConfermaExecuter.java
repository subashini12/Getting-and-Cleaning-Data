package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.address.sm.ExecuterHelper;
import it.sella.address.sm.addressmgt.AddressMgtConstants;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;

public class AddressAdminModifyConfermaExecuter extends AddressAdminBaseExecuter {
    
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAdminModifyConfermaExecuter.class);

    public ExecuteResult execute(final RequestEvent requestEvent) {
        AddressView addressView = null;
        Map addressDetails = null;
        ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrConferma");
        final StateMachineSession session = requestEvent.getStateMachineSession();
        addressDetails = new Hashtable();
        setAddressDetails(requestEvent, addressDetails);
        try {
            session.put(AddressMgtConstants.ADDRESSDETAILS, addressDetails);
            addressView = ExecuterHelper.validateIndirizzo(addressDetails);
            session.put(AddressMgtConstants.ADDRESSVIEW, addressView);
            executeResult.setAttribute(AddressMgtConstants.ADDRESSDETAILS, (Serializable)addressDetails);
            executeResult.setAttribute(AddressMgtConstants.OLDADDRESSDETAILS, session.get(AddressMgtConstants.OLDADDRESSDETAILS));
            executeResult.setAttribute("IS_MODIFY","TRUE");
            session.put(AddressMgtConstants.OPERATION,"MODIFY");
        } catch (final AddressException e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
            executeResult.setAttribute("errorMessage", e.getMessage());
            setDatasOnError(session, executeResult);
        }
        return executeResult;
    }

    private void setDatasOnError(final StateMachineSession session, final ExecuteResult executeResult) {
        if(session.get(AddressMgtConstants.OLDADDRESSDETAILS) != null) {
			executeResult.setAttribute(AddressMgtConstants.OLDADDRESSDETAILS,session.get(AddressMgtConstants.OLDADDRESSDETAILS));
		}
        if(session.get(AddressMgtConstants.ADDRESSDETAILS) != null) {
			executeResult.setAttribute(AddressMgtConstants.ADDRESSDETAILS, session.get(AddressMgtConstants.ADDRESSDETAILS));
		}
    }
}
