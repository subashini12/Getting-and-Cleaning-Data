
package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressView;
import it.sella.address.implementation.dbhelper.AddressLogHelper;
import it.sella.address.sm.ExecuterHelper;
import it.sella.address.sm.addressmgt.AddressMgtConstants;
import it.sella.statemachine.EventExecuter;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Map;

public class AddressLinkAdminConfermaExecuter implements EventExecuter {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressLinkAdminConfermaExecuter.class);
	private static final String TXTSOGGETTOID = "txtSoggettoId";
	private static final String SOGGETTOID = "soggettoId";
	private static final String PRIMARY_KEY = "PRIMARY_KEY";
	private static final String ADLK_MOD = "ADLK-MOD";
	private static final String ADLK_DEL = "ADLK-DEL";
	private static final String ADLK_INST = "ADLK-INST";

    public ExecuteResult execute(final RequestEvent requestEvent) {
        String errorMessage = null;
        Long opId = null;
        final AddressLogHelper addressLogHelper = new AddressLogHelper();
        ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrConferma");
        final StateMachineSession session = requestEvent.getStateMachineSession();
        final String operation = (String) session.get(AddressMgtConstants.OPERATION);
        final AddressView addressView = new AddressView();
        try {
        	if("MODIFY".equals(operation)) {
    			addressView.setSoggettoId(Long.valueOf((String)session.get(TXTSOGGETTOID)));
        		opId = addressLogHelper.logAddressOperation(ADLK_MOD, addressView, null, false);
        		AddressAdminToolHelper.modifyAddressLink(opId, session);
            } else if("DELETE".equals(operation)) {
                addressView.setSoggettoId(Long.valueOf((String)session.get(TXTSOGGETTOID)));
            	opId = addressLogHelper.logAddressOperation(ADLK_DEL, addressView, null, false);
                AddressAdminToolHelper.deleteAddressLink(opId, session);
            } else if("ADD".equals(operation)){
            	addressView.setSoggettoId(Long.valueOf((String) ((Map) session.get(AddressMgtConstants.ADDRESSLINKDETAILS)).get(SOGGETTOID)));
            	opId = addressLogHelper.logAddressOperation(ADLK_INST, addressView, null, false);
                final Long primaryKey = AddressAdminToolHelper.createAddressLink(opId, session);
                if(primaryKey != null) {
					session.put(PRIMARY_KEY, primaryKey);
				}
            }
        } catch (final Exception e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
            errorMessage = e.getMessage();
            executeResult.setAttribute("errorMessage", errorMessage);
            if(session.get(AddressMgtConstants.ADDRESSLINKDETAILS) != null) {
				executeResult.setAttribute(AddressMgtConstants.ADDRESSLINKDETAILS, session.get(AddressMgtConstants.ADDRESSLINKDETAILS));
			}
        } finally {
       	 	try {
       	 		addressLogHelper.updateAddressLog(opId, null, errorMessage);
			} catch (final Exception e) {
				log4Debug.severe("This exception is just caught not to affect the parent transaction !!!!!");
				log4Debug.warnStackTrace(e);
			}
        }
        return executeResult;
    }
    
}
