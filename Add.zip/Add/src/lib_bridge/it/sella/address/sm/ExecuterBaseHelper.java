package it.sella.address.sm;

import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.util.AnagrafeHandler;
import it.sella.address.sm.addressmgt.AddressErrorConstants;
import it.sella.anagrafe.ICapView;
import it.sella.anagrafe.ICittaView;
import it.sella.anagrafe.INazioneView;
import it.sella.anagrafe.IProvinciaView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

public class ExecuterBaseHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(ExecuterBaseHelper.class);

    protected static AddressView getAddressView(final String indirizzo, final String cap, final String citta, String provincia, final String nazione) throws AddressException {
    	final AddressView addressView = new AddressView();
        try {
        	final AnagrafeHandler anagrafeHandler = new AnagrafeHandler();
            INazioneView nazioneView = null;
            ICittaView cittaView = null;
            ICapView capView = null;
            IProvinciaView provinciaView = null;
            final Map searchCriteria = new Hashtable();
            searchCriteria.put("NA_NOME", nazione);
            final Collection naziones = anagrafeHandler.getNazione(searchCriteria);
            nazioneView = getNazioneView(naziones);
            checkNazioneViewIsNull(nazioneView);
            if ("ITALIA".equalsIgnoreCase(nazione)) {
            	checkForDummyString(cap, AddressErrorConstants.ERR08);
            	checkForDummyString(provincia, AddressErrorConstants.ERR09);
                validateCitta(citta, anagrafeHandler);
                validateProvincia(provincia, anagrafeHandler);
                
                if (validCittaAndProvincia(anagrafeHandler, provincia, citta)) {
                    cittaView = anagrafeHandler.getCitta(citta, provincia);
                    provincia = cittaView.getProvincia();
                }                
                capView = validateCapAndGetView(cap, citta, anagrafeHandler, cittaView);
                provinciaView = anagrafeHandler.getProvinciaViewForSigla(provincia);
            }
            addressView.setCapView(capView);
            addressView.setCap(cap);
            addressView.setCittaView(cittaView);
            addressView.setCitta(citta);
            addressView.setIndirizzo(indirizzo);
            addressView.setNazioneView(nazioneView);
            addressView.setNazione(nazione);
            addressView.setProvinciaView(provinciaView);
            addressView.setProvincia(provincia);
        } catch (final RemoteException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        } catch(final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        }
        return addressView;
    }

	private static ICapView validateCapAndGetView(final String cap,	final String citta, final AnagrafeHandler anagrafeHandler, ICittaView cittaView) throws AddressException, RemoteException, SubSystemHandlerException {
		ICapView capView = null;
		if (!"".equals(cap)) {
		    try {
		        if (cap.length() == 5) {
		        	Long.valueOf(cap);
				} else {
					throw new AddressException(AddressErrorConstants.ERR12);
				}
		    } catch (final NumberFormatException nx) {
		        log4Debug.severeStackTrace(nx);
		        throw new AddressException(AddressErrorConstants.ERR12);
		    }
		    if (anagrafeHandler.isValidCapForProvincia(cap, cittaView.getProvincia())) {
		        capView = anagrafeHandler.getCapviewForCapcodeAndCittacommune(cap, citta);
		    } else {
				throw new AddressException(AddressErrorConstants.ERR12);
			}
		}
		return capView;
	}

	private static void validateProvincia(String provincia, final AnagrafeHandler anagrafeHandler) throws SubSystemHandlerException, RemoteException, AddressException {
		if (!anagrafeHandler.isValidProvinciaSigla(provincia)) {
			throw new AddressException(AddressErrorConstants.ERR11);
		}
	}

	private static void validateCitta(final String citta, final AnagrafeHandler anagrafeHandler) throws RemoteException, SubSystemHandlerException, AddressException {
		if (!anagrafeHandler.isValidCittaCommune(citta)) {
			throw new AddressException(AddressErrorConstants.ERR10);
		}
	}
	
	private static boolean validCittaAndProvincia(final AnagrafeHandler anagrafeHandler, String provincia, String citta) throws RemoteException, SubSystemHandlerException, AddressException{
		boolean result = false;
		if (anagrafeHandler.isValidProvinciaForSiglaAndCittaCommune(provincia, citta)) {
            if (anagrafeHandler.isValidCittaForProvincia(citta, provincia)) {
            	result = true;
            } else {
				throw new AddressException(AddressErrorConstants.ERR11);
			}
        } else {
			throw new AddressException(AddressErrorConstants.ERR11);
		}
		return result;
	}

	private static INazioneView getNazioneView(final Collection naziones) {
		INazioneView nazioneView = null;
		if (naziones != null && !naziones.isEmpty()) {
			nazioneView = (INazioneView) new Vector(naziones).get(0);
		}
		return nazioneView;
	}

	private static void checkNazioneViewIsNull(INazioneView nazioneView)
			throws AddressException {
		if (nazioneView == null) {
			throw new AddressException(AddressErrorConstants.ERR07);
		}
	}
    
    protected static void checkForDummyString(final String value, final String errorMessage) throws AddressException {
    	if("".equals(value)) {
			throw new AddressException(errorMessage);
		}
    }
}
