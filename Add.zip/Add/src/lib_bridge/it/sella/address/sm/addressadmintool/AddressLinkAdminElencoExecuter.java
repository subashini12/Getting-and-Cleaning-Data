package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressConstants;
import it.sella.address.AddressException;
import it.sella.address.HelperException;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.addresslink.AddressLink;
import it.sella.address.implementation.addresslink.IAddressLinkBeanManager;
import it.sella.address.implementation.factory.ReflectionUtil;
import it.sella.address.implementation.util.ClassificazioneHandler;
import it.sella.address.sm.ExecuterHelper;
import it.sella.address.sm.addressmgt.AddressMgtConstants;
import it.sella.statemachine.EventExecuter;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;

import javax.ejb.FinderException;

public class AddressLinkAdminElencoExecuter implements EventExecuter {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressLinkAdminElencoExecuter.class);
    private static final String TR_NONCONFERMA = "TrNonConferma";
    private static final String SOGGETTOID = "soggettoId";
    private static final String ERRORMESSAGE = "errorMessage";
    private static final String SUBSYSTEM = "subSystem";
    private static final String ADDRESSTYPE = "addressType";
    private static final String PRODUCTID = "productId";
    private static final String ADDRESSID = "addressId";
    private static final String EVENTNAME = "eventName";

    public ExecuteResult execute(final RequestEvent requestEvent) {
        ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrConferma");
        final StateMachineSession session = requestEvent.getStateMachineSession();
        String errorMessage = null;
        Map addressLinkDetail = null;
        final ArrayList addressLinkDetails = new ArrayList();
        final String soggettoId = (String) requestEvent.getAttribute("txtSoggettoId");
        try {
            validateSoggettoId(soggettoId);
            final IAddressLinkBeanManager addressLinkBeanManager  = (IAddressLinkBeanManager) ReflectionUtil.createServiceImplInstance(AddressConstants.BUNDLE_KEY, AddressConstants.DAOIMPL_KEY_FOR_ADDRESSLINK);
            final Collection addressDetailsCollection = addressLinkBeanManager.findBySoggettoId(Long.valueOf(soggettoId));
            if(addressDetailsCollection != null) {
                final int size = addressDetailsCollection.size();
                final Iterator addressIterator = addressDetailsCollection.iterator();
                for(int i=0;i<size;i++) {
                    final AddressLink addressLink = (AddressLink) addressIterator.next();
                    addressLinkDetail = new Hashtable();
                    addressLinkDetail.put(SOGGETTOID, addressLink.getSoggettoId().toString());
                    addressLinkDetail.put(AddressMgtConstants.ADRESSLINKID, addressLink.getAddressLinkId().toString());
                    setSubSystem(addressLinkDetail, addressLink.getSubSystem());
                    setAddressType(addressLinkDetail, addressLink.getAddressType());
                    setDataInAddressLinkDetailMap(addressLinkDetail, PRODUCTID, addressLink.getLinkedId());
                    setDataInAddressLinkDetailMap(addressLinkDetail, ADDRESSID, addressLink.getAddressId());
                    addressLinkDetails.add(addressLinkDetail);
                }
            }
            session.put(AddressMgtConstants.ADDRESSLINKDETAILS, addressLinkDetails);
            session.put(EVENTNAME, requestEvent.getEventName());
            executeResult.setAttribute(AddressMgtConstants.ADDRESSLINKDETAILS, addressLinkDetails);
        } catch (final HelperException e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult(TR_NONCONFERMA);
            errorMessage = e.getMessage();
        } catch(final NumberFormatException e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult(TR_NONCONFERMA);
            errorMessage = "Enter a valid Soggetto Id !!!";
        } catch (final RemoteException e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult(TR_NONCONFERMA);
            errorMessage = "Enter a valid causale for Sub System / Address Type !!!";
        } catch (final FinderException e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult(TR_NONCONFERMA);
            errorMessage = "Record does not exists !!!";
        } catch (final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult(TR_NONCONFERMA);
            errorMessage = "Enter a valid causale for Sub System / Address Type !!!";
		}catch (final AddressException e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult(TR_NONCONFERMA);
            errorMessage = e.getMessage();
		}
        if(errorMessage != null) {
            executeResult.setAttribute(ERRORMESSAGE, errorMessage);
            executeResult.setAttribute(SOGGETTOID, soggettoId != null ? soggettoId : "");
            setDataInExecuteResult(executeResult, AddressMgtConstants.OLDADDRESSLINKDETAILS, session.get(AddressMgtConstants.OLDADDRESSLINKDETAILS));
            setDataInExecuteResult(executeResult, AddressMgtConstants.ADDRESSLINKDETAILS, session.get(AddressMgtConstants.ADDRESSLINKDETAILS));
        }
        return executeResult;
    }

	private void setAddressType(Map addressLinkDetail,final Long addressTypeValue) throws SubSystemHandlerException,RemoteException {
		if(addressTypeValue != null) {
		    addressLinkDetail.put(ADDRESSTYPE, ClassificazioneHandler.getClassificazioneView(addressTypeValue).getCausale());
		}
	}

	private void setSubSystem(Map addressLinkDetail, final Long subSystemValue) throws SubSystemHandlerException, RemoteException {
		if(subSystemValue != null) {
		    addressLinkDetail.put(SUBSYSTEM, ClassificazioneHandler.getClassificazioneView(subSystemValue).getCausale());
		}
	}

	private void validateSoggettoId(final String soggettoId)
			throws HelperException {
		if(soggettoId == null || soggettoId.length() == 0) {
			final String errorMsg = "Enter the Soggetto Id";
			throw new HelperException(errorMsg);
		}
	}
	
	private void setDataInExecuteResult(final ExecuteResult executeResult, final String key, final Object value){
		if(value != null){
			executeResult.setAttribute(key,(Serializable)value);
		}
	}
	
	private void setDataInAddressLinkDetailMap(final Map addressLinkDetail, final String key, final Object value){
		if(value != null){
			addressLinkDetail.put(key, value.toString());
		}
	}
}
