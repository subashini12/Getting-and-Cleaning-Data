package it.sella.address.sm.addressadmintool;

import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.util.ClassificazioneHandler;
import it.sella.address.sm.ExecuterHelper;
import it.sella.address.sm.addressmgt.AddressMgtConstants;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.statemachine.EventExecuter;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Map;

public class AddressAEAdminModifyConfermaExecuter implements EventExecuter {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAEAdminModifyConfermaExecuter.class);
	private static final String AEFREQUENCYID = "aeFrequencyId";
	private static final String AEINTERNALID = "aeInternalId";
	private static final String HIDAELINKID = "hidAELinkId";
	private static final String TXTAERESERVED = "txtAEReserved";
	private static final String TXTAEFREQUENCY = "txtAEFrequency";
	private static final String TXTAEINTERNAL = "txtAEInternal";
	private static final String IS_MODIFY = "IS_MODIFY";

    public ExecuteResult execute(final RequestEvent requestEvent) {
        ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrConferma");
        final StateMachineSession session = requestEvent.getStateMachineSession();
        final Map addressAEDetails = new Hashtable();
            
        final String aeLinkId = (String) requestEvent.getAttribute(HIDAELINKID);
        setValueInAddAEDetailsIfNotNull(addressAEDetails, AddressMgtConstants.AELINKID, aeLinkId);
            
        final String aeReserved = (String) requestEvent.getAttribute(TXTAERESERVED);
        setValueInAddAEDetailsIfNotNull(addressAEDetails, AddressMgtConstants.AERESERVED, aeReserved);
            
        final  String aeFrequency = (String) requestEvent.getAttribute(TXTAEFREQUENCY);
        setValueInAddAEDetailsIfNotNull(addressAEDetails, AddressMgtConstants.AEFREQUENCY, aeFrequency);
        
        final String aeInternal = (String) requestEvent.getAttribute(TXTAEINTERNAL);
        setValueInAddAEDetailsIfNotNull(addressAEDetails, AddressMgtConstants.AEINTERNAL, aeInternal);
        
        session.put(AddressMgtConstants.ADDRESSAEDETAILS, (Serializable)addressAEDetails);
        try {
            if(aeReserved != null && !"0".equals(aeReserved)) {
				final String errorMsg = "AE reserved should be 0";
				throw new ControlloDatiException(errorMsg);
			}
            final Long aeFrequencyId = (ClassificazioneHandler.getClassificazioneView(aeFrequency, "AN_FREQ")).getId();
            setValueInAddAEDetailsIfNotNull(addressAEDetails, AEFREQUENCYID, aeFrequencyId);
            final Long aeInternalId = (ClassificazioneHandler.getClassificazioneView(aeInternal, "AEADD")).getId();
            setValueInAddAEDetailsIfNotNull(addressAEDetails, AEINTERNALID, aeInternalId);
            executeResult.setAttribute(AddressMgtConstants.ADDRESSAEDETAILS, (Serializable)addressAEDetails);
            session.put(AddressMgtConstants.ADDRESSAEDETAILS, (Serializable)addressAEDetails);
            session.put(AddressMgtConstants.OPERATION, "MODIFY");
        } catch (final RemoteException e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
            setDatasOnError(aeLinkId, aeReserved, aeFrequency, aeInternal, executeResult,"Enter a valid causale for Frequency / Internal !!!");
        } catch (final ControlloDatiException e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
            setDatasOnError(aeLinkId, aeReserved, aeFrequency, aeInternal, executeResult,e.getMessage());
        } catch (final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
            setDatasOnError(aeLinkId, aeReserved, aeFrequency, aeInternal, executeResult,"Enter a valid causale for Frequency / Internal !!!");
		}
        executeResult.setAttribute(AddressMgtConstants.ADDRESSAEDETAILS, (Serializable)addressAEDetails);
        executeResult.setAttribute(AddressMgtConstants.OLDADDRESSAEDETAILS, session.get(AddressMgtConstants.OLDADDRESSAEDETAILS));
        executeResult.setAttribute(IS_MODIFY,"TRUE");
        return executeResult;
    }

    private void setDatasOnError(final String aeLinkId, final String aeReserved, final String aeFrequency, final String aeInternal, final ExecuteResult executeResult,final String errorMessage) {
    	setDataInExecuteResult(executeResult, "errorMessage", errorMessage);
    	setDataInExecuteResult(executeResult, AddressMgtConstants.AELINKID, aeLinkId);
    	setDataInExecuteResult(executeResult, AddressMgtConstants.AERESERVED, aeReserved);
    	setDataInExecuteResult(executeResult, AddressMgtConstants.AEFREQUENCY, aeFrequency);
    	setDataInExecuteResult(executeResult, AddressMgtConstants.AEINTERNAL, aeInternal);
    }
    
    private void setDataInExecuteResult(final ExecuteResult executeResult, final String key, final String value){
    	executeResult.setAttribute(key, value != null ? value : "");
    }
    
    private void setValueInAddAEDetailsIfNotNull(final Map addressAEDetails, final String key,final Object value){
		if(addressAEDetails != null && key != null  && value != null){
			addressAEDetails.put(key, value);
		}
	}
}
