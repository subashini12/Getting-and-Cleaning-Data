package it.sella.address.sm.addressadmintool;


import it.sella.address.AddressException;
import it.sella.address.implementation.AddressAdminFactory;
import it.sella.address.implementation.dbhelper.AddressLogHelper;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Map;

public class AddressAdminToolDeleteHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAdminToolDeleteHelper.class);

    public static void deleteAddress(final Long opId, final StateMachineSession session) throws AddressException {
        String loggerOperation = "FAILURE";
        String logData = null;
        try {
        	final Map addressDetails = (Map) session.get("addressDetails");
        	AddressAdminFactory.getInstance().getAddressAdmin().deleteAddress(opId, (Long) addressDetails.get("addressPrimaryKey"));
            loggerOperation = "SUCCESS";
            logData = AddressAdminToolLogger.getAddressDetailsForLog(addressDetails);
            logAddressOperationDetails(opId,"","");
        } catch (final Exception e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        } finally {
            AddressAdminToolLogger.logMessage("ADDRESS ADMIN DELETE", logData, "ADDR-DEL", loggerOperation);
        }
    }

    public static void deleteAddressLink(final Long opId, final StateMachineSession session) throws AddressException {
        String loggerOperation = "FAILURE";
        String logData = null;
        try {
        	AddressAdminFactory.getInstance().getAddressAdmin().deleteAddressLink(opId, Long.valueOf((String) session.get("addressLinkId")));
            loggerOperation = "SUCCESS";
            final Map addressLinkDetails = (Map) session.get("oldAddressLinkDetails");
            logData = AddressAdminToolLogger.getAddressLinkDetailsForLog(addressLinkDetails);
            logAddressOperationDetails(opId,"","");
        } catch (final NumberFormatException e) {
            log4Debug.severeStackTrace(e);
            final String errorMsg = "Enter a valid Address AE Link Id !!!";
			throw new AddressException(errorMsg);
        } catch (final Exception e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        } finally {
            AddressAdminToolLogger.logMessage("ADDRESS ADMIN DELETE", logData, "ADLK-DEL", loggerOperation);
        }
    }

    public static void deleteAddressAE(final Long opId, final StateMachineSession session) throws AddressException {
        String loggerOperation = "FAILURE";
        String logData = null;
        try {
        	final Map addressAEDetails = (Map) session.get("addressAEDetails");
        	AddressAdminFactory.getInstance().getAddressAdmin().deleteAddressAE(opId,(Long)session.get("addressAELinkId"));
        	loggerOperation = "SUCCESS";
            logData = AddressAdminToolLogger.getAddressAEDetailsForLog(addressAEDetails);
            logAddressOperationDetails(opId,"","");
        } catch (final Exception e) {
            log4Debug.warnStackTrace(e);
            throw new AddressException(e.getMessage());
        } finally {
            AddressAdminToolLogger.logMessage("ADDRESS ADMIN DELETE", logData, "ADAE-DEL", loggerOperation);
        }
    }
    
    private static void logAddressOperationDetails(final Long opId, final String mapperMessage, final String addressData) {
    	try {
        	new AddressLogHelper().logAddressOpDetails(opId, mapperMessage, addressData);
		} catch (final Exception e) {
			log4Debug.severe("This exception is just caught not to affect the parent transaction !!!!!");
			log4Debug.warnStackTrace(e);
		}
    }
}
