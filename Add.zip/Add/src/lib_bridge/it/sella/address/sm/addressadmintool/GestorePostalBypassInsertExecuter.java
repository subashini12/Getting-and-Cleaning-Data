package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressException;
import it.sella.address.HelperException;
import it.sella.address.PostalByPassView;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineException;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Hashtable;
import java.util.Map;

public class GestorePostalBypassInsertExecuter  extends AddressAdminBaseExecuter {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(
			GestorePostalBypassRicercaExecuter.class);

	public ExecuteResult execute(final RequestEvent requestEvent)	throws StateMachineException {
		ExecuteResult executeResult = null;
		final PostalByPassAdminHelper postalByPassAdminHelper = new PostalByPassAdminHelper();
		final String byPassCode = ((String) requestEvent.getAttribute("byPassCode")).trim();
		final StateMachineSession session = requestEvent.getStateMachineSession();
		PostalByPassView postalByPassView = null;
		final Map postalByPassDetails = session.get("POSTALBYBASSDETAILS") != null ?
				(Map) session.get("POSTALBYBASSDETAILS") :  new Hashtable(1);
		try {
			log4Debug.debug("GestorePostalBypassInsertExecuter : execute : byPassCode :===>>",byPassCode);
			postalByPassAdminHelper.validateAllFields(requestEvent, true);
			postalByPassView = postalByPassAdminHelper.getPostalByPassView(requestEvent, byPassCode);
			executeResult = getExecuteResult("TrConferma");
		} catch (final AddressException e) {
			log4Debug.severeStackTrace(e);
			executeResult = getNonConfermaExecuteResult("ErrorMessage", e.getMessage());
		} catch (final HelperException e) {
			log4Debug.severeStackTrace(e);
			executeResult = getNonConfermaExecuteResult("ErrorMessage", e.getMessage());
		}
		isNotNullSetInMap(postalByPassDetails, "BYBASSCODE", byPassCode);
		isNotNullSetInMap(postalByPassDetails, "OPERATION", "INSERT");
		isNotNullSetInMap(postalByPassDetails, "PostalBypassViewNew", postalByPassView);
		isNotNullSetInSession(session, "POSTALBYBASSDETAILS", postalByPassDetails);
		return executeResult;
	}
}

