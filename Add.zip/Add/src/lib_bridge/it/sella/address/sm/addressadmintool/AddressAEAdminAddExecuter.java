package it.sella.address.sm.addressadmintool;

import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.util.ClassificazioneHandler;
import it.sella.address.sm.ExecuterHelper;
import it.sella.address.sm.addressmgt.AddressMgtConstants;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.statemachine.EventExecuter;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Map;

public class AddressAEAdminAddExecuter implements EventExecuter {
    
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAEAdminAddExecuter.class);
    private static final String AEFREQUENCYID = "aeFrequencyId";
    private static final String AEINTERNALID = "aeInternalId";

    public ExecuteResult execute(final RequestEvent requestEvent) {
    	ExecuteResult executeResult = null;
        final StateMachineSession session = requestEvent.getStateMachineSession();
        final Map aeAddressDetails = new Hashtable();
        aeAddressDetails.put(AddressMgtConstants.AELINKID, requestEvent.getAttribute("txtAELinkId"));
        aeAddressDetails.put(AddressMgtConstants.AERESERVED, requestEvent.getAttribute("txtAEReserved"));
        aeAddressDetails.put(AddressMgtConstants.AEFREQUENCY, requestEvent.getAttribute("txtAEFrequency"));
        aeAddressDetails.put(AddressMgtConstants.AEINTERNAL, requestEvent.getAttribute("txtAEInternal"));
        try {
        	Long.valueOf((String)aeAddressDetails.get(AddressMgtConstants.AELINKID));
        	if(((String)aeAddressDetails.get(AddressMgtConstants.AERESERVED)).length() == 0) {
				final String errorMsg = "Enter value for AE reserved";
				throw new ControlloDatiException(errorMsg);
			}
            if(!"0".equals(aeAddressDetails.get(AddressMgtConstants.AERESERVED))) {
				final String errorMsg = "AE reserved should be 0";
				throw new ControlloDatiException(errorMsg);
			}
            final Long aeFrequencyId = (ClassificazioneHandler.getClassificazioneView((String)aeAddressDetails.get(AddressMgtConstants.AEFREQUENCY), "AN_FREQ")).getId();
            final Long aeInternalId = (ClassificazioneHandler.getClassificazioneView((String)aeAddressDetails.get(AddressMgtConstants.AEINTERNAL), "AEADD")).getId();
            aeAddressDetails.put(AEFREQUENCYID, aeFrequencyId);
            aeAddressDetails.put(AEINTERNALID, aeInternalId);
            executeResult = ExecuterHelper.getExecuteResult("TrConferma");
            executeResult.setAttribute(AddressMgtConstants.ADDRESSAEDETAILS, aeAddressDetails);
            session.put(AddressMgtConstants.ADDRESSAEDETAILS, aeAddressDetails);
            session.put(AddressMgtConstants.OPERATION, "ADD");
        } catch(final ControlloDatiException e) {
            log4Debug.warnStackTrace(e);
            executeResult = getNonConfermaTransition(aeAddressDetails,e.getMessage());
        } catch(final NumberFormatException e) {
            log4Debug.warnStackTrace(e);
            executeResult = getNonConfermaTransition(aeAddressDetails,"Enter a valid Address AE Link Id !!!");
        } catch (final RemoteException e) {
            log4Debug.warnStackTrace(e);
            executeResult = getNonConfermaTransition(aeAddressDetails,"Enter valid causale for Frequency / Internal");
		} catch (final SubSystemHandlerException e) {
            log4Debug.warnStackTrace(e);
            executeResult = getNonConfermaTransition(aeAddressDetails,"Enter valid causale for Frequency / Internal");
		}
        return executeResult;
    }

    private ExecuteResult getNonConfermaTransition(final Map aeAddressDetails,final String errorMessage) {
    	final ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
        executeResult.setAttribute("errorMessage", errorMessage);
        setDatasOnError(aeAddressDetails, executeResult);
        return executeResult;
    }
    
    private void setDatasOnError(final Map aeAddressDetails, final ExecuteResult executeResult) {
    	executeResult.setAttribute(AddressMgtConstants.AELINKID, (Serializable)aeAddressDetails.get(AddressMgtConstants.AELINKID));
        executeResult.setAttribute(AddressMgtConstants.AERESERVED, (Serializable)aeAddressDetails.get(AddressMgtConstants.AERESERVED));
        executeResult.setAttribute(AddressMgtConstants.AEFREQUENCY, (Serializable)aeAddressDetails.get(AddressMgtConstants.AEFREQUENCY));
        executeResult.setAttribute(AddressMgtConstants.AEINTERNAL, (Serializable)aeAddressDetails.get(AddressMgtConstants.AEINTERNAL));
    }
}
