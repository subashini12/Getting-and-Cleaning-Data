package it.sella.address.sm.addressmgt;

import it.sella.address.sm.ExecuterHelper;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;

import java.io.Serializable;
import java.util.Map;

public class GeograficaRicercaExecuter extends InputDetailsHandlerExecuter {

	public ExecuteResult execute( final RequestEvent requestEvent ) {
        final ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrRicerca");
        final StateMachineSession session = requestEvent.getStateMachineSession();
		final Map inputDetails = getInputDetails(requestEvent);
        session.put("PREV_VALUES", (Serializable)inputDetails); // to redisplay the values after pop back
        session.put("OPERATION", "ACTUAL_VIEW");
        if ( requestEvent.getAttribute("GEOGRAFICA_RICERCA_FOR") != null ) {
        	session.put("OPERATION_NAME", (Serializable) requestEvent.getAttribute("GEOGRAFICA_RICERCA_FOR"));	
        }
        return executeResult;
    }
}
