package it.sella.address.sm.addressadmintool;

import it.sella.address.sm.ExecuterHelper;
import it.sella.address.sm.addressmgt.AddressMgtConstants;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.Serializable;
import java.util.Map;

public class AddressAdminModifyExecuter extends AddressAdminBaseExecuter {
    
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAdminModifyExecuter.class);

    public ExecuteResult execute(final RequestEvent requestEvent) {
        final StateMachineSession session = requestEvent.getStateMachineSession();
        Map addressDetails = null;
        ExecuteResult executeResult = null;
        try {
        	addressDetails = getAddressDetails(requestEvent);
            session.put(AddressMgtConstants.ADDRESSPRIMARYKEY, (Serializable) addressDetails.get(AddressMgtConstants.ADDRESSPRIMARYKEY));
            session.put(AddressMgtConstants.OLDADDRESSDETAILS, (Serializable)addressDetails);
            executeResult = ExecuterHelper.getExecuteResult("TrConferma");
            executeResult.setAttribute(AddressMgtConstants.OLDADDRESSDETAILS, (Serializable)addressDetails);
            session.put(AddressMgtConstants.OPERATION,"MODIFY");
        } catch (final Exception e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
            executeResult.setAttribute("errorMessage", e.getMessage());
            executeResult.setAttribute(AddressMgtConstants.ADDRESSPKID, addressDetails != null && addressDetails.get(AddressMgtConstants.ADDRESSPRIMARYKEY) != null ?
            		(Serializable)addressDetails.get(AddressMgtConstants.ADDRESSPRIMARYKEY) : "");
            if(session.get(AddressMgtConstants.OLDADDRESSDETAILS) != null) {
				executeResult.setAttribute(AddressMgtConstants.OLDADDRESSDETAILS,session.get(AddressMgtConstants.OLDADDRESSDETAILS));
			}
            if(session.get(AddressMgtConstants.ADDRESSDETAILS) != null) {
				executeResult.setAttribute(AddressMgtConstants.ADDRESSDETAILS, session.get(AddressMgtConstants.ADDRESSDETAILS));
			}
        } 
        return executeResult;
    }
}
