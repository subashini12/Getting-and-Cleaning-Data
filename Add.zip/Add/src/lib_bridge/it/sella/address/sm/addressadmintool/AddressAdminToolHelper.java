/**
 * Created by IntelliJ IDEA.
 * User: ssile6
 * Date: Feb 1, 2005
 * Time: 1:12:48 PM
 * To change this template use Options | File Templates.
 */
package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.statemachine.StateMachineSession;

public class AddressAdminToolHelper {

	public static Long createAddress(final Long opId, final AddressView addressView, final StateMachineSession session) throws AddressException {
    	return AddressAdminToolCreateHelper.createAddress(opId, addressView, session);
    }

    public static void modifyAddress(final Long opId, final AddressView addressView, final Long addressPrimaryKey, final StateMachineSession session) throws AddressException {
    	AddressAdminToolModificaHelper.modifyAddress(opId, addressView, addressPrimaryKey, session);
    }

    public static void deleteAddress(final Long opId, final StateMachineSession session) throws AddressException {
    	AddressAdminToolDeleteHelper.deleteAddress(opId, session);
    }

    public static Long createAddressLink(final Long opId, final StateMachineSession session) throws AddressException {
    	return AddressAdminToolCreateHelper.createAddressLink(opId, session);
    }

    public static void modifyAddressLink(final Long opId, final StateMachineSession session) throws AddressException {
    	AddressAdminToolModificaHelper.modifyAddressLink(opId, session);
    }

    public static void deleteAddressLink(final Long opId, final StateMachineSession session) throws AddressException {
    	AddressAdminToolDeleteHelper.deleteAddressLink(opId, session);
    }

    public static Long createAddressAE(final Long opId, final StateMachineSession session) throws AddressException {
    	return AddressAdminToolCreateHelper.createAddressAE(opId, session);
    }

    public static void modifyAddressAE(final Long opId, final StateMachineSession session) throws AddressException {
    	AddressAdminToolModificaHelper.modifyAddressAE(opId, session);
    }

    public static void deleteAddressAE(final Long opId, final StateMachineSession session) throws AddressException {
    	AddressAdminToolDeleteHelper.deleteAddressAE(opId, session);
    }
}
