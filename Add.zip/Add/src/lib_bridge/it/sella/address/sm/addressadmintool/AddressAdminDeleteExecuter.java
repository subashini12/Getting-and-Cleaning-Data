package it.sella.address.sm.addressadmintool;

import it.sella.address.sm.ExecuterHelper;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.Serializable;
import java.util.Map;

public class AddressAdminDeleteExecuter extends AddressAdminBaseExecuter {
    
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAdminDeleteExecuter.class);

    public ExecuteResult execute(final RequestEvent requestEvent) {
        final StateMachineSession session = requestEvent.getStateMachineSession();
        Map addressDetails = null;
        ExecuteResult executeResult = null;
        try {
        	addressDetails = getAddressDetails(requestEvent); 
            executeResult = ExecuterHelper.getExecuteResult("TrConferma");
            executeResult.setAttribute("addressDetails", (Serializable)addressDetails);
            executeResult.setAttribute("IS_DELETE", "TRUE");
            session.put("addressDetails", (Serializable)addressDetails);
            session.put("OPERATION","DELETE");
            session.put("addressPkId", (Serializable)addressDetails.get("addressPrimaryKey"));
            executeResult.setAttribute("addressDetails", (Serializable)addressDetails);
        } catch (final Exception e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
            executeResult.setAttribute("errorMessage", e.getMessage());
            executeResult.setAttribute("addressPkId", addressDetails != null && addressDetails.get("addressPrimaryKey") != null ?
            		addressDetails.get("addressPrimaryKey") : "");
        } 
        return executeResult;
    }
}
