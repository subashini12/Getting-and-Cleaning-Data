package it.sella.address.sm.addressadmintool;


import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.address.implementation.AddressAdminFactory;
import it.sella.address.implementation.addr.Address;
import it.sella.address.implementation.addresslink.AddressLink;
import it.sella.address.implementation.addresslink.AddressLinkView;
import it.sella.address.implementation.ae.AEAddress;
import it.sella.address.implementation.ae.AEAddressView;
import it.sella.address.implementation.dbhelper.AddressLogHelper;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Map;

public class AddressAdminToolCreateHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAdminToolCreateHelper.class);

    public static Long createAddress(final Long opId, final AddressView addressView, final StateMachineSession session) throws AddressException {
        String loggerOperation = "FAILURE";
        String logData = null;
        Address address = null;
        try {
            //AddressHome addressHome = (AddressHome) Helper.getHomeObject("ADDRESSHOMENAME", "it.sella.address.implementation.addr.AddressHome");
            final it.sella.address.implementation.addr.AddressView addrView = new it.sella.address.implementation.addr.AddressView();
            addrView.setIndirizzo(addressView.getIndirizzo().replace(',',' '));
            if(addressView.getCapView() != null) {
				addrView.setCapId(addressView.getCapView().getCapId());
			} else {
				addrView.setCapValue(addressView.getCap());
			}
            if(addressView.getCittaView() != null) {
				addrView.setCitta(addressView.getCittaView().getCittaId().toString());
			} else {
				addrView.setCitta(addressView.getCitta());
			}
            if(addressView.getProvinciaView() != null) {
				addrView.setProvincia(addressView.getProvinciaView().getProvinciaId().toString());
			} else {
				addrView.setProvincia(addressView.getProvincia());
			}
            addrView.setNazione(addressView.getNazioneView().getNazioneId());
            addrView.setOpId(opId);
            addrView.setNormStatus(addressView.getNormStatus());
            //addrView.setNormStatus("Dummy");
            address = AddressAdminFactory.getInstance().getAddressAdmin().createEntityAddress(addrView);
            //address = ((IAddressBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL","Manager.Address")).create(addrView);
            loggerOperation = "SUCCESS";
            final Map addressDetails = (Map) session.get("addressDetails");
            logData = AddressAdminToolLogger.getAddressDetailsForLog(addressDetails);
            AddressAdminToolLogger.logMessage("ADDRESS ADMIN INSERT", logData, "ADDR-INST", loggerOperation);
            logAddressOperationDetails(opId,"","");
            return address.getId();
        } catch (final Exception e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        }
    }

    public static Long createAddressLink(final Long opId, final StateMachineSession session) throws AddressException {
        String loggerOperation = "FAILURE";
        String logData = null;
        AddressLink addressLink = null;
        try {
            final Map addressLinkDetails = (Map) session.get("addressLinkDetails");
            final AddressLinkView addressLinkView = new AddressLinkView();
            if(addressLinkDetails.get("soggettoId") != null) {
				addressLinkView.setSoggettoId(Long.valueOf((String) addressLinkDetails.get("soggettoId")));
			}
            if(addressLinkDetails.get("longSubsystem") != null) {
				addressLinkView.setSubSystem((Long) addressLinkDetails.get("longSubsystem"));
			}
            if(addressLinkDetails.get("longAddressType") != null) {
				addressLinkView.setAddressType((Long) addressLinkDetails.get("longAddressType"));
			}
            if(addressLinkDetails.get("longProductId") != null) {
				addressLinkView.setLinkedId((Long) addressLinkDetails.get("longProductId"));
			}
            if(addressLinkDetails.get("longAddressId") != null) {
				addressLinkView.setAddressId((Long) addressLinkDetails.get("longAddressId"));
			}
            addressLinkView.setOpId(opId);
            addressLink = AddressAdminFactory.getInstance().getAddressAdmin().createAddressLink(addressLinkView);
            loggerOperation = "SUCCESS";
            logData = AddressAdminToolLogger.getAddressLinkDetailsForLog(addressLinkDetails);
            AddressAdminToolLogger.logMessage("ADDRESS ADMIN INSERT", logData, "ADLK-INST", loggerOperation);
            logAddressOperationDetails(opId,"","");
            return addressLink.getAddressLinkId();
        } catch (final NumberFormatException e) {
            log4Debug.severeStackTrace(e);
            final String errorMsg = "Enter a valid Soggetto Id !!!";
			throw new AddressException(errorMsg);
        } catch (final Exception e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        }
    }

    public static Long createAddressAE(final Long opId, final StateMachineSession session) throws AddressException {
        String loggerOperation = "FAILURE";
        String logData = null;
        AEAddress aeAddress = null;
        try {
            final Map addressAEDetails = (Map) session.get("addressAEDetails");
            final AEAddressView aeView = new AEAddressView();
            aeView.setAddressLinkId(Long.valueOf((String) addressAEDetails.get("aeLinkId")));
            aeView.setFrequency((Long) addressAEDetails.get("aeFrequencyId"));
            aeView.setInternal((Long) addressAEDetails.get("aeInternalId"));
            aeView.setReserved(Long.valueOf((String) addressAEDetails.get("aeReserved")));
            aeView.setOpId(opId);
            aeAddress = AddressAdminFactory.getInstance().getAddressAdmin().createAEAddress(aeView);
            loggerOperation = "SUCCESS";
            logData = AddressAdminToolLogger.getAddressAEDetailsForLog(addressAEDetails);
            AddressAdminToolLogger.logMessage("ADDRESS ADMIN INSERT", logData, "ADAE-INST", loggerOperation);
            logAddressOperationDetails(opId,"","");
            return aeAddress.getAeAddressId();
        } catch (final NumberFormatException e) {
            log4Debug.severeStackTrace(e);
            final String errorMsg = "Enter a valid Address AE Link Id / AE Reserved !!!";
			throw new AddressException(errorMsg);
        } catch (final Exception e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        }
    }

    private static void logAddressOperationDetails(final Long opId, final String mapperMessage, final String addressData) {
    	try {
        	new AddressLogHelper().logAddressOpDetails(opId, mapperMessage, addressData);
		} catch (final Exception e) {
			log4Debug.severe("This exception is just caught not to affect the parent transaction !!!!!");
			log4Debug.warnStackTrace(e);
		}
    }
}
