package it.sella.address.sm.addressmgt;

import it.sella.address.AddressManagerFactory;
import it.sella.address.AddressView;
import it.sella.address.sm.ExecuterHelper;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

public class AddressModifyAllExecuter extends GestioneIndirizziExecuter {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressModifyAllExecuter.class);

	public it.sella.statemachine.ExecuteResult execute(final RequestEvent requestEvent) {
		ExecuteResult executeResult = null;
		final StateMachineSession session = requestEvent.getStateMachineSession();
		final Long soggettoId = (Long)session.get("SoggettoId");
		try {
			final AddressView addressView = AddressManagerFactory.getInstance().getAddressManager().getDefaultPostalAddress(soggettoId);
			addressView.setCausaleSubsystem("ACFW");
			executeResult = ExecuterHelper.getExecuteResult("TrDettaglio");
			setDataForDettaglioPage(executeResult,addressView,soggettoId,session);
			session.put("MODIFY_ALL_CLICKED", "true");
		} catch (final Exception e) {
			log4Debug.warnStackTrace(e);
			executeResult = ExecuterHelper.getExecuteResult("TrElenco");
			setCommonDetails(executeResult,soggettoId,session);
			executeResult.setAttribute("errorMessage",e.getMessage());
		}
		return executeResult;
	}

	private void setDataForDettaglioPage(final ExecuteResult executeResult, final AddressView addressView,final Long soggettoId,final StateMachineSession session) {
		executeResult.setAttribute("tipoIndirizzo", "ACFW".equals(addressView.getCausaleSubsystem()) ? "IPO" : addressView.getCausaleTipoIndirizzo());
		setInExecuteResultFromView(executeResult,addressView);
		setCommonDetails(executeResult,soggettoId,session);
		executeResult.setAttribute("IS_MODIFY_ALL_CLICKED","true");
	}
}
