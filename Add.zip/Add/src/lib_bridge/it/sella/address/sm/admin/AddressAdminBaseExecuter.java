package it.sella.address.sm.admin;

import it.sella.address.AddressException;
import it.sella.address.AddressManagerFactory;
import it.sella.address.IAddressManager;
import it.sella.address.implementation.util.AddressManagerTestMethods;
import it.sella.statemachine.EventExecuter;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.StringTokenizer;

public abstract class AddressAdminBaseExecuter implements EventExecuter {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAdminBaseExecuter.class);

    protected void validateAddressDetails( final RequestEvent requestEvent ) throws AddressException {
        final StateMachineSession session = requestEvent.getStateMachineSession();
        final String strSoggettoId = ((String) requestEvent.getAttribute("soggettoId")).trim();
        final String subSystemCausale = ((String) requestEvent.getAttribute("subSystemCausale")).trim().toUpperCase();
        final String motiv = ((String) requestEvent.getAttribute("motiv")).trim().toUpperCase();
        final String productContoId = ((String) requestEvent.getAttribute("productContoID")).trim();
        final String nchValue = ((String) requestEvent.getAttribute("NCH")).trim();
        Long soggettoId = null;
        if ( "".equals(strSoggettoId) || "".equals(subSystemCausale) || "".equals(motiv) ) {
        	final String errorMsg = "Enter All Details";
			throw new AddressException(errorMsg);	
        }
        try {
            soggettoId = Long.valueOf(strSoggettoId);
            setInSessionAfterNullCheck("SoggettoId", soggettoId, session);
            setInSessionAfterNullCheck("SubSystemId", subSystemCausale, session);
            setInSessionAfterNullCheck("ADMOTIV", motiv, session);
            setInSessionAfterNullCheck("ProductContoId", Long.valueOf(productContoId), session);
            setInSessionAfterNullCheck("NCH", nchValue, session);
        } catch (final NumberFormatException e) {
            log4Debug.severeStackTrace(e);
            final String errorMsg = "Enter a valid Soggetto Id/ProductContoId !!!";
			throw new AddressException(errorMsg);
        }
    }

    protected void validateInputForCheckingAddressAPI(final RequestEvent requestEvent) throws AddressException {
        if ("".equals(requestEvent.getAttribute("methodName")) || "".equals(requestEvent.getAttribute("arguments"))) {
			final String errorMsg = "Enter Proper Details";
			throw new AddressException(errorMsg);
		}
    }

    protected Object invokeMethod(final String arguments, final String methodName) throws AddressException {
        boolean invoked = false;
        boolean methodExecuted = false;
        Object output = null;
        Object[] parameters = null;
        log4Debug.debug(" AddressAdminBaseExecuter: invokeMethod: methodName:===>>",methodName);
        log4Debug.debug(" AddressAdminBaseExecuter: invokeMethod: arguments:===>>",arguments);
        
        if (arguments.indexOf(',') != -1) {
            final StringTokenizer tokenizer = new StringTokenizer(arguments, ",");
            final int tokens = tokenizer.countTokens();
            parameters = new Object[tokens];
            for (int i = 0 ; i < tokens ; i++) {
            	parameters[i] = ("getAddress".equalsIgnoreCase(methodName) || "getPostalAddress".equalsIgnoreCase(methodName) || "getPostalAddressInXMLFormat".equalsIgnoreCase(methodName) || "gestoreAccountAddress".equals(methodName)) ? tokenizer.nextToken() : tokenizer.nextToken().trim();   
            }
        } else {
            parameters = new Object[1];
            parameters[0] = arguments;
        }
        log4Debug.debug(" AddressAdminBaseExecuter: invokeMethod: parameters:===>>",parameters);
        try {
            if("getAddress".equalsIgnoreCase(methodName)) {
                output = AddressManagerTestMethods.getInstance().getAddress(parameters);
                methodExecuted = true;
            } else if("getPostalAddress".equals(methodName)) {
                output = AddressManagerTestMethods.getInstance().getPostalAddress(parameters);
                methodExecuted = true;
            } else if("getPostalAddressInXMLFormat".equalsIgnoreCase(methodName)) {
                output = AddressManagerTestMethods.getInstance().getPostalAddressInXMLFormat(parameters);
                methodExecuted = true;
            } 
            if(!methodExecuted) {
            final IAddressManager addressManager = AddressManagerFactory.getInstance().getAddressManager();
            final Class managerClass = addressManager.getClass();
            final Method[] managerMethods = managerClass.getMethods();
            final int methodSize = managerMethods.length;
            for (int i = 0 ; i < methodSize ; i++) {
                final Method method = managerMethods[i];
                if (method.getName().equals(methodName)) {
                    final Class[] checkParameters = managerMethods[i].getParameterTypes();
                    final int parameterCount = checkParameters.length;
                    if (parameters.length == parameterCount) {
                        for (int j = 0 ; j < parameterCount ; j++) {
                            if (checkParameters[j].toString().indexOf("java.lang.Long") != -1) {
								parameters[j] = Long.valueOf(parameters[j].toString());
							} else if(checkParameters[j].toString().indexOf("java.lang.Boolean") != -1) {
								parameters[j] = Boolean.valueOf(parameters[j].toString());
							} else {
								parameters[j] = parameters[j].toString();
							}
                        }
                        output = method.invoke(managerClass.newInstance(), parameters);
                        invoked = true;
                        break;
                    }
                }
            }
            if (!invoked) {
            	final String errorMsg = "No Such Method Available";
				throw new AddressException(errorMsg);	
            }
            }
        } catch (final Exception e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        } 
        return output;
    }
    
	protected void setInExecuteResultAfterNullCheck( final String key, final Object value, final ExecuteResult executeResult) {
		if( value != null ) {
			executeResult.setAttribute(key, value);
		}
	}

	protected void setInSessionAfterNullCheck( final String key, final Object value, final StateMachineSession session) {
		if( value != null ) {
			session.put(key, (Serializable) value);
		}
	}

	protected void clearSessionDetails( final Map pfDetails, final String key ) {
		if( pfDetails != null && key != null ) {
			pfDetails.remove(key);
		}
	}
	
}
