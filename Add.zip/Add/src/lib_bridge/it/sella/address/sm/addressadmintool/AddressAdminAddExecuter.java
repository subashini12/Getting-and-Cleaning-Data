package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.address.sm.ExecuterHelper;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;

public class AddressAdminAddExecuter extends AddressAdminBaseExecuter {
    
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAdminAddExecuter.class);

    public ExecuteResult execute(final RequestEvent requestEvent) {
        ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrConferma");
        final StateMachineSession session = requestEvent.getStateMachineSession();
        AddressView addressView = null;
        final Map addressDetails = new Hashtable();
        setAddressDetails(requestEvent, addressDetails);
        try {
            addressView = ExecuterHelper.validateIndirizzo(addressDetails);
        } catch (final AddressException e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
            executeResult.setAttribute("errorMessage", e.getMessage());
            setDatasOnError(addressDetails,executeResult);
        }
        executeResult.setAttribute("addressDetails", (Serializable)addressDetails);
        session.put("addressDetails", (Serializable)addressDetails);
        if(addressView != null) {
			session.put("addressView", addressView);
		}
        session.put("OPERATION", "ADD");
        return executeResult;
    }

    private void setDatasOnError(final Map addressDetails, final ExecuteResult executeResult) {
    	setDataInExecuteResult(executeResult, "indirizzo", addressDetails.get("indirizzo"));
    	setDataInExecuteResult(executeResult, "cap", addressDetails.get("cap"));
    	setDataInExecuteResult(executeResult, "citta", addressDetails.get("citta"));
    	setDataInExecuteResult(executeResult, "provincia", addressDetails.get("provincia"));
    	setDataInExecuteResult(executeResult, "nazione", addressDetails.get("nazione"));
    }
    
    private void setDataInExecuteResult(final ExecuteResult executeResult,final String key, final Object value) {
    	executeResult.setAttribute(key, value != null ? (Serializable)value : "");
    }
}
