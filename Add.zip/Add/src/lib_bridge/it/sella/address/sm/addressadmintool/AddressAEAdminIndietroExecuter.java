/**
 * Created by IntelliJ IDEA.
 * User: ssile6
 * Date: Jan 12, 2005
 * Time: 5:34:25 PM
 * To change this template use Options | File Templates.
 */
package it.sella.address.sm.addressadmintool;

import it.sella.address.sm.ExecuterHelper;
import it.sella.address.sm.addressmgt.AddressMgtConstants;
import it.sella.statemachine.EventExecuter;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;

import java.io.Serializable;
import java.util.Map;

public class AddressAEAdminIndietroExecuter implements EventExecuter {
	
	private static final String ADD = "ADD";
	private static final String MODIFY = "MODIFY";
	private static final String DELETE = "DELETE";
	
	public ExecuteResult execute(final RequestEvent requestEvent) {
        ExecuteResult executeResult = null;
        final StateMachineSession session = requestEvent.getStateMachineSession();
        final String operation = (String) session.get(AddressMgtConstants.OPERATION);
        if(ADD.equals(operation)) {
            executeResult = ExecuterHelper.getExecuteResult("TrAddIndietro");
            final Map addressAEDetails = (Map) session.get(AddressMgtConstants.ADDRESSAEDETAILS);
            if(addressAEDetails != null) {
                executeResult.setAttribute(AddressMgtConstants.AELINKID, (Serializable)addressAEDetails.get(AddressMgtConstants.AELINKID));
                executeResult.setAttribute(AddressMgtConstants.AERESERVED, (Serializable)addressAEDetails.get(AddressMgtConstants.AERESERVED));
                executeResult.setAttribute(AddressMgtConstants.AEFREQUENCY, (Serializable)addressAEDetails.get(AddressMgtConstants.AEFREQUENCY));
                executeResult.setAttribute(AddressMgtConstants.AEINTERNAL, (Serializable)addressAEDetails.get(AddressMgtConstants.AEINTERNAL));
            }
        } else if(MODIFY.equals(operation)) {
            executeResult = ExecuterHelper.getExecuteResult("TrModifyIndietro");
            if(session.get(AddressMgtConstants.OLDADDRESSAEDETAILS) != null) {
				executeResult.setAttribute(AddressMgtConstants.OLDADDRESSAEDETAILS,session.get(AddressMgtConstants.OLDADDRESSAEDETAILS));
			}
            if(session.get(AddressMgtConstants.ADDRESSAEDETAILS) != null) {
				executeResult.setAttribute(AddressMgtConstants.ADDRESSAEDETAILS, session.get(AddressMgtConstants.ADDRESSAEDETAILS));
			}
            if(session.get(AddressMgtConstants.ADRESSLINKID) != null) {
				executeResult.setAttribute(AddressMgtConstants.ADRESSLINKID, session.get(AddressMgtConstants.ADRESSLINKID));
			}
        } else if(DELETE.equals(operation)) {
            executeResult = ExecuterHelper.getExecuteResult("TrDeleteIndietro");
            if(session.get(AddressMgtConstants.ADRESSAELINKID) != null) {
				executeResult.setAttribute(AddressMgtConstants.ADRESSAELINKID, session.get(AddressMgtConstants.ADRESSAELINKID));
			}
        }
        return executeResult;
    }

}
