package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressException;
import it.sella.address.AddressManagerBeanHelperException;
import it.sella.address.PostalByPassView;
import it.sella.address.implementation.dbhelper.AddressLogHelper;
import it.sella.address.implementation.dbhelper.PostalFormatBypassHelper;
import it.sella.address.implementation.util.UtilHelper;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineException;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Map;

public class GestorePostalBypassConfermaExecuter extends AddressAdminBaseExecuter {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(
			GestorePostalBypassConfermaExecuter.class);
	private static final String MODIFY = "MODIFY";
	private static final String DELETE = "DELETE";
	private static final String INSERT = "INSERT";

	public ExecuteResult execute(final RequestEvent requestEvent)	throws StateMachineException {
	    ExecuteResult executeResult = null;
	    PostalByPassView postalByPassViewOld = null;
	    PostalByPassView postalByPassViewNew = null;
		String errorMessage = null;
		String byPassCode = null;
		String operationResult = "SUCCESS";
		String operation = null;
		try {
			final StateMachineSession session = requestEvent.getStateMachineSession();
			final Map postalByPassDetails = session.get("POSTALBYBASSDETAILS") != null ?
					(Map) session.get("POSTALBYBASSDETAILS") :  new Hashtable(1);
	    	operation = (String) postalByPassDetails.get("OPERATION");
	    	byPassCode = (String) postalByPassDetails.get("BYBASSCODE");
	    	postalByPassViewOld = (PostalByPassView) postalByPassDetails.get("PostalBypassViewOld");
	    	postalByPassViewNew = (PostalByPassView) postalByPassDetails.get("PostalBypassViewNew");
	    	final PostalFormatBypassHelper posBypassHelper = new PostalFormatBypassHelper();
	    	if (MODIFY.equals(operation)) {
	    		if (!postalByPassViewNew.equals(postalByPassViewOld)) {
	    			log4Debug.debug(" <<===: GestorePostalBypassConfermaExecuter: execute : MODIFY :===>>");
	    			postalByPassViewNew.setId(postalByPassViewOld.getId());
	    			posBypassHelper.updatePostalFormatBypass(postalByPassViewNew);
	    			logOperations(MODIFY, byPassCode, postalByPassViewOld, postalByPassViewNew, operationResult);
	    		}
		    } else if (DELETE.equals(operation)) {
		    	log4Debug.debug(" <<===: GestorePostalBypassConfermaExecuter: execute : DELETE :===>>");
		    	posBypassHelper.removePostalFormatBypass(postalByPassViewNew);
	    		logOperations(DELETE, byPassCode, postalByPassViewNew, null, operationResult);
	    	} else if (INSERT.equals(operation)) {
	    		log4Debug.debug(" <<===: GestorePostalBypassConfermaExecuter: execute : INSERT :===>>");
	    		final Long postalByPassViewId = posBypassHelper.createPostalFormatBypass(postalByPassViewNew);
	    		if(postalByPassViewId != null)
	    		{
	    			postalByPassViewNew.setId(postalByPassViewId);
	    		}
				logOperations(INSERT, byPassCode, null, postalByPassViewNew, operationResult);
	        }
	    	executeResult = getExecuteResult("TrConferma");
	    	session.remove("POSTALBYBASSDETAILS");
		} catch (final Exception e) {
			try {
				operationResult = "FAILURE";
				if (MODIFY.equals(operation)) {
					logOperations(MODIFY, byPassCode, postalByPassViewOld, postalByPassViewNew, operationResult);
				}else if(DELETE.equals(operation)){
					logOperations(DELETE, byPassCode, postalByPassViewNew, null, operationResult);
				}else if(INSERT.equals(operation)){
					logOperations(INSERT, byPassCode, null, postalByPassViewNew, operationResult);
				}
			} catch (final RemoteException e1) {
				log4Debug.severeStackTrace(e);
			} catch (final AddressException e1) {
				log4Debug.severeStackTrace(e);
			}
	    	log4Debug.severeStackTrace(e);
	    	errorMessage = e.getMessage();
	    	executeResult = getNonConfermaExecuteResult("ErrorMessage",errorMessage);
		}
	    return executeResult;
   }
    
   private void logOperations(final String operation, final String byPassCode, 
		   final PostalByPassView postalByPassViewOld, 
		   final PostalByPassView postalByPassViewNew, final String operationResult ) throws AddressException, RemoteException {
	   final StringBuilder logBuffer = new StringBuilder();
	   logBuffer.append(getLogForGivenTag("OPERATION",operation));
	   try {
		   if(MODIFY.equals(operation)) {
			   logBuffer.append("<DATA_OLD>");
			   logBuffer.append(getLogFromView(postalByPassViewOld,byPassCode));
			   logBuffer.append("</DATA_OLD>");
			   logBuffer.append("<DATA_NEW>");
			   logBuffer.append(getLogFromView(postalByPassViewNew,byPassCode));
			   logBuffer.append("</DATA_NEW>");
		   } else if(DELETE.equals(operation)) {
			   logBuffer.append(getLogFromView(postalByPassViewOld,byPassCode));
		   } else if(INSERT.equals(operation)){
			   logBuffer.append(getLogFromView(postalByPassViewNew,byPassCode));
		   }
		   new AddressLogHelper().logMessage(null,"POSTALBYPASS ADIM", logBuffer.toString(), "ADDR-ADPB", operationResult, null);
	   } catch (final AddressManagerBeanHelperException e) {
		   log4Debug.warnStackTrace(e);
		   throw new AddressException(e.getMessage());
	   }
   }
   
   private StringBuffer getLogFromView( final PostalByPassView postalByPassView, final String byPassCode ) {
	   final StringBuffer logBuffer = new StringBuffer();
	   
	   UtilHelper.addLog(logBuffer, "PB_ID", postalByPassView.getId());
	   UtilHelper.addLog(logBuffer, "PB_BYPASS_CODE", byPassCode != null ? byPassCode : postalByPassView.getBypassCode());
	   UtilHelper.addLog(logBuffer, "PB_DESCRIPTION", postalByPassView.getDescription());
	   UtilHelper.addLog(logBuffer, "PB_START_DATE", postalByPassView.getStartDate());
	   UtilHelper.addLog(logBuffer, "PB_END_DATE", postalByPassView.getEndDate());
	   UtilHelper.addLog(logBuffer, "PB_NOTES", postalByPassView.getNotes());
	   return logBuffer;
   }
}
