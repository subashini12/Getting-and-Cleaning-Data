package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressView;
import it.sella.address.implementation.dbhelper.AddressLogHelper;
import it.sella.address.sm.ExecuterHelper;
import it.sella.statemachine.EventExecuter;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

public class AddressAdminConfermaExecuter implements EventExecuter {
    
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAdminConfermaExecuter.class);

    public ExecuteResult execute(final RequestEvent requestEvent) {
        AddressView addressView = null;
        ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrConferma");
        final StateMachineSession session = requestEvent.getStateMachineSession();
        final String operation = (String) session.get("OPERATION");
        Long opId = null;
        String errorMessage = null;
        final AddressLogHelper addressLogHelper = new AddressLogHelper();
        try {
        	 if("MODIFY".equals(operation)) {
                final Long addressPrimaryKey = (Long) session.get("addressPrimaryKey");
                addressView = (AddressView) session.get("addressView");
                opId = addressLogHelper.logAddressOperation("ADDR-MOD", addressView, null, false);
            	AddressAdminToolHelper.modifyAddress(opId, addressView, addressPrimaryKey, session);
             } else if("DELETE".equals(operation)) {
                opId = addressLogHelper.logAddressOperation("ADDR-DEL", null, null, false);
                AddressAdminToolHelper.deleteAddress(opId, session);
             } else if("ADD".equals(operation)) {
                addressView = (AddressView) session.get("addressView");
                opId = addressLogHelper.logAddressOperation("ADDR-INST", addressView, null, false);
                final Long primaryKey = AddressAdminToolHelper.createAddress(opId, addressView, session);
                if(primaryKey != null) {
					session.put("PRIMARY_KEY", primaryKey);
				}
             }
        } catch (final Exception e) {
            log4Debug.warnStackTrace(e);
            errorMessage = e.getMessage();
            executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
            executeResult.setAttribute("errorMessage", errorMessage);
            if(session.get("addressDetails") != null) {
				executeResult.setAttribute("addressDetails", session.get("addressDetails"));
			}
        } finally {
        	 try {
             	addressLogHelper.updateAddressLog(opId, addressView!=null ? addressView.getSoggettoId() : null, errorMessage);
 			} catch (final Exception e) {
 				log4Debug.severe("This exception is just caught not to affect the parent transaction !!!!!");
 				log4Debug.warnStackTrace(e);
 			}
        }
        return executeResult;
    }

 }
