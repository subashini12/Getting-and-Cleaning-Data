package it.sella.address.sm.addressmgt;

import it.sella.address.AddressException;
import it.sella.address.AddressManagerFactory;
import it.sella.address.AddressView;
import it.sella.address.IAddressManager;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.util.ClassificazioneHandler;
import it.sella.anagrafe.CollegamentoView;
import it.sella.anagrafe.GestoreAnagrafeFactory;
import it.sella.anagrafe.GestoreCollegamentoException;
import it.sella.anagrafe.IGestoreAnagrafe;
import it.sella.classificazione.ClassificazioneView;
import it.sella.intestatazione.IIntestatazioneManager;
import it.sella.intestatazione.IntestatazioneException;
import it.sella.intestatazione.IntestatazioneManagerFactory;
import it.sella.statemachine.EventExecuter;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;


public abstract class GestioneIndirizziBaseExecuter implements EventExecuter {
	
	private static final String ANAG = "ANAG";
	private static final String INTST = "INTST";
	private static final String CAE = "CAE";
	private static final String IRE = "IRE";
	private static final String SLE = "SLE";
	private static final String ACCT = "ACCT";
	
	Map getAnagraficAddress( final Long soggettoId, final String tipoSoggetto ) throws RemoteException,AddressException,GestoreCollegamentoException {
		final Map output = new Hashtable(1);
		final IGestoreAnagrafe iGestoreAnagrafe = GestoreAnagrafeFactory.getInstance().getGestoreAnagrafe();
		final IAddressManager addressManager = AddressManagerFactory.getInstance().getAddressManager();
		if( "Plurintestazione".equals(tipoSoggetto) ) {
			final Collection intestatari = iGestoreAnagrafe.getLinkedSoggetto(soggettoId,INTST);
			final Iterator iterator = intestatari.iterator();
			final int size = intestatari.size();
			Long intestatarioId = null;
			for( int i=0; i<size; i++ ) {
				intestatarioId = ((CollegamentoView)iterator.next()).getLinkedSoggettoId();
				output.put(intestatarioId,sortAddress(addressManager.listAddress(intestatarioId, ANAG)));
			}
		} else {
			output.put(soggettoId,sortAddress(addressManager.listAddress(soggettoId, ANAG)));
		}
		return output;
	}

	Collection getAccountAddress( final Long soggettoId, final Long accountId, final String subSystemCausale ) throws AddressException,RemoteException {
		final ArrayList output = new ArrayList(1);
		if( accountId != null ) {
			final AddressView addressView = AddressManagerFactory.getInstance().getAddressManager().getAddress(soggettoId, subSystemCausale, accountId);
			if( addressView != null && !CAE.equals(addressView.getCausaleSubsystem()) ) {
				output.add(addressView);
			}
		} else if( !ANAG.equals(subSystemCausale) ) {
			final Collection listAddress = AddressManagerFactory.getInstance().getAddressManager().listAddress(soggettoId,subSystemCausale);
			if( listAddress != null && !listAddress.isEmpty() ) {
				final Iterator iterator = listAddress.iterator();
				final int size = listAddress.size();
				AddressView addressView = null;
				for( int i=0; i<size; i++ ) {
					addressView = (AddressView)iterator.next();
					if( !CAE.equals(addressView.getCausaleSubsystem()) ) {
						output.add(addressView);
					}
				}
			}
		}
		return output;
	}

	void checkForNullAndSetValue( final Map details, final String keyRetrieve, final ExecuteResult executeResult, final String keySet ) {
		if( details.get(keyRetrieve) != null ) {
			executeResult.setAttribute(keySet,(Serializable)details.get(keyRetrieve));
		}
	}

	private Collection sortAddress( final Collection input ) {
		final ArrayList output = new ArrayList(1);
		final int size = input.size();
		final Iterator iterator = input.iterator();
		AddressView addressView = null; 
		for (int i = 0 ; i < size ; i++) {
			addressView = (AddressView) iterator.next();
			if (IRE.equals(addressView.getCausaleTipoIndirizzo()) || SLE.equals(addressView.getCausaleTipoIndirizzo())) {
				output.add(0, addressView);
			} else {
				output.add(addressView);
			}
		}
		return output;
	}

	Map getIntestazioneString( final Long soggettoId ) throws RemoteException,IntestatazioneException {
		final Map output = new Hashtable(1);
		final String intestazineString = IntestatazioneManagerFactory.getInstance().getIntestatazioneManager().getIntestatazioneString(soggettoId);
		output.put(soggettoId,intestazineString != null ? intestazineString : "");
		return output;
	}

	Map getIntestatariNames( final Long soggettoId ) throws GestoreCollegamentoException,IntestatazioneException,RemoteException {
		final Map output = new Hashtable(1);
		final Collection intestatari = GestoreAnagrafeFactory.getInstance().getGestoreAnagrafe().getLinkedSoggetto(soggettoId,INTST);
		final IIntestatazioneManager iIntestatazioneManager = IntestatazioneManagerFactory.getInstance().getIntestatazioneManager();
		final Iterator iterator = intestatari.iterator();
		final int size = intestatari.size();
		String intestazione = null;
		Long intestatarioId = null;
		for( int i=0; i<size; i++ ) {
			intestatarioId = ((CollegamentoView)iterator.next()).getLinkedSoggettoId();
			intestazione = iIntestatazioneManager.getIntestatazioneString(intestatarioId);
			output.put(intestatarioId,intestazione != null ? intestazione : "");
		}
		intestazione = iIntestatazioneManager.getIntestatazioneString(soggettoId);
		output.put(soggettoId,intestazione != null ? intestazione : "");
		return output;
	}

	ClassificazioneView getClassificazioneView( final String causale, final String parentCausale ) throws SubSystemHandlerException,RemoteException {
		return ClassificazioneHandler.getClassificazioneView(causale,parentCausale);
	}

	AddressView getSelectedView( final Long soggettoId, final String selectedAddress ) throws AddressException,RemoteException{
		AddressView addressView = null;
		final StringTokenizer tokenizer = new StringTokenizer(selectedAddress,"^");
		final String temp = tokenizer.nextToken().trim();
		if( ANAG.equals(temp) ) {
            addressView = getSelectedAnagraficAddressView(Long.valueOf(tokenizer.nextToken()),tokenizer.nextToken());
		} else if( ACCT.equals(temp) ) {
            addressView = AddressManagerFactory.getInstance().getAddressManager().getAddress(soggettoId,tokenizer.nextToken(),Long.valueOf(tokenizer.nextToken()));
		}
		return addressView;
	}

    private AddressView getSelectedAnagraficAddressView( final Long soggettoId, final String tipoIndirizzo )throws AddressException,RemoteException {
		AddressView addressView = null;
		final Collection anagAddress = AddressManagerFactory.getInstance().getAddressManager().listAddress(soggettoId,ANAG);
		final int size = anagAddress.size();
		final Iterator iterator = anagAddress.iterator();
		for( int i=0; i<size; i++ ) {
			addressView = (AddressView)iterator.next();
			if( addressView.getCausaleTipoIndirizzo().equals(tipoIndirizzo) ) {
				break;
			}
			addressView = null;
		}
		return addressView;
	}

	void checkForNullAndSetLong( final RequestEvent requestEvent, final String keyRetrieve, final Map details, final String keyStore ) {
		if( requestEvent.getAttribute(keyRetrieve) != null ) {
			details.put(keyStore,Long.valueOf(((String)requestEvent.getAttribute(keyRetrieve))));
		}
	}
	
	public void setInExecuteResultSetWithValueCheck( final ExecuteResult executeResult, final String key, final Object value) {
    	executeResult.setAttribute(key, value != null ? value : "");
    }
	
	public void isNotNullSetInExecuteResultSet( final ExecuteResult executeResult, final String key, final Object value) {
    	if( executeResult != null && key != null && value != null) {
    		executeResult.setAttribute(key,value);
    	}
    }
}
