package it.sella.address.sm.addressmgt;

import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.address.sm.ExecuterHelper;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

public class ElencoAddressConfermaExecuter extends GestioneIndirizziExecuter
{
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(ElencoAddressConfermaExecuter.class);

	public it.sella.statemachine.ExecuteResult execute(final RequestEvent requestEvent) {
		ExecuteResult executeResult = null;
		final StateMachineSession session = requestEvent.getStateMachineSession();
		final String selectedAddress = (String) requestEvent.getAttribute("selectedAddress");
		final Long soggettoId = (Long)session.get("SoggettoId");
		try {
			if(selectedAddress == null || "".equals(selectedAddress)) {
				throw new AddressException(AddressErrorConstants.ERR13);
			}
			final AddressView addressView = getSelectedView(soggettoId,selectedAddress);
			if ("MANCANTE".equals(addressView.getIndirizzo()) || "MANCANTE".equals(addressView.getCitta())) {
				throw new AddressException(AddressErrorConstants.ERR18);
			}
			addressView.setSoggettoId(soggettoId);
			addressView.setCausaleTipoIndirizzo("IPO");
			addressView.setTipoIndirrizo(null);
			addressView.setNch((String)session.get("NCH"));
			addressView.setCausaleSubsystem((String)session.get("SubSystemId"));
			session.put("ADDRESSVIEW", addressView);
			executeResult = ExecuterHelper.getExecuteResult("TrConferma");
			clearSession(session);
		} catch (final Exception e) {
			log4Debug.warnStackTrace(e);
			executeResult = getNonConfermaTransition(e,soggettoId,session);
		}
		return executeResult;
	}

	private ExecuteResult getNonConfermaTransition(final Exception e,final Long soggettoId,final StateMachineSession session) {
		final ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrNonConferma");
		setCommonDetails(executeResult,soggettoId,session);
		executeResult.setAttribute("errorMessage",e.getMessage());
		return executeResult;
	}
}
