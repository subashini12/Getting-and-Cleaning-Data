package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressException;
import it.sella.address.HelperException;
import it.sella.address.sm.ExecuterHelper;
import it.sella.address.sm.addressmgt.AddressMgtConstants;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.Serializable;
import java.util.Map;

public class AddressAEAdminModifyExecuter extends AddressAEAdminBaseExecuter {
    
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAEAdminModifyExecuter.class);
	private static final String ERRORMESSAGE = "errorMessage";
	private static final String TRNONCONFERMA = "TrNonConferma";

    public ExecuteResult execute(final RequestEvent requestEvent) {
        ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrConferma");
        final StateMachineSession session = requestEvent.getStateMachineSession();
        String errorMessage = null;
        Map addressAEDetails = null;
        try {
	        addressAEDetails = getAddressAEDetails(requestEvent);
	        if(addressAEDetails.get(AddressMgtConstants.AELINKID) != null) {
				session.put(AddressMgtConstants.ADRESSAELINKID, Long.valueOf((String)addressAEDetails.get(AddressMgtConstants.AELINKID)));
			}
            session.put(AddressMgtConstants.OLDADDRESSAEDETAILS, (Serializable)addressAEDetails);
            executeResult.setAttribute(AddressMgtConstants.OLDADDRESSAEDETAILS,  (Serializable)addressAEDetails);
            session.put(AddressMgtConstants.OPERATION,"MODIFY");
        } catch (final HelperException e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult(TRNONCONFERMA);
            errorMessage = e.getMessage();
        } catch(final NumberFormatException e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult(TRNONCONFERMA);
            errorMessage = "Enter a valid Address AE Link Id !!!";
        } catch (final AddressException e) {
            log4Debug.severeStackTrace(e);
            executeResult = ExecuterHelper.getExecuteResult(TRNONCONFERMA);
            errorMessage = e.getMessage();
        }
        if(errorMessage != null) {
            executeResult.setAttribute(ERRORMESSAGE, errorMessage);
            if(addressAEDetails != null && addressAEDetails.get(AddressMgtConstants.AELINKID) != null) {
				executeResult.setAttribute(AddressMgtConstants.ADRESSAELINKID, (Serializable)addressAEDetails.get(AddressMgtConstants.AELINKID));
			}
            if(session.get(AddressMgtConstants.OLDADDRESSAEDETAILS) != null) {
				executeResult.setAttribute(AddressMgtConstants.OLDADDRESSAEDETAILS,session.get(AddressMgtConstants.OLDADDRESSAEDETAILS));
			}
            if(session.get(AddressMgtConstants.ADDRESSAEDETAILS) != null) {
				executeResult.setAttribute(AddressMgtConstants.ADDRESSAEDETAILS, session.get(AddressMgtConstants.ADDRESSAEDETAILS));
			}
        }
        return executeResult;
    }
}
