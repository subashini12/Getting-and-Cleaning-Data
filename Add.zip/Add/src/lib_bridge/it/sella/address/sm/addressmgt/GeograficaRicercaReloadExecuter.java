package it.sella.address.sm.addressmgt;

import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.util.AnagrafeHandler;
import it.sella.address.sm.ExecuterHelper;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Map;

public class GeograficaRicercaReloadExecuter extends InputDetailsHandlerExecuter
{
        
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(GeograficaRicercaReloadExecuter.class);

    public ExecuteResult execute(final RequestEvent requestEvent) {
        final ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrDettaglio");
		try {
			final StateMachineSession session = requestEvent.getStateMachineSession();
			final Long soggettoId = (Long)session.get("SoggettoId");
			final Map preValues = (Map) session.remove("PREV_VALUES");
			final Long geograficaId = (Long) session.remove("GEOGRAFICA_ID");
			final String operationName = (String) session.remove("OPERATION_NAME");
			session.remove("OPERATION");
			setInputDetails(executeResult, preValues,null);
			setCommonDetails(executeResult,soggettoId,session);
			setNewGeograficaRicercaValue(executeResult,geograficaId,operationName);
		} catch (final Exception e) {
			log4Debug.warnStackTrace(e);
			executeResult.setAttribute("errorMessage",e.getMessage());
		}
        return executeResult;
    }

    private void setNewGeograficaRicercaValue(final ExecuteResult executeResult,final Long geograficaId,final String operationName) throws SubSystemHandlerException, RemoteException {
        if(geograficaId != null) {
            final AnagrafeHandler anagrafeHandler = new AnagrafeHandler();
			if("RICERCA_CAP".equals(operationName)) {
				executeResult.setAttribute("cap", anagrafeHandler.getCap(geograficaId).getCap());
			} else if("RICERCA_CITTA".equals(operationName)) {
				executeResult.setAttribute("citta", anagrafeHandler.getCitta(geograficaId).getCommune());
			} else if("RICERCA_PROVINCIA".equals(operationName)) {
				executeResult.setAttribute("provincia", anagrafeHandler.getProvincia(geograficaId).getSigla());
			} else if("RICERCA_NAZIONE".equals(operationName)) {
				executeResult.setAttribute("nazione", anagrafeHandler.getNazione(geograficaId).getNome());
			}
        }
    }
}
