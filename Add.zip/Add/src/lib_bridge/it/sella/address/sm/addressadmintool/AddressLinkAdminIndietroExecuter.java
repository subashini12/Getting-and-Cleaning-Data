/**
 * Created by IntelliJ IDEA.
 * User: ssile6
 * Date: Jan 18, 2005
 * Time: 6:23:47 PM
 * To change this template use Options | File Templates.
 */
package it.sella.address.sm.addressadmintool;

import it.sella.address.sm.ExecuterHelper;
import it.sella.address.sm.addressmgt.AddressMgtConstants;
import it.sella.statemachine.EventExecuter;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;

import java.io.Serializable;
import java.util.Map;

public class AddressLinkAdminIndietroExecuter implements EventExecuter {
	
	private static final String SOGGETTOID = "soggettoId";
	private static final String SUBSYSTEM = "subSystem";
	private static final String ADDRESSTYPE = "addressType";
	private static final String PRODUCTID = "productId";
	private static final String ADDRESSID = "addressId";
   
	public ExecuteResult execute(final RequestEvent requestEvent) {
        ExecuteResult executeResult = null;
        final StateMachineSession session = requestEvent.getStateMachineSession();
        final String operation = (String) session.get(AddressMgtConstants.OPERATION);
        if("ADD".equals(operation)) {
            executeResult = ExecuterHelper.getExecuteResult("TrAddIndietro");
            final Map addressLinkDetails = (Map) session.get(AddressMgtConstants.ADDRESSLINKDETAILS);
            if(addressLinkDetails != null) {
                executeResult.setAttribute(SOGGETTOID, (Serializable)addressLinkDetails.get(SOGGETTOID));
                executeResult.setAttribute(SUBSYSTEM, (Serializable)addressLinkDetails.get(SUBSYSTEM));
                executeResult.setAttribute(ADDRESSTYPE, (Serializable)addressLinkDetails.get(ADDRESSTYPE));
                executeResult.setAttribute(PRODUCTID, (Serializable)addressLinkDetails.get(PRODUCTID));
                executeResult.setAttribute(ADDRESSID, (Serializable)addressLinkDetails.get(ADDRESSID));
            }
        } else if("MODIFY".equals(operation)) {
            executeResult = ExecuterHelper.getExecuteResult("TrModifyIndietro");
            if(session.get(AddressMgtConstants.OLDADDRESSLINKDETAILS) != null) {
				executeResult.setAttribute(AddressMgtConstants.OLDADDRESSLINKDETAILS,session.get(AddressMgtConstants.OLDADDRESSLINKDETAILS));
			}
            if(session.get(AddressMgtConstants.ADDRESSLINKDETAILS) != null) {
				executeResult.setAttribute(AddressMgtConstants.ADDRESSLINKDETAILS, session.get(AddressMgtConstants.ADDRESSLINKDETAILS));
			}
        } else if("DELETE".equals(operation)) {
            executeResult = ExecuterHelper.getExecuteResult("TrDeleteIndietro");
            if(session.get(SOGGETTOID) != null) {
				executeResult.setAttribute(SOGGETTOID, session.get(SOGGETTOID));
			}
            if(session.get(AddressMgtConstants.OLDADDRESSLINKDETAILS) != null) {
				executeResult.setAttribute(AddressMgtConstants.OLDADDRESSLINKDETAILS,session.get(AddressMgtConstants.OLDADDRESSLINKDETAILS));
			}
        }
        return executeResult;
    }

}
