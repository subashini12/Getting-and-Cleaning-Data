package it.sella.address.sm.addressmgt;

import it.sella.address.sm.ExecuterHelper;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;

public class AddressAggiungiExecuter extends GestioneIndirizziExecuter {
	
	public it.sella.statemachine.ExecuteResult execute( final RequestEvent requestEvent ) {
		final ExecuteResult executeResult = ExecuterHelper.getExecuteResult("TrConferma");
		final StateMachineSession session = requestEvent.getStateMachineSession();
		final Long soggettoId = (Long)session.get("SoggettoId");
		setCommonDetails(executeResult,soggettoId,session);	
		return executeResult;
	}
}
