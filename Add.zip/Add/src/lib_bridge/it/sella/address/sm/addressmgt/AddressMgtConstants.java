package it.sella.address.sm.addressmgt;

public class AddressMgtConstants
{
	
	public static final String ADDR_SESSION = "AddressSession";
	public static final String ADDR_MOTIV = "AddressMotiv";
    public static final String ADDR_SOGGETTO_ID = "AddressSoggettoId";
    public static final String ADDR_SUBSYSTEM_ID = "AddressSubSystemId";
    public static final String ADDR_SUBSYSTEM_CAUSALE = "AddressSubSystemCausale";
    public static final String ADDR_COLL = "AddressColl";
    public static final String ADDR_NUMERO_CONTOS = "Numero Contos";
    public static final String ADDR_TIPO_CONTOS = "Tipo Contos";
    public static final String ADDR_STATUS_CONTOS = "Status Contos";
    public static final String ADDR_INTERNAL_TYPES = "InternalAddressTypeColl";
    public static final String ANAG_ADDR_COLL = "AnagraficAddresses";
    public static final String PROD_ADDR_COLL = "ProductAddresses";
    public static final String ADDRESSDETAILS = "addressDetails";
    public static final String ADDRESSPKID = "addressPkId";
    public static final String OLDADDRESSDETAILS = "oldAddressDetails";
    public static final String ADDRESSPRIMARYKEY = "addressPrimaryKey";
    public static final String ADDRESSVIEW = "addressView";
    public static final String OPERATION = "OPERATION";
    public static final String AELINKID = "aeLinkId";
    public static final String AERESERVED = "aeReserved";
    public static final String AEFREQUENCY = "aeFrequency";
    public static final String AEINTERNAL = "aeInternal";
    public static final String ADDRESSAEDETAILS = "addressAEDetails";
    public static final String ADRESSAELINKID = "addressAELinkId";
    public static final String ADRESSLINKID = "addressLinkId";
    public static final String OLDADDRESSAEDETAILS = "oldAddressAEDetails";
    public static final String ADDRESSLINKDETAILS = "addressLinkDetails";
    public static final String OLDADDRESSLINKDETAILS = "oldAddressLinkDetails";
}
