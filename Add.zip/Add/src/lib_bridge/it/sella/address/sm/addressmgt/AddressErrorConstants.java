
package it.sella.address.sm.addressmgt;

public class AddressErrorConstants {

    public static final String ERR01 = "Tipo Indirizzo Obbligatorio";
    public static final String ERR02 = "Indirizzo obbligatorio";
    public static final String ERR03 = "Citta obbligatoria";
    public static final String ERR04 = "Nazione Obbligatoria";
    public static final String ERR05 = "Address with this tipo indirizzo already exists";
    public static final String ERR06 = "Enter Proper Tipo Indirizzo";
    public static final String ERR07 = "Nazione Non Valida";
    public static final String ERR08 = "Cap Obbligatorio";
    public static final String ERR09 = "Provincia Obbligatoria";
    public static final String ERR10 = "Citta non Valida";
    public static final String ERR11 = "Provincia Non Valida";
    public static final String ERR12 = "Cap Non Valido";
    public static final String ERR13 = "Selezionare almeno un indirizzo";
    public static final String ERR14 = "ID conto/prodotto inesistenti";
    public static final String ERR15 = "Indirizzo gi� presente per il conto/prodotto";
    public static final String ERR16 = "Indirizzo gi� presente per l�ID conto/prodotto";
    public static final String ERR17 = "Tipo indirizzo con compatibile con la chiave sottosistema";
    public static final String ERR18 = "Address with MANCANTE not allowed for products";
    public static final String ERR19 = "Non Sono Ammessi i Caratteri ( e ) e ^";
    public static final String ERR20 = "User not allowed for this INVIO/TIPO INDIRIZZO";
    public static final String ERR21 = "Non Sono Ammessi i Caratteri ( & ) ";
    public static final String ERR22 = "PRODUCT/CONTO ID deve essere nullo se il sottosistema chiamante � ANAG(IRE/IDO/SLE/SAM)";
}
