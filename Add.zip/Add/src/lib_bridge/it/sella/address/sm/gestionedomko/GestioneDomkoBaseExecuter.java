package it.sella.address.sm.gestionedomko;

import it.sella.acfw.GestoreContiFactory;
import it.sella.acfw.ICaratteristicheConto;
import it.sella.address.AddressConstants;
import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.dbhelper.LogDBAccessHelper;
import it.sella.address.implementation.util.ClassificazioneHandler;
import it.sella.address.implementation.util.Helper;
import it.sella.address.implementation.util.SecurityHandler;
import it.sella.address.log.LogView;
import it.sella.classificazione.ClassificazioneView;
import it.sella.statemachine.EventExecuter;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;

public abstract class GestioneDomkoBaseExecuter implements EventExecuter {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(GestioneDomkoBaseExecuter.class);
    
	protected void getNumeroAndTipoConto(final Collection addressCollection, final Map addressSession) throws AddressException,SubSystemHandlerException,RemoteException {
	    final Map tipoContoTable = new Hashtable();
        if (addressCollection != null && !addressCollection.isEmpty()) {
            final int size = addressCollection.size();
            final Map numeroContos = new Hashtable(size);
            final Map tipoContos = new Hashtable(size);
            final Map statusContos = new Hashtable(size);
            final Map internalValues = new Hashtable();
        	tipoContoTable.put("01","C/C");
        	tipoContoTable.put("05","D/R");
        	tipoContoTable.put("02","C/T");
            final Iterator iterator = addressCollection.iterator();
            AddressView addressView = null;
            for (int i = 0; i < size; i++) {
                String tipoConto = "";
                String numeroConto = "";
                String statusConto = "";
                addressView = (AddressView) iterator.next();
                if (!"ANAG".equals(addressView.getCausaleSubsystem())) {
                    if ("ACFW".equals(addressView.getCausaleSubsystem())) {
                        try {
                            final ICaratteristicheConto caratteristicheConto = GestoreContiFactory.getInstance().getGestoreConti().getCaratteristicheConto(addressView.getProductContoId());
                            statusConto = caratteristicheConto.getDataChiusura() != null ? "chiuso" : "aperto";   
                            final String tipoContoCausale = caratteristicheConto.getTipoConto();
                            if ("45".equals(tipoContoCausale)) {
                                tipoConto = "MUTUO";
                                numeroConto = caratteristicheConto.getCodiceEsterno("13CifreHost");
                            } else {
                            	tipoConto = tipoContoTable.get(tipoContoCausale) != null ? (String) tipoContoTable.get(tipoContoCausale) : ""; 
                                numeroConto = caratteristicheConto.getCodiceEsterno("NC");
                            }
                            numeroConto = (caratteristicheConto.isNumerato() && !SecurityHandler.isOperationAllowedForNumerati(caratteristicheConto.getSuccursale())) ? "Conto Numerato" : numeroConto;
                        } catch (final Exception e) {
                            log4Debug.warnStackTrace(e);
                        } 
                    } else if(addressView.getProductContoId() != null) {
						if("VIACARD".equals(addressView.getCausaleSubsystem())) {
							numeroConto = addressView.getProductContoId().toString();
						} else if("BANTEL".equals(addressView.getCausaleSubsystem())) {
							numeroConto = addressView.getProductContoId().toString();
							numeroConto = numeroConto.length() < 8 ? get8DigitNumeroConto(numeroConto) : numeroConto;  
						}
					}
                    if (addressView.getInternal().longValue() > 0) {
                        internalValues.put(addressView.getProductContoId(), getClassificazioneView(addressView.getInternal()));
                    }
                    numeroContos.put(addressView.getProductContoId(), numeroConto);
                    tipoContos.put(addressView.getProductContoId(), tipoConto);
                    statusContos.put(addressView.getProductContoId(), statusConto);
                }
            }
			addressSession.put(AddressConstants.ADDR_NUMERO_CONTOS, numeroContos);
			addressSession.put(AddressConstants.ADDR_TIPO_CONTOS, tipoContos);
			addressSession.put(AddressConstants.ADDR_STATUS_CONTOS, statusContos);
			addressSession.put(AddressConstants.INTERNAL_TYPES, internalValues);
        }
    }


	protected Map getDatasForLog(final Long soggettoId) throws AddressException {
       return getLogViews(new LogDBAccessHelper().getLogForSoggettoAndProductID(soggettoId));
    }

	protected Map getDatasForDOMKOLog(final Long soggettoId) throws AddressException {
       return getLogViews(new LogDBAccessHelper().getLogDOMKO(soggettoId));
    }

	protected Map getLogViews(final Collection logDataCollection) {
        final Map logDataHash = new Hashtable();
        if (logDataCollection != null) {
            final int size = logDataCollection.size();
            final Iterator iterator = logDataCollection.iterator();
            for (int i = 0; i < size; i++) {
                final LogView logView = (LogView) iterator.next();
                logDataHash.put(logView.getAccountId(), logView);
            }
        }
        return logDataHash;
    }

	protected ExecuteResult getNonConfermaExecuteResult(final StateMachineSession session) {
        final ExecuteResult executeResult = Helper.getExecuteResult("TrNonConferma");
        session.remove(AddressConstants.ADDR_SESSION);
        return executeResult;
    }

	protected String get8DigitNumeroConto(final String inputNumeroConto) {
		final StringBuffer output = new StringBuffer();
		final int length = inputNumeroConto.length();
		for (int i=length; i<8 ; i++) {
			output.append("0");
		}
		return output.append(inputNumeroConto).toString();
	}
	
	private ClassificazioneView getClassificazioneView(final Long aeInternal) throws AddressException,SubSystemHandlerException,RemoteException {
		try {
			return ClassificazioneHandler.getClassificazioneView(aeInternal); 
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			final String errorMsg = "ClId for Address AE Internal:"+aeInternal+" is invalid !!!";
			throw new AddressException(errorMsg); 
		}		
	}
}
