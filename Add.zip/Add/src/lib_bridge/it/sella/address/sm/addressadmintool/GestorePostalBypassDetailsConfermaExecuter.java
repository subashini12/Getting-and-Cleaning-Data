package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressException;
import it.sella.address.HelperException;
import it.sella.address.PostalByPassView;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Hashtable;
import java.util.Map;

public class GestorePostalBypassDetailsConfermaExecuter extends AddressAdminBaseExecuter {
	
    private static final Log4Debug log4Debug  = Log4DebugFactory.getLog4Debug(
    		GestorePostalBypassDetailsConfermaExecuter.class);
    
    public ExecuteResult execute( final RequestEvent requestEvent ) {
    	ExecuteResult executeResult = null;
    	final PostalByPassAdminHelper postalByPassAdminHelper = new PostalByPassAdminHelper();
		final StateMachineSession session = requestEvent.getStateMachineSession();
		final Map postalByPassDetails = session.get("POSTALBYBASSDETAILS") != null ?
				(Map) session.get("POSTALBYBASSDETAILS") :  new Hashtable(1);
		PostalByPassView postalByPassView = null;
    	try {
    		postalByPassDetails.remove("PostalBypassViewNew");
    		postalByPassAdminHelper.validateAllFields(requestEvent, false);
    		postalByPassView = postalByPassAdminHelper.getPostalByPassView(requestEvent,null);
    		executeResult = getExecuteResult("TrConferma");
    	} catch(final AddressException e) {
    		log4Debug.severeStackTrace(e);
    		executeResult = getNonConfermaExecuteResult("ErrorMessage", e.getMessage());
    	} catch(final HelperException e) {
    		log4Debug.severeStackTrace(e);
    		executeResult = getNonConfermaExecuteResult("ErrorMessage", e.getMessage());
    	}
    	isNotNullSetInMap(postalByPassDetails, "PostalBypassViewNew", postalByPassView);
		return executeResult;
	} 
}

