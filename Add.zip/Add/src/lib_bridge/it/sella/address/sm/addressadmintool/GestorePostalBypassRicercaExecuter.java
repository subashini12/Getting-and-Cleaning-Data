package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressException;
import it.sella.address.PostalByPassView;
import it.sella.address.implementation.dbhelper.PostalFormatBypassHelper;
import it.sella.address.implementation.util.Helper;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineException;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Hashtable;
import java.util.List;
import java.util.Map;

public class GestorePostalBypassRicercaExecuter extends AddressAdminBaseExecuter {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(GestorePostalBypassRicercaExecuter.class);

	public ExecuteResult execute(final RequestEvent requestEvent)	throws StateMachineException {
		ExecuteResult executeResult = null;
		List<PostalByPassView> postalByPassList = null;
		final String bypassCode = ((String)requestEvent.getAttribute("bypassCode")).trim();
		final StateMachineSession stateMachineSession = requestEvent.getStateMachineSession();
		final Map postalByPassDetails = stateMachineSession.get("POSTALBYBASSDETAILS") != null ?
				(Map) stateMachineSession.get("POSTALBYBASSDETAILS") :  new Hashtable(1);
		try {
			log4Debug.debug(" GestorePostalBypassRicercaExecuter: execute: bypassCode:===>>",bypassCode);
			if (bypassCode.trim().length() < 1) {
				final String errorMessage = "ByPassCode ";
				throw new AddressException(errorMessage+Helper.getMessage("ANAG-1264"));
			}
			postalByPassList = new PostalFormatBypassHelper().getPostalFormatBypass(bypassCode);
			log4Debug.debug(" GestorePostalBypassRicercaExecuter: execute: postalFormatCol:===>>",postalByPassList);
			if (postalByPassList.size() < 1) {
				throw new AddressException(Helper.getMessage("ANAG-1356"));
			}
			executeResult = getExecuteResult("TrConferma");
			isNotNullSetInExecuteResultSet(executeResult, "postalByPassList", postalByPassList);
		} catch (final AddressException e) {
			log4Debug.severeStackTrace(e);
			executeResult = getNonConfermaExecuteResult("ErrorMessage", e.getMessage());
		} 
		isNotNullSetInMap(postalByPassDetails, "BYBASSCODE", bypassCode);
		isNotNullSetInSession(stateMachineSession, "POSTALBYBASSDETAILS", postalByPassDetails);
		return executeResult;
	}
}