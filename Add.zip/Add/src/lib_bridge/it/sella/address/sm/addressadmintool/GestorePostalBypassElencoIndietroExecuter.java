package it.sella.address.sm.addressadmintool;

import it.sella.address.AddressException;
import it.sella.address.implementation.dbhelper.PostalFormatBypassHelper;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Map;

public class GestorePostalBypassElencoIndietroExecuter extends AddressAdminBaseExecuter {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(GestorePostalBypassElencoIndietroExecuter.class);

	public ExecuteResult execute(final RequestEvent requestEvent)	throws StateMachineException {
    	ExecuteResult executeResult = null;
		try {
	    	final String byPassCode = (String) ((Map) requestEvent.getStateMachineSession().get("POSTALBYBASSDETAILS")).get("BYBASSCODE");
			executeResult = getExecuteResult("TrRicerca");
			isNotNullSetInExecuteResultSet(executeResult, "postalByPassList", new PostalFormatBypassHelper().getPostalFormatBypass(byPassCode));
		} catch (final AddressException e) {
			log4Debug.severeStackTrace(e);
			executeResult = getNonConfermaExecuteResult("ErrorMessage", e.getMessage());
		}
		return executeResult;
	}	
}
