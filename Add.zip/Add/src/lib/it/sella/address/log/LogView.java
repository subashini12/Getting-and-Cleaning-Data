package it.sella.address.log;

import it.sella.address.ILogView;

import java.sql.Timestamp;

public class LogView implements ILogView {
	
    public String getCodiciDipendente() {
        return codiciDipendente;
    }

    public void setCodiciDipendente(final String codiciDipendente) {
        this.codiciDipendente = codiciDipendente;
    }

    public Timestamp getDateOfOperation() {
        return dateOfOperation;
    }

    public void setDateOfOperation(final Timestamp dateOfOperation) {
        this.dateOfOperation = dateOfOperation;
    }

    public Long getSoggettoId() {
        return soggettoId;
    }

    public void setSoggettoId(final Long soggettoId) {
        this.soggettoId = soggettoId;
    }

    public String getModeOfOperation() {
        return modeOfOperation;
    }

    public void setModeOfOperation(final String modeOfOperation) {
        this.modeOfOperation = modeOfOperation;
    }

    public String getParameterList() {
        return null;
    }

    public String getShortParameterList() {
        return null;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(final Long accountId) {
        this.accountId = accountId;
    }

    private String codiciDipendente;
    private Timestamp dateOfOperation;
    private Long soggettoId;
    private String modeOfOperation;
    private Long accountId;

}
