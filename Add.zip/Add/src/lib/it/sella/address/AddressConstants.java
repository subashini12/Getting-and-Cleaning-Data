
package it.sella.address;

public class AddressConstants {
    
    public static final String ADDR_SESSION = "GestoreDOMKOSession";
    public static final String ADDR_SOGGETTO_ID = "GestoreIndirizziSoggettoId";
    public static final String ADDR_COLL = "GestoreIndirizziColl";
    public static final String ADDR_NUMERO_CONTOS = "Numero Contos";
    public static final String ADDR_TIPO_CONTOS = "Tipo Contos";
    public static final String ADDR_STATUS_CONTOS = "Status Contos";
    public static final String INTESTAZIONESTRING = "INTESTAZIONESTRING";
    public static final String INTERNAL_TYPES ="Internal Types";
    public static final String LOG_DATAS = "Log Datas";
    public static final String ADDR_PRODUCT_IDS = "ProductIds";
    public static final String LOG_DOMKO = "Log DOMKO";
    public static final String INDIRIZZO_SCARTATO_MESSAGE = "INDIRIZZO SCARTATO�(dopo aver verificato la correttezza dell'indirizzo puoi procedere all'inserimento):";
    public static final String SUBSYS = "SUBSYS";
    public static final String DOMOL = "DOMOL";
    public static final String DOMCP = "DOMCP";
    public static final String DOMDG = "DOMDG";
    public static final String DOMKO = "DOMKO";
    public static final String DOMOR = "DOMOR";
    public static final String BUNDLE_KEY = "INTERNAL";
    public static final String DAOIMPL_KEY_FOR_AEADDRESS = "Manager.AEAddress";
    public static final String DAOIMPL_KEY_FOR_ADDRESSLINK = "Manager.AddressLink";
    public static final String DAOIMPL_KEY_FOR_ADDRESS = "Manager.Address";
}

