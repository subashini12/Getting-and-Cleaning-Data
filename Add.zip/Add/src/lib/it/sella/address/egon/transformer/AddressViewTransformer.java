package it.sella.address.egon.transformer;

import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.egon.common.AddressAbstractTransformer;
import it.sella.address.egon.common.EgonUtil;
import it.sella.address.egon.view.EgonAddressView;
import it.sella.address.implementation.util.AnagrafeHandler;
import it.sella.anagrafe.ICapView;
import it.sella.anagrafe.ICittaView;
import it.sella.anagrafe.IProvinciaView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Comparator;

public class AddressViewTransformer extends AddressAbstractTransformer<AddressView, EgonAddressView, AddressView> implements Comparator<String>{

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressViewTransformer.class);

	@Override
	public AddressView transform(final AddressView addressViewOld,final EgonAddressView egonAddressView) throws AddressException {
		final AddressView addressView = addressViewOld;
		if (!EgonUtil.isNull(egonAddressView)) {
			log4Debug.debug(egonAddressView.toString());
			setCap(egonAddressView, addressView);
			setProvincia(egonAddressView, addressView);
			setCitta(egonAddressView, addressView);
			addressViewOld.setIndirizzo(egonAddressView.getIndirizzo());
			addressViewOld.setNormStatus(egonAddressView.getNormalisationSuccess() ? "OK":"KO");
			addressViewOld.setPresso(egonAddressView.getPresso());//Need to check whether retuned by EGON else code to be commented
			addressViewOld.setEdificio(egonAddressView.getEdificio());//Need to check whether retuned by EGON else code to be commented
		}
		return addressView;
	}

	@Override
	public int compare(final String value1, final String value2) {
		return value1.compareTo(value2) ;
	}

	private void setCap(final EgonAddressView egonAddressView, final AddressView addressView) throws AddressException {
		try {
			final String cap = !EgonUtil.isNull(addressView.getCapView()) ? addressView.getCapView().getCap() : (!EgonUtil.isEmpty(addressView.getCap()) ? addressView.getCap() : "");
			final String egoncap = egonAddressView.getCap();
			final Boolean valid = (compare(cap, egoncap) ==0) ? Boolean.TRUE :Boolean.FALSE ;
			if (!valid) {
				final ICapView capView = new AnagrafeHandler().getCapviewForCapcodeAndCittacommune(egoncap, egonAddressView.getCitta());
				addressView.setCapView(capView);
			}
		}  catch (RemoteException e) {
			log4Debug.severeStackTrace(e);
			throw new AddressException(e.getMessage());
		} catch (SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		}
	}

	private void setProvincia(final EgonAddressView egonAddressView, AddressView addressView) throws AddressException {
		try {
			final String provinciaNome = !EgonUtil.isNull(addressView.getProvinciaView()) ? addressView.getProvinciaView().getNome() : (!EgonUtil.isEmpty(addressView.getProvincia()) ? addressView.getProvincia() : "");
			final String egonProvincia = egonAddressView.getProvincia();
			final Boolean valid = (compare(provinciaNome, egonProvincia) ==0) ? Boolean.TRUE :Boolean.FALSE ;
			if (!valid) {
				final IProvinciaView provinciaView = new AnagrafeHandler().getProvinciaViewForSigla(egonProvincia);
				addressView.setProvinciaView(provinciaView);
			}
		}  catch (RemoteException e) {
			log4Debug.severeStackTrace(e);
			throw new AddressException(e.getMessage());
		} catch (SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		}
	}

	private void setCitta(final EgonAddressView egonAddressView, final AddressView addressView) throws AddressException {
		try {
			final String citta = !EgonUtil.isNull(addressView.getCittaView()) ? addressView.getCittaView().getCommune() : (!EgonUtil.isEmpty(addressView.getCitta()) ? addressView.getCitta() :"");
			final String egonCittaName = egonAddressView.getCitta();
			final Boolean valid = (compare(citta, egonCittaName) ==0) ? Boolean.TRUE :Boolean.FALSE ;
			if (!valid) {
				final ICittaView cittaView = new AnagrafeHandler().getCitta(egonCittaName, egonAddressView.getProvinciaSingla());
				addressView.setCittaView(cittaView);
			}
		}  catch (RemoteException e) {
			log4Debug.severeStackTrace(e);
			throw new AddressException(e.getMessage());
		} catch (SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		}
	}
}