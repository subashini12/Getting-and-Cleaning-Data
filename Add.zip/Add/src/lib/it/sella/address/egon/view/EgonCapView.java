package it.sella.address.egon.view;

import java.io.Serializable;

public class EgonCapView implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private String capCode;

	public String getCapCode() {
		return capCode;
	}

	public void setCapCode(final String capCode) {
		this.capCode = capCode;
	}
}
