package it.sella.address.egon.common;

import it.sella.address.AddressException;
import it.sella.address.implementation.AddressManagerBean;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Map;

public enum ReflectionAPIUtil {

	INSTANCE, ;
	private ReflectionAPIUtil() {
	}

	private static final Log4Debug log4Debug = Log4DebugFactory
			.getLog4Debug(AddressManagerBean.class);

	public Object invokeSetMethod(final Map<String, Object> map,
			final String className) throws AddressException {
		Object classObj = null;
		try {
			Class<?> cls = Class.forName(className);
			Class<?>[] paramVarArgs = new Class[1];
			classObj = cls.newInstance();
			for (final Map.Entry<String, Object> entry : map.entrySet()) {
				if (!EgonUtil.isNull(entry.getValue())) {
				paramVarArgs[0] = entry.getValue().getClass();
				Method method = cls.getDeclaredMethod(
						"set".concat(entry.getKey()), paramVarArgs);
				method.setAccessible(true);
				method.invoke(classObj, entry.getValue());
				}
			}
		} catch (RuntimeException runEx) {
			log4Debug.debug(runEx.getMessage());
			throw new AddressException(runEx);
		} catch (IllegalAccessException illException) {
			log4Debug.debug(illException.getMessage());
			throw new AddressException(illException);
		} catch (InvocationTargetException targetEx) {
			log4Debug.debug(targetEx.getMessage());
			throw new AddressException(targetEx);
		} catch (NoSuchMethodException noSuchMethodExecption) {
			log4Debug.debug(noSuchMethodExecption.getMessage());
			throw new AddressException(noSuchMethodExecption);
		} catch (ClassNotFoundException classNotFoundExecption) {
			log4Debug.debug(classNotFoundExecption.getMessage());
			throw new AddressException(classNotFoundExecption);
		} catch (InstantiationException insException) {
			log4Debug.debug(insException.getMessage());
			throw new AddressException(insException);
		}
		return classObj;
	}

	@SuppressWarnings("unchecked")
	public <T> Collection<T> invokeGetMethod(final Object className,
			final Collection<T> result, final String[] fieldName)
			throws AddressException {
		try {
			Class<?> cls = className.getClass();
			for (int i = 0; i < fieldName.length; i++) {
				Field strField = cls.getDeclaredField(fieldName[0]);
				strField.setAccessible(true);
				Object value = strField.get(className);
				if (!EgonUtil.isNull(value)) {
					result.add((T) value);
				}
			}
		} catch (RuntimeException runEx) {
			log4Debug.debug(runEx.getMessage());
			throw new AddressException(runEx);
		} catch (IllegalAccessException illException) {
			log4Debug.debug(illException.getMessage());
			throw new AddressException(illException);
		}  catch (NoSuchFieldException noSuchFieldEx) {
			log4Debug.debug(noSuchFieldEx.getMessage());
			throw new AddressException(noSuchFieldEx);
		}
		return result;
	}

	public <T> Object getInstance(final String className) throws AddressException {
		try {
			return Class.forName(className).newInstance();
		} catch (InstantiationException insEx) {
			insEx.printStackTrace();
			log4Debug.debug(insEx.getMessage());
			throw new AddressException(insEx);
		} catch (IllegalAccessException illAccExecption) {
			log4Debug.debug(illAccExecption.getMessage());
			throw new AddressException(illAccExecption);
		} catch (ClassNotFoundException classNotFoundEx) {
			log4Debug.debug(classNotFoundEx.getMessage());
			throw new AddressException(classNotFoundEx);
		}
	}

}
