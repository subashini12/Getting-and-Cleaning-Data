package it.sella.address.egon.common;

import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.address.egon.view.EgonAddressView;

public abstract class AddressAbstractTransformer<T extends AddressView,U extends EgonAddressView,ReturnType extends AddressView> {

	/**
	 * Entity are the elements making up each "element" of the given result. The contract here is to
	 * transform these elements into the final application-visible result.
	 *
	 * @param entityType
	 * @param entityType1
	 * @return ReturnType
	 * @throws AddressException
	 */
	public abstract ReturnType transform(final T entityType,final U entityType1) throws AddressException;


}
