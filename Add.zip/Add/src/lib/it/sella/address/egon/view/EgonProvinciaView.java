package it.sella.address.egon.view;

import java.io.Serializable;

public class EgonProvinciaView implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;


	public String getProvinciaNome() {
		return provinciaNome;
	}
	public void setProvinciaNome(final String provinciaNome) {
		this.provinciaNome = provinciaNome;
	}
	public String getProvinciaSigla() {
		return provinciaSigla;
	}
	public void setProvinciaSigla(final String provinciaSigla) {
		this.provinciaSigla = provinciaSigla;
	}

	private String provinciaNome;
	private String provinciaSigla;

}
