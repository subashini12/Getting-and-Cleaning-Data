package it.sella.address.egon.dao;

import java.util.Map;
import java.util.WeakHashMap;

import it.sella.address.AddressException;
import it.sella.address.egon.common.EgonAPIClassNameConstants;
import it.sella.address.egon.common.EgonParConstant;
import it.sella.address.egon.common.EgonParValueConstant;
import it.sella.address.egon.common.EgonUtil;
import it.sella.address.egon.common.ReflectionAPIUtil;
import it.wareplace.www.services.it.EgonWpIta4Suite.CDPPLC;
import it.wareplace.www.services.it.EgonWpIta4Suite.CDPSTR;
import it.wareplace.www.services.it.EgonWpIta4Suite.CIVICO;
import it.wareplace.www.services.it.EgonWpIta4Suite.COO_626;
import it.wareplace.www.services.it.EgonWpIta4Suite.DSXPLC;
import it.wareplace.www.services.it.EgonWpIta4Suite.DSXSTRINP;
import it.wareplace.www.services.it.EgonWpIta4Suite.DSXSTROUT;
import it.wareplace.www.services.it.EgonWpIta4Suite.ELECLI;
import it.wareplace.www.services.it.EgonWpIta4Suite.ERR_620_ELE;
import it.wareplace.www.services.it.EgonWpIta4Suite.INR_020;
import it.wareplace.www.services.it.EgonWpIta4Suite.INR_620;
import it.wareplace.www.services.it.EgonWpIta4Suite.KII;
import it.wareplace.www.services.it.EgonWpIta4Suite.KIO;
import it.wareplace.www.services.it.EgonWpIta4Suite.LNGCDP;
import it.wareplace.www.services.it.EgonWpIta4Suite.LOCNAS;
import it.wareplace.www.services.it.EgonWpIta4Suite.MCZ_627;
import it.wareplace.www.services.it.EgonWpIta4Suite.PAR;
import it.wareplace.www.services.it.EgonWpIta4Suite.RGS_010;
import it.wareplace.www.services.it.EgonWpIta4Suite.RGS_610;
import it.wareplace.www.services.it.EgonWpIta4Suite.SEG;
import it.wareplace.www.services.it.EgonWpIta4Suite.SEZ_ERR;
import it.wareplace.www.services.it.EgonWpIta4Suite.SOG;
import it.wareplace.www.services.it.EgonWpIta4Suite.STROUTELE;
import it.wareplace.www.services.it.EgonWpIta4Suite.WPFGO;

import org.apache.axis.types.UnsignedShort;

public abstract class EgonNormalisationParam {

	protected WPFGO setInitialParams(final WPFGO normInput) throws AddressException
	{
		normInput.setSOG(new SOG[1]);

		final SOG pSog = (SOG) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.SOG.getValue());
		normInput.setSOG(0, pSog);

		normInput.getSOG(0).setPAR((PAR) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.PAR.getValue()));

		normInput.getSOG(0).setRGS_010((RGS_010) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.RGS_010.getValue()));

		normInput.getSOG(0).setINR_020((INR_020) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.INR_020.getValue()));

		normInput.getSOG(0).setRGS_610((RGS_610) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.RGS_610.getValue()));

		normInput.getSOG(0).setINR_620((INR_620) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.INR_620.getValue()));

		normInput.getSOG(0).getINR_620().setDSXPLCUFF((DSXPLC) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.DSXPLC.getValue()));

		normInput.getSOG(0).getINR_620().setDSXSTRUFF((DSXSTROUT) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.DSXSTROUT.getValue()));

		normInput.getSOG(0).getINR_620().getDSXSTRUFF().setDSXST1((STROUTELE) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.STROUTELE.getValue()));

		normInput.getSOG(0).getINR_620().setDSXPLCSIG((DSXPLC) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.DSXPLC.getValue()));

		normInput.getSOG(0).getINR_620().setDSXPLCUFF((DSXPLC) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.DSXPLC.getValue()));

		normInput.getSOG(0).getINR_620().setCIVICOST1((CIVICO) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.CIVICO.getValue()));

		normInput.getSOG(0).getINR_620().setDSXLPOUFF((DSXPLC) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.DSXPLC.getValue()));

		normInput.getSOG(0).getINR_620().setLNGPLCCNY((LNGCDP) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.LNGCDP.getValue()));

		normInput.getSOG(0).getINR_620().setCDPLPOOBJ((CDPPLC) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.CDPPLC.getValue()));

		normInput.getSOG(0).getINR_620().setCDPPLCOBJ((CDPPLC) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.CDPPLC.getValue()));

		normInput.getSOG(0).getINR_620().setCDPSTRST1((CDPSTR) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.CDPSTR.getValue()));

		normInput.getSOG(0).getINR_020().setDSXPLC((DSXPLC) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.DSXPLC.getValue()));

		normInput.getSOG(0).getINR_020().setDSXST1((DSXSTRINP) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.DSXSTRINP.getValue()));

		normInput.getSOG(0).setCOO_626((COO_626) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.COO_626.getValue()));

		normInput.getSOG(0).setMCZ_627((MCZ_627) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.MCZ_627.getValue()));

		normInput.getSOG(0).setKII((KII) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.KII.getValue()));

		normInput.getSOG(0).setKIO((KIO) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.KIO.getValue()));

		normInput.getSOG(0).setSEG((SEG) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.SEG.getValue()));

		normInput.getSOG(0).getSEG().setERR_GEO_ELE(new SEZ_ERR[6]);
		for (int i = 0; i < 6; i++) {
			normInput.getSOG(0).getSEG().setERR_GEO_ELE(i, (SEZ_ERR) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.SEZ_ERR.getValue()));
			normInput.getSOG(0).getSEG().getERR_GEO_ELE(i).setCDPSEG(new UnsignedShort(0L));
			normInput.getSOG(0).getSEG().getERR_GEO_ELE(i).setFLXSEG("");
			normInput.getSOG(0).getSEG().getERR_GEO_ELE(i).setDSXSEG("");
		}

		normInput.getSOG(0).getSEG().setERR_620_ELE((ERR_620_ELE) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.ERR_620_ELE.getValue()));

		normInput.getSOG(0).getSEG().getERR_620_ELE().setERR_620(new SEZ_ERR[2]);
		for (int i = 0; i < 2; i++) {
			normInput.getSOG(0).getSEG().getERR_620_ELE().setERR_620(i, (SEZ_ERR) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.SEZ_ERR.getValue()));
			normInput.getSOG(0).getSEG().getERR_620_ELE().getERR_620(i).setFLXSEG("");
		}

		normInput.getSOG(0).getSEG().setERR_KIO_ELE(new SEZ_ERR[1]);
		normInput.getSOG(0).getSEG().setERR_KIO_ELE(0, (SEZ_ERR) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.SEZ_ERR.getValue()));
		normInput.getSOG(0).getSEG().getERR_KIO_ELE(0).setFLXSEG("");

		normInput.getSOG(0).getSEG().setERR_610_ELE(new SEZ_ERR[2]);
		for (int i = 0; i < 2; i++) {
			normInput.getSOG(0).getSEG().setERR_610_ELE(i, (SEZ_ERR) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.SEZ_ERR.getValue()));
			normInput.getSOG(0).getSEG().getERR_610_ELE(i).setFLXSEG("");
		}

		normInput.getSOG(0).getKIO().setFLXDOP("");
		normInput.getSOG(0).getKIO().setELECLI((ELECLI) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.ELECLI.getValue()));

		normInput.getSOG(0).setRGS_010(EgonUtil.isNull(normInput.getSOG(0).getRGS_010()) ? (RGS_010) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.RGS_010.getValue()) : normInput.getSOG(0).getRGS_010());


		normInput.getSOG(0).getRGS_010().setLOCNAS(EgonUtil.isNull(normInput.getSOG(0).getRGS_010().getLOCNAS()) ? (LOCNAS) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.LOCNAS.getValue()) : normInput.getSOG(0).getRGS_010().getLOCNAS());

		normInput.getSOG(0).getRGS_010().getLOCNAS().setDSXPLCNAS( EgonUtil.isNull(normInput.getSOG(0).getRGS_010().getLOCNAS().getDSXPLCNAS()) ? (DSXPLC) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.DSXPLC.getValue()) : normInput.getSOG(0).getRGS_010().getLOCNAS().getDSXPLCNAS());

		return normInput;
	}

	protected Map<String, Object> setEgonInitParams() throws AddressException {
		final Map<String, Object> initialParamMap = new WeakHashMap<String, Object>();
		initialParamMap.put(EgonParConstant.INDRES.getValue(),EgonParValueConstant.INDRES.getValue());
		initialParamMap.put(EgonParConstant.CDXISO.getValue(),EgonParValueConstant.ITA.getValue());
		initialParamMap.put(EgonParConstant.WPPASW.getValue(),EgonParValueConstant.WPPASW.getValue());
		initialParamMap.put(EgonParConstant.WPUSER.getValue(),EgonParValueConstant.WPUSER.getValue());
		return initialParamMap;
	}


}
