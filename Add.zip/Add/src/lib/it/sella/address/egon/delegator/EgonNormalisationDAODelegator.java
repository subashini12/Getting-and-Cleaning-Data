package it.sella.address.egon.delegator;

import it.sella.address.AddressException;
import it.sella.address.egon.common.AddressBeanUtil;
import it.sella.address.egon.common.EgonAddressBeanConstant;
import it.sella.address.egon.dao.INormalisationDAO;
import it.sella.address.egon.view.EgonAddressView;

public class EgonNormalisationDAODelegator {

	public EgonAddressView normalisation(final String nazione,final String citta,final String indirrizzo,final String provincia,final String cap,final String edifico,final String presso) throws AddressException {
		final EgonAddressView normalisationView = new EgonAddressView();
    	normalisationView.setCap(cap);
		normalisationView.setCitta(citta);
		normalisationView.setProvincia(provincia);
		normalisationView.setIndirizzo(indirrizzo);
		normalisationView.setEdificio(edifico);
		normalisationView.setPresso(presso);
		return getNormalisationDAO().normalisation(normalisationView);
	}
	private INormalisationDAO getNormalisationDAO() {
		return (INormalisationDAO) AddressBeanUtil.getInstance().getBean(EgonAddressBeanConstant.NORMALISATION_DAO.getBeanId());
	}
}
