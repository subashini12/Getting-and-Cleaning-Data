package it.sella.address.egon.transformer;

import it.sella.address.AddressException;
import it.sella.address.egon.common.EgonAbstractTransformer;
import it.sella.address.egon.common.EgonUtil;
import it.sella.address.egon.common.EgonViewNameConstant;
import it.sella.address.egon.common.ReflectionAPIUtil;
import it.sella.address.egon.view.EgonCapView;
import it.sella.address.egon.view.EgonCittaView;
import it.sella.address.egon.view.EgonIndrizziView;
import it.sella.address.egon.view.EgonView;
import it.wareplace.www.services.it.EgonWpIta4Lst.LSTSTR_OUT;
import it.wareplace.www.services.it.EgonWpIta4Lst.STR;

import java.util.ArrayList;
import java.util.Collection;

public class EgonIndrizziViewTransformer extends EgonAbstractTransformer<LSTSTR_OUT, Collection<EgonView>>{

	public Collection<EgonView> transform(final LSTSTR_OUT streetOutput) throws AddressException {
		final Collection<EgonView> streetCollection = new ArrayList<EgonView>();
		if (!EgonUtil.isNull(streetOutput.getSTR_AREA_OUT())) {
			for (int i = 0; i < streetOutput.getSTR_AREA_OUT().getNR9STR().intValue(); i++) {
				final STR street = streetOutput.getSTR_AREA_OUT().getSTR(i);
				final EgonIndrizziView egonIndrizziView = (EgonIndrizziView) ReflectionAPIUtil.INSTANCE.getInstance(EgonViewNameConstant.EGON_INDRIZZI_VIEW.getValue());
				final EgonView egonView = (EgonView) ReflectionAPIUtil.INSTANCE.getInstance(EgonViewNameConstant.EGON_VIEW.getValue());
				final EgonCittaView egonCittaView = (EgonCittaView) ReflectionAPIUtil.INSTANCE.getInstance(EgonViewNameConstant.CITTA_VIEW.getValue());
				final EgonCapView egonCapView = (EgonCapView) ReflectionAPIUtil.INSTANCE.getInstance(EgonViewNameConstant.CAP_VIEW.getValue());
				egonCapView.setCapCode(street.getCDXZIP());
				egonView.setCap(egonCapView);
				egonIndrizziView.setIndrizzi(street.getDSXOBJSTR());
				egonView.setIndrizzi(egonIndrizziView);
				egonCittaView.setCittaNome(street.getDSXOBJDPT());
				egonView.setCitta(egonCittaView);
				streetCollection.add(egonView);
			}
		}
		return streetCollection;
	}

}
