package it.sella.address.egon.dao;

public enum QueryConstants {

	VALIDATE_CITTA_BY_COMMUNE("ValidateCittaByCommune"),
	VALIDATE_PROVINCIA_BY_SIGLA("ValidateProvinciaBySigla"),
	VALIDATE_PROVINCIA_BY_SIGLA_AND_COMMUNE("ValidateProvinciaBySiglaAndCommune"),
	VALIDATE_CITTA_FOR_PROVINCIA("ValidateCittaForProvincia"),
	VALIDATE_CAP_FOR_PROVINCIA("ValidateCapForProvincia"),
	GET_ALL_NAZIONE_NOMES("GetNazioneNomesFromEgon"),
	GET_ALL_CITTA_NOMES("GetCapandProvinciaFromEgon"),
	;


	private String value;

	/**
	 * Instantiates a new constant.
	 *
	 * @param value the value
	 */
	private QueryConstants(final String value){
		this.value = value;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public String getValue() {
		return this.value;
	}

}
