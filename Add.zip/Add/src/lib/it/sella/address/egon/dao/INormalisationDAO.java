package it.sella.address.egon.dao;

import it.sella.address.AddressException;
import it.sella.address.egon.view.EgonAddressView;

public abstract class INormalisationDAO extends EgonNormalisationParam {
	public abstract EgonAddressView normalisation(final EgonAddressView normalisationView) throws AddressException;

}
