package it.sella.address.egon.dao.implementation;

import it.sella.address.AddressException;
import it.sella.address.egon.common.EgonAPIClassNameConstants;
import it.sella.address.egon.common.EgonAbstractTransformer;
import it.sella.address.egon.common.EgonTransformerConstant;
import it.sella.address.egon.common.ReflectionAPIUtil;
import it.sella.address.egon.dao.ICapDAO;
import it.sella.address.egon.view.EgonView;
import it.sella.address.implementation.util.DBHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;
import it.wareplace.www.services.it.EgonWpIta4Lst.LSTPAR;
import it.wareplace.www.services.it.EgonWpIta4Lst.LSTZIP_INP;
import it.wareplace.www.services.it.EgonWpIta4Lst.LSTZIP_OUT;
import it.wareplace.www.services.it.EgonWpIta4Lst.ZIP_AREA_INP;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import org.apache.axis.types.UnsignedShort;

import WpIta4.wpWs.RWJWLST0;

public class CapDAOImpl extends ICapDAO{

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CapDAOImpl.class);

	private void setCapInputParams(final LSTZIP_INP inp) throws AddressException {
		inp.setLSTPAR((LSTPAR) ReflectionAPIUtil.INSTANCE.invokeSetMethod(setEgonInitParams(),
				EgonAPIClassNameConstants.LSTPAR.getValue()));

	}

	private void setCapAreaInput(final Map<String, Object> map,
			final LSTZIP_INP inp) throws AddressException {
		inp.setZIP_AREA_INP((ZIP_AREA_INP) ReflectionAPIUtil.INSTANCE
				.invokeSetMethod(map,
						EgonAPIClassNameConstants.ZIP_AREA_INP.getValue()));
	}

	@SuppressWarnings("unchecked")
	public Collection<EgonView> getCap(final Map<String, Object> map) throws AddressException {
		Connection connection = null;
		Collection<EgonView> zipCollection = new ArrayList<EgonView>();
		try {
			final RWJWLST0 lst = (RWJWLST0) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.API_CLASS_NAME.getValue());

			final LSTZIP_INP capInput = (LSTZIP_INP) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.LSTZIP_INP.getValue());
			setCapInputParams(capInput);
			setCapAreaInput(map, capInput);
			capInput.getZIP_AREA_INP().setMAXLIVLOC(new UnsignedShort(5L));

			connection = DBHelper.getConnection();
			final LSTZIP_OUT capOutput = lst.wpLstZip(capInput,connection);
			final EgonAbstractTransformer<LSTZIP_OUT , Collection<EgonView>>  transformer =(EgonAbstractTransformer<LSTZIP_OUT, Collection<EgonView>>) ReflectionAPIUtil.INSTANCE
					.getInstance(EgonTransformerConstant.CAP_TRANSFORMER.getValue());
			zipCollection = transformer.transform(capOutput);

		} catch (final SQLException sqlEx) {
			log4Debug.severeStackTrace(sqlEx);
			throw new AddressException(sqlEx.getMessage(), sqlEx);
		} catch (final RuntimeException runTimeEx) {
			log4Debug.severeStackTrace(runTimeEx);
			throw new AddressException(runTimeEx.getMessage(), runTimeEx);
		} finally {
			DBHelper.closeConnection(connection);
		}
		return zipCollection;
	}
}
