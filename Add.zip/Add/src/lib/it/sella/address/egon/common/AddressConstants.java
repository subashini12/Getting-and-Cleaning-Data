package it.sella.address.egon.common;

public enum AddressConstants {

	ADDRESS_PROPERTY("Address");

	private String value;

	/**
	 * Instantiates a new constant.
	 *
	 * @param value the value
	 */
	private AddressConstants(final String value){
		this.value = value;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public String getValue() {
		return this.value;
	}


}
