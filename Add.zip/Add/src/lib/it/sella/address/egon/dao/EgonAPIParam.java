package it.sella.address.egon.dao;

import it.sella.address.AddressException;
import it.sella.address.egon.common.EgonParConstant;
import it.sella.address.egon.common.EgonParValueConstant;

import java.util.Map;
import java.util.WeakHashMap;

public abstract class EgonAPIParam {
	protected Map<String, Object> setEgonInitParams() throws AddressException {
		Map<String, Object> map = new WeakHashMap<String, Object>();
		map.put(EgonParConstant.CDXISO.getValue(),EgonParValueConstant.ITA.getValue());
		map.put(EgonParConstant.WPPASW.getValue(),EgonParValueConstant.WPPASW.getValue());
		map.put(EgonParConstant.WPUSER.getValue(),EgonParValueConstant.WPUSER.getValue());
		return map;
	}
}
