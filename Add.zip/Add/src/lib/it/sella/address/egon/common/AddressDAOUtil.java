package it.sella.address.egon.common;

import it.sella.address.egon.dao.IJDBCTemplateDAO;
import it.sella.util.CommonProperties;
import it.sella.util.CommonPropertiesFactory;

public class AddressDAOUtil {

	public static IJDBCTemplateDAO getJdbcTemplateInstance(){
		return (IJDBCTemplateDAO)AddressBeanUtil.getInstance().getBean(EgonAddressBeanConstant.GET_JDBC_TEMPLATE.getBeanId());
	}

	public static CommonProperties getCommonProperties() {
		return CommonPropertiesFactory.getInstance().getCommonProperties(AddressConstants.ADDRESS_PROPERTY.getValue());
	}

}
