package it.sella.address.egon.common;

public enum EgonViewNameConstant {


		//Common
		CAP_VIEW("it.sella.address.egon.view.EgonCapView"),
		NAZIONE_VIEW("it.sella.address.egon.view.EgonNazioneView"),
		PROVINCIA_VIEW("it.sella.address.egon.view.EgonProvinciaView"),
		CITTA_VIEW("it.sella.address.egon.view.EgonCittaView"),
		EGON_VIEW("it.sella.address.egon.view.EgonView"),
		EGON_INDRIZZI_VIEW("it.sella.address.egon.view.EgonIndrizziView"),



		;

		private String value;

		/**
		 * Instantiates a new constant.
		 *
		 * @param value the value
		 */
		private EgonViewNameConstant(final String value){
			this.value = value;
		}

		/**
		 * Gets the value.
		 *
		 * @return the value
		 */
		public String getValue() {
			return this.value;
		}

}
