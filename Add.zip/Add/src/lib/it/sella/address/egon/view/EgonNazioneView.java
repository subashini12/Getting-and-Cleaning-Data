package it.sella.address.egon.view;

import java.io.Serializable;

public class EgonNazioneView implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String nazioneNome;

	public String getNazioneNome() {
		return nazioneNome;
	}
	public void setNazioneNome(final String nazioneNome) {
		this.nazioneNome = nazioneNome;
	}
}
