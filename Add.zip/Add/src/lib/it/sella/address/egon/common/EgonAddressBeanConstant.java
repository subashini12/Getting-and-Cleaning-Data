package it.sella.address.egon.common;


public enum EgonAddressBeanConstant {

	NAZIONE_DAO("INazioneDAO"),
	CITTA_DAO("ICittaDAO"),
	PROVINCIA_DAO("IProvinciaDAO"),
	GET_JDBC_TEMPLATE("jdbcTemplateDAO"),
	CAP_DAO("ICapDAO"),
	ANAGRAFE_HANDLER("AnagrafeHandler"),
	CLASSIFICAZIONE_HANDLER("ClassificazioneHandler"),
	SECURITY_HANDLER("SecurityHandler"),
	INDIRIZZI_DAO("IIndirizziDAO"),
	EGON_CAP_DAO_DELEGATOR("EgonCapDAODelegator"),
	EGON_CITTA_DAO_DELEGATOR("EgonCittaDAODelegator"),
	EGON_PROVINCIA_DAO_DELEGATOR("EgonProvinciaDAODelegator"),
	NORMALISATION_DAO("INormalisationDAO"),
	EGON_NORMALISATION_DAO_DELEGATOR("EgonNormalisationDAODelegator"),
	EGON_INDIRIZZI_DAO_DELEGATOR("EgonIndirizziDAODelegator"),
	EGON_NAZIONE_DAO_DELEGATOR("EgonNazioneDAODelegator"),
	;

	private String beanId;

	/**
	 * Instantiates a new constant.
	 *
	 * @param value the value
	 */
	private EgonAddressBeanConstant(final String beanId){
		this.beanId = beanId;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public String getBeanId() {
		return this.beanId;
	}
}
