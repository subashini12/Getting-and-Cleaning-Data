package it.sella.address.egon.dao;

import java.util.List;

import org.springframework.jdbc.core.RowMapper;

public interface IJDBCTemplateDAO {


	public <T> T queryForObject(final String sql,final Object[] params,final Class<T> requiredType);

	<T> List<T> queryListWithNoInput(final String sql,final RowMapper<T> rowMapper);

	public <T> List<T> queryForListWithParameter(final String sql,final Object[] params,final RowMapper<T> rowMapper) ;

	public long queryForLong(final String sql,final Object[] params);

	public <T> List<T> queryListWithInput(String sql, final Object[] params,final Class<T> requiredType);

}