package it.sella.address.egon.view;

import java.io.Serializable;

public class EgonIndrizziView implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private String indrizzi;

	public String getIndrizzi() {
		return indrizzi;
	}

	public void setIndrizzi(final String indrizzi) {
		this.indrizzi = indrizzi;
	}



}
