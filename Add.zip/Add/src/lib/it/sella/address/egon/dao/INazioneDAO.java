package it.sella.address.egon.dao;

import it.sella.address.AddressException;
import it.sella.address.egon.view.EgonView;

import java.util.List;


public abstract class INazioneDAO {
	public abstract List<EgonView> getNazione(final String nazione) throws AddressException;
}
