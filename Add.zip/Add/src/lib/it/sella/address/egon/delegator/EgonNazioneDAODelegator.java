package it.sella.address.egon.delegator;

import it.sella.address.AddressException;
import it.sella.address.egon.common.AddressBeanUtil;
import it.sella.address.egon.common.EgonAddressBeanConstant;
import it.sella.address.egon.common.EgonUtil;
import it.sella.address.egon.dao.INazioneDAO;
import it.sella.address.egon.view.EgonView;

import java.util.ArrayList;
import java.util.Collection;

public class EgonNazioneDAODelegator {

	public Collection<EgonView> getNazione(final String nazione) throws AddressException {
		Collection<EgonView> egonViews = new ArrayList<EgonView>();
		if (!EgonUtil.isEmpty(nazione) ) {
			egonViews = getNazioneDAO().getNazione(nazione);
		}
		return egonViews;
	}

	private INazioneDAO getNazioneDAO() {
		return (INazioneDAO)AddressBeanUtil.getInstance().getBean(EgonAddressBeanConstant.NAZIONE_DAO.getBeanId());
	}

}
