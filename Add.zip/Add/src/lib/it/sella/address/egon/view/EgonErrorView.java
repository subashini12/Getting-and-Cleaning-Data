package it.sella.address.egon.view;

import java.io.Serializable;

public class EgonErrorView implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String errorFlag;
	private String errorDescription;
	/**
	 * @return the errorFlag
	 */
	public String getErrorFlag() {
		return errorFlag;
	}
	/**
	 * @param errorFlag the errorFlag to set
	 */
	public void setErrorFlag(final String errorFlag) {
		this.errorFlag = errorFlag;
	}
	/**
	 * @return the errorDescription
	 */
	public String getErrorDescription() {
		return errorDescription;
	}
	/**
	 * @param errorDescription the errorDescription to set
	 */
	public void setErrorDescription(final String errorDescription) {
		this.errorDescription = errorDescription;
	}





}
