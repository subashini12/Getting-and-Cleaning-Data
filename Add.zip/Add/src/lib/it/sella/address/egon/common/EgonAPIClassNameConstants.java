package it.sella.address.egon.common;


public enum EgonAPIClassNameConstants {

	//Common
	LSTPAR("it.wareplace.www.services.it.EgonWpIta4Lst.LSTPAR"),

	//street
	STR_AREA_INP("it.wareplace.www.services.it.EgonWpIta4Lst.STR_AREA_INP"),
	LSTSTR_INP("it.wareplace.www.services.it.EgonWpIta4Lst.LSTSTR_INP"),
	//API name
	API_CLASS_NAME("WpIta4.wpWs.RWJWLST0"),


	//provincia
	DPT_AREA_INP("it.wareplace.www.services.it.EgonWpIta4Lst.DPT_AREA_INP"),
	LSTDPT_INP("it.wareplace.www.services.it.EgonWpIta4Lst.LSTDPT_INP"),

	//citta
	CNL_AREA_INP("it.wareplace.www.services.it.EgonWpIta4Lst.CNL_AREA_INP"),
	LSTCNL_INP("it.wareplace.www.services.it.EgonWpIta4Lst.LSTCNL_INP"),

	//state
	STA_AREA_INP("it.wareplace.www.services.it.EgonWpIta4Lst.STA_AREA_INP"),
	LSTSTA_INP("it.wareplace.www.services.it.EgonWpIta4Lst.LSTSTA_INP"),

	//cap
	ZIP_AREA_INP("it.wareplace.www.services.it.EgonWpIta4Lst.ZIP_AREA_INP"),
	LSTZIP_INP("it.wareplace.www.services.it.EgonWpIta4Lst.LSTZIP_INP"),

	//Normalisation
	PAR("it.wareplace.www.services.it.EgonWpIta4Suite.PAR"),
	SOG("it.wareplace.www.services.it.EgonWpIta4Suite.SOG"),
	WPFGO("it.wareplace.www.services.it.EgonWpIta4Suite.WPFGO"),
	RGS_010("it.wareplace.www.services.it.EgonWpIta4Suite.RGS_010"),
	INR_020("it.wareplace.www.services.it.EgonWpIta4Suite.INR_020"),
	RGS_610("it.wareplace.www.services.it.EgonWpIta4Suite.RGS_610"),
	INR_620("it.wareplace.www.services.it.EgonWpIta4Suite.INR_620"),
	DSXPLC("it.wareplace.www.services.it.EgonWpIta4Suite.DSXPLC"),
	DSXSTRINP("it.wareplace.www.services.it.EgonWpIta4Suite.DSXSTRINP"),
	COO_626("it.wareplace.www.services.it.EgonWpIta4Suite.COO_626"),
	MCZ_627("it.wareplace.www.services.it.EgonWpIta4Suite.MCZ_627"),
	KII("it.wareplace.www.services.it.EgonWpIta4Suite.KII"),
	KIO("it.wareplace.www.services.it.EgonWpIta4Suite.KIO"),
	SEG("it.wareplace.www.services.it.EgonWpIta4Suite.SEG"),
	SEZ_ERR("it.wareplace.www.services.it.EgonWpIta4Suite.SEZ_ERR"),
	ERR_620_ELE("it.wareplace.www.services.it.EgonWpIta4Suite.ERR_620_ELE"),
	ELECLI("it.wareplace.www.services.it.EgonWpIta4Suite.ELECLI"),
	LOCNAS("it.wareplace.www.services.it.EgonWpIta4Suite.LOCNAS"),
	ALTRO_620("it.wareplace.www.services.it.EgonWpIta4Suite.ALTRO_620"),
	DSXSTROUT("it.wareplace.www.services.it.EgonWpIta4Suite.DSXSTROUT"),
	STROUTELE("it.wareplace.www.services.it.EgonWpIta4Suite.STROUTELE"),
	CIVICO("it.wareplace.www.services.it.EgonWpIta4Suite.CIVICO"),
	LNGCDP("it.wareplace.www.services.it.EgonWpIta4Suite.LNGCDP"),
	CDPPLC("it.wareplace.www.services.it.EgonWpIta4Suite.CDPPLC"),
	CDPSTR("it.wareplace.www.services.it.EgonWpIta4Suite.CDPSTR"),

	//ENQ,LST
	MIA("it.wareplace.www.services.it.EgonWpIta4Suite.MIA"),
	TAB_MIA("it.wareplace.www.services.it.EgonWpIta4Suite.TAB_MIA"),
	PAR_MIA("it.wareplace.www.services.it.EgonWpIta4Gia.PAR"),
	ERR("it.wareplace.www.services.it.EgonWpIta4Gia.ERR"),
	WPFGI("it.wareplace.www.services.it.EgonWpIta4Gia.WPFGI"),
	API_CLASS_ENQ_LST("WpIta4.wpWs.RWJWGIA"),


	API_CLASS_NAME_NORMLISATION("WpIta4.wpWs.RWJWFGO5")

	;

	private String value;

	/**
	 * Instantiates a new constant.
	 *
	 * @param value the value
	 */
	private EgonAPIClassNameConstants(final String value){
		this.value = value;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public String getValue() {
		return this.value;
	}


}
