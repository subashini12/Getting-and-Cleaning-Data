package it.sella.address.egon.transformer;

import it.sella.address.AddressException;
import it.sella.address.egon.common.EgonAbstractTransformer;
import it.sella.address.egon.common.EgonUtil;
import it.sella.address.egon.view.EgonErrorView;
import it.sella.address.egon.view.EgonAddressView;
import it.wareplace.www.services.it.EgonWpIta4Suite.SEZ_ERR;
import it.wareplace.www.services.it.EgonWpIta4Suite.WPFGO;

import java.util.ArrayList;
import java.util.List;

public class EgonNormalisationTransformer extends EgonAbstractTransformer<WPFGO, EgonAddressView>{

	@Override
	public EgonAddressView transform(final WPFGO output) throws AddressException {
		final EgonAddressView egonNormalisationView = new EgonAddressView();
		egonNormalisationView.setNazione(output.getSOG(0).getINR_620().getDSXPLCUFF().getDSXCNY());//Nazione-DSXCNY
		egonNormalisationView.setProvincia(output.getSOG(0).getINR_620().getDSXPLCUFF().getDSXDPT());
		egonNormalisationView.setProvinciaSingla(output.getSOG(0).getINR_620().getDSXPLCSIG().getDSXDPT());
		egonNormalisationView.setCitta(output.getSOG(0).getINR_620().getDSXPLCUFF().getDSXCNL());
		egonNormalisationView.setCap(output.getSOG(0).getINR_620().getCDXZIP());
		egonNormalisationView.setIndirizzo(output.getSOG(0).getINR_620().getDSXSTRUFF().getDSXADD());
		egonNormalisationView.setPresso(output.getSOG(0).getINR_620().getALTRO().getDSXPREINR());

		final SEZ_ERR[] errOutput = output.getSOG(0).getSEG().getERR_620_ELE().getERR_620();

		List<EgonErrorView> warningErrorView = null;
		List<EgonErrorView> failureErrorView = null;
		if (!EgonUtil.isNull(errOutput)) {
			failureErrorView = new ArrayList<EgonErrorView>();
			warningErrorView = new ArrayList<EgonErrorView>();
			for (int i = 0; i < errOutput.length; i++)
			{
				if (Integer.valueOf(errOutput[i].getFLXSEG()) > 1) {
					final EgonErrorView error = new EgonErrorView();
					error.setErrorFlag(errOutput[i].getFLXSEG());
					error.setErrorDescription(String.valueOf(errOutput[i].getDSXSEG()));
					failureErrorView.add(error);
				} else if (Integer.valueOf(errOutput[i].getFLXSEG()) !=0) {
					final EgonErrorView error = new EgonErrorView();
					error.setErrorFlag(errOutput[i].getFLXSEG());
					error.setErrorDescription(String.valueOf(errOutput[i].getDSXSEG()));
					warningErrorView.add(error);
				}

			}
			if (!EgonUtil.isListEmpty(failureErrorView)) {
				egonNormalisationView.setFailureMessage(failureErrorView);
				egonNormalisationView.setNormalisationFailure(Boolean.TRUE);
			} else {
				egonNormalisationView.setNormalisationSuccess(Boolean.TRUE);
			}

			if (!EgonUtil.isListEmpty(warningErrorView)) {
				egonNormalisationView.setWarningMessage(warningErrorView);
			}
		}
		return egonNormalisationView;
	}

}
