package it.sella.address.egon.common;

import java.util.Collection;
import java.util.Map;

import org.apache.commons.beanutils.converters.LongConverter;
import org.apache.commons.beanutils.converters.StringConverter;
import org.apache.commons.lang.StringUtils;

public class EgonUtil {
	public static Boolean isEmpty(final String value) {
		return StringUtils.isEmpty(!isNull(value) ? value.trim():"");
	}

	public static Boolean isNull(final Object value) {
		return value == null;
	}

	public static Long convertObjectToLong(final Object value) {
		Long convertedValue = null;
		if (!isNull(value)) {
			convertedValue = (Long) new LongConverter().convert(Long.class, value);
		}
		return convertedValue;
	}

	public static String convertObjectToString(final Object value) {
		return !isNull(value) ? (String) new StringConverter().convert(String.class, value) : "";
	}

	public static <T> Boolean isListEmpty(final Collection<T> list) {
		return isNull(list) || list.isEmpty();
	}

	public static String getStringValueFromLong(final Long value) {
		return !isNull(value) ? (String) new StringConverter().convert(String.class, value) : "";
	}

	public static String getStringValue(final String value) {
		return !isNull(value) ? (String) new StringConverter().convert(String.class, value) : "";
	}

	public static String getStringValue(final String value,final String value1,final String seperator) {
		return !isEmpty(value) && !isEmpty(value1)? value.concat(seperator).concat(value1) : "";
	}

	public static Boolean checkIsValidString(final String value,final int length) {
		return value.length() == length ? Boolean.TRUE : Boolean.FALSE;
	}

	public static Map<String, Object> setMapValue(final String key,final String value,Map<String, Object> map ) {
		if (!EgonUtil.isEmpty(key) && !EgonUtil.isEmpty(value)) {
			map.put(key, value.toUpperCase());
		}
		return map;
	}
}
