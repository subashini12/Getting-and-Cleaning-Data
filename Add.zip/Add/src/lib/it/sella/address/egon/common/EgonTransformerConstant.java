package it.sella.address.egon.common;

public enum EgonTransformerConstant {


		//Indrizzi
		INDRIZZI_TRANSFORMER("it.sella.address.egon.transformer.EgonIndrizziViewTransformer"),
		PROVINCIA_TRANSFORMER("it.sella.address.egon.transformer.EgonProvinciaViewTransformer"),
		CITTA_TRANSFORMER("it.sella.address.egon.transformer.EgonCittaViewTransformer"),
		CAP_TRANSFORMER("it.sella.address.egon.transformer.EgonCapViewTransformer"),
		NORMALIZATION_TRANSFORMER("it.sella.address.egon.transformer.EgonNormalisationTransformer"),
		ADDRESSVIEW_TRANSFORMER("it.sella.address.egon.transformer.AddressViewTransformer"),
		;

		private String value;

		/**
		 * Instantiates a new constant.
		 *
		 * @param value the value
		 */
		private EgonTransformerConstant(final String value){
			this.value = value;
		}

		/**
		 * Gets the value.
		 *
		 * @return the value
		 */
		public String getValue() {
			return this.value;
		}

}
