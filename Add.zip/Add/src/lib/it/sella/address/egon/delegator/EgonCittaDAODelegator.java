package it.sella.address.egon.delegator;

import it.sella.address.AddressException;
import it.sella.address.egon.common.AddressBeanUtil;
import it.sella.address.egon.common.EgonAddressBeanConstant;
import it.sella.address.egon.common.EgonInputFieldValueConstant;
import it.sella.address.egon.common.EgonUtil;
import it.sella.address.egon.dao.ICittaDAO;
import it.sella.address.egon.view.EgonView;

import java.util.Collection;
import java.util.Map;
import java.util.WeakHashMap;

public class EgonCittaDAODelegator {

	public Collection<EgonView> getCitta(final String cap,final String citta,final String nazione,final String provincia) throws AddressException {
		final Map<String, Object> map = new WeakHashMap<String, Object>();
		EgonUtil.setMapValue(EgonInputFieldValueConstant.CITTA.getValue(), citta,map);
		EgonUtil.setMapValue(EgonInputFieldValueConstant.NAZIONE.getValue(), nazione,map);
		EgonUtil.setMapValue(EgonInputFieldValueConstant.PROVINCIA.getValue(), provincia,map);
		EgonUtil.setMapValue(EgonInputFieldValueConstant.ZIPCODE.getValue(), cap,map);
		return getCittaDAO().getCitta(map);

	}
	private ICittaDAO getCittaDAO(){
		return (ICittaDAO)AddressBeanUtil.getInstance().getBean(EgonAddressBeanConstant.CITTA_DAO.getBeanId());
	}

}
