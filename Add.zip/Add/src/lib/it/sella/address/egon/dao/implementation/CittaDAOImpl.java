package it.sella.address.egon.dao.implementation;

import it.sella.address.AddressException;
import it.sella.address.egon.common.EgonAPIClassNameConstants;
import it.sella.address.egon.common.EgonAbstractTransformer;
import it.sella.address.egon.common.EgonTransformerConstant;
import it.sella.address.egon.common.ReflectionAPIUtil;
import it.sella.address.egon.dao.ICittaDAO;
import it.sella.address.egon.view.EgonView;
import it.sella.address.implementation.util.DBHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;
import it.wareplace.www.services.it.EgonWpIta4Lst.CNL_AREA_INP;
import it.wareplace.www.services.it.EgonWpIta4Lst.LSTCNL_INP;
import it.wareplace.www.services.it.EgonWpIta4Lst.LSTCNL_OUT;
import it.wareplace.www.services.it.EgonWpIta4Lst.LSTPAR;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import WpIta4.wpWs.RWJWLST0;

public class CittaDAOImpl extends ICittaDAO{

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CittaDAOImpl.class);

	private void setCittaInputParams(final LSTCNL_INP inp) throws AddressException {
		inp.setLSTPAR((LSTPAR) ReflectionAPIUtil.INSTANCE.invokeSetMethod(setEgonInitParams(),
				EgonAPIClassNameConstants.LSTPAR.getValue()));

	}

	private void setCittaAreaInput(final Map<String, Object> map,
			final LSTCNL_INP inp) throws AddressException {
		inp.setCNL_AREA_INP((CNL_AREA_INP) ReflectionAPIUtil.INSTANCE
				.invokeSetMethod(map,
						EgonAPIClassNameConstants.CNL_AREA_INP.getValue()));
	}

	@SuppressWarnings("unchecked")
	public Collection<EgonView> getCitta(final Map<String, Object> map)
			throws AddressException {
		Connection connection = null;
		Collection<EgonView> cittaCollection = new ArrayList<EgonView>();
		try {
			final RWJWLST0 lst = (RWJWLST0) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.API_CLASS_NAME.getValue());

			final LSTCNL_INP cittaInput = (LSTCNL_INP) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.LSTCNL_INP.getValue());
			setCittaInputParams(cittaInput);
			setCittaAreaInput(map, cittaInput);
			connection = DBHelper.getConnection();
			final LSTCNL_OUT cittaOuput = lst.wpLstCnl(cittaInput,connection);
			final EgonAbstractTransformer<LSTCNL_OUT , Collection<EgonView>>  transformer =(EgonAbstractTransformer<LSTCNL_OUT, Collection<EgonView>>) ReflectionAPIUtil.INSTANCE
					.getInstance(EgonTransformerConstant.CITTA_TRANSFORMER.getValue());
			cittaCollection = transformer.transform(cittaOuput);
		} catch (final SQLException sqlEx) {
			sqlEx.printStackTrace();
			log4Debug.severeStackTrace(sqlEx);
			throw new AddressException(sqlEx.getMessage(), sqlEx);
		} finally {
			DBHelper.closeConnection(connection);
		}
		return cittaCollection;
	}
}
