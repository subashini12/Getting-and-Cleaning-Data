package it.sella.address.egon.transformer;

import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.address.egon.common.EgonAbstractTransformer;
import it.sella.address.egon.common.EgonUtil;
import it.sella.address.egon.view.EgonAddressView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

public class EgonAddressViewTransformer extends EgonAbstractTransformer<AddressView, EgonAddressView>{

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(EgonAddressViewTransformer.class);

	@Override
	public EgonAddressView transform(final AddressView addressView) throws AddressException {
		EgonAddressView egonAddressView = null;
      if (!EgonUtil.isNull(egonAddressView)) {
    	  egonAddressView = new EgonAddressView();
    	  setCap(egonAddressView, addressView);
    	  setProvincia(egonAddressView, addressView);
    	  setCitta(egonAddressView, addressView);
    	  egonAddressView.setIndirizzo(addressView.getIndirizzo());
    	  egonAddressView.setPresso(addressView.getPresso());//Need to check whether retuned by EGON else code to be commented
    	  egonAddressView.setEdificio(addressView.getEdificio());//Need to check whether retuned by EGON else code to be commented
    	  log4Debug.debug(egonAddressView.toString());
      }
		return egonAddressView;
	}

	private void setCap(final EgonAddressView egonAddressView, final AddressView addressView) {
		egonAddressView.setCap(!EgonUtil.isEmpty(addressView.getCap()) ? addressView.getCap() : addressView.getCapView().getCap());
	}

	private void setProvincia(final EgonAddressView egonAddressView, final AddressView addressView) {
		egonAddressView.setProvincia(!EgonUtil.isEmpty(addressView.getProvincia()) ? addressView.getProvincia() : addressView.getProvinciaView().getNome());
	}

	private void setCitta(final EgonAddressView egonAddressView, AddressView addressView) {
		egonAddressView.setCitta(!EgonUtil.isEmpty(addressView.getCitta()) ? addressView.getCitta() : addressView.getCittaView().getCommune());
	}
}