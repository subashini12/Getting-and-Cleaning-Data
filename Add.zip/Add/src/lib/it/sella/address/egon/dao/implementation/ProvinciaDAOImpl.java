package it.sella.address.egon.dao.implementation;

import it.sella.address.AddressException;
import it.sella.address.egon.common.EgonAPIClassNameConstants;
import it.sella.address.egon.common.EgonAbstractTransformer;
import it.sella.address.egon.common.EgonInputFieldValueConstant;
import it.sella.address.egon.common.EgonTransformerConstant;
import it.sella.address.egon.common.ReflectionAPIUtil;
import it.sella.address.egon.dao.IProvinciaDAO;
import it.sella.address.egon.view.EgonView;
import it.sella.address.implementation.util.DBHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;
import it.wareplace.www.services.it.EgonWpIta4Lst.DPT_AREA_INP;
import it.wareplace.www.services.it.EgonWpIta4Lst.LSTDPT_INP;
import it.wareplace.www.services.it.EgonWpIta4Lst.LSTDPT_OUT;
import it.wareplace.www.services.it.EgonWpIta4Lst.LSTPAR;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.WeakHashMap;

import WpIta4.wpWs.RWJWLST0;

public class ProvinciaDAOImpl extends IProvinciaDAO {
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(ProvinciaDAOImpl.class);

	private void setProvinciaListInputParams(final LSTDPT_INP inp) throws AddressException {
		inp.setLSTPAR((LSTPAR) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.LSTPAR.getValue()));
		inp.setLSTPAR((LSTPAR) ReflectionAPIUtil.INSTANCE.invokeSetMethod(setEgonInitParams(),
				EgonAPIClassNameConstants.LSTPAR.getValue()));

	}

	private void setProvinciaAreaInput(final Map<String, Object> map,
			final LSTDPT_INP inp) throws AddressException {
		inp.setDPT_AREA_INP((DPT_AREA_INP) ReflectionAPIUtil.INSTANCE
				.invokeSetMethod(map,
						EgonAPIClassNameConstants.DPT_AREA_INP.getValue()));
	}

	@SuppressWarnings("unchecked")
	public Collection<EgonView> getProvincia(final Map<String, Object> map) throws AddressException {
		Collection<EgonView> provinciaCollection = new ArrayList<EgonView>();
		Connection connection = null;
		try {
			final RWJWLST0 lst = (RWJWLST0) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.API_CLASS_NAME.getValue());

			final  LSTDPT_INP provinciaInput = (LSTDPT_INP) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.LSTDPT_INP.getValue());
			setProvinciaListInputParams(provinciaInput);
			setProvinciaAreaInput(map, provinciaInput);

			 connection =  DBHelper.getConnection();

			final LSTDPT_OUT provinciaOutput = lst.wpLstDpt(provinciaInput,connection);
			final EgonAbstractTransformer<LSTDPT_OUT , Collection<EgonView>>  transformer =(EgonAbstractTransformer<LSTDPT_OUT, Collection<EgonView>>) ReflectionAPIUtil.INSTANCE
					.getInstance(EgonTransformerConstant.PROVINCIA_TRANSFORMER.getValue());
			provinciaCollection = transformer.transform(provinciaOutput);

		} catch (final SQLException sqlEx) {
			log4Debug.severeStackTrace(sqlEx);
			throw new AddressException(sqlEx.getMessage(), sqlEx);
		} finally {
			DBHelper.closeConnection(connection);
		}
		return provinciaCollection;
	}

	public static void main(String[] args) throws SQLException {
		ProvinciaDAOImpl s = new ProvinciaDAOImpl();
		try {
			Map<String, Object> map = new WeakHashMap<String, Object>();
			map.put(EgonInputFieldValueConstant.ZIPCODE.getValue(), "13900");
			map.put(EgonInputFieldValueConstant.NAZIONE.getValue(), "ITALIA");
			map.put(EgonInputFieldValueConstant.PROVINCIA.getValue(), "");

			Collection<EgonView> provinciaCollection = s.getProvincia(map);
			for (EgonView egonView : provinciaCollection) {
				System.out.println("1"+egonView.getProvincia().getProvinciaNome());
				System.out.println("2"+egonView.getProvincia().getProvinciaSigla());
			}



		} catch (AddressException e) {
			e.printStackTrace();
		}
	}

}
