package it.sella.address.egon.dao.implementation;

import it.sella.address.AddressException;
import it.sella.address.egon.common.EgonAPIClassNameConstants;
import it.sella.address.egon.common.EgonAbstractTransformer;
import it.sella.address.egon.common.EgonInputFieldValueConstant;
import it.sella.address.egon.common.EgonTransformerConstant;
import it.sella.address.egon.common.ReflectionAPIUtil;
import it.sella.address.egon.dao.IIndirizziDAO;
import it.sella.address.egon.view.EgonView;
import it.sella.address.implementation.util.DBHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;
import it.wareplace.www.services.it.EgonWpIta4Lst.LSTPAR;
import it.wareplace.www.services.it.EgonWpIta4Lst.LSTSTR_INP;
import it.wareplace.www.services.it.EgonWpIta4Lst.LSTSTR_OUT;
import it.wareplace.www.services.it.EgonWpIta4Lst.STR_AREA_INP;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Map;
import java.util.WeakHashMap;

import WpIta4.wpWs.RWJWLST0;

public class IndirizziDAOImpl extends IIndirizziDAO {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(IndirizziDAOImpl.class);

	private void setIndrizzoListParams(final LSTSTR_INP inp) throws AddressException {
		inp.setLSTPAR((LSTPAR) ReflectionAPIUtil.INSTANCE.invokeSetMethod(
				setEgonInitParams(), EgonAPIClassNameConstants.LSTPAR.getValue()));

	}

	private void setStreetAreaInput(final Map<String, Object> map,
			final LSTSTR_INP inp) throws AddressException {
		inp.setSTR_AREA_INP((STR_AREA_INP) ReflectionAPIUtil.INSTANCE
				.invokeSetMethod(map,
						EgonAPIClassNameConstants.STR_AREA_INP.getValue()));
	}

	@SuppressWarnings("unchecked") //Note No provincia is set there in indrizzi view
	public Collection<EgonView> getStreet(final Map<String, Object> map) throws AddressException {
		Collection<EgonView> egonView = null;
		Connection connection = null;
		try {
			final RWJWLST0 lst = (RWJWLST0) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.API_CLASS_NAME.getValue());

			final LSTSTR_INP streetInput = (LSTSTR_INP) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.LSTSTR_INP
							.getValue());
			setIndrizzoListParams(streetInput);
			setStreetAreaInput(map, streetInput);

			connection = DBHelper.getConnection();
			final LSTSTR_OUT streetOutput = lst.wpLstStr(streetInput,connection);

			final EgonAbstractTransformer<LSTSTR_OUT , Collection<EgonView>>  transformer =(EgonAbstractTransformer<LSTSTR_OUT, Collection<EgonView>>) ReflectionAPIUtil.INSTANCE
					.getInstance(EgonTransformerConstant.INDRIZZI_TRANSFORMER.getValue());
			egonView = transformer.transform(streetOutput);
		} catch (final SQLException sqlEx) {
			log4Debug.severeStackTrace(sqlEx);
			throw new AddressException(sqlEx.getMessage(), sqlEx);
		} finally {
			DBHelper.closeConnection(connection);
		}
		return egonView;
	}

	public static void main(String[] args) throws SQLException {
		IndirizziDAOImpl s = new IndirizziDAOImpl();
		try {
			Map<String, Object> map = new WeakHashMap<String, Object>();
		    map.put(EgonInputFieldValueConstant.ZIPCODE.getValue(), "01011");
			map.put(EgonInputFieldValueConstant.NAZIONE.getValue(), "ITALIA");
			map.put(EgonInputFieldValueConstant.INDRIZZO.getValue(), "STR");

			Collection<EgonView> streetCollection = s.getStreet(map);
			System.out.println("öutput"+streetCollection);

			for (EgonView egonView : streetCollection) {
				System.out.println(egonView.getIndrizzi().getIndrizzi());
				System.out.println(egonView.getCap().getCapCode());
			}

		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
