package it.sella.address.egon.dao.implementation;

import it.sella.address.AddressException;
import it.sella.address.egon.common.AddressDAOUtil;
import it.sella.address.egon.dao.INazioneDAO;
import it.sella.address.egon.dao.QueryConstants;
import it.sella.address.egon.view.EgonNazioneView;
import it.sella.address.egon.view.EgonView;

import java.util.ArrayList;
import java.util.List;

public class NazioneDAOImpl extends INazioneDAO {

	public List<EgonView> getNazione(final String nazione) throws AddressException {
		final String query = AddressDAOUtil.getCommonProperties().getProperty(QueryConstants.GET_ALL_NAZIONE_NOMES.getValue());
		List<String> nazioneList = AddressDAOUtil.getJdbcTemplateInstance().queryListWithInput(query, new Object[] { "%"+nazione.toUpperCase()+"%" },String.class);
		List<EgonView> egonViews = new ArrayList<EgonView>();
		EgonView egonView = null;
		EgonNazioneView nazioneView = null;
		for (final String nazioneNome : nazioneList) {
			nazioneView = new EgonNazioneView();
			egonView = new EgonView();
			nazioneView.setNazioneNome(nazioneNome);
			egonView.setNazione(nazioneView);
			egonViews.add(egonView);
		}
		return egonViews;
	}
}
