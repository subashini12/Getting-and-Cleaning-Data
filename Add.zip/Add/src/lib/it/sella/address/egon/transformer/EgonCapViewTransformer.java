package it.sella.address.egon.transformer;

import it.sella.address.AddressException;
import it.sella.address.egon.common.EgonAbstractTransformer;
import it.sella.address.egon.common.EgonUtil;
import it.sella.address.egon.common.EgonViewNameConstant;
import it.sella.address.egon.common.ReflectionAPIUtil;
import it.sella.address.egon.view.EgonCapView;
import it.sella.address.egon.view.EgonCittaView;
import it.sella.address.egon.view.EgonIndrizziView;
import it.sella.address.egon.view.EgonNazioneView;
import it.sella.address.egon.view.EgonProvinciaView;
import it.sella.address.egon.view.EgonView;
import it.wareplace.www.services.it.EgonWpIta4Lst.LSTZIP_OUT;
import it.wareplace.www.services.it.EgonWpIta4Lst.ZIP;

import java.util.ArrayList;
import java.util.Collection;

public class EgonCapViewTransformer extends EgonAbstractTransformer<LSTZIP_OUT, Collection<EgonView>>{

	public Collection<EgonView> transform(final LSTZIP_OUT capOutput) throws AddressException {
		final Collection<EgonView> capCollection = new ArrayList<EgonView>();
		if (!EgonUtil.isNull(capOutput.getZIP_AREA_OUT())) {
		for (int i = 0; i < capOutput.getZIP_AREA_OUT().getNR9ZIP().intValue(); i++) {
			final ZIP cap = capOutput.getZIP_AREA_OUT().getZIP(i);
			final EgonView egonView = (EgonView) ReflectionAPIUtil.INSTANCE.getInstance(EgonViewNameConstant.EGON_VIEW.getValue());
			final EgonCapView egonCapView = (EgonCapView) ReflectionAPIUtil.INSTANCE.getInstance(EgonViewNameConstant.CAP_VIEW.getValue());
			final EgonNazioneView egonNazioneView = (EgonNazioneView) ReflectionAPIUtil.INSTANCE.getInstance(EgonViewNameConstant.NAZIONE_VIEW.getValue());
			final EgonCittaView egonCittaView = (EgonCittaView) ReflectionAPIUtil.INSTANCE.getInstance(EgonViewNameConstant.CITTA_VIEW.getValue());
			final EgonIndrizziView egonIndrizziView = (EgonIndrizziView) ReflectionAPIUtil.INSTANCE.getInstance(EgonViewNameConstant.EGON_INDRIZZI_VIEW.getValue());
			egonCittaView.setCittaNome(cap.getDSXOBJCNL());
			egonView.setCitta(egonCittaView);
			egonNazioneView.setNazioneNome(cap.getDSXOBJCNY());
			egonView.setNazione(egonNazioneView);
			egonCapView.setCapCode(cap.getCDXZIP());
			egonView.setCap(egonCapView);
			final EgonProvinciaView egonProvinciaView = (EgonProvinciaView) ReflectionAPIUtil.INSTANCE.getInstance(EgonViewNameConstant.PROVINCIA_VIEW.getValue());
			final String[] proviceArr = cap.getDSXOBJDPT().split("-");
			if (!EgonUtil.isNull(proviceArr) && proviceArr.length == 2) {
				egonProvinciaView.setProvinciaSigla(proviceArr[0].trim());
				egonProvinciaView.setProvinciaNome(proviceArr[1].trim());
			}
			egonView.setProvincia(egonProvinciaView);
			System.out.println(cap.getDSXOBJSTR());
			egonIndrizziView.setIndrizzi(cap.getDSXOBJSTR());
			egonView.setIndrizzi(egonIndrizziView);
			capCollection.add(egonView);
		}
		}
		return capCollection;
	}
}
