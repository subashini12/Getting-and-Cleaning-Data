package it.sella.address.egon.view;

import it.sella.address.egon.common.EgonUtil;

import java.io.Serializable;
import java.util.List;

public class EgonAddressView implements Serializable{
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String nazione;
	private String indirizzo;
	private String cap;
	private String citta;
	private String provinciaSingla;
	private String edificio;
	private String presso;
	private String provincia;
    //From EGON
    private List<EgonErrorView> failureMessage;//0 -> ok 1 -> CNL Error  2 -> STR Error
    private List<EgonErrorView> warningMessage;
    private Boolean normalisationSuccess = Boolean.FALSE;
    private Boolean normalisationFailure = Boolean.FALSE;

	/**
	 * @return the nazione
	 */
	public String getNazione() {
		return nazione;
	}
	/**
	 * @param nazione the nazione to set
	 */
	public void setNazione(final String nazione) {
		this.nazione = nazione;
	}

	/**
	 * @return the indirizzo
	 */
	public String getIndirizzo() {
		return indirizzo;
	}
	/**
	 * @param indirizzo the indirizzo to set
	 */
	public void setIndirizzo(final String indirizzo) {
		this.indirizzo = indirizzo;
	}
	/**
	 * @return the cap
	 */
	public String getCap() {
		return cap;
	}
	/**
	 * @param cap the cap to set
	 */
	public void setCap(final String cap) {
		this.cap = cap;
	}

	/**
	 * @return the citta
	 */
	public String getCitta() {
		return citta;
	}
	/**
	 * @param citta the citta to set
	 */
	public void setCitta(final String citta) {
		this.citta = citta;
	}
	/**
	 * @return the provinciaSingla
	 */
	public String getProvinciaSingla() {
		return provinciaSingla;
	}
	/**
	 * @param provinciaSingla the provinciaSingla to set
	 */
	public void setProvinciaSingla(final String provinciaSingla) {
		this.provinciaSingla = provinciaSingla;
	}
	/**
	 * @return the edificio
	 */
	public String getEdificio() {
		return edificio;
	}
	/**
	 * @param edificio the edificio to set
	 */
	public void setEdificio(final String edificio) {
		this.edificio = edificio;
	}
	/**
	 * @return the presso
	 */
	public String getPresso() {
		return presso;
	}
	/**
	 * @param presso the presso to set
	 */
	public void setPresso(final String presso) {
		this.presso = presso;
	}
	/**
	 * @return the provincia
	 */
	public String getProvincia() {
		return provincia;
	}
	/**
	 * @param provincia the provincia to set
	 */
	public void setProvincia(final String provincia) {
		this.provincia = provincia;
	}
	/**
	 * @return the failureMessage
	 */
	public final List<EgonErrorView> getFailureMessage() {
		return failureMessage;
	}
	/**
	 * @param failureMessage the failureMessage to set
	 */
	public final void setFailureMessage(final List<EgonErrorView> failureMessage) {
		this.failureMessage = failureMessage;
	}
	/**
	 * @return the warningMessage
	 */
	public final List<EgonErrorView> getWarningMessage() {
		return warningMessage;
	}
	/**
	 * @param warningMessage the warningMessage to set
	 */
	public final void setWarningMessage(final List<EgonErrorView> warningMessage) {
		this.warningMessage = warningMessage;
	}
	/**
	 * @return the normalisationSuccess
	 */
	public final Boolean getNormalisationSuccess() {
		return normalisationSuccess;
	}
	/**
	 * @param normalisationSuccess the normalisationSuccess to set
	 */
	public final void setNormalisationSuccess(final Boolean normalisationSuccess) {
		this.normalisationSuccess = normalisationSuccess;
	}
	/**
	 * @return the normalisationFailure
	 */
	public final Boolean getNormalisationFailure() {
		return normalisationFailure;
	}
	/**
	 * @param normalisationFailure the normalisationFailure to set
	 */
	public final void setNormalisationFailure(final Boolean normalisationFailure) {
		this.normalisationFailure = normalisationFailure;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		final StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append("Cap ..").append(this.cap).append("\n").append("Citta ..").append(this.citta).append("\n").append("Provincia ..").append(this.provincia)
		.append("Indirizzo ..").append(this.indirizzo).append("\n").append("Edificio..").append(this.edificio).append("\n").append("Presso ..")
		.append(this.presso).append("\n").append("Normalisation Status").append(this.normalisationSuccess).append("\n");

		if (!EgonUtil.isNull(this.failureMessage) && !this.failureMessage.isEmpty()) {
			for (final EgonErrorView egonErrorView : failureMessage) {
				stringBuffer.append("Failure Error Message ..").append(egonErrorView.getErrorDescription()).append("\n");
			}
		}

		if (!EgonUtil.isNull(this.warningMessage) && !this.warningMessage.isEmpty()) {
			for (final EgonErrorView egonErrorView : warningMessage) {
				stringBuffer.append("Warning Error Message ..").append(egonErrorView.getErrorDescription()).append("\n");
			}
		}
		return stringBuffer.toString();

	}


}
