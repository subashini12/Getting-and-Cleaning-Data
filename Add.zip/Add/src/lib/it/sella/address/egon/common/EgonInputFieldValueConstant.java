package it.sella.address.egon.common;

public enum EgonInputFieldValueConstant {
	ZIPCODE("CDXZIP"),
	CITTA("DSXCNL"),
	NAZIONE("DSXSTA"),
	INDRIZZO("DSXST1"),
	STREET("DSXOBJSTR"),
	PROVINCIA("DSXDPT"),
	SEARCH_FULL_PARTIAL("FLXRAD"),
	SEARCH_EXTENSION("TPXEXT"),
	SEARCH_MAXLIVLOC("MAXLIVLOC"),


	TP9INDSOT("TP9INDSOT"),


	INDRIZZI("DSXVIA"),
	CIVICO("DSXESP"),
	PRESSO("DSXPREINR"),
	EDIFICIO("DSXBLD"),

	PARAM_METHOD_NAME("TPXFUN"),
	SOGGETTO("CDXSOG"),
	ABICODE("CDXBNC"),
	LINKED_ID("CDXPRD"),
	SUBSYSTEM_CAUSALE("TPXPRD"),
	ADDRESS_TYPE_CAUSALE("TPXIND"),


	;

	private String value;

	/**
	 * Instantiates a new constant.
	 *
	 * @param value the value
	 */
	private EgonInputFieldValueConstant(final String value){
		this.value = value;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public String getValue() {
		return this.value;
	}
}
