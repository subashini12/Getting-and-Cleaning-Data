package it.sella.address.egon.view;

import java.io.Serializable;

public class EgonCittaView implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;


	private String cittaNome;

	public String getCittaNome() {
		return cittaNome;
	}
	public void setCittaNome(final String cittaNome) {
		this.cittaNome = cittaNome;
	}
}
