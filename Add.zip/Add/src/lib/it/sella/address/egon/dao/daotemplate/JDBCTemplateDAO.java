package it.sella.address.egon.dao.daotemplate;

import it.sella.address.egon.dao.IJDBCTemplateDAO;

import java.util.List;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;

public class JDBCTemplateDAO extends NamedParameterJdbcDaoSupport implements IJDBCTemplateDAO{


	public <T> T queryForObject(final String sql,final Object[] params,final Class<T> requiredType) {
		return getJdbcTemplate().queryForObject(sql,  params , requiredType);
	}


	public <T> List<T> queryListWithNoInput(final String sql,final RowMapper<T> rowMapper){
		return getJdbcTemplate().query( sql, rowMapper);
	}

	public <T> List<T> queryForListWithParameter(final String sql,final Object[] params,final RowMapper<T> rowMapper) {
		return getJdbcTemplate().query(sql,params, rowMapper);
	}

	public long queryForLong(final String sql,final Object[] params) {
		return getJdbcTemplate().queryForLong(sql,params);
	}


	public <T> List<T> queryListWithInput(String sql, final Object[] params,final Class<T> requiredType) {
		return (List<T>) getJdbcTemplate().queryForList(sql, params, requiredType);

	}
}

