package it.sella.address.egon.common;

public enum EgonParValueConstant {

	ITA("ITA"),
	WPPASW("wp1299"),
	WPUSER("wp"),
	FLXSYN(""),
	INDRES("S"),

	TPXFUN_ENQ("ENQ"),
	TPXFUN_LST("LST"),

	;

	private String value;

	/**
	 * Instantiates a new constant.
	 *
	 * @param value the value
	 */
	private EgonParValueConstant(final String value){
		this.value = value;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public String getValue() {
		return this.value;
	}

}
