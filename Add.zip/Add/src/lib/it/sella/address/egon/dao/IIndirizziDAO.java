package it.sella.address.egon.dao;

import it.sella.address.AddressException;
import it.sella.address.egon.view.EgonView;

import java.util.Collection;
import java.util.Map;

public abstract class IIndirizziDAO extends EgonAPIParam{
	public abstract Collection<EgonView> getStreet(final Map<String, Object> map) throws AddressException;

}
