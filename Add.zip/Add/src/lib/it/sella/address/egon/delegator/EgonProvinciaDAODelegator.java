package it.sella.address.egon.delegator;

import java.util.Collection;
import java.util.Map;
import java.util.WeakHashMap;

import it.sella.address.AddressException;
import it.sella.address.egon.common.AddressBeanUtil;
import it.sella.address.egon.common.EgonAddressBeanConstant;
import it.sella.address.egon.common.EgonInputFieldValueConstant;
import it.sella.address.egon.common.EgonUtil;
import it.sella.address.egon.dao.IProvinciaDAO;
import it.sella.address.egon.view.EgonView;

public class EgonProvinciaDAODelegator {

	public Collection<EgonView> getProvincia(final String cap,final String nazione,final String provincia) throws AddressException {
		final Map<String, Object> map = new WeakHashMap<String, Object>();
		EgonUtil.setMapValue(EgonInputFieldValueConstant.NAZIONE.getValue(), nazione,map);
		EgonUtil.setMapValue(EgonInputFieldValueConstant.PROVINCIA.getValue(), provincia,map);
		EgonUtil.setMapValue(EgonInputFieldValueConstant.ZIPCODE.getValue(), cap,map);
		return getProvinciaDAO().getProvincia(map);
	}

	private IProvinciaDAO getProvinciaDAO() {
		return (IProvinciaDAO)AddressBeanUtil.getInstance().getBean(EgonAddressBeanConstant.PROVINCIA_DAO.getBeanId());
	}

}
