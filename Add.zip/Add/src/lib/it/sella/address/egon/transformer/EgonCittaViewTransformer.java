package it.sella.address.egon.transformer;

import it.sella.address.AddressException;
import it.sella.address.egon.common.EgonAbstractTransformer;
import it.sella.address.egon.common.EgonUtil;
import it.sella.address.egon.common.EgonViewNameConstant;
import it.sella.address.egon.common.ReflectionAPIUtil;
import it.sella.address.egon.view.EgonCapView;
import it.sella.address.egon.view.EgonCittaView;
import it.sella.address.egon.view.EgonProvinciaView;
import it.sella.address.egon.view.EgonView;
import it.wareplace.www.services.it.EgonWpIta4Lst.CNL;
import it.wareplace.www.services.it.EgonWpIta4Lst.LSTCNL_OUT;

import java.util.ArrayList;
import java.util.Collection;

public class EgonCittaViewTransformer extends EgonAbstractTransformer<LSTCNL_OUT, Collection<EgonView>>{

	@Override
	public Collection<EgonView> transform(final LSTCNL_OUT cittaOuput) throws AddressException {
		final Collection<EgonView> cittaCollection = new ArrayList<EgonView>();
		if (!EgonUtil.isNull(cittaOuput.getCNL_AREA_OUT())) {
			for (int i = 0; i < cittaOuput.getCNL_AREA_OUT().getNR9CNL().intValue(); i++) {
				final CNL citta = cittaOuput.getCNL_AREA_OUT().getCNL(i);
				final EgonView egonView = (EgonView) ReflectionAPIUtil.INSTANCE.getInstance(EgonViewNameConstant.EGON_VIEW.getValue());
				final EgonCittaView egonCittaView = (EgonCittaView) ReflectionAPIUtil.INSTANCE.getInstance(EgonViewNameConstant.CITTA_VIEW.getValue());
				final EgonProvinciaView egonProvinciaView = (EgonProvinciaView) ReflectionAPIUtil.INSTANCE.getInstance(EgonViewNameConstant.PROVINCIA_VIEW.getValue());
				final EgonCapView egonCapView = (EgonCapView) ReflectionAPIUtil.INSTANCE.getInstance(EgonViewNameConstant.CAP_VIEW.getValue());
				final String[] proviceArr = citta.getDSXOBJDPT().split("-");
				if (!EgonUtil.isNull(proviceArr)) {
					egonProvinciaView.setProvinciaNome(proviceArr[1].trim());
					egonProvinciaView.setProvinciaSigla(proviceArr[0].trim());
				}
				egonCittaView.setCittaNome(citta.getDSXOBJCNL());
				egonCapView.setCapCode(citta.getCDXZIP());
				egonView.setCap(egonCapView);
				egonView.setCitta(egonCittaView);
				egonView.setProvincia(egonProvinciaView);
				cittaCollection.add(egonView);
			}
		}
		return cittaCollection;
	}
}
