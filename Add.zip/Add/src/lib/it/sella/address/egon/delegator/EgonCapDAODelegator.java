package it.sella.address.egon.delegator;

import it.sella.address.AddressException;
import it.sella.address.egon.common.AddressBeanUtil;
import it.sella.address.egon.common.EgonAddressBeanConstant;
import it.sella.address.egon.common.EgonInputFieldValueConstant;
import it.sella.address.egon.common.EgonUtil;
import it.sella.address.egon.dao.ICapDAO;
import it.sella.address.egon.view.EgonView;

import java.util.Collection;
import java.util.Map;
import java.util.WeakHashMap;

public class EgonCapDAODelegator {

	public Collection<EgonView> getCapWithProvincia(final String cap) throws AddressException {
		final Map<String, Object> map = new WeakHashMap<String, Object>();
		EgonUtil.setMapValue(EgonInputFieldValueConstant.ZIPCODE.getValue(), cap, map);
		EgonUtil.setMapValue(EgonInputFieldValueConstant.SEARCH_EXTENSION.getValue(), "T", map);
		EgonUtil.setMapValue(EgonInputFieldValueConstant.SEARCH_FULL_PARTIAL.getValue(), "S", map);
		return getCapDAO().getCap(map);
	}
	private ICapDAO getCapDAO() {
		return (ICapDAO)AddressBeanUtil.getInstance().getBean(EgonAddressBeanConstant.CAP_DAO.getBeanId());
	}
}
