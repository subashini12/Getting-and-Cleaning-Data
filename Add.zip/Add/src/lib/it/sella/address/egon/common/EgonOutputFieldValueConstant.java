package it.sella.address.egon.common;

public enum EgonOutputFieldValueConstant {

	ZIPCODE("CDXZIP"),
	STREET("DSXOBJSTR"),
	CITTA("DSXOBJCNL"),
	PROVICIA("DSXOBJDPT"),
	REGION("DSXOBJREG"),
	NAZIONE("DSXOBJSTA"),
	CODICE_STREET("CDPOBJSTR"),
	CODICE_CITTA("CDPOBJCNL"),
	CODICE_PROVICIA("CDPOBJDPT"),
	CODICE_REGIONE("CDPOBJREG"),
	CODICE_STATE("CDPOBJSTA"),
	CODICE_LINGUA("CDPLNG"),
	TIPO_LINGUA("TPPLNG"),
	NRP_PRG("NRPPRG"),

	;

	private String value;

	/**
	 * Instantiates a new constant.
	 *
	 * @param value the value
	 */
	private EgonOutputFieldValueConstant(final String value){
		this.value = value;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public String getValue() {
		return this.value;
	}


}
