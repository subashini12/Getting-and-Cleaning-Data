package it.sella.address.egon.dao.implementation;

import it.sella.address.AddressException;
import it.sella.address.egon.common.EgonAPIClassNameConstants;
import it.sella.address.egon.common.EgonAbstractTransformer;
import it.sella.address.egon.common.EgonInputFieldValueConstant;
import it.sella.address.egon.common.EgonTransformerConstant;
import it.sella.address.egon.common.ReflectionAPIUtil;
import it.sella.address.egon.dao.INormalisationDAO;
import it.sella.address.egon.view.EgonAddressView;
import it.sella.address.egon.view.EgonErrorView;
import it.sella.address.implementation.util.DBHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;
import it.wareplace.www.services.it.EgonWpIta4Suite.DSXPLC;
import it.wareplace.www.services.it.EgonWpIta4Suite.DSXSTRINP;
import it.wareplace.www.services.it.EgonWpIta4Suite.INR_020;
import it.wareplace.www.services.it.EgonWpIta4Suite.PAR;
import it.wareplace.www.services.it.EgonWpIta4Suite.WPFGO;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

import org.apache.axis.types.UnsignedInt;

import WpIta4.wpWs.RWJWFGO5;

public class NormalisationDAOImpl extends INormalisationDAO {
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(NormalisationDAOImpl.class);

	private WPFGO setNormalisationInput(final EgonAddressView normalisationView , final WPFGO inp ) throws AddressException {

		setInitialParams(inp);
		inp.getSOG(0).setPAR((PAR) ReflectionAPIUtil.INSTANCE.invokeSetMethod(setEgonInitParams(),
				EgonAPIClassNameConstants.PAR.getValue()));


		final Map<String, Object> inr020 = new WeakHashMap<String, Object>();
		inr020.put(EgonInputFieldValueConstant.EDIFICIO.getValue(), normalisationView.getEdificio());
		inr020.put(EgonInputFieldValueConstant.TP9INDSOT.getValue(), new UnsignedInt(0L));
		inr020.put(EgonInputFieldValueConstant.ZIPCODE.getValue(), normalisationView.getCap());
		inp.getSOG(0).setINR_020((INR_020) ReflectionAPIUtil.INSTANCE.invokeSetMethod(inr020,EgonAPIClassNameConstants.INR_020.getValue()));

		final Map<String, Object> dsxst1 = new WeakHashMap<String, Object>();
		dsxst1.put(EgonInputFieldValueConstant.INDRIZZI.getValue(),normalisationView.getIndirizzo() );
		inp.getSOG(0).getINR_020().setDSXST1((DSXSTRINP)	ReflectionAPIUtil.INSTANCE
				.invokeSetMethod(dsxst1,
						EgonAPIClassNameConstants.DSXSTRINP.getValue()));



		final Map<String, Object> dsxplcMap = new WeakHashMap<String, Object>();
		dsxplcMap.put(EgonInputFieldValueConstant.NAZIONE.getValue(), normalisationView.getNazione());
		dsxplcMap.put(EgonInputFieldValueConstant.PROVINCIA.getValue(), normalisationView.getProvinciaSingla());
		dsxplcMap.put(EgonInputFieldValueConstant.CITTA.getValue(), normalisationView.getCitta());

		inp.getSOG(0).getINR_020().setDSXPLC((DSXPLC) ReflectionAPIUtil.INSTANCE
				.invokeSetMethod(dsxplcMap,
						EgonAPIClassNameConstants.DSXPLC.getValue()));
		return inp;


	}

	@SuppressWarnings("unchecked")
	public EgonAddressView normalisation(final EgonAddressView normalisationView) throws AddressException {
		Connection connection = null;
		EgonAddressView normalisationTransformerView = null;
		try {

			final RWJWFGO5 normalisation = (RWJWFGO5) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.API_CLASS_NAME_NORMLISATION.getValue());

			WPFGO pINOU = (WPFGO) ReflectionAPIUtil.INSTANCE.getInstance(EgonAPIClassNameConstants.WPFGO.getValue());

		    pINOU = setNormalisationInput (normalisationView,pINOU);

		    connection =  DBHelper.getConnection();

		    pINOU = normalisation.WPNORM(pINOU,connection);

			final EgonAbstractTransformer<WPFGO, EgonAddressView>  transformer =(EgonAbstractTransformer<WPFGO, EgonAddressView>) ReflectionAPIUtil.INSTANCE
					.getInstance(EgonTransformerConstant.NORMALIZATION_TRANSFORMER.getValue());
			normalisationTransformerView = transformer.transform(pINOU);
			normalisationTransformerView.setEdificio(normalisationView.getEdificio());
		} catch (SQLException sqlEx) {
			log4Debug.debug("Error from SQL",sqlEx);
			throw new AddressException(sqlEx.getMessage(), sqlEx);
		} finally {
			DBHelper.closeConnection(connection);
		}
		return normalisationTransformerView;

	}

	public static void main(String[] args)  {
		try {
		EgonAddressView normalisationView  = new EgonAddressView();

		normalisationView.setIndirizzo("C/O ST.CAOPRESO VIA ITALIA");
		normalisationView.setProvinciaSingla("BI");
		normalisationView.setCap("13901");
		normalisationView.setCitta("BIELLA");
		normalisationView.setEdificio("23423432");

		EgonAddressView normalisationTransformerView = new NormalisationDAOImpl().normalisation(normalisationView);
		System.out.println("cap " +normalisationTransformerView.getCap());
		System.out.println( "indrizzo " +normalisationTransformerView.getIndirizzo());
		System.out.println("citta " + normalisationTransformerView.getCitta());
		System.out.println("provincia " +normalisationTransformerView.getProvincia());
		System.out.println("provincia sigla " +normalisationTransformerView.getProvinciaSingla());
		System.out.println("edificio " +normalisationTransformerView.getEdificio());
		System.out.println("presso " +normalisationTransformerView.getPresso());
		List<EgonErrorView> eror = normalisationTransformerView.getFailureMessage();
		List<EgonErrorView> warning = normalisationTransformerView.getWarningMessage();
		if (eror!= null) {
			for (EgonErrorView egonErrorView : eror) {
				System.out.println("error flag "+egonErrorView.getErrorFlag());
				System.out.println("error desc " +egonErrorView.getErrorDescription());

			}
		}
		if (warning!= null) {
			for (EgonErrorView egonErrorView : warning) {
				System.out.println("warning error flag "+egonErrorView.getErrorFlag());
				System.out.println("warning error desc " +egonErrorView.getErrorDescription());

			}
		}
		System.out.println("Success " +normalisationTransformerView.getNormalisationSuccess());
		System.out.println("Failure " +normalisationTransformerView.getNormalisationFailure());
		}catch (Exception e) {
			e.printStackTrace();
		}
	}


}
