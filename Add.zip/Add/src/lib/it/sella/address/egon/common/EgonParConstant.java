package it.sella.address.egon.common;

public enum EgonParConstant {
	CDXISO("CDXISO"),
	WPPASW("WPPASW"),
	WPUSER("WPUSER"),
	FLXSYN("FLXSYN"),

	//Normalisation
	INDRES("INDRES"),

	;

	private String value;

	/**
	 * Instantiates a new constant.
	 *
	 * @param value the value
	 */
	private EgonParConstant(final String value){
		this.value = value;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public String getValue() {
		return this.value;
	}
}
