package it.sella.address.egon.view;

import it.sella.address.egon.view.EgonCapView;
import it.sella.address.egon.view.EgonCittaView;
import it.sella.address.egon.view.EgonNazioneView;
import it.sella.address.egon.view.EgonProvinciaView;

import java.io.Serializable;

public class EgonView implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private EgonCapView cap;
	private EgonProvinciaView provincia;
	private EgonNazioneView nazione;
	private EgonCittaView citta;
	private EgonIndrizziView indrizzi;

	public EgonCapView getCap() {
		return cap;
	}
	public void setCap(final EgonCapView cap) {
		this.cap = cap;
	}
	public EgonProvinciaView getProvincia() {
		return provincia;
	}
	public void setProvincia(final EgonProvinciaView provincia) {
		this.provincia = provincia;
	}
	public EgonNazioneView getNazione() {
		return nazione;
	}
	public void setNazione(final EgonNazioneView nazione) {
		this.nazione = nazione;
	}
	public EgonCittaView getCitta() {
		return citta;
	}
	public void setCitta(final EgonCittaView citta) {
		this.citta = citta;
	}
	public EgonIndrizziView getIndrizzi() {
		return indrizzi;
	}
	public void setIndrizzi(final EgonIndrizziView indrizzi) {
		this.indrizzi = indrizzi;
	}
}
