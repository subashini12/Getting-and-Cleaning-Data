package it.sella.address.egon.common;

import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AddressBeanUtil {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressBeanUtil.class);

	private static final String[] XML_BEANS = new String[] { "it/sella/address/egon/egonaddressbean.xml" };

	private static final AddressBeanUtil ADDRESS_BEAN_MANAGER = new AddressBeanUtil(
			XML_BEANS);

	private ApplicationContext applicationContext = null;

	private AddressBeanUtil(final String[] xmlBeans) {
		applicationContext = new ClassPathXmlApplicationContext(xmlBeans);
	}

	public static AddressBeanUtil getInstance() {
		return ADDRESS_BEAN_MANAGER;
	}

	public <T> Object getBean(final String beanName, final T... t) {
		log4Debug.debug("Getting bean instance");
		return this.applicationContext.getBean(beanName, t);
	}

	public <T> Object getBean(final String beanName) {
		log4Debug.debug("Getting bean instance");
		return this.applicationContext.getBean(beanName);
	}

}
