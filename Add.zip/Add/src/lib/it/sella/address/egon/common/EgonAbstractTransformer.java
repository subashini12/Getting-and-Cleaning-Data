package it.sella.address.egon.common;

import it.sella.address.AddressException;

import java.util.ArrayList;
import java.util.List;

import javax.xml.transform.TransformerException;

/**
 * Implementors define a strategy for transforming <code> InputType </code> results into the actual
 * application-visible result <code> ReturnType </code> list.
 *
 */
public abstract class EgonAbstractTransformer<InputType,ReturnType> {

	/**
	 * Entity are the elements making up each "element" of the given result. The contract here is to
	 * transform these elements into the final application-visible result.
	 *
	 * @param entity - InputType which is need to transform
	 * @return ReturnType - The transformed result
	 * @throws AddressException
	 *
	 * @throws TransformerException
	 */
	public abstract ReturnType transform(final InputType entity) throws AddressException;

	/**
	 * Here we have an opportunity to perform transformation on the given result as a whole. This might be useful
	 * to convert from one collection type to another or to remove duplicates from the result, etc.
	 *
	 * @param entityList - The Result need to convert
	 * @return List - The transformed result
	 *
	 * @throws TransformerException
	 */
	public List<ReturnType> transformList(final List<InputType> entityList) throws AddressException {
		final List<ReturnType> pageViewList = new ArrayList<ReturnType>();
		if(entityList != null ) {
			for(final InputType entity : entityList) {
				final ReturnType view = transform(entity);
				pageViewList.add(view);
			}
		}
		return pageViewList;
	}
}