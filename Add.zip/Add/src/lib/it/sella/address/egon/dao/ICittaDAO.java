package it.sella.address.egon.dao;

import it.sella.address.AddressException;
import it.sella.address.egon.view.EgonView;

import java.util.Collection;
import java.util.Map;

public abstract class ICittaDAO extends EgonAPIParam{
	public abstract Collection<EgonView> getCitta(final Map<String, Object> map) throws AddressException;

}
