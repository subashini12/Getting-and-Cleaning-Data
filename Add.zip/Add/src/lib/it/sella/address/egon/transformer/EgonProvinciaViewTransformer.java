package it.sella.address.egon.transformer;

import it.sella.address.AddressException;
import it.sella.address.egon.common.EgonAbstractTransformer;
import it.sella.address.egon.common.EgonUtil;
import it.sella.address.egon.common.EgonViewNameConstant;
import it.sella.address.egon.common.ReflectionAPIUtil;
import it.sella.address.egon.view.EgonProvinciaView;
import it.sella.address.egon.view.EgonView;
import it.wareplace.www.services.it.EgonWpIta4Lst.DPT;
import it.wareplace.www.services.it.EgonWpIta4Lst.LSTDPT_OUT;

import java.util.ArrayList;
import java.util.Collection;

public class EgonProvinciaViewTransformer extends EgonAbstractTransformer<LSTDPT_OUT, Collection<EgonView>>{

	@Override
	public Collection<EgonView> transform(final LSTDPT_OUT provinciaOutput) throws AddressException {
		final Collection<EgonView> provinciaCollection = new ArrayList<EgonView>();
		if (!EgonUtil.isNull(provinciaOutput.getDPT_AREA_OUT())) {
			for (int i = 0; i < provinciaOutput.getDPT_AREA_OUT().getNR9DPT().intValue(); i++) {
				final EgonView egonView = (EgonView) ReflectionAPIUtil.INSTANCE.getInstance(EgonViewNameConstant.EGON_VIEW.getValue());
				final DPT province = provinciaOutput.getDPT_AREA_OUT().getDPT(i);
				final EgonProvinciaView egonProvinciaView = (EgonProvinciaView) ReflectionAPIUtil.INSTANCE.getInstance(EgonViewNameConstant.PROVINCIA_VIEW.getValue());
				final String[] proviceArr = province.getDSXOBJDPT().split("-");
				if (!EgonUtil.isNull(proviceArr) && proviceArr.length == 2) {
					egonProvinciaView.setProvinciaNome(proviceArr[1].trim());
					egonProvinciaView.setProvinciaSigla(proviceArr[0].trim());
				}
				egonView.setProvincia(egonProvinciaView);
				provinciaCollection.add(egonView);
			}
		}
		return provinciaCollection;
	}

}
