package it.sella.address.egon.delegator;

import it.sella.address.AddressException;
import it.sella.address.egon.common.AddressBeanUtil;
import it.sella.address.egon.common.EgonAddressBeanConstant;
import it.sella.address.egon.common.EgonInputFieldValueConstant;
import it.sella.address.egon.common.EgonUtil;
import it.sella.address.egon.dao.IIndirizziDAO;
import it.sella.address.egon.view.EgonView;

import java.util.Collection;
import java.util.Map;
import java.util.WeakHashMap;

public class EgonIndirizziDAODelegator {

	public Collection<EgonView> getIndrizzi(final String cap,final String citta,final String nazione,final String indrizzi,final String provincia) throws AddressException {
		final Map<String, Object> map = new WeakHashMap<String, Object>();
		EgonUtil.setMapValue(EgonInputFieldValueConstant.ZIPCODE.getValue(), cap, map);
		EgonUtil.setMapValue(EgonInputFieldValueConstant.CITTA.getValue(), citta, map);
		EgonUtil.setMapValue(EgonInputFieldValueConstant.NAZIONE.getValue(), nazione, map);
		EgonUtil.setMapValue(EgonInputFieldValueConstant.INDRIZZO.getValue(), indrizzi, map);
		EgonUtil.setMapValue(EgonInputFieldValueConstant.PROVINCIA.getValue(), provincia, map);
		return getIndirizziDAO().getStreet(map);
	}

	private IIndirizziDAO getIndirizziDAO() {
		return (IIndirizziDAO)AddressBeanUtil.getInstance().getBean(EgonAddressBeanConstant.INDIRIZZI_DAO.getBeanId());
	}
}
