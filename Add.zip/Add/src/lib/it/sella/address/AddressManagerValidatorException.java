package it.sella.address;

public class AddressManagerValidatorException extends Exception {

	
    /**
     *  Default Constructor
     */
    public AddressManagerValidatorException() {
    	// explicit default constructor
    }

    /**
     * One argument Constructor, which in turn calls superclass constructor
     * @param message java.lang.String
     */
    public AddressManagerValidatorException(final String message) {
        super(message);
    }

}
