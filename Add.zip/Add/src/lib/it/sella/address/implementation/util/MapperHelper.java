
package it.sella.address.implementation.util;

import it.sella.address.AddressView;
import it.sella.address.SubSystemHandlerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;

import com.bsella.jmapper.client.ClientAdapter;

public class MapperHelper {

    static final int NUM_FIELDS = 39;
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(MapperHelper.class);
    

    public String aggiornaIndirizzo(final AddressView addressView,final String hostUserCode) throws MapperHelperException, RemoteException {
        String out = null;
        final StringBuffer mapperInput = new StringBuffer();
        final StringBuffer output = new StringBuffer();
        try {
            final String[] in = new String[NUM_FIELDS];
            final ClientAdapter remoteObject = instanziaMapper();
            in[0] = hostUserCode != null ? hostUserCode : SecurityHandler.getLoginUsersHostCode();
            in[15] = addressView.getNch();
            in[19] = "612(A0500,A03";
            in[19] = in[19] + addressView.getIndirizzo().replace(',', ' ') + ",A04";
            if (addressView.getCap() != null && addressView.getCap().length() > 0) {
				mapperInput.append(addressView.getCap().length() > 5 ? addressView.getCap().substring(0, 5) : addressView.getCap());
				mapperInput.append("ITALIA".equals(addressView.getNazione()) ? "   " : " ");
            }
            mapperInput.append(addressView.getCitta());
			in[19] = in[19] + (mapperInput.length() > 35 ? mapperInput.toString().substring(0,35) : mapperInput.toString()) +  ")";
            log4Debug.info("in[FLAGS] " , in[19]);
            output.append(getStringFromStringArray(in)).append(":");
            out = (String) remoteObject.callCustomService(SecurityHandler.getBancaCodeForMapperAlignment(), "ANAG - ADDRESS", "",
                    "myobjects.ContiHost", "Contrassegni", new Object[]{in,SecurityHandler.getLoginUserId()});
            output.append(out);
            log4Debug.info("Risposta CUSTOM !!!!!!!!!!!!!!1: " , out);
            if (out.startsWith("KO") || 
            		out.indexOf("java.net.NoRouteToHostException") != -1 ||
            		out.indexOf("Servizio non attivo") != -1 ) {
                throw new MapperHelperException(getErrorMessage(out)+"�"+output.toString());
            }
        } catch(final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            throw new MapperHelperException(e.getMessage()+"�"+output.toString());
        }
        return output.toString();
    }

    private String getErrorMessage(final String erroreCod) {
        String errorMessage = null;
        if ((erroreCod.indexOf("997~Maschera errata: C3021") != -1) || (erroreCod.indexOf("997~Maschera errata: C3031") != -1) || (erroreCod.indexOf("997~Maschera errata: C3041") != -1)) {
            errorMessage = "Cliente indiretto collegato a societ�, selezionare il check 'Apertura 8 cifre host a cliente indiretto' in fondo alla pagina!";
        } else if (erroreCod.indexOf("997~Maschera errata: C0103") != -1) {
            errorMessage = "Esistono pi� nominativi a Tp con gli stessi dati anagrafici. Inviare messaggio indicando tutti i dati del cliente al casetto BS H2O Anagrafe  che provveder� al censimento o alla sistemazione del soggetto!";
        } else if ((erroreCod.indexOf("997~Maschera errata: C0302") != -1) || (erroreCod.indexOf("997~Maschera errata: C0303") != -1) || (erroreCod.indexOf("997~Maschera errata: C0402") != -1) || (erroreCod.indexOf("997~Maschera errata: C0403") != -1) || (erroreCod.indexOf("997~Maschera errata: C0502") != -1) || (erroreCod.indexOf("997~Maschera errata: C0503") != -1)) {
            errorMessage = "Esiste gi� a Tp la societ� che si sta censendo, ma non � stata migrata su H2O. Inviare messaggio indicando tutti i dati della societ� e delle persone collegate al casetto BS H2O Anagrafe che provveder� al censimento!";
        } else if ((erroreCod.indexOf("997~Maschera errata: C0208") != -1)) {
            errorMessage = "Esiste gi� a Tp la plurintestazione che si sta censendo, ma non � stata migrata su H2O. Inviare messaggio  indicando tutti i dati della plurintestazione e delle persone collegate al casetto BS H2O Anagrafe che provveder� al censimento!";
        } else if(erroreCod.indexOf("Errore -1103") != -1 || erroreCod.indexOf("java.net.NoRouteToHostException") != -1) {
			errorMessage = "Errore tecnico contattare servizi di assistenza !!!" + erroreCod;
		} else if (erroreCod.indexOf("ERR.009") != -1) {
            errorMessage = "selezionare crea otto cifre a cliente indiretto";
		} else if (erroreCod.indexOf("Servizio non attivo") != -1) {
            errorMessage = "Servizio non attivo";
		} else {
			errorMessage = erroreCod;
		}
        return errorMessage;
    }

    private ClientAdapter instanziaMapper() {
        final ClientAdapter cl = new ClientAdapter();
        cl.initMapperPoolEngine();
        return cl;
    }

    private String getStringFromStringArray(final String messages[]) {
        final StringBuffer output = new StringBuffer();
        final int arraySize = messages.length;
		output.append(messages[0]);
        for(int i=1; i<arraySize; i++,output.append("~").append(messages[i-1])) {
			;
		}
        return output.toString();
    }

}
