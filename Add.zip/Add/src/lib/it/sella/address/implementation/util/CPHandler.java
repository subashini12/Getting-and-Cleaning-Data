package it.sella.address.implementation.util;

import it.sella.casellariopostale.GestoreCasellaContiFactory;
import it.sella.casellariopostale.implementation.view.CasellarioContractView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Collection;

public class CPHandler {
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CPHandler.class);
	
	public CasellarioContractView getCPNumero(final Long productId) {
		CasellarioContractView casellarioContract = null;
		try {
			final Collection<CasellarioContractView> cpNumeroCollection = GestoreCasellaContiFactory
					.getInstance().getGestoreCasellaConti().getIdCasellaPerLinkedId(productId);
			if (cpNumeroCollection != null) {
				casellarioContract = cpNumeroCollection.iterator().next();
			}
		} catch (final Exception e) {
			log4Debug.severe(" ++++++++++++++++++ Exception Raised Trying to get nemeroconto in CP ");
			log4Debug.severeStackTrace(e);
		}
		return casellarioContract;
	}
			
}
