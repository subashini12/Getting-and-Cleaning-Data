package it.sella.address.implementation.util;

import it.sella.address.AddressView;
import it.sella.address.HelperException;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.AddressHomeInterfaceCache;
import it.sella.message.MessageException;
import it.sella.message.MessageManagerFactory;
import it.sella.util.CommonProperties;
import it.sella.util.CommonPropertiesException;
import it.sella.util.CommonPropertiesFactory;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Iterator;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

public class BaseHelper extends AddressHelper {
    
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(BaseHelper.class);

    private static AddressHomeInterfaceCache addressHomeInterfaceCache = null;
    private static Collection<String> dombkIndirizziInputsForCheck = null;
    
    public static Object getHomeObject(final String homeObjectName, final String homeClassName) throws HelperException {
        if(addressHomeInterfaceCache == null) {
			addressHomeInterfaceCache = new AddressHomeInterfaceCache();
		}
        try {
            if(!addressHomeInterfaceCache.isHomeObjectExists(homeObjectName)) {
                final Context context = new InitialContext();
                final CommonProperties commonProperties = CommonPropertiesFactory.getInstance().getCommonProperties("Address");
                final Object object = PortableRemoteObject.narrow(context.lookup(commonProperties.getProperty(homeObjectName)), Class.forName(homeClassName));
                addressHomeInterfaceCache.putHomeObject(homeObjectName,object);
            }
            return addressHomeInterfaceCache.getHomeObject(homeObjectName);
        } catch(final NamingException e) {
            log4Debug.severeStackTrace(e);
            throw new HelperException(e.getMessage());
        } catch(final CommonPropertiesException e) {
            log4Debug.severeStackTrace(e);
            throw new HelperException(e.getMessage());
        } catch(final ClassCastException e) {
            log4Debug.severeStackTrace(e);
            throw new HelperException(e.getMessage());
        } catch(final ClassNotFoundException e) {
            log4Debug.severeStackTrace(e);
            throw new HelperException(e.getMessage());
        }
    }
    
	public static AddressView checkExistsOneIPOAddress(final Collection addressViews) {
        int count = 0;
        AddressView returnAddressView = null;
        if(addressViews != null) {
            final Iterator iterator = addressViews.iterator();
            AddressView addressView = null;
            for(int i=addressViews.size(); i>0; i--) {
                addressView = (AddressView)iterator.next();
                if("IPO".equals(addressView.getCausaleTipoIndirizzo())) {
                    count++;
                    returnAddressView = addressView;
                }
            }
        }
        if(count != 1) {
        	returnAddressView = null;
		}
		return returnAddressView;
    }

	public static Collection<String> getDombkIndirizziInputForCheck() throws HelperException {
		log4Debug.debug("<<<<<<< BaseHelper : dombkIndirizziInputsForCheck :",dombkIndirizziInputsForCheck ," >>>>>");
		if(dombkIndirizziInputsForCheck == null) {
			try {
				Collection<String> bankNamesColl= new AnagrafeHandler().getListOfBankAddressNames();
				if(bankNamesColl !=null && !bankNamesColl.isEmpty()){
					dombkIndirizziInputsForCheck = bankNamesColl;
				}
			} catch (RemoteException e) {
				log4Debug.severeStackTrace(e);
				throw new HelperException(e.getMessage());
			} catch (SubSystemHandlerException e) {
				log4Debug.warnStackTrace(e);
				throw new HelperException(e.getMessage());
			} 
		}
		return dombkIndirizziInputsForCheck;
	}

    public static String getMessage(final String errorCode) {
        String errorMessage = null;
        try {
            errorMessage = MessageManagerFactory.getInstance().getMessageManagerClientImpl().getMessage(errorCode);
        } catch(final MessageException e) {
            errorMessage = e.getMessage();
        }
        return errorMessage;
    }
   
}
