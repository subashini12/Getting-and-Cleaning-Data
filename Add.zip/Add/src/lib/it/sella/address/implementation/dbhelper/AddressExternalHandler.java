package it.sella.address.implementation.dbhelper;

import it.sella.address.AddressException;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.util.AnagrafeHandler;
import it.sella.address.implementation.util.DBHelper;
import it.sella.address.implementation.util.SecurityHandler;
import it.sella.util.CommonPropertiesFactory;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

public class AddressExternalHandler {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressExternalHandler.class);

    public Integer getEsercentiPresenti(final Long soggettoId) throws AddressException, RemoteException {
        Connection connection = null;
        CallableStatement statement = null;
        try {
            connection = DBHelper.getConnection();
            statement = connection.prepareCall("{ call ? := ESERCENTI_X_IDSOGGETTO(?) }");
            statement.registerOutParameter(1,Types.INTEGER);
            statement.setLong(2,soggettoId.longValue());
            statement.execute() ;
            return Integer.valueOf(statement.getInt(1));
        } catch (final SQLException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        } finally {
            DBHelper.cleanup(connection,statement);
        }
    }

    public String getProductValues( final Long soggettoId ) throws AddressException, RemoteException {
        Connection connection = null;
        CallableStatement statement = null;
        try {
            String codiceHost = new AnagrafeHandler().getValoreCodiciSoggetto(soggettoId,"codiceHost");
            codiceHost = (codiceHost != null && codiceHost.length() > 8) ? codiceHost.substring(1,9) : codiceHost;  
            final Long bancaId = SecurityHandler.getLoginBancaSoggettoId();
            //connection = DBHelper.getConnectionFrom121("DBALIAS_FOR_ORAGP");
            final String connectionPoolName = CommonPropertiesFactory.getInstance().getCommonProperties("Address").getProperty("DBALIAS_FOR_ORAGP_DATA_POOLNAME");
            log4Debug.debug(" AddressExternalHandler : getProductValues : connectionPoolName :===>>>",connectionPoolName);
            connection = DBHelper.getConnection(connectionPoolName);
            statement = connection.prepareCall("{call SP_GET_DS_PROD_NDG(?,?,?,?,?,?,?)}");
            statement.setString(1, codiceHost);
            statement.setString(2, "1");
            statement.setString(3, "@");
            statement.setString(4, "#");
            statement.registerOutParameter(5, Types.CLOB);
            statement.registerOutParameter(6, Types.VARCHAR);
            statement.setString(7, bancaId.toString());
            statement.execute();
            final Clob products = statement.getClob(5);
            String buffer = products.getSubString(1, (int)products.length());
            final String error = statement.getString(6);
            buffer = (!error.equals("E00000")) ? "E00000" : buffer;  
            return buffer;
        } catch (final SQLException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        } catch(final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        } finally {
            DBHelper.cleanup(connection,statement);
        }
    }
}
