package it.sella.address.implementation.util;



import it.sella.address.AddressException;
import it.sella.address.implementation.NormalizedAddressStatus;
import it.sella.address.implementation.dbhelper.AddressNormalizedHelper;

public class NormalizedIndirrizoHelper {

    public NormalizedAddressStatus getNormalliza(final String nazione,final String cittaCommune,final String indirrizzo,final String provincia,final String cap,final Boolean isDOMXXCheckReq) throws AddressException {
		NormalizedAddressStatus normalizedAddressStatus = null;
		boolean isDOMCheck = false ;
		if( nazione != null && "ITALIA".equals(nazione) &&
				indirrizzo != null && indirrizzo.trim().length() > 0 &&
				indirrizzo.indexOf("C/O") == -1 && indirrizzo.indexOf("PRESSO") == -1 ) {
				isDOMCheck = isDOMXXCheckReq != null ?  isDOMXXCheckReq.booleanValue() : false ;
				if(isDOMCheck) {
					String internal = Helper.getInternalBasedOnIndirizzo(indirrizzo);//getInternalBasedOnIndirizzo(addressView.getIndirizzo());
					if(!"DOMBK".equals(internal) && !"DOMCP".equals(internal)) {
						normalizedAddressStatus = AddressNormalizedHelper.normalizeIndirrizo(nazione,cittaCommune,indirrizzo,provincia,cap);
						if(!normalizedAddressStatus.isNormalizationErrato()) {
							internal = Helper.getInternalBasedOnIndirizzo(normalizedAddressStatus.getIndirrizi());
							if("DOMBK".equals(internal)) {
								normalizedAddressStatus = setOutputForInputDetails(cittaCommune,indirrizzo,provincia,cap);
							}
						}
					} else {

						normalizedAddressStatus = setOutputForInputDetails(cittaCommune,indirrizzo,provincia,cap);

					}
				} else {
					normalizedAddressStatus = AddressNormalizedHelper.normalizeIndirrizo(nazione,cittaCommune,indirrizzo,provincia,cap);
				}
		} else {
			normalizedAddressStatus = setOutputForInputDetails(cittaCommune,indirrizzo,provincia,cap);
		}
		return normalizedAddressStatus;
	}

    private NormalizedAddressStatus setOutputForInputDetails(final String cittaCommune,final String indirrizzo,final String provincia,final String cap) {
    	final NormalizedAddressStatus normalizedAddressStatus = new NormalizedAddressStatus();
    	normalizedAddressStatus.setCap(cap);
		normalizedAddressStatus.setCittaCommune(cittaCommune);
		normalizedAddressStatus.setProvinca(provincia);
		normalizedAddressStatus.setIndirrizi(indirrizzo);
		return normalizedAddressStatus;
    }

    private NormalizedAddressStatus setOutputForInputDetails(final String cittaCommune,final String indirrizzo,final String provincia,final String cap,final String edificio,final String presso) {
    	final NormalizedAddressStatus normalizedAddressStatus = new NormalizedAddressStatus();
    	normalizedAddressStatus.setCap(cap);
		normalizedAddressStatus.setCittaCommune(cittaCommune);
		normalizedAddressStatus.setProvinca(provincia);
		normalizedAddressStatus.setIndirrizi(indirrizzo);
		normalizedAddressStatus.setEdificio(edificio);
		normalizedAddressStatus.setPresso(presso);
		return normalizedAddressStatus;
    }

    public NormalizedAddressStatus getNormallizaNew(final String nazione,final String cittaCommune,final String indirrizzo,final String provincia,final String cap,final Boolean isDOMXXCheckReq,final String edificio,final String presso) throws AddressException {
		NormalizedAddressStatus normalizedAddressStatus = null;
		boolean isDOMCheck = false ;
		if( nazione != null && "ITALIA".equals(nazione) &&
				indirrizzo != null && indirrizzo.trim().length() > 0 &&
				indirrizzo.indexOf("C/O") == -1 && indirrizzo.indexOf("PRESSO") == -1 ) {
				isDOMCheck = isDOMXXCheckReq != null ?  isDOMXXCheckReq.booleanValue() : false ;
				if(isDOMCheck) {
					String internal = Helper.getInternalBasedOnIndirizzo(indirrizzo);//getInternalBasedOnIndirizzo(addressView.getIndirizzo());
					if(!"DOMBK".equals(internal) && !"DOMCP".equals(internal)) {
						normalizedAddressStatus = AddressNormalizedHelper.normalizeIndirrizo_New(nazione,cittaCommune,indirrizzo,provincia,cap,edificio,presso);
						if(!normalizedAddressStatus.isNormalizationErrato()) {
							internal = Helper.getInternalBasedOnIndirizzo(normalizedAddressStatus.getIndirrizi());
							if("DOMBK".equals(internal)) {
								normalizedAddressStatus = setOutputForInputDetails(cittaCommune,indirrizzo,provincia,cap);
								normalizedAddressStatus.setEdificio(edificio);
								normalizedAddressStatus.setPresso(presso);
							}
						}
					} else {
						normalizedAddressStatus = setOutputForInputDetails(cittaCommune, indirrizzo, provincia, cap, edificio, presso);
					}
				} else {
					normalizedAddressStatus = AddressNormalizedHelper.normalizeIndirrizo_New(nazione,cittaCommune,indirrizzo,provincia,cap,edificio,presso);
				}
		} else {
			normalizedAddressStatus = setOutputForInputDetails(cittaCommune, indirrizzo, provincia, cap, edificio, presso);
		}
		return normalizedAddressStatus;
	}
}
