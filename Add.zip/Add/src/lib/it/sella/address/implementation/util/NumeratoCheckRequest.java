/**
 * Created by IntelliJ IDEA.
 * User: ssil72
 * Date: Jan 6, 2005
 * Time: 4:45:42 PM
 */
package it.sella.address.implementation.util;

import it.sella.security.event.SecurityRequest;

public class NumeratoCheckRequest extends SecurityRequest
{

	public String succ_conto;


    public String getSuccConto() {
        return succ_conto;
    }

    public void setSuccConto(final String succ_conto) {
        this.succ_conto = succ_conto;
    }
}
