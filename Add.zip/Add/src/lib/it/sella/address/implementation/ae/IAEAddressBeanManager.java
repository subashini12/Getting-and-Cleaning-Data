package it.sella.address.implementation.ae;

import it.sella.address.AddressException;

import javax.ejb.FinderException;

public interface IAEAddressBeanManager {

	/**
	 * Method to create AEAddress
	 * @param aeAddress
	 * @return
	 * @throws AddressException
	 */
	AEAddress create(AEAddress aeAddress) throws  AddressException;

	/**
	 * Method to update AEAddress
	 * @param addressLink
	 * @return
	 * @throws AddressException
	 */
	AEAddress update(AEAddress aeAddress) throws  AddressException;

	/**
	 * Method to remove AEAddress
	 * @param addressLink
	 */
	void remove(AEAddress aeAddress);

	/**
	 * Method to find data using primary key
	 * @param primaryKey
	 * @return
	 * @throws FinderException
	 */
	AEAddress findByPrimaryKey(Long primaryKey) throws  FinderException;

	/**
	 * Method to find data using Linked Id
	 * @param linkedId
	 * @return
	 * @throws FinderException
	 */
	AEAddress findByLinkedId(Long linkedId) throws FinderException;

}
