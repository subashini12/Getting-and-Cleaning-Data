package it.sella.address.implementation.util;

public class MapperHelperException extends Exception {

    /**
     * Default Constructor
     */
    public MapperHelperException() {
    	// explicit default constructor
    }

    public MapperHelperException(final String errorMsg) {
        super(errorMsg);
    }
}
