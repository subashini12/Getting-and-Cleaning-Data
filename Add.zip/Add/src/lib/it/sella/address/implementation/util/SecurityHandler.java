/**
 * Created by IntelliJ IDEA.
 * User: ssil72
 * Date: Jun 10, 2004
 * Time: 4:12:56 PM
 */
package it.sella.address.implementation.util;

import it.sella.address.SubSystemHandlerException;
import it.sella.security.SecurityException;
import it.sella.security.SecurityManagerFactory;
import it.sella.security.event.SecurityRequest;
import it.sella.security.event.SecurityResponse;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *  Class used to handle security calls
 */

public class SecurityHandler
{

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(SecurityHandler.class);

    /**
     * this method gets the login userid from security
     * @return String loginuserId
     * @throws SubSystemHandlerException
     */

    public static String getLoginUserId() throws SubSystemHandlerException {
        try {
            return getSecurityManager().getIdentity().getUserId();
        } catch(final SecurityException e) {
            log4Debug.severeStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * Gets the soggettoid of login bank
     * @return Long
     * @throws SubSystemHandlerException
     */

    public static Long getLoginBancaSoggettoId() throws SubSystemHandlerException {
        try {
            return getSecurityManager().getIdentity().getIdBancaProprietaria();
        } catch (final SecurityException e) {
            log4Debug.severeStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * Gets the hostcode of the login user
     * @return String
     * @throws SubSystemHandlerException
     */

    public static String getLoginUsersHostCode() throws SubSystemHandlerException {
        try {
            return getSecurityManager().getIdentity().getHostCode();
        } catch(final SecurityException e) {
            log4Debug.severeStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        } catch(final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * Gets the shorter code for Login banca denominazione
     * @return String bancacode formapper
     * @throws SubSystemHandlerException
     */

    public static String getBancaCodeForMapperAlignment() throws SubSystemHandlerException {
        String bancaCode = null;
        try {
            bancaCode = getSecurityManager().getBankPrefix(getLoginBancaSoggettoId());
            if("BS".equals(bancaCode)) {
				bancaCode = "BSE";
			}
        } catch(final SecurityException e) {
            log4Debug.severeStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        } catch(final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
        return bancaCode;
    }

    /**
     * Checks whether the operation passed as input is allowed for the login user..
     * @param operation
     * @return
     */

    public static boolean isOperationAllowed(final String operation) throws SubSystemHandlerException {
        boolean isAllowed = false;
        it.sella.security.SecurityManager securityManager = null;
        SecurityRequest securityRequest = null;
        try {
            securityManager = getSecurityManager();
            securityRequest = new SecurityRequest();
            securityRequest.setCurrentOperation(securityManager.getOperation(operation));
            final SecurityResponse securityResponse = securityManager.handle(securityRequest);
            isAllowed = securityResponse.isAllowed();
        } catch(final SecurityException e) {
            log4Debug.severeStackTrace(e);
            final String errorMsg = "Exception in isOperationAllowed for operation : "+operation;
			throw new SubSystemHandlerException(errorMsg);
        }
        log4Debug.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> THE OPERATION ",operation," IS ALLOWED : ", Boolean.valueOf(isAllowed));
        return isAllowed;
    }

    /**
     * Checks whether the given succursale is allowed for operation ccdr_operativita_numerati
     * @return boolean
     */

    public static boolean isOperationAllowedForNumerati(final String succursale) throws SubSystemHandlerException {
        boolean isAllowed = false;
        it.sella.security.SecurityManager securityManager = null;
        try {
            securityManager = getSecurityManager();
            final NumeratoCheckRequest securityRequest = new NumeratoCheckRequest();
            securityRequest.setCurrentOperation(securityManager.getOperation("ccdr_operativita_numerati"));
            securityRequest.setSuccConto(succursale);
            final SecurityResponse securityResponse = securityManager.handle(securityRequest);
            isAllowed = securityResponse.isAllowed();
        } catch(final SecurityException e) {
            log4Debug.severeStackTrace(e);
            final String errorMsg = "Exception in isOperationAllowedForNumerati for succursale : "+succursale;
			throw new SubSystemHandlerException(errorMsg);
        } catch(final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
        }
        log4Debug.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> THE OPERATION ccdr_operativita_numerati"," IS ALLOWED : ", Boolean.valueOf(isAllowed));
        return isAllowed;
    }

	/**
	 * gets the abi code of the loggedin bank
	 * @return String abicode
	 * @throws SubSystemHandlerException
	 */
	public static String getCodiceAbiBanca() throws SubSystemHandlerException {
		try {
			return getSecurityManager().getIdentity().getAbiCode();
		} catch (final SecurityException e) {
			log4Debug.severeStackTrace(e);
			throw new SubSystemHandlerException(e.getMessage());
		}
	}

	/**
	 * gets logged in branch's cdrcode
	 * @return String codiceCDR
	 * @throws SubSystemHandlerException
	 */
	public static String getCdrName() throws SubSystemHandlerException {
		try {
			return getSecurityManager().getIdentity().getCdrName();
		} catch (final SecurityException e) {
			log4Debug.severeStackTrace(e);
			throw new SubSystemHandlerException(e.getMessage());
		}
	}

	/**
	 * gets the IpAddress of the logged machine
	 * @return String IpAddress
	 * @throws SubSystemHandlerException
	 */
	public static String getUserTerminalName() throws SubSystemHandlerException {
		try {
			return getSecurityManager().getExecutionContextView().getIpAddress();
		} catch (final SecurityException e) {
			log4Debug.severeStackTrace(e);
			throw new SubSystemHandlerException(e.getMessage());
		}
	}

	/**
	 * gets the loggedin user's soggettoid
	 * @return Long soggettoid
	 * @throws SubSystemHandlerException
	 */
	public static Long getLoginSoggettoId() throws SubSystemHandlerException {
		Long loginIdSoggetto = null;
		try {
			loginIdSoggetto = getSecurityManager().getIdentity().getIdSoggetto();
			log4Debug.info(">>>>>>>>>>>>>>>>>>>>>> LOGIN SOGGETTOID :",loginIdSoggetto);
		} catch(final SecurityException e) {
			log4Debug.severeStackTrace(e);
			throw new SubSystemHandlerException(e.getMessage());
		}
		return loginIdSoggetto;
	}

    private static it.sella.security.SecurityManager getSecurityManager() throws SubSystemHandlerException,SecurityException {
        try {
            return SecurityManagerFactory.getSecurityManager(new InitialContext());
        } catch(final NamingException e) {
            log4Debug.severeStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }


}
