package it.sella.address.implementation.dbhelper;

import it.sella.address.AddressException;
import it.sella.address.implementation.util.DBHelper;
import it.sella.address.implementation.util.Helper;
import it.sella.address.implementation.util.UtilHelper;
import it.sella.address.log.LogView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class LogDBAccessHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(LogDBAccessHelper.class);
	
	public Collection getLog(final Long soggettoId) throws AddressException {
		return getLog(soggettoId, "I", "M");
	}
	
    public Collection getLogForSoggettoAndProductID(final Long soggettoId) throws AddressException {
        return getLogForSoggettoAndProductID(soggettoId,"M");
    }

    public Collection getLogDOMKO(final Long soggettoId) throws AddressException {
        return getLogForSoggettoAndProductID(soggettoId,"DOMKO");
    }

    private Collection getLogForSoggettoAndProductID( final Long soggettoId,
    		final String operationType) throws AddressException {
        if (soggettoId == null) {
        	throw new AddressException(Helper.getMessage("ANAG-1300"));	
        }
        final StringBuffer query = new StringBuffer();
        query.append("SELECT LG_CODDP, LG_DATE, LG_ACCOUNT_ID FROM ANADD_TR_LOG LG WHERE LG_SOGGETTO_ID = ? AND LG_OPERATION = ? AND LG_DATE = (SELECT MAX(LG_DATE) FROM ANADD_TR_LOG WHERE LG_SOGGETTO_ID = ? AND LG_OPERATION = ? AND LG_ACCOUNT_ID = LG.LG_ACCOUNT_ID ) AND LG_ACCOUNT_ID IS NOT NULL");
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        final List logViews = new ArrayList();
        try {
            connection = DBHelper.getConnection();
            preparedStatement = connection.prepareStatement(query.toString());
            preparedStatement.setLong(1, soggettoId.longValue());
            preparedStatement.setString(2, operationType);
            preparedStatement.setLong(3, soggettoId.longValue());
            preparedStatement.setString(4, operationType);
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()) {
                final LogView logView = new LogView();
                logView.setCodiciDipendente(resultSet.getString("LG_CODDP"));
                logView.setDateOfOperation(new Timestamp((resultSet.getDate("LG_DATE")).getTime()));
                logView.setModeOfOperation(operationType);
                logView.setSoggettoId(soggettoId);
                logView.setAccountId(UtilHelper.getLongValue(resultSet.getString("LG_ACCOUNT_ID")));
                logViews.add(logView);
            }
        } catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new AddressException(e.getMessage());
        } finally {
        	DBHelper.cleanup(connection, preparedStatement, resultSet);
        }
        return logViews;
    }
	
    private Collection getLog(final Long soggettoId, final String insertOperationCode,
    		final String modificaOperationCode) throws AddressException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        final List logViews = new ArrayList();
        try {
            connection = DBHelper.getConnection();
            preparedStatement = connection.prepareStatement("select LG_CODDP, LG_DATE from ANADD_TR_LOG where LG_SOGGETTO_ID = ? and LG_OPERATION = ? and LG_ACCOUNT_ID is null");
            preparedStatement.setLong(1, soggettoId.longValue());
            preparedStatement.setString(2, insertOperationCode);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                final LogView logView = new LogView();
                logView.setCodiciDipendente(resultSet.getString("LG_CODDP"));
                logView.setDateOfOperation(new Timestamp((resultSet.getDate("LG_DATE")).getTime()));
                logView.setModeOfOperation(insertOperationCode);
                logView.setSoggettoId(soggettoId);
                logViews.add(logView);
            }
            DBHelper.closeResultSet(resultSet);
            DBHelper.closeStatement(preparedStatement);
            preparedStatement = connection.prepareStatement("select LG_CODDP, LG_DATE from ANADD_TR_LOG where LG_SOGGETTO_ID = ? and LG_OPERATION = ? and LG_DATE = (select max(LG_DATE) from ANADD_TR_LOG where LG_SOGGETTO_ID = ? and LG_OPERATION = ? and LG_ACCOUNT_ID is null) and LG_ACCOUNT_ID is null");
            preparedStatement.setLong(1, soggettoId.longValue());
            preparedStatement.setString(2, modificaOperationCode);
            preparedStatement.setLong(3, soggettoId.longValue());
            preparedStatement.setString(4, modificaOperationCode);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                final LogView logView = new LogView();
                logView.setCodiciDipendente(resultSet.getString("LG_CODDP"));
                logView.setDateOfOperation(new Timestamp((resultSet.getDate("LG_DATE")).getTime()));
                logView.setModeOfOperation(modificaOperationCode);
                logView.setSoggettoId(soggettoId);
                logViews.add(logView);
            }
        } catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new AddressException(e.getMessage());
        } finally {
        	DBHelper.cleanup(connection, preparedStatement, resultSet);
        }
        return logViews;
    }

	public void createLog(final LogView logView) throws AddressException {
        Connection connection = null;
        PreparedStatement logStatement = null;
        try {
            connection = DBHelper.getConnection();
            logStatement = connection.prepareStatement("INSERT INTO ANADD_TR_LOG (LG_ID, LG_CODDP, LG_DATE, LG_SOGGETTO_ID, LG_OPERATION, LG_ACCOUNT_ID) VALUES (seq_loghome.nextval,?,?,?,?,?)");
            logStatement.setString(1, logView.getCodiciDipendente());
            logStatement.setTimestamp(2, logView.getDateOfOperation());
            logStatement.setLong(3, logView.getSoggettoId());
            logStatement.setString(4, logView.getModeOfOperation());
            if (logView.getAccountId() != null) {
            	logStatement.setLong(5, logView.getAccountId());
            } else {
            	logStatement.setNull(5, Types.NUMERIC);
            }
            logStatement.execute();
        } catch(final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new AddressException(e.getMessage());
        } finally {
            DBHelper.cleanup(connection, logStatement);
        }
	}
}
