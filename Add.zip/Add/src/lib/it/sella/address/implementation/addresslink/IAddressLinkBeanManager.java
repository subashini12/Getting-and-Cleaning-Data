package it.sella.address.implementation.addresslink;

import it.sella.address.AddressException;

import java.util.Collection;

import javax.ejb.FinderException;

public interface IAddressLinkBeanManager {

	/**
	 * Method to create Address Link
	 * @param addressLink
	 * @return
	 */
	AddressLink create(AddressLink addressLink) throws  AddressException;

	/**
	 * Method to update Address Link
	 * @param addressLink
	 * @return
	 */
	AddressLink update(AddressLink addressLink) throws  AddressException;

	/**
	 * Method to remove Address Link
	 * @param addressLink
	 */
	void remove(AddressLink addressLink);

	/**
	 * Method to find the data using primary key
	 * @param primaryKey
	 * @return
	 * @throws FinderException
	 */
	AddressLink findByPrimaryKey(Long primaryKey) throws  FinderException;

	/**
	 * Method to find data using soggetto and indirizzo
	 * @param soggettoId
	 * @param addressId
	 * @return
	 * @throws FinderException
	 */
	Collection<AddressLink> findBySoggettoIndirizzo(Long soggettoId, Long addressId) throws  FinderException;

	/**
	 * Method to find data using sogetto and sub system PCId
	 * @param soggettoId
	 * @param subSystemId
	 * @param pcId
	 * @return
	 * @throws FinderException
	 */
	AddressLink findBySoggettoSubsytemPCId(Long soggettoId, Long subSystemId, Long pcId) throws  FinderException;

	/**
	 * Method to find data using soggetto, sub system and TipIndirizzo
	 * @param soggettoId
	 * @param subSystemId
	 * @param tipoIndirizzo
	 * @return
	 * @throws FinderException
	 */
	AddressLink findBySoggettoSubsytemTipoIndirizzo(Long soggettoId, Long subSystemId, Long tipoIndirizzo) throws  FinderException;

	/**
	 * Method to find all data using productconto id
	 * @param soggettoId
	 * @return
	 * @throws FinderException
	 */
	Collection<AddressLink> findAllProductContoId(Long soggettoId) throws  FinderException;

	/**
	 * Method to find all data using address primary key id.
	 * @param addressPkId
	 * @return
	 * @throws FinderException
	 */
	Collection<AddressLink> findByAddressPkId(Long addressPkId) throws  FinderException;

	/**
	 * Method to find all data using soggetto id
	 * @param soggettoId
	 * @return
	 * @throws FinderException
	 */
	Collection<AddressLink> findBySoggettoId(Long soggettoId) throws  FinderException;

	 /**
     * Method to find all data using soggetto id and subsystem \PCId
     * @param soggettoId
     * @param subSystemId
     * @param pcId
     * @return
     * @throws FinderException
     */
	Collection<AddressLink> findAllBySoggettoSubsytemPCId(Long soggettoId, Long subSystemId, Long pcId) throws  FinderException;

	/**
	 * Method to find all data using Soggetto, subsystem and Tipo Indirizzo
	 * @param soggettoId
	 * @param subSystemId
	 * @param tipoIndirizzo
	 * @return
	 * @throws FinderException
	 */
	Collection<AddressLink> findAllBySoggettoSubsytemTipoIndirizzo(Long soggettoId, Long subSystemId, Long tipoIndirizzo) throws  FinderException;
}
