package it.sella.address.implementation.dbhelper;

import it.sella.address.AddressManagerBeanHelperException;
import it.sella.address.AddressView;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.util.AnagrafeHandler;
import it.sella.address.implementation.util.DBHelper;
import it.sella.address.implementation.util.Helper;
import it.sella.anagrafe.CollegamentoView;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreAnagrafeFactory;
import it.sella.anagrafe.GestoreSoggettoException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class AddressGetterHelper extends AddressBaseHelper {
	

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressGetterHelper.class);

    public AddressView getAddress( final Long soggettoId, String subSystemCausale, Long productContoId ) throws AddressManagerBeanHelperException, RemoteException {
        Connection connection = null;
        PreparedStatement addressStatement = null;
        ResultSet addressSet = null;
        AddressView addressView = null;
        try {
        	validateSoggettoIdAndProductId(soggettoId, productContoId);
            if(isSoggettoFromDBP(soggettoId)) {
        		subSystemCausale = "DBP";
        		productContoId = soggettoId;
            }
            log4Debug.debug(" AddressGetterHelper : getAddress : subSystemCausale :===>>>",subSystemCausale);
            log4Debug.debug(" AddressGetterHelper : getAddress : productContoId :===>>>",productContoId);
            connection = DBHelper.getConnection();
            final StringBuffer query = getSelectQueryForView();
            
            appendQuery(query, soggettoId, productContoId, subSystemCausale);
            final String queryStr = query.toString();
            log4Debug.debug(" AddressGetterHelper : getAddress : query :===>>>",queryStr);
            
            addressStatement = connection.prepareStatement(queryStr);
            int counter = 0;
            if( soggettoId != null ) {
            	addressStatement.setLong(++counter,soggettoId.longValue());	
            }
            if( productContoId != null ) {
            	addressStatement.setLong(++counter,productContoId.longValue());	
            }
            addressSet = addressStatement.executeQuery();
            if( addressSet.next() ) {
                addressView = getAddressViewFromResultSet(soggettoId, addressSet);
                addressView.setPostalCode(new Helper().getPostalCode(addressView));
            }
        } catch( final SQLException e ) {
            log4Debug.warnStackTrace(e);
            throw new AddressManagerBeanHelperException(e.getMessage());
        } catch ( final GestoreAnagrafeException e ) {
            log4Debug.warnStackTrace(e);
            throw new AddressManagerBeanHelperException(e.getMessage());
		} finally {
            DBHelper.cleanup(connection, addressStatement, addressSet);
        }
        return addressView;
    }

    public AddressView getDefaultPostalAddress( final Long soggettoId ) throws AddressManagerBeanHelperException, RemoteException {
        Connection connection = null;
        PreparedStatement addressStatement = null;
        ResultSet addressSet = null;
        AddressView addressView = null;
        Long soggettoIdToBeUsed = soggettoId;
        try {
        	final AnagrafeHandler anagrafeHandler = new AnagrafeHandler();
            connection = DBHelper.getConnection();
            final StringBuffer query = getSelectQueryForView();
            query.append(" AL_SOGGETTO_ID = ?  AND AL_TYPE_ADDRESS = ?");
            addressStatement = connection.prepareStatement(query.toString());
            final String tipoSoggetto = anagrafeHandler.getTiposoggetto(soggettoIdToBeUsed);
            Long tipoIndirizzo = null;
            if( tipoSoggetto != null ) {
            	if( "Semplice".equals(tipoSoggetto) ) {
                    tipoIndirizzo = getClassificazioneId("IRE", "IND");
                } else if( "Plurintestazione".equals(tipoSoggetto) ) {
                    tipoIndirizzo = getClassificazioneId("IRE", "IND");
                    final Collection coll = anagrafeHandler.getLinkedSoggetto(soggettoIdToBeUsed, "INTPR");
                    if( coll != null && !coll.isEmpty() ) {
                    	soggettoIdToBeUsed = ((CollegamentoView)coll.iterator().next()).getLinkedSoggettoId();
                    }
                } else if( "AZIENDE".equals(anagrafeHandler.getParentTipoSoggetto(soggettoIdToBeUsed)) ) {
                    tipoIndirizzo = getClassificazioneId("SLE", "IND");
                }
            	if(tipoIndirizzo != null){
            		addressStatement.setLong(1, soggettoIdToBeUsed.longValue());
                    addressStatement.setLong(2, tipoIndirizzo.longValue());
                    addressSet = addressStatement.executeQuery();
                    if( addressSet.next() ) {
                        addressView = getAddressViewFromResultSet(soggettoIdToBeUsed, addressSet);
                    }
            	}
            }
        } catch(final SQLException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressManagerBeanHelperException(e.getMessage());
        } catch(final SubSystemHandlerException e) {
            log4Debug.warnStackTrace(e);
            throw new AddressManagerBeanHelperException(e.getMessage());
        } finally {
            DBHelper.cleanup(connection, addressStatement, addressSet);
        }
        return addressView;
    }
    
	public List getAddressAlreadyUsed( final String indirizzio, final String cap, final String cittaCommune, final String provinciaSingla, final String nazione, 
			final String tipoIndirrizoCausale, final Long bankSoggettId ) throws AddressManagerBeanHelperException, RemoteException {
        Connection connection = null;
        PreparedStatement addressStatement = null;
        ResultSet addressSet = null;
		validateBankSoggettoId(bankSoggettId);
		final List soggettoList = new ArrayList(1);
		final String cittaValue = getUpperCaseIfValueNotNull(cittaCommune);
		final String provinicaValue = getUpperCaseIfValueNotNull(provinciaSingla);
        try {
            connection = DBHelper.getConnection();

            final StringBuffer query = new StringBuffer(
            			 	 " SELECT AL.AL_SOGGETTO_ID ");
	            query.append(" FROM ADD_TR_ADDRESS_LINK AL ");
            	query.append(" WHERE AL.AL_ADDRESS_ID IN ");
            	query.append("			(SELECT TA.AD_ADDRESS_ID ");
            	query.append("            FROM ADD_TR_ADDRESS TA, AN_MA_NAZIONE MN ");
            	query.append("			 WHERE TA.AD_INDIRIZZO = ? ");
            	query.append("				AND MN.NA_NOME = ? ");
            	query.append("				AND TA.AD_NAZIONE = MN.NAZIONE_ID ");
            	query.append("				AND (TA.AD_CITTA = ? OR ");
            	query.append("						TA.AD_CITTA IN ");
            	query.append("           			(SELECT TO_CHAR(C.CI_ID) ");
            	query.append("						  FROM AN_MA_CITTA C ");
            	query.append("						WHERE C.CI_COMMUNE = ? ");
            	query.append("						AND C.CI_PROVINCIA = ? ");
            	query.append("						AND NVL(C.CI_STORICO, 0) = 0)) ");
				query.append("				AND (NVL(TA.AD_PROVINCIA, '0') = NVL( ?, '0') OR ");
				query.append("			    	 TA.AD_PROVINCIA IN ");
				query.append("   				 (SELECT TO_CHAR(MP.PR_ID) ");
				query.append("			 			FROM AN_MA_PROVINCE MP ");
				query.append("			   		   WHERE MP.PR_SIGLA = ? )) ");
				query.append("				AND (( ? IS NULL AND TA.AD_CAP IS NULL AND ");
				query.append("						TA.AD_CAP_VALUE IS NULL) OR ");
				query.append("						TA.AD_CAP IN ");
				query.append("						(SELECT MC.CAP_ID FROM AN_MA_CAP MC WHERE MC.CA_CAP = ? ) OR ");
				query.append("							TA.AD_CAP_VALUE = ? )) ");
				query.append("				AND AL.AL_TYPE_ADDRESS = ");
				query.append("	    			(SELECT VC1.CL_ID ");
				query.append("						FROM CL_VW_CLASSIFICAZIONE VC1 ");
				query.append("						WHERE VC1.CL_CAUSALE = ? ) ");
				query.append("				AND EXISTS ");
				query.append("			 (SELECT 1 ");
				query.append("				FROM AN_TR_COLLAGAMENTO_SOGGETTO CS, CL_VW_CLASSIFICAZIONE VC ");
				query.append("			  WHERE CS.CL_SOGGETTO_PRINCIPALE + 0 = ? ");
				query.append("				AND VC.CL_CAUSALE = 'CENST' ");
				query.append("				AND CS.CL_MOTIVO = VC.CL_ID ");
				query.append("				AND CS.CL_DATA_FINE IS NULL ");
				query.append("				AND CS.CL_LINKED_SOGGETTO = AL.AL_SOGGETTO_ID) ");
				query.append("	AND ROWNUM < 100 ");
				
			addressStatement = connection.prepareStatement(query.toString());
			addressStatement.setString(1,getUpperCaseIfValueNotNull(indirizzio));
			addressStatement.setString(2,getUpperCaseIfValueNotNull(nazione));
			addressStatement.setString(3,cittaValue);
			addressStatement.setString(4,cittaValue);
			addressStatement.setString(5,provinicaValue);
			addressStatement.setString(6,provinicaValue);
			addressStatement.setString(7,provinicaValue);
			addressStatement.setString(8,cap);
			addressStatement.setString(9,cap);
			addressStatement.setString(10,cap);
			addressStatement.setString(11, tipoIndirrizoCausale != null ? tipoIndirrizoCausale.trim() : null);
			addressStatement.setLong(12, bankSoggettId.longValue());
			addressSet = addressStatement.executeQuery();
			
			while (addressSet.next()) {
				soggettoList.add(Long.valueOf(addressSet.getLong("AL_SOGGETTO_ID")));
			}
        } catch(final SQLException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressManagerBeanHelperException(e.getMessage());
        } finally {
            DBHelper.cleanup(connection, addressStatement, addressSet);
        }
		return soggettoList;
	}

	private void validateBankSoggettoId(final Long bankSoggettId)
			throws AddressManagerBeanHelperException {
		if( bankSoggettId == null ) {
			final String errorMsg = "BankSoggettoId null";
			throw new AddressManagerBeanHelperException(errorMsg);
		}
	}
	
	private String getUpperCaseIfValueNotNull(String value){
		if(value != null){
			value = value.trim().toUpperCase();
		}
		return value;		
	}
	
	private void validateSoggettoIdAndProductId(final Long soggettoId, final Long productContoId) throws AddressManagerBeanHelperException{
		 if( soggettoId == null && productContoId == null ) {
				throw new AddressManagerBeanHelperException("Both soggettoId and ContoId is null: Atleast one should has the value");	
         }
	}
	
	private boolean isSoggettoFromDBP(final Long soggettoId) throws GestoreSoggettoException, RemoteException{
		boolean result = false;
		if( soggettoId != null ) {
        	final String tipoSoggetto = GestoreAnagrafeFactory.getInstance().getGestoreAnagrafe().getTipoSoggetto(soggettoId);
        	log4Debug.debug(" AddressGetterHelper : getAddress : tipoSoggetto :===>>>",tipoSoggetto);
        	if( "Succursale".equals(tipoSoggetto) || "Ufficio interno".equals(tipoSoggetto) ) {
        		result = true;
        	}
		}
		return result;
	}
	
	private void appendQuery(final StringBuffer query, final Long soggettoId, Long productContoId, String subSystemCausale) throws RemoteException, AddressManagerBeanHelperException {
		if( soggettoId != null ) {
            query.append(" AL_SOGGETTO_ID = ? ");
            if( productContoId != null ) {
                query.append(" AND AL_LINKED_ID = ? ");
            } else {
                query.append(" AND AL_LINKED_ID IS NULL ");
            }
        } else if( productContoId != null ) {
        	query.append(" AL_LINKED_ID = ? ");
        }
        if( subSystemCausale != null ) {
            query.append(" AND AL_TYPE_SUBSYSTEM = ").append(getClassificazioneId(subSystemCausale, "SUBSYS"));
        }
	}
}
