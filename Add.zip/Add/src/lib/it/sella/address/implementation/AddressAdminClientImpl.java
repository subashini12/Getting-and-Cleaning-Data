package it.sella.address.implementation;

import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.address.HelperException;
import it.sella.address.implementation.addr.Address;
import it.sella.address.implementation.addresslink.AddressLink;
import it.sella.address.implementation.addresslink.AddressLinkView;
import it.sella.address.implementation.ae.AEAddress;
import it.sella.address.implementation.util.Helper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.Handle;
import javax.naming.NamingException;
import javax.persistence.EntityManager;

public class AddressAdminClientImpl implements IAddressAdmin {


	private transient AddressAdmin addressAdmin = null;
    private Handle addressAdminHandle = null;

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAdminClientImpl.class);

	public void createAddress(final AddressView addressView) throws AddressException, RemoteException {
		getAddressAdminImpl().createAddress(addressView);

	}

	public void setAddress(final boolean modifyAllProductConto, final AddressView addressView) throws AddressException, RemoteException {
		getAddressAdminImpl().setAddress(modifyAllProductConto,addressView);
	}

    public void deleteAddress(final Long operationId, final Long addressId) throws RemoteException, AddressException {
		getAddressAdminImpl().deleteAddress(operationId,addressId);

	}

	public void deleteAddressAE(final Long operationId, final Long addressAELinkId) throws RemoteException, AddressException {
		getAddressAdminImpl().deleteAddressAE(operationId,addressAELinkId);

	}

	public void deleteAddressLink(final Long operationId, final Long addressLinkId) throws RemoteException, AddressException {
		getAddressAdminImpl().deleteAddressLink(operationId,addressLinkId);

	}

	public void updateAddressAdmin(final Long addressPrimaryKey, final AddressView addressView) throws RemoteException, AddressException {
		getAddressAdminImpl().updateAddressAdmin(addressPrimaryKey,addressView);

	}

	public void updateAddressAEAdmin(final Long addressAEPrimaryKey, final AddressView addressView) throws RemoteException, AddressException {
		getAddressAdminImpl().updateAddressAEAdmin(addressAEPrimaryKey,addressView);

	}

	public void updateAddressLinkAdmin(final Long addressLinkPrimaryKey, final AddressLinkView addressLinkView) throws RemoteException, AddressException {
		getAddressAdminImpl().updateAddressLinkAdmin(addressLinkPrimaryKey,addressLinkView);

	}

	public void updateAnagrafeLog(final Long operationId, final Long soggettoId, final String errorMessage) throws RemoteException, AddressException {
		getAddressAdminImpl().updateAnagrafeLog(operationId,soggettoId,errorMessage);

	}

	public NormalizedAddressStatus normalizeIndirrizo(final String nazione,final String cittaCommune,final String indirrizzo,final String provincia,final String cap,final Boolean isDOMXXCheckReq) throws AddressException, RemoteException {
		return getAddressAdminImpl().normalizeIndirrizo(nazione,cittaCommune,indirrizzo,provincia,cap,isDOMXXCheckReq);
	}
	public AddressLink createAddressLink(final AddressLink addressLink) throws AddressException,RemoteException{
		return getAddressAdminImpl().createAddressLink(addressLink);
	}

	public AEAddress createAEAddress(final AEAddress aeAddress) throws AddressException,RemoteException{
		return getAddressAdminImpl().createAEAddress(aeAddress);
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.IAddressAdmin#createAddr(it.sella.address.implementation.addr.AddressView)
	 */
	public Address createEntityAddress(final it.sella.address.implementation.addr.AddressView addressView) throws RemoteException, AddressException{
		return getAddressAdminImpl().createEntityAddress(addressView);
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.IAddressAdmin#getPersistenceEntityManager()
	 */
	public EntityManager getPersistenceEntityManager() throws NamingException,RemoteException, AddressException{
		return getAddressAdminImpl().getPersistenceEntityManager();
	}
	private AddressAdmin getAddressAdminImpl() throws AddressException, RemoteException {
        try {
            if(addressAdmin == null && addressAdminHandle == null) {
            	addressAdmin = getAddressAdminImplHome().create();
            	addressAdminHandle = addressAdmin.getHandle();
            } else if (addressAdmin  == null && addressAdminHandle != null) {
            	addressAdmin = (AddressAdmin) addressAdminHandle.getEJBObject();
            }
        } catch(final CreateException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        }
        return addressAdmin;
    }

    private AddressAdminHome getAddressAdminImplHome() throws AddressException
    {
        try {
            return  ((AddressAdminHome)Helper.getHomeObject("ADDRESSADMINHOMENAME", "it.sella.address.implementation.AddressAdminHome"));
        } catch(final HelperException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        }
    }

	public NormalizedAddressStatus normalizeIndirrizo(final String nazione,	final String cittaCommune, final String indirrizzo, final String provincia,	final String cap, final Boolean isDOMXXCheckReq, final String edificio, final String presso)
			throws AddressException, RemoteException {
		return getAddressAdminImpl().normalizeIndirrizo(nazione, cittaCommune, indirrizzo, provincia, cap, isDOMXXCheckReq, edificio, presso);
	}


}
