package it.sella.address.implementation;

import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.address.HelperException;
import it.sella.address.IAddressManager;
import it.sella.address.egon.view.EgonView;
import it.sella.address.implementation.util.Helper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.List;

import javax.ejb.CreateException;
import javax.ejb.Handle;

public class AddressManagerClientImpl implements IAddressManager {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressManagerClientImpl.class);

    private transient AddressManager addressManager = null;
    private Handle addressManagerHandle = null;

    public void createAddress ( final AddressView addressView ) throws AddressException, RemoteException {
        getAddressManagerImpl().createAddress(addressView );
    }

    public void setAddress (  final boolean modifyAllProductConto, final AddressView addressView ) throws AddressException, RemoteException {
        getAddressManagerImpl().setAddress(modifyAllProductConto,addressView );
    }

    public AddressView getAddress( final Long soggettoId, final String subSystemCl, final Long pcId ) throws AddressException, RemoteException {
        return getAddressManagerImpl().getAddress(soggettoId,subSystemCl,pcId);
    }

    public Collection listAddress( final Long soggettoId, final String subSystemCl ) throws AddressException, RemoteException {
        return getAddressManagerImpl().listAddress(soggettoId,subSystemCl);
    }

    public Collection listAddressSoggetto( final Long soggettoId ) throws AddressException, RemoteException {
        return getAddressManagerImpl().listAddressSoggetto(soggettoId);
    }

    public AddressView getDefaultPostalAddress( final Long soggettoId ) throws AddressException, RemoteException {
        return getAddressManagerImpl().getDefaultPostalAddress(soggettoId);
    }

    public AddressView validateAddress ( final String xml ) throws AddressException, RemoteException {
        return getAddressManagerImpl().validateAddress(xml);
    }

    public void updateSoggetto ( final Long oldSoggettoId, final Long newSoggettoId ) throws AddressException, RemoteException {
        getAddressManagerImpl().updateSoggetto(oldSoggettoId,newSoggettoId);
    }

    public void updateSoggetto ( final Long oldSoggettoId, final Long newSoggettoId, final Long opId ) throws AddressException, RemoteException {
        getAddressManagerImpl().updateSoggetto(oldSoggettoId,newSoggettoId, opId);
    }

    public boolean isCompatibleIndirizzo( final String subSystemCl, final String tipoIndirizzoCl ) throws AddressException, RemoteException {
        return getAddressManagerImpl().isCompatibleIndirizzo(subSystemCl,tipoIndirizzoCl);
    }

    public String getPostalAddress(final Long soggettoId, final Long productId, final String subSystemCausale) throws AddressException, RemoteException {
        return getAddressManagerImpl().getPostalAddress(soggettoId,productId,subSystemCausale);
    }

    public String getPostalAddressInXMLFormat(final Long soggettoId, final Long productId, final String subSystemCausale) throws AddressException, RemoteException {
        return getAddressManagerImpl().getPostalAddressInXMLFormat(soggettoId,productId,subSystemCausale);
    }

    public String getPostalAddress(final Long soggettoId, final Long productId,final String subSystemCausale, final String intestazione, final Long errorCode) throws AddressException, RemoteException {
        return getAddressManagerImpl().getPostalAddress(soggettoId, productId, subSystemCausale, intestazione, errorCode);
    }

    public String getPostalAddressInXMLFormat(final Long soggettoId, final Long productId,final String subSystemCausale, final String intestazione, final Long errorCode) throws AddressException, RemoteException {
        return getAddressManagerImpl().getPostalAddressInXMLFormat(soggettoId, productId, subSystemCausale, intestazione, errorCode);
    }

    public void modificaInternal(final Collection addressViews) throws AddressException,RemoteException {
        getAddressManagerImpl().modificaInternal(addressViews);
    }

	public void gestoreAccountAddress(final String tredeciCifre,final String valore, final String hostUserCode) throws AddressException, RemoteException {
        getAddressManagerImpl().gestoreAccountAddress(tredeciCifre,valore,hostUserCode);
	}

	public NormalizedAddressStatus normalizeIndirrizo(final String nazione,final String cittaCommune,final String indirrizzo,final String provincia,final String cap,final Boolean isDOMXXCheckReq) throws AddressException, RemoteException {
		return getAddressManagerImpl().normalizeIndirrizo(nazione,cittaCommune,indirrizzo,provincia,cap,isDOMXXCheckReq);
	}

	public void setDOMOL(final Long soggettoId, final Long productId,final String subSystemCausale) throws AddressException, RemoteException {
		getAddressManagerImpl().setDOMOL(soggettoId,productId,subSystemCausale);
	}

	public void removeDOMOL(final Long soggettoId, final Long productId,final String subSystemCausale) throws AddressException, RemoteException {
		getAddressManagerImpl().removeDOMOL(soggettoId,productId,subSystemCausale);
	}

	public void removeProductAddress(final Long soggettoId,final String subSystemCausale, final Long productId) throws AddressException, RemoteException {
		getAddressManagerImpl().removeProductAddress(soggettoId,subSystemCausale,productId);
	}

	public List getAddressAlreadyUsed(final String indirizzio, final String cap,
			final String cittaCommune, final String provinciaSingla, final String nazione, final String tipoIndirrizoCausale, final Long bankSoggettId)
			throws AddressException, RemoteException {
		return getAddressManagerImpl().getAddressAlreadyUsed(indirizzio, cap, cittaCommune, provinciaSingla, nazione, tipoIndirrizoCausale, bankSoggettId);
	}

    public String getPostalAddressInXMLFormat(final Long soggettoId, final Long productId,
    		final String subSystemCausale, final String bypassCode) throws AddressException, RemoteException {
    	return getAddressManagerImpl().getPostalAddressInXMLFormat(soggettoId, productId,
    			subSystemCausale, bypassCode);
    }

    public String getPostalAddress(final Long soggettoId, final Long productId,
    		final String subSystemCausale, final String intestazione,
    		final Long errorCode, final String bypassCode) throws AddressException, RemoteException {
    	return getAddressManagerImpl().getPostalAddress(soggettoId, productId,
    			subSystemCausale, intestazione, errorCode, bypassCode);
    }

    public String getPostalAddressInXMLFormat(final Long soggettoId, final Long productId,
    		final String subSystemCausale, final String intestazione,
    		final Long errorCode, final String bypassCode) throws AddressException, RemoteException {
    	return getAddressManagerImpl().getPostalAddressInXMLFormat(soggettoId, productId,
    			subSystemCausale, intestazione, errorCode, bypassCode);
    }

    /* (non-Javadoc)
     * @see it.sella.address.IAddressManager#swapProductAddressPerSoggetto(java.lang.Long, java.lang.Long, java.lang.String, java.lang.Long)
     */
    public void swapProductAddressPerSoggetto(final Long oldSoggettoId,final Long newSoggettoId,final String subSystemCausale ,final Long productId) throws AddressException, RemoteException{
    	getAddressManagerImpl().swapProductAddressPerSoggetto(oldSoggettoId, newSoggettoId,subSystemCausale, productId);
    }

    /*public String getPostalAddressInXMLFormat(final Long soggettoId,final Long productId,
    		final String subSystemCausale,final String intestazione, final Long errorCode,
			final String bypassCode, final String skipDomolCheck)throws AddressException, RemoteException {
		return getAddressManagerImpl().getPostalAddressInXMLFormat(soggettoId,productId, subSystemCausale,
				intestazione, errorCode,bypassCode,skipDomolCheck);
	}

    public String getPostalAddress(final Long soggettoId,final Long productId,
    		final String subSystemCausale,final String intestazione, final Long errorCode,
			final String bypassCode, final String skipDomolCheck)throws AddressException, RemoteException {
		return getAddressManagerImpl().getPostalAddress(soggettoId,productId, subSystemCausale,
				intestazione, errorCode,bypassCode,skipDomolCheck);
	}*/


	/*
     * (non-Javadoc)
     * @see it.sella.address.IAddressManager#validateAddressWithThrowError(java.lang.String)
     */
    public AddressView validateAddressWithThrowError ( final String xml ) throws AddressException, RemoteException {
    	return getAddressManagerImpl().validateAddressWithThrowError(xml);
    }

    private AddressManager getAddressManagerImpl() throws AddressException, RemoteException {
        try {
            if(addressManager == null && addressManagerHandle == null) {
                addressManager = getAddressManagerImplHome().create();
                addressManagerHandle = addressManager.getHandle();
            } else if (addressManager == null && addressManagerHandle != null) {
                addressManager = (AddressManager) addressManagerHandle.getEJBObject();
            }
        } catch(final CreateException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        }
        return addressManager;
    }

    private AddressManagerHome getAddressManagerImplHome() throws AddressException
    {
        try {
            return  (AddressManagerHome)Helper.getHomeObject("ADDMANAGERHOMENAME","it.sella.address.implementation.AddressManagerHome");
        } catch(final HelperException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        }
    }

	public NormalizedAddressStatus normalizeIndirrizo(final String nazione,final String cittaCommune, final String indirrizzo, final String provincia,
			final String cap, final Boolean isDOMXXCheckReq, final String edificio, final String presso)
			throws AddressException, RemoteException {
		return getAddressManagerImpl().normalizeIndirrizo(nazione, cittaCommune, indirrizzo, provincia, cap, isDOMXXCheckReq, edificio, presso);
	}

	public Collection<EgonView> getProvincia(final String cap, final String nazione, final String provincia) throws AddressException, RemoteException {
		return getAddressManagerImpl().getProvincia(cap, nazione, provincia);
	}

	public Collection<EgonView> getCitta(final String cap, final String citta, final String nazione, final String provincia) throws AddressException, RemoteException {
		return getAddressManagerImpl().getCitta(cap, citta, nazione, provincia);
	}

	public Collection<EgonView> getCapWithProvincia(final String cap) throws AddressException, RemoteException {
		return getAddressManagerImpl().getCapWithProvincia(cap);
	}

	public Collection<EgonView> getIndrizzi(final String cap, final String citta,final String nazione, final String provincia, final String indrizzi) throws AddressException, RemoteException {
		return getAddressManagerImpl().getIndrizzi(cap, citta, nazione, provincia, indrizzi);
	}

	public Collection<EgonView> getNazione(String nazione) throws AddressException, RemoteException {
		return getAddressManagerImpl().getNazione(nazione);
	}


}
