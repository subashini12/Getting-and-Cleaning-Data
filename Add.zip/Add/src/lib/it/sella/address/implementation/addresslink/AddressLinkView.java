package it.sella.address.implementation.addresslink;


public class AddressLinkView  implements AddressLink
{

	public Long getAddressLinkId() {
		return addressLinkId;
	}

	public void setAddressLinkId(final Long addressLinkId) {
		this.addressLinkId = addressLinkId;
	}

    public Long getSubSystem()
    {
        return subSystem;
    }

    public void setSubSystem(final Long subSystem)
    {
        this.subSystem = subSystem;
    }

    public Long getAddressType()
    {
        return addressType;
    }

    public void setAddressType(final Long addressType)
    {
        this.addressType = addressType;
    }

    public Long getLinkedId()
    {
        return linkedId;
    }

    public void setLinkedId(final Long linkedId)
    {
        this.linkedId = linkedId;
    }

    public Long getSoggettoId()
    {
        return soggettoId;
    }

    public void setSoggettoId(final Long soggettoId)
    {
        this.soggettoId = soggettoId;
    }

    public Long getAddressId()
    {
        return addressId;
    }

    public void setAddressId(final Long addressId)
    {
        this.addressId = addressId;
    }

	public Long getOpId() {
		return this.opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}

	private Long addressLinkId;
    private Long subSystem;
    private Long addressType;
    private Long linkedId;
    private Long soggettoId;
    private Long addressId;
    private Long opId;

}
