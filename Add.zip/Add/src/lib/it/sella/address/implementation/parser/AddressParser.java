package it.sella.address.implementation.parser;

import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.egon.common.EgonUtil;
import it.sella.address.implementation.util.AnagrafeHandler;
import it.sella.address.implementation.util.ClassificazioneHandler;
import it.sella.anagrafe.ICapView;
import it.sella.anagrafe.ICittaView;
import it.sella.anagrafe.INazioneView;
import it.sella.anagrafe.IProvinciaView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;


public class AddressParser implements ContentHandler {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressParser.class);

    AddressView addressView = null;
    String tipoIndirizzo;
    String indirizzo = null;
    String provincia = null;
    String cap = null;
    String cittaValue = null;
    boolean isValid = true;
    ICittaView cittaView = null;
    String errorMessage = null;
    StringBuffer elementValueBuffer = new StringBuffer();

    String presso = null;
    String edificio = null;

    public void characters(final char[] ch, final int start, final int length) throws SAXException {
        /* for(int i = start; i < start + length; i++) {
            elementValue += (ch[i]);
        } */
        elementValueBuffer.append(ch,start,length);
    }

    public AddressView getAddressView() {
    	AddressView addressViewLocal = null;
        if(isValid) {
        	addressViewLocal = addressView;
		}
		return addressViewLocal;
    }

    public void endDocument() throws SAXException {
    	// Nothing to check
    }

    public void endElement(final String namespaceURI, final String localName, final String qName) throws SAXException {
        final AnagrafeHandler anagrafeHandler = new AnagrafeHandler();
        try {
        	final String elementValue = elementValueBuffer.toString();
            if("TIPO_INDIRIZZO".equals(localName)) {
                tipoIndirizzo = elementValue;
            } else if("INDIRIZZO".equals(localName)) {
                indirizzo = elementValue.trim().toUpperCase();
            } else if("PROVINCIA".equals(localName)) {
                if(elementValue != null) {
					provincia = elementValue.toUpperCase();
				}
            } else if("CAP".equals(localName)) {
                cap = elementValue;
            } else if("CITTA".equals(localName)) {
                if(elementValue != null) {
					cittaValue = elementValue.toUpperCase();
				}
            } else if("NAZIONE".equals(localName)) {
                try {
                    final Map searchCriteria = new Hashtable();
                    searchCriteria.put("NA_NOME", elementValue.toUpperCase());
                    final Collection nazioneColl = anagrafeHandler.getNazione(searchCriteria);
                    if(nazioneColl != null) {
                        final Iterator nazioneIterator = nazioneColl.iterator();
                        addressView.setNazioneView((INazioneView) nazioneIterator.next());
                    }
                    if(addressView.getNazioneView() == null) {
                    	errorMessage = "Nazione Non Valida";
                        throw new AddressException();
                    }
                    if((tipoIndirizzo == null || tipoIndirizzo.length() == 0) || (indirizzo == null || indirizzo.length() == 0)) {
                    	errorMessage = "Tipo Indirizzo / indirizzo Obbligatorio";
                        throw new AddressException();
                    }
                    if(indirizzo.indexOf('(') != -1 || indirizzo.indexOf(')') != -1 || indirizzo.indexOf('^') != -1 ||
                    		indirizzo.indexOf('&') != -1 ) {
                    	errorMessage = "Non Sono Ammessi i Caratteri ( e ) e ^";
                        throw new AddressException();
                    }
                    if(cittaValue.indexOf('(') != -1 || cittaValue.indexOf(')') != -1 || cittaValue.indexOf('^') != -1 ||
                    		cittaValue.indexOf('&') != -1 ) {
                    	errorMessage = "Non Sono Ammessi i Caratteri ( e ) e ^";
                        throw new AddressException();
                    }
                    if("ITALIA".equalsIgnoreCase(elementValue)) {
                        ICapView capView = null;
                        checkForDummyString(cap,"Cap Obbligatorio");
                        checkForDummyString(provincia,"Provincia Obbligatoria");
                        if(!anagrafeHandler.isValidCittaCommune(cittaValue)) {
                        	errorMessage = "Citta non Valida";
                            throw new AddressException();
                        }
                        if(!anagrafeHandler.isValidProvinciaSigla(provincia)) {
                        	errorMessage = "Provincia Non Valida";
                            throw new AddressException();
                        }
                        if(anagrafeHandler.isValidProvinciaForSiglaAndCittaCommune(provincia, cittaValue)) {
                            if(anagrafeHandler.isValidCittaForProvincia(cittaValue, provincia)) {
                                cittaView = anagrafeHandler.getCitta(cittaValue, provincia);
                                provincia = cittaView.getProvincia();
                            } else {
                            	errorMessage = "Provincia Non Valida";
                            	throw new AddressException();
                            }
                        } else {
                        	errorMessage = "Provincia Non Valida";
                            throw new AddressException();
                        }
                        if(!"".equals(cap)) {
                            try {
                                if(cap.length() == 5) {
                                	Long.valueOf(cap);
								} else {
                                	errorMessage = "Cap Non Valido";
                                    throw new AddressException();
                                }
                            } catch(final NumberFormatException nx) {
                            	log4Debug.warnStackTrace(nx);
                            	errorMessage = "Cap Non Valido";
                                throw new AddressException();
                            }
                            if(anagrafeHandler.isValidCapForProvincia(cap, cittaView.getProvincia())) {
                                capView = anagrafeHandler.getCapviewForCapcodeAndCittacommune(cap, cittaValue);
                            } else {
                            	errorMessage = "Cap Non Valido";
                                throw new AddressException();
                            }
                        }
                        final IProvinciaView provinciaView = anagrafeHandler.getProvinciaViewForSigla(provincia);
                        addressView.setCittaView(cittaView);
                        addressView.setNazione(elementValue);
                        addressView.setProvinciaView(provinciaView);

                        addressView.setCapView(capView);
                        addressView.setCap(cap);
                        addressView.setCitta(cittaValue);
                    } else if(!"ITALIA".equalsIgnoreCase(elementValue)) {
                        addressView.setCitta(cittaValue);
                        addressView.setProvincia(provincia);
                        addressView.setNazione(elementValue);
                        addressView.setCap(cap);
                    }
                    if("IPO".equals(tipoIndirizzo)) {
                        addressView.setFrequency(ClassificazioneHandler.getClassificazioneView("GIORN","AN_FREQ").getId());
                        addressView.setReserved(0L);
//                        addressView.setInternal(Helper.validateInternalValue(indirizzo));
                    }
                    addressView.setIndirizzo(indirizzo);
                    addressView.setTipoIndirrizo(ClassificazioneHandler.getClassificazioneView(tipoIndirizzo, "IND").getId());
                    addressView.setCausaleTipoIndirizzo(tipoIndirizzo);
                } catch(final AddressException e) {
                	log4Debug.warnStackTrace(e);
                	if(errorMessage == null) {
						errorMessage = e.getMessage();
					}
                    isValid = false;
                } catch(final SubSystemHandlerException e) {
                	log4Debug.warnStackTrace(e);
                	if(errorMessage == null) {
						errorMessage = e.getMessage();
					}
                    isValid = false;
                }
            }
            //Added for the EGON Migration
            setAddressValues(localName, elementValue.toUpperCase());
            elementValueBuffer.setLength(0);
        } catch(final RemoteException exception) {
        	log4Debug.warnStackTrace(exception);
            throw new SAXException(exception);
        }
    }

    public void endPrefixMapping(final String s) throws SAXException {
    	//Nothing to check
    }

    public void ignorableWhitespace(final char[] chars, final int i, final int i1) throws SAXException {
    	//Nothing to check
    }

    public void processingInstruction(final String s, final String s1) throws SAXException {
    	//Nothing to check
    }

    public void setDocumentLocator(final Locator locator) {
    	// Nothing to check
    }

    public void skippedEntity(final String s) throws SAXException {
    	// Nothing to check
    }

    public void startDocument() throws SAXException {
        addressView = new AddressView();
    }

    public void startElement(final String s, final String s1, final String s2, final Attributes attributes) throws SAXException {
    	elementValueBuffer.setLength(0);
    }

    public void startPrefixMapping(final String s, final String s1) throws SAXException {
    	//Nothing to Check
    }

    private void checkForDummyString(final String value,final String error) throws AddressException {
    	if("".equals(value)) {
    		errorMessage = error;
    		throw new AddressException();
    	}
    }

    public String getErrorMessage() {
    	log4Debug.warn("############# error msg in addressparser:",errorMessage);
    	return errorMessage;
    }

    /**
     *Method to store Edificio and Presso after Egon migration for the Address table
     * @param xmlTagName
     * @param xmlValue
     * @throws AddressException
     */
    private void setAddressValues (final String xmlTagName,final String xmlValue) {
    	try {
    		if("PRESSO".equalsIgnoreCase(xmlTagName)) {
    			isValidValue(xmlValue,"Presso");
    			addressView.setPresso(xmlValue);
    		} else if("EDIFICIO".equalsIgnoreCase(xmlTagName)) {
    			isValidValue(xmlValue,"Edificio");
    			addressView.setEdificio(xmlValue);
    		}
    	} catch(final AddressException e) {
    		log4Debug.warnStackTrace(e);
    		if(errorMessage == null) {
    			errorMessage = e.getMessage();
    		}
    		isValid = false;
    	}
    }

   private void isValidValue(final String value,final String fieldName) throws AddressException {
	   if (!EgonUtil.isEmpty(value) && EgonUtil.checkIsValidString(value,45)) {
		   errorMessage = fieldName +" Non Valid";
           throw new AddressException();
	   }
   }
}
