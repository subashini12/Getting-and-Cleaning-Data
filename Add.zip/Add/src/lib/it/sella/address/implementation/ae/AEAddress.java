package it.sella.address.implementation.ae;

import java.io.Serializable;


public interface AEAddress extends Serializable  {

	public Long getAeAddressId();

	public void setAeAddressId(Long aeAddressId);

	public Long getReserved();

    public void setReserved(Long reserved);

    public Long getFrequency();

    public void setFrequency(Long frequency);

    public Long getInternal();

    public void setInternal(Long internal);

    public Long getAddressLinkId();

    public void setAddressLinkId(Long addressLinkId);

    public Long getOpId();

    public void setOpId(Long opId);
}
