package it.sella.address.implementation.factory;

import it.sella.address.AddressException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;


public class ReflectionUtil {
	
private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(ReflectionUtil.class);
	
    public static Object  newInstance(final String loadingClassName) throws AddressException {
        try {
            return Class.forName(loadingClassName).newInstance();

        } catch (final ClassNotFoundException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        } catch (final InstantiationException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        } catch (final IllegalAccessException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        }
    }
    
    public static Object  createServiceImplInstance(final String bundleKey, final String daoImplKey) throws AddressException {
		Object daoImplObj = null;
		@SuppressWarnings("rawtypes")
		Class partypes[] = null;
		try {
			daoImplObj = newInstance(ResourceFinder.getString(bundleKey, daoImplKey));
			partypes = new Class[1];
			partypes[0] = Object.class;
			return daoImplObj;
		} catch (final SecurityException e) {
			log4Debug.severeStackTrace(e);
			throw new AddressException(e.getMessage());
		} catch (final IllegalArgumentException e) {
			log4Debug.severeStackTrace(e);
			throw new AddressException(e.getMessage());
		}
	}

}
