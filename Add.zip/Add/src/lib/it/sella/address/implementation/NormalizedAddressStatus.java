package it.sella.address.implementation;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

public class NormalizedAddressStatus implements Serializable {


	public Collection getAmbigui() {
		return ambigui;
	}
	public void setAmbigui(final Collection normAmbiguiView) {
		this.ambigui = normAmbiguiView;
	}
	public String getCap() {
		return cap;
	}
	public void setCap(final String cap) {
		this.cap = cap;
	}
	public String getIndirrizi() {
		return indirrizi;
	}
	public void setIndirrizi(final String indirrizi) {
		this.indirrizi = indirrizi;
	}
	public String getProvinca() {
		return provinca;
	}
	public void setProvinca(final String provinca) {
		this.provinca = provinca;
	}

	public String getCittaCommune() {
		return cittaCommune;
	}

	public void setCittaCommune(final String cittaCommune) {
		this.cittaCommune = cittaCommune;
	}

	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(final String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public boolean isAmbiguityExists() {
		return ambiguityExists;
	}
	public void setAmbiguityExists(final boolean isAmbiguityExists) {
		this.ambiguityExists = isAmbiguityExists;
	}
	public boolean isNormalizationErrato() {
		return normalizationErrato;
	}
	public void setNormalizationErrato(final boolean isNormalizationWrong) {
		this.normalizationErrato = isNormalizationWrong;
	}

	/**
	 * @return the provincaSigla
	 */
	public String getProvincaSigla() {
		return provincaSigla;
	}
	/**
	 * @param provincaSigla the provincaSigla to set
	 */
	public void setProvincaSigla(String provincaSigla) {
		this.provincaSigla = provincaSigla;
	}
	/**
	 * @return the nazioneNome
	 */
	public String getNazioneNome() {
		return nazioneNome;
	}
	/**
	 * @param nazioneNome the nazioneNome to set
	 */
	public void setNazioneNome(String nazioneNome) {
		this.nazioneNome = nazioneNome;
	}
	/**
	 * @return the presso
	 */
	public String getPresso() {
		return presso;
	}
	/**
	 * @param presso the presso to set
	 */
	public void setPresso(String presso) {
		this.presso = presso;
	}
	/**
	 * @return the edificio
	 */
	public String getEdificio() {
		return edificio;
	}
	/**
	 * @param edificio the edificio to set
	 */
	public void setEdificio(String edificio) {
		this.edificio = edificio;
	}

	/**
	 * @return the normalizationWarningErrato
	 */
	public boolean isNormalizationWarningErrato() {
		return normalizationWarningErrato;
	}
	/**
	 * @param normalizationWarningErrato the normalizationWarningErrato to set
	 */
	public void setNormalizationWarningErrato(boolean normalizationWarningErrato) {
		this.normalizationWarningErrato = normalizationWarningErrato;
	}
	/**
	 * @return the failureMessage
	 */
	public List<String> getFailureMessage() {
		return failureMessage;
	}
	/**
	 * @param failureMessage the failureMessage to set
	 */
	public void setFailureMessage(List<String> failureMessage) {
		this.failureMessage = failureMessage;
	}
	/**
	 * @return the warningMessage
	 */
	public List<String> getWarningMessage() {
		return warningMessage;
	}
	/**
	 * @param warningMessage the warningMessage to set
	 */
	public void setWarningMessage(List<String> warningMessage) {
		this.warningMessage = warningMessage;
	}

	private String indirrizi;
	private String cap;
	private String provinca;
	private Collection ambigui;
	private String cittaCommune;

	private boolean normalizationErrato;
	private boolean ambiguityExists;
	private String errorMessage;
	//Added for EGON Migration
	private String provincaSigla;
	private String nazioneNome;
	private String presso;
	private String edificio;
	private boolean normalizationWarningErrato;
    private List<String> failureMessage;//0 -> ok 1 -> CNL Error  2 -> STR Error
    private List<String> warningMessage;

}
