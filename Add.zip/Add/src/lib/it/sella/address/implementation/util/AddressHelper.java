package it.sella.address.implementation.util;

import it.sella.address.AddressConstants;
import it.sella.address.AddressView;
import it.sella.address.SubSystemHandlerException;
import it.sella.dbpersonale.DBPersonaleException;
import it.sella.dbpersonale.DBPersonaleFactory;
import it.sella.statemachine.ExecuteResult;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Map;

public class AddressHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressHelper.class);

    public static void setDataToElencoAddress(final Long soggettoId, final ExecuteResult executeResult, final Collection indirizzoViewCollection, final Map addressSession) {
        setDataForExecuteResult(AddressConstants.ADDR_COLL, indirizzoViewCollection, executeResult);
        setDataForExecuteResult(AddressConstants.ADDR_NUMERO_CONTOS, addressSession.get(AddressConstants.ADDR_NUMERO_CONTOS), executeResult);
        setDataForExecuteResult(AddressConstants.ADDR_TIPO_CONTOS, addressSession.get(AddressConstants.ADDR_TIPO_CONTOS), executeResult);
        setDataForExecuteResult(AddressConstants.ADDR_STATUS_CONTOS, addressSession.get(AddressConstants.ADDR_STATUS_CONTOS), executeResult);
        setDataForExecuteResult(AddressConstants.INTESTAZIONESTRING, addressSession.get(AddressConstants.INTESTAZIONESTRING), executeResult);
        setDataForExecuteResult(AddressConstants.LOG_DATAS, addressSession.get(AddressConstants.LOG_DATAS), executeResult);
        setDataForExecuteResult(AddressConstants.INTERNAL_TYPES, addressSession.get(AddressConstants.INTERNAL_TYPES), executeResult);
        setDataForExecuteResult(AddressConstants.LOG_DOMKO, addressSession.get(AddressConstants.LOG_DOMKO), executeResult);
        setDataForExecuteResult(AddressConstants.ADDR_SOGGETTO_ID, soggettoId, executeResult);
    }

    public String getPostalCode(final AddressView addressView) throws RemoteException {
    	String postalCode = null;
        if (addressView.getIndirizzo() == null || addressView.getCitta() == null || addressView.getNazione() == null) {
			postalCode = "AC00" ;
		} else if ("ITALIA".equals(addressView.getNazione()) && addressView.getCap() == null) {
			postalCode = "AC00" ;
		} else if (addressView.getIndirizzo().indexOf("MANCANTE") == -1 && addressView.getCitta().indexOf("MANCANTE") == -1 && addressView.getNazione().indexOf("MANCANTE") == -1) {
            try {
                if (addressView.getInternal() != null && !"0".equals(addressView.getInternal().toString())) {
                    Collection principalIds = null;
                    try {
                        //principalIds = new AnagrafeHandler().getPrincipalSoggettos(addressView.getSoggettoId(),"DIPEN");
                        principalIds = DBPersonaleFactory.getInstance().getDBPersonale().listPrincipaleOrganisationUnits(addressView.getSoggettoId(),"DIPEN");
                    } catch (final DBPersonaleException e) {
                    	log4Debug.info("!!!!!!!!!!!!!!!!!!! Exception caught just to check logical flow ... Not an error");
					}
                    
                    final String internalValue = ClassificazioneHandler.getClassificazioneView(addressView.getInternal()).getCausale();
                    if ("DOMBK".equals(internalValue)) {
                        if(principalIds != null && !principalIds.isEmpty()) {
							postalCode = "AA04";
						} else {
							postalCode = "AA01";
						}
                    } else if ("DOMCP".equals(internalValue)) {
                        if(principalIds != null && !principalIds.isEmpty()) {
							postalCode = "AA04";
						} else {
							postalCode = "AA02";
						}
                    } else if ("DOMDG".equals(internalValue)) {
                        if(principalIds != null && !principalIds.isEmpty()) {
							postalCode = "AA04";
						} else {
							postalCode = "AA03";
						}
                    } else if ("DOMNO".equals(internalValue)) {
                    	postalCode = "XX07";
                    }
                } else if (addressView.getReserved() != null && addressView.getReserved().intValue() == 1) {
					postalCode = "AA05";
				} else if ("SVIZZERA".equals(addressView.getNazione())) {
					postalCode = "AB07";
				} else if (!"ITALIA".equals(addressView.getNazione()) && addressView.getNazioneView() != null) {
                    if ("1".equals(addressView.getNazioneView().getContinente())) {
						postalCode = "AB08";
					} else if ("0".equals(addressView.getNazioneView().getContinente())) {
						postalCode = "AB09";
					}
                } else {
                	postalCode = "AA06";
                }
            } catch(final SubSystemHandlerException e) {
                log4Debug.severeStackTrace(e);
            }
        } else {
            postalCode = "AC00";
        }
        return postalCode;
    }
    
    public static String getCodiceHostEightDigitFormat( final String codiceHost) {
    	String CodiceHostEightDigit = null;
    	if(codiceHost != null && codiceHost.trim().length() > 0 ) {
    		final String[] codiceArray = codiceHost.split("\\;");
    		if(codiceArray != null && codiceArray.length > 0) {
    			final int codiceSize = codiceArray.length;
    			String token = null;
    			for(int i=0; i<codiceSize; i++) {
    				token = codiceArray[i];
    				if(token != null && token.trim().length() > 0) {
    					token = token.trim();
    					if('0' == token.charAt(0)) {
    						CodiceHostEightDigit = token.substring(1);
    						break;
    					}      					
    				}
    			}
    		}
    	}
    	return CodiceHostEightDigit;
    }


    private static void setDataForExecuteResult(final String key, final Object value, final ExecuteResult executeResult) {
        if (value != null) {
			executeResult.setAttribute(key, value);
		}
    }
}
