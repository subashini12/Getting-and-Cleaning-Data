package it.sella.address.implementation.parser;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;

public class AddressServiceParser implements ContentHandler {

	private String elementValue;
    private String methodName;
    private String soggettoValue;
    private String subSystemCl;
    private String productContoValue;
    private String motivValue;
    private String modifyAllPC;

    // The method which will returning the parsed value
    public String getMethodName()
    {
        return methodName;
    }

    public Long getSoggettoId()
    {
    	Long soggettoIdL = null;
        if(soggettoValue != null) {
        	soggettoIdL = Long.valueOf(soggettoValue);
		}
		return soggettoIdL;
    }

    public String getSubSystem()
    {
        return subSystemCl;
    }

    public Long getProductContoId()
    {
    	Long prodValL = null;
        if(productContoValue != null) {
        	prodValL = Long.valueOf(productContoValue);
		}
		return prodValL;
    }

    public String getMotiv()
    {
        return motivValue;
    }

    public boolean isModifyAllPC()
    {
        return Boolean.valueOf(modifyAllPC);
    }

    public void characters(final char[] ch, final int start, final int length) throws SAXException
    {
        for (int i = start; i < start + length; i++)
        {
            elementValue += (ch[i]);
        }
    }

    
    /* (non-Javadoc)
     * @see org.xml.sax.ContentHandler#endDocument()
     */
    public void endDocument() throws SAXException
    { // Nothing to check
    }

    public void endElement(final String namespaceURI, final String localName, final String qName) throws SAXException
    {
        if ("METHODNAME".equals(localName))
        {
            methodName = elementValue;
        }
        else if("SOGGETTOID".equals(localName))
        {
            soggettoValue = elementValue;
        }
        else if("SUBSYSTEMCL".equals(localName))
        {
            subSystemCl = elementValue;
        }
        else if("PRODUCTCONTOID".equals(localName))
        {
            productContoValue = elementValue;
        }
        else if("MOTIV".equals(localName))
        {
            motivValue = elementValue;
        }
        else if("MODIFYALLPC".equals(localName))
        {
            modifyAllPC = elementValue;
        }
        elementValue = "";
    }

    public void endPrefixMapping(final String s) throws SAXException
    {// Nothing to check
    }

    public void ignorableWhitespace(final char[] chars, final int i, final int i1) throws SAXException
    {// Nothing to check
    }

    public void processingInstruction(final String s, final String s1) throws SAXException
    {// Nothing to check
    }

    public void setDocumentLocator(final Locator locator)
    {// Nothing to check
    }

    public void skippedEntity(final String s) throws SAXException
    {// Nothing to check
    }

    public void startDocument() throws SAXException
    {// Nothing to check

    }

    public void startElement(final String s, final String s1, final String s2, final Attributes attributes) throws SAXException
    {
        elementValue = "";
    }

    public void startPrefixMapping(final String s, final String s1) throws SAXException
    {// Nothing to check
    }

}
