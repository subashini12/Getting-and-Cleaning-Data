package it.sella.address.implementation.addresslink;

import java.io.Serializable;

public interface AddressLink extends Serializable{

	public Long getAddressLinkId();

	public void setAddressLinkId(Long addressLinkId);

	public Long getSubSystem();

	public void setSubSystem(Long subSystem);

	public Long getAddressType();

	public void setAddressType(Long addressType);

	public Long getLinkedId();

	public void setLinkedId(Long linkedId);

	public Long getSoggettoId();

	public void setSoggettoId(Long soggettoId);

	public Long getAddressId();

	public void setAddressId(Long addressId);

	public Long getOpId();

	public void setOpId(Long opId);
}
