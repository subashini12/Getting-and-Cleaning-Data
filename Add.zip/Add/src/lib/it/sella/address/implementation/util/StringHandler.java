package it.sella.address.implementation.util;

import org.apache.commons.lang.StringEscapeUtils;

public class StringHandler {

	public static String encodeXMLTagValue(final String data){
		return StringEscapeUtils.escapeXml(data); 
	}

	public boolean checkForEquality(final Object oldValue, final Object newValue) {
		boolean equalityCheck = true;
	   	if(oldValue != null && newValue != null) {
	   		equalityCheck = oldValue.equals(newValue);
	   	} else if(oldValue != null || newValue != null) {
	   		equalityCheck = false;
		}
		return equalityCheck;
	}
	
}
