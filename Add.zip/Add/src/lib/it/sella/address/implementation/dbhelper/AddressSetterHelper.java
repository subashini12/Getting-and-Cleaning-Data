package it.sella.address.implementation.dbhelper;

import it.sella.address.AddressConstants;
import it.sella.address.AddressException;
import it.sella.address.AddressManagerBeanHelperException;
import it.sella.address.AddressManagerMapperException;
import it.sella.address.AddressManagerValidatorException;
import it.sella.address.AddressView;
import it.sella.address.implementation.addresslink.AddressLink;
import it.sella.address.implementation.addresslink.AddressLinkView;
import it.sella.address.implementation.util.AddressHelper;
import it.sella.address.implementation.util.CommonPropertiesUtil;
import it.sella.address.implementation.util.MapperHelper;
import it.sella.address.implementation.util.MapperHelperException;
import it.sella.address.implementation.util.UtilHelper;
import it.sella.anagrafe.GestoreAnagrafeFactory;
import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.logserver.LoggerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import javax.ejb.FinderException;

public class AddressSetterHelper extends AddressSetterBaseHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressSetterHelper.class);
	private static final String WARN_MSG_TO_LOG = "This exception is just caught not to affect the parent transaction !!!!!";
	

    public void setAddress( final boolean modifyAllProductConto, final AddressView addressView ) throws AddressManagerValidatorException ,RemoteException, AddressManagerMapperException {
        AddressLink addressLink = null;
        Long subSystemId = null;
        Long tipoIndirizzoId = null;
        final String logOperation = "ADDR-VARI";
        String operationResult = "FAILURE";
        final StringBuffer logForHost = new StringBuffer();
        String errorMessage = null;
        Long operationId = null;
        final AddressLogHelper addressLogHelper = new AddressLogHelper();
        final StringBuffer oldAddressViewLogger = new StringBuffer();
        try {
    		operationId = addressView.getOpId() == null ? addressLogHelper.logAddressOperation(logOperation, addressView, null, modifyAllProductConto) : addressView.getOpId();
            subSystemId = getClassificazioneId(addressView.getCausaleSubsystem(), AddressConstants.SUBSYS);
            Collection addrLinkCollection = null;

            if( isCompatibleIndirizzo(addressView.getCausaleSubsystem(), addressView.getCausaleTipoIndirizzo()) ) {
                tipoIndirizzoId = addressView.getTipoIndirrizo() != null ? addressView.getTipoIndirrizo() : getClassificazioneId(addressView.getCausaleTipoIndirizzo(), "IND");
                try {
               		validateAddressTypeInProductID(addressView);
               	    //Product Address (nazione) can not be different from the address (Nazione) of residence or domicile For PF
            		validateNazioneWithIREIDONazione(addressView);
                    if( modifyAllProductConto ) {
                        addrLinkCollection = getAddressLinkHome().findAllProductContoId(addressView.getSoggettoId());
                    } else if( !"ANAG".equals(addressView.getCausaleSubsystem()) && addressView.getProductContoId() == null ) {
                    	errorMessage = "PRODUCT/CONTO ID IS NOT AVAILABLE";
                        throw new AddressManagerBeanHelperException(errorMessage);
                    } else if ( addressView.getProductContoId() != null && addressView.getSoggettoId() != null &&
                    			addressView.getCausaleSubsystem() != null ) {
                        try {
                            addressLink = getAddressLinkHome().findBySoggettoSubsytemPCId(addressView.getSoggettoId(), subSystemId, addressView.getProductContoId());
                        } catch (final FinderException e) {
                        	checkFinderExceptionForDuplicate(e.getMessage());
                            addressLink = getAddressLinkRemoteFromCollection(getAddressLinkHome().findAllBySoggettoSubsytemPCId(addressView.getSoggettoId(), subSystemId, addressView.getProductContoId()));
                        }
                    } else {
                        try {
                            addressLink = getAddressLinkHome().findBySoggettoSubsytemTipoIndirizzo(addressView.getSoggettoId(), subSystemId, tipoIndirizzoId);
                        } catch (final FinderException e) {
                        	checkFinderExceptionForDuplicate(e.getMessage());
                            addressLink = getAddressLinkRemoteFromCollection(getAddressLinkHome().findAllBySoggettoSubsytemTipoIndirizzo(addressView.getSoggettoId(), subSystemId, tipoIndirizzoId));
                        }
                    }
                } catch( final FinderException e ) {
                    final AddressLinkView addressLinkView = new AddressLinkView();
                    addressView.setOpId(operationId);
                    addressLinkView.setAddressId(createAddr(addressView, operationId));
                    addressLinkView.setAddressType(tipoIndirizzoId);
                    addressLinkView.setSoggettoId(addressView.getSoggettoId());
                    addressLinkView.setSubSystem(subSystemId);
                    addressLinkView.setLinkedId(addressView.getProductContoId());
                    addressLinkView.setOpId(operationId);
                    try {
                        addressLink = getAddressLinkHome().create(addressLinkView);
                    } catch(final AddressException ceexception) {
                        log4Debug.severeStackTrace(ceexception);
                        throw new AddressManagerBeanHelperException(ceexception.getMessage());
                    }
                }
                final Long acfwId = getClassificazioneId("ACFW",AddressConstants.SUBSYS);
                final Long caeId = getClassificazioneId("CAE",AddressConstants.SUBSYS);
                final Long cpderId = getClassificazioneId("CPDER",AddressConstants.SUBSYS);
                final Long cassalarioPotaleId = getClassificazioneId("DOMCP","AEADD");
                final boolean isHostAllowed = new CommonPropertiesUtil().isHostAllowedForLoginBank();
                final MapperHelper mapperHelper = new MapperHelper();
                if( addrLinkCollection != null ) {
                	final Iterator linkIterator = addrLinkCollection.iterator();
                	AddressLink productAddressLink = null;
                    for( int i = addrLinkCollection.size(); i > 0; i-- ) {
                        productAddressLink = (AddressLink)linkIterator.next();
                        if( !caeId.equals(productAddressLink.getSubSystem()) &&
                        		!cpderId.equals(productAddressLink.getSubSystem()) &&
                        		(!cassalarioPotaleId.equals(new AddressGetterHelper().getAddress(
                        				addressView.getSoggettoId(),
                        				getClassificazioneCausale(productAddressLink.getSubSystem()),
                        				productAddressLink.getLinkedId()).getInternal()))) {
                            addressView.setProductContoId(productAddressLink.getLinkedId());
                            if( addressView.getProductContoId() != null && acfwId.equals(productAddressLink.getSubSystem()) ) {
                                final Map contoCharacteristics = getContoCharacteristics(addressView.getProductContoId());
                                log4Debug.warn(" AddressSetterHelper : setAddress : CODICE_ESTERNO : >>",contoCharacteristics.get("CODICE_ESTERNO"));
                                log4Debug.warn(" AddressSetterHelper : setAddress : DATA_CHIUSURA : >>",contoCharacteristics.get("DATA_CHIUSURA"));
                                addressView.setNch((String)contoCharacteristics.get("CODICE_ESTERNO"));
                                //Added this Line to get the Old Data for Logger for TUTTI ACFW
                                oldAddressViewLogger.append(addressLogHelper.setAddressView4Logger(addressView.getSoggettoId(), getClassificazioneCausale(productAddressLink.getSubSystem()), productAddressLink.getLinkedId()));
                                setAddress(productAddressLink, addressView, operationId);
                                if( addressView.getNch() != null &&
                                		contoCharacteristics.get("DATA_CHIUSURA") == null && isHostAllowed) {
                                	logForHost.append("^").append(mapperHelper.aggiornaIndirizzo(addressView,null));
                                }
                            } else {
                            	//Added this Line to get the Old Data for Logger
                            	oldAddressViewLogger.append(addressLogHelper.setAddressView4Logger(addressView.getSoggettoId(), getClassificazioneCausale(productAddressLink.getSubSystem()), productAddressLink.getLinkedId()));
                                setAddress(productAddressLink, addressView, operationId);
                            }
                        }
                    }
                } else {
                	//Added this Line to get the Old Data for Logger for Single Address Modification
                	oldAddressViewLogger.append(addressLogHelper.setAddressView4Logger(addressView.getSoggettoId(), getClassificazioneCausale(addressLink.getSubSystem()), addressLink.getLinkedId()));
                    setAddress(addressLink, addressView, operationId);
                    //The mapper call for address should be called at the end of the method.
                    //Whether aligned with Host or not, the flow(address will be SET) will be SUCCESS
                    if( addressView.getNch() != null && isHostAllowed ) {
                        logForHost.append(mapperHelper.aggiornaIndirizzo(addressView,null));
                    }
                }
            }
            operationResult = "SUCCESS";
        } catch( final MapperHelperException e ) {
        	operationResult = "SUCCESS";
			log4Debug.severeStackTrace(e);
			final StringTokenizer tokenizer = new StringTokenizer(e.getMessage(),"�");
           // errorMessage = tokenizer.nextToken();
			logForHost.append(tokenizer.hasMoreTokens() ? tokenizer.nextToken() : "");
            throw new AddressManagerMapperException(e.getMessage());
        } catch( final LoggerException e ) {
			log4Debug.severeStackTrace(e);
			final StringTokenizer tokenizer = new StringTokenizer(e.getMessage(),"�");
            errorMessage = tokenizer.nextToken();
			logForHost.append(tokenizer.hasMoreTokens() ? tokenizer.nextToken() : "");
            throw new AddressManagerValidatorException(errorMessage);
        } catch (final AddressManagerBeanHelperException e) {
        	log4Debug.severeStackTrace(e);
            errorMessage = e.getMessage();
            throw new AddressManagerValidatorException(errorMessage);
		} finally {
        	final StringBuffer logMessage = new StringBuffer(new AddressLogHelper().getLogData(addressView,modifyAllProductConto));
        	//To append Old data Logger
        	logMessage.append(UtilHelper.getTag("DATA_OLD", oldAddressViewLogger.toString()));
        	log4Debug.debug("OLD DATA",oldAddressViewLogger);
            String codiceHost = null;
	        try {
	        	codiceHost = AddressHelper.getCodiceHostEightDigitFormat(GestoreAnagrafeFactory.getInstance().getGestoreAnagrafe().getValoreCodiciSoggetto(addressView.getSoggettoId(),"codiceHost"));
			} catch (final GestoreCodiciSoggettoException e) {
	            log4Debug.severeStackTrace(e);
				log4Debug.warn(WARN_MSG_TO_LOG);
			} catch (final RemoteException e) {
	            log4Debug.severeStackTrace(e);
				log4Debug.warn(WARN_MSG_TO_LOG);
			}
			//To append Old data Logger
	        logMessage.append(UtilHelper.getTag("DATA_NEW", new AddressLogHelper().getLogDataFromAddressView(addressView)));
            log4Debug.debug("LOGGER WITH NEW DATA",logMessage);
            try {
				new AddressLogHelper().logMessageWithErrorMsg(addressView.getSoggettoId(),"ADDRESS MODIFICATION", logMessage.toString(), logOperation, operationResult, codiceHost,errorMessage);
			} catch (final AddressManagerBeanHelperException e) {
				errorMessage = e.getMessage();
				log4Debug.severeStackTrace(e);
				throw new AddressManagerValidatorException(errorMessage);
			}
            try {
            	addressLogHelper.updateAddressLog(operationId, addressView.getSoggettoId(), errorMessage);
			} catch (final LoggerException e) {
				log4Debug.severe(WARN_MSG_TO_LOG);
				log4Debug.warnStackTrace(e);
			}
            try {
            	if( addressView.getOpId() == null ) {
            		addressLogHelper.logAddressOpDetails(operationId, logForHost.toString(), "");
            	}
			} catch (final LoggerException e) {
				log4Debug.severe(WARN_MSG_TO_LOG);
				log4Debug.warnStackTrace(e);
			}
        }
    }
}
