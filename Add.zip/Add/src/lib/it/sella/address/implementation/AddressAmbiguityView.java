package it.sella.address.implementation;

import java.io.Serializable;

public class AddressAmbiguityView implements Serializable {
	
	public String getDugVia() {
		return dugVia;
	}
	public void setDugVia(final String dugVia) {
		this.dugVia = dugVia;
	}
	public String getLocalita() {
		return localita;
	}
	public void setLocalita(final String locaLoca) {
		this.localita = locaLoca;
	}
	public String getNomeVia() {
		return nomeVia;
	}
	public void setNomeVia(final String nomeVia) {
		this.nomeVia = nomeVia;
	}
	public String getProvincia() {
		return provincia;
	}
	public void setProvincia(final String provLoca) {
		this.provincia = provLoca;
	}
	public String getOnlyNum() {
		return onlyNum;
	}
	public void setOnlyNum(final String onlyNum) {
		this.onlyNum = onlyNum;
	}
	
	private String provincia;
	private String localita;
	private String dugVia;
	private String nomeVia;
	private String onlyNum;
	
}

