package it.sella.address.implementation.util;

import it.sella.address.AddressException;
import it.sella.address.HelperException;
import it.sella.address.SubSystemHandlerException;
import it.sella.classificazione.ClassificazioneFactory;
import it.sella.classificazione.ClassificazioneView;
import it.sella.classificazione.FactoryManager;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.ExecuteResultFactory;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;

import javax.ejb.CreateException;
import javax.naming.NamingException;

public class Helper extends BaseHelper {

    
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(Helper.class);

    public static Collection getCompatibleInternalAddressesType() throws AddressException,RemoteException {
       try {
            final ClassificazioneFactory classificazioneFactory  = FactoryManager.getClassificazioneFactory();
            final ClassificazioneView classificazioneView  = classificazioneFactory.getClassificazione("AEADD", 0L, 0L);
            return classificazioneFactory.listClassificazioni(0L, classificazioneView.getId());
        } catch(final NamingException ne) {
            log4Debug.severeStackTrace(ne);
            throw new AddressException(ne);
        } catch(final CreateException ce) {
            log4Debug.severeStackTrace(ce);
            throw new AddressException(ce);
        }
    }

    public static ExecuteResult getExecuteResult(final String transition) {
        return ExecuteResultFactory.getInstance().getExecuteResult(transition);
    }

    public static String getInternalBasedOnIndirizzo(final String indirizzo) throws AddressException {
    	String internalCausale = null;
    	try {
    		final Collection<String> dombkInputs = getDombkIndirizziInputForCheck();
    		if(dombkInputs!=null && !dombkInputs.isEmpty()){
    			for (String inputToCheck : dombkInputs) {
    				if (getNormalisedIndirizzo(indirizzo).indexOf(inputToCheck) != -1) {
    					internalCausale = "DOMBK";
    					break;
    				}
    			}
    		}
    		if (internalCausale == null) {
    			internalCausale = "DOMOR";
    		}
    	} catch (final HelperException e) {
    		log4Debug.warnStackTrace(e);
    		throw new AddressException(e.getMessage());
    	}
    	return internalCausale;
    }
    
    private static String getNormalisedIndirizzo(final String indirizzo) {
        final StringBuffer output = new StringBuffer();
        if(indirizzo != null && indirizzo.length() > 0) {
            final int size = indirizzo.length();
            for(int i=0; i<size; i++) {
                final char ch = indirizzo.charAt(i);
                if(ch != '/' && ch != '\\' && ch != '-' && ch != ' ' && ch != '.') {
					output.append(ch);
				}
            }
        }
        return output.toString();
    }

	public static Long validateInternalValue(final String indirizzo) throws AddressException,SubSystemHandlerException,RemoteException {
		final String internalCausale = Helper.getInternalBasedOnIndirizzo(indirizzo);
		boolean isDomiciliatoAllowed = false;
		try {
			isDomiciliatoAllowed = SecurityHandler.isOperationAllowed("DOMICILIATO_ALLOWED");
		} catch (final Exception e) {
			log4Debug.warnStackTrace(e);
		}
		if(!isDomiciliatoAllowed && "DOMBK".equals(internalCausale)) {
			throw new AddressException(Helper.getMessage("ADDR-0001"));
		}
		return ClassificazioneHandler.getClassificazioneView(internalCausale,"AEADD").getId();
	}
    
}
