/**
 * Created by IntelliJ IDEA.
 * User: SSIL72
 * Date: Oct 29, 2003
 * Time: 5:36:03 PM
 * To change this template use Options | File Templates.
 */
package it.sella.address.implementation.util;

import it.sella.connection.Connection121;
import it.sella.sql.DataSourceFactory;
import it.sella.sql.DataSourceFactoryException;
import it.sella.util.CommonPropertiesFactory;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collection;
import java.util.Iterator;

import javax.sql.DataSource;

public class DBHelper {

   
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DBHelper.class);

    /**
     * To establish Connection to db instances other than weblogic_dba.
     * @param key
     * @return Connection
     * @throws SQLException
     */

    public static Connection getConnectionFrom121( final String key ) throws SQLException{
        final String alias = CommonPropertiesFactory.getInstance().getCommonProperties("Address").getProperty(key);
        return Connection121.getConn(alias);
    }

    
    /**
     * Establishes the connection to the db
     * @param connectionData
     * @return Connection
     * @throws SQLException
     */

    public static Connection getConnection( final String connectionData ) throws SQLException {
        try {
            final DataSource dataSource = DataSourceFactory.getInstance().getDataSource(connectionData);
            return dataSource.getConnection();
        } catch (final DataSourceFactoryException exception) {
            log4Debug.severeStackTrace(exception);
            throw new SQLException(exception.getLocalizedMessage());
        }
    }

    /**
     * This establishes the connection to the db with the default data source
     * @return Connection
     * @throws SQLException
     */

    public static Connection getConnection() throws SQLException {
        try {
            final DataSource dataSource = DataSourceFactory.getInstance().getDataSource();
            return dataSource.getConnection();
        } catch (final DataSourceFactoryException exception) {
            log4Debug.severeStackTrace(exception);
            throw new SQLException(exception.getLocalizedMessage());
        }
    }

    /**
     * To clese the statement and resultset objects
     * @param connection
     * @param statement
     */

    public static void cleanup( final Connection connection, final Statement statement ) {
        closeStatement(statement);
        closeConnection(connection);
    }

    /**
     * To clese the statement and resultset objects and the connection
     * @param connection
     * @param statement
     * @param resultSet
     */
    public static void cleanup(final Connection connection, final PreparedStatement statement, final ResultSet resultSet) {
        closeResultSet(resultSet);
        closeStatement(statement);
        closeConnection(connection);
    }

    /**
     * closes the statement
     * @param statement
     */

    public static void closeStatement( final Statement statement ) {
        if( statement != null ) {
            try {
                statement.close();
            } catch(final SQLException e) {
                log4Debug.severeStackTrace(e);
            }
        }
    }

    /**
     * closes the resultSet objects
     * @param resultSet
     */

    public static void closeResultSet( final ResultSet resultSet ) {
        if( resultSet != null ) {
            try {
                resultSet.close();
            } catch(final SQLException e) {
                log4Debug.severeStackTrace(e);
            }
        }
    }

    /**
     * closes the connection
     * @param connection
     */

    public static void closeConnection( final Connection connection ) {
        try {
            if( connection != null && !connection.isClosed() ) {
                connection.close();
            }
        } catch(final SQLException e) {
            log4Debug.severeStackTrace(e);
        }
    }

    /**
     * closes a collection of resultsetobjects, statement object and the connection
     * @param connection
     * @param statement
     * @param resultSetColl
     */

    public static void cleanup( final Connection connection, final Statement statement, final Collection resultSetColl ) {
        if ( resultSetColl != null ) {
            final Iterator resultSetIterator = resultSetColl.iterator();
            ResultSet resultSet = null;
            for ( int i = resultSetColl.size(); i > 0; i-- ) {
                resultSet = (ResultSet) resultSetIterator.next();
                closeResultSet(resultSet);
            }
        }
        closeStatement(statement);
        closeConnection(connection);
    }
}
