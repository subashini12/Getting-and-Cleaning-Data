package it.sella.address.implementation;

import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.address.implementation.addr.Address;
import it.sella.address.implementation.addresslink.AddressLink;
import it.sella.address.implementation.addresslink.AddressLinkView;
import it.sella.address.implementation.ae.AEAddress;

import java.io.Serializable;
import java.rmi.RemoteException;

import javax.naming.NamingException;
import javax.persistence.EntityManager;

public interface IAddressAdmin extends Serializable {



    public void createAddress (AddressView addressView) throws AddressException, RemoteException;

    public void setAddress(boolean modifyAllProductConto, AddressView addressView) throws AddressException, RemoteException;

    public void deleteAddressAE(Long operationId,Long addressAELinkId)throws RemoteException, AddressException ;

    public void deleteAddressLink(Long operationId,Long addressLinkId)throws RemoteException, AddressException;

    public void deleteAddress(Long operationId,Long addressId)throws RemoteException, AddressException;

    public void updateAddressAEAdmin(Long addressAEPrimaryKey, AddressView addressView) throws RemoteException, AddressException;

    public void updateAddressLinkAdmin(Long addressLinkPrimaryKey, AddressLinkView addressLinkView) throws RemoteException, AddressException ;

    public void updateAddressAdmin(Long addressPrimaryKey, AddressView addressView) throws RemoteException, AddressException;

    public void updateAnagrafeLog(Long operationId, Long soggettoId, String errorMessage)throws  RemoteException, AddressException;

    public NormalizedAddressStatus normalizeIndirrizo(String nazione,String cittaCommune,String indirrizzo,String provincia,String cap,Boolean isDOMXXCheckReq) throws AddressException, RemoteException;

    public AddressLink createAddressLink(AddressLink addressLink) throws AddressException,RemoteException;

    public AEAddress createAEAddress(AEAddress aeAddress) throws AddressException,RemoteException;

    /**
     * Method to create Address
     * @param addressView
     * @return
     * @throws AddressException
     * @throws RemoteException
     */
    public Address createEntityAddress(it.sella.address.implementation.addr.AddressView addressView) throws AddressException,RemoteException;

    /**
     * Method to create reference for Entity Manager
     * @return
     * @throws AddressException
     * @throws NamingException
     * @throws RemoteException
     */
    public EntityManager getPersistenceEntityManager() throws AddressException,NamingException,RemoteException;

    /**
     * New Method for Address normlization After EGON migration
     * @param nazione
     * @param cittaCommune
     * @param indirrizzo
     * @param provincia
     * @param cap
     * @param isDOMXXCheckReq
     * @param edificio
     * @param presso
     * @return
     * @throws AddressException
     * @throws RemoteException
     */
    public NormalizedAddressStatus normalizeIndirrizo(final String nazione,final String cittaCommune, final String indirrizzo, final String provincia, final String cap, final Boolean isDOMXXCheckReq, final String edificio, final String presso) throws AddressException, RemoteException;

}
