package it.sella.address.implementation.dbhelper;

import it.sella.address.AddressException;
import it.sella.address.AddressManagerBeanHelperException;
import it.sella.address.AddressView;
import it.sella.address.implementation.addresslink.AddressLink;
import it.sella.address.implementation.addresslink.IAddressLinkBeanManager;
import it.sella.address.implementation.ae.AEAddress;
import it.sella.address.implementation.ae.AEAddressView;
import it.sella.address.implementation.ae.IAEAddressBeanManager;
import it.sella.address.implementation.factory.ReflectionUtil;
import it.sella.address.implementation.util.StringHandler;
import it.sella.logserver.LoggerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Iterator;

import javax.ejb.FinderException;

public class AddressAEHelper extends AddressBaseHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAEHelper.class);

    public void modificaInternal(final Collection addressViews) throws AddressManagerBeanHelperException, RemoteException {
        String errorMessage = null;
        Long operationId = null;
        Long soggettoId = null;
        final AddressLogHelper addressLogHelper = new AddressLogHelper();
        try {
        	final IAddressLinkBeanManager addressLinkBeanManager  = (IAddressLinkBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.AddressLink");
            Long subSystemId = null;
            final IAEAddressBeanManager aeAddressBeanManager = (IAEAddressBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.AEAddress");
			final Long domkoId = getClassificazioneId("DOMKO","AEADD");
            final Iterator addressViewsIterator = addressViews.iterator();
            AddressView addressView = null;
            Collection addrLinkCollection = null;
            final int contoSize = addressViews.size();
            for (int j=0;j<contoSize;j++) {
                addressView = (AddressView) addressViewsIterator.next();
            	soggettoId = addressView.getSoggettoId();
            	if(operationId == null) {
            		operationId = addressView.getOpId() != null ?
            				addressView.getOpId() : addressLogHelper.logAddressOperation("ADDR-API-INT-MOD",addressView, null, false);
            	}
                subSystemId = getClassificazioneId(addressView.getCausaleSubsystem(),"SUBSYS");
                addrLinkCollection = addressLinkBeanManager.findAllBySoggettoSubsytemPCId(addressView.getSoggettoId(),subSystemId, addressView.getProductContoId());
                final Iterator linkIterator = addrLinkCollection.iterator();
                final int size = addrLinkCollection.size();
                for (int i=0;i<size;i++) {
                    final AddressLink addressLink = (AddressLink) linkIterator.next();
                    try {
                        final AEAddress aeAddress = aeAddressBeanManager.findByLinkedId(addressLink.getAddressLinkId());
                        if(!new StringHandler().checkForEquality(addressView.getInternal(), aeAddress.getInternal())) {
                        	aeAddress.setInternal(addressView.getInternal());
                        	aeAddress.setOpId(operationId);
                        	aeAddressBeanManager.update(aeAddress);
                        }
                    } catch (final FinderException e) {
                        log4Debug.warnStackTrace(e);
                        final AEAddressView aeView = new AEAddressView();
                        aeView.setAddressLinkId(addressLink.getAddressLinkId());
                        aeView.setFrequency(getClassificazioneId("GIORN","AN_FREQ"));
                        aeView.setInternal(addressView.getInternal());
                        aeView.setReserved(0L);
                        aeView.setOpId(operationId);
                        try {
                        	aeAddressBeanManager.create(aeView);
                        } catch (final AddressException e1) {
                            log4Debug.warnStackTrace(e1);
                            throw new AddressManagerBeanHelperException(e1.getMessage());
                        }
                    }
                }
                if(domkoId.equals(addressView.getInternal())) {
                    new AddressLogHelper().logInAddressLogTable(addressView,"DOMKO");
                }
            }
            if(operationId != null) {
				addressLogHelper.logAddressOpDetails(operationId, "", "");
			}
        } catch (final LoggerException e) {
        	errorMessage = e.getMessage();
            log4Debug.warnStackTrace(e);
            throw new AddressManagerBeanHelperException(errorMessage);
        } catch (final AddressException e) {
        	errorMessage = e.getMessage();
            log4Debug.warnStackTrace(e);
            throw new AddressManagerBeanHelperException(errorMessage);
        } catch (final FinderException e) {
        	errorMessage = e.getMessage();
            log4Debug.warnStackTrace(e);
            throw new AddressManagerBeanHelperException(errorMessage);
        } finally {
        	try {
            	addressLogHelper.updateAddressLog(operationId, soggettoId, errorMessage);
			} catch (final LoggerException e) {
				log4Debug.severe("This exception is just caught not to affect the parent transaction !!!!!");
				log4Debug.warnStackTrace(e);
			}
		}
    }

}
