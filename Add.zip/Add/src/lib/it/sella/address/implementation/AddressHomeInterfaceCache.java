/**
 * Created by IntelliJ IDEA.
 * User: ssil72
 * Date: Jun 10, 2004
 * Time: 3:19:28 PM
 */
package it.sella.address.implementation;

import it.sella.util.CacheFactory;

import java.io.Serializable;
import java.util.Map;

/**
 * The class is used to cache homeinterfaces to avoid repeated lookup.
 */
public class AddressHomeInterfaceCache implements Serializable
{
    
    private final Map addressHomeInterfacesCache = CacheFactory.getInstance(AddressHomeInterfaceCache.class).getCacheInstance("addressHomeInterfacesCache");

    /**
     * checks whether the homeobject is already lookedup and cached
     * @param homeObjectName String
     * @return boolean
     */
    public boolean isHomeObjectExists(final String homeObjectName) {
        return addressHomeInterfacesCache.containsKey(homeObjectName);
    }

    /**
     * returns the homeobject cached for the input key
     * @param homeObjectName String
     * @return object
     */
    public Object getHomeObject(final String homeObjectName) {
        return addressHomeInterfacesCache.get(homeObjectName);
    }

    /**
     * stores the homeobject using the input key passed
     * @param homeObjectName String
     * @param homeObject Object
     */
    public void putHomeObject(final String homeObjectName,final Object homeObject) {
        addressHomeInterfacesCache.put(homeObjectName, homeObject);
    }

}
