package it.sella.address.implementation.ae;


public class AEAddressView implements AEAddress
{
	public Long getAeAddressId() {
		return aeAddressId;
	}

	 public void setAeAddressId(final Long aeAddressId) {
		 this.aeAddressId = aeAddressId;
	}

	public Long getReserved()
    {
        return reserved;
    }

    public void setReserved(final Long reserved)
    {
        this.reserved = reserved;
    }

    public Long getFrequency()
    {
        return frequency;
    }

    public void setFrequency(final Long frequency)
    {
        this.frequency = frequency;
    }

    public Long getInternal()
    {
        return internal;
    }

    public void setInternal(final Long internal)
    {
        this.internal = internal;
    }

    public Long getAddressLinkId()
    {
        return addressLinkId;
    }

    public void setAddressLinkId(final Long addressLinkId)
    {
        this.addressLinkId = addressLinkId;
    }

	public Long getOpId() {
		return this.opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}

	private Long aeAddressId;
    private Long reserved;
    private Long frequency;
    private Long internal;
    private Long addressLinkId;
    private Long opId;
}
