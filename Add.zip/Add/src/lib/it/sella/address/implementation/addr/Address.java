package it.sella.address.implementation.addr;

import java.io.Serializable;

public interface Address extends Serializable {

	public Long getId();

	public void setId(Long id);

	public String getProvincia();

    public void setProvincia(String provincia);

    public Long getCapId();

    public void setCapId(Long capId);

    public String getCapValue();

    public void setCapValue(String capValue);

    public Long getNazione();

    public void setNazione(Long nazione);

    public String getCitta();

    public void setCitta(String citta);

    public String getIndirizzo();

    public void setIndirizzo(String indirizzo);

    public Long getOpId();

    public void setOpId(Long opId);

	public String getNormStatus();

	public void setNormStatus(String normStatus);

	public String getCittaName();

	public void setCittaName(String cittaName);

	public String getNazioneName();

	public void setNazioneName(String nazioneName);

	public String getProvinciaSigla();

	public void setProvinciaSigla(String provinciaSigla);

	public String getProvinciaName();

	public void setProvinciaName(String provinciaName);

	public String getPresso();

	public void setPresso(String presso);

	public String getEdificio();

	public void setEdificio(String edificio);
}
