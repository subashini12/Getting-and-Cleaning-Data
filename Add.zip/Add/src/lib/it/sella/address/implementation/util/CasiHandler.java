package it.sella.address.implementation.util;

import it.sella.casi.factory.GestoreCasiFactory;
import it.sella.casi.util.IGestoreCasiConstants;
import it.sella.casi.util.view.CustodiaDetailView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Hashtable;
import java.util.List;
import java.util.Map;

public class CasiHandler {
	 private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CasiHandler.class);

	public Map getCustodiaDetail(final Long soggettoId ){
		Map custodialDeatails = null;
		try{
			log4Debug.debug("CasiHandler : getCustodiaDetail :soggettoId  " , soggettoId);
			custodialDeatails = GestoreCasiFactory.getInstance().getGestoreCasiManager()
					.getGestoreCasi().getCustodiaDetail(soggettoId);
		}
		catch( final Exception e ) {
    		log4Debug.severe(" ++++++++++++++++++ Exception Raised Trying to get custodiaDetai in CASI ");
    		log4Debug.severeStackTrace(e);
        }
		return custodialDeatails;
	}
	
	public Map getCustodiaDetailForProductId(final Map custodiaDetailMap , final Long productId ){
		log4Debug.debug("CasiHandler : getCustodiaDetail : productId  " , productId);
		CustodiaDetailView custodiaDetailView = null;
		Map outputHsTable = null;
		StringBuilder custodiaDetail = null;
		final List cassettaDetailList = (List)custodiaDetailMap.get(IGestoreCasiConstants.IGESTORE_CASSETTA_LIST);
		final List colloDetailList = (List)custodiaDetailMap.get(IGestoreCasiConstants.IGESTORE_COLLO_LIST);
		for(int i =0 ; i<cassettaDetailList.size();i++){
			custodiaDetailView = (CustodiaDetailView)cassettaDetailList.get(i);
			if(productId.equals(custodiaDetailView.getCustodiaId())){
				outputHsTable = new Hashtable();
				custodiaDetail = new StringBuilder();
				custodiaDetail.append(" numero ").append(custodiaDetailView.getLabelNumber());
				custodiaDetail.append(" succursale ").append(custodiaDetailView.getBranchCode());
				outputHsTable.put("cassettaType", "Cassetta di sicurezza ");
				outputHsTable.put("cassettaLebel", custodiaDetail.toString());
				outputHsTable.put("cassettaStatus", (custodiaDetailView.getDataScadenza() == null ? "aperto" : "chiuso"));
				break;
			}
		}
		if(outputHsTable == null){
			for(int i =0 ; i<colloDetailList.size();i++){
				custodiaDetailView = (CustodiaDetailView)colloDetailList.get(i);
				if(productId.equals(custodiaDetailView.getCustodiaId())){
					outputHsTable = new Hashtable();
					custodiaDetail = new StringBuilder();
					custodiaDetail.append(" numero ").append(custodiaDetailView.getLabelNumber());
					custodiaDetail.append(" succursale ").append(custodiaDetailView.getBranchCode());
					outputHsTable.put("cassettaType", "Collo");
					outputHsTable.put("cassettaLebel", custodiaDetail.toString());
					outputHsTable.put("cassettaStatus", (custodiaDetailView.getDataScadenza() == null ? "aperto" : "chiuso"));
					break;
				}
			}	
		}
		return outputHsTable;
	}
	
	public boolean isEmptyCustodiaDeatail(final Map custodiaDetailMap){
		final List cassettaDetailList = (List)custodiaDetailMap.get(IGestoreCasiConstants.IGESTORE_CASSETTA_LIST);
		final List colloDetailList = (List)custodiaDetailMap.get(IGestoreCasiConstants.IGESTORE_COLLO_LIST);
		return (cassettaDetailList == null && colloDetailList == null)
				|| ((cassettaDetailList != null && cassettaDetailList.isEmpty()) && (colloDetailList != null && colloDetailList.isEmpty()));
	}
}
