package it.sella.address.implementation.dbhelper;

import it.sella.address.AddressException;
import it.sella.address.AddressManagerBeanHelperException;
import it.sella.address.AddressManagerFactory;
import it.sella.address.AddressView;
import it.sella.address.IAddressManager;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.AddressAdminFactory;
import it.sella.address.implementation.util.DateHandler;
import it.sella.address.implementation.util.SecurityHandler;
import it.sella.address.implementation.util.UtilHelper;
import it.sella.address.log.LogView;
import it.sella.anagrafe.OperazioneAnagrafeFactory;
import it.sella.anagrafe.OperazioneAnagrafeManager;
import it.sella.anagrafe.hostlog.LogHostCallView;
import it.sella.anagrafe.hostlog.LogOperationDataView;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.logserver.LoggerClient;
import it.sella.logserver.LoggerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Timestamp;

public class AddressLogHelper extends AddressBaseHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressLogHelper.class);

    public void logInAddressLogTable(final AddressView addressView,
    		final String operation) throws RemoteException, AddressManagerBeanHelperException {
        try {
            final LogView logView = new LogView();
			logView.setCodiciDipendente(SecurityHandler.getLoginUserId());
			logView.setDateOfOperation(new DateHandler().getCurrentDateInTimeStampFormat());
            logView.setModeOfOperation(operation);
            logView.setSoggettoId(addressView.getSoggettoId());
            logView.setAccountId(addressView.getProductContoId());
            new LogDBAccessHelper().createLog(logView);
        } catch(final SubSystemHandlerException e) {
            log4Debug.warnStackTrace(e);
            throw new AddressManagerBeanHelperException(e.getMessage());
        } catch(final AddressException e) {
            log4Debug.warnStackTrace(e);
            throw new AddressManagerBeanHelperException(e.getMessage());
        }
    }

    public void logMessage(final Long soggettoId, final String operation, final String data, final String operationCode, final String operationResult, final String codiceHost) throws AddressManagerBeanHelperException {
    	logMessage(soggettoId, operation, data, operationCode, operationResult, codiceHost, null);
    }

    // Since LG_OPERATION_RESULT column size is 120 ,first 100 char only taken(errorMessage.substring(0, 100))
    public void logMessageWithErrorMsg(final Long soggettoId, final String operation, final String data, final String operationCode, final String operationResult, final String codiceHost,final String errorMessage) throws AddressManagerBeanHelperException {
    	logMessage(soggettoId, operation, data, operationCode, operationResult, codiceHost, errorMessage != null && errorMessage.length() > 100 ? errorMessage.substring(0, 100) : errorMessage);
    }

    public void logMessage(final Long soggettoId, final String operation, final String data, final String operationCode, final String operationResult, final String codiceHost,final String errorMessage) throws AddressManagerBeanHelperException {
        try {
            final LoggerClient logggerClient = LoggerClient.getInstance();
            final StringBuffer variableTag = new StringBuffer();
            UtilHelper.getOpenTag(variableTag, "LOG_OPTIONAL_SECTION");
            variableTag.append(UtilHelper.getTag("OPERATION_CODE", operationCode));
            variableTag.append(UtilHelper.getTag("ID_SOGGETTO_TRATTATO", soggettoId != null ? soggettoId.toString() : ""));
            variableTag.append(UtilHelper.getTagWithValueCheck("NUMERO_CONTO_PARTENZA", codiceHost));
            variableTag.append("<DIVISA_PARTENZA/><IMPORTO_PARTENZA/><NUMERO_CONTO_ARRIVO/><VALUTA_OPERAZIONE/><ID_AUTORIZZANTE/>");
            variableTag.append(UtilHelper.getTag("OPERATION_RESULT", "FAILURE".equals(operationResult) &&  errorMessage != null ? "FAILURE - "+errorMessage : operationResult));
            UtilHelper.getCloseTag(variableTag, "LOG_OPTIONAL_SECTION");

            UtilHelper.getOpenTag(variableTag, "LOG_VARIABLE_SECTION");
            UtilHelper.getOpenTag(variableTag, "XML_DATA");
            UtilHelper.getOpenTag(variableTag, "ADDRESSMANAGER");
            variableTag.append(UtilHelper.getTag("OPERATION",operation));
            variableTag.append(UtilHelper.getTagWithValueCheck("DATA",data));
            UtilHelper.getCloseTag(variableTag, "ADDRESSMANAGER");
            UtilHelper.getCloseTag(variableTag, "XML_DATA");
            UtilHelper.getCloseTag(variableTag, "LOG_VARIABLE_SECTION");

            logggerClient.log(variableTag.toString());
        } catch(final LoggerException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressManagerBeanHelperException(e.getMessage());
        }
    }

    public String getLogData(final AddressView addressView,final boolean modificaTutti) {
        final StringBuffer logMessageData = new StringBuffer();
    	if(addressView != null) {
	        NullDummyValueHandler.addLogAfterNullCheck(logMessageData, "SoggettoId", addressView.getSoggettoId());
	        NullDummyValueHandler.addLogAfterNullCheck(logMessageData, "SubSystemCl", addressView.getCausaleSubsystem());
    	}
		if(modificaTutti) {
			logMessageData.append(UtilHelper.getTag("ProductContoId", "MODIFICA_TUTTI"));
		} else if(addressView.getNch() != null) {
			logMessageData.append("<ProductContoId>").append(addressView.getNch()).append("</ProductContoId>");
		} else if(addressView.getProductContoId() != null) {
			logMessageData.append("<ProductContoId>").append(addressView.getProductContoId()).append("</ProductContoId>");
		}
        return logMessageData.toString() ;
    }

    public Long logAddressOperation(final String operationCode, final AddressView addressView, final String errorMessage,final boolean isModificaTutti) throws LoggerException, RemoteException {
    	Long logHostCallPK = null;
        try {
            final LogHostCallView logHostCallView = new LogHostCallView();
            logHostCallView.setAbiCode(SecurityHandler.getCodiceAbiBanca());
            logHostCallView.setCdrName(SecurityHandler.getCdrName());
            logHostCallView.setDateOfOperation(new Timestamp(System.currentTimeMillis()));
            logHostCallView.setMotivazioneSkipHost(null);
            logHostCallView.setOperationCode(operationCode);
            logHostCallView.setSkipHostFlag(null);
            logHostCallView.setSoggettoId(addressView != null ? addressView.getSoggettoId() : null);
			if (isModificaTutti) {
				logHostCallView.setLinkedProd("MODIFICA_TUTTI");
			} else if(addressView != null && addressView.getNch() != null) {
				logHostCallView.setLinkedProd(addressView.getNch());
			} else if(addressView != null && addressView.getProductContoId() != null) {
				logHostCallView.setLinkedProd(addressView.getProductContoId().toString());
			}
			if(addressView != null && addressView.getCausaleSubsystem() != null){
				logHostCallView.setSubSystemId(getClassificazioneId(addressView.getCausaleSubsystem(),"SUBSYS"));
			}
            logHostCallView.setTerminalName(SecurityHandler.getUserTerminalName());
            logHostCallView.setUserId(SecurityHandler.getLoginUserId());
            logHostCallView.setUserSoggettoId(SecurityHandler.getLoginSoggettoId());
            logHostCallView.setErrorMessage(errorMessage);
            logHostCallView.setDeletionDate(null);
			final OperazioneAnagrafeManager operazioneAnagrafeManager = OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager();
			logHostCallPK = operazioneAnagrafeManager.createLogHOSTCall(logHostCallView);
        } catch (final OperazioneAnagrafeManagerException e) {
            log4Debug.severeStackTrace(e);
            throw new LoggerException(e.getMessage());
        } catch (final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            throw new LoggerException(e.getMessage());
        } catch (final AddressManagerBeanHelperException e) {
            log4Debug.severeStackTrace(e);
            throw new LoggerException(e.getMessage());
		}
        return logHostCallPK;
    }

    public void logAddressOpDetails(final Long opId, final String mapperMessage, final String addressData) throws LoggerException, RemoteException {
    	try {
	        final LogOperationDataView logOperationDataView = new LogOperationDataView();
	        logOperationDataView.setHostCallViewPK(opId);
	        logOperationDataView.setMapperMessage(mapperMessage != null ? mapperMessage : "");
	        logOperationDataView.setXmlOperation(addressData != null ? addressData : "");
	        OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager().createLogHOSTOperationData(logOperationDataView);
    	} catch (final OperazioneAnagrafeManagerException e) {
            log4Debug.warnStackTrace(e);
            throw new LoggerException(e.getMessage());
        }
    }

    public void updateAddressLog(final Long operationId, final Long soggettoId, final String errorMessage) throws LoggerException, RemoteException {
    	try {
			if(operationId != null && errorMessage != null) {
				//OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager().updateAnagrafeLog(operationId, soggettoId, errorMessage);
				AddressAdminFactory.getInstance().getAddressAdmin().updateAnagrafeLog(operationId,soggettoId,errorMessage);
			}
		} catch (final AddressException e) {
			log4Debug.warnStackTrace(e);
            throw new LoggerException(e.getMessage());
		}
	}

    public String getLogDataFromAddressView(final AddressView addressView) {
        final StringBuffer logData = new StringBuffer();
        if(addressView != null) {
        	logData.append("<AddressView>");
        	NullDummyValueHandler.addLogAfterNullCheck(logData, "TipoIndirizzo", addressView.getTipoIndirrizo());
        	NullDummyValueHandler.addLogAfterNullCheck(logData, "Indirizzo", addressView.getIndirizzo());
        	NullDummyValueHandler.addLogAfterNullCheck(logData, "Cap", addressView.getCapView());
        	NullDummyValueHandler.addLogAfterNullCheck(logData, "Citta", addressView.getCittaView());
        	NullDummyValueHandler.addLogAfterNullCheck(logData, "Nazione", addressView.getNazioneView());
        	NullDummyValueHandler.addLogAfterNullCheck(logData, "Provincia", addressView.getProvinciaView());
        	NullDummyValueHandler.addLogAfterNullCheck(logData, "Frequency", addressView.getFrequency());
        	NullDummyValueHandler.addLogAfterNullCheck(logData, "Internal", addressView.getInternal());
        	NullDummyValueHandler.addLogAfterNullCheck(logData, "Reserved", addressView.getReserved());
        	NullDummyValueHandler.addLogAfterNullCheck(logData, "Presso", addressView.getPresso());
        	NullDummyValueHandler.addLogAfterNullCheck(logData, "Edificio", addressView.getPresso());
        	logData.append("</AddressView>");
        }
        return logData.toString();
    }

    /**
     * Method to set Old data Logger for Product and SubsystemCausale
     * @param soggettoId
     * @param subSystemCl
     * @param productContoId
     * @return String
     * @throws LoggerException
     */
	public String setAddressView4Logger(final Long soggettoId,final String subSystemCl, final Long productContoId) throws LoggerException  {
		final StringBuffer logMessageData = new StringBuffer();
		final IAddressManager addressManager = AddressManagerFactory.getInstance().getAddressManager();
		AddressView addressView4Conto = null;
		try {
			addressView4Conto = addressManager.getAddress(soggettoId, subSystemCl, productContoId );
			if (addressView4Conto!= null ) {
				logMessageData.append("<Address>");
				NullDummyValueHandler.addLogAfterNullCheck(logMessageData, "ProductContoId", productContoId);
				NullDummyValueHandler.addLogAfterNullCheck(logMessageData, "SubSystemCl", subSystemCl);
				logMessageData.append( getLogDataFromAddressView(addressView4Conto) );
				logMessageData.append("</Address>");
			}
		} catch (RemoteException e) {
		 log4Debug.debugStackTrace(e);
	      throw new LoggerException(e.getMessage());
		} catch (AddressException e) {
		  log4Debug.debugStackTrace(e);
	      throw new LoggerException(e.getMessage());
		}
		return logMessageData.toString();
	}
}
