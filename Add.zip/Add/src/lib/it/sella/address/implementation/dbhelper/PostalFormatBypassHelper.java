package it.sella.address.implementation.dbhelper;

import it.sella.address.AddressException;
import it.sella.address.PostalByPassView;
import it.sella.address.implementation.util.DBHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class PostalFormatBypassHelper {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(PostalFormatBypassHelper.class);
	
	public Long createPostalFormatBypass(final PostalByPassView postalByBassView) throws AddressException{
		Connection connection = null;
    	PreparedStatement preparedStatement = null;
    	final StringBuffer query = new StringBuffer();
    	Long postalByPassViewId = null;
    	query.append("INSERT INTO ADD_TR_POSTAL_FORMAT_BYPASS (PB_ID ,PB_BYPASS_CODE ,PB_DESCRIPTION , PB_START_DATE ,PB_END_DATE ,PB_NOTES) VALUES (ADD_SQ_PB_ID.NEXTVAL,?,?,?,?,?)");
    	try {
			connection = DBHelper.getConnection();
			final String column [] = {"PB_ID"};
			preparedStatement = connection.prepareStatement(query.toString(), column);
			preparedStatement.setString(1, postalByBassView.getBypassCode());
			preparedStatement.setString(2, postalByBassView.getDescription());
			checkForNullAndSetinStatement(preparedStatement, postalByBassView.getStartDate(), 3);
			checkForNullAndSetinStatement(preparedStatement, postalByBassView.getEndDate(), 4);
			preparedStatement.setString(5, postalByBassView.getNotes());
			preparedStatement.executeUpdate();
            final ResultSet rs = preparedStatement.getGeneratedKeys();
            if(rs != null)
            {
            	if(rs.next())
            	{
            		postalByPassViewId = rs.getLong(1);
            	}
            }
		} catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new AddressException(e.getMessage());
        } finally {
            DBHelper.cleanup(connection, preparedStatement);
        }
        return postalByPassViewId;
	}
	
	public void updatePostalFormatBypass(final PostalByPassView postalByBassView) throws AddressException{
		Connection connection = null;
    	PreparedStatement preparedStatement = null;
    	final StringBuffer query = new StringBuffer();
    	query.append("UPDATE  ADD_TR_POSTAL_FORMAT_BYPASS SET PB_BYPASS_CODE = ? ,PB_DESCRIPTION = ? , PB_START_DATE = ? ,PB_END_DATE = ? ,PB_NOTES = ? WHERE PB_ID = ? ");
    	try {
			connection = DBHelper.getConnection();
			preparedStatement = connection.prepareStatement(query.toString());
			preparedStatement.setString(1, postalByBassView.getBypassCode());
			preparedStatement.setString(2, postalByBassView.getDescription());
			checkForNullAndSetinStatement(preparedStatement, postalByBassView.getStartDate(), 3);
			checkForNullAndSetinStatement(preparedStatement, postalByBassView.getEndDate(), 4);
			preparedStatement.setString(5, postalByBassView.getNotes());
			preparedStatement.setLong(6, postalByBassView.getId());
			preparedStatement.executeUpdate();
		} catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new AddressException(e.getMessage());
        } finally {
            DBHelper.cleanup(connection, preparedStatement);
        }
	}
	
	public void removePostalFormatBypass(final PostalByPassView postalByBassView) throws AddressException{
		Connection connection = null;
    	PreparedStatement preparedStatement = null;
    	final StringBuffer query = new StringBuffer();
    	query.append("DELETE FROM ADD_TR_POSTAL_FORMAT_BYPASS  WHERE PB_ID = ? ");
    	try {
			connection = DBHelper.getConnection();
			preparedStatement = connection.prepareStatement(query.toString());
			preparedStatement.setLong(1, postalByBassView.getId());
			preparedStatement.executeUpdate();
		} catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new AddressException(e.getMessage());
        } finally {
            DBHelper.cleanup(connection, preparedStatement);
        }
	}
	
	public List<PostalByPassView> getPostalFormatBypass(final String bypassCode) throws AddressException {
		Connection connection = null;
    	PreparedStatement preparedStatement = null;
    	ResultSet resultSet = null;
    	PostalByPassView postalByPassView = null;
    	final List<PostalByPassView> postalFormatCol = new ArrayList<PostalByPassView>(1);
    	final StringBuffer query = new StringBuffer("SELECT PB_ID,PB_DESCRIPTION,PB_START_DATE, ");
    	query.append("PB_END_DATE,PB_NOTES FROM ADD_TR_POSTAL_FORMAT_BYPASS WHERE PB_BYPASS_CODE = ?");
    	try {
			connection = DBHelper.getConnection();
			preparedStatement = connection.prepareStatement(query.toString());
			preparedStatement.setString(1, bypassCode);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()){
				postalByPassView = new PostalByPassView();
				postalByPassView.setId(resultSet.getLong("PB_ID"));
				postalByPassView.setDescription(resultSet.getString("PB_DESCRIPTION"));
				postalByPassView.setStartDate(resultSet.getTimestamp("PB_START_DATE"));
				postalByPassView.setEndDate(resultSet.getTimestamp("PB_END_DATE"));
				postalByPassView.setNotes(resultSet.getString("PB_NOTES"));
				postalByPassView.setBypassCode(bypassCode);
				postalFormatCol.add(postalByPassView);
   		   }
		} catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new AddressException(e.getMessage());
        } finally {
            DBHelper.cleanup(connection, preparedStatement, resultSet);
        }
        return postalFormatCol;
	}

	public PostalByPassView getPostalFormatBypass(final Long pkId) throws AddressException {
		Connection connection = null;
    	PreparedStatement preparedStatement = null;
    	ResultSet resultSet = null;
    	PostalByPassView postalByPassView = null;
    	
    	final StringBuffer query = new StringBuffer("SELECT PB_ID, PB_BYPASS_CODE, PB_DESCRIPTION,PB_START_DATE, ");
    	query.append("PB_END_DATE,PB_NOTES FROM ADD_TR_POSTAL_FORMAT_BYPASS WHERE PB_ID = ?");
    	try {
			connection = DBHelper.getConnection();
			preparedStatement = connection.prepareStatement(query.toString());
			preparedStatement.setLong(1, pkId);
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next()){
				postalByPassView = new PostalByPassView();
				postalByPassView.setId(pkId);
				postalByPassView.setBypassCode(resultSet.getString("PB_BYPASS_CODE"));
				postalByPassView.setDescription(resultSet.getString("PB_DESCRIPTION"));
				postalByPassView.setStartDate(resultSet.getTimestamp("PB_START_DATE"));
				postalByPassView.setEndDate(resultSet.getTimestamp("PB_END_DATE"));
				postalByPassView.setNotes(resultSet.getString("PB_NOTES"));
   		   }
		} catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new AddressException(e.getMessage());
        } finally {
            DBHelper.cleanup(connection, preparedStatement, resultSet);
        }
        return postalByPassView;
	}

	
	 private void checkForNullAndSetinStatement(final PreparedStatement preparedStatement, 
			 final Timestamp value, final int index)	throws SQLException {
		if (value != null) {
			preparedStatement.setTimestamp(index, value);
		} else {
			preparedStatement.setNull(index, Types.TIMESTAMP);
		}
	}
}
