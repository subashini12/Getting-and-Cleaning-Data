package it.sella.address.implementation.dbhelper;

import it.sella.address.AddressView;
import it.sella.anagrafe.common.CAP;
import it.sella.anagrafe.implementation.CittaView;
import it.sella.anagrafe.implementation.NazioneView;
import it.sella.anagrafe.implementation.ProvinciaView;

import java.sql.ResultSet;
import java.sql.SQLException;

public class AddressViewBuilder {
        
    public void setCapInAddressView(final ResultSet addressSet,final AddressView addressView) throws SQLException {
        try {
            if(addressSet.getString("CAP_ID") != null) {
                final CAP cap = new CAP();
                cap.setCapId(Long.valueOf(addressSet.getString("CAP_ID")));
                cap.setCap(addressSet.getString("CA_CAP"));
                cap.setLocalita(addressSet.getString("CA_LOCALITA"));
                cap.setNote(addressSet.getString("CA_NOTE"));
                cap.setProvincia(addressSet.getString("CA_PROVINCIA"));
                addressView.setCapView(cap);
                addressView.setCap(addressSet.getString("CA_CAP"));
            } else {
                addressView.setCap(addressSet.getString("AD_CAP_VALUE"));
            }
        } catch (final NumberFormatException e) {
            addressView.setCap(addressSet.getString("AD_CAP_VALUE"));
        }
    }

    public void setCittaInAddressView(final ResultSet addressSet,final AddressView addressView) throws SQLException {
        try {
            if(addressSet.getLong("CI_ID") != 0) {
                final CittaView cittaView = new CittaView();
                cittaView.setCittaId(Long.valueOf(addressSet.getLong("CI_ID")));
                cittaView.setCommune(addressSet.getString("CI_COMMUNE"));
                cittaView.setProvincia(addressSet.getString("CI_PROVINCIA"));
                cittaView.setRegion(addressSet.getString("CI_REGION"));
                cittaView.setCapoluogo(Long.valueOf(addressSet.getLong("CI_CAPOLUOGO")));
                cittaView.setCab(addressSet.getString("CI_CAB"));
                cittaView.setCincab(addressSet.getString("CI_CINCAB"));
                cittaView.setCabStorico(addressSet.getString("CI_CAB_STORICO"));
                cittaView.setCncf(addressSet.getString("CI_CNCF"));
                cittaView.setCap(addressSet.getString("CI_CAP"));
                cittaView.setStorico(String.valueOf(addressSet.getLong("CI_STORICO")));
                cittaView.setAltraDenominazione(addressSet.getString("CI_ALTRADENOMINAZIONE"));
                addressView.setCittaView(cittaView);
                addressView.setCitta(addressSet.getString("CI_COMMUNE"));
            } else {
                addressView.setCitta(addressSet.getString("AD_CITTA"));
            }
        } catch (final NumberFormatException e) {
            addressView.setCitta(addressSet.getString("AD_CITTA"));
        }
    }

    public void setNazioneInAddressView(final ResultSet addressSet,final AddressView addressView) throws SQLException {
        final NazioneView nazioneView = new NazioneView();
        nazioneView.setNome(addressSet.getString("NA_NOME"));
		nazioneView.setAderenteTarget(getLongValue(addressSet, "NA_ADERENTE_TARGET"));
		nazioneView.setAltradenominazione(addressSet.getString("NA_ALTRADENOMINAZIONE"));
		
		nazioneView.setAppartenenteBlackList(getLongValue(addressSet,"NA_APPARTENENTE_BLACK_LIST"));
		
        nazioneView.setAreaGeografica(addressSet.getString("NA_AREA_GEOGRAFICA"));
        nazioneView.setCncf(addressSet.getString("NA_CNCF"));
        nazioneView.setCodiceDivisa(addressSet.getString("NA_CODICE_DIVISA"));
        nazioneView.setCodiceIso(addressSet.getString("NA_CODICE_ISO"));
        nazioneView.setCodiceProvincia(addressSet.getString("NA_CODICE_PROVINCIA"));
        nazioneView.setCodiceUic(addressSet.getString("NA_CODICE_UIC"));
        nazioneView.setContinente(String.valueOf(addressSet.getLong("NA_CONTINENTE")));
        
		nazioneView.setHa_embargo(getLongValue(addressSet,"NA_HA_EMBARGO"));
		if(addressSet.getString("NA_LINGUA_PARLATA") != null) {
			nazioneView.setLinguaParlata((Long.valueOf(addressSet.getLong("NA_LINGUA_PARLATA"))).toString());
		}
		
		nazioneView.setMembroUe(getLongValue(addressSet,"NA_MEMBRO_UE"));
		
		nazioneView.setMembroUme(getLongValue(addressSet, "NA_MEMBRO_UME"));
		
        nazioneView.setNazionalita(addressSet.getString("NA_NAZIONALITA"));
        
		if(addressSet.getString("NA_NAZIONE") != null) {
			nazioneView.setNazione(Long.valueOf(addressSet.getString("NA_NAZIONE")));
		}
		
        nazioneView.setNazioneAppartenenza(addressSet.getString("NA_NAZIONE_APPARTENENZA"));
        nazioneView.setNazioneId(Long.valueOf(addressSet.getLong("NAZIONE_ID")));
        nazioneView.setSinglaInternazionale(addressSet.getString("NA_SINGLA_INTERNAZIONALE"));
        
		nazioneView.setStorico(getLongValue(addressSet,"NA_STORICO"));
		
		nazioneView.setValutario(getLongValue(addressSet,"NA_VALUTARIO"));
		nazioneView.setZcr(getLongValue(addressSet,"NA_ZCR"));
		nazioneView.setZonaBilanciGrandiRischi(getLongValue(addressSet,"NA_ZONA_BILANCI_GRANDI_RISCHI"));
		
        if(addressSet.getString("NA_DOC_AGGIUNTIVI") != null) {
			nazioneView.setDocAggiuntivi(addressSet.getString("NA_DOC_AGGIUNTIVI"));
		}
        addressView.setNazioneView(nazioneView);
        addressView.setNazione(addressSet.getString("NA_NOME"));
    }

    public void setProvinciaInAddressView(final ResultSet addressSet,final AddressView addressView) throws SQLException {
        try {
            if (addressSet.getLong("PR_ID") != 0) {
                final ProvinciaView provinciaView = new ProvinciaView();
                provinciaView.setProvinciaId(Long.valueOf(addressSet.getLong("PR_ID")));
                provinciaView.setSigla(addressSet.getString("PR_SIGLA"));
                provinciaView.setNome(addressSet.getString("PR_NOME"));
                provinciaView.setCodiceArea(addressSet.getString("PR_CODICE_AREA"));
                provinciaView.setCodiceCab(addressSet.getString("PR_CODICE_CAB"));
                provinciaView.setCodicePuma2(addressSet.getString("PR_CODICE_PUMA2"));
                addressView.setProvinciaView(provinciaView);
                addressView.setProvincia(addressSet.getString("PR_SIGLA"));
            } else {
                addressView.setProvincia(addressSet.getString("AD_PROVINCIA"));
            }
        } catch (final NumberFormatException e) {
            addressView.setProvincia(addressSet.getString("AD_PROVINCIA"));
        }
    }
    
    private Long getLongValue(final ResultSet addressSet, final String keyname) throws SQLException {
    	Long value = null;
		if(addressSet.getString(keyname) != null) {
			value = Long.valueOf(addressSet.getLong(keyname));
		}
    	 return value;
    }
}
