package it.sella.address.implementation.dbhelper;

import it.sella.address.implementation.util.StringHandler;
import it.sella.anagrafe.ICapView;
import it.sella.anagrafe.ICittaView;
import it.sella.anagrafe.INazioneView;
import it.sella.anagrafe.IProvinciaView;

public class NullDummyValueHandler {
	public static void addLogAfterNullCheck(final StringBuffer buffer,final String tagName,final String value) {
		if(value != null) {
			addLog(buffer,tagName,value);
		}
	}

	public static void addLogAfterNullCheck(final StringBuffer buffer,final String tagName,final Long value) {
		if(value != null) {
			addLog(buffer,tagName,value.toString());
		}
	}

	public static void addLogAfterNullCheck(final StringBuffer buffer,final String tagName,final ICapView value) {
		if(value != null) {
			addLog(buffer,tagName,value.getCap());
		}
	}
	
	public static void addLogAfterNullCheck(final StringBuffer buffer,final String tagName,final ICittaView value) {
		if(value != null) {
			addLog(buffer,tagName,value.getCommune());
		}
	}

	public static void addLogAfterNullCheck(final StringBuffer buffer,final String tagName,final INazioneView value) {
		if(value != null) {
			addLog(buffer,tagName,value.getNome());
		}
	}

	public static void addLogAfterNullCheck(final StringBuffer buffer,final String tagName,final IProvinciaView value) {
		if(value != null) {
			addLog(buffer,tagName,value.getSigla());
		}
	}
	
	public static void addLogAfterNullCheck(final StringBuffer buffer,final String tagName,final Boolean value) {
		if(value != null) {
			addLog(buffer,tagName,value.toString());
		}
	}

	public static void addLog(final StringBuffer buffer,final String tagName,final String value) {
		buffer.append("<").append(tagName).append(">");
		buffer.append(StringHandler.encodeXMLTagValue(value));
		buffer.append("</").append(tagName).append(">");
	}

}
