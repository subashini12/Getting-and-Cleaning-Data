package it.sella.address.implementation.dbhelper;

import it.sella.address.AddressException;
import it.sella.address.AddressManagerBeanHelperException;
import it.sella.address.AddressView;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.addresslink.AddressLink;
import it.sella.address.implementation.addresslink.IAddressLinkBeanManager;
import it.sella.address.implementation.factory.ReflectionUtil;
import it.sella.address.implementation.util.ClassificazioneHandler;
import it.sella.address.implementation.util.DBHelper;
import it.sella.address.implementation.util.Helper;
import it.sella.logserver.LoggerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;

import javax.ejb.FinderException;

public class AddressUpdateHelper {


    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressUpdateHelper.class);

    public void removeUnusedAddress() throws AddressException, RemoteException {
        Connection connection = null;
        CallableStatement callableStatement = null;
        //Passing op_id to the procedure to log the person who is removing the unused address
        Long opId = null;
        try {
        	log4Debug.info("################## UNUSED ADDRESS GOING TO REMOVE ###############");
            connection = DBHelper.getConnection();
            opId = new AddressLogHelper().logAddressOperation("DEL_UNUSED_ADDR",null,null,false);
            callableStatement = connection.prepareCall("{call AN_PR_DELETE_UNUSEDADDRESS(?) }");
            log4Debug.info("################## OPERATION ID",opId);
            callableStatement.setLong(1, opId);
            callableStatement.executeUpdate();
            log4Debug.info("################## ADDRESS REMOVAL PROCEDURE SUCCESSFULLY EXECUTED ###############");
        } catch(final SQLException sqlException) {
            log4Debug.severeStackTrace(sqlException);
            throw new AddressException(sqlException.getMessage());
        } catch (LoggerException loggerException) {
        	 log4Debug.severeStackTrace(loggerException);
             throw new AddressException(loggerException.getMessage());
		} finally {
            DBHelper.cleanup(connection, callableStatement);
        }
    }

    public void updateSoggetto(final Long oldSoggettoId, final Long newSoggettoId, Long operationId) throws AddressException, RemoteException {
        Collection addrLinkCollection = null;
        String errorMessage = null;
        final AddressLogHelper addressLogHelper = new AddressLogHelper();
        try {
        	final IAddressLinkBeanManager addressLinkBeanManager  = (IAddressLinkBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.AddressLink");
            addrLinkCollection = addressLinkBeanManager.findAllProductContoId(oldSoggettoId);
            if(addrLinkCollection != null) {
                final Iterator addrLinkIterator = addrLinkCollection.iterator();
                for(int size = addrLinkCollection.size(); size > 0; size--) {
                    final AddressLink addressLink = (AddressLink) addrLinkIterator.next();
                    if(operationId == null) {
						operationId = getOpId(addressLink.getSoggettoId(),ClassificazioneHandler.getClassificazioneView(addressLink.getSubSystem()).getCausale(),
                    			addressLink.getLinkedId(),"ADDR-SOGGID-SWAP");
					}
                    if(addressLink.getLinkedId() != null) {
                        addressLink.setSoggettoId(newSoggettoId);
                        addressLink.setOpId(operationId);
                        addressLinkBeanManager.update(addressLink);
                    }
                }
            }
            if(operationId != null) {
				addressLogHelper.logAddressOpDetails(operationId, "", "");
			}
        } catch(final LoggerException e) {
        	errorMessage = e.getMessage();
            log4Debug.warnStackTrace(e);
            throw new AddressException(errorMessage);
        } catch(final FinderException e) {
        	errorMessage = e.getMessage();
            log4Debug.warnStackTrace(e);
            throw new AddressException(errorMessage);
        }  catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		}  finally {
        	try {
        	addressLogHelper.updateAddressLog(operationId, newSoggettoId, errorMessage);
			} catch (final LoggerException e) {
				log4Debug.severe("This exception is just caught not to affect the parent transaction !!!!!");
				log4Debug.warnStackTrace(e);
			}
        }
    }


    public void removeProductAddress(final Long soggettoId,final String subSystemCausale, final Long productId) throws AddressException, RemoteException {
    	try {
    		new AddressAESetterHelper().isNotNull(soggettoId,productId,subSystemCausale);
    		final Long subSystemId = ClassificazioneHandler.getClassificazioneView(subSystemCausale, "SUBSYS").getId();
    		final IAddressLinkBeanManager addressLinkBeanManager  = (IAddressLinkBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.AddressLink");
			final Collection addressLinkColl = addressLinkBeanManager.findAllBySoggettoSubsytemPCId(soggettoId,subSystemId,productId);
			int size = 0;
			if( addressLinkColl == null || (size = addressLinkColl.size()) < 1) {
				throw new AddressException(Helper.getMessage("ADDR-0002"));
			}
			AddressLink addressLink = null;
			Long opId = null;
			final Iterator linkIterator = addressLinkColl.iterator();

			opId = getOpId(soggettoId, subSystemCausale, productId, "ADD_API_DEL_LINK");
			final StoricDataUpdateHelper storicDataUpdateHelper = new StoricDataUpdateHelper();
			for(int i = 0; i < size; i++ ) {
				addressLink = (AddressLink) linkIterator.next();
				storicDataUpdateHelper.updateAddresLink(opId,
						 addressLink.getAddressLinkId(),
						addressLink.getSubSystem(),
						addressLink.getAddressType(),
						addressLink.getLinkedId(),
						addressLink.getSoggettoId(),
						addressLink.getAddressId(),
						addressLink.getOpId());
				addressLinkBeanManager.remove(addressLink);
			}
		} catch (final FinderException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(Helper.getMessage("ADDR-0002"));
        }  catch (final SubSystemHandlerException e) {
        	log4Debug.warnStackTrace(e);
        	throw new AddressException(e.getMessage());
        } catch (final LoggerException e) {
          	log4Debug.warnStackTrace(e);
            throw new AddressException(e.getMessage());
        }
    }

	public void swapProductAddressPerSoggetto(final Long oldSoggettoId,
			final Long newSoggettoId, final String subSystemCausale,final Long productId) throws AddressException, RemoteException {
		String errorMessage = null;
        final AddressLogHelper addressLogHelper = new AddressLogHelper();
        Long opId= null;
        final String logOperation = "ADDR-SOGGID-SWAP";
        String operationResult = "FAILURE";
        try {
        	final Long subSystemId = ClassificazioneHandler.getClassificazioneView(subSystemCausale, "SUBSYS").getId();
        	opId = getOpId(newSoggettoId, subSystemCausale, productId, logOperation);
        	final IAddressLinkBeanManager addressLinkBeanManager  = (IAddressLinkBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.AddressLink");
            final AddressLink addressLink  = addressLinkBeanManager.findBySoggettoSubsytemPCId(oldSoggettoId,subSystemId,productId);
            addressLink.setSoggettoId(newSoggettoId);
            addressLink.setOpId(opId);
            addressLinkBeanManager.update(addressLink);
            if(opId != null){
            	addressLogHelper.logAddressOpDetails(opId, "", "");
            }
            operationResult = "SUCCESS";
        } catch(final LoggerException e) {
        	errorMessage = e.getMessage();
            log4Debug.warnStackTrace(e);
            throw new AddressException(errorMessage);
        } catch(final FinderException e) {
        	errorMessage = e.getMessage();
            log4Debug.warnStackTrace(e);
            throw new AddressException(errorMessage);
        }   catch (final SubSystemHandlerException e) {
        	log4Debug.warnStackTrace(e);
        	throw new AddressException(e.getMessage());
        }finally {
        	 try {
        		 final AddressView addressView = new AddressView();
        		 addressView.setSoggettoId(newSoggettoId);
        		 addressView.setProductContoId(productId);
        		 addressView.setCausaleSubsystem(subSystemCausale);
        		 addressLogHelper.logMessageWithErrorMsg(newSoggettoId,"SWAP PRODUCT ADDRESS PER SOGGETTO",getLogData(oldSoggettoId,newSoggettoId,subSystemCausale,productId ), logOperation, operationResult, null,errorMessage);
 			} catch (final AddressManagerBeanHelperException e) {
 				errorMessage = e.getMessage();
 				log4Debug.severeStackTrace(e);
 				throw new AddressException(errorMessage);
 			}
 			try {
 				addressLogHelper.updateAddressLog(opId, newSoggettoId, errorMessage);
			} catch (final LoggerException e) {
				log4Debug.severe("This exception is just caught not to affect the parent transaction !!!!!");
				log4Debug.warnStackTrace(e);
			}
        }
    }
    private Long getOpId(final Long soggettoId, final String subSystemCausale, final Long productId,final String operationCode) throws RemoteException, LoggerException {
    		final AddressView addressView = new AddressView();
			addressView.setSoggettoId(soggettoId);
			addressView.setCausaleSubsystem(subSystemCausale);
			addressView.setProductContoId(productId);
			return new AddressLogHelper().logAddressOperation(operationCode, addressView, null, false);
	}

    private String getLogData(final Long oldSoggettoId,final Long newSoggettoId, final String subSystemCausale,final Long productId){
    	final StringBuilder logBuilder = new StringBuilder();
		logBuilder.append("<DATA_OLD>");
		logBuilder.append("<SOGGETTO_ID>").append(oldSoggettoId).append("</SOGGETTO_ID>");
		logBuilder.append("<SUB_SYSTEM_CAUSALE>").append(subSystemCausale).append("</SUB_SYSTEM_CAUSALE>");
		logBuilder.append("<PRODUCT_ID>").append(productId).append("</PRODUCT_ID>");
		logBuilder.append("</DATA_OLD>");
		logBuilder.append("<DATA_NEW>");
		logBuilder.append("<SOGGETTO_ID>").append(newSoggettoId).append("</SOGGETTO_ID>");
		logBuilder.append("<SUB_SYSTEM_CAUSALE>").append(subSystemCausale).append("</SUB_SYSTEM_CAUSALE>");
		logBuilder.append("<PRODUCT_ID>").append(productId).append("</PRODUCT_ID>");
		logBuilder.append("</DATA_NEW>");
		return logBuilder.toString();
    }
    /*private Long getOpId(AddressLink addressLink) throws RemoteException,LoggerException,HelperException {
    	try {
			AddressView addressView = new AddressView();
			addressView.setSoggettoId(addressLink.getSoggettoId());
			addressView.setCausaleSubsystem(ClassificazioneHandler.getClassificazioneView(addressLink.getSubSystem()).getCausale());
			addressView.setProductContoId(addressLink.getLinkedId());
			return new AddressLogHelper().logAddressOperation("ADDR-SOGGID-SWAP", addressView, null, false);
		} catch (SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new HelperException(e.getMessage());
		}
    }*/
}
