package it.sella.address.implementation.dbhelper;

import it.sella.address.AddressException;
import it.sella.address.implementation.addr.Address;
import it.sella.address.implementation.util.DBHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;

public class StoricDataUpdateHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(StoricDataUpdateHelper.class);

    public void updateAddress(final Long operationId, final Long addressId, final Address address)throws AddressException {
    	Connection connection = null;
    	PreparedStatement preparedStatement = null;
    	final StringBuffer query = new StringBuffer();
    	query.append(" INSERT INTO ADDSE_TR_ADDRESS (AD_ADDRESS_ID, AD_PROVINCIA, AD_CITTA, AD_CAP, AD_NAZIONE, AD_INDIRIZZO, AD_CAP_VALUE, AD_OP_ID, AD_OP_DATE, AD_OLD_OP_ID,AD_NORM_STATUS,AD_CITTA_NOME,AD_NAZIONE_NOME,AD_PROVINCA_SIGLA,AD_PROVINCA_NOME,AD_PRESSO,AD_EDIFICIO) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, SYSDATE,?,?,?,?,?,?,?,? )");
    	try {
			connection = DBHelper.getConnection();
			preparedStatement = connection.prepareStatement(query.toString());
			checkForNullAndSetinStatement(preparedStatement,addressId,1);
			preparedStatement.setString(2,address.getProvincia());
			preparedStatement.setString(3,address.getCitta());
			checkForNullAndSetinStatement(preparedStatement,address.getCapId(),4);
			checkForNullAndSetinStatement(preparedStatement,address.getNazione(),5);
			preparedStatement.setString(6,address.getIndirizzo());
			preparedStatement.setString(7,address.getCapValue());
			checkForNullAndSetinStatement(preparedStatement,operationId,8);
			checkForNullAndSetinStatement(preparedStatement,address.getOpId(),9);
			preparedStatement.setString(10,address.getNormStatus());
			preparedStatement.setString(11,address.getCittaName());
			preparedStatement.setString(12,address.getNazioneName());
			preparedStatement.setString(13,address.getProvinciaSigla());
			preparedStatement.setString(14,address.getProvinciaName());
			preparedStatement.setString(15,address.getPresso());
			preparedStatement.setString(16,address.getEdificio());
			preparedStatement.executeUpdate();
		} catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new AddressException(e.getMessage());
        } finally {
            DBHelper.cleanup(connection, preparedStatement);
        }
    }

    public void updateAddresLink(final Long operationId, final Long addressLink, final Long subSystemType, final Long addressType, final Long linkedId, final Long soggettoId, final Long addressId, final Long oldOpId)throws AddressException {
    	Connection connection = null;
    	PreparedStatement preparedStatement = null;
    	final StringBuffer query = new StringBuffer();
    	query.append("INSERT INTO ADDSE_TR_ADDRESS_LINK (AL_ADR_LINK, AL_TYPE_SUBSYSTEM, AL_TYPE_ADDRESS, AL_LINKED_ID, AL_SOGGETTO_ID, AL_ADDRESS_ID, AL_OP_ID, AL_OP_DATE, AL_OLD_OP_ID ) VALUES ( ?, ?, ?, ?, ?, ?, ?, SYSDATE,? ) ");
    	try {
			connection = DBHelper.getConnection();
			preparedStatement = connection.prepareStatement(query.toString());
			checkForNullAndSetinStatement(preparedStatement,addressLink,1);
			checkForNullAndSetinStatement(preparedStatement,subSystemType,2);
			checkForNullAndSetinStatement(preparedStatement,addressType,3);
			checkForNullAndSetinStatement(preparedStatement,linkedId,4);
			checkForNullAndSetinStatement(preparedStatement,soggettoId,5);
			checkForNullAndSetinStatement(preparedStatement,addressId,6);
			checkForNullAndSetinStatement(preparedStatement,operationId,7);
			checkForNullAndSetinStatement(preparedStatement,oldOpId,8);
			preparedStatement.executeUpdate();
		} catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new AddressException(e.getMessage());
        } finally {
            DBHelper.cleanup(connection, preparedStatement);
        }
    }

    public void updateAddressAE(final Long operationId, final Long addressId, final Long addressLinkId, final String reserved, final Long frequency, final Long internal, final Long oldOpId ) throws AddressException {
	    Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    final StringBuffer query = new StringBuffer();
	    query.append("INSERT INTO ADDSE_TR_AE_ADDRESS (AE_ADDRESS_ID, AE_ADDRESS_LINK_ID, AE_RESERVED, AE_FREQUENCY, AE_INTERNAL, AE_OP_ID, AE_OP_DATE, AE_OLD_OP_ID ) VALUES ( ?, ?, ?, ?, ?, ?, SYSDATE,? )");
	    try {
			connection = DBHelper.getConnection();
			preparedStatement = connection.prepareStatement(query.toString());
			checkForNullAndSetinStatement(preparedStatement,addressId,1);
			checkForNullAndSetinStatement(preparedStatement,addressLinkId,2);
			preparedStatement.setString(3,reserved);
			checkForNullAndSetinStatement(preparedStatement,frequency,4);
			checkForNullAndSetinStatement(preparedStatement,internal,5);
			checkForNullAndSetinStatement(preparedStatement,operationId,6);
			checkForNullAndSetinStatement(preparedStatement,oldOpId,7);
			preparedStatement.executeUpdate();
		} catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new AddressException(e.getMessage());
        } finally {
            DBHelper.cleanup(connection, preparedStatement);
        }
    }

    private void checkForNullAndSetinStatement(final PreparedStatement preparedStatement,final Long value,final int index) throws SQLException {
    	if(value != null) {
			preparedStatement.setLong(index,value.longValue());
		} else {
			preparedStatement.setNull(index,Types.NUMERIC);
		}
    }
}



