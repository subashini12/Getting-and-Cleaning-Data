package it.sella.address.implementation.dbhelper;

import it.sella.address.implementation.util.DBHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

public class MUCAHelper {

   
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(MUCAHelper.class);
	
    /*
     *	 This method is used to get display details for Mutuo Cartolarizzato products
     *   to display in address mask.
     *   In case of any exception a default String "Mutuo Cartolarizzato" will be returned.
     */
    
    public String getMucaDisplayDetails(final Long mucaContoId) {
    	String mucaDisplayDetails = "";
        Connection connection = null;
        CallableStatement statement = null;
        try {
            connection = DBHelper.getConnection();
            statement = connection.prepareCall("{ call ? := mcart_pkg_indirizzi.getLabel(?) }");
            statement.registerOutParameter(1,Types.VARCHAR);
            statement.setLong(2,mucaContoId.longValue());
            statement.execute() ;
            mucaDisplayDetails = statement.getString(1);
        } catch (final SQLException e) {
            log4Debug.severeStackTrace(e);
            mucaDisplayDetails = "Mutuo Cartolarizzato";
        } finally {
            DBHelper.cleanup(connection,statement);
        }
		return mucaDisplayDetails;
    }
	
}
