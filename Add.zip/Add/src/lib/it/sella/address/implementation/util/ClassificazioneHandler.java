/**
 * Created by IntelliJ IDEA.
 * User: ssil72
 * Date: Jun 15, 2004
 * Time: 3:51:06 PM
 */
package it.sella.address.implementation.util;

import it.sella.address.SubSystemHandlerException;
import it.sella.classificazione.ClassificazioneFactory;
import it.sella.classificazione.ClassificazioneView;
import it.sella.classificazione.FactoryManager;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;

import javax.ejb.CreateException;
import javax.naming.NamingException;

/**
 * Class members used to access classificazione apis
 */

public class ClassificazioneHandler
{
    
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(ClassificazioneHandler.class);

    /**
     * Gets the classificazioneView corresponding to the child causale and parent causale passed.
     * @param causale
     * @param parentCausale
     * @return ClassificazioneView
     * @throws SubSystemHandlerException
     * @throws RemoteException
     */

    public static ClassificazioneView getClassificazioneView(final String causale, final String parentCausale) throws SubSystemHandlerException, RemoteException {
        final Long parentId = getClassificazioneFactory().getClassificazione(parentCausale, 0L, 0L).getId();
        return getClassificazioneFactory().getClassificazione(causale, 0L, parentId);
    }

    /**
     * Gets the classificazioneview corresponding to the id passed
     * @param classificazioneId
     * @return ClassificazioneView
     * @throws SubSystemHandlerException
     * @throws RemoteException
     */

    public static ClassificazioneView getClassificazioneView(final Long classificazioneId) throws SubSystemHandlerException, RemoteException {
        return getClassificazioneFactory().getClassificazione(classificazioneId);
    }

    /**
     * Gets the collection of child classificazioneViews under the input parent causale
     * @param parentCausale
     * @return Collection (ClassificazioneView)
     * @throws SubSystemHandlerException
     * @throws RemoteException
     */

    public static Collection getChildClassificazioneViewsForParentCausale(final String parentCausale) throws SubSystemHandlerException, RemoteException {
        final Long parentId = getClassificazioneFactory().getClassificazione(parentCausale, 0L, 0L).getId();
        return getClassificazioneFactory().listClassificazioni(0L, parentId);
    }

    private static ClassificazioneFactory getClassificazioneFactory() throws RemoteException,SubSystemHandlerException {
        try {
            return FactoryManager.getClassificazioneFactory();
        } catch(final CreateException e) {
            log4Debug.severeStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        } catch(final NamingException e) {
            log4Debug.severeStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

}
