package it.sella.address.implementation.util;

import it.sella.address.HelperException;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateHandler {
	
	/** returns the date in the specified format
	 @ param Timestamp dateToformat
	 @ param String pattern
	 @ return String
	 */

	public String formatDate(final Timestamp dateToConvert, final String pattern) {
		String formattedDate = null;
		if(dateToConvert != null && pattern != null){
			formattedDate = new SimpleDateFormat(pattern).format(dateToConvert);
		}
		return formattedDate;
	}
	
	 /** This method creates the timestamp object with the date value and pattern
     * passed to this function
     @ param String date
     @ param String pattern
     @ return Timestamp
     @ exception HelperException
     */

    public Timestamp getTimestampFromDateString( final String date, final String pattern ) throws HelperException {
        Date tempDate = null;
        Timestamp retTimestamp;
        char datechar;
        char patternchar;
        String dateextrchar = null;
        String patternextrchar = null;
        try {
        	final SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
            dateFormat.setLenient(false);
            tempDate = dateFormat.parse(date);
            retTimestamp = new Timestamp(tempDate.getTime());
            for( int i = date.length() - 1; i > 0; i-- ) {
                datechar = date.charAt(i);
                if( Character.isDigit(datechar) ) {
                    if( dateextrchar == null ) {
                    	dateextrchar = "";
                    }
                    dateextrchar = dateextrchar + datechar;
                } else {
                    if( dateextrchar == null ) {
                    	dateextrchar = "";
                    }
                    break;
                }
            }
            for( int j = pattern.length() - 1; j > 0; j-- ) {
                patternchar = pattern.charAt(j);
                if( Character.isLetter(patternchar) ) {
                    if( patternextrchar == null ) {
                    	patternextrchar = "";
                    }
                    patternextrchar = patternextrchar + patternchar;
                } else {
                    break;
                }
            }
            if( patternextrchar.length() != dateextrchar.length() ) {
                throw new HelperException(Helper.getMessage("ANAG-1320"));
            }
        } catch(final ParseException pe) {
        	throw new HelperException(Helper.getMessage("ANAG-1320"));
        }
        return retTimestamp;
    }
    
    public Timestamp getCurrentDateInTimeStampFormat() {
    	return new Timestamp(System.currentTimeMillis());
    }

}
