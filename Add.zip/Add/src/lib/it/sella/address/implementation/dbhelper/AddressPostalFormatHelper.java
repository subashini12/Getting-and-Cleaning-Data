package it.sella.address.implementation.dbhelper;

import it.sella.address.AddressException;
import it.sella.address.implementation.util.DBHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class AddressPostalFormatHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressPostalFormatHelper.class);
    
    public String getPostalAddress(final Long soggettoId, final Long productId,
    		final String subSystemCausale, final String bypassCode, final String skipDomolCheck) throws AddressException, RemoteException{
        Connection connection = null;
        CallableStatement callableStatement = null;

        String postalAECode = null ;
        try {
            connection = DBHelper.getConnection();
            final String sql = "{ call ? := ADDINST_PKG_POSTALFORMAT.ADD_FN_IND_ATTR(?,?,NULL,?,?,?) }" ;
            callableStatement = connection.prepareCall(sql);
            callableStatement.registerOutParameter(1,java.sql.Types.VARCHAR);
            callableStatement.setInt(2,soggettoId.intValue());
            callableStatement.setInt(3,productId.intValue());
            callableStatement.setString(4,subSystemCausale);
            callableStatement.setString(5,skipDomolCheck);
            callableStatement.setString(6,bypassCode);
            callableStatement.execute() ;
            postalAECode = callableStatement.getString(1) ;
        } catch(final SQLException sqlException) {
            log4Debug.severeStackTrace(sqlException);
            throw new AddressException(sqlException.getMessage());
        } finally {
            DBHelper.cleanup(connection, callableStatement);
        }
        return postalAECode;
    }

    public String getPostalAddressInXMLFormat(final Long soggettoId, final Long productId,
    		final String subSystemCausale, final String bypassCode, final String skipDomolCheck) throws AddressException, RemoteException{
        Connection connection = null;
        CallableStatement callableStatement = null;
        String postalAECode = null ;
        try {
            connection = DBHelper.getConnection();
            final String sql = "{ call ? := ADDINST_PKG_POSTALFORMAT.ADD_FN_IND_ATTR_XMLFORMAT(?,?,NULL,?,?,?) }" ;
            callableStatement = connection.prepareCall(sql);
            callableStatement.registerOutParameter(1,java.sql.Types.VARCHAR);
            callableStatement.setInt(2,soggettoId.intValue());
            callableStatement.setInt(3,productId.intValue());
            callableStatement.setString(4,subSystemCausale);
            callableStatement.setString(5,skipDomolCheck);
            callableStatement.setString(6,bypassCode);
            callableStatement.execute() ;
            

            postalAECode = callableStatement.getString(1) ;
        } catch(final SQLException sqlException) {
            log4Debug.severeStackTrace(sqlException);
            throw new AddressException(sqlException.getMessage());
        } finally {
            DBHelper.cleanup(connection, callableStatement);
        }
        return postalAECode;
    }

    public String getPostalAddress(final Long soggettoId, final Long productId,
    		final String subSystemCausale, final String intestazione, 
    		final Long errorCode, final String bypassCode, final String skipDomolCheck) throws AddressException, RemoteException {
    	Long error = null;
        String postalAECode = null ;
        if(intestazione == null && errorCode == null) {
        	postalAECode = getPostalAddress(soggettoId, productId, subSystemCausale, bypassCode, null);
		} else {
	        error = errorCode == null ? 0L : errorCode;  
	        Connection connection = null;
	        CallableStatement callableStatement = null;
	        try {
	            String sql = null;
	            connection = DBHelper.getConnection();
	            if(intestazione != null) {
	                sql = "{ call ? := ADDINST_PKG_POSTALFORMAT.ADD_FN_IND_ATTR(?,?,?,?,?,?,?) }";
	            } else {
	                sql = "{ call ? := ADDINST_PKG_POSTALFORMAT.ADD_FN_IND_ATTR(?,?,?,?,?,?) }";
	            }
	            callableStatement = connection.prepareCall(sql);
	            callableStatement.registerOutParameter(1,java.sql.Types.VARCHAR);
	            callableStatement.setInt(2,soggettoId.intValue());
	            callableStatement.setInt(3,productId.intValue());
	            if(intestazione != null) {
	                callableStatement.setString(4,intestazione);
	                callableStatement.setLong(5, error.longValue());
	                callableStatement.setString(6, subSystemCausale);
	                callableStatement.setString(7, skipDomolCheck);
	                callableStatement.setString(8, bypassCode);
	            } else {
	                callableStatement.setLong(4, error.longValue());
	                callableStatement.setString(5, subSystemCausale);
	                callableStatement.setString(6, skipDomolCheck);
	                callableStatement.setString(7, bypassCode);
	            }
	            callableStatement.execute() ;
	            postalAECode = callableStatement.getString(1) ;
	        } catch(final SQLException sqlException) {
	            log4Debug.severeStackTrace(sqlException);
	            throw new AddressException(sqlException.getMessage());
	        } finally {
	            DBHelper.cleanup(connection, callableStatement);
	        }
		}
        return postalAECode;
    }

    public String getPostalAddressInXMLFormat(final Long soggettoId, final Long productId,
    		final String subSystemCausale, final String intestazione, 
    		final Long errorCode, final String bypassCode,final String skipDomolCheck) throws AddressException, RemoteException {
    	Long error = null;
        String postalAECode = null ;
        if(intestazione == null && errorCode == null) {
        	postalAECode = getPostalAddressInXMLFormat(soggettoId, productId, subSystemCausale, bypassCode, skipDomolCheck);
		} else {
	        error = errorCode == null ? 0L : errorCode;
	        Connection connection = null;
	        CallableStatement callableStatement = null;
	        try {
	            String sql = null;
	            connection = DBHelper.getConnection();
	            if(intestazione != null) {
	                sql = "{ call ? := ADDINST_PKG_POSTALFORMAT.ADD_FN_IND_ATTR_XMLFORMAT(?,?,?,?,?,?,?) }";
	            } else {
	                sql = "{ call ? := ADDINST_PKG_POSTALFORMAT.ADD_FN_IND_ATTR_XMLFORMAT(?,?,?,?,?,?) }";
	            }
	            callableStatement = connection.prepareCall(sql);
	            callableStatement.registerOutParameter(1,java.sql.Types.VARCHAR);
	            callableStatement.setInt(2,soggettoId.intValue());
	            callableStatement.setInt(3,productId.intValue());
	            if(intestazione != null) {
	                callableStatement.setString(4,intestazione);
	                callableStatement.setLong(5, error.longValue());
	                callableStatement.setString(6, subSystemCausale);
	                callableStatement.setString(7, skipDomolCheck);
	                callableStatement.setString(8, bypassCode);
	            } else {
	                callableStatement.setLong(4, error.longValue());
	                callableStatement.setString(5, subSystemCausale);
	                callableStatement.setString(6, skipDomolCheck);
	                callableStatement.setString(7, bypassCode);
	            }
	            callableStatement.execute() ;
	            postalAECode = callableStatement.getString(1) ;
	        } catch(final SQLException sqlException) {
	            log4Debug.severeStackTrace(sqlException);
	            throw new AddressException(sqlException.getMessage());
	        } finally {
	            DBHelper.cleanup(connection, callableStatement);
	        }
		}
        return postalAECode;
    }    
}
