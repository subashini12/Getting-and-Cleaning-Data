package it.sella.address.implementation.dbhelper;

import it.sella.address.AddressConstants;
import it.sella.address.AddressException;
import it.sella.address.AddressManagerBeanHelperException;
import it.sella.address.HelperException;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.addresslink.AddressLink;
import it.sella.address.implementation.addresslink.IAddressLinkBeanManager;
import it.sella.address.implementation.ae.AEAddress;
import it.sella.address.implementation.ae.AEAddressView;
import it.sella.address.implementation.ae.IAEAddressBeanManager;
import it.sella.address.implementation.factory.ReflectionUtil;
import it.sella.address.implementation.util.Helper;
import it.sella.logserver.LoggerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;

public class AddressAESetterHelper extends AddressSetterBaseHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAESetterHelper.class);
	private static final String AEADD = "AEADD";
	private static final String ADD_API_SETDOMOL = "ADD-API-SETDOMOL";	
	private static final String ADD_API_DELDOMOL = "ADD-API-DELDOMOL";
	private static final String GIORN = "GIORN";
	private static final String AN_FREQ = "AN_FREQ";

	public void setDOMOL(final Long soggettoId, final Long productId,final String subSystemCausale) throws AddressException, RemoteException, AddressManagerBeanHelperException, CreateException{
		Long subSystemId = null;
		AddressLink addressLink = null;
		AEAddress aeAddress = null;
		Long opId = null;
		Long domolInternal = null;
		Long addressLinkerId = null;
		IAEAddressBeanManager aeAddressBeanManager = null;
		try {
			isNotNull(soggettoId,productId,subSystemCausale);
			subSystemId = getClassificazioneId(subSystemCausale, AddressConstants.SUBSYS);
			domolInternal = getClassificazioneId(AddressConstants.DOMOL, AEADD);
			addressLink = findBySoggettoSubsytemPCId(soggettoId,subSystemId,productId);
			opId = new AddressLogHelper().logAddressOperation(ADD_API_SETDOMOL, null, null, false);
			aeAddressBeanManager = (IAEAddressBeanManager) ReflectionUtil.createServiceImplInstance(AddressConstants.BUNDLE_KEY, AddressConstants.DAOIMPL_KEY_FOR_AEADDRESS);
			addressLinkerId =  addressLink.getAddressLinkId();
			aeAddress = aeAddressBeanManager.findByLinkedId(addressLinkerId);
			checkInternal(aeAddress.getInternal());
			if(!domolInternal.equals(aeAddress.getInternal())) {
				aeAddress.setInternal(domolInternal);
				aeAddress.setOpId(opId);
				aeAddressBeanManager.update(aeAddress);
			}
		} catch (final HelperException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		} catch (final FinderException e) {
			  final AEAddressView aeAddressView = new AEAddressView();
			  aeAddressView.setAddressLinkId(addressLinkerId);
			  aeAddressView.setFrequency(getClassificazioneId(GIORN,AN_FREQ));
			  aeAddressView.setInternal(getClassificazioneId(AddressConstants.DOMOL, AEADD));
			  aeAddressView.setReserved(0L);
			  aeAddressView.setOpId(opId);
			  aeAddressBeanManager.create(aeAddressView);
		} catch (final LoggerException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		}
	}

	public void removeDOMOL(final Long soggettoId, final Long productId,final String subSystemCausale) throws AddressException, RemoteException {
		Long subSystemId = null;
		Long domorInternal = null;
		Long domolInternal = null;
		AddressLink addressLink = null;
		AEAddress aeAddress = null;
		try {
			isNotNull(soggettoId,productId,subSystemCausale);
			subSystemId = getClassificazioneId(subSystemCausale, AddressConstants.SUBSYS);
			domolInternal = getClassificazioneId(AddressConstants.DOMOL, AEADD);
			domorInternal = getClassificazioneId(AddressConstants.DOMOR, AEADD);

			addressLink = findBySoggettoSubsytemPCId(soggettoId,subSystemId,productId);
			final IAEAddressBeanManager aeAddressBeanManager = (IAEAddressBeanManager) ReflectionUtil.createServiceImplInstance(AddressConstants.BUNDLE_KEY, AddressConstants.DAOIMPL_KEY_FOR_AEADDRESS);
			aeAddress = aeAddressBeanManager.findByLinkedId( addressLink.getAddressLinkId());
			if(aeAddress.getInternal() != null && !domolInternal.equals(aeAddress.getInternal()) && !domorInternal.equals(aeAddress.getInternal())) {
				throw new AddressException(Helper.getMessage("ADDR-0008"));
			}
			if(aeAddress.getInternal() != null && domolInternal.equals(aeAddress.getInternal())) {
				aeAddress.setInternal(domorInternal);
				aeAddress.setOpId(new AddressLogHelper().logAddressOperation(ADD_API_DELDOMOL, null, null, false));
				aeAddressBeanManager.update(aeAddress);
			}
		} catch (final HelperException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		} catch (final AddressManagerBeanHelperException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		} catch (final FinderException e) {
			log4Debug.warnStackTrace(e);
		/*  There is no iternal so its not an error and no need to navigate exception on pages */
		/*	throw new AddressException(Helper.getMessage("ADDR-0009"));*/
		} catch (final LoggerException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		}
	}

	private AddressLink findBySoggettoSubsytemPCId(final Long soggettoId, final Long subSystemId, final Long productId) throws AddressException, RemoteException,HelperException {
		try {
			return ((IAddressLinkBeanManager) ReflectionUtil.createServiceImplInstance(AddressConstants.BUNDLE_KEY, AddressConstants.DAOIMPL_KEY_FOR_ADDRESSLINK)).findBySoggettoSubsytemPCId(soggettoId,subSystemId,productId);
		} catch (final FinderException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(Helper.getMessage("ADDR-0002"));
		}
	}

	public void isNotNull(final Long soggettoId, final Long productId,final String subSystemCausale) throws AddressException {
		if(soggettoId == null || productId == null || subSystemCausale == null || subSystemCausale.trim().length() < 1 ) {
			throw new AddressException(Helper.getMessage("ADDR-0003"));
		}
	}

	private void checkInternal(final Long internal) throws AddressException,SubSystemHandlerException,RemoteException, AddressManagerBeanHelperException {
		if(internal != null) {
			final String existingInternal = getClassificazioneCausale(internal);
			/*if("DOMBK".equals(existingInternal)) {
				throw new AddressException(Helper.getMessage("ADDR-0004"));
			} else*/ if(AddressConstants.DOMCP.equals(existingInternal)) {
				throw new AddressException(Helper.getMessage("ADDR-0005"));
			} else if(AddressConstants.DOMDG.equals(existingInternal)) {
				throw new AddressException(Helper.getMessage("ADDR-0006"));
			} else if(AddressConstants.DOMKO.equals(existingInternal)) {
				throw new AddressException(Helper.getMessage("ADDR-0007"));
			}
		}
	}
}
