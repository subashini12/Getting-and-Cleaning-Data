package it.sella.address.implementation.util;

import java.sql.Timestamp;


public class UtilHelper {
	
	public static Long getLongValue(final String value) {
		Long resultL = null;
		if (value != null && value.trim().length() >= 1
				&& !"null".equalsIgnoreCase(value)) {
			resultL = Long.valueOf(value);
		}
		return resultL;
	}
	
	public static String getTag( final String tagName, final String value) {
		final StringBuffer output = new StringBuffer();
		output.append("<").append(tagName).append(">").append(value).append("</").append(tagName).append(">").toString();	
		return output.toString();
	}
	
	public static String getTagWithEscapeXML( final String tagName, final String value) {
		final StringBuffer output = new StringBuffer();
		output.append("<").append(tagName).append(">").append(StringHandler.encodeXMLTagValue(value)).append("</").append(tagName).append(">").toString();	
		return output.toString();
	}
	
	public static String getTagWithValueCheck( final String tagName, final String value) {
    	final StringBuffer output = new StringBuffer();
        return output.append("<").append(tagName).append(">").append((value != null ? value.trim() : "")).append("</").append(tagName).append(">").toString();
    }
	
	public static String getTagWithValueCheckWithEscapeXML( final String tagName, final String value) {
    	final StringBuffer output = new StringBuffer();
        return output.append("<").append(tagName).append(">").append((value != null ? StringHandler.encodeXMLTagValue(value.trim()) : "")).append("</").append(tagName).append(">").toString();
    }
	
	public static void getOpenTag(final StringBuffer buffer, final String tagName) {
		buffer.append("<").append(tagName).append(">");
	}
	
	public static void getCloseTag( StringBuffer buffer, final String tagName) {
		buffer.append("</").append(tagName).append(">");
	}
	
	public static void addLog(final StringBuffer buffer,final String tagName,final String value) {
		buffer.append("<").append(tagName).append(">");
		buffer.append(value != null ? StringHandler.encodeXMLTagValue(value) : "");
		buffer.append("</").append(tagName).append(">");
	}
	
	public static void addLog(final StringBuffer buffer,final String tagName,final Long value) {
		buffer.append("<").append(tagName).append(">");
		buffer.append(value != null ? StringHandler.encodeXMLTagValue(String.valueOf(value)) : "");
		buffer.append("</").append(tagName).append(">");
	}
	
	public static void addLog(final StringBuffer buffer,final String tagName,final Timestamp value) {
		buffer.append("<").append(tagName).append(">");
		buffer.append(value != null ? StringHandler.encodeXMLTagValue(String.valueOf(value)) : "");
		buffer.append("</").append(tagName).append(">");
	}
}
