package it.sella.address.implementation.dbhelper;

import it.sella.address.AddressException;
import it.sella.address.AddressManagerBeanHelperException;
import it.sella.address.AddressView;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.addresslink.AddressLink;
import it.sella.address.implementation.addresslink.IAddressLinkBeanManager;
import it.sella.address.implementation.ae.AEAddress;
import it.sella.address.implementation.ae.AEAddressView;
import it.sella.address.implementation.ae.IAEAddressBeanManager;
import it.sella.address.implementation.factory.ReflectionUtil;
import it.sella.address.implementation.util.ClassificazioneHandler;
import it.sella.address.implementation.util.StringHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;

import javax.ejb.FinderException;

public class AddressSetterBaseHelper extends AddressCreateBaseHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressSetterBaseHelper.class);

    public void setAddress(final AddressLink addressLink, final AddressView addressView, final Long opId) throws AddressManagerBeanHelperException, RemoteException {
    	 IAEAddressBeanManager aeAddressBeanManager = null;
        Long internalToBeSet = null;
        try {
        	aeAddressBeanManager = (IAEAddressBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.AEAddress");
            final Long addressId = createAddr(addressView, opId);
            final StringHandler stringHandler = new StringHandler();
            if(!stringHandler.checkForEquality(addressId, addressLink.getAddressId())) {
            	addressLink.setAddressId(addressId);
            	addressLink.setOpId(opId);
            	((IAddressLinkBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.AddressLink")).update(addressLink);
            }
            final Long addressLinkerId = addressLink.getAddressLinkId();
            try {
                final AEAddress aeAddress = aeAddressBeanManager.findByLinkedId(addressLinkerId);
                final String internalNewValue = addressView.getInternal()!= null ? ClassificazioneHandler.getClassificazioneView(addressView.getInternal()).getCausale() : null;
                if (aeAddress.getInternal() != null &&
                	 aeAddress.getInternal() != 0 &&
                	"DOMOL".equals(ClassificazioneHandler.getClassificazioneView(aeAddress.getInternal()).getCausale()) && !"DOMNO".equals(internalNewValue)) {
                	internalToBeSet = aeAddress.getInternal();
                } else {
                    /*if(aeAddress.getInternal() != null && aeAddress.getInternal() != 0 &&
                    		"DOMOL".equals(ClassificazioneHandler.getClassificazioneView(aeAddress.getInternal()).getCausale()) &&
                    		"DOMOR".equals(ClassificazioneHandler.getClassificazioneView(addressView.getInternal()).getCausale())) {
                    	internalToBeSet = aeAddress.getInternal();
                    } else {*/
                    	internalToBeSet = addressView.getInternal();
                    //}
                }
                log4Debug.debug("AddressSetterBaseHelper   ======================    internalToBeSet    ==========    ",internalToBeSet);
                if(!stringHandler.checkForEquality(addressView.getFrequency(),aeAddress.getFrequency()) ||
                		!stringHandler.checkForEquality(internalToBeSet,aeAddress.getInternal()) ||
                		!stringHandler.checkForEquality(addressView.getReserved(),aeAddress.getReserved())) {
	                aeAddress.setFrequency(addressView.getFrequency());
	                aeAddress.setInternal(internalToBeSet);
	                aeAddress.setReserved(addressView.getReserved());
	                aeAddress.setOpId(opId);
	                aeAddressBeanManager.update(aeAddress);
                }
            } catch(final FinderException e) {
                if(addressView.getFrequency() != null || addressView.getInternal() != null || addressView.getReserved() != null) {
                	final AEAddressView aeAddressView = new AEAddressView();
                    aeAddressView.setAddressLinkId(addressLinkerId);
                    aeAddressView.setFrequency(addressView.getFrequency());
                    aeAddressView.setInternal(addressView.getInternal());
                    aeAddressView.setReserved(addressView.getReserved());
                    aeAddressView.setOpId(opId);
                    aeAddressBeanManager.create(aeAddressView);
                }
            }
            if(!"ANAG".equals(addressView.getCausaleSubsystem())) {
                new AddressLogHelper().logInAddressLogTable(addressView,"M");
            }
        } catch(final AddressException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressManagerBeanHelperException(e.getMessage());
        } catch (final SubSystemHandlerException e) {
        	log4Debug.severeStackTrace(e);
            throw new AddressManagerBeanHelperException(e.getMessage());
        }
    }
}