package it.sella.address.implementation.dbhelper;

import it.sella.address.AddressException;
import it.sella.address.AddressManagerBeanHelperException;
import it.sella.address.AddressManagerMapperException;
import it.sella.address.AddressManagerValidatorException;
import it.sella.address.AddressView;
import it.sella.address.implementation.addresslink.AddressLink;
import it.sella.address.implementation.addresslink.AddressLinkView;
import it.sella.address.implementation.addresslink.IAddressLinkBeanManager;
import it.sella.address.implementation.ae.AEAddressView;
import it.sella.address.implementation.ae.IAEAddressBeanManager;
import it.sella.address.implementation.factory.ReflectionUtil;
import it.sella.address.implementation.util.CommonPropertiesUtil;
import it.sella.address.implementation.util.MapperHelper;
import it.sella.address.implementation.util.MapperHelperException;
import it.sella.logserver.LoggerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.StringTokenizer;

import javax.ejb.FinderException;

public class AddressCreateHelper extends AddressCreateBaseHelper {


    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressCreateHelper.class);

    public void createAddress( final AddressView addressView ) throws RemoteException, AddressManagerValidatorException, AddressManagerMapperException {

    	final String logOperation = "ADDR-CENS";
    	String operationResult = "FAILURE";
    	final StringBuffer logForHost = new StringBuffer();
        String errorMessage = null;
        Long operationId = null;
        final AddressLogHelper addressLogHelper = new AddressLogHelper();
        try {
    		operationId = addressView.getOpId() == null ?
				addressLogHelper.logAddressOperation(logOperation, addressView, null, false) : addressView.getOpId();
			final Long subSystemId = getClassificazioneId(addressView.getCausaleSubsystem(), "SUBSYS");
            if( !"ANAG".equals(addressView.getCausaleSubsystem()) && addressView.getProductContoId() == null ) {
                // if the product/conto id is not available throw an exception in case of other systems except anagrafe
            	errorMessage = "PRODUCT/CONTO ID IS NOT AVAILABLE";
                throw new AddressManagerBeanHelperException(errorMessage);
            }
           	validateAddressTypeInProductID(addressView);
           	//Product Address (nazione) can not be different from the address (Nazione) of residence or domicile For PF
           	validateNazioneWithIREIDONazione(addressView);
           	if( addressView.getProductContoId() != null ) {
                try {
                	((IAddressLinkBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.AddressLink")).findBySoggettoSubsytemPCId(addressView.getSoggettoId(), subSystemId, addressView.getProductContoId());
                	errorMessage = "ADDRESS FOR PRODUCT/CONTO ID IS ALREADY EXISTING";
                    throw new AddressManagerBeanHelperException(errorMessage);
                } catch(final FinderException e) {
                	log4Debug.warnStackTrace(e);
                }
            }
            if( isCompatibleIndirizzo(addressView.getCausaleSubsystem(), addressView.getCausaleTipoIndirizzo()) ) {
            	final Long tipoIndirizzoId = getClassificazioneId(addressView.getCausaleTipoIndirizzo(), "IND");
                validateAddressDuplicate(addressView.getSoggettoId(), addressView.getCausaleSubsystem(),
                    		addressView.getCausaleTipoIndirizzo(), subSystemId, tipoIndirizzoId);
            	final AddressLinkView addressLinkView = new AddressLinkView();
                addressLinkView.setAddressId(createAddr(addressView, operationId));
                addressLinkView.setAddressType(tipoIndirizzoId);
                addressLinkView.setSoggettoId(addressView.getSoggettoId());
                addressLinkView.setSubSystem(subSystemId);
                addressLinkView.setLinkedId(addressView.getProductContoId());
                addressLinkView.setOpId(operationId);
                final AddressLink addressLink = ((IAddressLinkBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.AddressLink")).create(addressLinkView);
                if ( addressView.getFrequency() != null || addressView.getInternal() != null ||
                		addressView.getReserved() != null ) {
                	final AEAddressView aeView = new AEAddressView();
                    aeView.setAddressLinkId(addressLink.getAddressLinkId());
                    aeView.setFrequency(addressView.getFrequency());
                    aeView.setInternal(addressView.getInternal());
                    aeView.setReserved(addressView.getReserved());
                    aeView.setOpId(operationId);
                    ((IAEAddressBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.AEAddress")).create(aeView);
                }
            } else {
            	errorMessage = "THE TIPO INDIRIZZO IS NOT COMPATIBLE FOR THIS SUBSYSTEM";
                throw new AddressManagerBeanHelperException(errorMessage);
            }
            if(!"ANAG".equals(addressView.getCausaleSubsystem())) {
            	new AddressLogHelper().logInAddressLogTable(addressView,"I");
            }
            operationResult = "SUCCESS";
            //The mapper call for address should be called at the end of the method.
            //Whether aligned with Host or not, the flow(address will be created) will be SUCCESS
            if(addressView.getNch() != null && new CommonPropertiesUtil().isHostAllowedForLoginBank()) {
            	logForHost.append(new MapperHelper().aggiornaIndirizzo(addressView,null));
            }
        } catch(final AddressException e) {
            log4Debug.warnStackTrace(e);
            errorMessage = e.getMessage();
            throw new AddressManagerValidatorException(e.getMessage());
        } catch(final LoggerException e) {
            log4Debug.warnStackTrace(e);
            errorMessage = e.getMessage();
            throw new AddressManagerValidatorException(e.getMessage());
        } catch(final MapperHelperException e) {
			log4Debug.warnStackTrace(e);
			final StringTokenizer tokenizer = new StringTokenizer(e.getMessage(),"�");
           // errorMessage = tokenizer.nextToken();
			if( tokenizer.hasMoreTokens() ) {
				logForHost.append(tokenizer.nextToken());
			}
            throw new AddressManagerMapperException(e.getMessage());
        } catch (final AddressManagerBeanHelperException e) {
        	log4Debug.warnStackTrace(e);
            errorMessage = e.getMessage();
            throw new AddressManagerValidatorException(e.getMessage());
		} finally {
            final StringBuffer logMessage = new StringBuffer(new AddressLogHelper().getLogData(addressView,false));
            logMessage.append(new AddressLogHelper().getLogDataFromAddressView(addressView));
            try {
				new AddressLogHelper().logMessageWithErrorMsg(addressView.getSoggettoId(),"CREATE ADDRESS", logMessage.toString(), logOperation, operationResult, null,errorMessage);
			} catch (final AddressManagerBeanHelperException e) {
				log4Debug.warnStackTrace(e);
	            errorMessage = e.getMessage();
				throw new AddressManagerValidatorException(e.getMessage());
			}
			try {
				addressLogHelper.updateAddressLog(operationId, addressView.getSoggettoId(), errorMessage);
			} catch (final LoggerException e) {
				log4Debug.warn("This exception is just caught not to affect the parent transaction !!!!!");
				log4Debug.warnStackTrace(e);
			}
			try {
				if( addressView.getOpId() == null ) {
					addressLogHelper.logAddressOpDetails(operationId, logForHost.toString(), "");
				}
			} catch (final LoggerException e) {
				log4Debug.warn("This exception is just caught not to affect the parent transaction !!!!!");
				log4Debug.warnStackTrace(e);
			}
		}
    }
}
