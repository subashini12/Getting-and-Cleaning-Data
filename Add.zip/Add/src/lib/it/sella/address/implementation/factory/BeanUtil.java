package it.sella.address.implementation.factory;

import it.sella.address.AddressException;

import java.lang.reflect.InvocationTargetException;

import org.apache.commons.beanutils.PropertyUtils;


public class BeanUtil {

	public static Object copyProperties(final Object dest, final Object orig) throws AddressException {
		try {
			PropertyUtils.copyProperties(dest, orig);
		} catch (final IllegalAccessException e) {
			throw new AddressException(e.getMessage());
		} catch (final InvocationTargetException e) {
			throw new AddressException(e.getMessage());
		} catch (final NoSuchMethodException e) {
			throw new AddressException(e.getMessage());
		}
		return dest;
	}
}
