package it.sella.address.implementation.addr;


public class AddressView implements Address   //extends EJBViewAdapter
{

	public Long getId() {
		return id;
	}
	public void setId(final Long id) {
		this.id = id;
	}

	public String getProvincia()
    {
        return provincia;
    }

    public void setProvincia(final String provincia)
    {
        this.provincia = provincia;
    }

    public Long getCapId()
    {
        return capId;
    }

    public void setCapId(final Long capId)
    {
        this.capId = capId;
    }

    public String getCapValue()
    {
        return capValue;
    }

    public void setCapValue(final String capValue)
    {
        this.capValue = capValue;
    }

    public Long getNazione()
    {
        return nazione;
    }

    public void setNazione(final Long nazione)
    {
        this.nazione = nazione;
    }

    public String getCitta()
    {
        return citta;
    }

    public void setCitta(final String citta)
    {
        this.citta = citta;
    }

    public String getIndirizzo()
    {
        return indirizzo;
    }

    public void setIndirizzo(final String indirizzo)
    {
        this.indirizzo = indirizzo;
    }

	public void setOpId(final Long opId) {
		this.opId = opId;
	}

	public Long getOpId() {
		return this.opId;
	}

    //protected parameterlist methods
    protected String getParameterList()
    {
        return "Address"+this.indirizzo;
    }

    protected String getShortParameterList()
    {
        return getParameterList();
    }

	public String getNormStatus() {
		return normStatus;
	}

	public void setNormStatus(final String normStatus) {
		this.normStatus = normStatus;
	}

	/**
	 * @return the cittaName
	 */
	public String getCittaName() {
		return cittaName;
	}
	/**
	 * @param cittaName the cittaName to set
	 */
	public void setCittaName(String cittaName) {
		this.cittaName = cittaName;
	}
	/**
	 * @return the nazioneName
	 */
	public String getNazioneName() {
		return nazioneName;
	}
	/**
	 * @param nazioneName the nazioneName to set
	 */
	public void setNazioneName(String nazioneName) {
		this.nazioneName = nazioneName;
	}
	/**
	 * @return the provinciaSigla
	 */
	public String getProvinciaSigla() {
		return provinciaSigla;
	}
	/**
	 * @param provinciaSigla the provinciaSigla to set
	 */
	public void setProvinciaSigla(String provinciaSigla) {
		this.provinciaSigla = provinciaSigla;
	}
	/**
	 * @return the provinciaName
	 */
	public String getProvinciaName() {
		return provinciaName;
	}
	/**
	 * @param provinciaName the provinciaName to set
	 */
	public void setProvinciaName(String provinciaName) {
		this.provinciaName = provinciaName;
	}
	/**
	 * @return the presso
	 */
	public String getPresso() {
		return presso;
	}
	/**
	 * @param presso the presso to set
	 */
	public void setPresso(String presso) {
		this.presso = presso;
	}
	/**
	 * @return the edificio
	 */
	public String getEdificio() {
		return edificio;
	}
	/**
	 * @param edificio the edificio to set
	 */
	public void setEdificio(String edificio) {
		this.edificio = edificio;
	}

    private String provincia;
    private Long capId;
    private String capValue;
    private Long nazione;
    private String citta;
    private String indirizzo;
    private Long opId;
    private String normStatus;
    private Long id;
    private String cittaName;
    private String nazioneName;
    private String provinciaSigla;
    private String provinciaName;
    private String presso;
    private String edificio;


}
