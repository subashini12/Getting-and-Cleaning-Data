package it.sella.address.implementation;


public class AddressAdminFactory {
	
    
    private static AddressAdminFactory addressAdminFactoryObj;
    private IAddressAdmin addressAdmin = null;

    protected AddressAdminFactory()
    {
    	// explicit default constructor
    }

    public static AddressAdminFactory getInstance()
    {
        if(addressAdminFactoryObj == null) {
			addressAdminFactoryObj = new AddressAdminFactory();
		}
        return addressAdminFactoryObj;
    }

    public IAddressAdmin getAddressAdmin()
    {
        if( addressAdmin == null) {
			addressAdmin = new AddressAdminClientImpl();
		}
        return addressAdmin;
    }


}
