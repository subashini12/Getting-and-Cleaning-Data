package it.sella.address.implementation.factory;

import java.util.HashMap;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class ResourceFinder {
	
	private static final ResourceBundle INTERNAL_BUNDLE = ResourceBundle.getBundle("it.sella.address.implementation.factory.InternalFinder");
    private static final Map<String,ResourceBundle> RESOURCEMAP = new HashMap<String, ResourceBundle>();
    
    private static void initializeBundle(){
    	RESOURCEMAP.put("INTERNAL", INTERNAL_BUNDLE );
    }
    
    public static String getString( final String bundleKey, final String key){
    	initializeBundle();    
        String resultStr = "";
    	try {
    		resultStr = RESOURCEMAP.get(bundleKey).getString(key);           
        } catch (final MissingResourceException e) {
        	resultStr = '!' + key + '!';
        }
		return resultStr;
    }
}
