package it.sella.address.implementation.util;

import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;
import it.sella.address.AddressView;
import it.sella.address.AddressManagerFactory;
import it.sella.address.AddressException;
import java.rmi.RemoteException;

public class AddressManagerTestMethods {
    	
    private static AddressManagerTestMethods addressManagerTestMethodsObj = null;
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressManagerTestMethods.class);

    //public AddressView getAddress(Long soggettoId, String subsystemcl, Long pcId)
    public AddressView getAddress(final Object[] params) throws AddressException {
        AddressView addressView = null;
        Long soggettoId = null;
        String subSystemCausale = null;
        Long pcId = null;
        if(params != null)
        {
            for(int i=0;i<params.length;i++)
            {
                if(params[i].toString().trim().length() > 0)
                {
                	switch(i) {
                	case 0 : soggettoId = (i == 0) ? Long.valueOf(params[i].toString().trim()) : null;
                	case 1 : subSystemCausale = (i == 1) ? params[i].toString().trim() : null;
                	case 2 : pcId = (i == 2) ? Long.valueOf(params[i].toString().trim()) : null; 
                	}
                }
            }
            try {
                addressView = AddressManagerFactory.getInstance().getAddressManager().getAddress(soggettoId, subSystemCausale, pcId);
            } catch (final RemoteException e) {
                log4Debug.severeStackTrace(e);
                throw new AddressException(e.getMessage());
            }
        }
        return addressView;
    }

    public String getPostalAddress(final Object[] params) throws AddressException {
    	return getAddressFromParam(params, false);
    }

    public String getPostalAddressInXMLFormat(final Object[] params) throws AddressException {
    	return getAddressFromParam(params, true);
    }

    private String getAddressFromParam(final Object[] params, final boolean isXMLMethod) throws AddressException {
        String address = null;
        Long soggettoId = null;
        String subSystemCausale = null;
        Long pcId = null;
        String intstString = null;
        Long errorCode = null;
        String bypassCode = null;
        String skipDomolCheck = null;
        if(params != null) {
            for(int i=0;i<params.length;i++) {
                if( params[i].toString().trim().length() > 0) {
                	switch(i) {
                	case 0 : soggettoId = (i == 0) ? Long.valueOf(params[i].toString().trim()) : null;
                	case 1 : pcId = (i == 1) ? Long.valueOf(params[i].toString().trim()) : null;
                	case 2 : subSystemCausale = (i == 2) ? params[i].toString().trim() : null;
                	case 3 : intstString = (i == 3) ? params[i].toString().trim() : null;
                	case 4 : errorCode = (i == 4) ? Long.valueOf(params[i].toString().trim()) : null; 
                	case 5 : bypassCode = (i == 5) ? params[i].toString().trim() : null;
                	case 6 : skipDomolCheck = (i == 6) ? params[i].toString().trim() : null;
                	}
                }
            }
            log4Debug.info("To avoid PMD violation skipDomolCheck printed as log Info ================= ",skipDomolCheck);
            try {
                    if(params.length == 3) {
                    	if(isXMLMethod) {
							address = AddressManagerFactory.getInstance().getAddressManager().getPostalAddressInXMLFormat(soggettoId, pcId, subSystemCausale);
						} else {
							address = AddressManagerFactory.getInstance().getAddressManager().getPostalAddress(soggettoId, pcId, subSystemCausale);
						}
                    } else if(params.length == 4) {
                    	if(isXMLMethod){
                    		address = AddressManagerFactory.getInstance().getAddressManager().getPostalAddressInXMLFormat(soggettoId, pcId, subSystemCausale, bypassCode);
                    	}
                    
                    } else if(params.length == 7){
                    	if(isXMLMethod){
                    		address = "API rollbacked";
                    		/*address = AddressManagerFactory.getInstance().getAddressManager()
                    		.getPostalAddressInXMLFormat(soggettoId,pcId, subSystemCausale,intstString,
                    				errorCode, bypassCode,skipDomolCheck); */
                    	}else {
                    		address = "API rollbacked";
                    		/* address = AddressManagerFactory.getInstance().getAddressManager()
                    		.getPostalAddress(soggettoId,pcId, subSystemCausale,intstString,
                    				errorCode, bypassCode,skipDomolCheck); */
                    	}
                    }
                    else {
                    	if(isXMLMethod){
                    		address = AddressManagerFactory.getInstance().getAddressManager().getPostalAddressInXMLFormat(soggettoId, pcId, subSystemCausale, intstString, errorCode, bypassCode);
                    	} else {
							address = AddressManagerFactory.getInstance().getAddressManager().getPostalAddress(soggettoId, pcId, subSystemCausale, intstString, errorCode);
						}
                    }
            } catch (final RemoteException e) {
                log4Debug.severeStackTrace(e);
                throw new AddressException(e.getMessage());
            }
        }
        return address;
    }
    
    public static AddressManagerTestMethods getInstance() {
        if(addressManagerTestMethodsObj == null) {
			addressManagerTestMethodsObj = new AddressManagerTestMethods();
		}
        return addressManagerTestMethodsObj;
    }
}
