package it.sella.address.implementation.dbhelper;

import it.sella.address.AddressManagerBeanHelperException;
import it.sella.address.AddressView;
import it.sella.address.implementation.util.DBHelper;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreAnagrafeFactory;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class AddressListHelper extends AddressBaseHelper{
	

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressListHelper.class);

    public Collection listAddressSoggetto(final Long soggettoId) throws AddressManagerBeanHelperException, RemoteException {
        Connection connection = null;
        PreparedStatement addressStatement = null;
        ResultSet addressSet = null;
        final List addressVector = new ArrayList();
        try {
            connection = DBHelper.getConnection();
            final StringBuffer query = getSelectQueryForView();
            query.append(" AL_SOGGETTO_ID = ?");
            addressStatement = connection.prepareStatement(query.toString());
            addressStatement.setLong(1, soggettoId.longValue());
            addressSet = addressStatement.executeQuery();
            while(addressSet.next()) {
                final AddressView addressView = getAddressViewFromResultSet(soggettoId, addressSet);
                addressVector.add(addressView);
            }
        } catch(final SQLException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressManagerBeanHelperException(e.getMessage());
        } finally {
            DBHelper.cleanup(connection, addressStatement, addressSet);
        }
        return addressVector;
    }

    public Collection listAddress( final Long soggettoId, String subSystemCl ) throws AddressManagerBeanHelperException, RemoteException {
        Connection connection = null;
        PreparedStatement addressStatement = null;
        ResultSet addressSet = null;
        final List addressVector = new ArrayList(1);
        try {
        	if( soggettoId == null ) {
        		final String errorMsg = " SoggettoId Null";
				throw new AddressManagerBeanHelperException( errorMsg);
        	}
        	if( subSystemCl == null || subSystemCl.trim().length() < 1 ) {
        		final String errorMsg = " SubSystemCausale Null";
				throw new AddressManagerBeanHelperException( errorMsg);
        	}
        	final String tipoSoggetto = GestoreAnagrafeFactory.getInstance().getGestoreAnagrafe().getTipoSoggetto(soggettoId);
        	log4Debug.debug(" AddressListHelper : listAddress : tipoSoggetto :===>>>",tipoSoggetto);
        	if( "Succursale".equals(tipoSoggetto) || "Ufficio interno".equals(tipoSoggetto) ) {
        		subSystemCl = "DBP";
        	}
        	log4Debug.debug(" AddressListHelper : listAddress : subSystemCl :===>>>",subSystemCl);
            connection = DBHelper.getConnection();
            final StringBuffer query = getSelectQueryForView();
            query.append(" AL_SOGGETTO_ID = ? AND AL_TYPE_SUBSYSTEM = ").append(getClassificazioneId(subSystemCl, "SUBSYS"));
            addressStatement = connection.prepareStatement(query.toString());
            addressStatement.setLong(1, soggettoId.longValue());
            addressSet = addressStatement.executeQuery();
            while(addressSet.next()) {
                addressVector.add(getAddressViewFromResultSet(soggettoId, addressSet));
            }
        } catch(final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new AddressManagerBeanHelperException(e.getMessage());
        } catch(final GestoreAnagrafeException e) {
            log4Debug.warnStackTrace(e);
            throw new AddressManagerBeanHelperException(e.getMessage());
        } finally {
            DBHelper.cleanup(connection, addressStatement, addressSet);
        }
        return addressVector;
    }
}
