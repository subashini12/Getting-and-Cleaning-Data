package it.sella.address.implementation.addr;

import it.sella.address.AddressException;

import java.util.Collection;

import javax.ejb.FinderException;

public interface IAddressBeanManager {

	/**
	 * Method to create Address
	 * @param address
	 * @return
	 * @throws AddressException
	 */
	Address create(Address address) throws AddressException;

	/**
	 * Method to update Address
	 * @param address
	 * @return
	 */
	Address update(Address address);

	/**
	 * Method to find the data using Address primary key
	 * @param primaryKey
	 * @return
	 * @throws FinderException
	 */
	Address findByPrimaryKey(Long primaryKey)throws FinderException;

	/**
	 * Method to find the data using Address details citta, nazione and indirizzo
	 * @param citta
	 * @param nazione
	 * @param indirizzo
	 * @return
	 * @throws FinderException
	 */
	Address findByAddress(String citta,Long nazione, String indirizzo)throws FinderException;

	/**
	 * Method to find the data using Address details by passing Provincia,citta,nazione and indirizzo
	 * @param provincia
	 * @param citta
	 * @param nazione
	 * @param indirizzo
	 * @return
	 * @throws FinderException
	 */
	Address findByAddressProvincia(String provincia,String citta,Long nazione, String indirizzo)throws FinderException;

	/**
	 * Method to find the data using Address details by passing provincia, citta, cap id , nazione and indirizzo
	 * @param provincia
	 * @param citta
	 * @param cap
	 * @param nazione
	 * @param indirizzo
	 * @return
	 * @throws FinderException
	 */
	Address findByAddressCapId(String provincia, String citta, Long cap, Long nazione, String indirizzo)throws FinderException;

	/**
	 * Method to find the data using Address details by passing citta, Cap Value, nazione and indirizzo
	 * @param citta
	 * @param capValue
	 * @param nazione
	 * @param indirizzo
	 * @return
	 * @throws FinderException
	 */
	Address findByAddressCapValue(String citta, String capValue, Long nazione, String indirizzo)throws FinderException;

	/**
	 * Method to find the data using Address details by passing Provincia, citta , capValue, nazione and indirizzo
	 * @param provincia
	 * @param citta
	 * @param capValue
	 * @param nazione
	 * @param indirizzo
	 * @return
	 * @throws FinderException
	 */
	Address findByAddressCapProvinciaValue(String provincia, String citta, String capValue, Long nazione, String indirizzo)throws FinderException;

    /* The below finder methods were added to retrieve collection of remote objects
       in case the finder method finds duplicated record in DB for the param passed */

	/**
	 * Method to find all the data using address
	 * @param citta
	 * @param nazione
	 * @param indirizzo
	 * @return
	 * @throws FinderException
	 */
	Collection<Address> findAllByAddress(String citta,Long nazione, String indirizzo)throws FinderException;

	/**
	 * Method to find all data using Address details by passing Provincia,citta,nazione and indirizzo
	 * @param provincia
	 * @param citta
	 * @param nazione
	 * @param indirizzo
	 * @return
	 * @throws FinderException
	 */
	Collection<Address> findAllByAddressProvincia(String provincia,String citta,Long nazione, String indirizzo)throws FinderException;

	/**
	 * Method to find all the data using Address details by passing provincia, citta, cap id , nazione and indirizzo
	 * @param provincia
	 * @param citta
	 * @param cap
	 * @param nazione
	 * @param indirizzo
	 * @return
	 * @throws FinderException
	 */
	Collection<Address> findAllByAddressCapId(String provincia, String citta, Long cap, Long nazione, String indirizzo)throws FinderException;

	/**
	 * Method to find all the data using Address details by passing citta, Cap Value, nazione and indirizzo
	 * @param citta
	 * @param capValue
	 * @param nazione
	 * @param indirizzo
	 * @return
	 * @throws FinderException
	 */
	Collection<Address> findAllByAddressCapValue(String citta, String capValue, Long nazione, String indirizzo)throws FinderException;

	/**
	 * Method to find all the data using Address details by passing Provincia, citta , capValue, nazione and indirizzo
	 * @param provincia
	 * @param citta
	 * @param capValue
	 * @param nazione
	 * @param indirizzo
	 * @return
	 * @throws FinderException
	 */
	Collection<Address> findAllByAddressCapProvinciaValue(String provincia, String citta, String capValue, Long nazione, String indirizzo)throws FinderException;

    /**
     * Method to remove Address
     * @param address
     */
    void remove(Address address);

    /**
     * Method to find all the data using Address details by passing Provincia, citta , capValue, nazione , indirizzo and presso
     * @param provincia
     * @param citta
     * @param capValue
     * @param nazione
     * @param indirizzo
     * @param presso
     * @return
     * @throws FinderException
     */
    Collection<Address> findAllByAddressPresso(final String provincia,final String citta, final Long capValue, final Long nazione, final String indirizzo,final String presso) throws FinderException;
    /**
     * Method to find the data using Address details by passing Provincia, citta , capValue, nazione , indirizzo and presso
     * @param provincia
     * @param citta
     * @param capValue
     * @param nazione
     * @param indirizzo
     * @param presso
     * @return
     * @throws FinderException
     */
     Address findByAddressPresso(final String provincia,final String citta, final Long capValue, final Long nazione, final String indirizzo,final String presso) throws FinderException;
     
     Address findByAddressPressoAndEdificio(final String provincia,final String citta, final Long capValue, final Long nazione, final String indirizzo,final String presso,final String edificio) throws FinderException;
     
     Collection<Address>findAllByAddressPressoAndEdificio(final String provincia,final String citta, final Long capValue, final Long nazione, final String indirizzo,final String presso,final String edificio) throws FinderException;
     
     Address findByAddressEdificio(final String provincia,final String citta, final Long capValue, final Long nazione, final String indirizzo,final String edificio) throws FinderException;
     
     Collection<Address> findAllByAddressByEdificio(final String provincia,final String citta, final Long capValue, final Long nazione, final String indirizzo,final String edificio) throws FinderException;

}
