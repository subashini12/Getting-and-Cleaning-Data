/**
 * Created by IntelliJ IDEA.
 * User: ssil72
 * Date: Jun 10, 2004
 * Time: 12:34:37 PM
 */
package it.sella.address.implementation.util;

import it.sella.address.SubSystemHandlerException;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreAnagrafeFactory;
import it.sella.anagrafe.GestoreCittaException;
import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.anagrafe.GestoreCollegamentoException;
import it.sella.anagrafe.GestoreNazioneException;
import it.sella.anagrafe.GestoreProvinciaException;
import it.sella.anagrafe.GestoreSoggettoException;
import it.sella.anagrafe.ICapView;
import it.sella.anagrafe.ICittaView;
import it.sella.anagrafe.IGestoreAnagrafe;
import it.sella.anagrafe.INazioneView;
import it.sella.anagrafe.IProvinciaView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Map;

/**
 *  Class used to access Anagrafe subsystem
 */
public class AnagrafeHandler
{

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AnagrafeHandler.class);

    /**
     * To get the tiposoggetto of the input soggettoid
     * @param soggettoId
     * @return String
     * @throws RemoteException
     * @throws SubSystemHandlerException
     */
    public String getTiposoggetto(final Long soggettoId) throws RemoteException,SubSystemHandlerException {
        try {
            return getGestoreAnagrafe().getTipoSoggetto(soggettoId);
        } catch(final GestoreSoggettoException e) {
            log4Debug.warnStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * to get the linkedsoggettos for the input soggettoid
     * @param soggettoId
     * @param motiv
     * @return Collection (it.sella.anagrafe.CollegamentoView)
     * @throws RemoteException
     * @throws SubSystemHandlerException
     */

    public Collection getLinkedSoggetto(final Long soggettoId, final String motiv) throws RemoteException,SubSystemHandlerException {
        try {
            return getGestoreAnagrafe().getLinkedSoggetto(soggettoId,motiv);
        } catch(final GestoreCollegamentoException e) {
            log4Debug.warnStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * to get pricipale soggettoIds linked with the input linkedsoggettoids with the motivoCollegamento passed
     * @param soggettoId
     * @param motivoCollegamento
     * @return Collection Long
     * @throws RemoteException
     * @throws SubSystemHandlerException
     */
    public Collection getPrincipalSoggettos(final Long soggettoId,final String motivoCollegamento) throws RemoteException,SubSystemHandlerException {
        try {
            return getGestoreAnagrafe().getSoggettoPrincipale(soggettoId,motivoCollegamento);
        } catch(final GestoreCollegamentoException e) {
            log4Debug.warnStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * To get the parentTiposoggetto of the input soggettoid
     * @param soggettoId
     * @return String
     * @throws RemoteException
     * @throws SubSystemHandlerException
     */

    public String getParentTipoSoggetto(final Long soggettoId) throws RemoteException,SubSystemHandlerException {
        try {
            return getGestoreAnagrafe().getParentTipoSoggetto(soggettoId);
        } catch(final GestoreSoggettoException e) {
            log4Debug.warnStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * To get the value for the input codicisoggetto causale
     * @param soggettoId
     * @param causale
     * @return String
     * @throws RemoteException
     * @throws SubSystemHandlerException
     */
    public String getValoreCodiciSoggetto(final Long soggettoId, final String causale) throws RemoteException,SubSystemHandlerException {
        try {
            return getGestoreAnagrafe().getValoreCodiciSoggetto(soggettoId,causale);
        } catch(final GestoreCodiciSoggettoException e) {
            log4Debug.warnStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * To get the nazione collection based on the input details given
     * @param inputDetails
     * @return Collection INazioneView
     * @throws RemoteException
     * @throws SubSystemHandlerException
     */

    public Collection getNazione(final Map inputDetails) throws RemoteException,SubSystemHandlerException {
        try {
            return getGestoreAnagrafe().getNazione((Hashtable)inputDetails);
        } catch(final GestoreNazioneException e) {
            log4Debug.warnStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * Gets nazioneView for the input nazioneid passed
     * @param nazioneId
     * @return INazioneView
     * @throws SubSystemHandlerException
     * @throws RemoteException
     */

    public INazioneView getNazione(final Long nazioneId) throws SubSystemHandlerException,RemoteException {
        try {
            return getGestoreAnagrafe().getNazione(nazioneId);
        } catch(final GestoreNazioneException e) {
            log4Debug.warnStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * To get citta details for the input citta commune passed
     * @param cittaCommune
     * @return ICittaView
     * @throws RemoteException
     * @throws SubSystemHandlerException
     */

    public ICittaView getCitta(final String cittaCommune) throws RemoteException,SubSystemHandlerException {
        try {
            return getGestoreAnagrafe().getCitta(cittaCommune);
        } catch(final GestoreCittaException e) {
            log4Debug.warnStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * Gets CittaView for the input cittaid passed
     * @param cittaId
     * @return ICittaView
     * @throws SubSystemHandlerException
     * @throws RemoteException
     */

    public ICittaView getCitta(final Long cittaId) throws SubSystemHandlerException,RemoteException {
        try {
            return getGestoreAnagrafe().getCitta(cittaId);
        } catch(final GestoreCittaException e) {
            log4Debug.warnStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * Gets the CittaView for the input cittacommune and provinciasigla passed.
     * @param cittaCommune
     * @param provinciaSigla
     * @return ICittaView
     * @throws RemoteException
     * @throws SubSystemHandlerException
     */

    public ICittaView getCitta(final String cittaCommune,final String provinciaSigla) throws RemoteException,SubSystemHandlerException {
        try {
            return getGestoreAnagrafe().getCitta(cittaCommune,provinciaSigla);
        } catch(final GestoreCittaException e) {
            log4Debug.warnStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * checks whether the input cittaCommune passed is valid
     * @param cittaCommune
     * @return boolean
     * @throws RemoteException
     * @throws SubSystemHandlerException
     */

    public boolean isValidCittaCommune(final String cittaCommune) throws RemoteException,SubSystemHandlerException {
        try {
            return getGestoreAnagrafe().isValidCitta(cittaCommune);
        } catch(final GestoreCittaException e) {
            log4Debug.warnStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * To check whether the input cittaCommune is a valid one based on the provincia sigla passed
     * @param cittaCommune
     * @param provinciaSigla
     * @return boolean
     * @throws RemoteException
     * @throws SubSystemHandlerException
     */

    public boolean isValidCittaForProvincia(final String cittaCommune, final String provinciaSigla) throws RemoteException,SubSystemHandlerException {
        try {
            return getGestoreAnagrafe().isValidCitta(cittaCommune,provinciaSigla);
        } catch(final GestoreCittaException e) {
            log4Debug.warnStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * To check whether the input capCode is a valid one based on the provincia sigla passed
     * @param capValue
     * @param provinciaSigla
     * @return boolean
     * @throws RemoteException
     * @throws SubSystemHandlerException
     */

    public boolean isValidCapForProvincia(final String capValue, final String provinciaSigla) throws RemoteException,SubSystemHandlerException {
        try {
            return getGestoreAnagrafe().isValidCAP(capValue,provinciaSigla);
        } catch(final GestoreAnagrafeException e) {
            log4Debug.warnStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * to get the ProvinciaDetails for the input provinciaSigla
     * @param provinciaSigla
     * @return IProvinciaView
     * @throws RemoteException
     * @throws SubSystemHandlerException
     */

    public IProvinciaView getProvinciaViewForSigla(final String provinciaSigla) throws RemoteException,SubSystemHandlerException {
        try {
            return getGestoreAnagrafe().getProvincia(provinciaSigla);
        } catch(final GestoreProvinciaException e) {
            log4Debug.warnStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * Gets the provinciaView for the input provinciaId passed
     * @param provinciaId
     * @return IProvinciaView
     * @throws SubSystemHandlerException
     * @throws RemoteException
     */

    public IProvinciaView getProvincia(final Long provinciaId) throws SubSystemHandlerException,RemoteException {
        try {
            return getGestoreAnagrafe().getProvincia(provinciaId);
        } catch(final GestoreProvinciaException e) {
            log4Debug.warnStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * To get the Cap details based on input CapCode and CittaCommune
     * @param capCode
     * @param cittaCommune
     * @return ICapView
     * @throws RemoteException
     * @throws SubSystemHandlerException
     */

    public ICapView getCapviewForCapcodeAndCittacommune(final String capCode,final String cittaCommune) throws RemoteException,SubSystemHandlerException {
        try {
            return getGestoreAnagrafe().getCap(capCode,cittaCommune);
        } catch(final GestoreAnagrafeException e) {
            log4Debug.warnStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * Gets capview for the input capid passed.
     * @param capId
     * @return ICapView
     * @throws RemoteException
     * @throws SubSystemHandlerException
     */

    public ICapView getCap(final Long capId) throws RemoteException,SubSystemHandlerException {
        try {
            return getGestoreAnagrafe().getCap(capId);
        } catch(final GestoreAnagrafeException e) {
            log4Debug.warnStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * checks whether the input provinciaSigla is valid
     * @param provinciaSigla
     * @return boolean
     * @throws SubSystemHandlerException
     * @throws RemoteException
     */

    public boolean isValidProvinciaSigla(final String provinciaSigla) throws SubSystemHandlerException,RemoteException {
        try {
            return getGestoreAnagrafe().isValidProvince(provinciaSigla);
        } catch(final GestoreProvinciaException e) {
            log4Debug.warnStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }

    /**
     * checks whether the provinciaSigla is valid based on CittaCommune
     * @param provinciaSigla
     * @param cittaCommune
     * @return boolean
     * @throws RemoteException
     * @throws SubSystemHandlerException
     */

    public boolean isValidProvinciaForSiglaAndCittaCommune(final String provinciaSigla,final String cittaCommune) throws RemoteException,SubSystemHandlerException {
        try {
            return getGestoreAnagrafe().isValidProvince(provinciaSigla,cittaCommune);
        } catch(final GestoreProvinciaException e) {
            log4Debug.warnStackTrace(e);
            throw new SubSystemHandlerException(e.getMessage());
        }
    }
    /**
     * To Get The Collection Of Bank Address Name
     * 
     * 
     */
    
    public Collection<String> getListOfBankAddressNames() throws RemoteException,SubSystemHandlerException {
    	try {
    		return getGestoreAnagrafe().getListOfBankAddressNames();
    	} catch(final GestoreAnagrafeException e) {
    		log4Debug.warnStackTrace(e);
    		throw new SubSystemHandlerException(e.getMessage());
    	} 
    }

    private IGestoreAnagrafe getGestoreAnagrafe() {
        return GestoreAnagrafeFactory.getInstance().getGestoreAnagrafe();
    }

}
