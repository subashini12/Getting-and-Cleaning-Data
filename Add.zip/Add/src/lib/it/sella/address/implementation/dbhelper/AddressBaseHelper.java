package it.sella.address.implementation.dbhelper;

import it.sella.address.AddressManagerBeanHelperException;
import it.sella.address.AddressView;
import it.sella.address.HelperException;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.implementation.addr.Address;
import it.sella.address.implementation.addresslink.AddressLink;
import it.sella.address.implementation.util.AcfwHandler;
import it.sella.address.implementation.util.ClassificazioneHandler;
import it.sella.address.implementation.util.DBHelper;
import it.sella.address.implementation.util.Helper;
import it.sella.anagrafe.GestoreAnagrafeFactory;
import it.sella.anagrafe.GestoreSoggettoException;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

public class AddressBaseHelper {


    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressBaseHelper.class);

    /* This method is used to return a single remote interface when
    the finder method encounters duplicate records matching the
    input param */
    protected Address getAddressRemoteFromCollection(final Collection addressCollection) {
	    final Iterator addressIterator = addressCollection.iterator();
	    return (Address) addressIterator.next();
    }

    public boolean isCompatibleIndirizzo(final String subSystemCl, final String tipoIndirizzocl) throws AddressManagerBeanHelperException, RemoteException {
        Connection connection = null;
        PreparedStatement compatibleStatement = null;
        ResultSet compatibleSet = null;
        try {
            connection = DBHelper.getConnection();
            compatibleStatement = connection.prepareStatement("SELECT CO_COMPATIBLE_ID FROM ADD_MA_COMPATIBLE_ADD_SUBSYS WHERE CO_TYPE_SUBSYSTEM = ? AND CO_TYPE_ADDRESS = ? ");
            compatibleStatement.setLong(1, ClassificazioneHandler.getClassificazioneView(subSystemCl, "SUBSYS").getId().longValue());
            compatibleStatement.setLong(2, ClassificazioneHandler.getClassificazioneView(tipoIndirizzocl, "IND").getId().longValue());
            compatibleSet = compatibleStatement.executeQuery();
            return compatibleSet.next();
        } catch(final SQLException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressManagerBeanHelperException(e.getMessage());
        } catch(final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            final String errorMsg = "Enter a valid causale for Sub System / Tipo Indirizzo !!!";
			throw new AddressManagerBeanHelperException(errorMsg);
        } finally {
            DBHelper.cleanup(connection, compatibleStatement, compatibleSet);
        }
    }

    protected AddressView getAddressViewFromResultSet(final Long soggettoId, final ResultSet addressSet) throws RemoteException, AddressManagerBeanHelperException {
        ClassificazioneView addrClView = null;
        final AddressView addressView = new AddressView();
        try {
            addressView.setSoggettoId(soggettoId);
            new AddressViewBuilder().setCapInAddressView(addressSet,addressView);
            addrClView = ClassificazioneHandler.getClassificazioneView(Long.valueOf(addressSet.getLong("AL_TYPE_SUBSYSTEM")));
            addressView.setCausaleSubsystem(addrClView.getCausale());
            addressView.setDescrizioneSubsystem(addrClView.getDescrizione());
            addrClView = ClassificazioneHandler.getClassificazioneView(Long.valueOf(addressSet.getLong("AL_TYPE_ADDRESS")));
            addressView.setCausaleTipoIndirizzo(addrClView.getCausale());
            addressView.setDescrizioneTipoIndirizzo(addrClView.getDescrizione());
            addressView.setTipoIndirrizo(addrClView.getId());
            new AddressViewBuilder().setCittaInAddressView(addressSet,addressView);
            addressView.setIndirizzo(addressSet.getString("AD_INDIRIZZO"));
            if(addressSet.getString("AL_LINKED_ID") != null) {
				addressView.setProductContoId(Long.valueOf(addressSet.getLong("AL_LINKED_ID")));
			}
            new AddressViewBuilder().setNazioneInAddressView(addressSet,addressView);
            new AddressViewBuilder().setProvinciaInAddressView(addressSet,addressView);
            addressView.setInternal(getDBNumberValue(addressSet.getLong("AE_INTERNAL")));
            addressView.setFrequency(getDBNumberValue(addressSet.getLong("AE_FREQUENCY")));
            addressView.setReserved(getDBNumberValue(addressSet.getLong("AE_RESERVED")));
            addressView.setNormStatus(addressSet.getString("AD_NORM_STATUS"));
            //Added for EGON migration
            addressView.setPresso(addressSet.getString("AD_PRESSO"));
            addressView.setEdificio(addressSet.getString("AD_EDIFICIO"));
        } catch (final SQLException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressManagerBeanHelperException(e.getMessage());
        } catch(final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            final String errorMsg = "Enter a valid causale for Sub System / Address Type !!!";
			throw new AddressManagerBeanHelperException(errorMsg);
        }
        return addressView;
    }

    private Long getDBNumberValue(final long value) {
    	Long dbNumberVal = null;
    	if(value != 0) {
    		dbNumberVal = Long.valueOf(value);
		}
    	return dbNumberVal;
    }

    protected StringBuffer getSelectQueryForView() {
        final StringBuffer query = new StringBuffer();
        query.append("SELECT AL_SOGGETTO_ID, AL_LINKED_ID, AL_TYPE_SUBSYSTEM, AL_TYPE_ADDRESS, AD_ADDRESS_ID, AD_INDIRIZZO,AD_PROVINCIA, PR_ID, PR_SIGLA, PR_NOME, PR_CODICE_AREA, PR_CODICE_CAB, PR_CODICE_PUMA2, PR_STORICO,");
        query.append(" AD_CITTA, CI_ID, CI_COMMUNE, CI_PROVINCIA, CI_REGION, CI_CAPOLUOGO, CI_CAB, CI_CINCAB, CI_CAB_STORICO, CI_CNCF, CI_CAP, CI_STORICO, CI_ALTRADENOMINAZIONE,AD_CAP_VALUE, AD_NORM_STATUS, CAP_ID, CA_CAP, CA_LOCALITA, CA_NOTE, CA_PROVINCIA,");
        query.append(" NAZIONE_ID, NA_NOME, NA_NAZIONALITA, NA_CODICE_UIC, NA_CODICE_ISO, NA_CODICE_DIVISA, NA_CODICE_PROVINCIA, NA_SINGLA_INTERNAZIONALE, NA_LINGUA_PARLATA, NA_ZCR, NA_ZONA_BILANCI_GRANDI_RISCHI, NA_VALUTARIO, NA_AREA_GEOGRAFICA, NA_ADERENTE_TARGET, NA_MEMBRO_UE, NA_MEMBRO_UME, NA_APPARTENENTE_BLACK_LIST, NA_CNCF, NA_ALTRADENOMINAZIONE, NA_CONTINENTE, NA_STORICO, NA_NAZIONE, NA_NAZIONE_APPARTENENZA, NA_HA_EMBARGO, NA_DOC_AGGIUNTIVI, AE_RESERVED, AE_FREQUENCY, AE_INTERNAL,AD_PRESSO , AD_EDIFICIO FROM ADD_VW_ADDRESSVIEW WHERE");
        return query;
    }

    protected AddressLink getAddressLinkRemoteFromCollection(final Collection addressLinkCollection) {
		final Iterator addressLinkIterator = addressLinkCollection.iterator();
		return (AddressLink) addressLinkIterator.next();
    }

    Object getHomeObject(final String homeName,final String className) throws AddressManagerBeanHelperException {
        try {
			return Helper.getHomeObject(homeName, className);
		} catch (final HelperException e) {
            log4Debug.warnStackTrace(e);
            throw new AddressManagerBeanHelperException(e.getMessage());
		}
    }

    protected Long getClassificazioneId(final String causale,final String parentCausale) throws RemoteException,AddressManagerBeanHelperException {
    	try {
			return ClassificazioneHandler.getClassificazioneView(causale,parentCausale).getId();
		} catch (final SubSystemHandlerException e) {
            log4Debug.warnStackTrace(e);
            final String errorMSg = "Invalid child causale:"+causale+" / parent causale:"+parentCausale;
			throw new AddressManagerBeanHelperException(errorMSg);
		}
    }

    protected String getClassificazioneCausale(final Long clId) throws RemoteException,AddressManagerBeanHelperException {
    	try {
			return ClassificazioneHandler.getClassificazioneView(clId).getCausale();
		} catch (final SubSystemHandlerException e) {
            log4Debug.warnStackTrace(e);
            final String errorMsg = "Invalid clId:"+clId+" for classificazione !!!";
			throw new AddressManagerBeanHelperException(errorMsg);
		}
    }

    protected Map getContoCharacteristics( final Long contoId ) {
		return AcfwHandler.getContoCharacteristics(contoId,"NCH");
    }

    /**
     * This method returns the IRE, IDO address of Nazione as collection for the given Subject.
     * @param soggettoId
     * @return
     * @throws AddressManagerBeanHelperException
     * Collection<Long>
     */
    protected Collection<Long> getIREAndIDOAddressNazioneForSoggetto(final Long soggettoId) throws AddressManagerBeanHelperException{
    	 Connection connection = null;
         PreparedStatement preparedStatement = null;
         ResultSet resultSet = null;
         final Collection<Long> nazioneCollection = new ArrayList<Long>();
         final StringBuffer query = new StringBuffer();
         query.append("SELECT DISTINCT(AD.AD_NAZIONE) AD_NAZIONE FROM ADD_TR_ADDRESS AD, ADD_TR_ADDRESS_LINK AL WHERE AL.AL_SOGGETTO_ID = ? AND AL.AL_ADDRESS_ID = AD.AD_ADDRESS_ID AND AL.AL_TYPE_SUBSYSTEM = ? AND AL.AL_TYPE_ADDRESS IN (SELECT CL_ID FROM CLASSIFICAZIONE WHERE CL_CAUSALE IN ('IRE', 'IDO'))");
         try {
             connection = DBHelper.getConnection();
             preparedStatement = connection.prepareStatement(query.toString());
             preparedStatement.setLong(1, soggettoId);
             preparedStatement.setLong(2, ClassificazioneHandler.getClassificazioneView("ANAG", "SUBSYS").getId().longValue());
             resultSet = preparedStatement.executeQuery();
             while(resultSet.next()) {
            	 if (resultSet.getString("AD_NAZIONE") != null) {
            		 nazioneCollection.add(Long.valueOf(resultSet.getLong("AD_NAZIONE")));
            	 }
             }
         } catch(final SQLException e) {
             log4Debug.severeStackTrace(e);
             throw new AddressManagerBeanHelperException(e.getMessage());
         } catch (RemoteException e) {
        	 log4Debug.severeStackTrace(e);
        	 throw new AddressManagerBeanHelperException(e.getMessage());
		} catch (SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressManagerBeanHelperException(e.getMessage());
		} finally {
             DBHelper.cleanup(connection, preparedStatement, resultSet);
         }
		return nazioneCollection;
    }

    /**
     * This Method checks if the subject is Semplice and the Product Address (of Nazione) is "STATI UNITI" then
     * alteast one of residence or domicile address (of Nazione) should be STATI UNITI. Else error will be thrown.
     * @param nazioneIPO
     * @param soggettoId
     * @throws AddressManagerBeanHelperException
     * void
     */
    protected void validateNazioneWithIREIDONazione(final AddressView addressView) throws AddressManagerBeanHelperException{
    	Long nazioneIdIPO = null;
    	String nazioneNomeIPO = addressView.getNazione();
    	if(addressView.getNazioneView() != null){
    		nazioneIdIPO = addressView.getNazioneView().getNazioneId();
    		nazioneNomeIPO = addressView.getNazioneView().getNome();
    	}
    	final Long soggettoId = addressView.getSoggettoId();
    	log4Debug.debug("validateNazioneWithIREIDONazione ============= nazioneId :::  ",nazioneIdIPO," ===   soggettoId  :::  ",soggettoId);
    	if(!"ANAG".equals(addressView.getCausaleSubsystem()) && "IPO".equals(addressView.getCausaleTipoIndirizzo()) && nazioneIdIPO != null && soggettoId != null) {
	    	try {
    			final String tipoSoggetto = GestoreAnagrafeFactory.getInstance().getGestoreAnagrafe().getTipoSoggetto(soggettoId);
    			log4Debug.debug("tipoSoggetto  ==================     ",tipoSoggetto, "=========  nazioneNomeIPO  =================   ",nazioneNomeIPO);
    			if("Semplice".equals(tipoSoggetto) && "STATI UNITI".equalsIgnoreCase(nazioneNomeIPO)){
    				final Collection<Long> nazioneCollection = getIREAndIDOAddressNazioneForSoggetto(soggettoId);
    				log4Debug.debug("nazioneCollection    ==================       ",nazioneCollection);
    				if(nazioneCollection.isEmpty() || !nazioneCollection.contains(nazioneIdIPO)){
    					throw new AddressManagerBeanHelperException(Helper.getMessage("ANAG-1708"));
    				}
    			}
			} catch (GestoreSoggettoException e) {
				log4Debug.warnStackTrace(e);
				throw new AddressManagerBeanHelperException(e.getMessage());
			} catch (RemoteException e) {
				log4Debug.warnStackTrace(e);
				throw new AddressManagerBeanHelperException(e.getMessage());
			}
    	}
    }
}
