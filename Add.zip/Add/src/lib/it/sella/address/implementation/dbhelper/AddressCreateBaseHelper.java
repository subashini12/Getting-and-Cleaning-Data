package it.sella.address.implementation.dbhelper;

import it.sella.address.AddressConstants;
import it.sella.address.AddressException;
import it.sella.address.AddressManagerBeanHelperException;
import it.sella.address.AddressView;
import it.sella.address.egon.common.EgonUtil;
import it.sella.address.implementation.addr.Address;
import it.sella.address.implementation.addr.IAddressBeanManager;
import it.sella.address.implementation.addresslink.IAddressLinkBeanManager;
import it.sella.address.implementation.factory.ReflectionUtil;
import it.sella.address.implementation.util.StringHandler;
import it.sella.address.sm.addressmgt.AddressErrorConstants;
import it.sella.anagrafe.INazioneView;
import it.sella.anagrafe.IProvinciaView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;

import javax.ejb.FinderException;

public class AddressCreateBaseHelper extends AddressBaseHelper {


	private static final String FINDEREXCEPTION_MSGCODE = "EJB:013073";
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressCreateBaseHelper.class);

	public Long createAddr( final AddressView addressView, final Long opId ) throws AddressManagerBeanHelperException, RemoteException {
		String cittaValue = null;
		Long capId = null;
		String provinciaValue = null;
		Address address = null;
		final String indirizzo = addressView.getIndirizzo().replace(',',' ').trim().toUpperCase();
		final String presso = addressView.getPresso();
		System.out.println("Presso=========="+presso);
		final String edificio = addressView.getEdificio();
		System.out.println("Edifico=========="+edificio);
		try {
			final it.sella.address.implementation.addr.AddressView addrView = new it.sella.address.implementation.addr.AddressView();
			//            final AddressHome addressHome = (AddressHome) Helper.getHomeObject("ADDRESSHOMENAME", "it.sella.address.implementation.addr.AddressHome");
			final IAddressBeanManager manager =  (IAddressBeanManager) ReflectionUtil.createServiceImplInstance(AddressConstants.BUNDLE_KEY,AddressConstants.DAOIMPL_KEY_FOR_ADDRESS);
			cittaValue = (addressView.getCittaView() != null && addressView.getCittaView().getCittaId() != null) ? addressView.getCittaView().getCittaId().toString() : addressView.getCitta();
			if ( addressView.getCapView() != null && addressView.getCapView().getCapId() != null ) {
				capId = addressView.getCapView().getCapId();
				addrView.setCapId(capId);
			} else {
				addrView.setCapValue(addressView.getCap());
			}
			provinciaValue = addressView.getProvinciaView() != null ? addressView.getProvinciaView().getProvinciaId().toString() : addressView.getProvincia();

			try {
				if((presso !=null && !"".equals(presso)) && (edificio !=null && !"".equals(edificio)) ){
					System.out.println("=================Reached presso and edificio not null case================");
					try {
						address = manager.findByAddressPressoAndEdificio(provinciaValue, cittaValue, capId, addressView.getNazioneView().getNazioneId(), indirizzo,presso,edificio);
						System.out.println("==========Inside presso and edificio I=============="+address !=null ? address.getId():"EMPTY");
					} catch (final FinderException e) {
						if ( e.getMessage().indexOf(FINDEREXCEPTION_MSGCODE) != -1 ) {
							address = getAddressRemoteFromCollection(manager.findAllByAddressPressoAndEdificio(provinciaValue, cittaValue, capId, addressView.getNazioneView().getNazioneId(), indirizzo,presso,edificio));
							System.out.println("==========Inside presso and edificio II=============="+address !=null ? address.getId():"EMPTY");
						} else {
							System.out.println("===========Inside presso and edificio Finder Exception I==============");
							throw new FinderException();
						}
					}
				}else if ((presso !=null && !"".equals(presso)) && (edificio ==null || "".equals(edificio)) ) {
					System.out.println("=================Reached presso not null case================");
					try {
						address = manager.findByAddressPresso(provinciaValue, cittaValue, capId, addressView.getNazioneView().getNazioneId(), indirizzo, presso);
						System.out.println("==========Inside presso=============="+address !=null ? address.getId():"EMPTY");
					} catch (final FinderException e) {
						if ( e.getMessage().indexOf(FINDEREXCEPTION_MSGCODE) != -1 ) {
							address = getAddressRemoteFromCollection(manager.findAllByAddressPresso(provinciaValue, cittaValue, capId, addressView.getNazioneView().getNazioneId(), indirizzo, presso));
							System.out.println("==========Inside presso=============="+address !=null ? address.getId():"EMPTY");
						} else {
							System.out.println("===========Reached Finder presso Exception V==============");
							throw new FinderException();
						}
					}
				}  else if ((presso ==null || "".equals(presso)) && (edificio !=null && !"".equals(edificio))  ) {
					System.out.println("=================Reached edificio not null case================");
					try {
						address = manager.findByAddressEdificio(provinciaValue, cittaValue, capId, addressView.getNazioneView().getNazioneId(), indirizzo, edificio);
						System.out.println("==========Inside edifcio XI=============="+address !=null ? address.getId():"EMPTY");
					} catch (final FinderException e) {
						if ( e.getMessage().indexOf(FINDEREXCEPTION_MSGCODE) != -1 ) {
							address = getAddressRemoteFromCollection(manager.findAllByAddressByEdificio(provinciaValue, cittaValue, capId, addressView.getNazioneView().getNazioneId(), indirizzo, edificio));
							System.out.println("==========Inside edificio XII=============="+address !=null ? address.getId():"EMPTY");
						} else {
							System.out.println("===========Reached Finder edifcio Exception VI==============");
							throw new FinderException();
						}

					}
				}else if ( capId != null ) {
					System.out.println("==========Inside Cap=============="+capId);
					try {
						address = manager.findByAddressCapId(provinciaValue, cittaValue, capId, addressView.getNazioneView().getNazioneId(), indirizzo);
						System.out.println("==========Inside Cap I=============="+address !=null ? address.getId():"EMPTY");
					} catch (final FinderException e) {
						if ( e.getMessage().indexOf(FINDEREXCEPTION_MSGCODE) != -1 ) {
							address = getAddressRemoteFromCollection(manager.findAllByAddressCapId(provinciaValue, cittaValue, capId, addressView.getNazioneView().getNazioneId(), indirizzo));
							System.out.println("==========Inside Cap II=============="+address !=null ? address.getId():"EMPTY");
						} else {
							System.out.println("===========Reached Finder Exception I==============");
							throw new FinderException();
						}
					}
				} else if ( addressView.getCap() != null && addressView.getCap().trim().length() > 0 ) {
					System.out.println("==========Inside capId=============="+addressView.getCap());
					if ( provinciaValue != null && provinciaValue.length() >= 0 ) {
						try {
							address = manager.findByAddressCapProvinciaValue(provinciaValue,cittaValue,addressView.getCap(), addressView.getNazioneView().getNazioneId(), indirizzo);
							System.out.println("==========Inside Cap III=============="+address !=null ? address.getId():"EMPTY");
						} catch (final FinderException e) {
							if ( e.getMessage().indexOf(FINDEREXCEPTION_MSGCODE) != -1 ) {
								address = getAddressRemoteFromCollection(manager.findAllByAddressCapProvinciaValue(provinciaValue,cittaValue,addressView.getCap(), addressView.getNazioneView().getNazioneId(), indirizzo));
								System.out.println("==========Inside Cap IV=============="+address !=null ? address.getId():"EMPTY");
							} else {
								System.out.println("===========Reached Finder Exception II==============");
								throw new FinderException();
							}
						}
					} else {
						try {
							address = manager.findByAddressCapValue(cittaValue,addressView.getCap(), addressView.getNazioneView().getNazioneId(),indirizzo);
							System.out.println("==========Inside Cap V=============="+address !=null ? address.getId():"EMPTY");
						} catch (final FinderException e) {
							if ( e.getMessage().indexOf(FINDEREXCEPTION_MSGCODE) != -1 ) {
								address = getAddressRemoteFromCollection(manager.findAllByAddressCapValue(cittaValue,addressView.getCap(), addressView.getNazioneView().getNazioneId(), indirizzo));
								System.out.println("==========Inside Cap VI=============="+address !=null ? address.getId():"EMPTY");
							} else {
								System.out.println("===========Reached Finder Exception III==============");
								throw new FinderException();
							}
						}
					}
				} else if ( provinciaValue != null && provinciaValue.trim().length() > 0 ) {
					try {
						address = manager.findByAddressProvincia(provinciaValue, cittaValue, addressView.getNazioneView().getNazioneId(), indirizzo);
						System.out.println("==========Inside Cap VII=============="+address !=null ? address.getId():"EMPTY");
					} catch (final FinderException e) {
						if ( e.getMessage().indexOf(FINDEREXCEPTION_MSGCODE) != -1 ) {
							address = getAddressRemoteFromCollection(manager.findAllByAddressProvincia(provinciaValue, cittaValue, addressView.getNazioneView().getNazioneId(), indirizzo));
							System.out.println("==========Inside Cap VIII=============="+address !=null ? address.getId():"EMPTY");
						} else {
							System.out.println("===========Reached Finder Exception IV==============");
							throw new FinderException();
						}
					}
				} else {
					try {
						address = manager.findByAddress(cittaValue, addressView.getNazioneView().getNazioneId(), indirizzo);
						System.out.println("==========Inside Cap XIII=============="+address !=null ? address.getId():"EMPTY");
					} catch (final FinderException e) {
						if ( e.getMessage().indexOf(FINDEREXCEPTION_MSGCODE) != -1 ) {
							address = getAddressRemoteFromCollection(manager.findAllByAddress(cittaValue, addressView.getNazioneView().getNazioneId(), indirizzo));
							System.out.println("==========Inside Cap XIV=============="+address !=null ? address.getId():"EMPTY");
						} else {
							System.out.println("===========Reached Finder Exception VII==============");
							throw new FinderException();
						}
					}

				}

				if ( addressView.getProvinciaView() != null) {
					if (!new StringHandler().checkForEquality(address.getProvinciaName(),addressView.getProvinciaView().getNome())) {
						address.setProvinciaName(addressView.getProvinciaView().getNome());
						address.setProvinciaSigla(addressView.getProvinciaView().getSigla());
					}
				} else {
					if (!new StringHandler().checkForEquality(address.getProvinciaName(),provinciaValue)) {
						address.setProvinciaName(provinciaValue);
					}
				}

				if ( addressView.getCittaView() != null) {
					if (!new StringHandler().checkForEquality(address.getCittaName(),addressView.getCittaView().getCommune())) {
						address.setCittaName(addressView.getCittaView().getCommune());
					}
				} else {
					if ( !new StringHandler().checkForEquality(address.getCittaName(),cittaValue)) {
						address.setCittaName(cittaValue);
					}
				}

				if (!new StringHandler().checkForEquality(address.getEdificio(),edificio)) {
					address.setEdificio(edificio);
				}
				if (!new StringHandler().checkForEquality(address.getPresso(),presso)) {
					address.setPresso(presso);
				}

				if (addressView.getNazioneView() != null) {
					if (!new StringHandler().checkForEquality(address.getNazioneName(),addressView.getNazioneView().getNome())) {
						address.setNazioneName(addressView.getNazione());
					}
				} else {
					if (!new StringHandler().checkForEquality(address.getNazioneName(),addressView.getNazione())) {
						address.setNazioneName(addressView.getNazione());
					}
				}

				if ( !"OK".equals(address.getNormStatus()) &&
						!new StringHandler().checkForEquality(address.getNormStatus(),addressView.getNormStatus()) ) {
					address.setNormStatus(addressView.getNormStatus());
					address.setOpId(opId);
					manager.update(address);
				}
			} catch(final FinderException e) {
				System.out.println("==============Reched Finder Exception==============");
				addrView.setIndirizzo(indirizzo);
				addrView.setCitta(cittaValue);
				final INazioneView nazioneView = addressView.getNazioneView();
				addrView.setNazione(nazioneView.getNazioneId());
				addrView.setProvincia(provinciaValue);
				addrView.setOpId(opId);
				addrView.setNormStatus(addressView.getNormStatus());
				//Added For EGON Migration
				final String nazioneNome = nazioneView.getNome();
				addrView.setNazioneName(nazioneNome);//AD_NAZIONE_NOME
				final IProvinciaView provinciaView = addressView.getProvinciaView();
				if (!EgonUtil.isNull(addressView.getCittaView())) {
					addrView.setCittaName(addressView.getCittaView().getCommune());
				} else {
					addrView.setCittaName(cittaValue);
				}
				if (!EgonUtil.isNull(provinciaView)) {
					addrView.setProvinciaName(EgonUtil.getStringValue(addressView.getProvinciaView() != null  ? addressView.getProvinciaView().getNome() : provinciaValue));//AD_PROVINCA_NOME
					addrView.setProvinciaSigla(EgonUtil.getStringValue(provinciaView.getSigla()));//AD_PROVINCA_SIGLA
				}
				System.out.println("Presso in address=========="+presso);
				System.out.println("Edificio in address=========="+edificio);
				addrView.setPresso(presso);//AD_PRESSO
				addrView.setEdificio(edificio);//AD_EDIFICIO
				address = manager.create(addrView);
			}
			return address.getId();
		} catch(final AddressException e) {
			e.printStackTrace();
			log4Debug.severeStackTrace(e);
			throw new AddressManagerBeanHelperException(e.getMessage());
		}
	}

	protected void validateAddressTypeInProductID( final AddressView addressView ) throws AddressManagerBeanHelperException {
		if ( addressView != null &&
				"ANAG".equals(addressView.getCausaleSubsystem()) &&
				( "IRE".equals(addressView.getCausaleTipoIndirizzo()) ||
						"IDO".equals(addressView.getCausaleTipoIndirizzo()) ||
						"SLE".equals(addressView.getCausaleTipoIndirizzo()) ||
						"SAM".equals(addressView.getCausaleTipoIndirizzo())) &&
						addressView.getProductContoId() != null ) {
			throw new AddressManagerBeanHelperException(AddressErrorConstants.ERR22);
		}
	}

	protected void validateAddressDuplicate( final Long soggettoId, final String subSystemCausale,
			final String tipoAddressCausale, final Long subSystemId, final Long tipoIndirrizzoId ) throws RemoteException, AddressManagerBeanHelperException {
		if ( "ANAG".equals(subSystemCausale) &&
				( "IRE".equals(tipoAddressCausale) ||
						"IDO".equals(tipoAddressCausale) ||
						"SLE".equals(tipoAddressCausale) ||
						"SAM".equals(tipoAddressCausale))) {
			try {
				final Collection addressLinkColl = getAddressLinkHome().findAllBySoggettoSubsytemTipoIndirizzo(soggettoId, subSystemId, tipoIndirrizzoId);
				if ( addressLinkColl != null && !addressLinkColl.isEmpty() ) {
					throw new AddressManagerBeanHelperException(AddressErrorConstants.ERR05);
				}
			} catch (final FinderException e) {
				log4Debug.warnStackTrace(e);
				checkFinderExceptionForDuplicateRaiseError(e.getMessage());
			}
		}
	}

	protected void checkFinderExceptionForDuplicateRaiseError( final String errorMessage ) throws AddressManagerBeanHelperException {
		if ( errorMessage.indexOf(FINDEREXCEPTION_MSGCODE) != -1 ) {
			throw new AddressManagerBeanHelperException(AddressErrorConstants.ERR05);
		}
	}


	protected void checkFinderExceptionForDuplicate( final String errorMessage ) throws FinderException {
		if ( errorMessage.indexOf(FINDEREXCEPTION_MSGCODE) == -1 ) {
			throw new FinderException();
		}
	}

	protected IAddressLinkBeanManager getAddressLinkHome() throws AddressManagerBeanHelperException {
		try {
			return (IAddressLinkBeanManager) ReflectionUtil.createServiceImplInstance(AddressConstants.BUNDLE_KEY, AddressConstants.DAOIMPL_KEY_FOR_ADDRESSLINK);
		} catch (final AddressException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressManagerBeanHelperException(e.getMessage());
		}
	}
}
