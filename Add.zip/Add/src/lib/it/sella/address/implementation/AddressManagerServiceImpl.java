/*
 * Created by IntelliJ IDEA.
 * User: SUGUMAR
 * Date: Oct 28, 2002
 * Time: 12:11:06 PM
 */

package it.sella.address.implementation;

import it.sella.address.AddressException;
import it.sella.address.HelperException;
import it.sella.address.IAddressServiceManager;
import it.sella.address.implementation.util.Helper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.List;

import javax.ejb.CreateException;
import javax.ejb.Handle;

public class AddressManagerServiceImpl implements IAddressServiceManager
{
    
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressManagerServiceImpl.class);

    private transient AddressManager addressManager = null;
    private Handle addressManagerHandle = null;

    public void removeUnusedAddress() throws AddressException, RemoteException {
        getAddressManagerImpl().removeUnusedAddress();
    }

    public Integer getEsercentiPresenti(final Long soggettoId) throws AddressException, RemoteException {
        return getAddressManagerImpl().getEsercentiPresenti(soggettoId);
    }

    /*
       This method get the products available for the input soggettoid
    */
    public String getProductValues(final Long soggettoId) throws AddressException, RemoteException {
        return getAddressManagerImpl().getProductValues(soggettoId);
    }

    public List getAddressAlreadyUsed(final String indirizzio, final String cap, final String cittaCommune, final String provinciaSingla, final String nazione, final String tipoIndirrizoCausale, final Long bankSoggettId )  throws AddressException, RemoteException {
    	return getAddressManagerImpl().getAddressAlreadyUsed(indirizzio,cap,cittaCommune,provinciaSingla,nazione,tipoIndirrizoCausale,bankSoggettId);
    }
    
    private AddressManager getAddressManagerImpl() throws AddressException, RemoteException {
        try {
            if(addressManager == null && addressManagerHandle == null) {
                addressManager = getAddressManagerImplHome().create();
                addressManagerHandle = addressManager.getHandle();
            } else if (addressManager == null && addressManagerHandle != null) {
                addressManager = (AddressManager) addressManagerHandle.getEJBObject();
            }
        } catch(final CreateException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        }
        return addressManager;
    }

    private AddressManagerHome getAddressManagerImplHome() throws AddressException
    {
        try {
            return  (AddressManagerHome)Helper.getHomeObject("ADDMANAGERHOMENAME","it.sella.address.implementation.AddressManagerHome");
        } catch(final HelperException e) {
            log4Debug.severeStackTrace(e);
            throw new AddressException(e.getMessage());
        }
    }

}
