package it.sella.address.implementation.factory;

import it.sella.address.AddressException;
import it.sella.address.implementation.AddressAdminFactory;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;

import javax.naming.NamingException;
import javax.persistence.EntityManager;

public class AddressEntityManagerFactory {
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressEntityManagerFactory.class);
	private static AddressEntityManagerFactory addressEntityManagerFactoryObj = null;
	private EntityManager entityManager = null;

	public static AddressEntityManagerFactory getInstance(){
		if(addressEntityManagerFactoryObj == null) {
			addressEntityManagerFactoryObj = new AddressEntityManagerFactory();
		}
		return addressEntityManagerFactoryObj;
	}

	public EntityManager getEntityManager(){
		if(entityManager == null || !entityManager.isOpen()){
			try {
				entityManager = AddressAdminFactory.getInstance().getAddressAdmin().getPersistenceEntityManager();
			} catch (final NamingException namingException) {
	        	log4Debug.severeStackTrace(namingException);
	        } catch (final RemoteException e) {
	        	log4Debug.severeStackTrace(e);
			}catch (final AddressException e) {
	        	log4Debug.severeStackTrace(e);
			}

		}
		return entityManager;
	}

}
