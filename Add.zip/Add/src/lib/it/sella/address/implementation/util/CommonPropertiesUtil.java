package it.sella.address.implementation.util;

import it.sella.address.SubSystemHandlerException;
import it.sella.util.CommonProperties;
import it.sella.util.CommonPropertiesFactory;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

public class CommonPropertiesUtil {
	
	

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CommonPropertiesUtil.class);

    public String getPropertyValue(final String propertyKey) {
        String propertyValue = null;
        final CommonProperties commonProperties = CommonPropertiesFactory.getInstance().getCommonProperties("Address");
        final String value = commonProperties.getProperty(propertyKey);
        if(value != null && !"".equals(value)) {
			propertyValue = value;
		}

        return propertyValue;
    }

    public boolean isHostAllowedForLoginBank() {
    	boolean hostAllowedForLoginBank = false;
    	try {
    		if("OK".equals(getPropertyValue(SecurityHandler.getLoginBancaSoggettoId().toString()))) {
    			hostAllowedForLoginBank = true;
			}
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
		}
		return hostAllowedForLoginBank;
    }
}
