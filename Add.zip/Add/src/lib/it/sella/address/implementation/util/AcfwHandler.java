package it.sella.address.implementation.util;

import it.sella.acfw.GestoreContiFactory;
import it.sella.acfw.ICaratteristicheConto;
import it.sella.acfw.IGestoreConti;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Hashtable;
import java.util.Map;


public class AcfwHandler {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AcfwHandler.class);
	private static Map tipoContoDesc = new Hashtable();

	private static void initializeTipoContoDesc() {
		if(tipoContoDesc.isEmpty()){
			tipoContoDesc.put("01","C/C");
			tipoContoDesc.put("05","D/R");
			tipoContoDesc.put("02","C/T");
			tipoContoDesc.put("45","MUTUO");
		}
	}

    /**
     * To get characteristics details of a contoid
     * @param contoId
     * @return Hashtable
     * @throws RemoteException
     * @throws SubSystemHandlerException
     */
	
	// If Any ACFW address not having NCH value we need to skip Host Alignment Exception should not propagrate Page
    public static Map getContoCharacteristics( final Long contoId, final String tipocausaleNumeroConto ) {
    	final Map output = new Hashtable(1);
        try {
        	initializeTipoContoDesc();
        	final ICaratteristicheConto caratteristicheConto =  getGestoreConti().getCaratteristicheConto(contoId);
            if( caratteristicheConto != null ) {
                if( "45".equals(caratteristicheConto.getTipoConto()) ) {
                	output.put("CODICE_ESTERNO",caratteristicheConto.getCodiceEsterno("13CifreHost"));
                } else {
                	output.put("CODICE_ESTERNO",caratteristicheConto.getCodiceEsterno(tipocausaleNumeroConto));
                }
                if( caratteristicheConto.getDataChiusura() != null ) {
                	output.put("DATA_CHIUSURA",caratteristicheConto.getDataChiusura());
                }
                if( caratteristicheConto.getTipoConto() != null && 
                		tipoContoDesc.get(caratteristicheConto.getTipoConto()) != null ) {
                	output.put("TIPOCONTO_CAUSALE",tipoContoDesc.get(caratteristicheConto.getTipoConto()));
                }
                output.put("IS_NUMERATO",Boolean.valueOf(caratteristicheConto.isNumerato()));
                output.put("SUCCURSALE",caratteristicheConto.getSuccursale());
            }
        } catch( final Exception e ) {
    		log4Debug.severe(" ++++++++++++++++++ Exception Raised Trying to get NCH or 13CifreHost value in ACFW ");
    		log4Debug.severeStackTrace(e);
        }
        return output;
    }

    private static IGestoreConti getGestoreConti() {
        return GestoreContiFactory.getInstance().getGestoreConti();
    }
}
