package it.sella.address.implementation.dbhelper;

import it.sella.address.AddressConstants;
import it.sella.address.AddressException;
import it.sella.address.egon.common.AddressBeanUtil;
import it.sella.address.egon.common.EgonAddressBeanConstant;
import it.sella.address.egon.common.EgonUtil;
import it.sella.address.egon.delegator.EgonNormalisationDAODelegator;
import it.sella.address.egon.view.EgonAddressView;
import it.sella.address.egon.view.EgonErrorView;
import it.sella.address.implementation.AddressAmbiguityView;
import it.sella.address.implementation.NormalizedAddressStatus;
import it.sella.address.implementation.util.DBHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class AddressNormalizedHelper {


    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressNormalizedHelper.class);

	public static NormalizedAddressStatus normalizeIndirrizo(final String nazione,final String cittaCommune,final String indirrizzo,final String provincia,final String cap) throws AddressException {
		Connection normallizaCon = null;
		PreparedStatement normStatement = null;
		ResultSet normResultSet	= null;

		String normIndirrizo = null;
		final StringBuffer errorMessage = new StringBuffer();
		final StringBuffer normIndirrizoBuf = new StringBuffer();

		final NormalizedAddressStatus normAddressView = new NormalizedAddressStatus();
		String ambiProvincia = null;
		String ambiCommune = null;
		String indirizzioErorrMsg = null;

		String query = "SELECT PROV,COMUUF,VIAAB,CAP,ERRORENOME,ERRORELOCA,ERROREVIA,DERORELOCA,DEROREVIA,DERORENOME,ONLYDEN,ONLYVIA,ONLYNUM,ONLYCIV,ONLYESP,AMBIGUI FROM TABLE (JNORM_DBA.fn_normalizza(?,?,?,?,?,?,?,?,?))";
		//String query = "SELECT PROV,COMUUF,VIAAB,CAP,ERRORENOME,ERRORELOCA,ERROREVIA,DERORELOCA,DEROREVIA,DERORENOME,ONLYDEN,ONLYVIA,ONLYNUM,ONLYCIV,ONLYESP,AMBIGUI FROM TABLE (fn_normalizza(?,?,?,?,?,?,?,?,?))";
		try {
			normallizaCon = DBHelper.getConnection();
			normStatement = normallizaCon.prepareStatement(query);
			normStatement.setString(1,null);
			normStatement.setString(2,"BATTIA");
			normStatement.setString(3,cittaCommune);
			normStatement.setString(4,indirrizzo);
			normStatement.setString(5,provincia);
			normStatement.setString(6,cap);
			normStatement.setString(7,"ITALIA");
			normStatement.setString(8,"M");
			normStatement.setString(9,"JNORM_DBA");
			normResultSet = normStatement.executeQuery();
			if(normResultSet.next()) {
				final int erroreNome = normResultSet.getInt("ERRORENOME");
				final int erroreLoca = normResultSet.getInt("ERRORELOCA");
				final int erroreVia = normResultSet.getInt("ERROREVIA");
				final String onlyNum = normResultSet.getString("ONLYNUM");

				if(erroreNome == 0 && erroreLoca == 0 && erroreVia == 0) {
					normIndirrizo = normIndirrizoBuf.append(getValue(normResultSet.getString("ONLYDEN"))).
									 append(getValue(normResultSet.getString("ONLYVIA"))).
									 append(getValue(normResultSet.getString("ONLYCIV"))).toString().trim();
					if(normIndirrizo.trim().length() > 30 ){
						normIndirrizo = (normResultSet.getString("VIAAB") != null ? normResultSet.getString("VIAAB").trim() : "").trim();
					}
					normAddressView.setCap(normResultSet.getString("CAP"));
					normAddressView.setIndirrizi(normIndirrizo);
					normAddressView.setProvinca(provincia);
					normAddressView.setCittaCommune(cittaCommune);

				} else {
					errorMessage.append( normResultSet.getString("DERORELOCA") != null ?
										 normResultSet.getString("DERORELOCA").trim() : "").
					             append(" ").append( normResultSet.getString("DEROREVIA") != null ?
					            		 normResultSet.getString("DEROREVIA").trim() : "").
					             append(normResultSet.getString("DERORENOME") != null ?
							            		 normResultSet.getString("DERORENOME").trim() : "");
					if(erroreLoca == 108 || erroreVia == 208 ) {
						final Collection ambiguityList = new ArrayList();
						query = "SELECT PROVLOCA,LOCALOCA,DUGVIA,NOMEVIA FROM TABLE (?) WHERE (DUGVIA IS NOT NULL OR NOMEVIA IS NOT NULL)";
						final Object ambigui = normResultSet.getObject("AMBIGUI");
						DBHelper.closeStatement(normStatement);
						normStatement = normallizaCon.prepareStatement(query);
						normStatement.setObject(1,ambigui);
						DBHelper.closeResultSet(normResultSet);
						normResultSet =  normStatement.executeQuery();
						boolean isSetProvAndComm = true;
						while(normResultSet.next()) {
							final AddressAmbiguityView normAmbiguiView = new AddressAmbiguityView();
							if(isSetProvAndComm) {
								ambiProvincia = normResultSet.getString("PROVLOCA");
								ambiCommune = normResultSet.getString("LOCALOCA");
								isSetProvAndComm = false;
							}
							normAmbiguiView.setDugVia(normResultSet.getString("DUGVIA"));
							normAmbiguiView.setLocalita(ambiCommune);
							normAmbiguiView.setNomeVia(normResultSet.getString("NOMEVIA"));
							normAmbiguiView.setProvincia(ambiProvincia);
							normAmbiguiView.setOnlyNum(onlyNum);
							ambiguityList.add(normAmbiguiView);
						}
						normAddressView.setAmbigui(ambiguityList);
						normAddressView.setAmbiguityExists(true);
					}
					indirizzioErorrMsg = errorMessage.toString().trim();
					normAddressView.setErrorMessage("INDIRIZZO SCARTATO".equalsIgnoreCase(indirizzioErorrMsg) ?
							AddressConstants.INDIRIZZO_SCARTATO_MESSAGE : indirizzioErorrMsg);
					normAddressView.setNormalizationErrato(true);
				}
			}
		} catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
	    } finally {
			DBHelper.cleanup(normallizaCon,normStatement,normResultSet);
		}
		return normAddressView;
	}

	private static String getValue(final String input) {
		final StringBuffer output = new StringBuffer();
		if(input != null) {
			output.append(input.trim()).append(" ");
		}
		return output.toString();
	}

	public static NormalizedAddressStatus normalizeIndirrizo_New(final String nazione,final String cittaCommune,final String indirrizzo,final String provincia,final String cap,final String edifico, final String presso) throws AddressException {
		final EgonNormalisationDAODelegator daoDelegator = (EgonNormalisationDAODelegator) AddressBeanUtil.getInstance().getBean(EgonAddressBeanConstant.EGON_NORMALISATION_DAO_DELEGATOR.getBeanId());
		final EgonAddressView egonAddressView = daoDelegator.normalisation(nazione, cittaCommune, EgonUtil.isEmpty(presso) ? indirrizzo : EgonUtil.getStringValue(presso, " ", indirrizzo), provincia, cap, edifico, presso);
		final NormalizedAddressStatus normAddressView = new NormalizedAddressStatus();
		normAddressView.setCap(egonAddressView.getCap());
		normAddressView.setIndirrizi(egonAddressView.getIndirizzo());
		normAddressView.setPresso(egonAddressView.getPresso());
		normAddressView.setProvinca(egonAddressView.getProvincia());
		normAddressView.setCittaCommune(cittaCommune);
		normAddressView.setEdificio(EgonUtil.getStringValue(edifico));
		if (egonAddressView.getNormalisationFailure()) {
			normAddressView.setNormalizationErrato(true);
			normAddressView.setErrorMessage(AddressConstants.INDIRIZZO_SCARTATO_MESSAGE);
			normAddressView.setFailureMessage(setMessage(egonAddressView.getFailureMessage()));
		} else {
			normAddressView.setNormalizationErrato(false);
			normAddressView.setWarningMessage(setMessage(egonAddressView.getWarningMessage()));
		}
		return normAddressView;

	}

	private static List<String> setMessage(final List<EgonErrorView> message) {
		final List<String> errorList = new ArrayList<String>();
		if (!EgonUtil.isListEmpty(message)) {
			for (final EgonErrorView egonErrorView : message) {
				errorList.add(egonErrorView.getErrorDescription());
			}
		}
		return errorList;
	}
}
