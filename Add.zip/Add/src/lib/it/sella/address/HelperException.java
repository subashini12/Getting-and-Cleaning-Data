package it.sella.address;

/**
 * This exception class used to wrap the exception thrown in Helper class
 */

public class HelperException extends Exception {

    /**
     *  Default Constructor
     */
    public HelperException() {
    	// explicit default constructor
    }

    /**
     * One argument Constructor, which in turn calls superclass constructor
     * @param message java.lang.String
     */
    public HelperException(final String message) {
        super(message);
    }
}
