/*
 * Created by IntelliJ IDEA.
 * User: SUGUMAR
 * Date: Oct 28, 2002
 * Time: 12:08:26 PM
 */

package it.sella.address;

import it.sella.address.implementation.AddressManagerServiceImpl;

public class AddressManagerServiceFactory
{

    private static AddressManagerServiceFactory addressManagerServiceFactoryObj;
    private IAddressServiceManager iAddressServiceManager = null;

    protected AddressManagerServiceFactory()
    {
    	// explicit default constructor
    }

    public static AddressManagerServiceFactory getInstance()
    {
        if(addressManagerServiceFactoryObj == null) {
			addressManagerServiceFactoryObj = new AddressManagerServiceFactory();
		}
        return addressManagerServiceFactoryObj;
    }

    public IAddressServiceManager getAddressServiceManager()
    {
        if( iAddressServiceManager == null) {
			iAddressServiceManager = new AddressManagerServiceImpl();
		}
        return iAddressServiceManager;
    }


}
