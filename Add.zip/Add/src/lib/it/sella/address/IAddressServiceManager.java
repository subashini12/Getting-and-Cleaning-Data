/*
 * Created by IntelliJ IDEA.
 * User: SUGUMAR
 * Date: Oct 28, 2002
 * Time: 11:52:33 AM
 */

package it.sella.address;

import java.io.Serializable;
import java.rmi.RemoteException;

public interface IAddressServiceManager extends Serializable
{

	/*
        This method invokes a procedure which will remove all the unused address records
        from add_tr_address and stores that datas in a file.
    */
    public void removeUnusedAddress() throws AddressException, RemoteException;

    /* This method invokes the function esercenti_x_idsoggetto() to get the
       trades available for the input soggettoid
    */

    public Integer getEsercentiPresenti(Long soggettoId) throws AddressException, RemoteException;

    /*
       This method get the products available for the input soggettoid
    */
    public String getProductValues(Long soggettoId) throws AddressException, RemoteException;
}
