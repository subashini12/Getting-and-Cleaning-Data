package it.sella.address;

public class AddressManagerMapperException extends Exception {

    /**
     *  Default Constructor
     */
    public AddressManagerMapperException() {
    	// explicit default constructor
    }

    /**
     * One argument Constructor, which in turn calls superclass constructor
     * @param message java.lang.String
     */
    public AddressManagerMapperException(final String message) {
        super(message);
    }

}
