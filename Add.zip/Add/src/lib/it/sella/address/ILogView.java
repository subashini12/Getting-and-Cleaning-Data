package it.sella.address;

import java.io.Serializable;
import java.sql.Timestamp;

public interface ILogView extends Serializable {

    public String getCodiciDipendente();

    public Timestamp getDateOfOperation();
    
    public Long getSoggettoId();
    
    public String getModeOfOperation();
    
    public String getShortParameterList();
    
    public Long getAccountId();

}
