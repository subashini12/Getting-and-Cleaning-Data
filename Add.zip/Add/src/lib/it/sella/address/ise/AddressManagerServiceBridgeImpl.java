package it.sella.address.ise;

import it.sella.address.AddressException;
import it.sella.address.AddressManagerServiceFactory;
import it.sella.integrazione_sistemi_esterni.ServiceException;
import it.sella.integrazione_sistemi_esterni.server.Bridge;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;

/** Integrates the AddresManager methods with ISE.
 *  So that the external systems which is not part of H2O can make use of these methods.
 */

public class AddressManagerServiceBridgeImpl implements Bridge
{
    
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressManagerServiceBridgeImpl.class);

    public String invokeService(final String xmlAddress) throws RemoteException, ServiceException
    {
        try {
            AddressManagerServiceFactory.getInstance().getAddressServiceManager().removeUnusedAddress();
        } catch (final AddressException e) {
            log4Debug.severeStackTrace(e);
            throw new ServiceException(e.getMessage());
        } catch (final RemoteException e) {
            log4Debug.severeStackTrace(e);
            throw new ServiceException(e.getMessage());
        }
        return "";
    }

}
