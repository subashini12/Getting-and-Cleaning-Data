package it.sella.address;

import it.sella.address.egon.view.EgonView;
import it.sella.address.implementation.NormalizedAddressStatus;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.List;

/**  To get the services or to invoke the methods from this interface. The syntax for invoking the method is :
 *   AddressManagerFactory.getInstance().getAddressManager().anymethod from this interface();
 *   For ex:
 *   AddressManagerFactory.getInstance().getAddressManager().createAddress(ht,addressView);
 */

public interface IAddressManager extends Serializable {

    /** Creates the address. The CausaleSubsystem,SoggettoId and productContoId must be containing the valid value. Other
     *  Values like citta also has to be set. Why CausaleSubsystem,SoggettoId and productContoId is given importance is
     *  that by calling validateAddress method these values will not be set. By pushing to Address application the
     *  AddressView is retrieved where even CausaleSubsystem,SoggettoId are set but the ProductContoId will not be set.
     *  CausaleSubsystem is the causale value from classificazione.
     *  The classificazione entries related with this are :
     *  SUBSYS ---- Parent Desc : Sub System
     *  ANAG -- Child of SUBSYS
     *  ACFW -- Child of SUBSYS
     *  CARTE  -- Child of SUBSYS.
     *  @see AddressView
     *  @param  AddressView addressview
     *  @exception AddressException
     *  @exception RemoteException;
     */

    public void createAddress (AddressView addressView) throws AddressException, RemoteException;

    /** Modifies the address
     *  @param  boolean. If the value is set as true for this parameter. It updates the address of this soggetto for all
     *  the products or contos of this soggetto. If the value is set as false, it update the address for the particular
     *  product or soggetto.
     *  @param  AddressView addressview
     *  @exception AddressException
     *  @exception RemoteException;
     */

    public void setAddress(boolean modifyAllProductConto, AddressView addressView) throws AddressException, RemoteException;

    /** The address is retrieved for the corresponding sogogettoid, subsystem id and product/conto id
     *  @param Long soggettoId
     *  @param String subSystemCl
     *  CausaleSubsystem is the causale value from classificazione.
     *  The classificazione entries related with this are :
     *  SUBSYS ---- Parent Desc : Sub System
     *  ANAG -- Child of SUBSYS
     *  ACFW -- Child of SUBSYS
     *  CARTE  -- Child of SUBSYS.
     *  @param Long soggettoId
     *  @return AddressView
     *  @exception AddressException
     *  @exception RemoteException;
     */


    public AddressView getAddress(Long soggettoId, String subSystemCl,Long pcId) throws AddressException, RemoteException;

    /** The address is retrieved for the corresponding sogogettoid, subsystem id
     *  @param Long soggettoId
     *  @param String subSystemCl
     *  CausaleSubsystem is the causale value from classificazione.
     *  The classificazione entries related with this are :
     *  SUBSYS ---- Parent Desc : Sub System
     *  ANAG -- Child of SUBSYS
     *  ACFW -- Child of SUBSYS
     *  CARTE  -- Child of SUBSYS.
     *  @return Collection of AddressView
     *  @exception AddressException
     *  @exception RemoteException;
     */

    public Collection listAddress(Long soggettoId,String subSystemCl) throws AddressException, RemoteException;

    /** The address is retrieved for the corresponding sogogettoid
     *  @param Long soggettoId
     *  @return Collection of AddressViews
     *  @exception AddressException
     *  @exception RemoteException;
     */

    public Collection listAddressSoggetto(Long soggettoId) throws AddressException, RemoteException;

    /**  residenza address for PF  residenza address of first intestatario for PL sede legale address for AZ. The returned view
     *  depends on the tiposoggetto of soggettoid
     *  @param Long soggettoId
     *  @return AddressView
     *  @exception AddressException
     *  @exception RemoteException;
     */

    public AddressView getDefaultPostalAddress(Long soggettoId) throws AddressException, RemoteException;

    /** The xml is verified for the data. If the data passed in the xml is correct the address view is returned which can
     * be passed for createAddress method else returns a view which is null. The validations performed are if the nazione is ITALIA
     * then there should be a citta, cap and provincia. If the nazione is not ITALIA then the citta alone is mandatory. But in both the
     * cases the indirizzo and TipoIndirizzo are mandatory. If the xml is not satisfied with these conditions then a null is returned
     * else the AddressView is returned which can be used for the createAddress or setAddress method
     *  @param String xml. The xml format is as follows:
     *  <pre>
     *  &lt;INDIRIZZO&gt;
     *  &lt;TIPO_INDIRIZZO&gt;IRE&lt;/TIPO_INDIRIZZO&gt;
     *  &lt;INDIRIZZO&gt;VIA ITALIA&lt;/INDIRIZZO&gt;
     *  &lt;PROVINCIA&gt;BI&lt;/PROVINCIA&gt;
     *  &lt;CAP&gt;13900&lt;/CAP&gt;
     *  &lt;CITTA&gt;BIELLA&lt;/CITTA&gt;
     *  &lt;NAZIONE&gt;ITALIA&lt;/NAZIONE&gt;
     *  &lt;/INDIRIZZO&gt;</pre>
     *  @return AddressView
     *  @exception AddressException
     *  @exception RemoteException;
     */

    public AddressView validateAddress (String xml) throws AddressException, RemoteException;


    /** This indicates that the subSystemcl is compatible with the tipoIndirizzoCl
     *  @param String subSystemCl : The subsystem causale
     *  @param String tipoIndirizzoCl : The tipo indirizzo causale
     *  @return boolean true is returned if the subSystemCl is compatible tipoIndirizzoCl else false will be returned
     *  @exception AddressException
     *  @exception RemoteException;
     * */
    public boolean isCompatibleIndirizzo(String subSystemCl, String tipoIndirizzoCl) throws AddressException, RemoteException;

    /** Updates the soggetto id for a conto
     *  @param Long oldSoggettoId
     *  @param Long newSoggettoId
     *  @exception AddressException, RemoteException;
     */
    public void updateSoggetto(Long oldSoggettoId, Long newSoggettoId) throws AddressException, RemoteException;

    public void updateSoggetto(Long oldSoggettoId, Long newSoggettoId, Long opId) throws AddressException, RemoteException;

    /** @deprecated This method will be removed on August 1, 2004. The substitution for this method
     * is the new method - getPostalAddressInXMLFormat.
     * The CDATA attribute is added to display the special chars in the xml element values.
     * Returns the AE code for the input soggettoId and the productId
     *  @param  soggettoId Long
     *  @param  productId Long
     *  @param  subSystemCausale String
     *  @exception AddressException
     *  @exception RemoteException
     */

    public String getPostalAddress(Long soggettoId, Long productId,String subSystemCausale) throws AddressException, RemoteException;

    /** Returns the AE code for the input soggettoId and the productId
     *  @param  soggettoId Long
     *  @param  productId Long
     *  @param  subSystemCausale String
     *  @exception AddressException
     *  @exception RemoteException
     */

    public String getPostalAddressInXMLFormat(Long soggettoId, Long productId,String subSystemCausale) throws AddressException, RemoteException;

	/**
	 * Returns the AE code for the input soggettoId and the productId
	 * @param soggettoId
	 * @param productId
	 * @param subSystemCausale
	 * @param bypassCode
	 * @return
	 * @throws AddressException
	 * @throws RemoteException
	 */

    public String getPostalAddressInXMLFormat(final Long soggettoId, final Long productId,
    		final String subSystemCausale, final String bypassCode) throws AddressException, RemoteException;

    /** The CDATA attribute is added to display the special chars in the xml element values.
     *  Returns the AE code for the input soggettoId and the productId
     *  @param  soggettoId Long
     *  @param  productId Long
     *  @param  subSystemCausale String
     *  @param  intestazione String
     *  @param  errorCode Long
     *  @exception AddressException
     *  @exception RemoteException
     */

    public String getPostalAddress(Long soggettoId, Long productId,String subSystemCausale, String intestazione, Long errorCode) throws AddressException, RemoteException;

    /** The CDATA attribute is added to display the special chars in the xml element values.
     *  Returns the AE code for the input soggettoId and the productId
     * @param soggettoId
     * @param productId
     * @param subSystemCausale
     * @param intestazione
     * @param errorCode
     * @param bypassCode
     * @return
     * @throws AddressException
     * @throws RemoteException
     */
    public String getPostalAddress(final Long soggettoId, final Long productId,
    		final String subSystemCausale, final String intestazione,
    		final Long errorCode,final String bypassCode) throws AddressException, RemoteException;

    /** Returns the AE code for the input soggettoId and the productId
     *  @param  soggettoId Long
     *  @param  productId Long
     *  @param  subSystemCausale String
     *  @param  intestazione String
     *  @param  errorCode Long
     *  @exception AddressException
     *  @exception RemoteException
     */

    public String getPostalAddressInXMLFormat(Long soggettoId, Long productId,String subSystemCausale, String intestazione, Long errorCode) throws AddressException, RemoteException;
     /**
     * Returns the AE code for the input soggettoId and the productId
     * @param soggettoId
     * @param productId
     * @param subSystemCausale
     * @param intestazione
     * @param errorCode
     * @param bypassCode
     * @return
     * @throws AddressException
     * @throws RemoteException
     */
    public String getPostalAddressInXMLFormat(final Long soggettoId, final Long productId,
    		final String subSystemCausale, final String intestazione,
    		final Long errorCode, final String bypassCode) throws AddressException, RemoteException;

    /** The CDATA attribute is added to display the special chars in the xml element values.
     * Returns the AE code for the input soggettoId and the productId
     * @param soggettoId
     * @param productId
     * @param subSystemCausale
     * @param intestazione
     * @param errorCode
     * @param bypassCode
     * @param skipDomolCheck
     * @return
     * @throws AddressException
     * @throws RemoteException
     */
    /*public String getPostalAddressInXMLFormat(final Long soggettoId,
			final Long productId, final String subSystemCausale,
			final String intestazione, final Long errorCode,
			final String bypassCode, final String skipDomolCheck)
			throws AddressException, RemoteException;*/

    /**
     * Returns the AE code for the input soggettoId and the productId
     * @param soggettoId
     * @param productId
     * @param subSystemCausale
     * @param intestazione
     * @param errorCode
     * @param bypassCode
     * @param skipDomolCheck
     * @return
     * @throws AddressException
     * @throws RemoteException
     */
    /*public String getPostalAddress(final Long soggettoId,
			final Long productId, final String subSystemCausale,
			final String intestazione, final Long errorCode,
			final String bypassCode, final String skipDomolCheck)
			throws AddressException, RemoteException; */


    /**
     * Updates internal values for given Collection of addressViews.
     * @param addressViews
     * @throws AddressException
     * @throws RemoteException
     */
    public void modificaInternal(Collection addressViews) throws AddressException,RemoteException;

    /**
     * The method updates address in h2o and or host based on input details for given 13cifre
     * @param tredeciCifre
     * @param valore
     * @param hostUserCode
     * @throws AddressException
     * @throws RemoteException
     */
    public void gestoreAccountAddress(String tredeciCifre,String valore, String hostUserCode) throws AddressException, RemoteException;


    public NormalizedAddressStatus normalizeIndirrizo(String nazione,String cittaCommune,String indirrizzo,String provincia,String cap,Boolean isDOMXXCheckReq) throws AddressException, RemoteException;

    /**
     * The method is used to set DOMOL internal for the given product address.
     * If any of the input detail passed is null exception will be thrown
     * If address not found for the input details exception will be thrown
     * If existing internal value is DOMBK/DOMCP/DOMDG/DOMKO exception will be thrown.
     * @param soggettoId Long
     * @param productId Long
     * @param subSystemCausale String from Classificazione table
     * @throws AddressException
     * @throws RemoteException
     */
    public void setDOMOL(Long soggettoId, Long productId,String subSystemCausale) throws AddressException, RemoteException;

    /**
     * This method is used to remove DOMOL internal. DOMOR will be set as internal
     * If any of the input detail passed is null exception will be thrown
     * If address not found for the input details exception will be thrown
     * If existing internal value is not DOMOR/DOMOL exception will be thrown.
     * @param soggettoId
     * @param productId
     * @param subSystemCausale
     * @throws AddressException
     * @throws RemoteException
     */
    public void removeDOMOL(Long soggettoId, Long productId,String subSystemCausale) throws AddressException, RemoteException;

    /**
     * This method is used to remove product address link details
     * If any of the input detail passed is null exception will be thrown
     * If address not found for the input details exception will be thrown
     * @param soggettoId
     * @param subSystemCausale
     * @param productId
     * @throws AddressException
     * @throws RemoteException
     */

    public void removeProductAddress(Long soggettoId,String subSystemCausale, Long productId) throws AddressException, RemoteException;
    /**
     * This method return the list of soggettoIds, this soggettos contains same IRE address and the same bank
     * @param indirizzio
     * @param cap
     * @param cittaCommune
     * @param provinciaSingla
     * @param nazione
     * @param tipoIndirrizoCausale
     * @param bankSoggettId
     * @return
     * @throws AddressException
     * @throws RemoteException
     */

    public List getAddressAlreadyUsed(String indirizzio, String cap, String cittaCommune, String provinciaSingla, String nazione, String tipoIndirrizoCausale, Long bankSoggettId )  throws AddressException, RemoteException;

    /**
     * Method to replace the address assigned for a product from one soggetto to another soggetto
     * If oldSoggettoId,productId,subSystemCausale record exist, oldSoggettoId will be replaced by  newSoggettoId
     * @param oldSoggettoId
     * @param newSoggettoId
     * @param productId
     * @throws AddressException
     * @throws RemoteException
     */
    public void swapProductAddressPerSoggetto(final Long oldSoggettoId, final Long newSoggettoId,final String subSystemCausal,final Long productId) throws AddressException, RemoteException;

    /**   This method functionality is similar of  validateAddress method .
     *   Only difference is , in validateAddressWithThrowError exception will be thrown , if error found in input XML.
     *   But in  validateAddress , null  AddressView object will be returned.
     *
     *  The xml is verified for the data. If the data passed in the xml is correct the address view is returned which can
     * be passed for createAddress method else exception will be thrown. The validations performed are if the nazione is ITALIA
     * then there should be a citta, cap and provincia. If the nazione is not ITALIA then the citta alone is mandatory. But in both the
     * cases the indirizzo and TipoIndirizzo are mandatory. If the xml is not satisfied with these conditions then exception will be thrown
     * else the AddressView is returned which can be used for the createAddress or setAddress method
     *  @param String xml. The xml format is as follows:
     *  <pre>
     *  &lt;INDIRIZZO&gt;
     *  &lt;TIPO_INDIRIZZO&gt;IRE&lt;/TIPO_INDIRIZZO&gt;
     *  &lt;INDIRIZZO&gt;VIA ITALIA&lt;/INDIRIZZO&gt;
     *  &lt;PROVINCIA&gt;BI&lt;/PROVINCIA&gt;
     *  &lt;CAP&gt;13900&lt;/CAP&gt;
     *  &lt;CITTA&gt;BIELLA&lt;/CITTA&gt;
     *  &lt;NAZIONE&gt;ITALIA&lt;/NAZIONE&gt;
     *  &lt;/INDIRIZZO&gt;</pre>
     *  @return AddressView
     *  @exception AddressException
     *  @exception RemoteException;
     */

    public AddressView validateAddressWithThrowError (String xml) throws AddressException, RemoteException;

    /**
     * Method added for New method for Normalization
     * This method does the normalization based on nazione,citta,indrizzo,provincia, cap, edificio (Which is the location),Presso C/O
     * @param nazione
     * @param cittaCommune
     * @param indirrizzo
     * @param provincia
     * @param cap
     * @param isDOMXXCheckReq
     * @param edificio
     * @param presso
     * @return NormalizedAddressStatus
     * @throws AddressException
     * @throws RemoteException
     */
    public NormalizedAddressStatus normalizeIndirrizo( final String nazione, final String cittaCommune, final String indirrizzo, final String provincia,
			final String cap, final Boolean isDOMXXCheckReq ,final String edificio,final String presso) throws AddressException, RemoteException;
    /**
     * Method can be used to get Provincia
     * @param cap
     * @param nazione
     * @param provincia
     * @return Collection<EgonView> which contains Collection<EgonProvinciaView>
     * @throws AddressException
     * @throws RemoteException
     */
    public Collection<EgonView> getProvincia(final String cap,final String nazione,final String provincia) throws AddressException,RemoteException;

    /**
     * Method can be used to get Citta
     * @param cap
     * @param citta
     * @param nazione
     * @param provincia
     * @return Collection<EgonView> which contains Collection<EgonProvinciaView>,Collection<EgonCittaView>,Collection<EgonCapView>
     * @throws AddressException
     * @throws RemoteException
     */
    public Collection<EgonView> getCitta(final String cap,final String citta,final String nazione,final String provincia) throws AddressException,RemoteException;

    /**
     * Method can be used to get Cap
     * @param cap
     * @return Collection<EgonView> which contains Collection<EgonProvinciaView>,Collection<EgonCapView>
     * @throws AddressException
     * @throws RemoteException
     */
    public Collection<EgonView> getCapWithProvincia(final String cap) throws AddressException,RemoteException;

    /**
     *  Method can be used to get Street
     * @param cap
     * @param citta
     * @param nazione
     * @param provincia
     * @param indrizzi
     * @returnCollection<EgonView> which contains Collection<EgonCittaView>,Collection<EgonCapView>, Collection<EgonProvinciaView>,Collection<EgonIndrizziView>
     * @throws AddressException
     * @throws RemoteException
     */
    public Collection<EgonView> getIndrizzi(final String cap,final String citta,final String nazione,final String provincia,final String indrizzi) throws AddressException, RemoteException;

    /**
     * Method can be used to get nazione
     * @param nazione
     * @return  which contains Collection<EgonNazioneView>
     * @throws AddressException
     * @throws RemoteException
     */
    public Collection<EgonView> getNazione(final String nazione) throws AddressException,RemoteException;

}
