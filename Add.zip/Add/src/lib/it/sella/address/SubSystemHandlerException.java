package it.sella.address;

/**
 * This exception class used to wrap the exception thrown by subsystem method calls
 */
public class SubSystemHandlerException extends Exception {
    
    /**
     *  Default Constructor
     */
    public SubSystemHandlerException() {
    	// explicit default constructor
    }

    /**
     * One argument Constructor, which in turn calls superclass constructor
     * @param message java.lang.String
     */
    public SubSystemHandlerException(final String message) {
        super(message);
    }

}
