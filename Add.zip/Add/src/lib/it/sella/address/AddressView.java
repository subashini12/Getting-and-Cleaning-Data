package it.sella.address;

import it.sella.anagrafe.ICapView;
import it.sella.anagrafe.ICittaView;
import it.sella.anagrafe.INazioneView;
import it.sella.anagrafe.IProvinciaView;

import java.io.Serializable;

public class AddressView implements Serializable
{



    public String getCitta()
    {
        return citta;
    }

    public void setCitta(final String citta)
    {
        this.citta = citta;
    }

    public String getProvincia()
    {
        return provincia;
    }

    public void setProvincia(final String provincia)
    {
        this.provincia = provincia;
    }

    public String getCap()
    {
        return cap;
    }

    public void setCap(final String cap)
    {
        this.cap = cap;
    }

    public String getNazione()
    {
        return nazione;
    }

    public void setNazione(final String nazione)
    {
        this.nazione = nazione;
    }

    public String getIndirizzo()
    {
        return indirizzo;
    }

    public void setIndirizzo(final String indirizzo)
    {
        this.indirizzo = indirizzo;
    }

    public Long getTipoIndirrizo()
    {
        return tipoIndirrizo;
    }

    public void setTipoIndirrizo(final Long tipoIndirrizo)
    {
        this.tipoIndirrizo = tipoIndirrizo;
    }

    public ICittaView getCittaView()
    {
        return cittaView;
    }

    public void setCittaView(final ICittaView cittaView)
    {
        this.cittaView = cittaView;
    }

    public INazioneView getNazioneView()
    {
        return nazioneView;
    }

    public void setNazioneView(final INazioneView nazioneView)
    {
        this.nazioneView = nazioneView;
    }

    public IProvinciaView getProvinciaView()
    {
        return provinciaView;
    }

    public void setProvinciaView(final IProvinciaView provinciaView)
    {
        this.provinciaView = provinciaView;
    }

    public String getCausaleTipoIndirizzo()
    {
        return causaleTipoIndirizzo;
    }

    public void setCausaleTipoIndirizzo(final String causaleTipoIndirizzo)
    {
        this.causaleTipoIndirizzo = causaleTipoIndirizzo;
    }

    public String getDescrizioneTipoIndirizzo()
    {
        return descrizioneTipoIndirizzo;
    }

    public void setDescrizioneTipoIndirizzo(final String descrizioneTipoIndirizzo)
    {
        this.descrizioneTipoIndirizzo = descrizioneTipoIndirizzo;
    }

    public String getCausaleSubsystem()
    {
        return causaleSubsystem;
    }

    public void setCausaleSubsystem(final String causaleSubsystem)
    {
        this.causaleSubsystem = causaleSubsystem;
    }

    public String getDescrizioneSubsystem()
    {
        return descrizioneSubsystem;
    }

    public void setDescrizioneSubsystem(final String descrizioneSubsystem)
    {
        this.descrizioneSubsystem = descrizioneSubsystem;
    }

    public Long getReserved()
    {
        return reserved;
    }

    public void setReserved(final Long reserved)
    {
        this.reserved = reserved;
    }

    public Long getFrequency()
    {
        return frequency;
    }

    public void setFrequency(final Long frequency)
    {
        this.frequency = frequency;
    }

    public Long getInternal()
    {
        return internal;
    }

    public void setInternal(final Long internal)
    {
        this.internal = internal;
    }

    public ICapView getCapView()
    {
        return capView;
    }

    public void setCapView(final ICapView capView)
    {
        this.capView = capView;
    }

    public Long getProductContoId()
    {
        return productContoId;
    }

    public void setProductContoId(final Long productContoId)
    {
        this.productContoId = productContoId;
    }

    public Long getSoggettoId()
    {
        return soggettoId;
    }

    public void setSoggettoId(final Long soggettoId)
    {
        this.soggettoId = soggettoId;
    }

    public String getNch()
    {
        return nch;
    }

    /** If alignment with host has to be done. In that case the value has to be set */
    public void setNch(final String nch)
    {
        this.nch = nch;
    }

    public String getPostalCode(){
        return postalCode ;
    }

    public void setPostalCode(final String postalCode){
        this.postalCode = postalCode;
    }

	public Long getOpId() {
		return opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}

	public void setNormStatus(final String normStatus) {
		this.normStatus = normStatus;
	}

	public String getNormStatus() {
		return normStatus;
	}

	/**
	 * @return the edificio
	 */
	public String getEdificio() {
		return edificio;
	}

	/**
	 * @param edificio the edificio to set
	 */
	public void setEdificio(String edificio) {
		this.edificio = edificio;
	}

	/**
	 * @return the presso
	 */
	public String getPresso() {
		return presso;
	}

	/**
	 * @param presso the presso to set
	 */
	public void setPresso(String presso) {
		this.presso = presso;
	}

	private String provincia;
    private String citta;
    private String cap;
    private String nazione;
    private String indirizzo;
    private Long tipoIndirrizo;
    private ICittaView cittaView;//    (If Foreign Citt� NULL value is returned)
    private INazioneView nazioneView;
    private IProvinciaView provinciaView;
    private ICapView capView;
    private String causaleTipoIndirizzo;
    private String descrizioneTipoIndirizzo;
    private String causaleSubsystem;
    private String descrizioneSubsystem;
    private Long reserved;
    private Long frequency;
    private Long internal;
    private Long productContoId;
    private Long soggettoId;
    private String nch;
    private String postalCode ;
    private Long opId;
    private String normStatus;
    private String edificio;
    private String presso;

	private boolean checkEquality(final String newValue, final String thisValue) {
		boolean isEquality = false;
	  if(newValue != null && thisValue != null &&
	   	 newValue.equals(thisValue) ) {
		  isEquality =  true;
	  } else if (newValue == null && thisValue == null) {
		  isEquality =  true;
	  }
	  return isEquality;
	}

    public boolean equals(final Object obj) {
    	boolean result = false;
		if (obj instanceof AddressView) {
			final AddressView addressView = (AddressView) obj;
			result = equalIndirizzo(addressView) && equalCitta(addressView) && equalCap(addressView) && equalProvincia(addressView) && equalNazione(addressView)
					&& equalEdificio(addressView) && equalPresso(addressView);
		}
		return result;
    }

	private boolean equalIndirizzo(final AddressView addressView){
		return checkEquality(addressView.getIndirizzo(), this.indirizzo);
	}

	private boolean equalCitta(final AddressView addressView){
		return checkEquality(addressView.getCittaView() != null ? addressView.getCittaView().getCommune() : addressView.getCitta(),
				this.cittaView != null ? this.cittaView.getCommune() : this.citta);
	}

	private boolean equalCap(final AddressView addressView){
		return checkEquality(addressView.getCapView() != null ? addressView.getCapView().getCap() : addressView.getCap(),
				this.capView != null ? this.capView.getCap() : this.cap);
	}

	private boolean equalProvincia(final AddressView addressView){
		return checkEquality(addressView.getProvinciaView() != null ? addressView.getProvinciaView().getSigla() : addressView.getProvincia(),
				this.provinciaView != null ? this.provinciaView.getSigla() : this.provincia);
	}

	private boolean equalNazione(final AddressView addressView){
		return checkEquality(addressView.getNazioneView() != null ? addressView.getNazioneView().getNome() : addressView.getNazione(),
				this.nazioneView != null ? this.nazioneView.getNome() : this.nazione);
	}

	private boolean equalEdificio(final AddressView addressView){
		return checkEquality(addressView.getEdificio(), this.edificio);
	}

	private boolean equalPresso(final AddressView addressView){
		return checkEquality(addressView.getPresso(), this.presso);
	}

    public int hashCode() {
		return super.hashCode();
	}
}
