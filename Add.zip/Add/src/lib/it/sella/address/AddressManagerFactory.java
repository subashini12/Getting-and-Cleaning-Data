package it.sella.address;

import it.sella.address.implementation.AddressManagerClientImpl;

public class AddressManagerFactory
{

	private static AddressManagerFactory addressManagerFactoryObj;
    private IAddressManager addressManager = null;

    protected AddressManagerFactory()
    {
    	// explicit default constructor
    }

    public static AddressManagerFactory getInstance()
    {
        if(addressManagerFactoryObj == null) {
			addressManagerFactoryObj = new AddressManagerFactory();
		}
        return addressManagerFactoryObj;
    }

    public IAddressManager getAddressManager()
    {
        if( addressManager == null) {
			addressManager = new AddressManagerClientImpl();
		}
        return addressManager;
    }

}
