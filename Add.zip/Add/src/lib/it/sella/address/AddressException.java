package it.sella.address;

public class AddressException extends Exception
{
    public AddressException()
    {
    	// explicit default constructor
    }

    public AddressException(final String s)
    {
        super(s);
    }

    public AddressException(final Throwable t)
    {
        super(t.getMessage());
    }

    public AddressException(final String message ,final Throwable throwable)
    {
        super(message,throwable);
    }

}
