package it.sella.address;

import it.sella.address.implementation.util.DateHandler;
import it.sella.address.implementation.util.StringHandler;

import java.io.Serializable;
import java.sql.Timestamp;

public class PostalByPassView implements Serializable {
	
	private static final String DATE_FORMAT = "dd/MM/yyyy";
	
	public Long getId() {
		return id;
	}
	
	public void setId(final Long id) {
		this.id = id;
	}
	
	public String getBypassCode() {
		return bypassCode;
	}
	
	public void setBypassCode(final String bypassCode) {
		this.bypassCode = bypassCode;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(final String description) {
		this.description = description;
	}
	
	public Timestamp getStartDate() {
		return startDate;
	}
	
	public void setStartDate(final Timestamp startDate) {
		this.startDate = startDate;
	}
	
	public Timestamp getEndDate() {
		return endDate;
	}
	
	public void setEndDate(final Timestamp endDate) {
		this.endDate = endDate;
	}
	
	public String getNotes() {
		return notes;
	}
	
	public void setNotes(final String notes) {
		this.notes = notes;
	}
	
    public boolean equals(final Object object) {
    	boolean result = false;
    	if (object instanceof PostalByPassView) {
    		final PostalByPassView postalByPassView = (PostalByPassView)object;
    		result = equalBypassCode(postalByPassView) && equalDescription(postalByPassView) && equalStartDate(postalByPassView) && equalEndDate(postalByPassView) && equalNotes(postalByPassView);
    	}
		return result;
    }
    
    private boolean equalBypassCode(final PostalByPassView postalByPassView){
    	return new StringHandler().checkForEquality(postalByPassView.getBypassCode(), this.bypassCode);
    }
    
    private boolean equalDescription(final PostalByPassView postalByPassView){
    	return new StringHandler().checkForEquality(postalByPassView.getDescription(), this.description);
    }
    
    private boolean equalStartDate(final PostalByPassView postalByPassView){
    	final DateHandler dateHandler = new DateHandler();
    	return new StringHandler().checkForEquality(dateHandler.formatDate(postalByPassView.getStartDate(), DATE_FORMAT), dateHandler.formatDate(this.startDate, DATE_FORMAT));
    }
    
    private boolean equalEndDate(final PostalByPassView postalByPassView){
    	final DateHandler dateHandler = new DateHandler();
    	return new StringHandler().checkForEquality(dateHandler.formatDate(postalByPassView.getEndDate(), DATE_FORMAT), dateHandler.formatDate(this.endDate, DATE_FORMAT));
    }
    
    private boolean equalNotes(final PostalByPassView postalByPassView){
    	return new StringHandler().checkForEquality(postalByPassView.getNotes(), this.notes);
    }
    
    
    public int hashCode() {
		return super.hashCode();
	}

	private Long id;
	private String bypassCode;
	private String description;
	private Timestamp startDate;
	private Timestamp endDate;
	private String notes;
}
