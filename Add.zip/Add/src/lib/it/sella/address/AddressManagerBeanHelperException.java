package it.sella.address;

public class AddressManagerBeanHelperException extends Exception {

	
    /**
     *  Default Constructor
     */
    public AddressManagerBeanHelperException() {
    	// explicit default constructor
    }

    /**
     * One argument Constructor, which in turn calls superclass constructor
     * @param message java.lang.String
     */
    public AddressManagerBeanHelperException(final String message) {
        super(message);
    }

}
