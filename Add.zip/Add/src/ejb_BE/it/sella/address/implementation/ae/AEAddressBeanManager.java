package it.sella.address.implementation.ae;

import it.sella.address.AddressException;
import it.sella.address.implementation.factory.AddressEntityManagerFactory;
import it.sella.address.implementation.factory.BeanUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

public class AEAddressBeanManager  implements IAEAddressBeanManager{

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AEAddressBeanManager.class);

	private final EntityManager entityManager;

	public AEAddressBeanManager(){
		entityManager = AddressEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.ae.IAEAddressBeanManager#create(it.sella.address.implementation.ae.AEAddress)
	 */
	public AEAddress create(final AEAddress aeAddress) throws AddressException {
		final AEAddressBean aeAddressBean  = new AEAddressBean();
		BeanUtil.copyProperties(aeAddressBean, aeAddress);
		entityManager.persist(aeAddressBean);
		entityManager.flush();
		BeanUtil.copyProperties(aeAddress,aeAddressBean);
		return aeAddress;
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.ae.IAEAddressBeanManager#update(it.sella.address.implementation.ae.AEAddress)
	 */
	public AEAddress update(final AEAddress aeAddress) throws AddressException {
		entityManager.persist(aeAddress);
		return aeAddress;
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.ae.IAEAddressBeanManager#remove(it.sella.address.implementation.ae.AEAddress)
	 */
	public void remove(final AEAddress aeAddress) {
		entityManager.remove(aeAddress);
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.ae.IAEAddressBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public AEAddress findByPrimaryKey(final Long primaryKey) throws FinderException {
		if(primaryKey == null){
			throw new FinderException("PrimaryKey is null");
		}
		final AEAddress aeAddressBe= entityManager.find(AEAddressBean.class, primaryKey);
		if(aeAddressBe == null){
			throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return aeAddressBe;
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.ae.IAEAddressBeanManager#findByLinkedId(java.lang.Long)
	 */
	public AEAddress findByLinkedId(final Long linkedId) throws  FinderException{
		try{
			final Query findByLinkedId = entityManager.createNamedQuery("AEAddressBean.findByLinkedId");
			findByLinkedId.setParameter("addressLinkId", linkedId);
			return (AEAddress)findByLinkedId.getSingleResult();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
		catch (final NonUniqueResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException("EJB:013073 too_many_results_for_get_single_result");
		}
	}

}
