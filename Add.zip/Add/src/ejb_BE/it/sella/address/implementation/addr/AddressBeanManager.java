package it.sella.address.implementation.addr;

import it.sella.address.AddressException;
import it.sella.address.implementation.factory.AddressEntityManagerFactory;
import it.sella.address.implementation.factory.BeanUtil;

import java.util.Collection;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;


/**
 * Bean Manager class to manage Address Bean
 *
 */
public class AddressBeanManager implements IAddressBeanManager {

	private final EntityManager entityManager;
	private static final String NONUNIQUE_RESULT_ERROR_MSG = "EJB:013073 too_many_results_for_get_single_result";
	private static final String CITTA = "citta";
	private static final String NAZIONE = "nazione";
	private static final String INDIRIZZO = "indirizzo";
	private static final String CAPVALUE = "capValue";
	private static final String PROVINCIA = "provincia";
	private static final String PRESSO = "presso";
	private static final String CAPID = "capId";
	private static final String EDIFICIO = "edificio";

	public AddressBeanManager() {
		entityManager = AddressEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addr.IAddressBeanManager#create(it.sella.address.implementation.addr.Address)
	 */
	public Address create(final Address address) throws AddressException {
		final Address addressBean = new AddressBean();
		BeanUtil.copyProperties(addressBean, address);
		entityManager.persist(addressBean);
		entityManager.flush();
		BeanUtil.copyProperties(address,addressBean);
		return address;
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addr.IAddressBeanManager#update(it.sella.address.implementation.addr.Address)
	 */
	public Address update(final Address address) {
		entityManager.persist(address);
		return address;
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addr.IAddressBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public Address findByPrimaryKey(final Long primaryKey) throws FinderException {
		if(primaryKey == null){
			throw new FinderException("PrimaryKey is null");
		}
		final AddressBean addressBean = entityManager.find(AddressBean.class, primaryKey);
		if(addressBean==null){
			throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return addressBean;
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addr.IAddressBeanManager#findByAddress(java.lang.String, java.lang.Long, java.lang.String)
	 */
	public Address findByAddress(final String citta,final Long nazione, final String indirizzo) throws FinderException {

		try{
			final Query findByAddress = buildFindByAddress(citta, nazione, indirizzo);

			final AddressBean addressBean = (AddressBean) findByAddress.getSingleResult();

			return addressBean;
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}catch (final NonUniqueResultException e) {
			throw new FinderException(NONUNIQUE_RESULT_ERROR_MSG);
		}
	}


	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addr.IAddressBeanManager#findByAddressProvincia(java.lang.String, java.lang.String, java.lang.Long, java.lang.String)
	 */
	public Address findByAddressProvincia(final String provincia,final String citta,final Long nazione, final String indirizzo) throws FinderException {

		try{
			final Query findByAddressProvincia = buildFindByAddressProvincia(
					provincia, citta, nazione, indirizzo);

			return (Address) findByAddressProvincia.getSingleResult();
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}catch (final NonUniqueResultException e) {
			throw new FinderException(NONUNIQUE_RESULT_ERROR_MSG);
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addr.IAddressBeanManager#findByAddressCapId(java.lang.String, java.lang.String, java.lang.Long, java.lang.Long, java.lang.String)
	 */
	public Address findByAddressCapId(final String provincia, final String citta, final Long cap, final Long nazione, final String indirizzo) throws FinderException {
		try{
			final Query findByAddressCapId = buildFindByAddressCapId(provincia,
					citta, cap, nazione, indirizzo);

			final Address addressBean = (Address) findByAddressCapId.getSingleResult();

			return addressBean;
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}catch (final NonUniqueResultException e) {
			throw new FinderException(NONUNIQUE_RESULT_ERROR_MSG);
		}
	}


	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addr.IAddressBeanManager#findByAddressCapValue(java.lang.String, java.lang.String, java.lang.Long, java.lang.String)
	 */
	public Address findByAddressCapValue(final String citta, final String capValue, final Long nazione, final String indirizzo) throws FinderException {

		try{
			final Query findByAddressCapValue = findByAddressCapVal(citta, capValue,
					nazione, indirizzo);

			return (Address) findByAddressCapValue.getSingleResult();
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}catch (final NonUniqueResultException e) {
			throw new FinderException(NONUNIQUE_RESULT_ERROR_MSG);
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addr.IAddressBeanManager#findByAddressCapProvinciaValue(java.lang.String, java.lang.String, java.lang.String, java.lang.Long, java.lang.String)
	 */
	public Address findByAddressCapProvinciaValue(final String provincia, final String citta, final String capValue, final Long nazione, final String indirizzo) throws FinderException {
		try{
			final Query findByAddressCapProvinciaValue = buildFindByAddressCapProvinciaValue(
					provincia, citta, capValue, nazione, indirizzo);

			return (Address) findByAddressCapProvinciaValue.getSingleResult();
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}catch (final NonUniqueResultException e) {
			throw new FinderException(NONUNIQUE_RESULT_ERROR_MSG);
		}
	}


	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addr.IAddressBeanManager#findAllByAddress(java.lang.String, java.lang.Long, java.lang.String)
	 */
	public Collection<Address> findAllByAddress(final String citta,final Long nazione, final String indirizzo) throws FinderException {
		try{
			final Query findByAddress = buildFindByAddress(citta, nazione, indirizzo);

			return findByAddress.getResultList();
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addr.IAddressBeanManager#findAllByAddressProvincia(java.lang.String, java.lang.String, java.lang.Long, java.lang.String)
	 */
	public Collection<Address> findAllByAddressProvincia(final String provincia,final String citta,final Long nazione, final String indirizzo) throws FinderException {
		try{
			final Query findByAddressProvincia = buildFindByAddressProvincia(
					provincia, citta, nazione, indirizzo);

			return findByAddressProvincia.getResultList();
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}

	}


	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addr.IAddressBeanManager#findAllByAddressCapId(java.lang.String, java.lang.String, java.lang.Long, java.lang.Long, java.lang.String)
	 */
	public Collection<Address> findAllByAddressCapId(final String provincia, final String citta, final Long cap, final Long nazione, final String indirizzo) throws FinderException {
		try{
			final Query findByAddressCapId = buildFindByAddressCapId(provincia,
					citta, cap, nazione, indirizzo);

			return findByAddressCapId.getResultList();
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}

	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addr.IAddressBeanManager#findAllByAddressCapValue(java.lang.String, java.lang.String, java.lang.Long, java.lang.String)
	 */
	public Collection<Address> findAllByAddressCapValue(final String citta, final String capValue, final Long nazione, final String indirizzo) throws FinderException {
		try{
			final Query findByAddressCapValue = findByAddressCapVal(citta, capValue,
					nazione, indirizzo);
			return findByAddressCapValue.getResultList();
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}


	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addr.IAddressBeanManager#findAllByAddressCapProvinciaValue(java.lang.String, java.lang.String, java.lang.String, java.lang.Long, java.lang.String)
	 */
	public Collection<Address> findAllByAddressCapProvinciaValue(final String provincia, final String citta, final String capValue, final Long nazione, final String indirizzo) throws FinderException {
		try{
			final Query findByAddressCapProvinciaValue = buildFindByAddressCapProvinciaValue(
					provincia, citta, capValue, nazione, indirizzo);

			return findByAddressCapProvinciaValue.getResultList();
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addr.IAddressBeanManager#remove(it.sella.address.implementation.addr.Address)
	 */
	public void remove(final Address address) {
		entityManager.remove(address);
	}

	/**
	 * Query Builder for FindByAddress
	 * @param citta
	 * @param nazione
	 * @param indirizzo
	 * @return
	 */
	private Query buildFindByAddress(final String citta, final Long nazione,
			final String indirizzo) {
		final Query findByAddress = entityManager.createNamedQuery("it.sella.address.implementation.addr.findByAddress");
		findByAddress.setParameter(CITTA, citta);
		findByAddress.setParameter(NAZIONE, nazione);
		findByAddress.setParameter(INDIRIZZO, indirizzo);
		return findByAddress;
	}


	/**
	 * Query Builder for FindByAddressCapId
	 * @param provincia
	 * @param citta
	 * @param cap
	 * @param nazione
	 * @param indirizzo
	 * @return
	 */
	private Query buildFindByAddressCapId(final String provincia, final String citta,
			final Long cap, final Long nazione, final String indirizzo) {
		final Query findByAddressCapId = entityManager.createNamedQuery("it.sella.address.implementation.addr.findByAddressCapId");
		findByAddressCapId.setParameter(PROVINCIA, provincia);
		findByAddressCapId.setParameter(CITTA, citta);
		findByAddressCapId.setParameter(CAPID,cap);
		findByAddressCapId.setParameter(NAZIONE, nazione);
		findByAddressCapId.setParameter(INDIRIZZO,indirizzo);
		return findByAddressCapId;
	}


	/**
	 * Query Builder for findByAddressCapProvinciaValue
	 * @param provincia
	 * @param citta
	 * @param capValue
	 * @param nazione
	 * @param indirizzo
	 * @return
	 */
	private Query buildFindByAddressCapProvinciaValue(final String provincia,
			final String citta, final String capValue, final Long nazione, final String indirizzo) {
		final Query findByAddressCapProvinciaValue = entityManager.createNamedQuery("it.sella.address.implementation.addr.findByAddressCapProvinciaValue");
		findByAddressCapProvinciaValue.setParameter(PROVINCIA, provincia);
		findByAddressCapProvinciaValue.setParameter(CITTA, citta);
		findByAddressCapProvinciaValue.setParameter(CAPVALUE,capValue);
		findByAddressCapProvinciaValue.setParameter(NAZIONE, nazione);
		findByAddressCapProvinciaValue.setParameter(INDIRIZZO,indirizzo);
		return findByAddressCapProvinciaValue;
	}



	/**
	 * Query Builder for findByAddressProvincia
	 * @param provincia
	 * @param citta
	 * @param nazione
	 * @param indirizzo
	 * @return
	 */
	private Query buildFindByAddressProvincia(final String provincia, final String citta,
			final Long nazione, final String indirizzo) {
		final Query findByAddressProvincia = entityManager.createNamedQuery("it.sella.address.implementation.addr.findByAddressProvincia");
		findByAddressProvincia.setParameter(PROVINCIA,provincia);
		findByAddressProvincia.setParameter(CITTA, citta);
		findByAddressProvincia.setParameter(NAZIONE, nazione);
		findByAddressProvincia.setParameter(INDIRIZZO,indirizzo);
		return findByAddressProvincia;
	}


	/**
	 * Query Builder for findByAddressCapValue
	 * @param citta
	 * @param capValue
	 * @param nazione
	 * @param indirizzo
	 * @return
	 */
	private Query findByAddressCapVal(final String citta, final String capValue,
			final Long nazione, final String indirizzo) {
		final Query findByAddressCapValue = entityManager.createNamedQuery("it.sella.address.implementation.addr.findByAddressCapValue");
		findByAddressCapValue.setParameter(CITTA,citta);
		findByAddressCapValue.setParameter(CAPVALUE,capValue);
		findByAddressCapValue.setParameter(NAZIONE, nazione);
		findByAddressCapValue.setParameter(INDIRIZZO,indirizzo);
		return findByAddressCapValue;
	}

	/**
	 * This method is used to get the address details with Presso
	 * @param citta
	 * @param capValue
	 * @param nazione
	 * @param indirizzo
	 * @param presso
	 * @return
	 * @throws FinderException
	 */
	@SuppressWarnings("unchecked")
	public Collection<Address> findAllByAddressPresso(final String provincia,final String citta, final Long capValue, final Long nazione, final String indirizzo,final String presso) throws FinderException {
		try{
			return setQueryParamForfindByAddressPresso(provincia,citta, capValue,	nazione, indirizzo,presso).getResultList();
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}
	private Query setQueryParamForfindByAddressPresso(final String provincia, final String citta, final Long cap, final Long nazione, final String indirizzo,final String presso) {
		final Query findByAddressByPresso = entityManager.createNamedQuery("it.sella.address.implementation.addr.findByAddressByPresso");
		findByAddressByPresso.setParameter(PROVINCIA, provincia);
		findByAddressByPresso.setParameter(CITTA, citta);
		findByAddressByPresso.setParameter(CAPID,cap);
		findByAddressByPresso.setParameter(NAZIONE, nazione);
		findByAddressByPresso.setParameter(INDIRIZZO,indirizzo);
		findByAddressByPresso.setParameter(PRESSO, presso);
		return findByAddressByPresso;
	}

	/**
	 * This method is used to get the address details with Presso
	 * @param provincia
	 * @param citta
	 * @param capValue
	 * @param nazione
	 * @param indirizzo
	 * @param presso
	 * @return Address
	 * @throws FinderException
	 */
	public Address findByAddressPresso(final String provincia,final String citta, final Long capValue, final Long nazione, final String indirizzo,final String presso) throws FinderException {
		try{
			return (Address) setQueryParamForfindByAddressPresso(provincia,citta, capValue,	nazione, indirizzo,presso).getSingleResult();
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}

	/**
	 * This method is used to get the address details with Edificio
	 * @param provincia
	 * @param citta
	 * @param capValue
	 * @param nazione
	 * @param indirizzo
	 * @param edificio
	 * @return Address
	 * @throws FinderException
	 */
	public Address findByAddressEdificio(final String provincia,final String citta, final Long capValue, final Long nazione, final String indirizzo,final String edificio) throws FinderException {
		try{
			return (Address) setQueryParamForfindByAddressEdificio(provincia,citta, capValue,nazione, indirizzo,edificio).getSingleResult();
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}

	private Query setQueryParamForfindByAddressEdificio(final String provincia, final String citta, final Long cap, final Long nazione, final String indirizzo,final String edificio) {
		final Query findByAddressByEdificio = entityManager.createNamedQuery("it.sella.address.implementation.addr.findByAddressByEdificio");
		findByAddressByEdificio.setParameter(PROVINCIA, provincia);
		findByAddressByEdificio.setParameter(CITTA, citta);
		findByAddressByEdificio.setParameter(CAPID,cap);
		findByAddressByEdificio.setParameter(NAZIONE, nazione);
		findByAddressByEdificio.setParameter(INDIRIZZO,indirizzo);
		findByAddressByEdificio.setParameter(EDIFICIO, edificio);
		return findByAddressByEdificio;
	}

	/**
	 * This method is used to get the address details with Edificio
	 * @param provincia
	 * @param citta
	 * @param capValue
	 * @param nazione
	 * @param indirizzo
	 * @param edificio
	 * @return Address
	 * @throws FinderException
	 */
	public Collection<Address> findAllByAddressEdificio(final String provincia,final String citta, final Long capValue, final Long nazione, final String indirizzo,final String edificio) throws FinderException {
		try{
			return (Collection<Address>) setQueryParamForfindByAddressEdificio(provincia,citta, capValue,nazione, indirizzo,edificio).getResultList();
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}

	@Override
	public Address findByAddressPressoAndEdificio(final String provincia,final String citta,final Long cap,final Long nazione,final String indirizzo,final String presso,final String edificio) throws FinderException {
		try{
			final Query findByAddressPressoAndEdificio = buildFindByAddressPressoAndEdificio(provincia,citta, cap, nazione, indirizzo,presso,edificio);
			return (Address) findByAddressPressoAndEdificio.getSingleResult();
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}

	private Query buildFindByAddressPressoAndEdificio(final String provincia, final String citta,final Long cap, final Long nazione, final String indirizzo,final String presso,final String edificio) {
		final Query findByAddressPressoAndEdificio = entityManager.createNamedQuery("it.sella.address.implementation.addr.findByAddressPressoAndEdificio");
		findByAddressPressoAndEdificio.setParameter(PROVINCIA, provincia);
		findByAddressPressoAndEdificio.setParameter(CITTA, citta);
		findByAddressPressoAndEdificio.setParameter(CAPID,cap);
		findByAddressPressoAndEdificio.setParameter(NAZIONE, nazione);
		findByAddressPressoAndEdificio.setParameter(INDIRIZZO,indirizzo);
		findByAddressPressoAndEdificio.setParameter(PRESSO,presso);
		findByAddressPressoAndEdificio.setParameter(EDIFICIO,edificio);
		return findByAddressPressoAndEdificio;
	}

	@Override
	public Collection<Address> findAllByAddressPressoAndEdificio(final String provincia,final String citta,final Long cap,final Long nazione,final String indirizzo,final String presso,final String edificio)throws FinderException {
		try{
			final Query findAllByAddressPressoAndEdificio = buildFindByAddressPressoAndEdificio(provincia,citta, cap, nazione, indirizzo,presso,edificio);
			return findAllByAddressPressoAndEdificio.getResultList();
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}



	@Override
	public Collection<Address> findAllByAddressByEdificio(String provincia,
			String citta, Long capValue, Long nazione, String indirizzo,
			String edificio) throws FinderException {
		try{
			return (Collection<Address>)setQueryParamForfindByAddressEdificio(provincia,citta, capValue,nazione, indirizzo,edificio).getSingleResult();
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}
}
