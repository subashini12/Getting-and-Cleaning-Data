package it.sella.address.implementation.addr;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name="ADD_TR_ADDRESS")
@SequenceGenerator(name = "addressNewSequenceGenerator", sequenceName="SEQ_AddressHome", allocationSize = 1)
@NamedQueries({
	@NamedQuery(name="it.sella.address.implementation.addr.findByAddressCapId", query="SELECT o FROM AddressBean o WHERE o.provincia= :provincia AND o.citta= :citta AND o.capId= :capId AND o.nazione= :nazione AND o.indirizzo= :indirizzo"),
	@NamedQuery(name="it.sella.address.implementation.addr.findByAddressCapValue", query="SELECT o FROM AddressBean o WHERE o.provincia is null AND o.citta= :citta AND o.capValue= :capValue AND o.nazione= :nazione AND o.indirizzo= :indirizzo"),
	@NamedQuery(name="it.sella.address.implementation.addr.findByAddressCapProvinciaValue", query="SELECT o FROM AddressBean o WHERE o.provincia= :provincia AND o.citta= :citta AND o.capValue= :capValue AND o.nazione= :nazione AND o.indirizzo= :indirizzo"),
	@NamedQuery(name="it.sella.address.implementation.addr.findByAddressProvincia", query="SELECT o FROM AddressBean o WHERE o.provincia= :provincia AND o.citta= :citta AND o.capValue is null AND o.nazione= :nazione AND o.indirizzo= :indirizzo"),
	@NamedQuery(name="it.sella.address.implementation.addr.findByAddress", query="SELECT o FROM AddressBean o WHERE o.provincia is null AND o.citta= :citta AND o.capValue is null AND o.nazione= :nazione AND o.indirizzo= :indirizzo "),
	@NamedQuery(name="it.sella.address.implementation.addr.findByAddressByPresso", query="SELECT o FROM AddressBean o WHERE o.provincia= :provincia AND o.citta= :citta AND o.capValue= :capValue AND o.nazione= :nazione AND o.indirizzo= :indirizzo and o.presso= :presso"),
	@NamedQuery(name="it.sella.address.implementation.addr.findByAddressByEdificio", query="SELECT o FROM AddressBean o WHERE o.provincia= :provincia AND o.citta= :citta AND o.capValue= :capValue AND o.nazione= :nazione AND o.indirizzo= :indirizzo and o.edificio= :edificio "),
	@NamedQuery(name="it.sella.address.implementation.addr.findByAddressPressoAndEdificio", query="SELECT o FROM AddressBean o WHERE o.provincia= :provincia AND o.citta= :citta AND o.capId= :capId AND o.nazione= :nazione AND o.indirizzo= :indirizzo and o.presso= :presso  and o.edificio= :edificio ")
})
public class AddressBean implements Address	{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="addressNewSequenceGenerator")
	@Column(name="AD_ADDRESS_ID")
	private Long id;

	@Column(name="AD_PROVINCIA")
	private String provincia;

	@Column(name="AD_CAP_VALUE")
	private String capValue;

	@Column(name="AD_CAP")
	private Long capId;

	@Column(name="AD_NAZIONE")
	private Long nazione;

	@Column(name="AD_CITTA")
	private String citta;

	@Column(name="AD_INDIRIZZO")
	private String indirizzo;

	@Column(name="AD_OP_ID")
	private Long opId;

	@Column(name="AD_NORM_STATUS")
	private String normStatus;

	@Column(name="AD_CITTA_NOME")
	private String cittaName;

	@Column(name="AD_NAZIONE_NOME")
	private String nazioneName;

	@Column(name="AD_PROVINCA_SIGLA")
	private String provinciaSigla;

	@Column(name="AD_PROVINCA_NOME")
	private String provinciaName;

	@Column(name="AD_PRESSO")
	private String presso;

	@Column(name="AD_EDIFICIO")
	private String edificio;


	public Long getId() {
		return id;
	}
	public void setId(final Long id) {
		this.id = id;
	}
	public String getProvincia() {
		return provincia;
	}
	public void setProvincia(final String provincia) {
		this.provincia = provincia;
	}
	public String getCapValue() {
		return capValue;
	}
	public void setCapValue(final String capValue) {
		this.capValue = capValue;
	}
	public Long getCapId() {
		return capId;
	}
	public void setCapId(final Long capId) {
		this.capId = capId;
	}
	public Long getNazione() {
		return nazione;
	}
	public void setNazione(final Long nazione) {
		this.nazione = nazione;
	}
	public String getCitta() {
		return citta;
	}
	public void setCitta(final String citta) {
		this.citta = citta;
	}
	public String getIndirizzo() {
		return indirizzo;
	}
	public void setIndirizzo(final String indirizzo) {
		this.indirizzo = indirizzo;
	}
	public Long getOpId() {
		return opId;
	}
	public void setOpId(final Long opId) {
		this.opId = opId;
	}
	public String getNormStatus() {
		return normStatus;
	}
	public void setNormStatus(final String normStatus) {
		this.normStatus = normStatus;
	}
	/**
	 * @return the cittaName
	 */
	public String getCittaName() {
		return cittaName;
	}
	/**
	 * @param cittaName the cittaName to set
	 */
	public void setCittaName(String cittaName) {
		this.cittaName = cittaName;
	}
	/**
	 * @return the nazioneName
	 */
	public String getNazioneName() {
		return nazioneName;
	}
	/**
	 * @param nazioneName the nazioneName to set
	 */
	public void setNazioneName(String nazioneName) {
		this.nazioneName = nazioneName;
	}
	/**
	 * @return the provinciaSigla
	 */
	public String getProvinciaSigla() {
		return provinciaSigla;
	}
	/**
	 * @param provinciaSigla the provinciaSigla to set
	 */
	public void setProvinciaSigla(String provinciaSigla) {
		this.provinciaSigla = provinciaSigla;
	}
	/**
	 * @return the provinciaName
	 */
	public String getProvinciaName() {
		return provinciaName;
	}
	/**
	 * @param provinciaName the provinciaName to set
	 */
	public void setProvinciaName(String provinciaName) {
		this.provinciaName = provinciaName;
	}
	/**
	 * @return the presso
	 */
	public String getPresso() {
		return presso;
	}
	/**
	 * @param presso the presso to set
	 */
	public void setPresso(String presso) {
		this.presso = presso;
	}
	/**
	 * @return the edificio
	 */
	public String getEdificio() {
		return edificio;
	}
	/**
	 * @param edificio the edificio to set
	 */
	public void setEdificio(String edificio) {
		this.edificio = edificio;
	}


}
