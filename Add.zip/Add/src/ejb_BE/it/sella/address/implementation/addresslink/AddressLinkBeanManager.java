package it.sella.address.implementation.addresslink;

import it.sella.address.AddressException;
import it.sella.address.implementation.factory.AddressEntityManagerFactory;
import it.sella.address.implementation.factory.BeanUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Collection;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

public class AddressLinkBeanManager implements IAddressLinkBeanManager {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressLinkBeanManager.class);
	private static final String SOGGETTO_ID = "soggettoId";
	private static final String ADDRESSID = "addressId";
	private static final String SUBSYSTEM = "subSystem";
	private static final String LINKEDID = "linkedId";
	private static final String ADDRESSTYPE = "addressType";

	private final EntityManager entityManager;

	public AddressLinkBeanManager(){
		entityManager = AddressEntityManagerFactory.getInstance().getEntityManager();
	}


	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addresslink.IAddressLinkBeanManager#create(it.sella.address.implementation.addresslink.AddressLink)
	 */
	public AddressLink create(final AddressLink addressLink) throws AddressException {
		final AddressLinkBean addressLinkBean = new AddressLinkBean();
		BeanUtil.copyProperties(addressLinkBean, addressLink);
		entityManager.persist(addressLinkBean);
		entityManager.flush();
		BeanUtil.copyProperties(addressLink,addressLinkBean);
		return addressLink;
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addresslink.IAddressLinkBeanManager#update(it.sella.address.implementation.addresslink.AddressLink)
	 */
	public AddressLink update(final AddressLink addressLink) throws AddressException {
		entityManager.persist(addressLink);
		return addressLink;
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addresslink.IAddressLinkBeanManager#remove(it.sella.address.implementation.addresslink.AddressLink)
	 */
	public void remove(final AddressLink addressLink) {
		entityManager.remove(addressLink);

	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addresslink.IAddressLinkBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public AddressLink findByPrimaryKey(final Long primaryKey) throws FinderException {
		if(primaryKey == null){
			throw new FinderException("PrimaryKey is null");
		}
		final AddressLink addressLink= entityManager.find(AddressLinkBean.class, primaryKey);
		if(addressLink == null){
			throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return addressLink;
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addresslink.IAddressLinkBeanManager#findBySoggettoIndirizzo(java.lang.Long, java.lang.Long)
	 */
	public Collection<AddressLink> findBySoggettoIndirizzo(final Long soggettoId, final Long addressId)	throws FinderException {
		try{
			final Query findBySoggettoIndirizzo = entityManager.createNamedQuery("AddressLinkBean.findBySoggettoIndirizzo");
			findBySoggettoIndirizzo.setParameter(SOGGETTO_ID, soggettoId);
			findBySoggettoIndirizzo.setParameter(ADDRESSID, addressId);
			return findBySoggettoIndirizzo.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addresslink.IAddressLinkBeanManager#findBySoggettoSubsytemPCId(java.lang.Long, java.lang.Long, java.lang.Long)
	 */
	public AddressLink findBySoggettoSubsytemPCId(final Long soggettoId,final Long subSystemId, final Long pcId) throws FinderException {
		try{
			final String namedQuery = "AddressLinkBean.findBySoggettoSubsytemPCId";
			final Query findBySoggettoSubsytemPCId = buildFindBySoggettoSubsytemPCId(
					soggettoId, subSystemId, pcId, namedQuery);
			return (AddressLink)findBySoggettoSubsytemPCId.getSingleResult();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		} catch (final NonUniqueResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException("EJB:013073 too_many_results_for_get_single_result");
		}
	}



	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addresslink.IAddressLinkBeanManager#findBySoggettoSubsytemTipoIndirizzo(java.lang.Long, java.lang.Long, java.lang.Long)
	 */
	public AddressLink findBySoggettoSubsytemTipoIndirizzo(final Long soggettoId,final Long subSystemId, final Long tipoIndirizzo) throws FinderException {
		try{
			final String namedQuery = "AddressLinkBean.findBySoggettoSubsytemTipoIndirizzo";
			final Query findBySoggettoSubsytemTipoIndirizzo = buildFindAllBySoggettoSubsytemTipoIndirizzo(
					soggettoId, subSystemId, tipoIndirizzo, namedQuery);
			return (AddressLink)findBySoggettoSubsytemTipoIndirizzo.getSingleResult();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		} catch (final NonUniqueResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException("EJB:013073 too_many_results_for_get_single_result");
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addresslink.IAddressLinkBeanManager#findAllProductContoId(java.lang.Long)
	 */
	public Collection<AddressLink> findAllProductContoId(final Long soggettoId) throws FinderException {
		try{
			final Query findAllProductContoId = entityManager.createNamedQuery("AddressLinkBean.findAllProductContoId");
			findAllProductContoId.setParameter(SOGGETTO_ID, soggettoId);
			return findAllProductContoId.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addresslink.IAddressLinkBeanManager#findByAddressPkId(java.lang.Long)
	 */
	public Collection<AddressLink> findByAddressPkId(final Long addressPkId) throws FinderException {
		try{
			final Query findByAddressPkId = entityManager.createNamedQuery("AddressLinkBean.findByAddressPkId");
			findByAddressPkId.setParameter(ADDRESSID, addressPkId);
			return findByAddressPkId.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addresslink.IAddressLinkBeanManager#findBySoggettoId(java.lang.Long)
	 */
	public Collection<AddressLink> findBySoggettoId(final Long soggettoId) throws FinderException {
		try{
			final Query findByAddressPkId = entityManager.createNamedQuery("AddressLinkBean.findBySoggettoId");
			findByAddressPkId.setParameter(SOGGETTO_ID, soggettoId);
			return findByAddressPkId.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addresslink.IAddressLinkBeanManager#findAllBySoggettoSubsytemPCId(java.lang.Long, java.lang.Long, java.lang.Long)
	 */
	public Collection<AddressLink> findAllBySoggettoSubsytemPCId(final Long soggettoId,final Long subSystemId, final Long pcId) throws FinderException {
		try{

			final String namedQuery = "AddressLinkBean.findAllBySoggettoSubsytemPCId";
			final Query findAllBySoggettoSubsytemPCId = buildFindBySoggettoSubsytemPCId(
					soggettoId, subSystemId, pcId, namedQuery);
			return findAllBySoggettoSubsytemPCId.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.address.implementation.addresslink.IAddressLinkBeanManager#findAllBySoggettoSubsytemTipoIndirizzo(java.lang.Long, java.lang.Long, java.lang.Long)
	 */
	public Collection<AddressLink> findAllBySoggettoSubsytemTipoIndirizzo(final Long soggettoId,final Long subSystemId, final Long tipoIndirizzo) throws FinderException {
		try{
			final String namedQuery = "AddressLinkBean.findAllBySoggettoSubsytemTipoIndirizzo";
			final Query findAllBySoggettoSubsytemTipoIndirizzo = buildFindAllBySoggettoSubsytemTipoIndirizzo(
					soggettoId, subSystemId, tipoIndirizzo, namedQuery);
			return findAllBySoggettoSubsytemTipoIndirizzo.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}


	/**
	 * Query Builder for findBySoggettoSubsytemPCId
	 * @param soggettoId
	 * @param subSystemId
	 * @param pcId
	 * @param namedQuery
	 * @return
	 */
	private Query buildFindBySoggettoSubsytemPCId(final Long soggettoId,
			final Long subSystemId, final Long pcId, final String namedQuery) {
		final Query findBySoggettoSubsytemPCId = entityManager.createNamedQuery(namedQuery);
		findBySoggettoSubsytemPCId.setParameter(SOGGETTO_ID, soggettoId);
		findBySoggettoSubsytemPCId.setParameter(SUBSYSTEM, subSystemId);
		findBySoggettoSubsytemPCId.setParameter(LINKEDID, pcId);
		return findBySoggettoSubsytemPCId;
	}



	/**
	 * Query Builder for findAllBySoggettoSubsytemTipoIndirizzo
	 * @param soggettoId
	 * @param subSystemId
	 * @param tipoIndirizzo
	 * @param namedQuery
	 * @return
	 */
	private Query buildFindAllBySoggettoSubsytemTipoIndirizzo(final Long soggettoId,
			final Long subSystemId, final Long tipoIndirizzo, final String namedQuery) {
		final Query findAllBySoggettoSubsytemTipoIndirizzo = entityManager.createNamedQuery(namedQuery);
		findAllBySoggettoSubsytemTipoIndirizzo.setParameter(SOGGETTO_ID, soggettoId);
		findAllBySoggettoSubsytemTipoIndirizzo.setParameter(SUBSYSTEM, subSystemId);
		findAllBySoggettoSubsytemTipoIndirizzo.setParameter(ADDRESSTYPE, tipoIndirizzo);
		return findAllBySoggettoSubsytemTipoIndirizzo;
	}

}
