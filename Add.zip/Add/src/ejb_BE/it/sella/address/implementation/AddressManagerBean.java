
package it.sella.address.implementation;

import it.sella.acfw.GestoreContiFactory;
import it.sella.acfw.ISoggettoCollegatoAConto;
import it.sella.acfw.exception.GestoreContiException;
import it.sella.address.AddressException;
import it.sella.address.AddressManagerBeanHelperException;
import it.sella.address.AddressManagerMapperException;
import it.sella.address.AddressManagerValidatorException;
import it.sella.address.AddressView;
import it.sella.address.SubSystemHandlerException;
import it.sella.address.egon.common.AddressBeanUtil;
import it.sella.address.egon.common.EgonAddressBeanConstant;
import it.sella.address.egon.common.EgonUtil;
import it.sella.address.egon.delegator.EgonCapDAODelegator;
import it.sella.address.egon.delegator.EgonCittaDAODelegator;
import it.sella.address.egon.delegator.EgonIndirizziDAODelegator;
import it.sella.address.egon.delegator.EgonNazioneDAODelegator;
import it.sella.address.egon.delegator.EgonProvinciaDAODelegator;
import it.sella.address.egon.view.EgonView;
import it.sella.address.implementation.dbhelper.AddressAEHelper;
import it.sella.address.implementation.dbhelper.AddressAESetterHelper;
import it.sella.address.implementation.dbhelper.AddressBaseHelper;
import it.sella.address.implementation.dbhelper.AddressCreateHelper;
import it.sella.address.implementation.dbhelper.AddressExternalHandler;
import it.sella.address.implementation.dbhelper.AddressGetterHelper;
import it.sella.address.implementation.dbhelper.AddressListHelper;
import it.sella.address.implementation.dbhelper.AddressLogHelper;
import it.sella.address.implementation.dbhelper.AddressPostalFormatHelper;
import it.sella.address.implementation.dbhelper.AddressSetterHelper;
import it.sella.address.implementation.dbhelper.AddressUpdateHelper;
import it.sella.address.implementation.parser.AddressParser;
import it.sella.address.implementation.util.ClassificazioneHandler;
import it.sella.address.implementation.util.Helper;
import it.sella.address.implementation.util.MapperHelper;
import it.sella.address.implementation.util.MapperHelperException;
import it.sella.address.implementation.util.NormalizedIndirrizoHelper;
import it.sella.address.implementation.util.UtilHelper;
import it.sella.classificazione.ClassificazioneView;
import it.sella.ejb.SessionBeanAdapter;
import it.sella.logserver.LoggerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.IOException;
import java.io.StringReader;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.List;
import java.util.StringTokenizer;

import javax.ejb.CreateException;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

public class AddressManagerBean extends SessionBeanAdapter {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressManagerBean.class);

	public void createAddress(final AddressView addressView) throws AddressException, RemoteException {
		try {
			new AddressCreateHelper().createAddress(getValidatedAddress(addressView));
		} catch (final AddressManagerValidatorException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new AddressException(e.getMessage());
		} catch (final AddressManagerMapperException e) {
			//The transaction will not be RolledBack , if Mapper Exception is raised.
			log4Debug.warnStackTrace(e);
		}
	}

	public void setAddress( final boolean modifyAllProductConto, final AddressView addressView) throws AddressException, RemoteException{
		try {
			new AddressSetterHelper().setAddress(modifyAllProductConto,getValidatedAddress(addressView));
		} catch (final AddressManagerValidatorException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new AddressException(e.getMessage());
		} catch (final AddressManagerMapperException e) {
			//The transaction will not be RolledBack , if Mapper Exception is raised.
			log4Debug.warnStackTrace(e);
		}
	}

	public void modificaInternal(final Collection addressViews) throws AddressException, RemoteException {
		try {
			new AddressAEHelper().modificaInternal(addressViews);
		} catch (final AddressManagerBeanHelperException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new AddressException(e.getMessage());
		}
	}

	public AddressView getAddress(final Long soggettoId, final String subSystemCausale, final Long productContoId) throws AddressException, RemoteException {
		try {
			return new AddressGetterHelper().getAddress(soggettoId,subSystemCausale, productContoId);
		} catch (final AddressManagerBeanHelperException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		}
	}

	public Collection listAddressSoggetto(final Long soggettoId) throws AddressException, RemoteException {
		try {
			return new AddressListHelper().listAddressSoggetto(soggettoId);
		} catch (final AddressManagerBeanHelperException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		}
	}

	public AddressView getDefaultPostalAddress(final Long soggettoId) throws AddressException, RemoteException {
		try {
			return new AddressGetterHelper().getDefaultPostalAddress(soggettoId);
		} catch (final AddressManagerBeanHelperException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		}
	}

	public Collection listAddress(final Long soggettoId, final String subSystemCl) throws AddressException, RemoteException {
		try {
			return new AddressListHelper().listAddress(soggettoId, subSystemCl);
		} catch (final AddressManagerBeanHelperException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		}
	}

	public AddressView validateAddress(final String xmlAddress)throws AddressException, RemoteException {
		return validateAddressDetails(xmlAddress, false);
	}

	private AddressView validateAddressDetails(final String xmlAddress,final boolean checkForNull) throws AddressException {
		try {
			final AddressParser addressParser = new AddressParser();
			final XMLReader xmlReader = XMLReaderFactory.createXMLReader();
			xmlReader.setContentHandler(addressParser);
			xmlReader.parse(new InputSource(new StringReader(xmlAddress)));
			final AddressView addressView = addressParser.getAddressView();
			log4Debug.warn("################### addressview in validateAddressDetails:",addressView);
			log4Debug.warn("################### addressParser.getErrorMessage():",addressParser.getErrorMessage());
			if (checkForNull && addressView == null) {
				throw new AddressException(addressParser.getErrorMessage());
			}
			return addressView;
		} catch (final SAXException e) {
			log4Debug.severeStackTrace(e);
			throw new AddressException(e.getMessage());
		} catch (final IOException e) {
			log4Debug.severeStackTrace(e);
			throw new AddressException(e.getMessage());
		}
	}

	public boolean isCompatibleIndirizzo(final String subSystemCl,final String tipoIndirizzocl) throws AddressException, RemoteException {
		try {
			return new AddressBaseHelper().isCompatibleIndirizzo(subSystemCl, tipoIndirizzocl);
		} catch (final AddressManagerBeanHelperException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		}
	}

	public void updateSoggetto(final Long oldSoggettoId, final Long newSoggettoId) throws AddressException, RemoteException {
		new AddressUpdateHelper().updateSoggetto(oldSoggettoId, newSoggettoId, null);
	}

	public void updateSoggetto(final Long oldSoggettoId, final Long newSoggettoId, final Long opId) throws AddressException, RemoteException {
		new AddressUpdateHelper().updateSoggetto(oldSoggettoId, newSoggettoId, opId);
	}

	public void removeUnusedAddress() throws AddressException, RemoteException {
		new AddressUpdateHelper().removeUnusedAddress();
	}

	public String getPostalAddress(final Long soggettoId, final Long productId, final String subSystemCausale) throws AddressException, RemoteException {
		return new AddressPostalFormatHelper().getPostalAddress(soggettoId, productId, subSystemCausale, null, null);
	}

	public String getPostalAddressInXMLFormat(final Long soggettoId, final Long productId, final String subSystemCausale) throws AddressException, RemoteException {
		return new AddressPostalFormatHelper().getPostalAddressInXMLFormat( soggettoId, productId,
				subSystemCausale, null, null);
	}

	public Integer getEsercentiPresenti(final Long soggettoId) throws AddressException, RemoteException {
		return new AddressExternalHandler().getEsercentiPresenti(soggettoId);
	}

	public String getProductValues(final Long soggettoId) throws AddressException, RemoteException {
		return new AddressExternalHandler().getProductValues(soggettoId);
	}

	public String getPostalAddress(final Long soggettoId, final Long productId, final String subSystemCausale, final String intestazione, final Long errorCode)
			throws AddressException, RemoteException {
		return new AddressPostalFormatHelper().getPostalAddress(soggettoId, productId,
				subSystemCausale, intestazione, errorCode, null, null);
	}

	public String getPostalAddressInXMLFormat(final Long soggettoId, final Long productId,
			final String subSystemCausale, final String intestazione, final Long errorCode ) throws AddressException, RemoteException {
		return new AddressPostalFormatHelper().getPostalAddressInXMLFormat( soggettoId, productId,
				subSystemCausale, intestazione, errorCode, null, null);
	}

    public String getPostalAddressInXMLFormat(final Long soggettoId, final Long productId,
    		final String subSystemCausale, final String bypassCode) throws AddressException, RemoteException {
    	return new AddressPostalFormatHelper().getPostalAddressInXMLFormat(soggettoId, productId,
    			subSystemCausale, bypassCode, null);
    }


    public String getPostalAddress(final Long soggettoId, final Long productId,
    		final String subSystemCausale, final String intestazione,
    		final Long errorCode,final String bypassCode) throws AddressException, RemoteException {
    	return new AddressPostalFormatHelper().getPostalAddress(soggettoId, productId,
    			subSystemCausale, intestazione, errorCode, bypassCode, null);
    }

    public String getPostalAddressInXMLFormat(final Long soggettoId, final Long productId,
    		final String subSystemCausale, final String intestazione,
    		final Long errorCode, final String bypassCode) throws AddressException, RemoteException {
    	return new AddressPostalFormatHelper().getPostalAddressInXMLFormat(soggettoId, productId, subSystemCausale,
    			intestazione, errorCode, bypassCode, null);
    }

    /* public String getPostalAddressInXMLFormat(final Long soggettoId, final Long productId,
    		final String subSystemCausale, final String intestazione,
    		final Long errorCode, final String bypassCode,final String skipDomolCheck) throws AddressException, RemoteException {
    	return new AddressPostalFormatHelper().getPostalAddressInXMLFormat(soggettoId, productId, subSystemCausale,
    			intestazione, errorCode, bypassCode, skipDomolCheck);
    }
    public String getPostalAddress(final Long soggettoId, final Long productId,
    		final String subSystemCausale, final String intestazione,
    		final Long errorCode, final String bypassCode,final String skipDomolCheck) throws AddressException, RemoteException {
    	return new AddressPostalFormatHelper().getPostalAddress(soggettoId, productId, subSystemCausale,
    			intestazione, errorCode, bypassCode, skipDomolCheck);
    }*/

	public void gestoreAccountAddress( final String tredeciCifre, final String valore, final String hostUserCode ) throws AddressException, RemoteException {
		Long opId = null;
		String logForHost = null;
		String errorMessage = null;
		Long soggettoId = null;
		final AddressLogHelper addressLogHelper = new AddressLogHelper();
		try {
			if ( valore.length() < 168 ) {
				final String errorMsg = "Invalid Valore !!";
				throw new AddressException(errorMsg);
			}
			final String indirrizzi = valore.substring(0, 35).trim().toUpperCase();
			final String citta = valore.substring(35, 75).trim().toUpperCase();
			final String cap = valore.substring(75, 80).trim();
			final String provincia = valore.substring(80, 82).trim().toUpperCase();
			final String nazione = valore.substring(82, 132).trim().toUpperCase();
			final String causaleSubsys = valore.substring(132, 142).trim().toUpperCase();
			final String tipoIndirizzo = valore.substring(142, 146).trim().toUpperCase();
			final String otherSubsysContoId = valore.substring(146, 161).trim();
			final String internalCausale = valore.substring(161, 166).trim().toUpperCase();
			final boolean isToAlignH2o = !valore.endsWith("_T") ? true : false;
			final boolean isToAlignHost = !valore.endsWith("_H") ? true : false;

			log4Debug.debug(" AddressManagerBean: gestoreAccountAddress: indirrizzi :===>>> ",indirrizzi);
			log4Debug.debug(" AddressManagerBean: gestoreAccountAddress: citta :===>>> ",citta);
			log4Debug.debug(" AddressManagerBean: gestoreAccountAddress: cap :===>>> ",cap);
			log4Debug.debug(" AddressManagerBean: gestoreAccountAddress: provincia :===>>> ",provincia);
			log4Debug.debug(" AddressManagerBean: gestoreAccountAddress: nazione :===>>> ",nazione);
			log4Debug.debug(" AddressManagerBean: gestoreAccountAddress: causaleSubsys :===>>> ",causaleSubsys);
			log4Debug.debug(" AddressManagerBean: gestoreAccountAddress: tipoIndirizzo :===>>> ",tipoIndirizzo);
			log4Debug.debug(" AddressManagerBean: gestoreAccountAddress: otherSubsysContoId :===>>> ",otherSubsysContoId);
			log4Debug.debug(" AddressManagerBean: gestoreAccountAddress: internalCausale :===>>> ",internalCausale);
			log4Debug.debug(" AddressManagerBean: gestoreAccountAddress: isToAlignH2o :===>>> ",isToAlignH2o);
			log4Debug.debug(" AddressManagerBean: gestoreAccountAddress: isToAlignHost :===>>> ",isToAlignHost);

			final StringBuffer xmlBuilder = new StringBuffer("<INDIRIZZO>");
			xmlBuilder.append(UtilHelper.getTag("TIPO_INDIRIZZO", tipoIndirizzo));
			xmlBuilder.append(UtilHelper.getTagWithEscapeXML("INDIRIZZO",indirrizzi));
			xmlBuilder.append(UtilHelper.getTag("PROVINCIA",provincia));
			xmlBuilder.append(UtilHelper.getTag("CAP",cap));
			xmlBuilder.append(UtilHelper.getTagWithEscapeXML("CITTA",citta));
			xmlBuilder.append(UtilHelper.getTag("NAZIONE",nazione));
			xmlBuilder.append("</INDIRIZZO>");

			final AddressView addressView = validateAddressDetails(xmlBuilder.toString(), true);
			if ( isToAlignH2o ) {
				if ( "ACFW".equals(causaleSubsys) ) {
					final Long contoId = GestoreContiFactory.getInstance().getGestoreConti().getConto(tredeciCifre);
					if ( contoId == null ) {
						final String errorMsg = "ContoId Not exists for given 13cifre !!";
						throw new AddressException(errorMsg);
					}
					final Collection soggettoCollection = GestoreContiFactory.getInstance().getGestoreConti().getSoggettiCollegatiAConto(contoId, "MIT", null);
					if ( soggettoCollection != null && !soggettoCollection.isEmpty() ) {
						soggettoId = ((ISoggettoCollegatoAConto) soggettoCollection.iterator().next()).getSoggettoCollegatoId();
					}
					if ( soggettoId == null ) {
						final String errorMsg = "SoggettoId Not exists for given 13cifre !!";
						throw new AddressException(errorMsg);
					}
					setAddressAEDetails(addressView, indirrizzi, contoId, internalCausale);
				} else {
					soggettoId = Long.valueOf(tredeciCifre.trim());
					if (!"ANAG".equals(causaleSubsys)) {
						Long subsysContoId = null;
						try {
							subsysContoId = Long.valueOf(otherSubsysContoId);
						} catch (final NumberFormatException e) {
							final String errorMsg = "Subsystem productId not valid";
							throw new AddressException(errorMsg);
						}
						setAddressAEDetails(addressView, indirrizzi, subsysContoId, internalCausale);
					}
				}
				addressView.setSoggettoId(soggettoId);
				addressView.setCausaleSubsystem(causaleSubsys);
				opId = addressLogHelper.logAddressOperation( "ADDR-GES-ADD-BIBO", addressView, null, false);
				addressView.setOpId(opId);
				setAddress(false, addressView);
			}
			if ("ACFW".equals(causaleSubsys) && isToAlignHost) {
				addressView.setNch(tredeciCifre);
				logForHost = new MapperHelper().aggiornaIndirizzo(addressView, hostUserCode.trim());
			}
		} catch (final LoggerException e) {
			this.getSessionContext().setRollbackOnly();
			log4Debug.warnStackTrace(e);
			errorMessage = e.getMessage();
			updateErrorMessage(opId, soggettoId, errorMessage);
			throw new AddressException(e);
		} catch (final MapperHelperException e) {
			this.getSessionContext().setRollbackOnly();
			log4Debug.warnStackTrace(e);
			final StringTokenizer tokenizer = new StringTokenizer(e.getMessage(), "�");
			errorMessage = tokenizer.nextToken();
			if (tokenizer.hasMoreTokens()) {
				logForHost = tokenizer.nextToken();
			}
			updateErrorMessage(opId, soggettoId, errorMessage);
			throw new AddressException(e);
		} catch (final GestoreContiException e) {
			this.getSessionContext().setRollbackOnly();
			log4Debug.warnStackTrace(e);
			errorMessage = e.getMessage();
			updateErrorMessage(opId, soggettoId, errorMessage);
			throw new AddressException(e);
		} catch (final SubSystemHandlerException e) {
			this.getSessionContext().setRollbackOnly();
			log4Debug.warnStackTrace(e);
			errorMessage = e.getMessage();
			updateErrorMessage(opId, soggettoId, errorMessage);
			throw new AddressException(e);
		} finally {
			try {
				if ( opId != null ) {
					addressLogHelper.logAddressOpDetails(opId, logForHost, errorMessage);
				}
			} catch (final LoggerException e) {
				log4Debug.warn("This exception is just caught not to affect the parent transaction !!!!!");
				log4Debug.warnStackTrace(e);
			}
		}
	}

	private void updateErrorMessage(final Long opId, final Long soggettoId, final String errorMessage) throws RemoteException, AddressException {
		try {
			new AddressLogHelper().updateAddressLog(opId, soggettoId, errorMessage);
		} catch (final LoggerException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		}
	}

	private AddressView getValidatedAddress(final AddressView addressView) throws AddressException, RemoteException {
		//Added after EGON Migration
        final String presso = EgonUtil.getStringValue(addressView.getPresso());
        final String edificio = EgonUtil.getStringValue(addressView.getEdificio());

		final AddressView validatedAddressView = validateAddressDetails(addressView.getCausaleTipoIndirizzo(),
						addressView.getNazioneView() != null ? addressView.getNazioneView().getNome()
								: addressView.getNazione() != null ? addressView.getNazione().trim() : "",
						addressView.getCittaView() != null ? addressView.getCittaView().getCommune()
								: addressView.getCitta() != null ? addressView.getCitta().trim() : "",
						addressView.getIndirizzo() != null ? addressView.getIndirizzo().trim() : "",
				        addressView.getProvinciaView() != null ? addressView.getProvinciaView().getSigla()
				        		: addressView.getProvincia() != null ? addressView.getProvincia().trim() : "",
				        addressView.getCapView() != null ? addressView.getCapView().getCap()
				        		: addressView.getCap() != null ? addressView.getCap().trim() : "",
				        				presso,edificio);
		validatedAddressView.setDescrizioneTipoIndirizzo(addressView.getDescrizioneTipoIndirizzo());
		validatedAddressView.setCausaleSubsystem(addressView.getCausaleSubsystem());
		validatedAddressView.setDescrizioneSubsystem(addressView.getDescrizioneSubsystem());
		validatedAddressView.setProductContoId(addressView.getProductContoId());
		validatedAddressView.setSoggettoId(addressView.getSoggettoId());
		validatedAddressView.setNch(addressView.getNch());
		validatedAddressView.setPostalCode(addressView.getPostalCode());
		validatedAddressView.setOpId(addressView.getOpId());
		 //Added after EGON Migration
		validatedAddressView.setPresso(presso);
		validatedAddressView.setEdificio(edificio);
		if("ANAG-SOA-NORM-OK".equals(addressView.getNormStatus())){
			validatedAddressView.setNormStatus("OK");
		}
		try {
			if ( addressView.getInternal() != null ) {
				validatedAddressView.setInternal(addressView.getInternal());
			} else {
				validatedAddressView.setInternal(Helper.validateInternalValue(validatedAddressView.getIndirizzo()));
			}
			return validatedAddressView;
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		}
	}

	public NormalizedAddressStatus normalizeIndirrizo( final String nazione, final String cittaCommune, final String indirrizzo, final String provincia,
			final String cap, final Boolean isDOMXXCheckReq ,final String edificio,final String presso) throws AddressException, RemoteException {
		validateAddressDetails("IPO", nazione, cittaCommune, indirrizzo,provincia, cap,edificio,presso);
		return new NormalizedIndirrizoHelper().getNormallizaNew(nazione,cittaCommune, indirrizzo, provincia, cap, isDOMXXCheckReq,edificio,presso);
	}

	public NormalizedAddressStatus normalizeIndirrizo( final String nazione, final String cittaCommune, final String indirrizzo, final String provincia,
			final String cap, final Boolean isDOMXXCheckReq ) throws AddressException, RemoteException {
		validateAddressDetails("IPO", nazione, cittaCommune, indirrizzo,provincia, cap,null,null);
		return new NormalizedIndirrizoHelper().getNormallizaNew(nazione,cittaCommune, indirrizzo, provincia, cap, isDOMXXCheckReq,null,null);
	}

	public void setDOMOL(final Long soggettoId, final Long productId, final String subSystemCausale) throws AddressException, RemoteException {
		try {
			new AddressAESetterHelper().setDOMOL(soggettoId, productId, subSystemCausale);
		} catch (final AddressManagerBeanHelperException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		} catch (final CreateException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		}
	}

	public void removeDOMOL(final Long soggettoId, final Long productId, final String subSystemCausale) throws AddressException, RemoteException {
		new AddressAESetterHelper().removeDOMOL(soggettoId, productId, subSystemCausale);
	}

	public void removeProductAddress(final Long soggettoId, final String subSystemCausale, final Long productId) throws AddressException, RemoteException {
		new AddressUpdateHelper().removeProductAddress(soggettoId, subSystemCausale, productId);
	}

	public List getAddressAlreadyUsed(final String indirizzio, final String cap, final String cittaCommune, final String provinciaSingla,
			final String nazione, final String tipoIndirrizoCausale, final Long bankSoggettId ) throws AddressException, RemoteException {
		try {
			return new AddressGetterHelper().getAddressAlreadyUsed(indirizzio, cap, cittaCommune, provinciaSingla, nazione, tipoIndirrizoCausale, bankSoggettId);
		} catch (final AddressManagerBeanHelperException e) {
			log4Debug.severeStackTrace(e);
			throw new AddressException(e.getMessage());
		}
	}

	public void swapProductAddressPerSoggetto(final Long oldSoggettoId, final Long newSoggettoId,final String subSystemCausale,final Long productId) throws AddressException, RemoteException{
		new AddressUpdateHelper().swapProductAddressPerSoggetto(oldSoggettoId, newSoggettoId, subSystemCausale ,productId);
	}

	private AddressView validateAddressDetails( final String tipoIndirizzo, final String nazione, final String cittaCommune, final String indirrizzo,
			final String provincia, final String cap ,final String presso,final String edificio) throws AddressException {

		final StringBuffer addressXML = new StringBuffer("<INDIRIZZO>");
		addressXML.append(UtilHelper.getTagWithValueCheck("TIPO_INDIRIZZO", tipoIndirizzo));
		addressXML.append(UtilHelper.getTagWithValueCheckWithEscapeXML("INDIRIZZO", indirrizzo));
		addressXML.append(UtilHelper.getTagWithValueCheck("PROVINCIA", provincia));
		addressXML.append(UtilHelper.getTagWithValueCheck("CAP", cap));
		addressXML.append(UtilHelper.getTagWithValueCheckWithEscapeXML("CITTA", cittaCommune));
		addressXML.append(UtilHelper.getTagWithValueCheck("NAZIONE", nazione));
		//Added after EGON Migration
		addressXML.append(UtilHelper.getTagWithValueCheck("PRESSO", presso));
		addressXML.append(UtilHelper.getTagWithValueCheck("EDIFICIO", edificio));
		addressXML.append("</INDIRIZZO>");
		log4Debug.info("################## built address string :", addressXML);
		return validateAddressDetails(addressXML.toString(), true);
	}

	private void setAddressAEDetails( final AddressView addressView, final String indirrizzi, final Long contoId, final String internalCausale ) throws AddressException,
			SubSystemHandlerException, RemoteException {
		ClassificazioneView classificazioneView = null;
		if ( internalCausale.length() == 0  ) {
			classificazioneView = ClassificazioneHandler.getClassificazioneView(Helper.getInternalBasedOnIndirizzo(indirrizzi), "AEADD");
		} else {
			classificazioneView = ClassificazioneHandler.getClassificazioneView(internalCausale, "AEADD");
		}
		addressView.setInternal(classificazioneView != null ? classificazioneView.getId() : null);
		log4Debug.debug(" AddressManagerBean: setAddressAEDetails: getInternal :===>>>",addressView.getInternal());
		addressView.setFrequency(ClassificazioneHandler.getClassificazioneView("GIORN", "AN_FREQ").getId());
		addressView.setReserved(0L);
		addressView.setProductContoId(contoId);
	}

	public AddressView validateAddressWithThrowError(final String xmlAddress)throws AddressException, RemoteException {
		return validateAddressDetails(xmlAddress, true);
	}

	public Collection<EgonView> getProvincia(final String cap,final String nazione,final String provincia) throws AddressException,RemoteException {
		final EgonProvinciaDAODelegator provinciaDelegator=(EgonProvinciaDAODelegator) AddressBeanUtil.getInstance().getBean(EgonAddressBeanConstant.EGON_PROVINCIA_DAO_DELEGATOR.getBeanId());
		return provinciaDelegator.getProvincia(cap,nazione,provincia);
	}

	public Collection<EgonView> getCitta(final String cap,final String citta,final String nazione,final String provincia) throws AddressException,RemoteException {
		final EgonCittaDAODelegator cittaDelegator=(EgonCittaDAODelegator) AddressBeanUtil.getInstance().getBean(EgonAddressBeanConstant.EGON_CITTA_DAO_DELEGATOR.getBeanId());
		return cittaDelegator.getCitta(cap, citta, nazione, provincia);
	}

	public   Collection<EgonView> getCapWithProvincia(final String cap) throws AddressException,RemoteException {
		final EgonCapDAODelegator capDelegator=(EgonCapDAODelegator) AddressBeanUtil.getInstance().getBean(EgonAddressBeanConstant.EGON_CAP_DAO_DELEGATOR.getBeanId());
		return capDelegator.getCapWithProvincia(cap);
	}

	public Collection<EgonView> getIndrizzi(final String cap,final String citta,final String nazione,final String provincia,final String indrizzi) throws AddressException {
		final EgonIndirizziDAODelegator indiriDelegator=(EgonIndirizziDAODelegator) AddressBeanUtil.getInstance().getBean(EgonAddressBeanConstant.EGON_INDIRIZZI_DAO_DELEGATOR.getBeanId());
		return indiriDelegator.getIndrizzi(cap, citta, nazione, indrizzi, provincia);
	}

	public Collection<EgonView> getNazione(final String nazione) throws AddressException,RemoteException {
		final EgonNazioneDAODelegator nazioneDelegator= (EgonNazioneDAODelegator) AddressBeanUtil.getInstance().getBean(EgonAddressBeanConstant.EGON_NAZIONE_DAO_DELEGATOR.getBeanId());
		return nazioneDelegator.getNazione(nazione);
	}

}