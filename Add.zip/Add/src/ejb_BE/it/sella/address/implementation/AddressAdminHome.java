package it.sella.address.implementation;



import it.sella.ejb.IEJBHome;

import java.rmi.RemoteException;

import javax.ejb.CreateException;

public interface AddressAdminHome extends IEJBHome {
	

    AddressAdmin create() throws CreateException, RemoteException;
}

