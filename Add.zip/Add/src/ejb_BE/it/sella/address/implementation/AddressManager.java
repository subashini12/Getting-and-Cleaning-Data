package it.sella.address.implementation;

import it.sella.address.IAddressManager;
import it.sella.address.IAddressServiceManager;
import it.sella.ejb.IEJBSessionObject;

public interface AddressManager extends IAddressManager,IAddressServiceManager,IEJBSessionObject {
    
}
