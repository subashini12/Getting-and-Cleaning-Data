package it.sella.address.implementation;

import it.sella.ejb.IEJBSessionHome;

import java.rmi.RemoteException;

import javax.ejb.CreateException;

public interface AddressManagerHome extends IEJBSessionHome
{

	AddressManager create()throws CreateException, RemoteException;

}
