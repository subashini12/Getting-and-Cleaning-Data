package it.sella.address.implementation;

import it.sella.ejb.IEJBObject;

public interface AddressAdmin extends IAddressAdmin,IEJBObject{
	

}
