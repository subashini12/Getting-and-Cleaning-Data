package it.sella.address.implementation.addresslink;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="ADD_TR_ADDRESS_LINK")
@SequenceGenerator(name="AddressLinkSequenceGenerator" , sequenceName="SEQ_ADDRESSLINKHOME" , allocationSize = 1 )
@NamedQueries({
	@NamedQuery(name="AddressLinkBean.findBySoggettoSubsytemPCId",query="select o from AddressLinkBean o where o.soggettoId= :soggettoId and o.subSystem=:subSystem and o.linkedId=:linkedId"),
	@NamedQuery(name="AddressLinkBean.findAllBySoggettoSubsytemPCId",query="select o from AddressLinkBean o where o.soggettoId= :soggettoId and o.subSystem=:subSystem and o.linkedId=:linkedId"),
	@NamedQuery(name="AddressLinkBean.findBySoggettoSubsytemTipoIndirizzo",query="select o from AddressLinkBean o where o.soggettoId= :soggettoId and o.subSystem=:subSystem and o.addressType=:addressType"),
	@NamedQuery(name="AddressLinkBean.findAllBySoggettoSubsytemTipoIndirizzo",query="select o from AddressLinkBean o where o.soggettoId= :soggettoId and o.subSystem=:subSystem and o.addressType=:addressType"),
	@NamedQuery(name="AddressLinkBean.findBySoggettoId",query="select o from AddressLinkBean o where o.soggettoId= :soggettoId"),
	@NamedQuery(name="AddressLinkBean.findByAddressPkId",query="select o from AddressLinkBean o where o.addressId= :addressId"),
	@NamedQuery(name="AddressLinkBean.findBySoggettoIndirizzo",query="select o from AddressLinkBean o where o.soggettoId= :soggettoId and o.addressId= :addressId"),
	@NamedQuery(name="AddressLinkBean.findAllProductContoId",query="select o from AddressLinkBean o where o.soggettoId= :soggettoId and o.linkedId is not null")
})
public class AddressLinkBean implements AddressLink
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="AddressLinkSequenceGenerator")
	@Column(name="AL_ADR_LINK")
	public Long addressLinkId;

	@Column(name="AL_TYPE_SUBSYSTEM")
	public Long subSystem;

	@Column(name="AL_TYPE_ADDRESS")
    public Long addressType;

	@Column(name="AL_LINKED_ID")
	public Long linkedId;

	@Column(name="AL_SOGGETTO_ID")
    public Long soggettoId;

	@Column(name="AL_ADDRESS_ID")
    public Long addressId;

	@Column(name="AL_OP_ID")
    public Long opId;


	public Long getAddressLinkId() {
		return addressLinkId;
	}

	public void setAddressLinkId(final Long addressLinkId) {
		this.addressLinkId = addressLinkId;
	}

    public Long getSubSystem()
    {
        return subSystem;
    }

    public void setSubSystem(final Long subSystem)
    {
        this.subSystem = subSystem;
    }

    public Long getAddressType()
    {
        return addressType;
    }

    public void setAddressType(final Long addressType)
    {
        this.addressType = addressType;
    }

    public Long getLinkedId()
    {
        return linkedId;
    }

    public void setLinkedId(final Long linkedId)
    {
        this.linkedId = linkedId;
    }

    public Long getSoggettoId()
    {
        return soggettoId;
    }

    public void setSoggettoId(final Long soggettoId)
    {
        this.soggettoId = soggettoId;
    }

    public Long getAddressId()
    {
        return addressId;
    }

    public void setAddressId(final Long addressId)
    {
        this.addressId = addressId;
    }

	public Long getOpId() {
		return this.opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}

}
