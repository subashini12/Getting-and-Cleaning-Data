package it.sella.address.implementation.ae;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="ADD_TR_AE_ADDRESS")
@SequenceGenerator(name="AEAddressSequenceGenerator" , sequenceName="SEQ_AEADDRESSHOME" , allocationSize = 1 )
@NamedQueries({
	@NamedQuery(name="AEAddressBean.findByLinkedId",query="select o from AEAddressBean o where o.addressLinkId= :addressLinkId")
})
public class AEAddressBean  implements AEAddress {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="AEAddressSequenceGenerator")
	@Column(name="AE_ADDRESS_ID")
	public Long aeAddressId;

	@Column(name="AE_RESERVED")
	public Long reserved;

	@Column(name="AE_FREQUENCY")
    public Long frequency;

	@Column(name="AE_INTERNAL")
    public Long internal;

	@Column(name="AE_ADDRESS_LINK_ID")
    public Long addressLinkId;

	@Column(name="AE_OP_ID")
    public Long opId;

    public Long getAeAddressId() {
		return aeAddressId;
	}

	public void setAeAddressId(final Long aeAddressId) {
		this.aeAddressId = aeAddressId;
	}
	public Long getReserved() {
        return reserved;
    }

    public void setReserved(final Long reserved) {
        this.reserved = reserved;
    }

    public Long getFrequency() {
        return frequency;
    }

    public void setFrequency(final Long frequency) {
        this.frequency = frequency;
    }

    public Long getInternal() {
        return internal;
    }

    public void setInternal(final Long internal) {
        this.internal = internal;
    }

    public Long getAddressLinkId() {
        return addressLinkId;
    }

    public void setAddressLinkId(final Long addressLinkId) {
        this.addressLinkId = addressLinkId;
    }

	public Long getOpId() {
		return this.opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}

}
