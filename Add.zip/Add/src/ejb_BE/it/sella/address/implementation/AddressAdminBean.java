package it.sella.address.implementation;

import it.sella.address.AddressException;
import it.sella.address.AddressManagerMapperException;
import it.sella.address.AddressManagerValidatorException;
import it.sella.address.AddressView;
import it.sella.address.HelperException;
import it.sella.address.egon.common.EgonUtil;
import it.sella.address.implementation.addr.Address;
import it.sella.address.implementation.addr.IAddressBeanManager;
import it.sella.address.implementation.addresslink.AddressLink;
import it.sella.address.implementation.addresslink.AddressLinkView;
import it.sella.address.implementation.addresslink.IAddressLinkBeanManager;
import it.sella.address.implementation.ae.AEAddress;
import it.sella.address.implementation.ae.IAEAddressBeanManager;
import it.sella.address.implementation.dbhelper.AddressCreateHelper;
import it.sella.address.implementation.dbhelper.AddressSetterHelper;
import it.sella.address.implementation.dbhelper.StoricDataUpdateHelper;
import it.sella.address.implementation.factory.ReflectionUtil;
import it.sella.address.implementation.util.DBHelper;
import it.sella.address.implementation.util.NormalizedIndirrizoHelper;
import it.sella.address.implementation.util.StringHandler;
import it.sella.anagrafe.dbaccess.ProvinciaDBAccessHelper;
import it.sella.ejb.SessionBeanAdapter;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Collection;

import javax.ejb.FinderException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.EntityManager;

public class AddressAdminBean extends SessionBeanAdapter {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressAdminBean.class);
    private static final String BUNDLE_KEY = "INTERNAL";
    private static final String DAOIMPL_KEY_FOR_ADDRESSLINK = "Manager.AddressLink";
    private static final String DAOIMPL_KEY_FOR_ADDRESS = "Manager.Address";
    private static final String DAOIMPL_KEY_FOR_AEADDRESS = "Manager.AEAddress";

    public void createAddress(final AddressView addressView) throws AddressException, RemoteException {
    	try {
    		validateAddressViewInProvincia(addressView);
			new AddressCreateHelper().createAddress(addressView);
		} catch (final AddressManagerValidatorException e) {
			log4Debug.warnStackTrace(e);
            this.getSessionContext().setRollbackOnly();
            throw new AddressException(e.getMessage());
		} catch (final AddressManagerMapperException e) {
			//The transaction will not be RolledBack , if Mapper Exception is raised.
			log4Debug.warnStackTrace(e);
		}
    }

    public void setAddress(final boolean modifyAllProductConto, final AddressView addressView) throws AddressException, RemoteException {
    	try {
    		validateAddressViewInProvincia(addressView);
			new AddressSetterHelper().setAddress(modifyAllProductConto, addressView);
		} catch (final AddressManagerValidatorException e) {
			log4Debug.warnStackTrace(e);
            this.getSessionContext().setRollbackOnly();
            throw new AddressException(e.getMessage());
		} catch (final AddressManagerMapperException e) {
			//The transaction will not be RolledBack , if Mapper Exception is raised.
			log4Debug.warnStackTrace(e);
		}
    }


    private void validateAddressViewInProvincia(final AddressView addressView) {
    	if(	addressView != null && ("ITALIA".equals(addressView.getNazione()) ||
			 (addressView.getNazioneView() != null && "ITALIA".equals(addressView.getNazioneView().getNome()))) &&
	    	  addressView.getProvinciaView() == null) {
	    		addressView.setProvinciaView(new ProvinciaDBAccessHelper().getProvincia(addressView.getProvincia()));
	    }
    }


    public void updateAddressAdmin(final Long addressPrimaryKey, final AddressView addressView) throws RemoteException, AddressException {
    	try {
			//AddressHome addressHome = (AddressHome) Helper.getHomeObject("ADDRESSHOMENAME", "it.sella.address.implementation.addr.AddressHome");
    		final IAddressBeanManager manager =  (IAddressBeanManager) ReflectionUtil.createServiceImplInstance(BUNDLE_KEY,DAOIMPL_KEY_FOR_ADDRESS);
			final Address address = manager.findByPrimaryKey(addressPrimaryKey);
			final String newCapValue = addressView.getCapView() != null ? addressView.getCapView().getCapId().toString() : addressView.getCap();
			final String oldCapValue = address.getCapId() != null ? address.getCapId().toString() : address.getCapValue();
			final String newCittaValue = addressView.getCittaView() != null ? addressView.getCittaView().getCittaId().toString() : addressView.getCitta();
			final String oldCittaValue = address.getCitta();
			final String newProvincia = addressView.getProvinciaView() != null ? addressView.getProvinciaView().getProvinciaId().toString() : addressView.getProvincia();
			final String oldProvincia = address.getProvincia();
			final Long newNazione = addressView.getNazioneView() != null ? addressView.getNazioneView().getNazioneId() : null;
			final Long oldNazione = address.getNazione();
			final String newIndirizzo = addressView.getIndirizzo() != null ? addressView.getIndirizzo().replace(',',' ').trim() : null ;

			final StringHandler stringHandler = new StringHandler();
			if(!stringHandler.checkForEquality(newIndirizzo,address.getIndirizzo()) ||
					!stringHandler.checkForEquality(newCapValue,oldCapValue) ||
					!stringHandler.checkForEquality(newCittaValue,oldCittaValue) ||
					!stringHandler.checkForEquality(newProvincia,oldProvincia) ||
					!stringHandler.checkForEquality(newNazione,oldNazione)||
					!stringHandler.checkForEquality(addressView.getNormStatus(),address.getNormStatus()) ||
					!stringHandler.checkForEquality(addressView.getPresso(),address.getPresso()) ||
					!stringHandler.checkForEquality(addressView.getEdificio(),address.getEdificio())) {
				address.setIndirizzo(newIndirizzo);
				if(addressView.getCapView() != null) {
				    address.setCapId(addressView.getCapView().getCapId());
				    address.setCapValue(null);
				} else {
				    address.setCapValue(addressView.getCap());
				    address.setCapId(null);
				}
				if(addressView.getCittaView() != null) {
					address.setCitta(addressView.getCittaView().getCittaId().toString());
				} else {
					address.setCitta(addressView.getCitta());
				}
				if(addressView.getProvinciaView() != null) {
					address.setProvincia(addressView.getProvinciaView().getProvinciaId().toString());
				} else {
					address.setProvincia(addressView.getProvincia());
				}
				if(!EgonUtil.isEmpty(addressView.getPresso())) {
					address.setPresso(addressView.getPresso());
				}

				if(!EgonUtil.isEmpty(addressView.getEdificio())) {
					address.setEdificio(addressView.getEdificio());
				}
				address.setNazione(addressView.getNazioneView().getNazioneId());
				address.setOpId(addressView.getOpId());
				address.setNormStatus(addressView.getNormStatus());
				manager.update(address);
			}
		} catch (final FinderException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new AddressException(e.getMessage());
		}
    }

    public void updateAddressLinkAdmin(final Long addressLinkPrimaryKey, final AddressLinkView addressLinkView) throws RemoteException, AddressException {
    	try {
    		final IAddressLinkBeanManager addressLinkBeanManager  = (IAddressLinkBeanManager) ReflectionUtil.createServiceImplInstance(BUNDLE_KEY, DAOIMPL_KEY_FOR_ADDRESSLINK);
			final AddressLink addressLink = addressLinkBeanManager.findByPrimaryKey(addressLinkPrimaryKey);
			final StringHandler stringHandler = new StringHandler();
			if(!stringHandler.checkForEquality(addressLinkView.getSoggettoId(),addressLink.getSoggettoId()) ||
					!stringHandler.checkForEquality(addressLinkView.getAddressId(),addressLink.getAddressId()) ||
					!stringHandler.checkForEquality(addressLinkView.getLinkedId(),addressLink.getLinkedId()) ||
					!stringHandler.checkForEquality(addressLinkView.getSubSystem(),addressLink.getSubSystem()) ||
					!stringHandler.checkForEquality(addressLinkView.getAddressType(),addressLink.getAddressType())) {
				addressLink.setSoggettoId(addressLinkView.getSoggettoId());
				addressLink.setSubSystem(addressLinkView.getSubSystem());
				addressLink.setAddressType(addressLinkView.getAddressType());
				addressLink.setLinkedId(addressLinkView.getLinkedId());
				addressLink.setAddressId(addressLinkView.getAddressId());
				addressLink.setOpId(addressLinkView.getOpId());
				addressLinkBeanManager.update(addressLink);
			}
		} catch (final AddressException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new AddressException(e.getMessage());
		} catch (final FinderException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new AddressException(e.getMessage());
		}
    }

    public void updateAddressAEAdmin(final Long addressAEPrimaryKey, final AddressView addressView) throws RemoteException, AddressException {
    	try {
    		final IAEAddressBeanManager aeAddressBeanManager = (IAEAddressBeanManager) ReflectionUtil.createServiceImplInstance(BUNDLE_KEY, DAOIMPL_KEY_FOR_AEADDRESS);
			final AEAddress aeAddress = aeAddressBeanManager.findByLinkedId(addressAEPrimaryKey);
			final StringHandler stringHandler = new StringHandler();
			if(!stringHandler.checkForEquality(addressView.getReserved(),aeAddress.getReserved()) ||
					!stringHandler.checkForEquality(addressView.getFrequency(),aeAddress.getFrequency()) ||
					!stringHandler.checkForEquality(addressView.getInternal(),aeAddress.getInternal())) {
				aeAddress.setReserved(addressView.getReserved());
				aeAddress.setFrequency(addressView.getFrequency());
				aeAddress.setInternal(addressView.getInternal());
				aeAddress.setOpId(addressView.getOpId());
				aeAddressBeanManager.update(aeAddress);
			}
 		} catch (final AddressException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new AddressException(e.getMessage());
		} catch (final FinderException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new AddressException(e.getMessage());
		}
    }

    public void deleteAddress(final Long operationId,final Long addressId)throws RemoteException, AddressException {
    	try {
    		final IAddressLinkBeanManager addressLinkBeanManager  = (IAddressLinkBeanManager) ReflectionUtil.createServiceImplInstance(BUNDLE_KEY, DAOIMPL_KEY_FOR_ADDRESSLINK);
			final Collection addrCollection = addressLinkBeanManager.findByAddressPkId(addressId);
			if(addrCollection != null && !addrCollection.isEmpty()) {
				final String errorMsg = "The address link table has reference to this address, first remove that link";
				throw new HelperException(errorMsg);
			} else {
				//AddressHome addressHome = (AddressHome) Helper.getHomeObject("ADDRESSHOMENAME", "it.sella.address.implementation.addr.AddressHome");
				final IAddressBeanManager manager =  (IAddressBeanManager) ReflectionUtil.createServiceImplInstance(BUNDLE_KEY,DAOIMPL_KEY_FOR_ADDRESS);
				final Address address = manager.findByPrimaryKey(addressId);
				new StoricDataUpdateHelper().updateAddress(operationId,addressId,address); // address.getProvincia(),address.getCitta(),address.getCapId(),address.getNazione(),address.getIndirizzo(),address.getCapValue(),address.getOpId(),address.getNormStatus()
				manager.remove(address);
			}
        } catch (final HelperException e) {
        	log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new AddressException(e.getMessage());
		} catch (final FinderException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new AddressException(e.getMessage());
		}
    }

    public void deleteAddressLink(final Long operationId,final Long addressLinkId)throws RemoteException, AddressException {
    	try {
    		final IAddressLinkBeanManager addressLinkBeanManager  = (IAddressLinkBeanManager) ReflectionUtil.createServiceImplInstance(BUNDLE_KEY, DAOIMPL_KEY_FOR_ADDRESSLINK);
			final AddressLink addressLink = addressLinkBeanManager.findByPrimaryKey(addressLinkId);
            new StoricDataUpdateHelper().updateAddresLink(operationId, addressLinkId, addressLink.getSubSystem(), addressLink.getAddressType(), addressLink.getLinkedId(), addressLink.getSoggettoId(), addressLink.getAddressId(),addressLink.getOpId());
            addressLinkBeanManager.remove(addressLink);
		} catch (final AddressException e) {
        	log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new AddressException(e.getMessage());
		} catch (final FinderException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new AddressException(e.getMessage());
		}

    }

    public void deleteAddressAE(final Long operationId,final Long addressAELinkId)throws RemoteException, AddressException {
    	try {
    		final IAEAddressBeanManager aeAddressBeanManager = (IAEAddressBeanManager) ReflectionUtil.createServiceImplInstance(BUNDLE_KEY, DAOIMPL_KEY_FOR_AEADDRESS);
			final AEAddress aeAddress = aeAddressBeanManager.findByLinkedId(addressAELinkId);
	        new StoricDataUpdateHelper().updateAddressAE(operationId,aeAddress.getAeAddressId(), aeAddress.getAddressLinkId(), aeAddress.getReserved() !=null ? aeAddress.getReserved().toString() : null, aeAddress.getFrequency(), aeAddress.getInternal(),aeAddress.getOpId());
	        aeAddressBeanManager.remove(aeAddress);
		} catch (final AddressException e) {
        	log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new AddressException(e.getMessage());
		} catch (final FinderException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new AddressException(e.getMessage());
		}
    }

    public void updateAnagrafeLog(final Long operationId, final Long soggettoId, final String errorMessage)throws  RemoteException, AddressException {
    	Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = DBHelper.getConnection();
            final StringBuffer query = new StringBuffer("UPDATE ANADD_LG_OPERATION SET");
            if(soggettoId != null) {
				query.append(" OP_SOGGETTO_ID = ?,");
			}
            query.append(" OP_ERROR_MESSAGE = ? WHERE OP_ID = ?");
            preparedStatement = connection.prepareStatement(query.toString());
            int counter = 0;
            if(soggettoId != null) {
				preparedStatement.setLong(++counter, soggettoId.longValue());
			}
            preparedStatement.setString(++counter, errorMessage);
            preparedStatement.setLong(++counter, operationId.longValue());
            preparedStatement.executeUpdate();
        } catch (final SQLException e) {
        	log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new AddressException(e.getMessage());
        } finally {
            DBHelper.cleanup(connection, preparedStatement);
        }
    }

    public NormalizedAddressStatus normalizeIndirrizo(final String nazione,final String cittaCommune,final String indirrizzo,final String provincia,final String cap,final Boolean isDOMXXCheckReq) throws AddressException, RemoteException {
    	return new NormalizedIndirrizoHelper().getNormallizaNew(nazione,cittaCommune,indirrizzo,provincia,cap,isDOMXXCheckReq,null,null);
    }

    public NormalizedAddressStatus normalizeIndirrizo(final String nazione,final String cittaCommune,final String indirrizzo,final String provincia,final String cap,final Boolean isDOMXXCheckReq,final String edificio,final String presso) throws AddressException, RemoteException {
    	return new NormalizedIndirrizoHelper().getNormallizaNew(nazione,cittaCommune,indirrizzo,provincia,cap,isDOMXXCheckReq,edificio,presso);
    }

    public AddressLink createAddressLink(final AddressLink addressLink) throws AddressException , RemoteException{
    	try {
			((IAddressLinkBeanManager) ReflectionUtil.createServiceImplInstance(BUNDLE_KEY, DAOIMPL_KEY_FOR_ADDRESSLINK)).create(addressLink);
		} catch (final AddressException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new AddressException(e.getMessage());
		}
    	return addressLink;
    }

    public AEAddress createAEAddress(final AEAddress aeAddress) throws AddressException,RemoteException{
    	try {
			((IAEAddressBeanManager) ReflectionUtil.createServiceImplInstance(BUNDLE_KEY, DAOIMPL_KEY_FOR_AEADDRESS)).create(aeAddress);
		} catch (final AddressException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new AddressException(e.getMessage());
		}
    	return aeAddress;
    }

    /**
     * Method to create Address
     * @param addressView
     * @return
     * @throws AddressException
     * @throws RemoteException
     */
    public Address createEntityAddress(final it.sella.address.implementation.addr.AddressView addressView) throws AddressException, RemoteException{
    	try {
			return ((IAddressBeanManager) ReflectionUtil.createServiceImplInstance(BUNDLE_KEY,DAOIMPL_KEY_FOR_ADDRESS)).create(addressView);
		} catch (final AddressException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new AddressException(e.getMessage());
		}
    }

    public EntityManager getPersistenceEntityManager() throws AddressException,NamingException,RemoteException{
    	final Context ctx = new InitialContext();
    	return (EntityManager) ctx.lookup("java:comp/env/persistence/AddressEntityManager");
    }
    }