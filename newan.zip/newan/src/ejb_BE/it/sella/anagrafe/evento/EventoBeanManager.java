package it.sella.anagrafe.evento;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Timestamp;
import java.util.Collection;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

/**
 * Manager Class to handle Evento
 *
 */
public class EventoBeanManager implements IEventoBeanManager{
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(EventoBeanManager.class);
	private static EntityManager entityManager;

	public EventoBeanManager(){
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.evento.IEventoBeanManager#create(it.sella.anagrafe.evento.Evento)
	 */
	public Evento create(final Evento evento) throws GestoreAnagrafeException{

		final EventoBean eventoBean = new EventoBean();
		BeanUtil.copyProperties(eventoBean, evento);
		entityManager.persist(eventoBean);
		entityManager.flush();
		BeanUtil.copyProperties(evento,eventoBean);
		return evento;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.evento.IEventoBeanManager#update(it.sella.anagrafe.evento.Evento)
	 */
	public Evento update(final Evento evento){
		entityManager.persist(evento);
		return evento;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.evento.IEventoBeanManager#remove(it.sella.anagrafe.evento.Evento)
	 */
	public void remove(final Evento evento) {
		entityManager.remove(evento);
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.evento.IEventoBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public Evento findByPrimaryKey(final Long primaryKey) throws FinderException{
		if(primaryKey == null){
			throw new FinderException("PrimaryKey is null");
		}
		final Evento evento = entityManager.find(EventoBean.class, primaryKey);
		if(evento == null){
			throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return evento;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.evento.IEventoBeanManager#findBySoggettoId(java.lang.Long)
	 */
	@SuppressWarnings("unchecked")
	public Collection<Evento> findBySoggettoId(final Long soggettoId) throws FinderException{
		try{
			final String query = "EventoBean.findBySoggettoId";
			final Query findBySoggettoId = entityManager.createNamedQuery(query);
			findBySoggettoId.setParameter("soggettoId", soggettoId);
			return findBySoggettoId.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.evento.IEventoBeanManager#findByTipoEventiAndDate(java.lang.Long, java.sql.Timestamp, java.sql.Timestamp)
	 */
	@SuppressWarnings("unchecked")
	public Collection<Evento> findByTipoEventiAndDate(final Long tipoEventi,final Timestamp dataInizio,final Timestamp dataFine) throws FinderException{
		try{
			final String query = "EventoBean.findByTipoEventiAndDate";
			final Query findByTipoEventiAndDate = entityManager.createNamedQuery(query);
			findByTipoEventiAndDate.setParameter("tipoEvento", tipoEventi);
			findByTipoEventiAndDate.setParameter("dataInizio", dataInizio);
			findByTipoEventiAndDate.setParameter("dataFine",  dataFine);
			return findByTipoEventiAndDate.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}

	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.evento.IEventoBeanManager#findBySoggettoTipoEventiAndDate(java.lang.Long, java.lang.Long, java.sql.Timestamp, java.sql.Timestamp)
	 */
	@SuppressWarnings("unchecked")
	public Collection<Evento> findBySoggettoTipoEventiAndDate(final Long soggettoId , final Long tipoEventi,final Timestamp dataInizio,final Timestamp dataFine) throws FinderException{
		try{
			final String query = "EventoBean.findBySoggettoTipoEventiAndDate";
			final Query findByTipoEventiAndDate = entityManager.createNamedQuery(query);
			findByTipoEventiAndDate.setParameter("soggettoId", soggettoId);
			findByTipoEventiAndDate.setParameter("tipoEvento", tipoEventi);
			findByTipoEventiAndDate.setParameter("dataInizio", dataInizio);
			findByTipoEventiAndDate.setParameter("dataFine",  dataFine);
			return findByTipoEventiAndDate.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.evento.IEventoBeanManager#findBySoggettoAndDate(java.lang.Long, java.sql.Timestamp, java.sql.Timestamp)
	 */
	@SuppressWarnings("unchecked")
	public Collection<Evento> findBySoggettoAndDate(final Long soggettoId ,final Timestamp dataInizio,final Timestamp dataFine) throws FinderException{
		try{
			final String query = "EventoBean.findBySoggettoAndDate";
			final Query findByTipoEventiAndDate = entityManager.createNamedQuery(query);
			findByTipoEventiAndDate.setParameter("soggettoId", soggettoId);
			findByTipoEventiAndDate.setParameter("dataInizio", dataInizio);
			findByTipoEventiAndDate.setParameter("dataFine",  dataFine);
			return findByTipoEventiAndDate.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.evento.IEventoBeanManager#findBySoggettoAndTipoEventi(java.lang.Long, java.lang.Long)
	 */
	@SuppressWarnings("unchecked")
	public Collection<Evento> findBySoggettoAndTipoEventi(final Long soggettoId , final Long tipoEventi) throws FinderException{
		try{
			final String query = "EventoBean.findBySoggettoAndTipoEventi";
			final Query findBySoggettoAndTipoEventi = entityManager.createNamedQuery(query);
			findBySoggettoAndTipoEventi.setParameter("soggettoId", soggettoId);
			findBySoggettoAndTipoEventi.setParameter("tipoEvento",tipoEventi);
			return findBySoggettoAndTipoEventi.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}
}
