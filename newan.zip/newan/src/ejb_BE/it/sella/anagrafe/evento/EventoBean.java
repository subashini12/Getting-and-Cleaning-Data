package it.sella.anagrafe.evento;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="AN_TR_EVENTI")
@SequenceGenerator(name="EventoSequenceGenerator" , sequenceName="SEQ_EVENTOHOME" , allocationSize = 1 )
@NamedQueries({
	@NamedQuery(name="EventoBean.findBySoggettoId",query="select o from EventoBean o where o.soggettoId= :soggettoId"),
	@NamedQuery(name="EventoBean.findByTipoEventiAndDate",query="select o from EventoBean o where o.tipoEvento=:tipoEvento and (o.dataInizio is null or o.dataInizio =:dataInizio)  and (o.dataFine is null or o.dataFine =:dataFine)"),
	@NamedQuery(name="EventoBean.findBySoggettoAndDate",query="select o from EventoBean o where o.soggettoId=:soggettoId and (o.dataInizio is null or o.dataInizio =:dataInizio)  and (o.dataFine is null or o.dataFine =:dataFine)"),
	@NamedQuery(name="EventoBean.findBySoggettoTipoEventiAndDate",query="select o from EventoBean o where o.soggettoId=:soggettoId and o.tipoEvento=:tipoEvento and (o.dataInizio is null or o.dataInizio =:dataInizio)  and (o.dataFine is null or o.dataFine =:dataFine)"),
	@NamedQuery(name="EventoBean.findBySoggettoAndTipoEventi",query="select o from EventoBean o where o.soggettoId=:soggettoId and o.tipoEvento=:tipoEvento")
})
public class EventoBean implements Evento {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="EventoSequenceGenerator")
	@Column(name="EV_EVENTO_ID")
	private Long eventoId;

	@Column(name="EV_SOGGETTO_ID")
	private Long soggettoId;


	@Column(name="EV_TIPO_EVENTO")
	private Long tipoEvento;


	@Column(name="EV_DATA_INIZIO")
	private Timestamp dataInizio;

	@Column(name="EV_DATA_FINE")
	private Timestamp dataFine;

	@Column(name="EV_NOTE")
	private String note;

	@Column(name="EV_OP_ID")
	private Long opId;



	public Long getEventoId() {
		return eventoId;
	}

	public Long getSoggettoId() {
		return this.soggettoId;
	}


	public String getNote() {
		return this.note;
	}

	public Long getTipoEvento() {
		return this.tipoEvento;
	}

	public Timestamp getDataInizio() {
		return this.dataInizio;
	}

	public Timestamp getDataFine() {
		return this.dataFine;
	}

	public Long getOpId() {
		return this.opId;
	}

	public void setEventoId(final Long eventoId) {
		this.eventoId = eventoId;
	}
	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;

	}


	public void setNote(final String note) {
		this.note = note;

	}

	public void setTipoEvento(final Long tipoEvento) {
		this.tipoEvento = tipoEvento;
	}

	public void setDataInizio(final Timestamp dataInizio) {
		this.dataInizio = dataInizio;

	}

	public void setDataFine(final Timestamp dataFine) {
		this.dataFine = dataFine;

	}

	public void setOpId(final Long opId) {
		this.opId = opId;

	}

}
