package it.sella.anagrafe.altritiposoggetto;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;


/**
 * Manager Class to handle Altri Tipo Soggetto
 *
 */
public class AltriTipoSoggettoBeanManager implements IAltriTipoSoggettoBeanManager {

	private final EntityManager entityManager;


	/**
	 * Method to get Instance
	 *
	 */
	public AltriTipoSoggettoBeanManager(){
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.altritiposoggetto.IAltriTipoSoggettoBeanManager#create(it.sella.anagrafe.altritiposoggetto.AltriTipoSoggetto)
	 */
	public AltriTipoSoggetto create(final AltriTipoSoggetto altrisoggetto) throws GestoreAnagrafeException {

		final AltriTipoSoggetto altriTipoSoggettoBean = new AltriTipoSoggettoBean();
		BeanUtil.copyProperties(altriTipoSoggettoBean, altrisoggetto);
		entityManager.persist(altriTipoSoggettoBean);
		entityManager.flush();
		BeanUtil.copyProperties(altrisoggetto,altriTipoSoggettoBean);
		return altrisoggetto;
	}


	/* (non-Javadoc)
	 * @see it.sella.anagrafe.altritiposoggetto.IAltriTipoSoggettoBeanManager#update(it.sella.anagrafe.altritiposoggetto.AltriTipoSoggetto)
	 */
	public AltriTipoSoggetto update(final AltriTipoSoggetto altrisoggetto){
		entityManager.persist(altrisoggetto);
		return altrisoggetto;
	}


	/* (non-Javadoc)
	 * @see it.sella.anagrafe.altritiposoggetto.IAltriTipoSoggettoBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public AltriTipoSoggetto findByPrimaryKey(final Long primaryKey) throws FinderException {
		if(primaryKey == null){
				throw new FinderException("PrimaryKey is null");
		}
		final AltriTipoSoggetto tipoSoggetto = entityManager.find(AltriTipoSoggettoBean.class, primaryKey);
		if(tipoSoggetto==null){
			throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return tipoSoggetto;
	}


	/* (non-Javadoc)
	 * @see it.sella.anagrafe.altritiposoggetto.IAltriTipoSoggettoBeanManager#findByDenominazione(java.lang.String)
	 */
	public AltriTipoSoggetto findByDenominazione(final String Denominazione) throws FinderException {
		try{
			final Query findBySoggettoId = entityManager.createNamedQuery("it.sella.anagrafe.altritiposoggetto.findByDenominazione");
			findBySoggettoId.setParameter("value", Denominazione);
			final AltriTipoSoggetto tipoSoggetto = (AltriTipoSoggetto) findBySoggettoId.getSingleResult();

			if(tipoSoggetto==null)
			{
				throw new FinderException("getSingleResult() did not retrieve any entities");
			}

			return tipoSoggetto;
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}


	/* (non-Javadoc)
	 * @see it.sella.anagrafe.altritiposoggetto.IAltriTipoSoggettoBeanManager#findBySoggettoId(java.lang.Long)
	 */
	public AltriTipoSoggetto findBySoggettoId(final Long soggId) throws FinderException {
		try{
			final Query findBySoggettoId = entityManager.createNamedQuery("it.sella.anagrafe.altritiposoggetto.findBySoggettoId");
			findBySoggettoId.setParameter("soggettoId", soggId);
			final AltriTipoSoggetto tipoSoggetto = (AltriTipoSoggetto) findBySoggettoId.getSingleResult();

			if(tipoSoggetto==null)
			{
				throw new FinderException("getSingleResult() did not retrieve any entities");
			}

			return tipoSoggetto;
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}

}
