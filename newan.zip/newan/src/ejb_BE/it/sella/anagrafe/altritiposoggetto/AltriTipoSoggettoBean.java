package it.sella.anagrafe.altritiposoggetto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="AN_TR_ALTRITIPOSOGGETTO")
@SequenceGenerator(name = "altriTipoSoggettoNewSequenceGenerator", sequenceName="SEQ_AltriTipoSoggettoHome", allocationSize = 1)
@NamedQueries({
	@NamedQuery(name="it.sella.anagrafe.altritiposoggetto.findBySoggettoId",query="select o from AltriTipoSoggettoBean o where o.soggettoId= :soggettoId"),
	@NamedQuery(name="it.sella.anagrafe.altritiposoggetto.findByDenominazione",query="select o from AltriTipoSoggettoBean o where o.denominazione= :value")
})
public class AltriTipoSoggettoBean implements AltriTipoSoggetto {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="altriTipoSoggettoNewSequenceGenerator")
	@Column(name="AT_Id")
	private Long id;
	
	@Column(name="AT_Soggetto_Id")
	private Long soggettoId;
	
	@Column(name="AT_DENOMINAZIONE")
	private String denominazione;
	
	@Column(name="AT_OP_ID")
	private Long opId;

	public Long getId() {
		return id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public Long getSoggettoId() {
		return soggettoId;
	}

	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}

	public String getDenominazione() {
		return denominazione;
	}

	public void setDenominazione(final String denominazione) {
		this.denominazione = denominazione;
	}

	public Long getOpId() {
		return opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}
}
