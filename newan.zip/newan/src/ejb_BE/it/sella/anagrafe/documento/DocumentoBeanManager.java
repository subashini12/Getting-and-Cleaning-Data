package it.sella.anagrafe.documento;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Collection;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;


/**
 * Manager Class to handle Documento
 *
 */
public class DocumentoBeanManager implements IDocumentoBeanManager{
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DocumentoBeanManager.class);
	private static EntityManager entityManager;

	public DocumentoBeanManager(){
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.documento.IDocumentoBeanManager#create(it.sella.anagrafe.documento.Documento)
	 */
	public Documento create(final Documento documento) throws GestoreAnagrafeException{
		final DocumentoBean documentoBean = new DocumentoBean();
		BeanUtil.copyProperties(documentoBean, documento);
		entityManager.persist(documentoBean);
		entityManager.flush();
		BeanUtil.copyProperties(documento,documentoBean);
		return documento;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.documento.IDocumentoBeanManager#update(it.sella.anagrafe.documento.Documento)
	 */
	public Documento update(final Documento documento){
		entityManager.persist(documento);
		return documento;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.documento.IDocumentoBeanManager#remove(it.sella.anagrafe.documento.Documento)
	 */
	public void remove(final Documento documento) {
		entityManager.remove(documento);
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.documento.IDocumentoBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public Documento findByPrimaryKey(final Long primaryKey) throws FinderException{
		if(primaryKey == null){
			throw new FinderException("PrimaryKey is null");
		}
		final Documento documento= entityManager.find(DocumentoBean.class, primaryKey);
		if(documento == null){
			throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return documento;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.documento.IDocumentoBeanManager#findBySoggettoAndTipo(java.lang.Long, java.lang.Long)
	 */
	public Documento findBySoggettoAndTipo(final Long soggettoId, final Long tipoDocumento) throws FinderException{
		try {
			final Query findBySoggettoAndTipo = entityManager.createNamedQuery("DocumentoBean.findBySoggettoAndTipo");
			findBySoggettoAndTipo.setParameter("soggettoId", soggettoId);
			findBySoggettoAndTipo.setParameter("typeOfDocument", tipoDocumento);
			return (Documento) findBySoggettoAndTipo.getSingleResult();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		} catch (final NonUniqueResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException("too_many_results_for_get_single_result");
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.documento.IDocumentoBeanManager#findBySoggettoId(java.lang.Long)
	 */
	@SuppressWarnings("unchecked")
	public Collection<Documento> findBySoggettoId(final Long soggettoId) throws FinderException{
		try {
			final String query = "DocumentoBean.findBySoggettoId";
			final Query findBySoggettoId = entityManager.createNamedQuery(query);
			findBySoggettoId.setParameter("soggettoId", soggettoId);
			return findBySoggettoId.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}
}
