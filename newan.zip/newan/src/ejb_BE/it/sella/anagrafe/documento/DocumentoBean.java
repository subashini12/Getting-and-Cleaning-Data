package it.sella.anagrafe.documento;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name="AN_TR_DOCUMENTI")
@SequenceGenerator(name="DocumentoSequenceGenerator" , sequenceName="SEQ_DOCUMENTOHOME" , allocationSize = 1 )
@NamedQueries({
	@NamedQuery(name="DocumentoBean.findBySoggettoId",query="select o from DocumentoBean o where o.soggettoId= :soggettoId"),
	@NamedQuery(name="DocumentoBean.findBySoggettoAndTipo",query="select o from DocumentoBean o where o.soggettoId= :soggettoId and o.typeOfDocument=:typeOfDocument")
})
public class DocumentoBean implements Documento {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="DocumentoSequenceGenerator")
	@Column(name="DO_DOCUMENTO_ID")
	private Long documentoId;

	@Column(name="DO_SOGGETTO_ID")
	private Long soggettoId;

	@Column(name="DO_TIPO_DOCUMENTO")
	private Long typeOfDocument;

	@Column(name="DO_NUMERO_DOCUMENTO")
	private String documentNumber;

	@Column(name="DO_LUOGO_EMISSIONE")
	private String luogoEmissione;

	@Column(name="DO_ENTE_EMISSIONE")
	private String enteEmissione;

	@Column(name="DO_DATA_EMISSIONE")
	private Timestamp dataEmissione;

	@Column(name="DO_DATA_SCADENZA")
	private Timestamp dataScadenza;

	@Column(name="DO_OP_ID")
	private Long opId;
	
	@Column(name="DO_DOC_ID")
	private String idDoc;
	
	@Column(name="DO_ISS_ID")
	private String issId;
	
	@Column(name="DO_BARCODE")
	private String barcode;
	
	@Column(name="DO_CITTA_ID")
	private Long citta;
	
	@Column(name="DO_DATA_FINE_VALIDITA")
	private Timestamp dataFineValidita;
	
	@Column(name="DO_DOC_INSERTED_OP_ID")
	private Long docInsertedOpId;
	

  public void setDocumentoId(final Long documentoId) {
		this.documentoId = documentoId;
  }

  public Long getDocumentoId() {
		return documentoId;
  }

  public Long getSoggettoId() {
    return this.soggettoId;
  }

  public Long getTypeOfDocument() {
    return this.typeOfDocument;
  }

  public String getDocumentNumber() {
    return this.documentNumber;
  }

  public String getLuogoEmissione() {
    return this.luogoEmissione;
  }

  public String getEnteEmissione() {
    return this.enteEmissione;
  }

  public java.sql.Timestamp getDataEmissione() {
    return dataEmissione;
  }

  public java.sql.Timestamp getDataScadenza() {
    return dataScadenza;
  }

  public Long getOpId() {
	return this.opId;
  }

  public void setSoggettoId(final Long soggettoId) {
    this.soggettoId = soggettoId;

  }

  public void setTypeOfDocument(final Long typeOfDocument) {
    this.typeOfDocument = typeOfDocument;
  }

  public void setDocumentNumber(final String documentNumber) {
    this.documentNumber = documentNumber;
  }

  public void setLuogoEmissione(final String luogoEmissione) {
    this.luogoEmissione = luogoEmissione;
  }

  public void setEnteEmissione(final String enteEmissione) {
    this.enteEmissione = enteEmissione;
  }

  public void setDataEmissione(final java.sql.Timestamp dataEmissione) {
    this.dataEmissione = dataEmissione;
  }

  public void setDataScadenza(final java.sql.Timestamp dataScadenza) {
    this.dataScadenza = dataScadenza;
  }

  public void setOpId(final Long opId) {
	this.opId = opId;
  }

	public String getIssId() {	
		return this.issId;
	}
	
	public String getBarcode() {
		return this.barcode;
	}
	
	public void setIssId(final String issId) {
		this.issId = issId;
	}
	
	public void setBarcode(final String barcode) {
		this.barcode = barcode;
	}
	
	public String getIdDoc() {		
		return this.idDoc;
	}
	
	public void setIdDoc(final String idDoc) {		
		this.idDoc = idDoc;
	}

	public Long getCitta() {
		return citta;
	}

	public void setCitta(Long citta) {
		this.citta = citta;
	}

	public Timestamp getDataFineValidita() {
		return dataFineValidita;
	}

	public void setDataFineValidita(final Timestamp dataFineValidita) {
		this.dataFineValidita = dataFineValidita;
	}

	public Long getDocInsertedOpId() {
		return docInsertedOpId;
	}

	public void setDocInsertedOpId(final Long docInsertedOpId) {
		this.docInsertedOpId = docInsertedOpId;
	}
}
