package it.sella.anagrafe.daisoggetto;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;


/**
 * @author GBS03447
 *
 */
public class DAISoggettoBeanManager implements IDAISoggettoBeanManager {
	
	private static final Log4Debug log4Debug  = Log4DebugFactory.getLog4Debug(DAISoggettoBeanManager.class);
	private EntityManager entityManager = null;
	
	public DAISoggettoBeanManager(){
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}
	
	/* (non-Javadoc)
	 * @see it.sella.anagrafe.daisoggetto.IDAISoggettoBeanManager#create(it.sella.anagrafe.daisoggetto.DAISoggetto)
	 */
	public DAISoggetto create(final DAISoggetto daiSoggetto) throws GestoreAnagrafeException {
		final DAISoggettoBean daiSoggettoBean = new DAISoggettoBean();
		BeanUtil.copyProperties(daiSoggettoBean, daiSoggetto);
		entityManager.persist(daiSoggettoBean);
		entityManager.flush();
		BeanUtil.copyProperties(daiSoggetto, daiSoggettoBean);
		return daiSoggetto;
	}
	
	/* (non-Javadoc)
	 * @see it.sella.anagrafe.daisoggetto.IDAISoggettoBeanManager#update(it.sella.anagrafe.daisoggetto.DAISoggetto)
	 */
	public DAISoggetto update(final DAISoggetto daiSoggetto) {
		entityManager.persist(daiSoggetto);
		return daiSoggetto;
	}
	
	/* (non-Javadoc)
	 * @see it.sella.anagrafe.daisoggetto.IDAISoggettoBeanManager#remove(it.sella.anagrafe.daisoggetto.DAISoggetto)
	 */
	public void remove(final DAISoggetto daiSoggetto) {
		entityManager.remove(daiSoggetto);
	}
	
	/* (non-Javadoc)
	 * @see it.sella.anagrafe.daisoggetto.IDAISoggettoBeanManager#findBySoggettoId(java.lang.Long)
	 */
	public DAISoggetto findBySoggettoId(final Long soggettoId) throws FinderException {
		try {
			final Query findBySoggettoId = entityManager.createNamedQuery("DAISoggettoBean.findBySoggettoId");
			findBySoggettoId.setParameter("soggettoId", soggettoId);
			final DAISoggetto daiSoggetto = (DAISoggetto) findBySoggettoId.getSingleResult();
			
			if(daiSoggetto == null) {
				throw new FinderException("getSingleResult() did not retrieve any entities");
			}
			return daiSoggetto;
		} catch (final NoResultException noResultExcep) {
			log4Debug.debugStackTrace(noResultExcep);
			throw new FinderException(noResultExcep.getMessage());
		}
	}
	
	/* (non-Javadoc)
	 * @see it.sella.anagrafe.daisoggetto.IDAISoggettoBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public DAISoggetto findByPrimaryKey(final Long primaryKey) throws FinderException {
		if (primaryKey == null) {
			throw new FinderException("PrimaryKey is null");
		}
		final DAISoggetto daiSoggetto = entityManager.find(DAISoggettoBean.class, primaryKey);
		if (daiSoggetto == null) {
			throw new FinderException("Record Not Found For PrimaryKey " + primaryKey);
		}
		return daiSoggetto;
	}
}