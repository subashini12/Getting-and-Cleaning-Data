package it.sella.anagrafe.daisoggetto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @author GBS03447
 *
 */
@Entity
@Table(name="AN_TR_DAI_SOGGETTO")
@SequenceGenerator(name="DAISoggettoSequenceGenerator", sequenceName="AN_SQ_DAI_SOGGETTO", allocationSize = 1)
@NamedQueries({
	@NamedQuery(name="DAISoggettoBean.findBySoggettoId",query="select o from DAISoggettoBean o where o.soggettoId = :soggettoId")
})
public class DAISoggettoBean implements DAISoggetto {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="DAISoggettoSequenceGenerator")
	@Column(name="DS_ID")
	private Long daiId;
	
	@Column(name="DS_SOGGETTO_ID")
	private Long soggettoId;
	
	@Column(name="DS_REGOLE_ID")
	private Long regoleId;
	
	@Column(name="DS_DAI_WEIGHT_ID_ID")
	private Long daiWeightId;
	
	@Column(name="DS_OP_ID")
	private Long opId;

	public Long getDaiId() {
		return daiId;
	}

	public void setDaiId(final Long daiId) {
		this.daiId = daiId;
	}

	public Long getSoggettoId() {
		return soggettoId;
	}

	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}

	public Long getRegoleId() {
		return regoleId;
	}

	public void setRegoleId(final Long regoleId) {
		this.regoleId = regoleId;
	}

	public Long getDaiWeightId() {
		return daiWeightId;
	}

	public void setDaiWeightId(final Long daiWeightId) {
		this.daiWeightId = daiWeightId;
	}

	public Long getOpId() {
		return opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}
}
