package it.sella.anagrafe.log;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;

/**
 * Manager Class to handle Log
 *
 */
public class LogBeanManager implements ILogBeanManager {

	private final EntityManager entityManager;

	public LogBeanManager(){
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.log.ILogBeanManager#create(it.sella.anagrafe.log.Log)
	 */
	public Log create(final Log log) throws GestoreAnagrafeException {

		final Log logBean = new LogBean();
		BeanUtil.copyProperties(logBean,log);
		entityManager.persist(logBean);
		entityManager.flush();
		BeanUtil.copyProperties(log, logBean);

		return log;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.log.ILogBeanManager#update(it.sella.anagrafe.log.Log)
	 */
	public Log update(final Log log) {

		entityManager.persist(log);

		return log;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.log.ILogBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public Log findByPrimaryKey(final Long primaryKey) throws FinderException {
		if(primaryKey == null){
			throw new FinderException("PrimaryKey is null");
		}
		final Log logBean = entityManager.find(LogBean.class, primaryKey);
		if(logBean==null){
			throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return logBean;
	}
}
