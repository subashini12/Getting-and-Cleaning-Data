package it.sella.anagrafe.log;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="ANADD_TR_LOG")
@SequenceGenerator(name = "logNewSequenceGenerator", sequenceName="SEQ_LogHome", allocationSize = 1)
public class LogBean implements Log {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="LG_ID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="logNewSequenceGenerator")
	private Long id;
	
	@Column(name="LG_SOGGETTO_ID")
	private Long soggettoId;
	
	@Column(name="LG_CODDP")
	private String codiciDipendente;
	
	@Column(name="LG_DATE")
	private Timestamp dateOfOperation;
	
	@Column(name="LG_OPERATION")
	private String modeOfOperation;
	
	@Column(name="LG_ACCOUNT_ID")
	private Long accountId;

	
	public Long getId() {
		return id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public Long getSoggettoId() {
		return soggettoId;
	}

	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}

	public String getCodiciDipendente() {
		return codiciDipendente;
	}

	public void setCodiciDipendente(final String codiciDipendente) {
		this.codiciDipendente = codiciDipendente;
	}

	public Timestamp getDateOfOperation() {
		return dateOfOperation;
	}

	public void setDateOfOperation(final Timestamp dateOfOperation) {
		this.dateOfOperation = dateOfOperation;
	}

	public String getModeOfOperation() {
		return modeOfOperation;
	}

	public void setModeOfOperation(final String modeOfOperation) {
		this.modeOfOperation = modeOfOperation;
	}

	public Long getAccountId() {
		return accountId;
	}

	public void setAccountId(final Long accountId) {
		this.accountId = accountId;
	}
}
