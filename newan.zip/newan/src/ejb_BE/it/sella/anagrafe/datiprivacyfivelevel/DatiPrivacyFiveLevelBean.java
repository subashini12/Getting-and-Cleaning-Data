package it.sella.anagrafe.datiprivacyfivelevel;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="AN_TR_DATIPRIVACY_FIVELEVEL")
@SequenceGenerator(name = "datiprivacyfivelevelNewSequenceGenerator", sequenceName="SEQ_DatiPrivacyFiveLevelHome", allocationSize = 1)
@NamedQuery(name="it.sella.anagrafe.persistence.datiprivacyfivelevel.findBySoggettoId",query="SELECT o FROM DatiPrivacyFiveLevelBean o WHERE o.soggettoId= :soggettoId")
public class DatiPrivacyFiveLevelBean implements DatiPrivacyFiveLevel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="datiprivacyfivelevelNewSequenceGenerator")
	@Column(name="DP_ID")
	private Long id;
	
	@Column(name="DP_SOGGETTO_ID")
	private Long soggettoId;
	
	@Column(name="DP_LEVEL1")
	private String value1;
	
	@Column(name="DP_LEVEL2")
	private String value2;
	
	@Column(name="DP_LEVEL3")
	private String value3;
	
	@Column(name="DP_LEVEL4")
	private String value4;
	
	@Column(name="DP_LEVEL5")
	private String value5;
	
	@Column(name="DP_LEVEL_PROFIL")
	private String profil;
	
	@Column(name="DP_OP_ID")
	private Long opId;

	
	public Long getId() {
		return id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public Long getSoggettoId() {
		return soggettoId;
	}

	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}

	public String getValue1() {
		return value1;
	}

	public void setValue1(final String value1) {
		this.value1 = value1;
	}

	public String getValue2() {
		return value2;
	}

	public void setValue2(final String value2) {
		this.value2 = value2;
	}

	public String getValue3() {
		return value3;
	}

	public void setValue3(final String value3) {
		this.value3 = value3;
	}

	public String getValue4() {
		return value4;
	}

	public void setValue4(final String value4) {
		this.value4 = value4;
	}

	public String getValue5() {
		return value5;
	}

	public void setValue5(final String value5) {
		this.value5 = value5;
	}
	
	public String getProfil() {
		return profil;
	}

	public void setProfil(final String profil) {
		this.profil = profil;
	}

	public Long getOpId() {
		return opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}
}
