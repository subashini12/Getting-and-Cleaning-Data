package it.sella.anagrafe.datiprivacyfivelevel;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;

import java.util.Collection;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

/**
 * Manager Class to handle DatiPrivacyFiveLevel
 *
 */
public class DatiPrivacyFiveLevelBeanManager implements IDatiPrivacyFiveLevelBeanManager {

	private final EntityManager entityManager;

	public DatiPrivacyFiveLevelBeanManager(){
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datiprivacyfivelevel.IDatiPrivacyFiveLevelBeanManager#create(it.sella.anagrafe.datiprivacyfivelevel.DatiPrivacyFiveLevel)
	 */
	public DatiPrivacyFiveLevel create(
			final DatiPrivacyFiveLevel datiPrivacyPFFiveLevelView) throws GestoreAnagrafeException {

		final DatiPrivacyFiveLevel datiPrivacyFiveLevel = new DatiPrivacyFiveLevelBean();
		BeanUtil.copyProperties(datiPrivacyFiveLevel,datiPrivacyPFFiveLevelView);
		entityManager.persist(datiPrivacyFiveLevel);
		entityManager.flush();
		BeanUtil.copyProperties(datiPrivacyPFFiveLevelView,datiPrivacyFiveLevel);

		return datiPrivacyPFFiveLevelView;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datiprivacyfivelevel.IDatiPrivacyFiveLevelBeanManager#update(it.sella.anagrafe.datiprivacyfivelevel.DatiPrivacyFiveLevel)
	 */
	public DatiPrivacyFiveLevel update(
			final DatiPrivacyFiveLevel datiPrivacyPFFiveLevelView) {

		entityManager.persist(datiPrivacyPFFiveLevelView);

		return datiPrivacyPFFiveLevelView;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datiprivacyfivelevel.IDatiPrivacyFiveLevelBeanManager#remove(it.sella.anagrafe.datiprivacyfivelevel.DatiPrivacyFiveLevel)
	 */
	public void remove(final DatiPrivacyFiveLevel datiPrivacyPFFiveLevelView) {

		entityManager.remove(datiPrivacyPFFiveLevelView);

	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datiprivacyfivelevel.IDatiPrivacyFiveLevelBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public DatiPrivacyFiveLevel findByPrimaryKey(final Long primaryKey) throws FinderException {
		if(primaryKey == null){
			throw new FinderException("PrimaryKey is null");
		}
		final DatiPrivacyFiveLevel datiPrivacyFiveLevel = entityManager.find(DatiPrivacyFiveLevelBean.class, primaryKey);
		if(datiPrivacyFiveLevel==null){
			throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return datiPrivacyFiveLevel;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datiprivacyfivelevel.IDatiPrivacyFiveLevelBeanManager#findBySoggettoId(java.lang.Long)
	 */
	public Collection<DatiPrivacyFiveLevel> findBySoggettoId(final Long soggettoId) throws FinderException  {
		try{
			final Query findBySoggettoId = entityManager.createNamedQuery("it.sella.anagrafe.persistence.datiprivacyfivelevel.findBySoggettoId");
			findBySoggettoId.setParameter("soggettoId", soggettoId);
			@SuppressWarnings("unchecked")
			final
			Collection<DatiPrivacyFiveLevel> datiPrivacyFiveLevelList = findBySoggettoId.getResultList();

			return datiPrivacyFiveLevelList;
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}

}
