package it.sella.anagrafe.datifiscali;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Collection;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

/**
 * Manager Class to handle DatiFiscali
 *
 */
public class DatiFiscaliBeanManager implements IDatiFiscaliBeanManager {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DatiFiscaliBeanManager.class);
	private final EntityManager entityManager;

	public DatiFiscaliBeanManager(){
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datifiscali.IDatiFiscaliBeanManager#create(it.sella.anagrafe.datifiscali.DatiFiscali)
	 */
	public DatiFiscali create(final DatiFiscali datiFiscali) throws GestoreAnagrafeException {
		
		final DatiFiscali datiFiscaliBean = new DatiFiscaliBean();
		BeanUtil.copyProperties(datiFiscaliBean,datiFiscali);
		try{
			entityManager.persist(datiFiscaliBean);
			entityManager.flush();
		} catch(final PersistenceException e) {
			log4Debug.severeStackTrace(e);
			final String cause = e.getCause() != null ? e.getCause().getMessage() : "";
			if(cause.contains("ORA-00001: unique constraint (WEBLOGIC_DBA.AN_TR_CODICE_FIS_CHECK_UQ)") || e.getMessage().contains("CODICE FISCALE EXISTS ALREADY")) { // ORA-00001: unique constraint (WEBLOGIC_DBA.AN_TR_CODICE_FIS_CHECK_UQ) violated
				throw new GestoreAnagrafeException(new AnagrafeHelper().getMessage("ANAG-1780")); // codice fiscale � gi� esistente
			} else {
				throw e;
			}
		}
		BeanUtil.copyProperties(datiFiscali,datiFiscaliBean);
		return datiFiscali;

	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datifiscali.IDatiFiscaliBeanManager#update(it.sella.anagrafe.datifiscali.DatiFiscali)
	 */
	public DatiFiscali update(final DatiFiscali datiFiscali) {
		entityManager.persist(datiFiscali);
		return datiFiscali;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datifiscali.IDatiFiscaliBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public DatiFiscali findByPrimaryKey(final Long primaryKey) throws FinderException {
		if(primaryKey == null){
			throw new FinderException("PrimaryKey is null");
		}
		final DatiFiscali datiFiscali = entityManager.find(DatiFiscaliBean.class, primaryKey);
		if(datiFiscali==null){
			throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return datiFiscali;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datifiscali.IDatiFiscaliBeanManager#findBySoggettoId(java.lang.Long)
	 */
	public Collection<DatiFiscali> findBySoggettoId(final Long soggId) throws FinderException {
		try{
			final Query findBySoggettoId = entityManager.createNamedQuery("it.sella.anagrafe.persistence.datifiscali.findBySoggettoId");
			findBySoggettoId.setParameter("soggettoId", soggId);
			@SuppressWarnings("unchecked")
			final
			Collection<DatiFiscali> datiFiscaliList = findBySoggettoId.getResultList();

			return datiFiscaliList;
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datifiscali.IDatiFiscaliBeanManager#findBySoggettoIdAndRightPk(java.lang.Long, java.lang.Long)
	 */
	public DatiFiscali findBySoggettoIdAndRightPk(final Long soggId, final Long rightPk) throws FinderException {
		try{
			final Query findBySoggettoId = entityManager.createNamedQuery("it.sella.anagrafe.persistence.datifiscali.findBySoggettoIdAndRightPk");
			findBySoggettoId.setParameter("soggettoId", soggId);
			findBySoggettoId.setParameter("rightPk", rightPk);
			final DatiFiscali datiFiscali = (DatiFiscali) findBySoggettoId.getSingleResult();

			if(datiFiscali==null) {
				throw new FinderException("getSingleResult() did not retrieve any entities");
			}

			return datiFiscali;
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datifiscali.IDatiFiscaliBeanManager#remove(it.sella.anagrafe.datifiscali.DatiFiscali)
	 */
	public void remove(final DatiFiscali datiFiscali){
		entityManager.remove(datiFiscali);
	}

}
