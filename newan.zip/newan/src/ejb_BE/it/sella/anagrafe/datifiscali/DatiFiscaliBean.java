package it.sella.anagrafe.datifiscali;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="An_tr_DatiFiscali")
@SequenceGenerator(name = "datifiscaliNewSequenceGenerator", sequenceName="SEQ_DatiFiscaliHome", allocationSize = 1)
@NamedQueries({
	@NamedQuery(name="it.sella.anagrafe.persistence.datifiscali.findBySoggettoId",query="select o from DatiFiscaliBean o where o.soggettoId= :soggettoId"),
	@NamedQuery(name="it.sella.anagrafe.persistence.datifiscali.findBySoggettoIdAndRightPk",query="select o from DatiFiscaliBean o where o.soggettoId= :soggettoId and o.rightPk= :rightPk")
})
public class DatiFiscaliBean implements DatiFiscali {
		
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="datifiscaliNewSequenceGenerator")
	@Column(name="Df_DatiFiscali_Id")
	private Long id;
	
	@Column(name="Df_Soggetto_Id")
	private Long soggettoId;
	
	@Column(name="Df_right_pk")
	private Long rightPk;
	
	@Column(name="Df_Value")
	private String value;
	
	@Column(name="Df_Op_id")
	private Long opId;
	
	
	public Long getId() {
		return id;
	}
	public void setId(final Long id) {
		this.id = id;
	}
	public Long getSoggettoId() {
		return soggettoId;
	}
	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}
	public Long getRightPk() {
		return rightPk;
	}
	public void setRightPk(final Long rightPk) {
		this.rightPk = rightPk;
	}
	public String getValue() {
		return value;
	}
	public void setValue(final String value) {
		this.value = value;
	}
	public Long getOpId() {
		return opId;
	}
	public void setOpId(final Long opId) {
		this.opId = opId;
	}
}
