package it.sella.anagrafe.recapiti;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "AN_TR_RECAPITI")
@SequenceGenerator(name = "RecapitiSequenceGenerator", sequenceName = "SEQ_RECAPITIHOME", allocationSize = 1)
@NamedQueries({
		@NamedQuery(name = "RecapitiBean.findBySoggettoId", query = "select o from RecapitiBean o where o.soggettoId= :soggettoId"),
		@NamedQuery(name = "RecapitiBean.findBySoggettoAndTipo", query = "select o from RecapitiBean o where o.soggettoId= :soggettoId and o.rightPk=:rightPk")
	})
public class RecapitiBean implements Recapiti {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RecapitiSequenceGenerator")
	@Column(name="RE_RECAPITI_ID")
	private Long recapitiId;

	@Column(name="RE_SOGGETTO_ID")
	private Long soggettoId;

	@Column(name="RE_RIGHT_PK")
	private Long rightPk;

	@Column(name="RE_VALUE")
	private String value;

	@Column(name="RE_RIFERIMENTO")
	private String riferimento;

	@Column(name="RE_OP_ID")
	private Long opId;
	
	@Column(name="RE_PREFISSO_INTER")
	private String prefissoCode;

	public Long getRecapitiId() {
		return recapitiId;
	}

	public Long getSoggettoId() {
		return this.soggettoId;
	}

	public Long getRightPk() {
		return this.rightPk;
	}

	public String getValue() {
		return this.value;
	}

	public String getRiferimento() {
		return this.riferimento;
	}

	public Long getOpId() {
		return this.opId;
	}
	
	public String getPrefissoCode() {
		return this.prefissoCode;
	}

	public void setRecapitiId(final Long recapitiId) {
		this.recapitiId = recapitiId;
	}

	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}

	public void setRightPk(final Long rightPk) {
		this.rightPk = rightPk;
	}

	public void setValue(final String value) {
		this.value = value;
	}

	public void setRiferimento(final String riferimento) {
		this.riferimento = riferimento;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}

	public void setPrefissoCode(String prefissoCode) {
		this.prefissoCode = prefissoCode;
		
	}

}
