package it.sella.anagrafe.recapiti;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Collection;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

/**
 * Manager Class to handle Recapiti
 *
 */
public class RecapitiBeanManager implements IRecapitiBeanManager{
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(RecapitiBeanManager.class);
	private static EntityManager entityManager;

	public RecapitiBeanManager(){
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.recapiti.IRecapitiBeanManager#create(it.sella.anagrafe.recapiti.Recapiti)
	 */
	public Recapiti create(final Recapiti recapiti) throws GestoreAnagrafeException {
		final RecapitiBean recapitiBean = new RecapitiBean();
		BeanUtil.copyProperties(recapitiBean, recapiti);
		entityManager.persist(recapitiBean);
		entityManager.flush();
		BeanUtil.copyProperties(recapiti,recapitiBean);
		return recapiti;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.recapiti.IRecapitiBeanManager#update(it.sella.anagrafe.recapiti.Recapiti)
	 */
	public Recapiti update(final Recapiti recapiti){
		entityManager.persist(recapiti);
		return recapiti;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.recapiti.IRecapitiBeanManager#remove(it.sella.anagrafe.recapiti.Recapiti)
	 */
	public void remove(final Recapiti recapiti) {
		entityManager.remove(recapiti);
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.recapiti.IRecapitiBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public Recapiti findByPrimaryKey(final Long primaryKey) throws FinderException{
		if(primaryKey == null){
			throw new FinderException("PrimaryKey is null");
		}
		final Recapiti recapiti = entityManager.find(RecapitiBean.class, primaryKey);
		if(recapiti == null){
			throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return recapiti;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.recapiti.IRecapitiBeanManager#findBySoggettoId(java.lang.Long)
	 */
	@SuppressWarnings("unchecked")
	public Collection<Recapiti> findBySoggettoId(final Long soggettoId) throws FinderException{
		try {
			final String query = "RecapitiBean.findBySoggettoId";
			final Query findBySoggettoId = entityManager.createNamedQuery(query);
			findBySoggettoId.setParameter("soggettoId",soggettoId);
			return findBySoggettoId.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.recapiti.IRecapitiBeanManager#findBySoggettoAndTipo(java.lang.Long, java.lang.Long)
	 */
	@SuppressWarnings("unchecked")
	public Collection<Recapiti> findBySoggettoAndTipo(final Long soggettoId, final Long tipoRecapito) throws FinderException{
		try {
			final String query = "RecapitiBean.findBySoggettoAndTipo";
			final Query findBySoggettoAndTipo = entityManager.createNamedQuery(query);
			findBySoggettoAndTipo.setParameter("soggettoId", soggettoId);
			findBySoggettoAndTipo.setParameter("rightPk", tipoRecapito);
			return findBySoggettoAndTipo.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}
}
