package it.sella.anagrafe.docpoterifirma;

import java.util.Collection;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

/**
 * @author GBS03447
 * Persistence Manager Class of DocumentiPoteriFirma
 * 
 */
public class DocumentiPoteriFirmaBeanManager implements IDocumentiPoteriFirmaBeanManager {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DocumentiPoteriFirmaBeanManager.class);
	private EntityManager entityManager = null;

	public DocumentiPoteriFirmaBeanManager() {
		entityManager = AnagrafeEntityManagerFactory.getInstance()
				.getEntityManager();
	}

	/* (non-Java doc)
	 * @see it.sella.anagrafe.docpoterifirma.IDocumentiPoteriFirmaBeanManager#create(it.sella.anagrafe.docpoterifirma.DocumentiPoteriFirma)
	 */
	public DocumentiPoteriFirma create(final DocumentiPoteriFirma docPoteriFirma) throws GestoreAnagrafeException {
		log4Debug.debug("Persisting DocumentiPoteriFirma   ::::  Create");
		final DocumentiPoteriFirmaBean docPoteriFirmaBean = new DocumentiPoteriFirmaBean();
		BeanUtil.copyProperties(docPoteriFirmaBean, docPoteriFirma);
		entityManager.persist(docPoteriFirmaBean);
		entityManager.flush();
		BeanUtil.copyProperties(docPoteriFirma, docPoteriFirmaBean);
		return docPoteriFirma;
	}
	
	/* (non-Java doc)
	 * @see it.sella.anagrafe.docpoterifirma.IDocumentiPoteriFirmaBeanManager#update(it.sella.anagrafe.docpoterifirma.DocumentiPoteriFirma)
	 */
	public DocumentiPoteriFirma update(final DocumentiPoteriFirma docPoteriFirma) {
		log4Debug.debug("Persisting DocumentiPoteriFirma   ::::  Update");
		entityManager.persist(docPoteriFirma);
		return docPoteriFirma;
	}
	
	/* (non-Java doc)
	 * @see it.sella.anagrafe.docpoterifirma.IDocumentiPoteriFirmaBeanManager#remove(it.sella.anagrafe.docpoterifirma.DocumentiPoteriFirma)
	 */
	public void remove(final DocumentiPoteriFirma docPoteriFirma){
		log4Debug.debug("Persisting DocumentiPoteriFirma   ::::  remove");
		entityManager.remove(docPoteriFirma);
	}
	
	/* (non-Java doc)
	 * @see it.sella.anagrafe.docpoterifirma.IDocumentiPoteriFirmaBeanManager#findBySoggettoId(java.lang.Long)
	 */
	@SuppressWarnings("unchecked")
	public Collection<DocumentiPoteriFirma> findBySoggettoId(final Long soggettoId) throws FinderException { // not used
		try {
			log4Debug.debug("DocumentiPoteriFirma   ::::  findBySoggettoId");
			final Query findBySoggettoId = entityManager.createNamedQuery("DocumentiPoteriFirmaBean.findBySoggettoId");
			findBySoggettoId.setParameter("soggettoId", soggettoId);
			return findBySoggettoId.getResultList();
		} catch (final NoResultException noResultExcep){
			log4Debug.warnStackTrace(noResultExcep);
			throw new FinderException(noResultExcep.getMessage());
		}
	}
	
	/* (non-Java doc)
	 * @see it.sella.anagrafe.docpoterifirma.IDocumentiPoteriFirmaBeanManager#findByCollegamentoId(java.lang.Long)
	 */
	public Collection<DocumentiPoteriFirma> findByCollegamentoId(final Long collegamentoId) throws FinderException {
		try {
			log4Debug.debug("DocumentiPoteriFirma   ::::  findByCollegamentoId");
			final Query findByCollegamentoId = entityManager.createNamedQuery("DocumentiPoteriFirmaBean.findByCollegamentoId");
			findByCollegamentoId.setParameter("collegamentoId", collegamentoId);
			return findByCollegamentoId.getResultList();
		}catch (final NoResultException noResultExcep){
			log4Debug.warnStackTrace(noResultExcep);
			throw new FinderException(noResultExcep.getMessage());
		}
	}
	
	/* (non-Java doc)
	 * @see it.sella.anagrafe.docpoterifirma.IDocumentiPoteriFirmaBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public DocumentiPoteriFirma findByPrimaryKey(final Long primaryKey) throws FinderException{
		if(primaryKey == null){
			throw new FinderException("Primary Key Null");
		}
		final DocumentiPoteriFirma docPoteriFirma = entityManager.find(DocumentiPoteriFirmaBean.class, primaryKey);
		if(docPoteriFirma == null){
			throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return docPoteriFirma;
	}
}
