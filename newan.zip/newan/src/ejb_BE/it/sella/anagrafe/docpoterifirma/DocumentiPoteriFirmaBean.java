package it.sella.anagrafe.docpoterifirma;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * @author GBS03447
 * DocumentoPoteriFirma Entity Bean
 *
 */
@Entity
@Table(name="AN_TR_DOCUMENTI_POTERI_FIRMA")
@SequenceGenerator(name="DocPoteriFirmaSequenceGenerator", sequenceName="AN_SQ_DOC_POTERIFIRMA", allocationSize = 1)
@NamedQueries({
	@NamedQuery(name="DocumentiPoteriFirmaBean.findBySoggettoId",query="select o from DocumentiPoteriFirmaBean o where o.soggettoId = :soggettoId"),
	@NamedQuery(name="DocumentiPoteriFirmaBean.findByCollegamentoId",query="select o from DocumentiPoteriFirmaBean o where o.collegamentoId = :collegamentoId"),
	@NamedQuery(name="DocumentiPoteriFirmaBean.findByCollegamentoIdAndSoggettoId",query="select o from DocumentiPoteriFirmaBean o where o.collegamentoId = :collegamentoId and o.soggettoId = :soggettoId")
	})
public class DocumentiPoteriFirmaBean implements DocumentiPoteriFirma {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="DocPoteriFirmaSequenceGenerator")
	@Column(name="DP_DOCUMENTO_ID")
	private Long documentoId;
	
	@Column(name="DP_COLLEGA_ID")
	private Long collegamentoId;
	
	@Column(name="DP_SOGGETTO_PRINCIPALE")
	private Long soggettoId;
	
	@Column(name="DP_LINKED_SOGGETTO")
	private Long linkedSoggettoId;
	
	@Column(name="DP_TIPO_DOCUMENT_ID")
	private Long tipoDocumentoId;
	
	@Column(name="DP_DOCUMENT_DESCRIPTION")
	private String documentDescription;
	
	@Column(name="DP_DATA_EMISSIONE")
	private Timestamp dataEmissione;
	
	@Column(name="DP_OP_ID")
	private Long opId;
	

	public Long getDocumentoId() {
		return documentoId;
	}

	public void setDocumentoId(final Long documentoId) {
		this.documentoId = documentoId;
	}

	public Long getCollegamentoId() {
		return collegamentoId;
	}

	public void setCollegamentoId(final Long collegamentoId) {
		this.collegamentoId = collegamentoId;
	}

	public Long getSoggettoId() {
		return soggettoId;
	}

	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}
	
	public Long getLinkedSoggettoId() {
		return linkedSoggettoId;
	}

	public void setLinkedSoggettoId(final Long linkedSoggettoId) {
		this.linkedSoggettoId = linkedSoggettoId;
	}

	public Long getTipoDocumentoId() {
		return tipoDocumentoId;
	}

	public void setTipoDocumentoId(final Long tipoDocumentoId) {
		this.tipoDocumentoId = tipoDocumentoId;
	}

	public String getDocumentDescription() {
		return documentDescription;
	}

	public void setDocumentDescription(final String documentDescription) {
		this.documentDescription = documentDescription;
	}

	public Timestamp getDataEmissione() {
		return dataEmissione;
	}

	public void setDataEmissione(final Timestamp dataEmissione) {
		this.dataEmissione = dataEmissione;
	}

	public Long getOpId() {
		return opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}
}
