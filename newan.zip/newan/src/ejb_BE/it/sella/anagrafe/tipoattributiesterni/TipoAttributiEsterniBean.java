package it.sella.anagrafe.tipoattributiesterni;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "AN_TR_ATTRIBUTIESTERNI")
@SequenceGenerator(name = "AttributiEsterniSequenceGenerator", sequenceName = "SEQ_TIPOATTRIBUTIESTERNIHOME", allocationSize = 1)
@NamedQueries({
		@NamedQuery(name = "AttributiEsterniBean.findBySoggettoId", query = "select o from TipoAttributiEsterniBean o where o.soggettoId= :soggettoId"),
		@NamedQuery(name = "AttributiEsterniBean.findBySoggettoIdAndRightPK", query = "select o from TipoAttributiEsterniBean o where o.soggettoId= :soggettoId and o.rightPk= :rightPk"),
		@NamedQuery(name = "AttributiEsterniBean.findByStato", query = "select o from TipoAttributiEsterniBean o where o.value =:value and o.soggettoId=:soggettoId"),
		@NamedQuery(name = "AttributiEsterniBean.findByStatoNonOperativa", query = "select o from TipoAttributiEsterniBean o where o.value =:value and o.soggettoId=:soggettoId ")
	})
public class TipoAttributiEsterniBean implements TipoAttributiEsterni {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="AttributiEsterniSequenceGenerator")
	@Column(name="AE_ATTRIBUTIESTERNI_ID")
	private Long attributiesterniId;

	@Column(name="AE_SOGGETTO_ID")
	private Long soggettoId;

	@Column(name="AE_RIGHT_PK")
	private Long rightPk;

	@Column(name="AE_VALUE")
	private String value;

	@Column(name="AE_OP_ID")
	private Long opId;

	public Long getAttributiesterniId() {
		return attributiesterniId;
	}

	public Long getSoggettoId() {
		return this.soggettoId;
	}

	public Long getRightPk() {
		return this.rightPk;
	}

	public String getValue() {
		return this.value;
	}

	public Long getOpId() {
		return this.opId;
	}

	public void setAttributiesterniId(final Long attributiesterniId) {
		this.attributiesterniId = attributiesterniId;
	}

	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;

	}

	public void setRightPk(final Long rightPk) {
		this.rightPk = rightPk;

	}

	public void setValue(final String value) {
		this.value = value;

	}

	public void setOpId(final Long opId) {
		this.opId = opId;

	}


}
