package it.sella.anagrafe.tipoattributiesterni;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Collection;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

/**
 * Manager Class to handle TipoAttributiEsterni
 *
 */
public class TipoAttributiEsterniBeanManager implements ITipoAttributiEsterniBeanManager {
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(TipoAttributiEsterniBeanManager.class);
	private final EntityManager entityManager;

	public TipoAttributiEsterniBeanManager(){
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.tipoattributiesterni.ITipoAttributiEsterniBeanManager#create(it.sella.anagrafe.tipoattributiesterni.TipoAttributiEsterni)
	 */
	public TipoAttributiEsterni create(final TipoAttributiEsterni tipoAttributiEsterni) throws GestoreAnagrafeException{
		final TipoAttributiEsterniBean attributiEsterniBean = new TipoAttributiEsterniBean();
		BeanUtil.copyProperties(attributiEsterniBean, tipoAttributiEsterni);
		entityManager.persist(attributiEsterniBean);
		entityManager.flush();
		BeanUtil.copyProperties(tipoAttributiEsterni,attributiEsterniBean);
		return tipoAttributiEsterni;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.tipoattributiesterni.ITipoAttributiEsterniBeanManager#update(it.sella.anagrafe.tipoattributiesterni.TipoAttributiEsterni)
	 */
	public TipoAttributiEsterni update(final TipoAttributiEsterni tipoAttributiEsterni){
		entityManager.persist(tipoAttributiEsterni);
		return tipoAttributiEsterni;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.tipoattributiesterni.ITipoAttributiEsterniBeanManager#remove(it.sella.anagrafe.tipoattributiesterni.TipoAttributiEsterni)
	 */
	public void remove(final TipoAttributiEsterni tipoAttributiEsterni){
		entityManager.remove(tipoAttributiEsterni);
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.tipoattributiesterni.ITipoAttributiEsterniBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public TipoAttributiEsterni findByPrimaryKey(final Long primaryKey) throws FinderException{
		if(primaryKey == null){
			throw new FinderException("PrimaryKey is null");
		}
		final TipoAttributiEsterni attributiEsterni = entityManager.find(TipoAttributiEsterniBean.class, primaryKey);
		if(attributiEsterni == null){
			throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return attributiEsterni;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.tipoattributiesterni.ITipoAttributiEsterniBeanManager#findBySoggettoId(java.lang.Long)
	 */
	@SuppressWarnings("unchecked")
	public Collection<TipoAttributiEsterni> findBySoggettoId(final Long soggettoId) throws FinderException{
		try{
			final String query = "AttributiEsterniBean.findBySoggettoId";
			final Query findBySoggettoId = entityManager.createNamedQuery(query);
			findBySoggettoId.setParameter("soggettoId", soggettoId);
			return findBySoggettoId.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.tipoattributiesterni.ITipoAttributiEsterniBeanManager#findByStato(java.lang.String, java.lang.Long)
	 */
	@SuppressWarnings("unchecked")
	public Collection<TipoAttributiEsterni> findByStato(final String stato , final Long soggettoId)throws FinderException{
		try{
			final String query = "AttributiEsterniBean.findByStato";
			final Query findByStato = entityManager.createNamedQuery(query);
			findByStato.setParameter("soggettoId", soggettoId);
			findByStato.setParameter("value", stato);
			return findByStato.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.tipoattributiesterni.ITipoAttributiEsterniBeanManager#findByStatoNonOperativa(java.lang.String, java.lang.Long)
	 */
	@SuppressWarnings("unchecked")
	public Collection<TipoAttributiEsterni> findByStatoNonOperativa(final String operativa , final Long soggettoId)throws FinderException{
		try{
			final String query = "AttributiEsterniBean.findByStatoNonOperativa";
			final Query findByStatoNonOperativa = entityManager.createNamedQuery(query);
			findByStatoNonOperativa.setParameter("soggettoId", soggettoId);
			findByStatoNonOperativa.setParameter("value", operativa);
			return findByStatoNonOperativa.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.tipoattributiesterni.ITipoAttributiEsterniBeanManager#findBySoggettoIdAndRightPK(java.lang.Long, java.lang.Long)
	 */
	public TipoAttributiEsterni findBySoggettoIdAndRightPK(final Long soggettoId,final Long rightPK)throws FinderException{
		try{
			final String query = "AttributiEsterniBean.findBySoggettoIdAndRightPK";
			final Query findBySoggettoIdAndRightPK = entityManager.createNamedQuery(query);
			findBySoggettoIdAndRightPK.setParameter("soggettoId", soggettoId);
			findBySoggettoIdAndRightPK.setParameter("rightPk", rightPK);
			return (TipoAttributiEsterni) findBySoggettoIdAndRightPK.getSingleResult();
		}catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}catch (final NonUniqueResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException("too_many_results_for_get_single_result");
		}
	}

}
