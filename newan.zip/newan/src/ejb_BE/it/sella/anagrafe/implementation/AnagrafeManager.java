package it.sella.anagrafe.implementation;

import it.sella.anagrafe.OperazioneCensimentoException;
import it.sella.anagrafe.RicercaException;
import it.sella.anagrafe.RicercaPFException;
import it.sella.anagrafe.az.DatiAnagraficiAZView;
import it.sella.anagrafe.view.SoggettoView;
import it.sella.ejb.IEJBSessionObject;
import it.sella.gestione_flussi.FlussoConsumer;
import it.sella.gestione_flussi.FlussoProducer;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Properties;


public interface AnagrafeManager extends IEJBSessionObject, FlussoProducer, FlussoConsumer {

    /**
     *  This method has to be invoked using
     * AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().performCensimento(SoggettoView soggettoView)
     * @param soggettoView
     * @return Long soggettoId
     * @exception OperazioneCensimentoException
     * @exception RemoteException
     * @see it.sella.anagrafe.AnagrafeManagerFactory
     */
    public Long performCensimento(SoggettoView soggettoView) throws OperazioneCensimentoException, RemoteException;

    /**
     * This method has to be invoked using
     * AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().performCensimentoModifica(SoggettoView soggettoView)
     * @param soggettoView
     * @exception OperazioneCensimentoException
     * @exception RemoteException
     * @see it.sella.anagrafe.AnagrafeManagerFactory
     */
    public void performCensimentoModifica(SoggettoView soggettoView) throws OperazioneCensimentoException, RemoteException;

    /**
     * This method has to be invoked using
     * AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().ricerca(Properties properties)
     * @param properties
     * @exception RicercaPFException
     * @exception RemoteException
     * @return java.util.Collection
     * @see it.sella.anagrafe.AnagrafeManagerFactory
     */
    public Collection ricerca(Properties properties) throws RicercaPFException, RemoteException;

    /**
     * This method has to be invoked using
     * AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().getSoggetto(Long soggettoId,Properties properties)
     * @param soggettoId
     * @param properties
     * @exception RemoteException
     * @return SoggettoView
     * @see it.sella.anagrafe.AnagrafeManagerFactory
     */
    public SoggettoView getSoggetto(Long soggettoId, Properties properties) throws RemoteException;

    /**
     * This method has to be invoked using
     * AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().createSoggetto(String xmlSoggetto)
     * @param xmlSoggetto : An xml data containing the soggetto details.
     * @exception OperazioneCensimentoException
     * @exception RemoteException
     * @return String : An xml data containing the soggetto id. The xml structure is as follows:
     * <?xml version='1.0' encoding='UTF-8'?>
     * <RISPOSTA>
     * <ESITO>0</ESITO>
     * <SOGGETTO_ID>1001</SOGGETTO_ID>
     * </RISPOSTA>
     * The below elements is being removed from the xml structure because the indirizzo id is not being returned to
     * the sub systems:
     *  <IRE_ID>1002</IRE_ID>
     *  <IDO_ID>1003</IDO_ID>
     *  <IPO_ID>1004</IPO_ID>
     * @see it.sella.anagrafe.AnagrafeManagerFactory
     */

    /**
     * @deprecated This service is deprecated, and will be removed on 31-12-2009. Instead the method creaSoggettoXML(String xmlSoggetto)
     * available in the same interface can be used.
     */

    public String createSoggetto(String xmlSoggetto) throws OperazioneCensimentoException, RemoteException;

    /**
     * This method has to be invoked using
     * AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().createSoggetto(String xmlSoggetto)
     * @param xmlSoggetto : An xml data containing the soggetto details.
     * @exception OperazioneCensimentoException
     * @exception RemoteException
     * @return String : An xml data containing the soggetto id. The xml structure is as follows:
     * <?xml version='1.0' encoding='UTF-8'?>
     * <RISPOSTA>
     * <ESITO>0</ESITO>
     * <SOGGETTO_ID>1001</SOGGETTO_ID>
     * </RISPOSTA>
     * @see it.sella.anagrafe.AnagrafeManagerFactory
     */

    /**
     * @deprecated This service is deprecated, and will be removed on 31-12-2009. Instead the method
     * creaSoggettoXMLWithHost(String xmlSoggetto) available in the same interface can be used.
     */
    public String createSoggettoWithHost(String xmlSoggetto) throws OperazioneCensimentoException, RemoteException;

    /*
    * This method has to be invoked using
    * AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().createSoggetto(String xmlSoggetto)
    * This method is used to update eventi and dipct for a list of soggettos by reading from a file
    * using flussi.
    */
    public void updateEventiEDipct() throws OperazioneAnagrafeManagerException, RemoteException;

    /**
     * This method has to be invoked using
     * AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().creaSoggettoXML(String xmlSoggetto)
     * @param xmlSoggetto : An xml data containing the soggetto details.
     * @exception OperazioneCensimentoException
     * @exception RemoteException
     * @return String : An xml data containing the soggetto id. The xml structure is as follows:
     * <?xml version='1.0' encoding='UTF-8'?>
     * <RISPOSTA>
     * <ESITO>0</ESITO>
     * <SOGGETTO_ID>1001</SOGGETTO_ID>
     * </RISPOSTA>
     * The below elements is being removed from the xml structure because the indirizzo id is not being returned to
     * the sub systems:
     *  <IRE_ID>1002</IRE_ID>
     *  <IDO_ID>1003</IDO_ID>
     *  <IPO_ID>1004</IPO_ID>
     * @see it.sella.anagrafe.AnagrafeManagerFactory
     */

    public String creaSoggettoXML(String xmlSoggetto) throws OperazioneCensimentoException, RemoteException;

    /**
     * This method has to be invoked using
     * AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().creaSoggettoXMLWithHost(String xmlSoggetto)
     * @param xmlSoggetto : An xml data containing the soggetto details.
     * @exception OperazioneCensimentoException
     * @exception RemoteException
     * @return String : An xml data containing the soggetto id. The xml structure is as follows:
     * <?xml version='1.0' encoding='UTF-8'?>
     * <RISPOSTA>
     * <ESITO>0</ESITO>
     * <SOGGETTO_ID>1001</SOGGETTO_ID>
     * </RISPOSTA>
     * @see it.sella.anagrafe.AnagrafeManagerFactory
     */


    public String creaSoggettoXMLWithHost(String xmlSoggetto) throws OperazioneCensimentoException, RemoteException;
    /**
     * This method used to validate xmlSoggettos
     * This method has to be invoked using
     * AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().validateSoggettoXML(String xmlSoggetto)
     * @param xmlSoggetto
     * @throws OperazioneCensimentoException
     * @throws RemoteException
     * @return String : The string as following format
     *  If xml format is correct the output "OK"
     *  If xml format is correct but specified the soggetto details not exist the output format is "OK:DESCRIPTIONS"
     *  If xml format is wrong the output "KO:ERRORMESSAGE"
     */
    public String validateSoggettoXML( String xmlSoggetto ) throws OperazioneCensimentoException, RemoteException;
    /**
       *  This method has to be invoked using
     * AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().variaSoggettoXML(final String xmlSoggetto , final Long soggettoId)
     * @param xmlSoggetto
     * @param soggettoId
     * @return
     * @throws OperazioneCensimentoException
     * @throws RemoteException
     */
    public String variaSoggettoXML( final String xmlSoggetto , final Long soggettoId ) throws OperazioneCensimentoException, RemoteException;
    /**
     * This method has to be invoked using
     * AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().variaSoggettoXMLCompleto(final String xmlSoggetto , final Long soggettoId)
     * @param xmlSoggetto
     * @param soggettoId
     * @return
     * @throws OperazioneCensimentoException
     * @throws RemoteException
     */
    public String variaSoggettoXMLCompleto( final String xmlSoggetto , final Long soggettoId ) throws OperazioneCensimentoException, RemoteException;
    /**
     *
     * @param xmlSoggetto
     * @return
     * @throws OperazioneCensimentoException
     * @throws RemoteException
     */
    public String creaSoggettoXMLWithXSDValidation(String xmlSoggetto) throws OperazioneCensimentoException, RemoteException;
    /**
     *
     * @param xmlSoggetto
     * @return
     * @throws OperazioneCensimentoException
     * @throws RemoteException
     */
    public String creaSoggettoXMLWithHostWithXSDValidation( String xmlSoggetto ) throws OperazioneCensimentoException, RemoteException;
    /**
     *
     * @param xmlSoggetto
     * @param soggettoId
     * @return
     * @throws OperazioneCensimentoException
     * @throws RemoteException
     */
    public String variaSoggettoXMLWithXSDValidation( String xmlSoggetto , Long soggettoId ) throws OperazioneCensimentoException, RemoteException;
    /**
     *
     * @param xmlSoggetto
     * @param soggettoId
     * @return
     * @throws OperazioneCensimentoException
     * @throws RemoteException
     */
    public String variaSoggettoXMLCompletoWithXSDValidation( final String xmlSoggetto , final Long soggettoId ) throws OperazioneCensimentoException, RemoteException;
    /**
     *
     * @param xmlSoggetto
     * @return
     * @throws OperazioneCensimentoException
     * @throws RemoteException
     */
    public String validateSoggettoXMLWithXSDValidation( String xmlSoggetto ) throws OperazioneCensimentoException, RemoteException;

    /**
     * Exposed Method to perform ricerca function for Azienda by passing input as DatiAnagraficiAZView,motive.
     * Input key for DatiAnagraficiAZView - View contains Denominazione of AZienda that needs to be looked for.
     * Input key for Motive - MOTIV
     * @param properties
     * @return
     * @throws RicercaException
     * @throws RemoteException
     */
    Collection ricercaAZDenominazione(Properties properties) throws RicercaException, RemoteException;
    /**
     * Exposed Method to perform ricerca function for Azienda by passing input as DatiAnagraficiAZView and Succursale Code.
     * Input key for DatiAnagraficiAZView - View contains Denominazione of AZienda that needs to be looked for.
     * codiceSuccursale denotes the code of Succursale
     * @param properties
     * @param codiceSuccursale
     * @return
     * @throws RicercaException
     * @throws RemoteException
     */
    Collection ricercaAZDenominazioneSuccursale(Properties properties,String codiceSuccursale) throws RicercaException, RemoteException;

    /**
     *
     * @param xmlSoggetto
     * @return
     * @throws OperazioneCensimentoException
     * @throws RemoteException
     */
    public String creaSoggettoXMLForBPAAutoCens( String xmlSoggetto ) throws OperazioneCensimentoException, RemoteException;

    /**
     *
     * @param mainSoggettoId
     * @param denominazione
     * @param dataDiCostituzione
     * @return
     * @throws OperazioneCensimentoException
     * @throws RemoteException
     */
    public Long createSellaLifeCustomer(final Long mainSoggettoId, final DatiAnagraficiAZView datiAnagraficiAZView) throws OperazioneCensimentoException, RemoteException;

}