package it.sella.anagrafe.implementation;

import it.sella.ejb.IEJBObject;

public interface GeograficaValidatorImpl extends GeograficaInformazione, AttributiEsterniInformazione, DatiFiscaliInformazione, AziendaInformazione, IEJBObject {

}


