package it.sella.anagrafe.implementation;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.IDocPoteriFirmaView;
import it.sella.anagrafe.az.DatiAnagraficiAZView;
import it.sella.anagrafe.discriminator.EventoDiscriminatorException;
import it.sella.anagrafe.evento.EventoView;
import it.sella.anagrafe.pf.SoggettoEventoView;
import it.sella.anagrafe.view.ClasseATECOView;
import it.sella.anagrafe.view.CompSettoreClasseView;
import it.sella.anagrafe.view.IW8W8iView;
import it.sella.anagrafe.view.ProvinciaAdminView;
import it.sella.ejb.IEJBObject;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Hashtable;

public interface AnagrafeAdmin extends IEJBObject {

    public void updateDatiAnagraficAZ(Long soggettoId,DatiAnagraficiAZView datiAnagraficiAZView) throws RemoteException, GestoreAnagrafeException;

    public void updateEventi(Long eventId,SoggettoEventoView soggettoEventoView) throws RemoteException, GestoreAnagrafeException;

    public void updateSoggetto(Long soggettoId,Long tipoSoggettoId,Long opId) throws RemoteException, GestoreAnagrafeException;

    public void deleteEvento(Long eventoId, Long opId) throws RemoteException, EventoDiscriminatorException;

    public void deleteDocumento(Long pkId, Long opId) throws RemoteException, GestoreAnagrafeException;

    public void removePrivacy(Collection pkIds, Long opId) throws RemoteException, GestoreAnagrafeException;

    public void removePrivacyFiveLevel(Long soggettoId, Long opId) throws RemoteException, GestoreAnagrafeException;

    public void removeRecapiti(Long pkId, Long opId) throws RemoteException, GestoreAnagrafeException;

    public void replaceCollegamento(Long oldSoggettoId, Long newSoggettoId, String motivCausale, Long opId) throws GestoreAnagrafeException, RemoteException;

    public void terminateLink(Long linkedSoggettoId, Hashtable attributes, Long opId) throws GestoreAnagrafeException, RemoteException;

    public void setDatiFiscaliW8W8I(final Long soggettoId, final IW8W8iView iView)  throws GestoreAnagrafeException, RemoteException;

    public void createProvincia(ProvinciaAdminView provincia ) throws GestoreAnagrafeException,RemoteException;

    public void updateProvincia(ProvinciaAdminView provincia ) throws GestoreAnagrafeException,RemoteException;

    public Long createClasseATECO(final ClasseATECOView classeATECOView) throws GestoreAnagrafeException, RemoteException;

    public void updateClasseATECO(final ClasseATECOView classeATECOView) throws GestoreAnagrafeException, RemoteException;

    public void deleteClasseATECO(final Long classeATECOId)	throws GestoreAnagrafeException, RemoteException ;

    public Long createCompSettoreClasse(final CompSettoreClasseView compSettoreClasseView)throws GestoreAnagrafeException, RemoteException;

    public void deleteCompSettoreClasse(final Long compSettoreClasseId)throws GestoreAnagrafeException, RemoteException;

    public void createEvento(EventoView eventoView) throws GestoreAnagrafeException, RemoteException;
    
    public void deleteDocumentPoteriFirma(final Long pkId, final Long opID) throws RemoteException, GestoreAnagrafeException;
    
    public void createPoteriFirmaDocument(final Long soggettoId, final IDocPoteriFirmaView docPoteriFirma ) throws GestoreAnagrafeException, RemoteException;
    
    public void setDocumentPoteriFirma(final Long opId, IDocPoteriFirmaView docPoteriFirma, final Long collegamentoId, final Long soggettoId) throws GestoreAnagrafeException, RemoteException;

}
