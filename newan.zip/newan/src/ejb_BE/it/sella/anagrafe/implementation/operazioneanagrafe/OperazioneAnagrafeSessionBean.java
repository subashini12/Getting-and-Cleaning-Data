package it.sella.anagrafe.implementation.operazioneanagrafe;

import it.sella.anagrafe.AltriSoggettoView;
import it.sella.anagrafe.AnagrafeDAIException;
import it.sella.anagrafe.AnagrafeManagerFactory;
import it.sella.anagrafe.CanalePreferitoDataView;
import it.sella.anagrafe.DAIRegoleException;
import it.sella.anagrafe.DAISoggettoException;
import it.sella.anagrafe.DIPCTAlignFailException;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.anagrafe.GestoreCollegamentoException;
import it.sella.anagrafe.GestoreDatiFiscaliException;
import it.sella.anagrafe.GestoreSoggettoException;
import it.sella.anagrafe.IAnagrafeLoggerView;
import it.sella.anagrafe.ICanaleUtilizzatoView;
import it.sella.anagrafe.IDAIRegoleDetailsView;
import it.sella.anagrafe.IRecapitiNonDispDetailView;
import it.sella.anagrafe.MigrationException;
import it.sella.anagrafe.OperazioneAnagrafeFactory;
import it.sella.anagrafe.OperazioneCensimentoException;
import it.sella.anagrafe.SocketHelperException;
import it.sella.anagrafe.SoggettoDAIDataView;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.UpdateAMMBAScanView;
import it.sella.anagrafe.az.AttributiTramiteAZView;
import it.sella.anagrafe.az.DatiAnagraficiAZView;
import it.sella.anagrafe.bpaautomaticcens.SoggettiPromtoreUtil;
import it.sella.anagrafe.collegamento.Collegamento;
import it.sella.anagrafe.collegamento.CollegamentoView;
import it.sella.anagrafe.common.CAP;
import it.sella.anagrafe.common.Citta;
import it.sella.anagrafe.common.Ramo;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.dao.AnagrafeBeanUtil;
import it.sella.anagrafe.dao.ICensimentoAutomaticoDAO;
import it.sella.anagrafe.dao.IDuplicateSoggettoDAO;
import it.sella.anagrafe.dao.ISoggettiPromotoreDAO;
import it.sella.anagrafe.dao.impl.CensimentoAutomaticoImpl;
import it.sella.anagrafe.dao.impl.PosteDaoHandler;
import it.sella.anagrafe.dbaccess.AltriSoggettiHandler;
import it.sella.anagrafe.dbaccess.AmministratoriBancaGetterHelper;
import it.sella.anagrafe.dbaccess.AmministratoriBancaSetterHelper;
import it.sella.anagrafe.dbaccess.AmministratoriBancaUpdateHelper;
import it.sella.anagrafe.dbaccess.AttributiEsterniDBAccessHelper;
import it.sella.anagrafe.dbaccess.AttributiTramiteDBAccessHelper;
import it.sella.anagrafe.dbaccess.AttributiTramiteUpdateHelper;
import it.sella.anagrafe.dbaccess.CSCifratiGetterHelper;
import it.sella.anagrafe.dbaccess.CanalePreferitoDBAccessHelper;
import it.sella.anagrafe.dbaccess.CapTableHandler;
import it.sella.anagrafe.dbaccess.CittaDBAccessHelper;
import it.sella.anagrafe.dbaccess.ClienteClassificazioneDBAccessHelper;
import it.sella.anagrafe.dbaccess.CodiceSoggettoDBAccessHelper;
import it.sella.anagrafe.dbaccess.CollegamentoCreateHelper;
import it.sella.anagrafe.dbaccess.CollegamentoDBAccessHelper;
import it.sella.anagrafe.dbaccess.CollegamentoPrincipaleGetterHelper;
import it.sella.anagrafe.dbaccess.CompatibilityHelper;
import it.sella.anagrafe.dbaccess.DatiAnagraficiFinderHelper;
import it.sella.anagrafe.dbaccess.DatiAnagraficiGetterHelper;
import it.sella.anagrafe.dbaccess.DatiAnagraficiPFUpdateHelper;
import it.sella.anagrafe.dbaccess.DatiFiscaliDBAccessHelper;
import it.sella.anagrafe.dbaccess.DipctAlignDBAccessHelper;
import it.sella.anagrafe.dbaccess.DocEventiDBAccessHelper;
import it.sella.anagrafe.dbaccess.DocumentiDBAccessHelper;
import it.sella.anagrafe.dbaccess.EventiDBAccessHelper;
import it.sella.anagrafe.dbaccess.FatcaUpdateBPAHelper;
import it.sella.anagrafe.dbaccess.FatturatoDBAccessHelper;
import it.sella.anagrafe.dbaccess.LogDBAccessHelper;
import it.sella.anagrafe.dbaccess.MigrationDBAccessHelper;
import it.sella.anagrafe.dbaccess.NazioneDBAccessHelper;
import it.sella.anagrafe.dbaccess.PF_merge_Helper;
import it.sella.anagrafe.dbaccess.PrivacyDBAccessHelper;
import it.sella.anagrafe.dbaccess.PrivacyFiveLevelDBAccessHelper;
import it.sella.anagrafe.dbaccess.RamoDBAccessHelper;
import it.sella.anagrafe.dbaccess.RecapitiDBAccessHelper;
import it.sella.anagrafe.dbaccess.SellaLifeDBAccessHelper;
import it.sella.anagrafe.dbaccess.SocketRBOperationGetterHelper;
import it.sella.anagrafe.dbaccess.SocketRBOperationSetterHelper;
import it.sella.anagrafe.dbaccess.TipoSoggettoHandler;
import it.sella.anagrafe.dbaccess.TipoSoggettoUtil;
import it.sella.anagrafe.discriminator.AttributiEsterniDiscriminatorException;
import it.sella.anagrafe.discriminator.CodiceSoggettoDiscriminatorException;
import it.sella.anagrafe.discriminator.CollegamentoException;
import it.sella.anagrafe.discriminator.DatiAnagraficiDiscriminatorException;
import it.sella.anagrafe.discriminator.DatiFiscaliDiscriminatorException;
import it.sella.anagrafe.discriminator.DatiPrivacyDiscriminatorException;
import it.sella.anagrafe.discriminator.DocumentoDiscriminatorException;
import it.sella.anagrafe.discriminator.EventoDiscriminatorException;
import it.sella.anagrafe.discriminator.RecapitiDiscriminatorException;
import it.sella.anagrafe.factory.SoggettiPromotoreDAOFactory;
import it.sella.anagrafe.hostlog.HostLogHelper;
import it.sella.anagrafe.hostlog.HostLoggerException;
import it.sella.anagrafe.hostlog.LogHostCallView;
import it.sella.anagrafe.hostlog.LogOperationDataView;
import it.sella.anagrafe.hostlog.SocketRBLogOperationDataView;
import it.sella.anagrafe.implementation.IView;
import it.sella.anagrafe.implementation.NazioneView;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.anagrafe.logView.LogView;
import it.sella.anagrafe.pf.DatiAnagraficiPFView;
import it.sella.anagrafe.pf.DatiFiscaliPFView;
import it.sella.anagrafe.pf.DocumentoPFView;
import it.sella.anagrafe.pf.SoggettoEventoView;
import it.sella.anagrafe.pf.SoggettoRecapitiView;
import it.sella.anagrafe.poste.exception.PosteException;
import it.sella.anagrafe.sm.admin.AdminConstants;
import it.sella.anagrafe.sm.censimentoautomatico.AutomaticCensimentoHandler;
import it.sella.anagrafe.sm.censimentoautomaticoadmin.CensimentoAutomaticoHelper;
import it.sella.anagrafe.terminatesoggetto.TerminateSoggettoHelper;
import it.sella.anagrafe.tiposoggetto.TipoSoggetto;
import it.sella.anagrafe.tiposoggetto.TipoSoggettoView;
import it.sella.anagrafe.util.AcfwHandler;
import it.sella.anagrafe.util.AddressHandler;
import it.sella.anagrafe.util.AnagrafeLoggerHelper;
import it.sella.anagrafe.util.CanalePreferitoException;
import it.sella.anagrafe.util.HelperException;
import it.sella.anagrafe.util.IntestatazioneHandler;
import it.sella.anagrafe.util.MessageManagerHandler;
import it.sella.anagrafe.util.RecapitiNonDisponibileException;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.anagrafe.util.SoggettiPromotoreException;
import it.sella.anagrafe.util.StringHandler;
import it.sella.anagrafe.util.logger.Logger;
import it.sella.anagrafe.util.socket.TransferContoSocketHelper;
import it.sella.anagrafe.util.xmlgen.BustaHelper;
import it.sella.anagrafe.util.xmlgen.W9XMLGenerator;
import it.sella.anagrafe.util.xmlgen.XMLGeneratorException;
import it.sella.anagrafe.validator.DocumentServiceManager;
import it.sella.anagrafe.view.ClienteClassificazioneView;
import it.sella.anagrafe.view.CompDocumentView;
import it.sella.anagrafe.view.DipctAlignDetailsView;
import it.sella.anagrafe.view.DocEventiView;
import it.sella.anagrafe.view.FatturatoView;
import it.sella.anagrafe.view.PosteCustomerView;
import it.sella.anagrafe.view.SoggettiPromtoreView;
import it.sella.anagrafe.view.SoggettoView;
import it.sella.anagrafe.view.TransferContoView;
import it.sella.classificazione.ClassificazioneView;
import it.sella.ejb.SessionBeanAdapter;
import it.sella.logserver.LoggerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.EntityManager;
import it.sella.anagrafe.dbaccess.CanalePreferitoUpdateHelper;
import it.sella.anagrafe.dbaccess.dai.AnagrafeDAIUpdateHelper;
import it.sella.anagrafe.dbaccess.dai.DAIDBAccessHelper;
import it.sella.anagrafe.dbaccess.recapnondisp.RecapitiNonDispGetterHelper;
import it.sella.anagrafe.dbaccess.recapnondisp.RecapitiNonDispUpdateHelper;

public class OperazioneAnagrafeSessionBean extends SessionBeanAdapter {

    /**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(OperazioneAnagrafeSessionBean.class);

    public void createCodiciSoggetto( final Long soggettoId, final IView iView ) throws CodiceSoggettoDiscriminatorException, RemoteException {
    	new CodiceSoggettoDBAccessHelper().createCodiciSoggetto(soggettoId, iView);
    }

    public IView getCodiciSoggetto( final Long soggettoId ) throws CodiceSoggettoDiscriminatorException, RemoteException, ClassNotFoundException {
        return new CodiceSoggettoDBAccessHelper().getCodiciSoggettoForOPBean(soggettoId);
    }

    public void setCodiciSoggetto( final Long soggettoId, final IView iView ) throws CodiceSoggettoDiscriminatorException, RemoteException {
    	new CodiceSoggettoDBAccessHelper().setCodiciSoggetto(soggettoId, iView);
    }

    public Long findByNDGNonOperativa( final IView iView ) throws CodiceSoggettoDiscriminatorException, RemoteException {
        return new CodiceSoggettoDBAccessHelper().findByNDGNonOperativa(iView);
    }

    public void createDatiFiscaliPF( final Long soggettoId, final IView iView ) throws DatiFiscaliDiscriminatorException, RemoteException {
        new DatiFiscaliDBAccessHelper().createDatiFiscaliPF(soggettoId, iView);
    }

    public IView getDatiFiscaliPF( final Long soggettoId ) throws DatiFiscaliDiscriminatorException, RemoteException {
        return new DatiFiscaliDBAccessHelper().getDatiFiscaliPF(soggettoId);
    }

    public void setDatiFiscaliPF( final Long soggettoId, final IView iView ) throws DatiFiscaliDiscriminatorException, RemoteException {
    	// While Updating CodiceFisacli For PF, and PF is acting as Titolare to any DittaInd AZ subject.. then Updating the new CodiceFiscali of to the AZ DI Subjects.
    	String tipoSoggetto = null;
    	String codiceFiscaliOld = null;
		try {
			tipoSoggetto = new TipoSoggettoHandler().getTipoSoggettoForAdmin(soggettoId);
			if("Semplice".equals(tipoSoggetto)) {
				codiceFiscaliOld = new DatiFiscaliDBAccessHelper().getDatiFiscali(soggettoId, "codiceFiscali");
			}
		} catch (final GestoreSoggettoException e) {
			throw new DatiFiscaliDiscriminatorException(e.getLocalizedMessage());
		} catch (final GestoreDatiFiscaliException e) {
			throw new DatiFiscaliDiscriminatorException(e.getLocalizedMessage());
		}
		new DatiFiscaliDBAccessHelper().setDatiFiscaliPF(soggettoId, iView);		
		processTitolareCodiceFiscali((DatiFiscaliPFView) iView, codiceFiscaliOld, soggettoId, tipoSoggetto);
    }
    
    private void processTitolareCodiceFiscali(final DatiFiscaliPFView datifisacliView, final String codiceFisacliOld, final Long soggettoId, final String tipoSoggetto) throws RemoteException, DatiFiscaliDiscriminatorException {
    	try {
	    	if("Semplice".equals(tipoSoggetto) && !new StringHandler().checkForEquality(datifisacliView.getCodiceFiscali(), codiceFisacliOld)) {
	    		final Collection principleIdOfTitolareMotiv = new CollegamentoDBAccessHelper().getSoggettoPrincipale(soggettoId, "TITOL");
	    		if(principleIdOfTitolareMotiv != null && !principleIdOfTitolareMotiv.isEmpty()) {
	    			final Long [] soggettoIds = (Long[]) principleIdOfTitolareMotiv.toArray(new Long[principleIdOfTitolareMotiv.size()]);
	    			new CollegamentoDBAccessHelper().updateCodiceFiscaliForSoggetto(soggettoIds, datifisacliView.getCodiceFiscali(), datifisacliView.getOpId());
	    		}
	    	}
    	} catch (final GestoreCollegamentoException e) {
			throw new DatiFiscaliDiscriminatorException(e.getLocalizedMessage());
		} catch (final CollegamentoException e) {
			throw new DatiFiscaliDiscriminatorException(e.getLocalizedMessage());
		}
    }

    public void setDatiFiscaliPFWithBussta( final Long soggettoId, final IView iView, final Hashtable pdfTable ) throws DatiFiscaliDiscriminatorException, RemoteException {
    	try {
    		new DatiFiscaliDBAccessHelper().setDatiFiscaliPF(soggettoId, iView);
			new W9XMLGenerator().generateXml(soggettoId, pdfTable);
		} catch (final XMLGeneratorException e) {
			log4Debug.warnStackTrace(e);
			throw new DatiFiscaliDiscriminatorException(e.getMessage());
		}
    }

    public void createDatiPrivacyPF( final Long soggettoId, final IView iView ) throws DatiPrivacyDiscriminatorException, RemoteException {
    	new PrivacyDBAccessHelper().createDatiPrivacyPF(soggettoId, iView);
    }

    public IView getDatiPrivacyPF( final Long soggettoId ) throws DatiPrivacyDiscriminatorException, RemoteException {
        return new PrivacyDBAccessHelper().getDatiPrivacyPF(soggettoId);
    }

    public void setDatiPrivacyPF( final Long soggettoId, final IView iView ) throws DatiPrivacyDiscriminatorException, RemoteException {
    	new PrivacyDBAccessHelper().setDatiPrivacyPF(soggettoId, iView);
    }

    public void createDatiPrivacyPFFiveLevel( final Long soggettoId, final IView iView ) throws DatiPrivacyDiscriminatorException, RemoteException {
        try {
        	new PrivacyFiveLevelDBAccessHelper().createDatiPrivacyPFFiveLevel(soggettoId, iView);
        } catch (final DatiPrivacyDiscriminatorException e) {
            log4Debug.warnStackTrace(e);
            this.getSessionContext().setRollbackOnly();
            throw new DatiPrivacyDiscriminatorException(e.getMessage());
        }
    }

    public IView getDatiPrivacyPFFiveLevel( final Long soggettoId ) throws DatiPrivacyDiscriminatorException, RemoteException {
        return new PrivacyFiveLevelDBAccessHelper().getDatiPrivacyPFFiveLevel(soggettoId);
    }

    public void setDatiPrivacyPFFiveLevel( final Long soggettoId, final IView iView ) throws DatiPrivacyDiscriminatorException, RemoteException {
        try {
        	new PrivacyFiveLevelDBAccessHelper().setDatiPrivacyPFFiveLevel(soggettoId, iView);
        } catch (final DatiPrivacyDiscriminatorException e) {
        	log4Debug.warnStackTrace(e);
            this.getSessionContext().setRollbackOnly();
            throw new DatiPrivacyDiscriminatorException(e.getMessage());
        }
    }

    public void createAttributiTramite( final Long soggettoId, final IView iView ) throws AttributiEsterniDiscriminatorException, RemoteException  {
        try {
        	new AttributiTramiteUpdateHelper().createAttributiTramite(soggettoId, iView);
        } catch (final AttributiEsterniDiscriminatorException e) {
        	log4Debug.warnStackTrace(e);
            this.getSessionContext().setRollbackOnly();
            throw new AttributiEsterniDiscriminatorException(e.getMessage());
        }
    }

    public void setAttributiTramite( final Long soggettoId, final AttributiTramiteAZView iView ) throws AttributiEsterniDiscriminatorException, RemoteException {
        try {
        	new AttributiTramiteUpdateHelper().setAttributiTramite(soggettoId, iView);
        } catch (final AttributiEsterniDiscriminatorException e) {
        	log4Debug.warnStackTrace(e);
            this.getSessionContext().setRollbackOnly();
            throw new AttributiEsterniDiscriminatorException(e.getMessage());
        }
    }

    public void createEvento( final Long soggettoId, final SoggettoEventoView soggettoEventoView ) throws EventoDiscriminatorException, RemoteException {
    	new EventiDBAccessHelper().createEvento(soggettoId, soggettoEventoView);
    }

    public Collection getEvento( final Long soggettoId ) throws EventoDiscriminatorException, RemoteException {
        return new EventiDBAccessHelper().getEvento(soggettoId);
    }

    public void setEvento( final Long soggettoId, final SoggettoEventoView soggettoEventoView ) throws EventoDiscriminatorException, RemoteException {
    	new EventiDBAccessHelper().setEvento(soggettoId, soggettoEventoView);
    }

    public void deleteEvento( final Long soggettoId, final Collection eventIds ) throws EventoDiscriminatorException, RemoteException {
    	new EventiDBAccessHelper().deleteEvento(soggettoId, eventIds);
    }

    public void updateEvento( final Long soggettoId, final Hashtable eventiHash, final Collection eventiIds, final Long opId ) throws EventoDiscriminatorException, RemoteException {
        try {
        	new EventiDBAccessHelper().updateEvento(soggettoId, eventiHash, eventiIds, opId);
        } catch (final EventoDiscriminatorException e) {
        	log4Debug.warnStackTrace(e);
            this.getSessionContext().setRollbackOnly();
            throw new EventoDiscriminatorException(e.getMessage());
        }
    }

    public void createRecapiti( final Long soggettoId, final SoggettoRecapitiView soggettoRecapitiView ) throws RecapitiDiscriminatorException, RemoteException {
    	new RecapitiDBAccessHelper().createRecapiti(soggettoId, soggettoRecapitiView);
    }

    public void setRecapiti( final Long soggettoId, final SoggettoRecapitiView soggettoRecapitiView ) throws RecapitiDiscriminatorException, RemoteException {
    	new RecapitiDBAccessHelper().setRecapiti(soggettoId, soggettoRecapitiView);
    }

    public Collection getRecapiti( final Long soggettoId ) throws RecapitiDiscriminatorException, RemoteException {
        return new RecapitiDBAccessHelper().getRecapiti(soggettoId);
    }

    public void deleteRecapiti( final Long soggettoId, final Collection recapitiIds, final Long opId ) throws RecapitiDiscriminatorException, RemoteException {
    	new RecapitiDBAccessHelper().deleteRecapiti(soggettoId, recapitiIds, opId);
    }

    public void createAttributiEsterniPF( final Long soggettoId, final IView iView ) throws AttributiEsterniDiscriminatorException, RemoteException {
    	new AttributiEsterniDBAccessHelper().createAttributiEsterniPF(soggettoId, iView);
    }

    public IView getAttributiEsterniPF( final Long soggettoId ) throws AttributiEsterniDiscriminatorException, RemoteException, ClassNotFoundException {
        return new AttributiEsterniDBAccessHelper().getAttributiEsterniPF(soggettoId);
    }

    public IView getAttributiTramiteAZView( final Long soggettoId )  throws AttributiEsterniDiscriminatorException, RemoteException {
    	return new AttributiTramiteDBAccessHelper().getAttributiTramiteAZView(soggettoId);
    }

    public void setAttributiEsterniPF( final Long soggettoId, final IView iView ) throws AttributiEsterniDiscriminatorException, RemoteException {
    	new AttributiEsterniDBAccessHelper().setAttributiEsterniPF(soggettoId, iView);
    }

    public void setAttributiEsterniValues( final Long soggettoId, final String value, final String causale, final Long opId ) throws AttributiEsterniDiscriminatorException, RemoteException {
    	new AttributiEsterniDBAccessHelper().setAttributiEsterniValues(soggettoId, value, causale, opId);
    }

    public Collection findByStato( final Collection soggettiIdColl, final String stato ) throws AttributiEsterniDiscriminatorException, RemoteException {
        return new AttributiEsterniDBAccessHelper().findByStato(soggettiIdColl, stato);
    }

    public void createAltriTipoSoggetto( final Long soggettoId, final AltriSoggettoView altriSoggettoView ) throws CreateException, RemoteException {
    	new AltriSoggettiHandler().createAltriTipoSoggetto(soggettoId, altriSoggettoView);
    }

    public AltriSoggettoView getAltriTipoSoggetto( final Long id ) throws FinderException, RemoteException {
        return new TipoSoggettoHandler().getAltriTipoSoggetto(id);
    }

    public void setAltriTipoSoggetto( final AltriSoggettoView altriSoggettoView ) throws FinderException, RemoteException {
    	new AltriSoggettiHandler().setAltriTipoSoggetto(altriSoggettoView);
    }

    public AltriSoggettoView findByDenominazione( final String Denominazione ) throws FinderException, RemoteException {
        return new AltriSoggettiHandler().findByDenominazione(Denominazione);
    }

    public void createDatiAnagraficiPF( final Long soggettoId, final IView iView ) throws DatiAnagraficiDiscriminatorException, RemoteException {
    	new DatiAnagraficiPFUpdateHelper().createDatiAnagraficiPF(soggettoId, iView);
    }

    public void setDatiAnagraficiPF( final Long soggettoId, final IView iView ) throws DatiAnagraficiDiscriminatorException, RemoteException {
    	new DatiAnagraficiPFUpdateHelper().setDatiAnagraficiPF(soggettoId, iView);
    }

    public Collection findByDatiAnagraficiPF( final DatiAnagraficiPFView datiAnagraficiPFView ) throws DatiAnagraficiDiscriminatorException, RemoteException {
        return new DatiAnagraficiFinderHelper().findByDatiAnagraficiPF(datiAnagraficiPFView);
    }

    //This is the method which is being callded from RicercaResultPFView
    public DatiAnagraficiPFView getDatiAnagraficiPF( final Long soggettoId ) throws DatiAnagraficiDiscriminatorException, RemoteException {
        return new DatiAnagraficiGetterHelper().getDatiAnagraficiPF(soggettoId);
    }

    public Collection getCompatibleTipoRecapiti( final String tipoSoggettoSecondLevelName ) throws RemoteException {
        return new CompatibilityHelper().getCompatibleTipoRecapiti(tipoSoggettoSecondLevelName);
    }

    public Collection getCompatibleTipoEventi( final String tipoSoggettoSecondLevelName ) throws RemoteException {
        return new EventiDBAccessHelper().getCompatibleTipoEventi(tipoSoggettoSecondLevelName);
    }

    public Collection getCompatibleTipoSocieta( final Long tipoSoggettoId ) throws RemoteException {
        return new CompatibilityHelper().getCompatibleTipoSocieta(tipoSoggettoId);
    }

    public Collection getCompatibleTipoDocumeni( final String tipoSoggettoSecondLevelName ) throws RemoteException {
        return new DocumentiDBAccessHelper().getCompatibleTipoDocumeni(tipoSoggettoSecondLevelName);
    }

    public Collection getCompatibleAttributiEsterni( final String tipoSoggetto ) throws RemoteException {
        return new CompatibilityHelper().getCompatibleAttributiEsterni(tipoSoggetto);
    }

    public void createDocumentoPF( final Long soggettoId, final IView iView ) throws DocumentoDiscriminatorException, RemoteException {
        new DocumentiDBAccessHelper().createDocumentoPF(soggettoId, iView);
    }
    public void setDocumenti(final Long soggettoId,final Collection documentiCollection,final ClassificazioneView modalita) throws GestoreAnagrafeException, RemoteException
    {
    	new DocumentServiceManager().createDocumento(soggettoId, documentiCollection,modalita);
    }

    public Collection getDocumentoPF( final Long soggettoId ) throws DocumentoDiscriminatorException, RemoteException {
        return new DocumentiDBAccessHelper().getDocumentoPF(soggettoId);
    }

    public void deleteDocumentoPF( final Long soggettoId, final Collection documentoIds, final Long opId ) throws DocumentoDiscriminatorException, RemoteException {
        new DocumentiDBAccessHelper().deleteDocumentoPF(soggettoId, documentoIds, opId);
    }

    public void setDocumentoPF( final Long soggettoId, final IView iView ) throws DocumentoDiscriminatorException, RemoteException {
        new DocumentiDBAccessHelper().setDocumentoPF(soggettoId, iView);
    }

    public Long createCollegamento( final CollegamentoView collegamentoView ) throws CollegamentoException, RemoteException {
        return new CollegamentoCreateHelper().createCollegamento(collegamentoView);
    }

    public Collection listCollegamento( final Long soggettoPrincipaleId ) throws CollegamentoException, RemoteException {
        return new CollegamentoDBAccessHelper().listCollegamento(soggettoPrincipaleId);
    }

    public Collection listForPrincipalAndLinked( final Long principalId, final Long linkedId ) throws CollegamentoException, RemoteException {
        return new CollegamentoDBAccessHelper().listForPrincipalAndLinked(principalId, linkedId);
    }
 
    public Collection listCollegamento( final Long soggettoId, final Long motivoCollegamento ) throws CollegamentoException, RemoteException {
        return new CollegamentoDBAccessHelper().listCollegamento(soggettoId, motivoCollegamento);
    }

    public void gestoreCollegamento( final Long principaleSoggettoId, final Collection existCollIds, final String motiv, final Long opId ) throws CollegamentoException, RemoteException {
        new CollegamentoDBAccessHelper().gestoreCollegamento(principaleSoggettoId, existCollIds, motiv, opId);
    }

    public List listCollegamento( final Long linkedSoggettoId, final String motivoCollegamento ) throws CollegamentoException, RemoteException {
    	return new CollegamentoDBAccessHelper().listCollegamento( linkedSoggettoId, motivoCollegamento );
    }

    public void setCollegamento( final Long linkedSoggettoId, final Timestamp dataFine, final Long opId ) throws CollegamentoException, RemoteException {
    	new CollegamentoDBAccessHelper().setCollegamento(linkedSoggettoId, dataFine,opId);
    }

    public void setCollegamento( final Long linkedSoggettoId, final Timestamp dataFine, final Collection motiv, final Long opId ) throws CollegamentoException, RemoteException {
    	new CollegamentoDBAccessHelper().setCollegamento(linkedSoggettoId, dataFine, motiv,opId);
    }

    public void modifyCollegamento( final Long id, final it.sella.anagrafe.CollegamentoView collegamentoView ) throws CollegamentoException, RemoteException {
    	new CollegamentoDBAccessHelper().modifyCollegamento(id, collegamentoView);
    }

    public void setCollegamento( final Long principaleId, final Long linkedSoggettoId, final Timestamp dataFine, final String motiv, final Long opId, final String note ) throws CollegamentoException, RemoteException {
    	new CollegamentoDBAccessHelper().setCollegamento(principaleId, linkedSoggettoId, dataFine, motiv, opId, note);
    }

    public Collection getSoggettiColleganti( final Long linkedSoggettoId ) throws CollegamentoException, RemoteException {
        return new CollegamentoPrincipaleGetterHelper().getSoggettiColleganti(linkedSoggettoId);
    }

    public Collection getSoggettoCollegante( final Long linkedSoggettoId, final String motivoCollegamento ) throws CollegamentoException, RemoteException {
        return new CollegamentoPrincipaleGetterHelper().getSoggettoCollegante(linkedSoggettoId, motivoCollegamento);
    }

    public Collegamento getColleganteMotivoAndLinked( final Long principaleId, final String motivoCollegamento, final Long linkedSoggettoId ) throws CollegamentoException, RemoteException {
        return new CollegamentoDBAccessHelper().getColleganteMotivoAndLinked(principaleId, motivoCollegamento, linkedSoggettoId);
    }

    public Long getPrincipaleForSoggettiColleganti( final Collection linkedSoggettoIds, final String motivoCollegamento ) throws CollegamentoException, RemoteException {
        return new CollegamentoDBAccessHelper().getPrincipaleForSoggettiColleganti(linkedSoggettoIds, motivoCollegamento);
    }

    public void setCodiceValues( final Long soggettoId, final String value, final String causale, final Long opId ) throws CodiceSoggettoDiscriminatorException, RemoteException {
        new CodiceSoggettoDBAccessHelper().setCodiceValues(soggettoId, value, causale, opId);
    }

    public void setCap( final CAP cap ) throws OperazioneAnagrafeManagerException, RemoteException {
    	new CapTableHandler().setCap(cap);
    }

    public void setCitta( final Citta citta ) throws OperazioneAnagrafeManagerException, RemoteException {
    	new CittaDBAccessHelper().setCitta(citta);
    }

    public void createCitta( final Citta citta ) throws OperazioneAnagrafeManagerException, RemoteException {
    	new CittaDBAccessHelper().createCitta(citta);
    }

    //added by pals
    public void setRamo( final Ramo ramo ) throws OperazioneAnagrafeManagerException, RemoteException {
    	new RamoDBAccessHelper().setRamo(ramo);
    }

    public void createRamo( final Ramo ramo ) throws OperazioneAnagrafeManagerException, RemoteException {
    	new RamoDBAccessHelper().createRamo(ramo);
    }

    public void removeRamo( final Long ramoPKID ) throws OperazioneAnagrafeManagerException, RemoteException {
        new RamoDBAccessHelper().removeRamo(ramoPKID);
    }

    public void createLog( final LogView logView ) throws RemoteException, OperazioneAnagrafeManagerException {
    	new LogDBAccessHelper().createLog(logView);
    }

    public Collection getLog( final Long soggettoId ) throws RemoteException, OperazioneAnagrafeManagerException {
        return new LogDBAccessHelper().getLog(soggettoId, "I", "M");
    }

    public void setNazione( final NazioneView nazioneView ) throws OperazioneAnagrafeManagerException, RemoteException {
    	new NazioneDBAccessHelper().setNazione(nazioneView);
    }

    public void createNazione( final NazioneView nazioneView ) throws OperazioneAnagrafeManagerException, RemoteException {
    	new NazioneDBAccessHelper().createNazione(nazioneView);
    }

    public void deleteCollegamento( final Collection collegamentoViews, final String action, final Long opId ) throws CollegamentoException, RemoteException {
    	new CollegamentoDBAccessHelper().deleteCollegamento(collegamentoViews, action, opId);
    }

    public void updateSconfWithHost( final Long soggettoId, final String newSconfValue, final String codiceHost, final Long opId ) throws OperazioneAnagrafeManagerException, RemoteException {
        try {
        	new AttributiEsterniDBAccessHelper().updateSconfWithHost(soggettoId, newSconfValue, codiceHost, opId,true);
        } catch (final OperazioneAnagrafeManagerException e) {
            this.getSessionContext().setRollbackOnly();
            log4Debug.warnStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage());
        }
    }

    public String mergeAnagraficDetails( final Long soggettoIdExisting, final Long soggettoIdDuplicate ) throws RemoteException, OperazioneAnagrafeManagerException {
        try {
            return new PF_merge_Helper().mergeAnagraficDetails(soggettoIdExisting, soggettoIdDuplicate);
        } catch (final OperazioneAnagrafeManagerException e) {
            this.getSessionContext().setRollbackOnly();
            log4Debug.warnStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage());
        }
    }

    public Collection getCompatibleTipoIntermediari() throws OperazioneAnagrafeManagerException, RemoteException {
    	return new CompatibilityHelper().getCompatibleTipoIntermediari();
    }

    public void updateDaiForPrincipalIds( final Long pfSoggettoId, final boolean oldDai, final boolean newDai, final Long opId ) throws OperazioneAnagrafeManagerException, RemoteException {
    	new AttributiEsterniDBAccessHelper().updateDaiForPrincipalIds(pfSoggettoId, oldDai, newDai, opId);
    }

    public void updateBollinoBluWithHost( final Long soggettoId, final String bollinoValue, final String codiceHost, final Long opId ) throws AttributiEsterniDiscriminatorException, RemoteException {
        try {
        	new AttributiEsterniDBAccessHelper().updateBollinoBluWithHost(soggettoId, bollinoValue, codiceHost, opId,true);
        } catch (final AttributiEsterniDiscriminatorException e) {
        	log4Debug.warnStackTrace(e);
            this.getSessionContext().setRollbackOnly();
            throw new AttributiEsterniDiscriminatorException(e.getMessage());
        }
    }

    public Collection isExistsDocumento( final DocumentoPFView documentoPFView ) throws DocumentoDiscriminatorException, RemoteException {
        return new DocumentiDBAccessHelper().isExistsDocumento(documentoPFView);
    }

    public Collection getLogForSoggettoAndProductID( final Long soggettoId ) throws OperazioneAnagrafeManagerException, RemoteException {
        return new LogDBAccessHelper().getLogForSoggettoAndProductID(soggettoId);
    }
    // Added by Durai to get Ultima Modifica DOMKO in Address Page
    public Collection getLogForDOMKO( final Long soggettoId ) throws OperazioneAnagrafeManagerException, RemoteException {
        return new LogDBAccessHelper().getLogDOMKO(soggettoId);
    }


    public String updateAmministratoriBanca( final Long soggettoId, final ClassificazioneView classificazioneView,
    		final String codiceHost, final Collection existingCausales, final Long opId ) throws OperazioneAnagrafeManagerException, RemoteException {
        try {
        	return new AmministratoriBancaUpdateHelper().updateAmministratoriBanca(soggettoId, classificazioneView, codiceHost, existingCausales, opId,true);
        } catch (final OperazioneAnagrafeManagerException e) {
        	log4Debug.warnStackTrace(e);
            this.getSessionContext().setRollbackOnly();
            throw new OperazioneAnagrafeManagerException(e.getMessage());
        }
    }

    public void updateAmministratoriBancaInHost( final UpdateAMMBAScanView updateAMMBAScanView, final String hostUserCode ) throws OperazioneAnagrafeManagerException, RemoteException {
    	new AmministratoriBancaUpdateHelper().updateAmministratoriBancaInHost( updateAMMBAScanView, hostUserCode,true);
    }

    public List getExtractArt136() throws OperazioneAnagrafeManagerException, RemoteException {
    	return new AmministratoriBancaGetterHelper().getExtractArt136();
    }


    public void createExtractArt136( final List ammbaLinkList ) throws OperazioneAnagrafeManagerException, RemoteException {
   	 	new AmministratoriBancaSetterHelper().createExtractArt136( ammbaLinkList );
   }

    public void deleteAllExtractArt136() throws OperazioneAnagrafeManagerException, RemoteException {
   	 	new AmministratoriBancaSetterHelper().deleteAllExtractArt136();
   }

    public List getAllExtendArt136Scan() throws OperazioneAnagrafeManagerException, RemoteException {
    	return new AmministratoriBancaGetterHelper().getAllExtendArt136Scan();
    }

    public void createExtendArt136Scan() throws OperazioneAnagrafeManagerException, RemoteException {
    	new AmministratoriBancaSetterHelper().createExtendArt136Scan();
    }

    public void updateExtendArt136ScanStatus( final UpdateAMMBAScanView updateAMMBAScanView ) throws OperazioneAnagrafeManagerException, RemoteException {
    	new AmministratoriBancaSetterHelper().updateExtendArt136ScanStatus( updateAMMBAScanView );
    }


	public Long createLogHOSTCall( final LogHostCallView logHostCallView ) throws OperazioneAnagrafeManagerException, RemoteException {
		try {
			return new LogDBAccessHelper().createLogHOSTCall(logHostCallView);
		} catch (final HostLoggerException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
	}

	public void createLogHOSTOperationData( final LogOperationDataView logOperationDataView ) throws OperazioneAnagrafeManagerException, RemoteException {
		try {
			new LogDBAccessHelper().createLogHOSTOperationData(logOperationDataView);
		} catch (final HostLoggerException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
	}

    public void updateAnagrafeLog( final Long operationId, final Long soggettoId, final String errorMessage ) throws OperazioneAnagrafeManagerException, RemoteException {
    	try {
			new HostLogHelper().updateAnagrafeLog(operationId, soggettoId, errorMessage);
		} catch (final HostLoggerException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
    }

    public void updateAnagrafeLog( final Long operationId, final Long soggettoId ) throws OperazioneAnagrafeManagerException, RemoteException {
    	try {
    		new HostLogHelper().updateAnagrafeLog(operationId, soggettoId);
		} catch (final HostLoggerException e) {
			log4Debug.warnStackTrace(e);
			throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
    }

    public void createCodiciSoggettoCifrati( final Long soggettoId, final String valoreCodiceHost, final Long opId ) throws CodiceSoggettoDiscriminatorException, RemoteException {
    	new CodiceSoggettoDBAccessHelper().createCodiciSoggettoCifrati(soggettoId,valoreCodiceHost,opId);
    }

    public void setCodiceSoggettoCifratiValues( final Long soggettoId, final String newValoreCodiceHost, final Long opId ) throws CodiceSoggettoDiscriminatorException, RemoteException {
    	new CodiceSoggettoDBAccessHelper().setCodiceSoggettoCifratiValues(soggettoId,newValoreCodiceHost,opId);
    }

    public void removeCodiceSoggettoCifrati( final Long soggettoId, final Long opId ) throws CodiceSoggettoDiscriminatorException, RemoteException {
    	new CodiceSoggettoDBAccessHelper().removeCodiceSoggettoCifrati(soggettoId, opId);
    }

    public Collection getDocEventi( final Long soggettoId ) throws ControlloDatiException , RemoteException  {
        return new DocEventiDBAccessHelper().getDocEventi(soggettoId);
    }

    public void insertDocEventi( final DocEventiView docEventiView ) throws ControlloDatiException , RemoteException {
    	new DocEventiDBAccessHelper().insertDocEventi(docEventiView);
    }

    public void modifiyDocEventi( final DocEventiView docEventiView ) throws ControlloDatiException , RemoteException {
    	new DocEventiDBAccessHelper().modifiyDocEventi(docEventiView);
    }

    public void removeDocEventi( final DocEventiView docEventiView ) throws ControlloDatiException ,RemoteException  {
    	new DocEventiDBAccessHelper().removeDocEventi(docEventiView);
    }

    public void createDipctAlignDetails( final DipctAlignDetailsView dipctAlignDetailsView ) throws DIPCTAlignFailException, RemoteException {
    	new DipctAlignDBAccessHelper().createDipctAlignDetails(dipctAlignDetailsView);
    }

    public Collection getDipctAlignDetails( final String fromCoddp ) throws DIPCTAlignFailException, RemoteException {
        return new DipctAlignDBAccessHelper().getDipctAlignDetails(fromCoddp);
    }

    public void updateDipctAlignDetails( final DipctAlignDetailsView dipctAlignDetailsView ) throws DIPCTAlignFailException, RemoteException {
    	new DipctAlignDBAccessHelper().updateDipctAlignDetails(dipctAlignDetailsView);
    }

    public void removeDipctAlignDetails( final DipctAlignDetailsView dipctAlignDetailsView ) throws DIPCTAlignFailException, RemoteException {
    	new DipctAlignDBAccessHelper().removeDipctAlignDetails(dipctAlignDetailsView);
    }

    public void transferConto( final TransferContoView transferContoView, final Long opId ) throws OperazioneAnagrafeManagerException, RemoteException {
    	String socketMessage = null;
        try {
            //GestoreContiFactory.getInstance().getGestoreConti().updateSoggettoCollegato(transferContoView.getSoggettoIdFrom(), transferContoView.getSoggettoIdTo());
            new AcfwHandler().updateSoggettoCollegato(transferContoView.getSoggettoIdFrom(), transferContoView.getSoggettoIdTo());
            //AddressManagerFactory.getInstance().getAddressManager().updateSoggetto(transferContoView.getSoggettoIdFrom(), transferContoView.getSoggettoIdTo(), opId);
            new AddressHandler().updateSoggetto(transferContoView.getSoggettoIdFrom(), transferContoView.getSoggettoIdTo(), opId);
            //IntestatazioneManagerFactory.getInstance().getIntestatazioneManager().updateSoggetto(transferContoView.getSoggettoIdFrom(), transferContoView.getSoggettoIdTo());
            new IntestatazioneHandler().updateSoggetto(transferContoView.getSoggettoIdFrom(), transferContoView.getSoggettoIdTo());
            updateCodiceHost(transferContoView.getSoggettoIdFrom(),transferContoView.getNewCodiceHostDa(),transferContoView.getExistingCodiceHostDa(), opId);
            updateCodiceHost(transferContoView.getSoggettoIdTo(),transferContoView.getNewCodiceHostA(),transferContoView.getExistingCodiceHostA(), opId);
            socketMessage = new TransferContoSocketHelper().performTransferContoSH( transferContoView, opId);
        } catch (final OperazioneAnagrafeManagerException e) {
            log4Debug.warnStackTrace(e);
            this.getSessionContext().setRollbackOnly();
            throw new OperazioneAnagrafeManagerException(e.getMessage());
        } catch (final SubSystemHandlerException e) {
            log4Debug.warnStackTrace(e);
            this.getSessionContext().setRollbackOnly();
            throw new OperazioneAnagrafeManagerException(e.getMessage());
        } catch (final SocketHelperException e) {
            log4Debug.warnStackTrace(e);
            this.getSessionContext().setRollbackOnly();
            throw new OperazioneAnagrafeManagerException(e.getMessage());
        } finally {
        	if( socketMessage != null && socketMessage.trim().length() > 0 ) {
        		updateAnagrafeLog(opId, transferContoView.getSoggettoIdFrom(), socketMessage);
        	}
        }
    }

    public void setSocketRollBackLog( final SocketRBLogOperationDataView socketRBLogOperationDataView ) throws OperazioneAnagrafeManagerException, RemoteException {
    	try {
			new SocketRBOperationSetterHelper().setSocketRollBackLog(socketRBLogOperationDataView);
		} catch (final SocketHelperException e) {
            log4Debug.warnStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
    }

    public List getSocketRollBackLog( final Hashtable searchCriteria ) throws OperazioneAnagrafeManagerException, RemoteException {
    	return new SocketRBOperationGetterHelper().getSocketRollBackLog(searchCriteria);
    }

    public SocketRBLogOperationDataView getSocketRollBackLog( final Long socketPKId ) throws OperazioneAnagrafeManagerException, RemoteException {
    	return new SocketRBOperationGetterHelper().getSocketRollBackLog(socketPKId);
    }

    public void updateSocketRollBackLog( final SocketRBLogOperationDataView socketRBLogOperationDataView ) throws OperazioneAnagrafeManagerException, RemoteException {
    	try {
    		new SocketRBOperationSetterHelper().updateSocketRollBackLog(socketRBLogOperationDataView);
		} catch (final SocketHelperException e) {
            log4Debug.warnStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
    }

    public List getAllSocketRollBackLogStatus() throws OperazioneAnagrafeManagerException, RemoteException {
    	return new SocketRBOperationGetterHelper().getAllSocketRollBackLogStatus();
    }

    public void removeSocketRBLog( final Long socketRBPKId )  throws OperazioneAnagrafeManagerException, RemoteException {
    	try {
			new SocketRBOperationSetterHelper().removeSocketRBLog(socketRBPKId);
		} catch (final SocketHelperException e) {
			log4Debug.warnStackTrace(e);
			throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
    }

    public void writeSocketRBLogMessage( final Long rollBackPKID, final Long bankSoggettoId, final Long opId,  final String socketMessage) throws OperazioneAnagrafeManagerException, RemoteException {
    	try {
			new SocketRBOperationSetterHelper().writeSocketRBLogMessage(rollBackPKID, bankSoggettoId, opId, socketMessage);
		} catch (final SocketHelperException e) {
			log4Debug.warnStackTrace(e);
			throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
	}

    public Long performCensimentoAndBusta( final SoggettoView soggettoView, final Hashtable stampaTable ) throws OperazioneAnagrafeManagerException, RemoteException {
    	Long soggettoId = null;
		try {
			soggettoId = AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().performCensimento(soggettoView);
			soggettoView.setId(soggettoId);
			BustaHelper.getInstance().bustaCheck( soggettoView, stampaTable);
			new SoggettiPromtoreUtil().setSoggettiPromtore(soggettoView, false);
		} catch (final OperazioneCensimentoException e) {
			log4Debug.warnStackTrace(e);
			if ( stampaTable != null ) {
				stampaTable.put("MAPPER_ERROR",e.getMessage());
			}
			throw new OperazioneAnagrafeManagerException(e.getMessage());
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new OperazioneAnagrafeManagerException(e.getMessage());
		}catch (final SoggettiPromotoreException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
    	return soggettoId;
    }

    public void performCensimentoModificaAndBusta( final SoggettoView soggettoView, final Hashtable stampaTable ) throws OperazioneAnagrafeManagerException, RemoteException {
		try {
			AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().performCensimentoModifica(soggettoView);
			BustaHelper.getInstance().bustaCheck( soggettoView, stampaTable);
			new SoggettiPromtoreUtil().setSoggettiPromtore(soggettoView, true);
		} catch (final OperazioneCensimentoException e) {
			log4Debug.warnStackTrace(e);
			if ( stampaTable != null ) {
				stampaTable.put("MAPPER_ERROR",e.getMessage());
			}
			throw new OperazioneAnagrafeManagerException(e.getMessage());
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new OperazioneAnagrafeManagerException(e.getMessage());
		}catch (final SoggettiPromotoreException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
    }

    public String getMessage( final String errorCode ) throws OperazioneAnagrafeManagerException, RemoteException {
		String errorMessage = null;
		try {
			errorMessage = new MessageManagerHandler().getMessage(errorCode);
		} catch (final SubSystemHandlerException e) {
			errorMessage = e.getMessage();
		}
		return errorMessage;
    }

    public Long getLoginSoggettoId() throws OperazioneAnagrafeManagerException, RemoteException {
    	try {
			return SecurityHandler.getLoginSoggettoId();
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
    }

    public void logMessageForAnagrafeManager( final Long soggettoId, final String operation, final String data, final String operationCode, final boolean operationSuccess ) throws OperazioneAnagrafeManagerException, RemoteException {
    	try {
			it.sella.anagrafe.util.Log.logMessageForAnagrafeManager(soggettoId, operation, data, operationCode, operationSuccess);
		} catch (final LoggerException e) {
			log4Debug.warnStackTrace(e);
			throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
    }

    public List getAllOperationCode() throws OperazioneAnagrafeManagerException, RemoteException {
    	try {
			return new HostLogHelper().getAllAnagrafeOperationCode();
		} catch (final HostLoggerException e) {
			log4Debug.warnStackTrace(e);
			throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
    }

    public List getAllMigrationPKId() throws OperazioneAnagrafeManagerException, RemoteException {
    	try {
			return new MigrationDBAccessHelper().getAllMigrationPKId();
		} catch (final MigrationException e) {
			log4Debug.warnStackTrace(e);
			throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
    }

    public String getMigrationInputData( final Long pkId ) throws OperazioneAnagrafeManagerException, RemoteException {
    	try {
			return new MigrationDBAccessHelper().getMigrationInputData(pkId);
		} catch (final MigrationException e) {
			log4Debug.warnStackTrace(e);
			throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
    }

    public void setMigrationStatus( final Long pkId, final String statusValue, final String errorMessage, final Long soggettoId, final String outputData ) throws OperazioneAnagrafeManagerException, RemoteException {
    	try {
			new MigrationDBAccessHelper().setMigrationStatus(pkId, statusValue, errorMessage, soggettoId, outputData);
		} catch (final MigrationException e) {
			log4Debug.warnStackTrace(e);
			throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
    }

    public void addMigrationData( final Long bankSoggettoId, final List migrationData , final String  errorDesc ) throws OperazioneAnagrafeManagerException, RemoteException {
  	  try {
  		  new MigrationDBAccessHelper().addMigrationData( bankSoggettoId, migrationData, errorDesc );
  	  } catch (final MigrationException e) {
		 log4Debug.warnStackTrace(e);
		 throw new OperazioneAnagrafeManagerException(e.getMessage());
	  }
    }

    public String getMigratedData( final String tipoSoggetto ) throws OperazioneAnagrafeManagerException ,RemoteException {
  	  try {
  		  return new MigrationDBAccessHelper().getMigratedData(tipoSoggetto);
  	  } catch (final MigrationException e) {
  		  log4Debug.warnStackTrace(e);
  		  throw new OperazioneAnagrafeManagerException(e.getMessage());
  	  }
    }

    public void clearMigrationData( final String deleteType ) throws OperazioneAnagrafeManagerException ,RemoteException {
  	  try {
  		  new MigrationDBAccessHelper().clearMigrationData(deleteType);
  	  } catch (final MigrationException e) {
  		  log4Debug.warnStackTrace(e);
  		  throw new OperazioneAnagrafeManagerException(e.getMessage());
  	  }
    }

    public String getExistSoggettoOutputData( final Long soggettoId, final Long bankId ) throws OperazioneAnagrafeManagerException, RemoteException {
    	  try {
      		  return new MigrationDBAccessHelper().getExistSoggettoOutputData(soggettoId, bankId);
      	  } catch (final MigrationException e) {
      		  log4Debug.warnStackTrace(e);
      		  throw new OperazioneAnagrafeManagerException(e.getMessage());
      	  }
    }

    public void setClienteClassificazione(final ClienteClassificazioneView clienteClassificazioneView,
    		final FatturatoView fatturatoView ,final Hashtable detailsTable)
    throws RemoteException,OperazioneAnagrafeManagerException {
		try {
			new ClienteClassificazioneDBAccessHelper().setClienteClassificazione(clienteClassificazioneView);
			log4Debug.info("Microimpresa : ",clienteClassificazioneView.getMicroimpresa());
			new FatturatoDBAccessHelper().setFatturato(fatturatoView , detailsTable);
		} catch (final GestoreAnagrafeException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
	}

    public void logMessageWithErrorMsg( final Long soggettoId, final String operation, final String data, final String operationCode, final boolean operationSuccess , final String errorMessage ) throws OperazioneAnagrafeManagerException, RemoteException {
    	try {
			it.sella.anagrafe.util.Log.logMessageWithErrorMsg(soggettoId, operation, data, operationCode, operationSuccess,errorMessage);
		} catch (final LoggerException e) {
			log4Debug.warnStackTrace(e);
			throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
    }
    private void updateCodiceHost( final Long soggettoId, final String newCodiceHost,
    		final String oldCodiceHost, final Long opId ) throws OperazioneAnagrafeManagerException, RemoteException {
        try {
            if (newCodiceHost != null && newCodiceHost.trim().length() > 0 && !newCodiceHost.equals(oldCodiceHost)) {
                setCodiceValues(soggettoId, newCodiceHost, "codiceHost", opId);
            }
        } catch (final CodiceSoggettoDiscriminatorException e) {
        	log4Debug.warnStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage());
        }
    }

    public List<CompDocumentView> getPFCompDocumentList( final Long bankId,final boolean isValid ) throws OperazioneAnagrafeManagerException, RemoteException {
    	try {
			return new DocumentiDBAccessHelper().getPFCompDocumentList(bankId,isValid);
		} catch (final GestoreAnagrafeException e) {
			log4Debug.warnStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
    }


    /**
     * Method to create Soggetto by passing ID which contains XML data for persisting in a particular bank (BPA)
     * @param soggettoPromotoreId
     * @param operationCode
     * @return
     * @throws OperazioneAnagrafeManagerException
     * @throws RemoteException
     */
    public String createSoggettoFromXMLForBPA(final Long soggettoPromotoreId, final String operationCode) throws OperazioneAnagrafeManagerException, RemoteException
    {
    	final ICensimentoAutomaticoDAO ibpaDAO = new CensimentoAutomaticoImpl();
    	String censimentoXML = "";
    	String outputSuccessOrErrormessage = null ;
    	final StringBuffer output = new StringBuffer();
    	String errorMessage = null;
    	String soggettoString = null;
    	final String operation = "CENSITO";
    	Long bpaSoggettoId = null;
    	Long opId = null;
    	try {
    		opId = new AnagrafeLoggerHelper().logAnagrafeOperation(null,false,operationCode,null,null);
    		log4Debug.debug("Soggetto Id : " , soggettoPromotoreId);
    		final Collection<String> xmlList = ibpaDAO.listSoggettiXMLForCensimento(soggettoPromotoreId);
    		if(!xmlList.isEmpty())
    		{
    			for (final Iterator<String> iterator = xmlList.iterator(); iterator.hasNext();) {
    				censimentoXML =  iterator.next();
    				soggettoString = null;
    				outputSuccessOrErrormessage = AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().creaSoggettoXMLForBPAAutoCens(censimentoXML);

    				if(outputSuccessOrErrormessage.indexOf("<SOGGETTO_ID>") != -1)
    				{
    					soggettoString = outputSuccessOrErrormessage.substring(outputSuccessOrErrormessage.indexOf("<SOGGETTO_ID>")+13,outputSuccessOrErrormessage.indexOf("</SOGGETTO_ID>"));
    					bpaSoggettoId = Long.valueOf(soggettoString);
    					log4Debug.debug("Created Soggetto Id : " , bpaSoggettoId);
    					new SoggettiPromtoreUtil().replaceDefaultDipctLink(bpaSoggettoId, opId);
    					output.append(outputSuccessOrErrormessage);
    				}
    				else
    				{
    					//  Need to update status as Error with error message returned "outputSuccessOrErrormessage" as ERRORE stato
    					output.append(outputSuccessOrErrormessage);
    					throw new OperazioneCensimentoException(output.toString());
    				}
    				final ISoggettiPromotoreDAO soggettiDAO = (ISoggettiPromotoreDAO) SoggettiPromotoreDAOFactory.getInstance().getSoggettiPromotoreDAOFactoryFinder();
    				final Long bsSoggettoId = soggettiDAO.getSoggettoId( soggettoPromotoreId );
    				log4Debug.debug("BS Soggetto Id : " , bsSoggettoId);
    				log4Debug.debug("BPA Soggetto Id : " , bpaSoggettoId);
    				new FatcaUpdateBPAHelper().insertFataForSoggettiPromotore(bsSoggettoId, bpaSoggettoId);
    			}
    			ibpaDAO.updateAutoCensitoStatus(soggettoPromotoreId, "", "CENSITO", null, opId);
    		}
    			
    	} catch (final LoggerException loggerException) {
    		log4Debug.warnStackTrace(loggerException);
    		errorMessage = "Failure" + loggerException.getMessage();
    	}
    	catch (final OperazioneCensimentoException e) {
    		log4Debug.warnStackTrace(e);
    		errorMessage = "Failure" + e.getMessage();
    	} catch (final SoggettiPromotoreException e) {
    		log4Debug.warnStackTrace(e);
    		errorMessage = "Failure" + e.getMessage();
    		throw new OperazioneAnagrafeManagerException(e.getMessage());
    	} finally
    	{
    		try {
    			if(errorMessage != null && errorMessage.length() > 0)
    			{
    				OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager().updateAutoCensitoStatus(soggettoPromotoreId,   errorMessage.length() > 4000 ? errorMessage.substring(0, 4000) : errorMessage, "ERRORE", null, opId);
    			}
    			final SoggettiPromtoreView soggettiPromotoreView = buildSoggettiPromtoreView(soggettoString,censimentoXML,errorMessage,opId);
    			new CensimentoAutomaticoHelper().setSecurityLog(operation, operationCode, errorMessage== null ? true : false, errorMessage,soggettiPromotoreView,null);
    		} catch (final SoggettiPromotoreException e) {
    			log4Debug.warnStackTrace(e);
    			errorMessage = "Failure" + e.getMessage();
    			log4Debug.debug("Error Message: " , errorMessage);
    			throw new OperazioneAnagrafeManagerException(e.getMessage());
    		}
    	}
    	final String outputStr = output.toString();
		log4Debug.debug("Message of Censimento: " , outputStr);
    	return outputStr;
    }

    private SoggettiPromtoreView buildSoggettiPromtoreView(final String soggettoString,final String censimentoXML, String outputSuccessOrErrormessage, final Long opId) throws SoggettiPromotoreException {
    	SoggettiPromtoreView soggettiPromotoreView = null;
    	soggettiPromotoreView = new SoggettiPromtoreView();
    	try {
    		soggettiPromotoreView.setBankId(SecurityHandler.getLoginBancaId());
    		soggettiPromotoreView.setCensimentoXML(new StringBuffer(censimentoXML));
    		if(outputSuccessOrErrormessage != null){
    			outputSuccessOrErrormessage = outputSuccessOrErrormessage.replace("<?xml version='1.0' encoding='UTF-8'?>", "");
    			soggettiPromotoreView.setErrorMsg(new StringBuffer(outputSuccessOrErrormessage));
    			soggettiPromotoreView.setStato(AdminConstants.ERRORE);
    		}
    		else{
    		soggettiPromotoreView.setStato(AdminConstants.CENSITO);
    		}
    		soggettiPromotoreView.setSoggettoId(soggettoString != null ? Long.valueOf(soggettoString) :null);
    		soggettiPromotoreView.setOpId(opId);
    		soggettiPromotoreView.setDataRiff(new AutomaticCensimentoHandler().rifDate());
    		soggettiPromotoreView.setTipoSoggetto(soggettoString != null ? new TipoSoggettoHandler().getTipoSoggetto(Long.valueOf(soggettoString)) :"");
    	} catch (final HelperException e) {
    		log4Debug.warnStackTrace(e);
    		throw new SoggettiPromotoreException(e.getMessage());
    	} catch (final GestoreSoggettoException e) {
    		log4Debug.warnStackTrace(e);
    		throw new SoggettiPromotoreException(e.getMessage());
    	} catch (final RemoteException e) {
    		log4Debug.warnStackTrace(e);
    		throw new SoggettiPromotoreException(e.getMessage());
    	} catch (final SubSystemHandlerException e) {
    		log4Debug.warnStackTrace(e);
    		throw new SoggettiPromotoreException(e.getMessage());
    	}
    	return soggettiPromotoreView;

    }

    public void updateAutoCensitoStatus(final Long soggettoPromotoreId,final String error, final String stato,final String rifDate,final Long opId) throws SoggettiPromotoreException,RemoteException{
    	new CensimentoAutomaticoImpl().updateAutoCensitoStatus(soggettoPromotoreId, error, stato, rifDate, opId);
    }

    /**
     * Session bean implementation to create Tipo soggetto
     * @param tipoView
     * @throws GestoreAnagrafeException
     * @throws RemoteException
     */
    public void createTipoSoggetto(final TipoSoggettoView tipoView) throws GestoreAnagrafeException,RemoteException {
    	new TipoSoggettoUtil().createTipoSoggetto(tipoView);
    }


    /**
     * Session bean implementation to update Tipo Soggetto
     * @param tipoView
     * @return
     * @throws GestoreAnagrafeException
     * @throws FinderException
     * @throws RemoteException
     */
    public TipoSoggetto setTipoSoggetto(final TipoSoggettoView tipoView) throws GestoreAnagrafeException, RemoteException {
    	return new TipoSoggettoUtil().setTipoSoggetto(tipoView);
    }

    public EntityManager getPersistenceEntityManager() throws NamingException,RemoteException{
    	final Context ctx = new InitialContext();
    	return (EntityManager) ctx.lookup("java:comp/env/persistence/AnagrafeEntityManager");
    }

    public Long createSellaLifeCustomer(final Long mainSoggettoId,final DatiAnagraficiAZView datiAnagraficiAZView,final Long operationId) throws OperazioneAnagrafeManagerException, RemoteException{
    	return new SellaLifeDBAccessHelper().createSoggetto(mainSoggettoId, datiAnagraficiAZView, operationId);
    }

    public String maintainTerminateSoggetto(final Long mainSoggetto,final Long terminateSoggetto,final String terminateCollegamentoLinks) throws OperazioneAnagrafeManagerException, RemoteException {
    	try {
    		final SoggettoView soggettoViewOld = AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().getSoggetto(mainSoggetto, new Properties());
    		final String codiceCifratiOld =  new CSCifratiGetterHelper().getCodiceHostCifrati(mainSoggetto);
    		final Map<String, String> outputMap = OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager().terminateSoggetto(mainSoggetto, terminateSoggetto,terminateCollegamentoLinks);
    		outputMap.put("mainSoggetto", String.valueOf(mainSoggetto));
    		outputMap.put("terminateSoggetto", String.valueOf(terminateSoggetto));
    		outputMap.put("codiceCifratiOld", codiceCifratiOld);
    		outputMap.put("terminateCollegamentoLinks", terminateCollegamentoLinks);
    		log4Debug.debug("outputMap",outputMap.get("status"));
    		final SoggettoView soggettoViewNew = AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().getSoggetto(mainSoggetto, new Properties());
    		return new TerminateSoggettoHelper().terminateSoggetto(soggettoViewOld,outputMap,soggettoViewNew);
    	} catch (final OperazioneAnagrafeManagerException e) {
    		log4Debug.warnStackTrace(e);
    		this.getSessionContext().setRollbackOnly();
    		throw new OperazioneAnagrafeManagerException(e.getMessage());
    	} catch (GestoreCodiciSoggettoException e) {
    		log4Debug.warnStackTrace(e);
    		this.getSessionContext().setRollbackOnly();
    		throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
    }
    
    public Map<String, String> terminateSoggetto(final Long mainSoggetto,final Long terminateSoggetto,final String terminateCollegamentoLinks) throws OperazioneAnagrafeManagerException, RemoteException {
    		final IDuplicateSoggettoDAO soggettoDAO = AnagrafeBeanUtil.getInstance().getBean(IDuplicateSoggettoDAO.class);
    		return soggettoDAO.maintainTerminateSoggetto(mainSoggetto, terminateSoggetto,terminateCollegamentoLinks);
    }
    
    public void logMessageToSecurity(final IAnagrafeLoggerView loggerView) throws RemoteException {
    	new Logger().logOperation(loggerView);  
    }
    
	  /**
	   * Method to update the status of createSoggettoFromXMLForBPA method invocation
	   * @param soggettoPromotoreId
	   * @param error
	   * @param stato
	   * @param rifDate
	   * @param opId
	   * @throws SoggettiPromotoreException
	   */
	   public void updateProcessedPosteStatus(final PosteCustomerView view) throws PosteException,RemoteException
	   {
		   new PosteDaoHandler().updateProcessedPosteStatus(view);
	   }
   
   /**
    * To Create CanalePreferito in Censimento
    * @param soggettoId
    * @param preferitoDataView
    * @param opId
    * @throws CanalePreferitoException
    * @throws RemoteException
    */
   public void createCanalePreferito(final Long soggettoId,final CanalePreferitoDataView preferitoDataView, final Long opId) throws CanalePreferitoException, RemoteException {
        new CanalePreferitoUpdateHelper().createCanalePreferito(preferitoDataView, opId, soggettoId);
    }
   
   /**
    * To Create / Modify CanalePreferito in Varia
    * @param soggettoId
    * @param preferitoDataView
    * @param opId
    * @throws CanalePreferitoException
    * @throws RemoteException
    */
   public void setCanalePreferito(final CanalePreferitoDataView newPreferitoDataView, final Long soggettoId, final Long opId) throws CanalePreferitoException, RemoteException {
        new CanalePreferitoUpdateHelper().setCanalePreferito(newPreferitoDataView, opId, soggettoId);
    }

   /**
    * To Get the Valid CanalePreferito Data for the given input SoggettoId
	 * @param soggettoId
	 * @return
	 * @throws CanalePreferitoException
	 * @throws RemoteException
	 */
	public CanalePreferitoDataView getValidCanalePreferitoForSoggettoId (final Long soggettoId) throws CanalePreferitoException, RemoteException {
	   return new CanalePreferitoDBAccessHelper().getValidCanalePreferitoForSoggettoId(soggettoId);
    }
	
	/**
	 * To Get the Valid CanaleUtilizzato Data for the given input SoggettoId
	 * @param soggettoId
	 * @return
	 * @throws CanalePreferitoException
	 * @throws RemoteException
	 */
	public ICanaleUtilizzatoView getValidCanaleUtilizzatoView (final Long soggettoId) throws CanalePreferitoException, RemoteException {
		return new CanalePreferitoDBAccessHelper().getCanaleUtilizzatoForSoggettoId(soggettoId);
	}
	
	/**
	 * To Create DAI Regole
	 * @param regoleDetailsView
	 * @param soggettoId
	 * @param opId
	 * @throws AnagrafeDAIException
	 * @throws RemoteException
	 */
	public void createDAIRegole (final IDAIRegoleDetailsView regoleDetailsView, final Long soggettoId, final Long opId) throws AnagrafeDAIException, RemoteException {
        new DAIDBAccessHelper().createDAIRegole(regoleDetailsView, soggettoId, opId);
    }
	
	/**
	 * To Create / Modify DAI Regole in Varia 
	 * @param regoleDetailView
	 * @param soggettoId
	 * @param opId
	 * @throws RemoteException
	 * @throws AnagrafeDAIException
	 */
	public void setDAIRegole(final IDAIRegoleDetailsView regoleDetailView, final Long soggettoId, final Long opId) throws RemoteException, AnagrafeDAIException {
		new DAIDBAccessHelper().setDAIRegole(regoleDetailView, soggettoId, opId);
	}
	
	/**
	 * To Create DAI Soggetto
	 * @param daiSoggettoView
	 * @param soggettoId
	 * @param opId
	 * @throws DAISoggettoException
	 * @throws RemoteException
	 */
	public void createDAISoggetto (final SoggettoDAIDataView daiSoggettoView, final Long soggettoId, final Long opId) throws DAISoggettoException, RemoteException {
		new DAIDBAccessHelper().createDAISoggetto(daiSoggettoView, soggettoId, opId);
    }
	
	/**
	 * To Create / Modify DAI Soggetto in Varia
	 * @param daiSoggettoViewNew
	 * @param daiSoggettoViewOld
	 * @param soggettoId
	 * @param opId
	 * @throws DAISoggettoException
	 * @throws RemoteException
	 */
	public void setDAISoggetto(final SoggettoDAIDataView daiSoggettoView, final Long soggettoId, final Long opId) throws DAISoggettoException, RemoteException {
		new DAIDBAccessHelper().setDAISoggetto(daiSoggettoView, soggettoId, opId);
    }
	
	/**
	 * To Delete DaiRegoleEntry From DAIregole table
	 * @param regoleDetailView
	 * @param soggettoId
	 * @param opId
	 * @throws DAIRegoleException
	 * @throws RemoteException
	 */
	public void removeDAIReole(final IDAIRegoleDetailsView regoleDetailView, final Long soggettoId, final Long opId) throws DAIRegoleException, RemoteException {
		new AnagrafeDAIUpdateHelper().removeDAIReole(regoleDetailView, soggettoId, opId);
	}
	
	/**
	 * TO create RecapitiNonDisponibile
	 * @param recapNonDispDetailView
	 * @param soggettoId
	 * @param opId
	 * @throws RecapitiNonDisponibileException
	 * @throws RemoteException
	 */
	public void createRecapitiNonDisponibile (final IRecapitiNonDispDetailView recapNonDispDetailView, final Long soggettoId, final Long opId) throws RecapitiNonDisponibileException, RemoteException {
		new RecapitiNonDispUpdateHelper().createRecapitiNonDisponibile(recapNonDispDetailView, soggettoId, opId);
	}
	
	/**
	 * returns valid Recapiti Non Disponibile Data for the given input soggetto
	 * @param sogggettoId
	 * @return
	 * @throws RecapitiNonDisponibileException
	 * @throws RemoteException
	 */
	public Collection<IRecapitiNonDispDetailView> getValidRecapitiNonDispDetailList (final Long sogggettoId) throws RecapitiNonDisponibileException, RemoteException {
		return new RecapitiNonDispGetterHelper().getValidRecapitiNonDispDetailList(sogggettoId);
	}
	
	/**
	 * To Update Recapiti Non Disponibile Data
	 * @param recapitiColl
	 * @param soggettoId
	 * @param tipoSoggetto
	 * @param opId
	 * @throws RecapitiNonDisponibileException
	 * @throws RemoteException
	 */
	public void setRecapitiNonDisponibile(final Collection recapitiColl, final Long soggettoId, final String tipoSoggetto, final Long opId) throws RecapitiNonDisponibileException, RemoteException {
		new RecapitiNonDispUpdateHelper().setRecapitiNonDisponibile(recapitiColl, soggettoId, tipoSoggetto, opId);
	}
	
}