package it.sella.anagrafe.implementation;

import it.sella.anagrafe.IGestoreAnagrafe;
import it.sella.ejb.IEJBObject;

public interface GestoreAnagrafeImpl extends IGestoreAnagrafe, IEJBObject {

}
