package it.sella.anagrafe.implementation;

import it.sella.anagrafe.AltriSoggettoView;
import it.sella.anagrafe.BeanHelperException;
import it.sella.anagrafe.DatiAnagraficiAltriTipiView;
import it.sella.anagrafe.GestoreSoggettoException;
import it.sella.anagrafe.OperazioneAnagrafeFactory;
import it.sella.anagrafe.OperazioneAnagrafeManager;
import it.sella.anagrafe.OperazioneCensimentoException;
import it.sella.anagrafe.RicercaException;
import it.sella.anagrafe.RicercaPFException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.XMLSchemaValidationException;
import it.sella.anagrafe.az.DatiAnagraficiAZView;
import it.sella.anagrafe.beanhelper.AMBBaseHelper;
import it.sella.anagrafe.beanhelper.AnagrafeFlussoImpl;
import it.sella.anagrafe.beanhelper.AnagrafeManagerBeanAZHelper;
import it.sella.anagrafe.beanhelper.AnagrafeManagerBeanAltriSoggettoHelper;
import it.sella.anagrafe.beanhelper.AnagrafeManagerBeanDipendenteHelper;
import it.sella.anagrafe.beanhelper.AnagrafeManagerBeanHelper;
import it.sella.anagrafe.beanhelper.AnagrafeManagerBeanPFHelper;
import it.sella.anagrafe.beanhelper.AnagrafeManagerBeanPLHelper;
import it.sella.anagrafe.beanhelper.AnagrafeManagerBeanRicercaHelper;
import it.sella.anagrafe.beanhelper.CommonHelper;
import it.sella.anagrafe.beanhelper.ISE_Impl;
import it.sella.anagrafe.beanhelper.XMLSoggettiHandler;
import it.sella.anagrafe.dbaccess.RicercaDBAccessHelper;
import it.sella.anagrafe.dbaccess.RicercaDBLoggerHelper;
import it.sella.anagrafe.dbaccess.SellaLifeDBAccessHelper;
import it.sella.anagrafe.dbaccess.TipoSoggettoHandler;
import it.sella.anagrafe.dipendente.RicercaDipendenteView;
import it.sella.anagrafe.factory.AziendaFactory;
import it.sella.anagrafe.factory.AziendaFactoryException;
import it.sella.anagrafe.pf.CodiceSoggettoPFView;
import it.sella.anagrafe.pf.DatiAnagraficiPFView;
import it.sella.anagrafe.pl.CodiceSoggettoPLView;
import it.sella.anagrafe.promotore.RicercaPromotoreView;
import it.sella.anagrafe.schema_validation.SchemaValidator;
import it.sella.anagrafe.sm.censimentoaz.IAziendaConstants;
import it.sella.anagrafe.sm.censimentopf.ICensimentoPFConstants;
import it.sella.anagrafe.soaservices.msg.IValidationMessage;
import it.sella.anagrafe.sviluppatore.RicercaSviluppatoreView;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.AnagrafeLoggerHelper;
import it.sella.anagrafe.util.GestoreDisponibilitaHandler;
import it.sella.anagrafe.util.IHelperConstants;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.anagrafe.view.AziendaView;
import it.sella.anagrafe.view.DipendenteView;
import it.sella.anagrafe.view.PersonaFisicaView;
import it.sella.anagrafe.view.PlurintestazioneView;
import it.sella.anagrafe.view.SoggettoView;
import it.sella.classificazione.ClassificazioneView;
import it.sella.ejb.SessionBeanAdapter;
import it.sella.gestione_flussi.GestioneElementoFlussoException;
import it.sella.logserver.LoggerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Properties;

public class AnagrafeManagerBean extends SessionBeanAdapter implements Serializable {

    /**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AnagrafeManagerBean.class);

    public Long performCensimento( final SoggettoView soggettoView ) throws OperazioneCensimentoException, RemoteException {
        Long soggettoId = null;
        Long operationId = null;
        String logOperation = null;
        AnagrafeManagerBeanHelper anagrafeManagerBeanHelper = null;
        final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
        final OperazioneAnagrafeManager operazioneAnagrafeManager = getOperazioneAnagrafeManager();
        try {
            if (soggettoView instanceof PersonaFisicaView) {
                anagrafeManagerBeanHelper = new AnagrafeManagerBeanPFHelper();
                logOperation = "ANAG-CNPF";
            } else if (soggettoView instanceof PlurintestazioneView) {
                anagrafeManagerBeanHelper = new AnagrafeManagerBeanPLHelper();
                logOperation = "ANAG-CNPL";
            } else if (soggettoView instanceof DipendenteView) {
                anagrafeManagerBeanHelper = new AnagrafeManagerBeanDipendenteHelper();
            } else if (soggettoView instanceof AltriSoggettoView) {
                anagrafeManagerBeanHelper = new AnagrafeManagerBeanAltriSoggettoHelper();
                logOperation = "ANAG-CNAS";
            } else if (soggettoView instanceof AziendaView) {
                logOperation = "ANAG-CNAZ";
                anagrafeManagerBeanHelper = new AnagrafeManagerBeanAZHelper();
            }
            if(anagrafeManagerBeanHelper != null) {
            	operationId = anagrafeLoggerHelper.logAnagrafeOperation(soggettoView.getMotivazioneNoHost(), soggettoView.isHostToBeCalled(), logOperation, soggettoView.getId(),null);
            	soggettoView.setOpId(operationId);
                soggettoId = anagrafeManagerBeanHelper.performCensimento(soggettoView);
                operazioneAnagrafeManager.updateAnagrafeLog(operationId, soggettoId);
            } else {
                throw new OperazioneCensimentoException(new AnagrafeHelper().getMessage("ANAG-1529"));
            }

        } catch (final LoggerException e) {
            changeCodiceHostToNull(soggettoView);
            handleExceptionWithLog(soggettoId, operationId, anagrafeLoggerHelper, e);
        } catch (final BeanHelperException e) {
            changeCodiceHostToNull(soggettoView);
            handleExceptionWithLog(soggettoId, operationId, anagrafeLoggerHelper, e);
        } catch (final OperazioneAnagrafeManagerException e) {
            changeCodiceHostToNull(soggettoView);
            handleExceptionWithLog(soggettoId, operationId, anagrafeLoggerHelper, e);
		} finally {
            try {
                if ( soggettoId != null ) {
                	operazioneAnagrafeManager.logMessageForAnagrafeManager(soggettoId,"PERFORM CENSIMENTO", getLongWithEndDataWriteTag(anagrafeManagerBeanHelper.getLogMsg())+"<SoggettoId>"+soggettoId+"</SoggettoId>", logOperation, true);
                } else {
                	operazioneAnagrafeManager.logMessageForAnagrafeManager(null,"PERFORM CENSIMENTO", "PROBLEM_IN_PERFORM_CENSIMENTO", logOperation, false);
                }
                if( operationId != null ) {
                	anagrafeLoggerHelper.logAnagrafeOpDetails(operationId,anagrafeManagerBeanHelper.getLogForHost(),"");
                }
            } catch (final LoggerException le) {
                handleExceptionWithoutLog(le);
            } catch (final OperazioneAnagrafeManagerException le) {
                handleExceptionWithoutLog(le);
            }
        }
        return soggettoId;
    }

	private OperazioneAnagrafeManager getOperazioneAnagrafeManager() {
		return OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager();
	}

    private void changeCodiceHostToNull( final SoggettoView soggettoView ) {
    	if( soggettoView instanceof PersonaFisicaView ) {
    		final PersonaFisicaView personaFisicaView = (PersonaFisicaView)soggettoView;
    		if( personaFisicaView.getCodiceSoggettoPFView() != null ) {
    			personaFisicaView.getCodiceSoggettoPFView().setCodiceHost(null);
    		}
    	} else if( soggettoView instanceof PlurintestazioneView ) {
    		final PlurintestazioneView plurintestazioneView = (PlurintestazioneView)soggettoView;
    		if( plurintestazioneView.getCodiceSoggettoPLView() != null ) {
    			plurintestazioneView.getCodiceSoggettoPLView().setCodiceHost(null);
    		}
    	} else if( soggettoView instanceof AziendaView ) {
    		final AziendaView aziendaView = (AziendaView)soggettoView;
    		if( aziendaView.getCodiceSoggettoAZView() != null ) {
    			aziendaView.getCodiceSoggettoAZView().setCodiceHost(null);
    		}
    	}
    }

    public void performCensimentoModifica( final SoggettoView soggettoView ) throws OperazioneCensimentoException, RemoteException {
        boolean success = false;
        String operationCode = "";
        Long operationId = null;
        AnagrafeManagerBeanHelper anagrafeManagerBeanHelper = null;
        final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
        final OperazioneAnagrafeManager operazioneAnagrafeManager = getOperazioneAnagrafeManager();
        try {
            if ( soggettoView instanceof PersonaFisicaView ) {
                operationCode = "ANAG-VRPF";
                anagrafeManagerBeanHelper = new AnagrafeManagerBeanPFHelper();
            } else if ( soggettoView instanceof PlurintestazioneView ) {
                operationCode = "ANAG-VRPL";
                anagrafeManagerBeanHelper = new AnagrafeManagerBeanPLHelper();
            } else if ( soggettoView instanceof AziendaView ) {
                operationCode = "ANAG-VRAZ";
                anagrafeManagerBeanHelper = new AnagrafeManagerBeanAZHelper();
            } else if ( soggettoView instanceof AltriSoggettoView ) {
                operationCode = "ANAG-VRATS";
                anagrafeManagerBeanHelper = new AnagrafeManagerBeanAltriSoggettoHelper();
            }
            if( anagrafeManagerBeanHelper != null ) {
            	operationId = anagrafeLoggerHelper.logAnagrafeOperation(soggettoView.getMotivazioneNoHost(), soggettoView.isHostToBeCalled(), operationCode, soggettoView.getId(), null);
            	soggettoView.setOpId(operationId);
                anagrafeManagerBeanHelper.performCensimentoModifica(soggettoView);
                operazioneAnagrafeManager.updateAnagrafeLog(operationId, soggettoView.getId());
            } else {
                throw new OperazioneCensimentoException(new AnagrafeHelper().getMessage("ANAG-1529"));
            }
            success = true;
        } catch (final LoggerException e) {
            handleExceptionWithLog(soggettoView.getId(), operationId, anagrafeLoggerHelper, e);
        } catch (final BeanHelperException e) {
            handleExceptionWithLog(soggettoView.getId(), operationId, anagrafeLoggerHelper, e);
        } catch (final OperazioneAnagrafeManagerException e) {
            handleExceptionWithLog(soggettoView.getId(), operationId, anagrafeLoggerHelper, e);
		} finally {
            try {
            	operazioneAnagrafeManager.logMessageForAnagrafeManager(soggettoView.getId(),"PERFORM CENSIMENTO MODIFICA", getLongWithEndDataWriteTag(anagrafeManagerBeanHelper.getLogMsg())+"<SoggettoId>"+soggettoView.getId().toString()+"</SoggettoId>", operationCode, success);
                if( operationId != null ) {
                	anagrafeLoggerHelper.logAnagrafeOpDetails(operationId,anagrafeManagerBeanHelper.getLogForHost(),"");
                }
            } catch (final LoggerException le) {
                handleExceptionWithoutLog(le);
            } catch (final OperazioneAnagrafeManagerException le) {
                handleExceptionWithoutLog(le);
            }
        }
    }

    public Collection ricerca( final Properties properties ) throws RicercaPFException, RemoteException {
        Collection ricercaColl = null;
        boolean success = false;
        String logOperation = null;
        final AnagrafeManagerBeanRicercaHelper ricercaHelper = new AnagrafeManagerBeanRicercaHelper();
        try {
        	new GestoreDisponibilitaHandler().checkDisponibilita(ICensimentoPFConstants.RICERCA_PF);
        	if (properties.get("View") instanceof RicercaDipendenteView) {
                ricercaColl = ricercaHelper.ricercaDipendente(properties);
            } else if (properties.get("View") instanceof RicercaPromotoreView) {
                ricercaColl = ricercaHelper.ricercaPromotore(properties);
            } else if (properties.get("View") instanceof RicercaSviluppatoreView) {
                ricercaColl = ricercaHelper.ricercaSviluppatore(properties);
            } else if (properties.get("View") instanceof DatiAnagraficiPFView) {
                logOperation = "ANAG-RCPF";
                ricercaColl = ricercaHelper.ricercaPF(properties);
            } else if (properties.get("View") instanceof CodiceSoggettoPFView) {
                ricercaColl = ricercaHelper.ricercaCodiceSoggettoPF(properties);
            } else if (properties.get("View") instanceof CodiceSoggettoPLView) {
                ricercaColl = ricercaHelper.ricercaCodiceSoggettoPL(properties);
            } else if (properties.get("View") instanceof DatiAnagraficiAZView) {
                logOperation = "ANAG-RCAZ";
                ricercaColl = ricercaHelper.ricercaAZ(properties);
            } else if (properties.get("View") instanceof DatiAnagraficiAltriTipiView) {
                logOperation = "ANAG-RCAS";
                ricercaColl = ricercaHelper.ricercaAltriSoggetto(properties);
            }
            success = true;
        } catch (final BeanHelperException e) {
            log4Debug.warnStackTrace(e);
            throw new RicercaPFException(e.getMessage());
        } catch (final SubSystemHandlerException e) {
			throw new RicercaPFException(e.getMessage());
		}
        finally {
        	try {
        		new RicercaDBLoggerHelper().loggerDetails(ricercaColl, success, new StringBuffer(ricercaHelper.getLogMsg()), logOperation);
        	} catch (final LoggerException le) {
                log4Debug.severeStackTrace(le);
                throw new RicercaPFException(le.getMessage());
            } catch (final SubSystemHandlerException le) {
                log4Debug.severeStackTrace(le);
                throw new RicercaPFException(le.getMessage());
            }
        }
        return ricercaColl;
    }

    public SoggettoView getSoggetto( final Long soggettoId, final Properties properties ) throws RemoteException {
        SoggettoView soggettoView = null;
        boolean success = false;
        String logOperation = "ANAG-RTNO";
        AnagrafeManagerBeanHelper anagrafeManagerBeanHelper = null;
        String errorMessage = null;
        try {
        	final String tipoSoggetto = new TipoSoggettoHandler().getTipoSoggetto(soggettoId);
            if ("Semplice".equals(tipoSoggetto)) {
                anagrafeManagerBeanHelper = new AnagrafeManagerBeanPFHelper();
                logOperation = "ANAG-RTPF";
                soggettoView = anagrafeManagerBeanHelper.getSoggetto(soggettoId, properties);
            } else if ("Plurintestazione".equals(tipoSoggetto)) {
                logOperation = "ANAG-RTPL";
                anagrafeManagerBeanHelper= new AnagrafeManagerBeanPLHelper();
                soggettoView = anagrafeManagerBeanHelper.getSoggetto(soggettoId,properties);
            } else if ("Dipendente".equals(tipoSoggetto)) {
                anagrafeManagerBeanHelper = new AnagrafeManagerBeanDipendenteHelper();
                logOperation = "ANAG-RTIN";
                soggettoView = anagrafeManagerBeanHelper.getSoggetto(soggettoId,properties);
            } else {
            	final String parentTipoSoggetto = new TipoSoggettoHandler().getParentTipoSoggetto(soggettoId);
                if ("AZIENDE".equals(parentTipoSoggetto)) {
                    logOperation = "ANAG-RTAZ";
                    anagrafeManagerBeanHelper = new AnagrafeManagerBeanAZHelper();
                    soggettoView = anagrafeManagerBeanHelper.getSoggetto(soggettoId,properties);
                } else if ("UNITA' ORGANIZZATIVA".equals(parentTipoSoggetto)) {
                    logOperation = "ANAG-RTAS";
                    anagrafeManagerBeanHelper = new AnagrafeManagerBeanAltriSoggettoHelper();
                    soggettoView = anagrafeManagerBeanHelper.getSoggetto(soggettoId,properties);
                }
            }
            if (soggettoView != null) {
             success = true;
            } else {
              errorMessage ="INVALID SOGGETTO ID";
            }
        } catch (final GestoreSoggettoException pffe) {
            log4Debug.warnStackTrace(pffe);
            errorMessage = pffe.getMessage();
            throw new RemoteException(pffe.getMessage());
        } catch (final BeanHelperException e) {
            log4Debug.warnStackTrace(e);
            errorMessage = e.getMessage();
            throw new RemoteException(e.getMessage());
        } finally {
            try {
                if ( soggettoId != null ) {
                	it.sella.anagrafe.util.Log.logMessageWithErrorMsg(soggettoId,"GET SOGGETTO", (anagrafeManagerBeanHelper != null ? anagrafeManagerBeanHelper.getLogMsg() : "In Valid Soggetto Id ") +"<SoggettoId>"+soggettoId+"</SoggettoId>", logOperation, success,errorMessage);
                } else {
                	it.sella.anagrafe.util.Log.logMessage(SecurityHandler.getLoginSoggettoId(),"GET SOGGETTO", "PROBLEM_IN_GETTING_SOGGETTO", logOperation, success);
                }

            } catch (final LoggerException le) {
                log4Debug.severeStackTrace(le);
                throw new RemoteException(le.getMessage());
            } catch (final SubSystemHandlerException le) {
                log4Debug.severeStackTrace(le);
                throw new RemoteException(le.getMessage());
            }
        }
        return soggettoView;
    }

    /** The xmlSoggetto is parsed and the soggetto is created
     * @ param String xmlSoggettoData
     * @ return String soggetto id and indirizzo ids in the form of xml tags
     * @ exception OperazioneCensimentoException, RemoteException
     */

    public String createSoggetto( String xmlSoggetto) throws OperazioneCensimentoException, RemoteException {
    	xmlSoggetto = AnagrafeManagerBeanHelper.handleXMLMetaCharecter(xmlSoggetto);
        final StringBuffer soggettoBuffer = new StringBuffer("<?xml version='1.0' encoding='UTF-8'?>");
        SoggettoView soggettoView = null;
        String errorMessage = null;
        String logOperation = null;
        AnagrafeManagerBeanHelper anagrafeManagerBeanHelper = null;
        final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
        final OperazioneAnagrafeManager operazioneAnagrafeManager = getOperazioneAnagrafeManager();
        try {
        	final int tipoSoggettoIndex = xmlSoggetto.indexOf("TipoSoggetto");
        	final String temp = xmlSoggetto.substring(tipoSoggettoIndex - 1, xmlSoggetto.indexOf('>', tipoSoggettoIndex));
            if (temp.indexOf("Semplice") == -1 && temp.indexOf("Plurintestazione") == -1) {
                logOperation = "ANAG-CNAZ";
                anagrafeManagerBeanHelper = new AnagrafeManagerBeanAZHelper();
                soggettoView = anagrafeManagerBeanHelper.getViewAfterParsing(xmlSoggetto);
                log4Debug.debug(" AnagrafeManagerBean : createSoggetto : soggettoView :===>>",soggettoView);
                soggettoBuffer.append(anagrafeManagerBeanHelper.createSoggetto(soggettoView,null,null,logOperation));
            } else if (temp.indexOf("Semplice") != -1) {
                logOperation = "ANAG-CNPF";
                anagrafeManagerBeanHelper = new AnagrafeManagerBeanPFHelper();
                soggettoView = anagrafeManagerBeanHelper.getViewAfterParsing(xmlSoggetto);
                new AMBBaseHelper().setDocudmentRilasciatoDa(soggettoView);
                soggettoBuffer.append(anagrafeManagerBeanHelper.createSoggetto(soggettoView,null,null,logOperation));
            } else { // Plurintestazione handling
                logOperation = "ANAG-CNPL";
                anagrafeManagerBeanHelper = new AnagrafeManagerBeanPLHelper();
                soggettoView   = anagrafeManagerBeanHelper.getViewAfterParsing(xmlSoggetto);
                final PlurintestazioneParser plurintestazioneParser = AnagrafeManagerBeanPLHelper.plurintestazioneParser;
                soggettoView  = plurintestazioneParser.getPlurintestazioneView();
                soggettoBuffer.append(anagrafeManagerBeanHelper.createSoggetto(soggettoView,plurintestazioneParser.getErrorMessages(),plurintestazioneParser.getBank(),logOperation));
            }
            final String output = soggettoBuffer.toString();
            if ( !soggettoView.isSoggettoAlreadyExist() ) {
                if ( output.indexOf("<SOGGETTO_ID>") != -1  ) {
    	            getOperazioneAnagrafeManager().updateAnagrafeLog(soggettoView.getOpId(), Long.valueOf((output.substring(output.indexOf("<SOGGETTO_ID>")+13,output.indexOf("</SOGGETTO_ID>")))));
                } else {
                    anagrafeLoggerHelper.updateAnagrafeLog(soggettoView.getOpId(), soggettoView.getId(), output);
                }
            }
        } catch (final OperazioneAnagrafeManagerException e) {
            errorMessage = e.getMessage();
            handleExceptionWithLog(soggettoView.getId(), soggettoView.getOpId(), anagrafeLoggerHelper, e);
        } catch (final BeanHelperException e) {
            errorMessage = e.getMessage();
            handleExceptionWithLog(soggettoView.getId(), soggettoView.getOpId(), anagrafeLoggerHelper, e);
        } catch (final SubSystemHandlerException e) {
        	errorMessage = e.getMessage();
            handleExceptionWithLog(soggettoView.getId(), soggettoView.getOpId(), anagrafeLoggerHelper, e);
		} finally {
            try {
                if ( soggettoView != null && soggettoView.getId() != null && errorMessage == null) {
                	if ( !soggettoView.isSoggettoAlreadyExist() ){
                		operazioneAnagrafeManager.logMessageForAnagrafeManager(soggettoView.getId(),"PERFORM CENSIMENTO", anagrafeManagerBeanHelper.getLogMsg()+"<SoggettoId>"+soggettoView.getId()+"</SoggettoId>", logOperation, true);
                	}
                } else {
                	operazioneAnagrafeManager.logMessageForAnagrafeManager(soggettoView != null ? soggettoView.getId() : null, "PERFORM CENSIMENTO","PROBLEM_IN_PERFORM_CENSIMENTO", logOperation, false);
                }
                if ( soggettoView != null && soggettoView.getOpId() != null && !soggettoView.isSoggettoAlreadyExist()  ) {
                	anagrafeLoggerHelper.logAnagrafeOpDetails(soggettoView.getOpId(),anagrafeManagerBeanHelper.getLogForHost(),"");
                }
            } catch (final LoggerException le) {
                handleExceptionWithoutLog(le);
            } catch (final OperazioneAnagrafeManagerException le) {
                handleExceptionWithoutLog(le);
            }
        }
        return soggettoBuffer.toString();
    }

    /** The xmlSoggetto is parsed and the soggetto is created
     * @ param String xmlSoggettoData
     * @ return String soggetto id and indirizzo ids in the form of xml tags
     * @ exception OperazioneCensimentoException, RemoteException
     */

    private String creaSoggettoXMLIsXSDChkRequired(String xmlSoggetto , final boolean isXSDChkRequired) throws OperazioneCensimentoException, RemoteException {
        SoggettoView soggettoView = null;
        String errorMessage = null;
        String logOperation = "ANAG-RTNO";
        AnagrafeManagerBeanHelper anagrafeManagerBeanHelper = null;
        final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
        final StringBuffer soggettoBuffer = new StringBuffer("<?xml version='1.0' encoding='UTF-8'?>");
        final OperazioneAnagrafeManager operazioneAnagrafeManager = getOperazioneAnagrafeManager();
        try {
        	xmlSoggetto = AnagrafeManagerBeanHelper.handleXMLMetaCharecterInFiveLevelXML(xmlSoggetto);
            final int tipoSoggettoIndex = xmlSoggetto.indexOf("TipoSoggetto");
            if(tipoSoggettoIndex == -1){// To avoid IndexOutOfBoundsException
    			throw new OperazioneCensimentoException(IValidationMessage.XML_INVALID);
            }
            final String temp = xmlSoggetto.substring(tipoSoggettoIndex - 1, xmlSoggetto.indexOf('>', tipoSoggettoIndex));
            if (temp.indexOf("Semplice") == -1 && temp.indexOf("Plurintestazione") == -1) {
            	logOperation = "ANAG-CNAZ";
                anagrafeManagerBeanHelper = new AnagrafeManagerBeanAZHelper();
            	checkToValidateSchema(xmlSoggetto, "AZ_XSD",isXSDChkRequired);
                log4Debug.debug(" AnagrafeManagerBean : creaSoggettoXML : before soggettoView :===>>",soggettoView);
                soggettoView = anagrafeManagerBeanHelper.getViewAfterParsingPrivacyFiveLevelXML(xmlSoggetto);
                log4Debug.debug(" AnagrafeManagerBean : creaSoggettoXML : after soggettoView :===>>",soggettoView);
                setStartUpFalseForANTCI(soggettoView);
                soggettoBuffer.append(anagrafeManagerBeanHelper.createSoggetto(soggettoView,null,null,logOperation));
            } else if (temp.indexOf("Semplice") != -1) {
            	logOperation = "ANAG-CNPF";
                anagrafeManagerBeanHelper = new AnagrafeManagerBeanPFHelper();
            	checkToValidateSchema(xmlSoggetto, "PF_XSD",isXSDChkRequired);
                soggettoView = anagrafeManagerBeanHelper.getViewAfterParsingPrivacyFiveLevelXML(xmlSoggetto);
                new AMBBaseHelper().setDocudmentRilasciatoDa(soggettoView);
                soggettoBuffer.append(anagrafeManagerBeanHelper.createSoggetto(soggettoView,null,null,logOperation));
            } else { // Plurintestazione handling
            	logOperation = "ANAG-CNPL";
                anagrafeManagerBeanHelper = new AnagrafeManagerBeanPLHelper();
            	checkToValidateSchema(xmlSoggetto, "PL_XSD",isXSDChkRequired);
                soggettoView   = anagrafeManagerBeanHelper.getViewAfterParsingPrivacyFiveLevelXML(xmlSoggetto);
                final PlurintestazioneParser plurintestazioneParser = AnagrafeManagerBeanPLHelper.plurintestazioneParser;
                soggettoView  = plurintestazioneParser.getPlurintestazioneView();
                soggettoBuffer.append(anagrafeManagerBeanHelper.createSoggetto(soggettoView,plurintestazioneParser.getErrorMessages(),plurintestazioneParser.getBank(),logOperation));
            }
            final String output = soggettoBuffer.toString();
            if ( !soggettoView.isSoggettoAlreadyExist() ) {
                if ( output.indexOf("<SOGGETTO_ID>") != -1 ) {
    	            getOperazioneAnagrafeManager().updateAnagrafeLog(soggettoView.getOpId(), Long.valueOf((output.substring(output.indexOf("<SOGGETTO_ID>")+13,output.indexOf("</SOGGETTO_ID>")))));
                } else {
                    anagrafeLoggerHelper.updateAnagrafeLog(soggettoView.getOpId(), soggettoView.getId(), output);
                }
            }
        } catch (final OperazioneAnagrafeManagerException e) {
            errorMessage = e.getMessage();
            handleExceptionWithLog(soggettoView.getId(), soggettoView.getOpId(), anagrafeLoggerHelper, e);
        } catch (final BeanHelperException e) {
            errorMessage = e.getMessage();
            if(soggettoView!=null) {
            handleExceptionWithLog(soggettoView.getId(), soggettoView.getOpId(), anagrafeLoggerHelper, e);
            }else {
            throw new OperazioneCensimentoException(errorMessage);
            }
        } catch (final SubSystemHandlerException e) {
        	errorMessage = e.getMessage();
            handleExceptionWithLog(soggettoView.getId(), soggettoView.getOpId(), anagrafeLoggerHelper, e);
		} catch (final XMLSchemaValidationException e) {
			errorMessage = IValidationMessage.XML_INVALID+" : "+e.getMessage();
			throw new OperazioneCensimentoException(errorMessage);
		} finally {
            try {
            	final Long soggettoId = soggettoView != null ? soggettoView.getId() : null;
            	final String logMsg = getLongWithEndDataWriteTag(anagrafeManagerBeanHelper != null ? anagrafeManagerBeanHelper.getLogMsg() : "")+"<SoggettoId>"+soggettoId+"</SoggettoId>";
            	if(soggettoId != null && errorMessage == null) {
            		if ( !soggettoView.isSoggettoAlreadyExist() ) {
                    	operazioneAnagrafeManager.logMessageForAnagrafeManager(soggettoId,"PERFORM CENSIMENTO", logMsg, logOperation, true);
                	}
            	} else {
            		operazioneAnagrafeManager.logMessageForAnagrafeManager(soggettoId, "PERFORM CENSIMENTO","PROBLEM_IN_PERFORM_CENSIMENTO", logOperation, false);
            	}
                
                if ( soggettoView != null && soggettoView.getOpId() != null && !soggettoView.isSoggettoAlreadyExist() )  {
                	anagrafeLoggerHelper.logAnagrafeOpDetails(soggettoView.getOpId(),anagrafeManagerBeanHelper.getLogForHost(),xmlSoggetto);
                }
            } catch (final LoggerException le) {
                handleExceptionWithoutLog(le);
            } catch (final OperazioneAnagrafeManagerException le) {
                handleExceptionWithoutLog(le);
            }
        }
        return soggettoBuffer.toString();
    }

	/**
	 * Private Method to check for ANTCI and set Start up as False only for Cliente
	 * @param soggettoView
	 */
	private void setStartUpFalseForANTCI(SoggettoView soggettoView) {
		final AnagrafeHelper helper = new AnagrafeHelper();
		final Collection motivCollection = ((AziendaView)soggettoView).getMotiv();
		if ( !(helper.checkForMotiv(motivCollection,"ANTCI") &&
		    	 ! helper.isExistsuperiorMotivThanAntci(motivCollection))) {
				new AMBBaseHelper().setIsSTARTUPNullAsFalse(soggettoView);
		}
	}


    /*
    * This method has to be invoked using
    * AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().createSoggetto(String xmlSoggetto)
    * This method is used to update eventi and dipct for a list of soggettos by reading from a file
    * using flussi.
    */
    public void updateEventiEDipct() throws OperazioneAnagrafeManagerException, RemoteException {
        new ISE_Impl().updateEventiEDipct();
    }

    // Flusso Consumer Method
    public void gestisciElementoFlusso( final Object elementoFlusso, final String nomeFlusso ) throws GestioneElementoFlussoException, RemoteException {
        final AnagrafeFlussoImpl flussoHelper = new AnagrafeFlussoImpl();
        flussoHelper.gestisciElementoFlusso(elementoFlusso, nomeFlusso);
    }

    // Flusso Producer Methods
    public void gestisciScarto( final Object elementoFlussoScartato, final Throwable motivoScarto, final String nomeFlusso ) throws GestioneElementoFlussoException, RemoteException {
    	final AnagrafeFlussoImpl flussoHelper = new AnagrafeFlussoImpl();
        flussoHelper.gestisciScarto(elementoFlussoScartato, motivoScarto, nomeFlusso);
    }

    public void notifcaFlussoTerminato( final String nomeFlusso ) throws RemoteException {
    	final AnagrafeFlussoImpl flussoHelper = new AnagrafeFlussoImpl();
        flussoHelper.notifcaFlussoTerminato(nomeFlusso);
    }

    public String createSoggettoWithHost( String xmlSoggetto) throws OperazioneCensimentoException, RemoteException {
    	xmlSoggetto = AnagrafeManagerBeanHelper.handleXMLMetaCharecter(xmlSoggetto);
        AnagrafeManagerBeanHelper beanHelper = null;
        final StringBuffer soggettoBuffer = new StringBuffer("<?xml version='1.0' encoding='UTF-8'?>");
        SoggettoView soggettoView = null;
        String operationCode = null;
        String errorMessage = null;
        final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
        final OperazioneAnagrafeManager operazioneAnagrafeManager = getOperazioneAnagrafeManager();
        try {
        	final int tipoSoggettoIndex = xmlSoggetto.indexOf("TipoSoggetto");
        	final String temp = xmlSoggetto.substring(tipoSoggettoIndex - 1, xmlSoggetto.indexOf('>', tipoSoggettoIndex));
            if (temp.indexOf("Semplice") == -1 && temp.indexOf("Plurintestazione") == -1) {
                operationCode = "ANAG-CNAZ";
                beanHelper = new AnagrafeManagerBeanAZHelper();
                soggettoView = beanHelper.getViewAfterParsing(xmlSoggetto);
                soggettoBuffer.append(beanHelper.createSoggettoWithHost(soggettoView,null,null,operationCode));
            } else if (temp.indexOf("Semplice") != -1) {
                operationCode = "ANAG-CNPF";
                beanHelper = new AnagrafeManagerBeanPFHelper();
                soggettoView = beanHelper.getViewAfterParsing(xmlSoggetto);
                new AMBBaseHelper().setDocudmentRilasciatoDa(soggettoView);
                soggettoBuffer.append(beanHelper.createSoggettoWithHost(soggettoView,null,null,operationCode));
            } else { // Plurintestazione handling
            	operationCode = "ANAG-CNPL";
                beanHelper = new AnagrafeManagerBeanPLHelper();
                soggettoView = beanHelper.getViewAfterParsing(xmlSoggetto);
                final PlurintestazioneParser plurintestazioneParser = AnagrafeManagerBeanPLHelper.plurintestazioneParser;
                soggettoBuffer.append(beanHelper.createSoggettoWithHost(soggettoView, plurintestazioneParser.getErrorMessages(),plurintestazioneParser.getBank(),operationCode));
            }
            final String output = soggettoBuffer.toString();
            if ( !soggettoView.isSoggettoAlreadyExist() ) {
                if ( output.indexOf("<SOGGETTO_ID>") != -1 ) {
    	            getOperazioneAnagrafeManager().updateAnagrafeLog(soggettoView.getOpId(), Long.valueOf((output.substring(output.indexOf("<SOGGETTO_ID>")+13,output.indexOf("</SOGGETTO_ID>")))));
                } else {
                    anagrafeLoggerHelper.updateAnagrafeLog(soggettoView.getOpId(), soggettoView.getId(), output);
                }
            }
        } catch (final OperazioneAnagrafeManagerException e) {
            errorMessage = e.getMessage();
            handleExceptionWithLog(soggettoView.getId(), soggettoView.getOpId(), anagrafeLoggerHelper, e);
        } catch (final BeanHelperException e) {
            errorMessage = e.getMessage();
            handleExceptionWithLog(soggettoView.getId(), soggettoView.getOpId(), anagrafeLoggerHelper, e);
        } catch (final SubSystemHandlerException e) {
        	errorMessage = e.getMessage();
            handleExceptionWithLog(soggettoView.getId(), soggettoView.getOpId(), anagrafeLoggerHelper, e);
		} finally {
            try {
                if (soggettoView != null && soggettoView.getId() != null && errorMessage == null) {
                	if ( !soggettoView.isSoggettoAlreadyExist() ) {
                    	operazioneAnagrafeManager.logMessageForAnagrafeManager(soggettoView.getId(),"PERFORM CENSIMENTO", beanHelper.getLogMsg()+"<SoggettoId>"+soggettoView.getId()+"</SoggettoId>", operationCode, true);
                	}
                } else {
                	operazioneAnagrafeManager.logMessageForAnagrafeManager(soggettoView.getId(),"PERFORM CENSIMENTO", "PROBLEM_IN_PERFORM_CENSIMENTO", operationCode, false);
                }
                if ( soggettoView != null && soggettoView.getOpId() != null && !soggettoView.isSoggettoAlreadyExist() ) {
                	anagrafeLoggerHelper.logAnagrafeOpDetails(soggettoView.getOpId(),beanHelper.getLogForHost(),"");
                }
            } catch (final LoggerException le) {
                handleExceptionWithoutLog(le);
            } catch (final OperazioneAnagrafeManagerException le) {
                handleExceptionWithoutLog(le);
            }
        }
        return soggettoBuffer.toString();
    }

    private String creaSoggettoXMLWithHostIsXSDChkRequired( String xmlSoggetto ,final boolean isXSDChkRequired, final boolean isCSSECheckAllowed ) throws OperazioneCensimentoException, RemoteException {
        AnagrafeManagerBeanHelper beanHelper = null;
        SoggettoView soggettoView = null;
        String operationCode = "ANAG-RTNO";
        String errorMessage = null;
        final Long soggettoId = null;
        final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
        final OperazioneAnagrafeManager operazioneAnagrafeManager = getOperazioneAnagrafeManager();
        final StringBuffer soggettoBuffer = new StringBuffer("<?xml version='1.0' encoding='UTF-8'?>");
        try {
        	xmlSoggetto = AnagrafeManagerBeanHelper.handleXMLMetaCharecterInFiveLevelXML(xmlSoggetto);
            final int tipoSoggettoIndex = xmlSoggetto.indexOf("TipoSoggetto");
            if(tipoSoggettoIndex == -1) {// To avoid IndexOutOfBoundsException
    			throw new OperazioneCensimentoException(IValidationMessage.XML_INVALID);
            }
            final String temp = xmlSoggetto.substring(tipoSoggettoIndex - 1, xmlSoggetto.indexOf('>', tipoSoggettoIndex));
            if (temp.indexOf("Semplice") == -1 && temp.indexOf("Plurintestazione") == -1) {
            	operationCode = "ANAG-CNAZ";
                beanHelper = new AnagrafeManagerBeanAZHelper();
            	checkToValidateSchema(xmlSoggetto, "AZ_XSD",isXSDChkRequired);
                soggettoView = beanHelper.getViewAfterParsingPrivacyFiveLevelXML(xmlSoggetto);
                ((AziendaView)soggettoView).setCSSECheckAllowed(isCSSECheckAllowed);
                setStartUpFalseForANTCI(soggettoView);
                soggettoBuffer.append(beanHelper.createSoggettoWithHost(soggettoView,null,null,operationCode));
            } else if (temp.indexOf("Semplice") != -1) {
            	operationCode = "ANAG-CNPF";
                beanHelper = new AnagrafeManagerBeanPFHelper();
            	checkToValidateSchema(xmlSoggetto, "PF_XSD",isXSDChkRequired);
                soggettoView = beanHelper.getViewAfterParsingPrivacyFiveLevelXML(xmlSoggetto);
                allowPosteUserCreation(((PersonaFisicaView)soggettoView).getMotiv()); // POSTE (Post Office-POS Machine Owners).
                new AMBBaseHelper().setDocudmentRilasciatoDa(soggettoView);
                ((PersonaFisicaView)soggettoView).setCSSECheckAllowed(isCSSECheckAllowed);
                soggettoBuffer.append(beanHelper.createSoggettoWithHost(soggettoView,null,null,operationCode));
            } else { // Plurintestazione handling
            	operationCode = "ANAG-CNPL";
                beanHelper = new AnagrafeManagerBeanPLHelper();
            	checkToValidateSchema(xmlSoggetto, "PL_XSD",isXSDChkRequired);
                soggettoView = beanHelper.getViewAfterParsingPrivacyFiveLevelXML(xmlSoggetto);
                final PlurintestazioneParser plurintestazioneParser = AnagrafeManagerBeanPLHelper.plurintestazioneParser;
                soggettoBuffer.append(beanHelper.createSoggettoWithHost(soggettoView, plurintestazioneParser.getErrorMessages(),plurintestazioneParser.getBank(),operationCode));
            }
            final String output = soggettoBuffer.toString();
            if ( !soggettoView.isSoggettoAlreadyExist() ) {
                if ( output.indexOf("<SOGGETTO_ID>") != -1 ) {
    	            getOperazioneAnagrafeManager().updateAnagrafeLog(soggettoView.getOpId(), Long.valueOf((output.substring(output.indexOf("<SOGGETTO_ID>")+13,output.indexOf("</SOGGETTO_ID>")))));
                } else {
                    anagrafeLoggerHelper.updateAnagrafeLog(soggettoView.getOpId(), soggettoId, output);
                }
            }
        } catch (final OperazioneAnagrafeManagerException e) {
            errorMessage = e.getMessage();
            handleExceptionWithLog(soggettoView.getId(), soggettoView.getOpId(), anagrafeLoggerHelper, e);
        } catch (final BeanHelperException e) {
            errorMessage = e.getMessage();
            if(soggettoView!=null) {
            handleExceptionWithLog(soggettoView.getId(), soggettoView.getOpId(), anagrafeLoggerHelper, e);
            }else {
                throw new OperazioneCensimentoException(errorMessage);
                }
        } catch (final SubSystemHandlerException e) {
        	errorMessage = e.getMessage();
            handleExceptionWithLog(soggettoView.getId(), soggettoView.getOpId(), anagrafeLoggerHelper, e);
		} catch (final XMLSchemaValidationException e) {
			errorMessage = IValidationMessage.XML_INVALID+" : "+e.getMessage();
			throw new OperazioneCensimentoException(errorMessage);
		} finally {
            try {
            	final Long soggetto = soggettoView != null ? soggettoView.getId() : null;
            	final String logMsg = getLongWithEndDataWriteTag(beanHelper != null ? beanHelper.getLogMsg() : "")+"<SoggettoId>"+soggetto+"</SoggettoId>";
                if (soggetto != null && errorMessage == null && soggettoView != null) {
                	if ( !soggettoView.isSoggettoAlreadyExist() ) {
                    	operazioneAnagrafeManager.logMessageForAnagrafeManager(soggetto,"PERFORM CENSIMENTO", logMsg, operationCode, true);
                	}
                } else {
                	operazioneAnagrafeManager.logMessageForAnagrafeManager(soggetto ,"PERFORM CENSIMENTO", "PROBLEM_IN_PERFORM_CENSIMENTO", operationCode, false);
                }
                if ( soggettoView != null && soggettoView.getOpId()!= null && !soggettoView.isSoggettoAlreadyExist() ) {
                	anagrafeLoggerHelper.logAnagrafeOpDetails(soggettoView.getOpId(),beanHelper.getLogForHost(),xmlSoggetto);
                }
            } catch (final LoggerException le) {
                handleExceptionWithoutLog(le);
            } catch (final OperazioneAnagrafeManagerException le) {
                handleExceptionWithoutLog(le);
            }
        }
        return soggettoBuffer.toString();
    }

    private String validateSoggettoXMLIsXSDChkRequired( String xmlSoggetto ,final boolean isXSDChkRequired ) throws OperazioneCensimentoException, RemoteException {
        AnagrafeManagerBeanHelper beanHelper = null;
        SoggettoView soggettoView = null;
        Hashtable soggettoXMLDetailsTable = null;
        String outputMessage = null;
        try {
        	xmlSoggetto = AnagrafeManagerBeanHelper.handleXMLMetaCharecterInFiveLevelXML(xmlSoggetto);
        	xmlSoggetto = AnagrafeManagerBeanHelper.addOperationTagInFiveLevelXML(xmlSoggetto);
        	log4Debug.debug(" AnagrafeManagerBean : validateSoggettoXML : xmlSoggetto :",xmlSoggetto);
            final int tipoSoggettoIndex = xmlSoggetto.indexOf("TipoSoggetto");
            final String temp = xmlSoggetto.substring(tipoSoggettoIndex - 1, xmlSoggetto.indexOf('>', tipoSoggettoIndex));
            if (temp.indexOf("Semplice") == -1 && temp.indexOf("Plurintestazione") == -1) {
            	beanHelper = new AnagrafeManagerBeanAZHelper();
            	checkToValidateSchema(xmlSoggetto, "AZ_XSD",isXSDChkRequired);
                soggettoView = beanHelper.getViewAfterParsingPrivacyFiveLevelXML(xmlSoggetto);
                soggettoXMLDetailsTable = beanHelper.validateSoggettoXML(soggettoView);
            } else if (temp.indexOf("Semplice") != -1) {
            	beanHelper = new AnagrafeManagerBeanPFHelper();
            	checkToValidateSchema(xmlSoggetto, "PF_XSD",isXSDChkRequired);
                soggettoView = beanHelper.getViewAfterParsingPrivacyFiveLevelXML(xmlSoggetto);
                new AMBBaseHelper().setDocudmentRilasciatoDa(soggettoView);
                soggettoXMLDetailsTable = beanHelper.validateSoggettoXML(soggettoView);
            } else { // Plurintestazione handling
            	beanHelper = new AnagrafeManagerBeanPLHelper();
            	checkToValidateSchema(xmlSoggetto, "PL_XSD",isXSDChkRequired);
                soggettoView = beanHelper.getViewAfterParsingPrivacyFiveLevelXML(xmlSoggetto);
                soggettoXMLDetailsTable = beanHelper.validateSoggettoXML(soggettoView);
            }
            if( soggettoXMLDetailsTable != null && !soggettoXMLDetailsTable.isEmpty()) {
            	final CommonHelper commonHelper = new CommonHelper();
            	if( soggettoXMLDetailsTable.get(IHelperConstants.VALIDATE_XML_STATUS_KO) != null ) {
            		//outputMessage = "KO:" + soggettoXMLDetailsTable.get(IHelperConstants.VALIDATE_XML_STATUS_VALUES);
            		outputMessage = commonHelper.getOutputXMLForValidateXML((String)soggettoXMLDetailsTable.get(IHelperConstants.VALIDATE_XML_STATUS_VALUES), "1");
            	} else if( soggettoXMLDetailsTable.get(IHelperConstants.VALIDATE_XML_STATUS_OKKO) != null ) {
            		//outputMessage = "OK:" + soggettoXMLDetailsTable.get(IHelperConstants.VALIDATE_XML_STATUS_VALUES);
            		outputMessage = commonHelper.getOutputXMLForValidateXML((String)soggettoXMLDetailsTable.get(IHelperConstants.VALIDATE_XML_STATUS_VALUES), "2");
            	} else if( soggettoXMLDetailsTable.get(IHelperConstants.VALIDATE_XML_STATUS_OK) != null ) {
            		outputMessage = commonHelper.getOutputXMLForValidateXML(null, "0");
            		/*if( soggettoXMLDetailsTable.get(IHelperConstants.VALIDATE_XML_STATUS_VALUES) != null )  {
            			outputMessage = "OK:" + soggettoXMLDetailsTable.get(IHelperConstants.VALIDATE_XML_STATUS_VALUES);
            		} else {
            			outputMessage = "OK";
            		}*/
            	}
            }
            log4Debug.debug(" AnagrafeManagerBean : validateSoggettoXML : outputMessage :",outputMessage);
        } catch (final BeanHelperException e) {
            log4Debug.warnStackTrace(e);
            throw new OperazioneCensimentoException(e.getMessage());
        } catch (final SubSystemHandlerException e) {
        	 log4Debug.warnStackTrace(e);
             throw new OperazioneCensimentoException(e.getMessage());
		} catch (final XMLSchemaValidationException e) {
			log4Debug.warnStackTrace(e);
			throw new OperazioneCensimentoException(e.getMessage());
		}
        return outputMessage;
    }

    private String variaSoggettoXMLIsXSDChkRequired( final String xmlSoggetto , final Long soggettoId , final boolean isXSDChkRequired ) throws OperazioneCensimentoException, RemoteException {
        Long operationId = null;
        AnagrafeManagerBeanHelper anagrafeManagerBeanHelper = null;
        final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
        final StringBuffer soggettoBuffer = new StringBuffer("<?xml version='1.0' encoding='UTF-8'?>");
        final XMLSoggettiHandler xmlSoggettiHandler = new XMLSoggettiHandler();
        String operationCode = "ANAG-RTNO";
        String errorMessage = null;
        try {
        	final String encodedSoggettoDetails = AnagrafeManagerBeanHelper.handleXMLMetaCharecterInFiveLevelXML(xmlSoggetto);
            final int tipoSoggettoIndex = encodedSoggettoDetails.indexOf("TipoSoggetto");
            if(tipoSoggettoIndex == -1) {// To avoid IndexOutOfBoundsException
            	errorMessage = IValidationMessage.XML_INVALID;
    			throw new OperazioneCensimentoException(errorMessage);
            }
            final String tipoSoggetto = encodedSoggettoDetails.substring(tipoSoggettoIndex - 1, encodedSoggettoDetails.indexOf('>', tipoSoggettoIndex));
             if (tipoSoggetto.indexOf("Semplice") != -1 && xmlSoggettiHandler.isValidSoggetto(soggettoId, "Semplice")) {
            	 anagrafeManagerBeanHelper =  new AnagrafeManagerBeanPFHelper();            	 
            	 operationCode = "ANAG-VRPF";            	 
            	 checkToValidateSchema(xmlSoggetto, "PF_XSD",isXSDChkRequired);
            	 operationId = anagrafeLoggerHelper.logAnagrafeOperation(null , true, operationCode, soggettoId ,null);
                log4Debug.debug("AnagrafeManagerBean : variaSoggettoXML : operationId ===>>> " , operationId);
                soggettoBuffer.append(xmlSoggettiHandler.variaSoggettoXML(
						encodedSoggettoDetails, soggettoId, operationId,(AnagrafeManagerBeanPFHelper) anagrafeManagerBeanHelper));
            } else if(tipoSoggetto.indexOf("Semplice") == -1 && tipoSoggetto.indexOf("Plurintestazione") == -1 && xmlSoggettiHandler.isValidSoggetto(soggettoId,"AZIENDE")) { 
            	// VaraiaSoggetto XML for AZiende 
            	anagrafeManagerBeanHelper =  new AnagrafeManagerBeanAZHelper();
            	operationCode = "ANAG-VRAZ";
            	log4Debug.debug("AnagrafeManagerBean : Varaia Soggetto XMl ==========================  AZIENDE : isXSDChkRequired ===>>> " , isXSDChkRequired);
            	checkToValidateSchema(xmlSoggetto, "AZ_XSD", isXSDChkRequired);
            	operationId = anagrafeLoggerHelper.logAnagrafeOperation(null, true, operationCode, soggettoId, null);
            	log4Debug.debug("AnagrafeManagerBean : Varaia Soggetto XMl ==========================  AZIENDE : operationId ===>>> " , operationId);
            	soggettoBuffer.append(xmlSoggettiHandler.variaSoggettoAZXML(xmlSoggetto, soggettoId, operationId, (AnagrafeManagerBeanAZHelper) anagrafeManagerBeanHelper));
        	}else {
            	errorMessage = new AnagrafeHelper().getMessage("ANAG-1529");
            	throw new OperazioneCensimentoException(errorMessage);
            }
        }  catch (final LoggerException e) {
        	errorMessage = e.getMessage();
        	handleExceptionWithLog(soggettoId, operationId, anagrafeLoggerHelper, e);
        } catch (final BeanHelperException e) {
        	errorMessage = e.getMessage();
        	handleExceptionWithLog(soggettoId, operationId, anagrafeLoggerHelper, e);
        } catch (final XMLSchemaValidationException e) {
        	errorMessage = IValidationMessage.XML_INVALID+" : "+e.getMessage();
        	throw new OperazioneCensimentoException(errorMessage);
		} finally {
            try {
            	final String logMsg = getLongWithEndDataWriteTag(anagrafeManagerBeanHelper != null ? anagrafeManagerBeanHelper.getLogMsg() : "")+"<SoggettoId>"+soggettoId+"</SoggettoId>";
            	if(soggettoBuffer.indexOf("<ESITO>1</ESITO>") == -1 && errorMessage == null){
            		getOperazioneAnagrafeManager().logMessageForAnagrafeManager( soggettoId ,"PERFORM CENSIMENTO MODIFICA XML", logMsg, operationCode, true);
            	}else{
            		getOperazioneAnagrafeManager().logMessageForAnagrafeManager( soggettoId ,"PERFORM CENSIMENTO MODIFICA XML",
            				"PROBLEM_IN_PERFORM_CENSIMENTO_MODIFICA_XML", operationCode, false);
            	}
                if ( operationId != null ) {
                	anagrafeLoggerHelper.logAnagrafeOpDetails(operationId,anagrafeManagerBeanHelper != null ? anagrafeManagerBeanHelper.getLogForHost(): "",xmlSoggetto);
                }
            } catch (final LoggerException le) {
                handleExceptionWithoutLog(le);
            } catch (final OperazioneAnagrafeManagerException le) {
                handleExceptionWithoutLog(le);
            }
        }
        return soggettoBuffer.toString();
    }

    private String variaSoggettoXMLCompletoIsXSDChkRequired( final String xmlSoggetto , final Long soggettoId , final boolean isXSDChkRequired ) throws OperazioneCensimentoException, RemoteException {
        Long operationId = null;
        final AnagrafeManagerBeanPFHelper anagrafeManagerBeanPFHelper =  new AnagrafeManagerBeanPFHelper();
        final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
        final StringBuffer soggettoBuffer = new StringBuffer("<?xml version='1.0' encoding='UTF-8'?>");
        final XMLSoggettiHandler xmlSoggettiHandler = new XMLSoggettiHandler();
        final String operationCode = "ANAG-VRPF";
        String errorMessage = null;
        try {
        	final String encodedSoggettoDetails = AnagrafeManagerBeanHelper.handleXMLMetaCharecterInFiveLevelXML(xmlSoggetto);
            final int tipoSoggettoIndex = encodedSoggettoDetails.indexOf("TipoSoggetto");
            final String tipoSoggetto = encodedSoggettoDetails.substring(tipoSoggettoIndex - 1, encodedSoggettoDetails.indexOf('>', tipoSoggettoIndex));
             if (tipoSoggetto.indexOf("Semplice") != -1 && xmlSoggettiHandler.isValidSoggetto(soggettoId, "Semplice")) {
            	 checkToValidateSchema(xmlSoggetto, "PF_XSD",isXSDChkRequired);
            	 operationId = anagrafeLoggerHelper.logAnagrafeOperation(null , true, operationCode, soggettoId ,null);
                log4Debug.debug("AnagrafeManagerBean : variaSoggettoXMLCompleto : operationId ===>>> " , operationId);
                soggettoBuffer.append(xmlSoggettiHandler
						.variaSoggettoXMLCompleto(encodedSoggettoDetails,
								soggettoId, operationId,anagrafeManagerBeanPFHelper));
            } else {
            	errorMessage = new AnagrafeHelper().getMessage("ANAG-1529");
            	throw new OperazioneCensimentoException(errorMessage);
            }
        }  catch (final LoggerException e) {
        	errorMessage = e.getMessage();
        	handleExceptionWithLog(soggettoId, operationId, anagrafeLoggerHelper, e);
        } catch (final BeanHelperException e) {
        	errorMessage = e.getMessage();
        	handleExceptionWithLog(soggettoId, operationId, anagrafeLoggerHelper, e);
        } catch (final XMLSchemaValidationException e) {
        	errorMessage = IValidationMessage.XML_INVALID+" : "+e.getMessage();
        	throw new OperazioneCensimentoException(errorMessage);
		} finally {
            try {
            	final String logMsg = getLongWithEndDataWriteTag(anagrafeManagerBeanPFHelper.getLogMsg())+"<SoggettoId>"+soggettoId+"</SoggettoId>";
            	if(soggettoBuffer.indexOf("<ESITO>1</ESITO>") == -1 && errorMessage == null){
            		getOperazioneAnagrafeManager().logMessageForAnagrafeManager( soggettoId ,"PERFORM CENSIMENTO MODIFICA XML", logMsg, operationCode, true);
            	}else{
            		getOperazioneAnagrafeManager().logMessageForAnagrafeManager( soggettoId ,"PERFORM CENSIMENTO MODIFICA_XML",
            				"PROBLEM_IN_PERFORM_CENSIMENTO_MODIFICA_XML", operationCode, false);
            	}

                if ( operationId != null ) {
                	anagrafeLoggerHelper.logAnagrafeOpDetails(operationId,anagrafeManagerBeanPFHelper.getLogForHost(),xmlSoggetto);
                }
            } catch (final LoggerException le) {
                handleExceptionWithoutLog(le);
            } catch (final OperazioneAnagrafeManagerException le) {
                handleExceptionWithoutLog(le);
            }
        }
        return soggettoBuffer.toString();
    }


	private void handleExceptionWithoutLog( final Exception e ) throws RemoteException, OperazioneCensimentoException {
		log4Debug.severeStackTrace(e);
		this.getSessionContext().setRollbackOnly();
		throw new OperazioneCensimentoException(e.getMessage());
	}

	private void handleExceptionWithLog( final Long soggettoId, final Long operationId, final AnagrafeLoggerHelper anagrafeLoggerHelper,
			final Exception e ) throws RemoteException, OperazioneCensimentoException {
		log4Debug.warnStackTrace(e);
		this.getSessionContext().setRollbackOnly();
		final String errMessage = e.getMessage();
		anagrafeLoggerHelper.updateAnagrafeLog(operationId, soggettoId, (errMessage != null && errMessage.length() > 1000 ? errMessage.substring(0, 1000) : errMessage));
		throw new OperazioneCensimentoException(errMessage);
	}

	private String getLongWithEndDataWriteTag(final String input) {
		return input.endsWith("</DataWrite>") ? input : input.indexOf("<DataWrite>") != -1 ?
				new StringBuffer(input).append("</DataWrite>").toString() : input;
	}

	public String creaSoggettoXML(final String xmlSoggetto) throws OperazioneCensimentoException, RemoteException {
		return creaSoggettoXMLIsXSDChkRequired(xmlSoggetto, false);
	}
	public String creaSoggettoXMLWithHost( final String xmlSoggetto ) throws OperazioneCensimentoException, RemoteException {
		return creaSoggettoXMLWithHostIsXSDChkRequired(xmlSoggetto, false, true);
	}
	public String variaSoggettoXML( final String xmlSoggetto , final Long soggettoId ) throws OperazioneCensimentoException, RemoteException {
		return variaSoggettoXMLIsXSDChkRequired(xmlSoggetto, soggettoId,false);
	}
	public String variaSoggettoXMLCompleto( final String xmlSoggetto , final Long soggettoId ) throws OperazioneCensimentoException, RemoteException {
		return variaSoggettoXMLCompletoIsXSDChkRequired(xmlSoggetto, soggettoId, false);
	}
	public String validateSoggettoXML( final String xmlSoggetto ) throws OperazioneCensimentoException, RemoteException {
		return validateSoggettoXMLIsXSDChkRequired(xmlSoggetto,false);
	}

	public String creaSoggettoXMLWithXSDValidation(final String xmlSoggetto) throws OperazioneCensimentoException, RemoteException {
		return creaSoggettoXMLIsXSDChkRequired(xmlSoggetto, true);
	}
	public String creaSoggettoXMLWithHostWithXSDValidation( final String xmlSoggetto ) throws OperazioneCensimentoException, RemoteException {
		return creaSoggettoXMLWithHostIsXSDChkRequired(xmlSoggetto, true, true);
	}
	public String variaSoggettoXMLWithXSDValidation( final String xmlSoggetto , final Long soggettoId ) throws OperazioneCensimentoException, RemoteException {
		return variaSoggettoXMLIsXSDChkRequired(xmlSoggetto, soggettoId,true);
	}
	public String variaSoggettoXMLCompletoWithXSDValidation( final String xmlSoggetto , final Long soggettoId ) throws OperazioneCensimentoException, RemoteException {
		return variaSoggettoXMLCompletoIsXSDChkRequired(xmlSoggetto, soggettoId, true);
	}
	public String validateSoggettoXMLWithXSDValidation( final String xmlSoggetto ) throws OperazioneCensimentoException, RemoteException {
		return validateSoggettoXMLIsXSDChkRequired(xmlSoggetto,true);
	}

	public Collection ricercaAZDenominazione( final Properties properties ) throws RicercaException, RemoteException {
    	try {
   			new GestoreDisponibilitaHandler().checkDisponibilita(IAziendaConstants.RICERCA_AZ);
    		return new RicercaDBAccessHelper().ricercaAZDenominazione(properties);
		} catch (final GestoreSoggettoException e) {
			log4Debug.debugStackTrace(e);
			throw new RicercaException(e.getMessage());
		}
		 catch (final SubSystemHandlerException e) {
			 log4Debug.debugStackTrace(e);
			 throw new RicercaException(e.getMessage());
 		}
	}

    public Collection ricercaAZDenominazioneSuccursale( final Properties properties, final String codiceSuccursale ) throws RicercaException, RemoteException {
    	try {
    		new GestoreDisponibilitaHandler().checkDisponibilita(IAziendaConstants.RICERCA_AZ);
    		return new RicercaDBAccessHelper().ricercaAZDenominazioneSuccursale(properties, codiceSuccursale);
    	} catch (final GestoreSoggettoException e) {
			log4Debug.debugStackTrace(e);
			throw new RicercaException(e.getMessage());
    	}
		catch (final SubSystemHandlerException e) {
			log4Debug.debugStackTrace(e);
			throw new RicercaException(e.getMessage());
   		}

    }
    public String creaSoggettoXMLForBPAAutoCens( final String xmlSoggetto ) throws OperazioneCensimentoException, RemoteException {
    	try {
    		final ClassificazioneView classificazioneView = new ClassificazioneHandler().getClassificazioneViewFromDescription("ANAG_PARAMETER", "AUTO_CENS_CSSE_ALLOWED");

    		boolean  isCSSECheckAllowed = true;

    		if(classificazioneView != null && "false".equals(classificazioneView.getCausale())){
    			isCSSECheckAllowed = false;
    		}
    		log4Debug.debug("AnagrafeManagerBean : creaSoggettoXMLForBPAAutoCens : isCSSECheckAllowed ==>",isCSSECheckAllowed);
    		return creaSoggettoXMLWithHostIsXSDChkRequired(xmlSoggetto, true, isCSSECheckAllowed);
    	} catch (final SubSystemHandlerException e) {
    		log4Debug.debugStackTrace(e);
    		throw new OperazioneCensimentoException(e.getMessage());
    	}
    }

	public Long createSellaLifeCustomer(final Long mainSoggettoId, final DatiAnagraficiAZView datiAnagraficiAZView) throws OperazioneCensimentoException, RemoteException {
        Long soggettoId = null;
        Long operationId = null;
        String logOperation = null;
        SoggettoView soggettoView = null;
        AnagrafeManagerBeanAZHelper anagrafeManagerBeanHelper = null;
        final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
        final OperazioneAnagrafeManager operazioneAnagrafeManager = getOperazioneAnagrafeManager();
        try {
        	logOperation = "ANAG-CNAZ";
            anagrafeManagerBeanHelper = new AnagrafeManagerBeanAZHelper();
            operationId = anagrafeLoggerHelper.logAnagrafeOperation(null, true, logOperation, null,null);
            log4Debug.debug("AnagrafeManagerBean : createSellaLifeCustomer : operationId ====>",operationId);
            soggettoId = new SellaLifeDBAccessHelper().createSoggetto(mainSoggettoId, datiAnagraficiAZView, operationId);
            log4Debug.debug("AnagrafeManagerBean : createSellaLifeCustomer : New soggettoId ====>",soggettoId);
            soggettoView = new AziendaFactory().getAzienda_withOutEjbCall(soggettoId);
            soggettoView.setOpId(operationId);
            anagrafeManagerBeanHelper.buildLogAndDoHostAlignMentForSellaLifeCust(soggettoView);
            operazioneAnagrafeManager.updateAnagrafeLog(operationId, soggettoId);
        } catch (final LoggerException e) {
        	soggettoId = null;
            changeCodiceHostToNull(soggettoView);
            handleExceptionWithLog(soggettoId, operationId, anagrafeLoggerHelper, e);
        } catch (final BeanHelperException e) {
        	soggettoId = null;
        	changeCodiceHostToNull(soggettoView);
            handleExceptionWithLog(soggettoId, operationId, anagrafeLoggerHelper, e);
        } catch (final OperazioneAnagrafeManagerException e) {
        	soggettoId = null;
        	changeCodiceHostToNull(soggettoView);
            handleExceptionWithLog(soggettoId, operationId, anagrafeLoggerHelper, e);
		} catch (final AziendaFactoryException e) {
			soggettoId = null;
			changeCodiceHostToNull(soggettoView);
			handleExceptionWithLog(soggettoId, operationId, anagrafeLoggerHelper, e);

		} finally {
            try {
                if ( soggettoId != null ) {
                	operazioneAnagrafeManager.logMessageForAnagrafeManager(soggettoId,"PERFORM CENSIMENTO", getLongWithEndDataWriteTag(anagrafeManagerBeanHelper.getLogMsg())+"<SoggettoId>"+soggettoId+"</SoggettoId>", logOperation, true);
                } else {
                	operazioneAnagrafeManager.logMessageForAnagrafeManager(null,"PERFORM CENSIMENTO", "PROBLEM_IN_PERFORM_CENSIMENTO", logOperation, false);
                }
                if( operationId != null ) {
                	anagrafeLoggerHelper.logAnagrafeOpDetails(operationId,anagrafeManagerBeanHelper.getLogForHost(),"");
                }
            } catch (final LoggerException le) {
                handleExceptionWithoutLog(le);
            } catch (final OperazioneAnagrafeManagerException le) {
                handleExceptionWithoutLog(le);
            }
        }
        return soggettoId;
    }

	private void checkToValidateSchema(final String xmlSoggetto , final String soggettoXsdUrlKey, final boolean isXSDChkRequired ) throws XMLSchemaValidationException{
		if(isXSDChkRequired){
			new SchemaValidator().validate(xmlSoggetto, soggettoXsdUrlKey);
		}
	}
	
	private void allowPosteUserCreation(final Collection motivi) throws BeanHelperException { // Get Confermation
    	final AnagrafeHelper helper = new AnagrafeHelper();
    	if(helper.checkForMotiv(motivi,"POSTE") && !helper.isExistsuperiorMotivThanPOSTE(motivi) && !helper.isPosteSubjectCreationAllowed()) {
    		throw new BeanHelperException(new AnagrafeHelper().getMessage("ANAG-1741"));
    	}
    }
}
