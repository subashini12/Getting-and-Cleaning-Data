package it.sella.anagrafe.implementation;

import it.sella.anagrafe.CanalePreferitoDataView;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreAttributiEsterniException;
import it.sella.anagrafe.GestoreCittaException;
import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.anagrafe.GestoreCollegamentoException;
import it.sella.anagrafe.GestoreDatiAnagrafeException;
import it.sella.anagrafe.GestoreDatiFiscaliException;
import it.sella.anagrafe.GestoreDatiPrivacyException;
import it.sella.anagrafe.GestoreEventiException;
import it.sella.anagrafe.GestoreMemoException;
import it.sella.anagrafe.GestoreNazioneException;
import it.sella.anagrafe.GestoreProvinciaException;
import it.sella.anagrafe.GestoreRecapitoException;
import it.sella.anagrafe.GestoreSoggettoException;
import it.sella.anagrafe.IAPView;
import it.sella.anagrafe.IAttributiTramiteView;
import it.sella.anagrafe.ICanalePreferitoDataView;
import it.sella.anagrafe.ICanaleUtilizzatoView;
import it.sella.anagrafe.ICapDetailView;
import it.sella.anagrafe.ICapView;
import it.sella.anagrafe.ICittaView;
import it.sella.anagrafe.IClasseATECOView;
import it.sella.anagrafe.IClienteClassificazione;
import it.sella.anagrafe.IDAIRegoleDetail;
import it.sella.anagrafe.IDAISoggettoData;
import it.sella.anagrafe.IDAIStoricDataView;
import it.sella.anagrafe.IDatiAnagraficiView;
import it.sella.anagrafe.IDatiPrivacyFiveLevelView;
import it.sella.anagrafe.IDocumentiView;
import it.sella.anagrafe.IFatturatoView;
import it.sella.anagrafe.INazioneView;
import it.sella.anagrafe.IOrigineClienteView;
import it.sella.anagrafe.IPoteriDiFirmaDocumentView;
import it.sella.anagrafe.IProvinciaView;
import it.sella.anagrafe.IRecapitiView;
import it.sella.anagrafe.ISAEView;
import it.sella.anagrafe.ISettoreView;
import it.sella.anagrafe.ISocioDetailsView;
import it.sella.anagrafe.ISoggettiResidenteFiscaleView;
import it.sella.anagrafe.ISoggettoBankView;
import it.sella.anagrafe.ITAEView;
import it.sella.anagrafe.IUltimoAggiornamentoView;
import it.sella.anagrafe.InformazioneManagerException;
import it.sella.anagrafe.OperazioneAnagrafeFactory;
import it.sella.anagrafe.OperazioneCensimentoException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.az.ICollegatiAbilAziendaView;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.dai.GestoreAPIDAICalculatorHelper;
import it.sella.anagrafe.dao.IBankAddressDAO;
import it.sella.anagrafe.dao.IDocumentiDAO;
import it.sella.anagrafe.dao.IProfessioneDAO;
import it.sella.anagrafe.dao.impl.BankAddressDAOImpl;
import it.sella.anagrafe.dbaccess.AEValoreGetter;
import it.sella.anagrafe.dbaccess.AlboProfessioneHandler;
import it.sella.anagrafe.dbaccess.AreaGetterHelper;
import it.sella.anagrafe.dbaccess.AttributiEsterniDBAccessHelper;
import it.sella.anagrafe.dbaccess.AttributiTramiteDBAccessHelper;
import it.sella.anagrafe.dbaccess.BancaDettagliGetterHelper;
import it.sella.anagrafe.dbaccess.CSCifratiGetterHelper;
import it.sella.anagrafe.dbaccess.CSSoggettoIdGetter;
import it.sella.anagrafe.dbaccess.CanalePreferitoDBAccessHelper;
import it.sella.anagrafe.dbaccess.CapTableHandler;
import it.sella.anagrafe.dbaccess.CittaDBAccessHelper;
import it.sella.anagrafe.dbaccess.ClasseATECODBAccessHelper;
import it.sella.anagrafe.dbaccess.CodiceFiscaliGenerator;
import it.sella.anagrafe.dbaccess.CodiceSoggettoDBAccessHelper;
import it.sella.anagrafe.dbaccess.CollegamentoDBAccessHelper;
import it.sella.anagrafe.dbaccess.CompatibilityHelper;
import it.sella.anagrafe.dbaccess.DaiAZGetterHelper;
import it.sella.anagrafe.dbaccess.DaiPFGetterHelper;
import it.sella.anagrafe.dbaccess.DatiAnagraficiGetterHelper;
import it.sella.anagrafe.dbaccess.DatiFiscaliDBAccessHelper;
import it.sella.anagrafe.dbaccess.DatiFiscaliSoggettoIdGetter;
import it.sella.anagrafe.dbaccess.DocPoteriFirmaGetterHelper;
import it.sella.anagrafe.dbaccess.DocumentiDBAccessHelper;
import it.sella.anagrafe.dbaccess.DocumentiGetterHelper;
import it.sella.anagrafe.dbaccess.DocumentiUpdateHelper;
import it.sella.anagrafe.dbaccess.EventiDBAccessHelper;
import it.sella.anagrafe.dbaccess.FlussiDaiHandler;
import it.sella.anagrafe.dbaccess.FlussiSconfHandler;
import it.sella.anagrafe.dbaccess.Flussi_Art136Helper;
import it.sella.anagrafe.dbaccess.IntestazioneGetterHelper;
import it.sella.anagrafe.dbaccess.LogDBAccessHelper;
import it.sella.anagrafe.dbaccess.MemoDBAccessHelper;
import it.sella.anagrafe.dbaccess.NazioneDBAccessHelper;
import it.sella.anagrafe.dbaccess.OrigineClienteDBAccessHelper;
import it.sella.anagrafe.dbaccess.PrivacyDBAccessHelper;
import it.sella.anagrafe.dbaccess.ProvinciaDBAccessHelper;
import it.sella.anagrafe.dbaccess.RecapitiDBAccessHelper;
import it.sella.anagrafe.dbaccess.RegioneHandler;
import it.sella.anagrafe.dbaccess.RicercaDBAccessHelper;
import it.sella.anagrafe.dbaccess.SconfHandler;
import it.sella.anagrafe.dbaccess.SettoreDiAttivitaHandler;
import it.sella.anagrafe.dbaccess.SettoreHandler;
import it.sella.anagrafe.dbaccess.SoggettoDBAccessHelper;
import it.sella.anagrafe.dbaccess.TAEHandler;
import it.sella.anagrafe.dbaccess.TipoSoggettoHandler;
import it.sella.anagrafe.dbaccess.USorigin_Util;
import it.sella.anagrafe.dbaccess.VirtualUserHelper;
import it.sella.anagrafe.dbaccess.dai.DAIDBAccessHelper;
import it.sella.anagrafe.discriminator.AttributiEsterniDiscriminatorException;
import it.sella.anagrafe.discriminator.CodiceSoggettoDiscriminatorException;
import it.sella.anagrafe.discriminator.CollegamentoException;
import it.sella.anagrafe.factory.DocumentiDAOFactory;
import it.sella.anagrafe.factory.ProfessioneDAOFactory;
import it.sella.anagrafe.hostlog.HostLoggerException;
import it.sella.anagrafe.pf.DocumentoPFView;
import it.sella.anagrafe.pf.ICollegatiAbilSoggView;
import it.sella.anagrafe.pf.IndirizzoPFView;
import it.sella.anagrafe.regione.IRegione;
import it.sella.anagrafe.sm.admin.StoricRicercaHelper;
import it.sella.anagrafe.sm.censimentopf.ICensimentoPFConstants;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.AnagrafeLoggerHelper;
import it.sella.anagrafe.util.CanalePreferitoException;
import it.sella.anagrafe.util.ClienteClassificazioneUtilHelper;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.DocumentiException;
import it.sella.anagrafe.util.FatturatoHelper;
import it.sella.anagrafe.util.GestoreDisponibilitaHandler;
import it.sella.anagrafe.util.HelperException;
import it.sella.anagrafe.util.MessageManagerHandler;
import it.sella.anagrafe.util.PartitivaEsteraException;
import it.sella.anagrafe.util.ProfessioneException;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.anagrafe.util.StringHandler;
import it.sella.anagrafe.util.deprecationutil.DeprecationScannerUtil;
import it.sella.anagrafe.validator.PartitaIvaEsteroValidator;
import it.sella.anagrafe.validator.documentvalidator.DocumentValidatorHelper;
import it.sella.anagrafe.view.IDocumentiMasterView;
import it.sella.anagrafe.view.StoricRicercaView;
import it.sella.classificazione.ClassificazioneView;
import it.sella.ejb.SessionBeanAdapter;
import it.sella.logserver.LoggerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.util.Vector;

public class GestoreAnagrafeImplBean extends SessionBeanAdapter {

    /**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(GestoreAnagrafeImplBean.class);

    /** This method returns the corresponding nazioneView for the nazione id
     * which is being passed
     * @ param Long Nazioneid
     * @ return INazioneView
     * @ exception GestoreNazioneException
     * @ exception RemoteException
     */

    public INazioneView getNazione( final Long nazioneId ) throws GestoreNazioneException, RemoteException {
        return new NazioneDBAccessHelper().getNazione(nazioneId);
    }

    /** This method returns the collection of nazioneView
     * @ return Collection of InazioneView
     * @ exception GestoreNazioneException
     * @ exception RemoteException
     * The search criteria are specified in the Hashtable . The keys are : NAZIONE_ID , NA_NOME
     * NA_CODICE_UIC , NA_CODICE_ISO , NA_STORICO , NA_NAZIONE , NA_HA_EMBARGO
     */

    public Collection getNazione( final Hashtable searchCriteria ) throws GestoreNazioneException, RemoteException {
        return new NazioneDBAccessHelper().getNazione(searchCriteria);
    }

    /** This method returns the collection of nazioneView
     * @ return Collection of InazioneView
     * @ exception GestoreNazioneException
     * @ exception RemoteException
     */

    public Collection getAllNazione() throws GestoreNazioneException, RemoteException {
        return new NazioneDBAccessHelper().getAllNazione();
    }

    /**
     * This method will return ICittaView for a given citta Id
     * @ param Long cittaId to which the cittaView has to be retrieved
     * @ return ICittaView
     * @ exception GestoreCittaException
     * @ exception RemoteException
     */

    public ICittaView getCitta( final Long cittaId ) throws GestoreCittaException, RemoteException {
        return new CittaDBAccessHelper().getCitta(cittaId);
    }

    /**
     * This method will return Collection of Citta Views
     * @ return Collection CittaView collection
     * @ exception GestoreCittaException
     * @ exception RemoteException
     */

    public Collection getAllCitta() throws GestoreCittaException, RemoteException {
        return new CittaDBAccessHelper().getAllCitta();
    }

    public List getCittaView( final String provincia ) throws GestoreCittaException, RemoteException {
        if ( provincia == null || (provincia.trim().length()) < 1 ) {
    		try {
				throw new GestoreCittaException(new MessageManagerHandler().getMessage("ANAG-1166"));
			} catch (final SubSystemHandlerException e) {
				log4Debug.debugStackTrace(e);
				throw new GestoreCittaException(e.getMessage());
			}
    	}
    	return new CittaDBAccessHelper().getCittaView(provincia.toUpperCase());
    }
    /**
     * the method will return a provincia view for a given provincia sigla
     * @ param String sigla
     * @ return IProvinciaView
     * @ exception GestoreProvinciaException
     * @ exception RemoteException
     */

    public IProvinciaView getProvincia( final String sigla ) throws GestoreProvinciaException, RemoteException {
        return new ProvinciaDBAccessHelper().getProvincia(sigla);
    }

    /**
     * the method will return a provincia view for a given provincia id
     * @ param Long provinceId
     * @ return IProvinciaView
     * @ exception GestoreProvinciaException
     * @ exception RemoteException
     */

    public IProvinciaView getProvincia( final Long provinceId ) throws GestoreProvinciaException, RemoteException {
        return new ProvinciaDBAccessHelper().getProvincia(provinceId);
    }

    /**
     * This method will return the IRecapitiView interface for the given input
     * @ Long soggetto id an the causale of the tipo recapito
     * @ return Collection
     * @ exception GestoreRecapitoException
     * @ exception RemoteException
     */

    public Collection getRecapiti( final Long soggettoId,  final String tipoRecapitoCausale ) throws GestoreRecapitoException, RemoteException {
        return new RecapitiDBAccessHelper().getRecapiti(soggettoId, tipoRecapitoCausale);
    }

    /**
     * This method will return a collection of the recapito View interface for a given soggetto Id.
     * @ param Long soggettoId
     * @ return Collection
     * @ exception GestoreRecapitoException
     * @ exception RemoteException
     */

    public Collection getRecapitiForSoggetto( final Long soggettoId ) throws GestoreRecapitoException, RemoteException {
        return new RecapitiDBAccessHelper().getRecapitiForSoggetto(soggettoId);
    }

    /**
     * This method will return a specific recapiti details
     * for a  given recapito Id which will be an input of type long for this method.
     * @ param Long recapitiId
     * @ return IRecapitiView the view for the corresponding recapitoId
     * @ exception GestoreRecapitoException
     * @ exception RemoteException
     */

    public IRecapitiView getSpecificRecapiti( final Long recapitoId ) throws GestoreRecapitoException, RemoteException {
        return new RecapitiDBAccessHelper().getSpecificRecapiti(recapitoId);
    }

    /**
     * This method to insert/delete/update for perticular soggetto recapiti details.
     * The operation should be INSERT/UPDATE/DELETE
     * @ param Long soggettoId, String operation, String causaleTipoRecapiti, String note, String valoreRecapiti
     * @ return void
     * @ exception GestoreRecapitoException
     * @ exception RemoteException
     */

    public void setRecapitiBasedOnOperation( final Long soggettoId, final String operation, final String causaleTipoRecapiti, final String note, final String valoreRecapiti) throws GestoreRecapitoException, RemoteException {
        new RecapitiDBAccessHelper().setRecapitiBasedOnOperation(soggettoId,operation,causaleTipoRecapiti,note,valoreRecapiti,null);
    }

    public String getNormalizedRecapiti( final String valoreRecapiti ) throws GestoreRecapitoException, RemoteException {
        return new RecapitiDBAccessHelper().getNormalizedRecapiti(valoreRecapiti);
    }

    /**
     * This method will return the Collection of soggetto id's .
     * the input will be the String of the tipodatiprivacy required and the value of the dati fiscali (a boolean that can be true or false)
     * @ param String -- The type of datiprivacy
     * @ param String value of the datiprivacy
     * @ Collection -- Datiprivacyviews for the tipodatiprivacy and valoredatiprivacy
     * @ exception GestoreDatiPrivacyException
     * @ exception RemoteException
     */

    public Collection getSoggettoIds( final String tipoDatiPrivacyCausale, final String valoreDatiPrivacy ) throws GestoreDatiPrivacyException, RemoteException {
        return new PrivacyDBAccessHelper().getSoggettoIds(tipoDatiPrivacyCausale, valoreDatiPrivacy);
    }

    /**
     * This method will return the Collection of IDatiPrivacyView interface for the given
     * soggetto id
     * @ param Long soggettoId
     * @ return Collection
     * @ exception GestoreDatiPrivacyException
     * @ exception RemoteException
     */
    public Collection getDatiPrivacy( final Long soggettoId ) throws GestoreDatiPrivacyException, RemoteException {
        return new PrivacyDBAccessHelper().getDatiPrivacy(soggettoId);
    }

    /**
     * This method will return the IDatiPrivacyFiveLevelView interface for the given
     * soggetto id
     * @ param Long soggettoId
     * @ return IDatiPrivacyFiveLevelView
     * @ exception GestoreDatiPrivacyException
     * @ exception RemoteException
     */
    public IDatiPrivacyFiveLevelView getDatiPrivacyFiveLevel( final Long soggettoId ) throws GestoreDatiPrivacyException, RemoteException {
        try {
        	validateSoggettoId(soggettoId);
        	return new PrivacyDBAccessHelper().getDatiPrivacyFiveLevel(soggettoId);
        } catch(final GestoreAnagrafeException gae) {
            log4Debug.severeStackTrace(gae);
            throw new GestoreDatiPrivacyException(gae.getMessage());
        }
    }

    /**
     * This method accepts the causale of a tipo soggetto.
     *  Example: Second level tipo soggetto like "Semplice" or "Plurintestazione"
     *  giving the first level i.e. "PF" will give a null collection.
     *
     * @ return Collection  soggettoIds ----- SoggettoIds
     * @ exception GestoreSoggettoException
     * @ exception RemoteException
     */
    public Collection getSoggetti( final String causale ) throws GestoreSoggettoException, RemoteException {
        return new SoggettoDBAccessHelper().getSoggetti(causale);
    }

    /**
     * This method would fetch all the soggetti from the anagrafe db unconditionally.
     * @ return Collection soggettoIds -- Collection of soggetto ids
     * @ exception GestoreSoggettoException
     * @ exception RemoteException
     */

    public Collection getAllSoggetti() throws GestoreSoggettoException, RemoteException { //Unnecessary Local Before Return
        return new Vector();// This method will be removed.. Not advisable to call.. so empty collection returned

    }

    public Collection getDatiFiscali( final Long soggettoId ) throws GestoreDatiFiscaliException, RemoteException {
        return new DatiFiscaliDBAccessHelper().getDatiFiscali(soggettoId);
    }

    public String getDatiFiscali( final Long soggettoId, final String motivo ) throws GestoreDatiFiscaliException, RemoteException {
        return new DatiFiscaliDBAccessHelper().getDatiFiscali(soggettoId, motivo);
    }

    public void setAltriDatiFiscali( final Long soggettoId, final String causale, final String valore ) throws GestoreDatiFiscaliException, RemoteException {
    	new DatiFiscaliDBAccessHelper().setAltriDatiFiscali(soggettoId, causale, valore, null);
    }

    public Boolean getCalculatedUSPerson( final Long soggettoId ) throws GestoreDatiFiscaliException, RemoteException {
        return new USorigin_Util().isUSOriginNew(soggettoId);
    }

    public Long getSoggettoIdDF( final String causale, final String valoreDatiFiscal ) throws GestoreDatiFiscaliException, RemoteException {
        return new DatiFiscaliDBAccessHelper().getSoggettoIdDF(causale, valoreDatiFiscal);
    }

    public Collection getAllProvincia() throws GestoreProvinciaException, RemoteException  {
        return new ProvinciaDBAccessHelper().getAllProvincia();
    }

    public Collection getAllSoggettoIdCS( final String causale, final String valoreCodiceSoggetto ) throws GestoreCodiciSoggettoException, RemoteException {
        return new CodiceSoggettoDBAccessHelper().getAllSoggettoIdCS(causale, valoreCodiceSoggetto);
    }

    public Long getSoggettoIdCS( final String causale, final String valoreCodiceSoggetto ) throws GestoreCodiciSoggettoException, RemoteException {
        return new CodiceSoggettoDBAccessHelper().getSoggettoIdCS(causale, valoreCodiceSoggetto);
    }

    public String getValoreCodiciSoggetto( final Long soggettoId, final String causale ) throws GestoreCodiciSoggettoException, RemoteException {
        return new CodiceSoggettoDBAccessHelper().getValoreCodiciSoggetto(soggettoId, causale);
    }

    public Collection getCodiciSoggetto( final Long soggettoId ) throws GestoreCodiciSoggettoException, RemoteException {
        return new CodiceSoggettoDBAccessHelper().getCodiciSoggetto(soggettoId);
    }

    public Collection getMemo( final Long soggettoId ) throws GestoreMemoException, RemoteException {
        return new MemoDBAccessHelper().getMemo(soggettoId);
    }

    public void createMemo(final it.sella.anagrafe.MemoView memoView) throws GestoreMemoException, RemoteException {
    	new MemoDBAccessHelper().createMemo(memoView, null);
    }

    public void updateMemo( final it.sella.anagrafe.MemoView memoView ) throws GestoreMemoException, RemoteException {
    	final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
    	String errorMessage = null;
    	Long opId = null;
    	try {
			opId = anagrafeLoggerHelper.logAnagrafeOperation(null,false,"ANAG-API-MEMO-UPD",memoView.getSoggettoId(),null);
			new MemoDBAccessHelper().updateMemo(memoView, opId);
            anagrafeLoggerHelper.logAnagrafeOpDetails(opId,"","");
        } catch (final LoggerException e) {
        	errorMessage = e.getMessage();
            log4Debug.warnStackTrace(e);
            throw new GestoreMemoException(errorMessage);
        } finally {
        	try {
				anagrafeLoggerHelper.updateAnagrafeLog(opId,memoView.getSoggettoId(),errorMessage);
			} catch (final OperazioneCensimentoException e) {
	            log4Debug.warnStackTrace(e);
			}
        }
    }

    public void deleteMemo( final it.sella.anagrafe.MemoView memoView ) throws GestoreMemoException, RemoteException {
    	new MemoDBAccessHelper().deleteMemo(memoView, null);
    }

    public boolean isExistsMemo( final Long soggettoId ) throws GestoreMemoException, RemoteException {
        return new MemoDBAccessHelper().isExistsMemo(soggettoId);
    }

    public void deleteAllMemo( final Long soggettoId ) throws GestoreMemoException, RemoteException {
    	final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
    	String errorMessage = null;
    	Long opId = null;
        try {
    		opId = anagrafeLoggerHelper.logAnagrafeOperation(null,false,"ANAG-API-MEMO-DEL",soggettoId,null);
    		new MemoDBAccessHelper().deleteAllMemo(soggettoId, opId);
            anagrafeLoggerHelper.logAnagrafeOpDetails(opId,"","");
        } catch (final LoggerException e) {
            log4Debug.warnStackTrace(e);
            errorMessage = e.getMessage();
            throw new GestoreMemoException(errorMessage);
        } finally {
        	try {
				anagrafeLoggerHelper.updateAnagrafeLog(opId,soggettoId,errorMessage);
			} catch (final OperazioneCensimentoException e) {
	            log4Debug.warnStackTrace(e);
			}
        }
    }

    public String getIntestazioneString( final Long soggettoId ) throws GestoreDatiAnagrafeException, RemoteException {
    	return new IntestazioneGetterHelper().getIntestazioneString(soggettoId);
    }

    public IDatiAnagraficiView getAnagraficiView( final Long soggettoId ) throws GestoreDatiAnagrafeException, RemoteException {
        return new DatiAnagraficiGetterHelper().getAnagraficiView(soggettoId);
    }

 /*   public Collection getDatiAnagraficiView(Long soggettoId) throws GestoreDatiAnagrafeException, RemoteException {
    	if(soggettoId == null) {
    		throw new GestoreDatiAnagrafeException("SoggettoId is null !!!");
    	}
        return new DatiAnagraficiGetterHelper().getDatiAnagraficiView(soggettoId);
    } */

    public Collection getAttributiEsterniAndValues( final Long soggettoId ) throws GestoreAttributiEsterniException, RemoteException {
        return new AttributiEsterniDBAccessHelper().getAttributiEsterniAndValues(soggettoId);
    }

    public String getAttribuiEsterniValore( final Long soggettoId, final String causale ) throws GestoreAttributiEsterniException, RemoteException {
        return new AttributiEsterniDBAccessHelper().getAttribuiEsterniValore(soggettoId, causale);
    }

    public Collection getSoggettoIdForTipoAttributoEsterno( final String tipoAttributiCausale, final String valoreAttributiesterniCausale) throws GestoreAttributiEsterniException, RemoteException {
        if(!"cosg".equals(tipoAttributiCausale)){
        	throw new GestoreAttributiEsterniException("Method not supported.Because datas are huge");
        }
    	return new AttributiEsterniDBAccessHelper().getSoggettoIdForTipoAttributoEsterno(tipoAttributiCausale, valoreAttributiesterniCausale);
    }

    public Collection getValuesForTipoAttributoEsterno( final String tipoAttributiEsterniCausale ) throws GestoreAttributiEsterniException, RemoteException {
        return new AttributiEsterniDBAccessHelper().getValuesForTipoAttributoEsterno(tipoAttributiEsterniCausale);
    }

    public Collection getLinkedSoggetto( final Long soggettoId ) throws GestoreCollegamentoException, RemoteException {
        return new CollegamentoDBAccessHelper().getLinkedSoggetto(soggettoId);
    }

    public Collection getLinkedSoggetto( final Long soggettoId, final String tipoCollagamentoCausale ) throws GestoreCollegamentoException, RemoteException {
        return new CollegamentoDBAccessHelper().getLinkedSoggetto(soggettoId, tipoCollagamentoCausale);
    }

    /**
     * This method will create a link for the given soggettos for a particular motive.
     * The principal soggetto id and the linked soggetto id should be given.
     * The motive should be the causale found in the Classificazione table under the Parent Causale MOTIV.
     * if the Data Inizio is not given then the System date will be assigned to it.
     */

    public void TerminateLink( final Long id, final Timestamp dataFine ) throws GestoreCollegamentoException, RemoteException {
    	new CollegamentoDBAccessHelper().TerminateLink(id, dataFine);
    }

    public Long createCollegamento( final it.sella.anagrafe.CollegamentoView collegamentoView ) throws GestoreCollegamentoException, RemoteException {
    	final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
    	Long opId = null;
    	String errorMessage = null;
    	Long linkId = null;
    	try {
    		opId = anagrafeLoggerHelper.logAnagrafeOperation(null,false,"ANAG-API-COLL-CREATE",collegamentoView.getLinkedSoggettoId(),null);
    		collegamentoView.setOpId(opId);
    		linkId = new CollegamentoDBAccessHelper().createCollegamento(collegamentoView);
            anagrafeLoggerHelper.logAnagrafeOpDetails(collegamentoView.getOpId(),"","");
    	} catch (final LoggerException e) {
        	errorMessage = e.getMessage();
            log4Debug.warnStackTrace(e);
            throw new GestoreCollegamentoException(errorMessage);
        } finally {
        	try {
				anagrafeLoggerHelper.updateAnagrafeLog(opId,collegamentoView.getLinkedSoggettoId(),errorMessage);
			} catch (final OperazioneCensimentoException e) {
	            log4Debug.warnStackTrace(e);
			}
        }
        return linkId;
    }

    /**
     * This method will update the end date of a link with the System Date.
     * The id refers to the primary key of the table
     */

    public void TerminateLink( final Long id ) throws GestoreCollegamentoException, RemoteException {
    	new CollegamentoDBAccessHelper().TerminateLink(id);
    }

    /**
     * This method will return a collection of IEventiView for a given soggetto id
     * and ClassificazioneView for tipo eventi.
     */

    public Collection getEventiForSoggetto( final Long soggettoId, final String tipoEvento, final Timestamp dataInizio, final Timestamp dataFine ) throws GestoreEventiException, RemoteException {
        return new EventiDBAccessHelper().getEventiForSoggetto(soggettoId, tipoEvento, dataInizio, dataFine);
    }

    /**
     * this method will return a collection of soggetto ids having the particular tipo eventi.
     * The ClassificazioneView (Tipo eventi) is mandatory while the dates are optional input parameters.
     */

    public Collection getSoggettiIds( final String tipoEvento, final Timestamp dataInizio, final Timestamp dataFine ) throws GestoreEventiException, RemoteException {
    	return new EventiDBAccessHelper().getSoggettiIds(tipoEvento, dataInizio, dataFine);
    }

    /**
     * This method will return a collection of IEventiView .
     * The soggetto id is a mandatory input while the start date and end dates are optional .
     */

    public Collection getEventi( final Long soggettoId, final Timestamp dataInizio, final Timestamp dataFine ) throws GestoreEventiException, RemoteException {
        return new EventiDBAccessHelper().getEventi(soggettoId, dataInizio, dataFine);
    }

    public void createEventi( final String eventoXml ) throws GestoreEventiException, RemoteException {
    	new EventiDBAccessHelper().createEventi(eventoXml);
    }

    /**
     * This method will return all the documents associated with the specified
     * soggetto(Collection of IDocumentiView). The input will be of type long (SoggettoId)
     */

    public Collection getAllDocumenti( final Long soggettoId ) throws GestoreAnagrafeException, RemoteException {
    	//Called for depreacted api DECAF-11
    	new DeprecationScannerUtil().getDeprecatedObjectCaller(this.getClass(), "DECAF-11"); 
        return new DocumentiDBAccessHelper().getAllDocumenti(soggettoId);
    }

    public Collection getMandatoryDocumentAggiuntiviForSubject( final Long soggettoId ) throws GestoreAnagrafeException, RemoteException {
    	//Called for depreacted api DECAF-13
    	new DeprecationScannerUtil().getDeprecatedObjectCaller(this.getClass(), "DECAF-13"); 
        return new DocumentiDBAccessHelper().getMandatoryDocumentAggiuntiviForSubject(soggettoId);
    }

    public Collection getDocumenti( final Long soggettoId, final String documentCausale ) throws GestoreAnagrafeException, RemoteException {
    	//Called for depreacted api DECAF-12
    	new DeprecationScannerUtil().getDeprecatedObjectCaller(this.getClass(), "DECAF-12"); 
        return new DocumentiGetterHelper().getDocumenti(soggettoId, documentCausale);
    }

    public String getTipoSoggetto( final Long soggettoId ) throws GestoreSoggettoException, RemoteException {
        return new TipoSoggettoHandler().getTipoSoggetto(soggettoId);
    }

    public Long getTipoSoggetto( final String tipoSoggettoDescrizione ) throws GestoreSoggettoException, RemoteException {
        return new TipoSoggettoHandler().getTipoSoggetto(tipoSoggettoDescrizione);
    }

    /**
     * @ param String Nome
     * @ param String Cognome
     * @ param Timestamp DataDiNascita
     * @ param String LuogoNascitaCitta
     * @ param String LuogoNascitaNazione
     * This method will return a Collection of the SoggettoIds of PF's matching the given input values.
     * The returned structure is a Collection of type Long SoggettoIds.
     */

    public Collection getSoggettiPF( final String nome, final String cognome, final Timestamp dataDiNascita, final String luogoNascitaCitta, final String luogoNascitaNazione ) throws GestoreSoggettoException, RemoteException {
        return new SoggettoDBAccessHelper().getSoggettiPF(nome, cognome, dataDiNascita, luogoNascitaCitta, luogoNascitaNazione);
    }

    /**
     * @ param String Denominazione
     * This method will return a Collection of the SoggettoIds of Aziende matching the given input values.
     *  The returned structure is a Collection of type Long SoggettoIds.
     */

    public Collection getSoggettiAZ( final String Denominazione ) throws GestoreSoggettoException, RemoteException {
        return new ArrayList();
    }

    /**
     * @ param Long SoggettoID
     * This method will return a Collection of the SoggettoIds (and relative TipoCollegamentos) to which the input SoggettoId is linked.
     */

    public Collection getSoggettoPrincipale( final Long soggettoId ) throws GestoreCollegamentoException, RemoteException {
        return new CollegamentoDBAccessHelper().getSoggettoPrincipale(soggettoId);
    }

    /**
     * @ param Long SoggettoID
     * @ param String motivo
     * This method will return a Collection of the SoggettoIds to which the input SoggettoId is linked with
     * the TipoCollegamento that has been provided as an input. The TipoCollegamento must be the causale found in the CLASSIFICAZIONE table for CL_CAUSALE = MOTIV.
     */

    public Collection getSoggettoPrincipale( final Long soggettoId, final String tipoCollegamento ) throws GestoreCollegamentoException, RemoteException {
        return new CollegamentoDBAccessHelper().getSoggettoPrincipale(soggettoId, tipoCollegamento);
    }

    /**
     * @ param Long soggettoId
     * @ param attributes Key MOTIVE : to which motive the link to be terminated and it should be of type collection
     Key ENDDATE : the link to be terminated on which date
     * @ return boolean indicating whether the soggetto falls under the given tipo soggetto
     * @ exception GestoreCollegamentoException
     */

    public void terminateLink( final Long linkedSoggettoId, final Hashtable attributes ) throws GestoreCollegamentoException, RemoteException {
    	final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
    	String errorMessage = null;
    	Long opId = null;
        try {
    		opId = anagrafeLoggerHelper.logAnagrafeOperation(null,false,"ANAG-API-COLL-TERM",linkedSoggettoId,null);
    		new CollegamentoDBAccessHelper().terminateLink(linkedSoggettoId, attributes,opId);
            anagrafeLoggerHelper.logAnagrafeOpDetails(opId,"","");
        } catch (final LoggerException e) {
        	errorMessage = e.getMessage();
            log4Debug.warnStackTrace(e);
            throw new GestoreCollegamentoException(errorMessage);
        } finally {
        	try {
				anagrafeLoggerHelper.updateAnagrafeLog(opId,linkedSoggettoId,errorMessage);
			} catch (final OperazioneCensimentoException e) {
	            log4Debug.warnStackTrace(e);
			}
        }
    }

    /**
     * @ param Long soggettoId
     * @ param String descrizione of the tipo soggetto
     * @ return boolean indicating whether the soggetto falls under the given tipo soggetto
     * @ exception GestoreSoggettoException
     */

    public boolean isValidSoggetto( final Long soggettoId, final String descrizione ) throws GestoreSoggettoException, RemoteException {
        return new SoggettoDBAccessHelper().isValidSoggetto(soggettoId, descrizione);
    }

    /**
     @ param Long soggettoId
     @ return String descrizione of the parent tipo soggetto of the soggetto
     @ exception GestoreSoggettoException
     */
    public String getParentTipoSoggetto( final Long soggettoId ) throws GestoreSoggettoException, RemoteException {
        return new TipoSoggettoHandler().getParentTipoSoggetto(soggettoId);
    }


    public Hashtable getAllTipoSoggettoForParent( final String parentTipoSoggettoDesc )  throws GestoreSoggettoException, RemoteException {
    	try {
    		if(parentTipoSoggettoDesc == null || parentTipoSoggettoDesc.trim().length() < 1) {
        		throw new GestoreSoggettoException(new AnagrafeHelper().getMessage("ANAG-1482"));
        	}
        	if("AZIENDA".equals(parentTipoSoggettoDesc)) {
    			return new CompatibilityHelper().getCompatibleTipoSoggetto();
    		} else if("PERSONA".equals(parentTipoSoggettoDesc)) {
    			return new CompatibilityHelper().getCompatibleTipoSoggetto(parentTipoSoggettoDesc);
    		} else {
    			throw new GestoreSoggettoException(new AnagrafeHelper().getMessage("ANAG-1483"));
    		}
    	} catch (final InformazioneManagerException e) {
    		log4Debug.severeStackTrace(e);
    		throw new GestoreSoggettoException(e.getMessage());
		}
    }

    public String getSettoreDescription( final String idSettore ) throws GestoreAttributiEsterniException, RemoteException {
        return new SettoreHandler().getSettoreDescription(idSettore,true);
    }

    public Collection getAllSettore() throws GestoreAnagrafeException, RemoteException {
        return new SettoreHandler().getAllSettore();
    }


    public Collection getCompatibleTipoSocieta( final Long tipoSoggettoId ) throws GestoreAttributiEsterniException, RemoteException {
    	try {
    		if(tipoSoggettoId == null) {
    			throw new GestoreAttributiEsterniException(new AnagrafeHelper().getMessage("ANAG-1484"));
    		}
    		return new CompatibilityHelper().getCompatibleTipoSocietaForTipoSoggetto(tipoSoggettoId);
    	} catch(final InformazioneManagerException e) {
    		log4Debug.severeStackTrace(e);
	        throw new GestoreAttributiEsterniException(e.getMessage());
	    }
    }

    public Collection getCompatibleSettore( final Long tipoSoggettoId, final Long tipoSocietaId ) throws GestoreAttributiEsterniException, RemoteException {
    	try {
    		if(tipoSoggettoId == null) {
        		throw new GestoreAttributiEsterniException(new AnagrafeHelper().getMessage("ANAG-1485"));
        	}
			return new SettoreHandler().listSettore(tipoSoggettoId,tipoSocietaId);
		} catch (final InformazioneManagerException e) {
			log4Debug.severeStackTrace(e);
	        throw new GestoreAttributiEsterniException(e.getMessage());
	    }
    }

    /**
     * @ param Long soggettoId
     * @ return Collection of collegamentoviews
     * @ exception GestoreCollegamentoException,RemoteException
     */
    public Collection getAziendaPrincipalSoggetto( final Long soggettoId ) throws GestoreCollegamentoException, RemoteException {
        return new CollegamentoDBAccessHelper().getAziendaPrincipalSoggetto(soggettoId);
    }

    public Collection getSoggettiOfMotiv( final String nome, final String cogNome, final Long bancaId, final String motiv ) throws GestoreDatiAnagrafeException, RemoteException {
        return new CollegamentoDBAccessHelper().getSoggettiOfMotiv(nome, cogNome, bancaId, motiv);
    }

    /** This method returns the hosttiposoggetto based on the value passed in
     * hastable
     */

    public String getHostTipoSoggetto( final Hashtable data ) throws GestoreSoggettoException, RemoteException {
        return new TipoSoggettoHandler().getHostTipoSoggetto(data);
    }

    public void setCodiceValues( final Long soggettoId, final String value, final String codiciSoggettoCausale ) throws GestoreCodiciSoggettoException, RemoteException {
    	String errorMessage = null;
    	Long opId = null;
    	final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
    	try {
    		opId = anagrafeLoggerHelper.logAnagrafeOperation(null,false,"ANAG-API-CS",soggettoId,null);
    		new CodiceSoggettoDBAccessHelper().setCodiceValues(soggettoId, value, codiciSoggettoCausale, opId);
            anagrafeLoggerHelper.logAnagrafeOpDetails(opId,"","");
		} catch (final CodiceSoggettoDiscriminatorException e) {
			log4Debug.warnStackTrace(e);
			errorMessage = e.getMessage();
			throw new GestoreCodiciSoggettoException(errorMessage);
		} catch (final LoggerException e) {
        	errorMessage = e.getLocalizedMessage();
            log4Debug.warnStackTrace(e);
            throw new GestoreCodiciSoggettoException(errorMessage);
        } finally {
        	try {
				anagrafeLoggerHelper.updateAnagrafeLog(opId,soggettoId,errorMessage);
			} catch (final OperazioneCensimentoException e) {
	            log4Debug.warnStackTrace(e);
			}
        }
    }

    public Collection getSoggettiCollegatiAbilitati( final Long principalSoggettoId ) throws GestoreCollegamentoException, RemoteException {
        return new CollegamentoDBAccessHelper().getSoggettiCollegatiAbilitati(principalSoggettoId);
    }

    public boolean isValidProvince( final String province ) throws GestoreProvinciaException, RemoteException {
        return new ProvinciaDBAccessHelper().isValidProvince(province);
    }

    public boolean isValidProvince( final String province, final String citta ) throws GestoreProvinciaException, RemoteException {
        return new ProvinciaDBAccessHelper().isValidProvince(province, citta);
    }

    public boolean isValidCAP( final String cap ) throws GestoreAnagrafeException, RemoteException {
        return new CapTableHandler().isValidCAP(cap);
    }

    public boolean isValidCAP( final String cap, final String provinciaSigla ) throws GestoreAnagrafeException, RemoteException {
        return new CapTableHandler().isValidCAP(cap, provinciaSigla);
    }

    public ICittaView getCitta( final String commune ) throws GestoreCittaException, RemoteException {
        return new CittaDBAccessHelper().getCitta(commune);
    }

    public ICittaView getCitta( final String commune, final String provinciaSigla ) throws GestoreCittaException, RemoteException {
        return new CittaDBAccessHelper().getCitta(commune, provinciaSigla);
    }

    public boolean isValidCitta( final String citta ) throws GestoreCittaException, RemoteException {
        return new CittaDBAccessHelper().isValidCitta(citta);
    }

    public boolean isValidAnagraficCitta( final String citta ) throws GestoreCittaException, RemoteException {
        return new CittaDBAccessHelper().isValidAnagraficCitta(citta);
    }

    public boolean isValidCitta( final String cittaName, final String provincia ) {
        return new CittaDBAccessHelper().isValidCitta(cittaName, provincia);
    }

    public ICapView getCap( final String capValue ) throws GestoreAnagrafeException, RemoteException {
        return new CapTableHandler().getCap(capValue);
    }

    public ICapView getCap( final Long capId ) throws GestoreAnagrafeException, RemoteException {
        return new CapTableHandler().getCap(capId);
    }

    public ICapView getCap( final String capValue, final String citta ) throws GestoreAnagrafeException, RemoteException {
        return new CapTableHandler().getCap(capValue, citta);
    }

    public Long getArea( final Long soggettoId, final Long bancaId ) throws GestoreCollegamentoException, RemoteException {
        return new AreaGetterHelper().getArea(soggettoId, bancaId);
    }

    public void replaceCollegamento( final Long oldSoggettoId, final Long newSoggettoId, final String motivCausale ) throws GestoreCollegamentoException, RemoteException {
    	final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
    	String errorMessage = null;
    	Long opId = null;
        try {
    		opId = anagrafeLoggerHelper.logAnagrafeOperation(null,false,"ANAG-API-COLL-SWAP",newSoggettoId,null);
        	new CollegamentoDBAccessHelper().replaceCollegamento(oldSoggettoId, newSoggettoId, motivCausale, opId);
            anagrafeLoggerHelper.logAnagrafeOpDetails(opId,"","");
        } catch (final LoggerException e) {
        	this.getSessionContext().setRollbackOnly();
        	errorMessage = e.getMessage();
            log4Debug.warnStackTrace(e);
            throw new GestoreCollegamentoException(errorMessage);
        } catch (final GestoreCollegamentoException e) {
        	this.getSessionContext().setRollbackOnly();
        	errorMessage = e.getMessage();
            log4Debug.warnStackTrace(e);
            throw new GestoreCollegamentoException(errorMessage);
        } finally {
        	try {
				anagrafeLoggerHelper.updateAnagrafeLog(opId,newSoggettoId,errorMessage);
			} catch (final OperazioneCensimentoException e) {
	            log4Debug.warnStackTrace(e);
			}
        }
    }

    public Hashtable listSoggetto( final Long tipoSoggettoId, final String causale ) throws GestoreSoggettoException, RemoteException {
        return new SoggettoDBAccessHelper().listSoggetto(tipoSoggettoId, causale);
    }

    public String getNormalisedString( final String unnormalisedString ) throws GestoreDatiAnagrafeException, RemoteException {
        return new StringHandler().getNormalisedString(unnormalisedString);
    }

    public void validatePartitaIva( final String partitaIva ) throws GestoreDatiFiscaliException, RemoteException {
    	new DatiFiscaliDBAccessHelper().validatePartitaIva(partitaIva);
    }


    public void validateNumericCodiceFiscale( final String codiceFiscale ) throws GestoreDatiFiscaliException, RemoteException {
    	new DatiFiscaliDBAccessHelper().validateNumericCodiceFiscale(codiceFiscale);
    }

    public String getCodiceFiscale( final String cogNome, final String nome, final Timestamp dataDiNascita, final ICittaView luogoDiNascitaCitta, final INazioneView luogoDiNascitaNazione, final String causaleSesso ) throws GestoreDatiFiscaliException, RemoteException {
        return new CodiceFiscaliGenerator().getCodiceFiscale(cogNome, nome, dataDiNascita, luogoDiNascitaCitta, luogoDiNascitaNazione, causaleSesso);
    }

    public Long getSoggettoIdForCodiceHost( final String codiceHost ) throws GestoreCodiciSoggettoException, RemoteException {
        return new CSSoggettoIdGetter().getSoggettoIdForCodiceHost(codiceHost);
    }

    public Collection getRecapitiSoggettoIDs( final String causale, final String valoreRecapiti ) throws GestoreRecapitoException, RemoteException {
        return new RecapitiDBAccessHelper().getRecapitiSoggettoIDs(causale, valoreRecapiti);
    }

    public Collection getRecapitiSoggettoIDs( final String valoreRecapiti ) throws GestoreRecapitoException, RemoteException {
        return new RecapitiDBAccessHelper().getRecapitiSoggettoIDs(valoreRecapiti);
    }

    public Collection getCollegamentoHistory( final Hashtable inputData ) throws GestoreCollegamentoException, RemoteException {
        return new CollegamentoDBAccessHelper().getCollegamentoHistory(inputData);
    }

    public Collection ricerca( final Properties properties ) throws GestoreSoggettoException, RemoteException {
        return new RicercaDBAccessHelper().ricerca(properties);
    }

    // Added by Karthik.
    public Collection ricercaConSuccursaleDiRiferimento( final Properties properties, final String codiceSuccursale ) throws GestoreSoggettoException, RemoteException {
       	try {
       		new GestoreDisponibilitaHandler().checkDisponibilita(ICensimentoPFConstants.RICERCA_PF);
    		return new RicercaDBAccessHelper().ricercaConSuccursaleDiRiferimento(properties, codiceSuccursale);
	    	}
	    	catch (final SubSystemHandlerException e) {
			throw new GestoreSoggettoException(e.getMessage());
		}
    }

    public Collection getSoggettoPrincipaleViews( final Long soggettoId ) throws GestoreCollegamentoException, RemoteException {
        return new CollegamentoDBAccessHelper().getSoggettoPrincipaleViews(soggettoId);
    }

    public Boolean isSoggettoInSellaGruppo( final Long soggettoId ) throws GestoreSoggettoException, RemoteException {
        return new SoggettoDBAccessHelper().isSoggettoInSellaGruppo(soggettoId);
    }

    public Long createVirtualUser() throws GestoreDatiAnagrafeException, RemoteException {
        try {
            return new VirtualUserHelper().createVirtualUser();
        } catch (final CollegamentoException e) {
            this.getSessionContext().setRollbackOnly();
            log4Debug.severeStackTrace(e);
            throw new GestoreDatiAnagrafeException(e.getMessage());
        }
    }

    public String getDaiPFOnAnagrafici( final Long soggettoId ) throws RemoteException, GestoreAnagrafeException {
        return new DaiPFGetterHelper().getDaiPFOnAnagrafici(soggettoId);
    }

    public String getDaiAZOnAnagrafici(final Long soggettoId) throws RemoteException, GestoreAnagrafeException {
    	return new DaiAZGetterHelper().getDaiAZOnAnagrafici(soggettoId);
    }

    public boolean isDocumentoNumeroInvalid( final String tipodocumentocausale, final String numerodocumento ) throws GestoreAnagrafeException, RemoteException {
        return new DocumentiDBAccessHelper().isDocumentoNumeroInvalid(tipodocumentocausale, numerodocumento);
    }

    public void updateSconf( final Long soggettoId, final String newSconf ) throws GestoreAnagrafeException, RemoteException {
    	new SconfHandler().updateSconf(soggettoId, newSconf,true);
    }

    public String getCodiceHostCifrati( final Long soggettoId ) throws GestoreCodiciSoggettoException, RemoteException {
        return new CSCifratiGetterHelper().getCodiceHostCifrati(soggettoId);
    }

    public void gestoreAnagrafeBiboEvento( final String soggettoDetails, final String valore, final String hostUserCode ) throws GestoreAnagrafeException, RemoteException {
        try {
        	new EventiDBAccessHelper().gestoreAnagrafeBiboEvento(soggettoDetails,valore,hostUserCode);
        } catch (final GestoreAnagrafeException e) {
            this.getSessionContext().setRollbackOnly();
            log4Debug.severeStackTrace(e);
            throw new GestoreAnagrafeException(e.getMessage());
        }
    }

    public void gestoreAnagrafeBiboSconfino( final String soggettoDetails, final String valore, final String hostUserCode ) throws GestoreAnagrafeException, RemoteException {
        try {
        	new FlussiSconfHandler().gestoreAnagrafeBiboSconfino(soggettoDetails, valore, hostUserCode,true);
        } catch (final GestoreAnagrafeException e) {
            this.getSessionContext().setRollbackOnly();
            log4Debug.severeStackTrace(e);
            throw new GestoreAnagrafeException(e.getMessage());
        }
    }

    public void gestoreAnagrafeBiboDipct( final String soggettoDetails, final String valore, final String hostUserCode ) throws GestoreAnagrafeException, RemoteException {
        try {
        	if("Y".equals(new BancaDettagliGetterHelper().getCheckDipct(SecurityHandler.getLoginBancaId()))){
        		new CollegamentoDBAccessHelper().gestoreIntermediariFlussiAnagrafe("DIPCT", "coddp", soggettoDetails, valore, hostUserCode, "A39");
        	}
        } catch (final GestoreAnagrafeException e) {
            handleFlussiException(e);
        }
    }

    public void gestoreAnagrafeBiboProct( final String soggettoDetails, final String valore, final String hostUserCode ) throws GestoreAnagrafeException, RemoteException {
        try {
        	new CollegamentoDBAccessHelper().gestoreIntermediariFlussiAnagrafe("PROCT", "codpr", soggettoDetails, valore, hostUserCode, "A80");
        } catch (final GestoreAnagrafeException e) {
            handleFlussiException(e);
        }
    }

    public void gestoreAnagrafeBiboDai( final String soggettoDetails, final String valore, final String hostUserCode ) throws GestoreAnagrafeException, RemoteException {
        try {
        	new FlussiDaiHandler().gestoreAnagrafeBiboDai(soggettoDetails, valore, hostUserCode,true);
        } catch (final GestoreAnagrafeException e) {
            this.getSessionContext().setRollbackOnly();
            log4Debug.severeStackTrace(e);
            throw new GestoreAnagrafeException(e.getMessage());
        }
    }

    public void setAttributiEsterni( final Long soggettoId, final String causale, final String valore ) throws GestoreAnagrafeException, RemoteException {
    	final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
    	String errorMessage = null;
    	Long opId = null;
        try {
        	final AnagrafeHelper helper = new AnagrafeHelper();
            if (!"stato".equals(causale)) {
				throw new GestoreAnagrafeException(helper.getMessage("ANAG-1286"));
			}
            if (!("Operativa".equals(valore) || "NonOperativa".equals(valore))) {
				final String errorMessages = "Valore ";
				throw new GestoreAnagrafeException(errorMessages + helper.getMessage("ANAG-1287"));
			}
            if (new CollegamentoDBAccessHelper().getSoggettoCollegante(soggettoId,ClassificazioneHandler.getClassificazioneView("CENST","MOTIV").getCausale()).size()==0) {
				throw new GestoreAnagrafeException(helper.getMessage("ANAG-1288"));
			}
    		opId = anagrafeLoggerHelper.logAnagrafeOperation(null,false,"ANAG-API-AE",soggettoId,null);
            new AttributiEsterniDBAccessHelper().setAttributiEsterniValues(soggettoId,valore,causale,opId);
            anagrafeLoggerHelper.logAnagrafeOpDetails(opId,"","");
        } catch (final LoggerException e) {
        	errorMessage = e.getLocalizedMessage();
            log4Debug.warnStackTrace(e);
            throw new GestoreAnagrafeException(errorMessage);
		} catch (final AttributiEsterniDiscriminatorException e) {
        	errorMessage = e.getLocalizedMessage();
            log4Debug.warnStackTrace(e);
            throw new GestoreAnagrafeException(errorMessage);
        } catch (final SubSystemHandlerException e) {
        	errorMessage = e.getLocalizedMessage();
            log4Debug.warnStackTrace(e);
            throw new GestoreAnagrafeException(errorMessage);
        } catch (final CollegamentoException e) {
        	errorMessage = e.getLocalizedMessage();
            log4Debug.warnStackTrace(e);
            throw new GestoreAnagrafeException(errorMessage);
        } finally {
        	try {
				anagrafeLoggerHelper.updateAnagrafeLog(opId,soggettoId,errorMessage);
			} catch (final OperazioneCensimentoException e) {
	            log4Debug.warnStackTrace(e);
			}
        }
    }

    public void gestoreAnagrafeBiboSvilct( final String soggettoDetails, final String valore, final String hostUserCode ) throws GestoreAnagrafeException, RemoteException {
        try {
        	new CollegamentoDBAccessHelper().gestoreIntermediariFlussiAnagrafe("SVICT", "codsv", soggettoDetails, valore, hostUserCode, "A80");
        } catch (final GestoreAnagrafeException e) {
            handleFlussiException(e);
        }
    }

	private void handleFlussiException(final GestoreAnagrafeException e)
			throws RemoteException, GestoreAnagrafeException {
		this.getSessionContext().setRollbackOnly();
		log4Debug.warnStackTrace(e);
		final String message = e.getMessage();
		log4Debug.severe(message);
		throw new GestoreAnagrafeException(message);
	}

    public Collection getAllBanks() throws GestoreAnagrafeException, RemoteException {
        return new BancaDettagliGetterHelper().getAllBanks();
    }

    public String getAttivita( final String codiceAttivita ) throws GestoreAnagrafeException, RemoteException {
    	return null;
    	//return new AttivitaHandler().getAttivita(codiceAttivita);
    }

   public void gestoreAnagrafeAmministratoreBanca( final String soggettoDetails, final String valore, final String hostUserCode ) throws GestoreAnagrafeException, RemoteException {
	   try {
		   new Flussi_Art136Helper().gestoreAnagrafeAmministratoreBanca(soggettoDetails,valore,hostUserCode,true);
	   } catch (final GestoreAnagrafeException e) {
		   this.getSessionContext().setRollbackOnly();
		   log4Debug.warnStackTrace(e);
		   throw new GestoreAnagrafeException(e.getMessage());
	   }
   }

   public IOrigineClienteView getOrigineCliente( final Long soggettoId ) throws GestoreAnagrafeException, RemoteException {
	   try {
		return new OrigineClienteDBAccessHelper().getOrigineCliente(soggettoId);
	   } catch (final CollegamentoException e) {
		   log4Debug.warnStackTrace(e);
		   throw new GestoreAnagrafeException(e.getMessage());
	   }
   }

   public Collection getStoricDetails( final StoricRicercaView storicView ) throws GestoreAnagrafeException, RemoteException {
	   Collection storicCollection = null;
	   try {
		   final StoricRicercaHelper  storicRicercaHelper = new StoricRicercaHelper();
		   if( storicView == null || (storicView.getSoggettoId() == null &&
			  (storicView.getParentCausale() == null || storicView.getParentCausale().trim().length() == 0) &&
		      (storicView.getChildCausale() == null || storicView.getChildCausale().trim().length() == 0 ))) {
			    final String errorMessage = "SoggettoId/TypeAttribute/OperationType ";
				throw new ControlloDatiException(errorMessage+new AnagrafeHelper().getMessage("ANAG-1264"));
		   }
		   if(storicView.getSearchOrder() !=null && !"DESC".equalsIgnoreCase(storicView.getSearchOrder()) &&
				   !"ASC".equalsIgnoreCase(storicView.getSearchOrder())) {
			   final String errorMessage = "Search Order must be ASC/DESC";
			   throw new ControlloDatiException(errorMessage);
		   }
		   final int size = storicRicercaHelper.getTotalNoOfOperations(storicView);
		   if(size > 200) {
	        	throw new ControlloDatiException(new AnagrafeHelper().getMessage("ANAG-1336"));
	       }
		   storicCollection = storicRicercaHelper.getStoricDetails(storicView);
	   } catch (final ControlloDatiException e) {
		   log4Debug.warnStackTrace(e);
		   throw new GestoreAnagrafeException(e.getMessage());
	   }
	   return storicCollection;
   }

   public Long getSoggettoIdCodiciCifrati( final String valoreCodiciCifrati ) throws GestoreCodiciSoggettoException, RemoteException {
	   return new CSCifratiGetterHelper().getSoggettoIdCodiciCifrati(valoreCodiciCifrati);
   }

   public Collection getsoggettoIDDFMultiple( final String valoreDatiFiscal, final String causale ) throws GestoreDatiFiscaliException, RemoteException {
	   if(!"codiceFiscali".equals(causale) && !"partitaIva".equals(causale)) {
		   throw new GestoreDatiFiscaliException(new AnagrafeHelper().getMessage("ANAG-1460"));
	   }
	   return new DatiFiscaliSoggettoIdGetter().getsoggettoIDDFMultiple(valoreDatiFiscal,causale);
   }

   public boolean validateCodiceFiscali( final String cogNome, final String nome, final Timestamp dataDiNascita, final ICittaView luogoDiNascitaCitta, final INazioneView luogoDiNascitaNazione, final String causaleSesso, final String inputCodiceFiscali ) throws GestoreDatiFiscaliException, RemoteException {
      return new DatiFiscaliDBAccessHelper().validateCodiceFiscali(cogNome,nome,dataDiNascita,luogoDiNascitaCitta,luogoDiNascitaNazione,causaleSesso,inputCodiceFiscali);
   }

   public  void setOttoCifreCifrati( final Long soggettoId, final String valoreCifrati ) throws GestoreCodiciSoggettoException, RemoteException {
   	try {
   		new CSCifratiGetterHelper().setOttoCifreCifrati(soggettoId,valoreCifrati);
		} catch (final GestoreAnagrafeException e) {
		    log4Debug.severeStackTrace(e);
           throw new GestoreCodiciSoggettoException(e.getMessage());
       }
   }

   public IAttributiTramiteView getAttributiTramite( final Long soggettoId ) throws GestoreCodiciSoggettoException, RemoteException {
		try {
			validateSoggettoId(soggettoId);
			return new AttributiTramiteDBAccessHelper().getAttributiTramite(
					soggettoId,SecurityHandler.getLoginBancaId());
		} catch (final AttributiEsterniDiscriminatorException e) {
		    log4Debug.severeStackTrace(e);
	        throw new GestoreCodiciSoggettoException(e.getMessage());
		} catch (final GestoreAnagrafeException e) {
		    log4Debug.severeStackTrace(e);
	        throw new GestoreCodiciSoggettoException(e.getMessage());
		}
   	}

   public String isExistCodiceFiscaliInExart136( final String valore ) throws GestoreDatiFiscaliException, RemoteException {
	   return new DatiFiscaliDBAccessHelper().isExistCodiceFiscaliInExart136(valore);
   }

   public List getValidDocument( final Long soggettoId )throws GestoreAnagrafeException, RemoteException {
	   return new DocumentiDBAccessHelper().getValidDocument(soggettoId);
   }

   public IDocumentiView getLastValidDocument( final Long soggettoId )throws GestoreAnagrafeException, RemoteException {
	   return new DocumentiDBAccessHelper().getLastValidDocument(soggettoId);
   }

   public ISettoreView getSettore( final String codiceSottoGruppo )
			throws GestoreAnagrafeException, RemoteException {
		try {
			return new SettoreHandler().getSettore(codiceSottoGruppo);
		} catch (final InformazioneManagerException e) {
			log4Debug.severeStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		}
	}

   public IClienteClassificazione getClienteClassificazione( final Long soggettoId )
			throws RemoteException, GestoreAnagrafeException {
		return new ClienteClassificazioneUtilHelper().getClienteClassificazioneView(soggettoId);
	}

	public void setClienteClassificazione(final Long soggettoId,
		final Long numeroDependenti, final BigDecimal fatturato, final BigDecimal bilancio)
		throws RemoteException, GestoreAnagrafeException {
		try {
			new ClienteClassificazioneUtilHelper().setClienteClassificazione(soggettoId,
					numeroDependenti, fatturato, bilancio);
		} catch (final GestoreAnagrafeException e) {
			log4Debug.severeStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		}
	}

	public IFatturatoView getFatturatoView(final Long soggettoId) throws RemoteException, GestoreAnagrafeException {
		return new FatturatoHelper().getFatturatoView(soggettoId);
	}

	public List<IClasseATECOView> getAllAteco2007() throws GestoreAnagrafeException, RemoteException {
		return new ClasseATECODBAccessHelper().getAllAteco2007();
	}

	public String getDescrizioneAteco2007(final String codice) throws GestoreAnagrafeException, RemoteException {
		if (codice == null || codice.trim().length() == 0 ) {
			throw new GestoreAnagrafeException(new AnagrafeHelper().getMessage("ANAG-1581"));
		}
		return new ClasseATECODBAccessHelper().getDescrizioneAteco2007(codice);
	}

	public String getCodiceAteco2007(final String descrizione) throws GestoreAnagrafeException, RemoteException {
		if (descrizione == null || descrizione.trim().length() == 0 ) {
			throw new GestoreAnagrafeException(new AnagrafeHelper().getMessage("ANAG-1582"));
		}
		return new ClasseATECODBAccessHelper().getCodiceAteco2007(descrizione);
	}

    public Collection<ICollegatiAbilSoggView> getSoggettiCollegatiAbilitatiWithPFCheck( final Long principalSoggettoId ) throws GestoreCollegamentoException, RemoteException, GestoreAnagrafeException {
        return new CollegamentoDBAccessHelper().getSoggettiCollegatiAbilitatiWithPFCheck(principalSoggettoId);
    }

    public Collection ricercaAZDenominazione( final Properties properties ) throws GestoreSoggettoException, RemoteException {
    	properties.put("ONLY_SOGGETTOIDS", "TRUE");
    	return new RicercaDBAccessHelper().ricercaAZDenominazione(properties);
    }

    public Collection ricercaAZDenominazioneSuccursale( final Properties properties, final String codiceSuccursale ) throws GestoreSoggettoException, RemoteException {
    	properties.put("ONLY_SOGGETTOIDS", "TRUE");
    	return new RicercaDBAccessHelper().ricercaAZDenominazioneSuccursale(properties, codiceSuccursale);
    }

    public boolean validatePIvaEstero(final String residenteFiscaliNome,final String partitaIvaEstero)
    throws GestoreDatiFiscaliException,RemoteException {
    	try {
			return new PartitaIvaEsteroValidator().validatePIvaEstero(residenteFiscaliNome, partitaIvaEstero);
		} catch (final PartitivaEsteraException e) {
			log4Debug.debugStackTrace(e);
			throw new GestoreDatiFiscaliException(e.getMessage());
		}
    }
	private void validateSoggettoId( final Long soggettoId ) throws GestoreAnagrafeException {
		if( soggettoId == null ) {
       		final String errorMessage = " SoggettoId is null";
			throw new GestoreAnagrafeException(errorMessage);
		}
	}

	public List<ClassificazioneView> listProfessioni(final Long bankId, final Boolean isValid) throws GestoreAnagrafeException, RemoteException {
		try{
			final IProfessioneDAO professionDAO = (IProfessioneDAO) ProfessioneDAOFactory.getInstance().getProfessioneDAOFactoryFinder();
			final Collection<ClassificazioneView> collection=  professionDAO.listProfessione(isValid,bankId);
			return new ArrayList(collection); //Unnecessary Local Before Return
		}
		catch(final ProfessioneException e){
			log4Debug.severeStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		}
	}

	public boolean isAziendaMicroImprese (final Long numeroDipendenti, final BigDecimal fatturato , final BigDecimal bilancio ) throws RemoteException {
		boolean isMicroImprese = false;
		if (numeroDipendenti < 10 && ( isLessthanEqualToValue(fatturato) || isLessthanEqualToValue(bilancio) ) ) {
			isMicroImprese = true;
		}
		return isMicroImprese;
	}

	public boolean isExistsAziendaMicroImprese( final Long soggettoId ) throws RemoteException, GestoreAnagrafeException{
		return new ClienteClassificazioneUtilHelper().isExistsAziendaMicroImprese(soggettoId);
	}

	public Boolean isExistsMicroImpreseForAzienda( final Long soggettoId ) throws RemoteException, GestoreAnagrafeException{
		return new ClienteClassificazioneUtilHelper().isExistsMicroImpreseForAzienda(soggettoId);
	}

	private boolean isLessthanEqualToValue( final BigDecimal value) {
		boolean isValid = false;
		if (value!= null && (value.compareTo( BigDecimal.valueOf(2000)) ==0 || value.compareTo( BigDecimal.valueOf(2000)) == -1  ) ){
			isValid = true;
		}
		return isValid;
	}

	public List<IDocumentiMasterView> listDocumentMaster(final Long bankId,final Boolean isValid) throws GestoreAnagrafeException, RemoteException {
		try {
			final IDocumentiDAO documentiDAO = (IDocumentiDAO) DocumentiDAOFactory.getInstance().getDocumentiDAOFactoryFinder();
			return documentiDAO.listDocumentMaster(bankId, isValid);
		} catch (final DocumentiException docException) {
			log4Debug.severeStackTrace(docException);
			throw new GestoreAnagrafeException(docException.getMessage());
		}

	}

	/**
	 * Method to validate the document
	 * @param tipoDocument
	 * @param documentNumber
	 * @param issuer
	 * @param placeOfIssue
	 * @param dataDiEmissione
	 * @param dataDiScadenza
	 * @param dataDiNascita
	 * @param nazioneNome
	 * @return
	 * @throws RemoteException
	 * @throws GestoreAnagrafeException
	 */
	public boolean checkIsDocumentValid(final String tipoDocument, final String documentNumber, final String issuer, final String placeOfIssue,
			final String dataDiEmissione, final String dataDiScadenza, final String dataDiNascita, final String nazioneNome) throws RemoteException, GestoreAnagrafeException {

		boolean isDocumentValid = false;


		final DocumentoPFView documentoView = new DocumentoPFView();
		final StringBuffer errorMessage = new StringBuffer();

		try {
			if(dataDiEmissione != null){

				final Collection<IndirizzoPFView> indirizzoViewCollection = new DocumentValidatorHelper().buildIndirizzoViewCollection("IRE", nazioneNome);

				new DocumentValidatorHelper().checkDocumentNotNull(documentNumber, dataDiEmissione,
						tipoDocument, issuer, placeOfIssue);

				new DocumentValidatorHelper().buildDocumentView(documentNumber, dataDiEmissione,
						dataDiScadenza, documentoView, tipoDocument, issuer, placeOfIssue);

				new DocumentValidatorHelper().validateBasicDocumentCheck(tipoDocument,  documentoView,
						errorMessage, dataDiNascita, indirizzoViewCollection);

				isDocumentValid = new DocumentValidatorHelper().validateDocument(tipoDocument,
						dataDiNascita, isDocumentValid, documentoView, errorMessage);
			}
		} catch (final HelperException helperException) {
			log4Debug.warnStackTrace(helperException);
			throw new GestoreAnagrafeException(helperException.getMessage());
		} catch (final HostLoggerException hostLoggerException) {
			log4Debug.warnStackTrace(hostLoggerException);
			throw new GestoreAnagrafeException(hostLoggerException.getMessage());
		}

		return isDocumentValid;
	}


	public boolean checkIsDocumentValid( final String tipoDocument, final String documentNumber, final String issuer, final String placeOfIssue, final String dataDiEmissione , final String dataDiScadenza , final String dataDiNascita) throws RemoteException, GestoreAnagrafeException {
		final DocumentoPFView documentoView = new DocumentoPFView();
		final StringBuffer errorMessage = new StringBuffer();
		boolean isDocumentValid = false;
		try {
			if ( dataDiEmissione!= null ) {
				new DocumentValidatorHelper().buildDocumentView(documentNumber, dataDiEmissione,
						dataDiScadenza, documentoView, tipoDocument, issuer, placeOfIssue);

				isDocumentValid = new DocumentValidatorHelper().validateDocument(tipoDocument,
						dataDiNascita, isDocumentValid, documentoView, errorMessage);
			}
		} catch (final HelperException helperException) {
			log4Debug.warnStackTrace(helperException);
			throw new GestoreAnagrafeException(helperException.getMessage());
		} catch (final HostLoggerException hostLoggerException) {
			log4Debug.warnStackTrace(hostLoggerException);
			throw new GestoreAnagrafeException(hostLoggerException.getMessage());
		}

		return isDocumentValid;
	}



	public String getCheckDipct(final Long bankId) throws GestoreAnagrafeException, RemoteException {
        return new BancaDettagliGetterHelper().getCheckDipct(bankId);
    }

	public IUltimoAggiornamentoView getUltimoAggiornamento(final Long soggettoId) throws GestoreAnagrafeException,RemoteException{
		try {
			return new LogDBAccessHelper().getUltimoAggiornamento(soggettoId);
		} catch (final HostLoggerException e) {
			log4Debug.severeStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		}
	}

	public void setFirmaGrafometrica(final Long soggettoId , final String value,final Date dataReferimento) throws GestoreAnagrafeException, RemoteException {
		final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
		String errorMessage = null;
		Long opId = null;
		try {
			opId = anagrafeLoggerHelper.logAnagrafeOperation(null,false,"ANAG-API-SET-FIGRA",soggettoId,null);
			final ClassificazioneView classificazioneView = new ClassificazioneHandler().getClassificazioneViewForChildByParentCausale("FIRMAGRAF", value);
			final TipoSoggettoHandler tipoSoggettoHandler = new TipoSoggettoHandler();
			final String tipoSoggetto = tipoSoggettoHandler.getTipoSoggetto(soggettoId);
			if(tipoSoggetto == null || !"Semplice".equals(tipoSoggetto)){
				throw new GestoreAttributiEsterniException( new AnagrafeHelper().getMessage("ANAG-1288"));
			}
			final AttributiEsterniDBAccessHelper attributiEsterniDBAccessHelper = new AttributiEsterniDBAccessHelper();
			attributiEsterniDBAccessHelper.setAttributiEsterniValues(soggettoId,String.valueOf(classificazioneView.getId()),"firmagraf",opId);
			final DateHandler dateHandler = new DateHandler();
			final Date dataReferimentotmp = dataReferimento != null ? dataReferimento : new Date();
			attributiEsterniDBAccessHelper.setAttributiEsterniValues(soggettoId,dateHandler.getDateSpecifiedFormat(dataReferimentotmp, "dd/MM/yyyy"),"firmadata",opId);
			anagrafeLoggerHelper.logAnagrafeOpDetails(opId,"","");
		} catch (final LoggerException e) {
			errorMessage = e.getMessage();
			log4Debug.warnStackTrace(e);
			throw new GestoreAnagrafeException(errorMessage);
		} catch (final AttributiEsterniDiscriminatorException e) {
			errorMessage = e.getMessage();
			log4Debug.warnStackTrace(e);
			throw new GestoreAnagrafeException(errorMessage);
		} catch (final SubSystemHandlerException e) {
			errorMessage = new AnagrafeHelper().getMessage("ANAG-1341");
			log4Debug.warnStackTrace(e);
			throw new GestoreAnagrafeException(errorMessage);
		} catch (final GestoreAttributiEsterniException e) {
			errorMessage = e.getMessage();
			log4Debug.warnStackTrace(e);
			throw new GestoreAnagrafeException(errorMessage);
		}
		finally {
			try {
				anagrafeLoggerHelper.updateAnagrafeLog(opId,soggettoId,errorMessage);
			} catch (final OperazioneCensimentoException e) {
				log4Debug.warnStackTrace(e);
			}
		}
	}


	public void setProfessioniDetails(final Long soggettoId ,final String causale) throws GestoreAnagrafeException, RemoteException {
		Long opId = null;
		try {
			if ( soggettoId != null ) {
				opId = new AnagrafeLoggerHelper().logAnagrafeOperation(null,false,"ANAG-API-SET-PROF",soggettoId,null);
				OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager().setAttributiEsterniValues(soggettoId,
						ClassificazioneHandler.getClassificazioneView(causale, "PROFESSIONE").getId().toString(),
						"professione", opId);
			} else {
				throw new GestoreAnagrafeException(new AnagrafeHelper().getMessage("ANAG-1530"));
			}
		} catch (final AttributiEsterniDiscriminatorException attributiEsterniDiscriminatorException) {
			log4Debug.warnStackTrace(attributiEsterniDiscriminatorException);
			throw new GestoreAnagrafeException(attributiEsterniDiscriminatorException.getMessage());
		} catch (final LoggerException loggerException) {
			log4Debug.warnStackTrace(loggerException);
			throw new GestoreAnagrafeException(loggerException.getMessage());
		}

	}

	public IDocumentiView getLastValidDocument( final Long soggettoId,final String date )throws GestoreAnagrafeException, RemoteException {
		   return new DocumentiDBAccessHelper().getLastValidDocument(soggettoId,date);
	}

	/**
	 * Method to check isRegimeMinimi
	 * @param soggettoId
	 * @param date
	 * @return
	 * @throws GestoreAnagrafeException
	 * @throws RemoteException
	 */
	public boolean isRegimeMinimi(final java.lang.Long soggettoId, final String date) throws GestoreAnagrafeException, RemoteException {
		return new DatiFiscaliDBAccessHelper().isRegimeMinimi(soggettoId,date);
	}

	/**
	 * This method is used the nazione details based on the input nazione name
	 * @param nome
	 * @return Collection<INazioneView>
	 * @throws RemoteException
	 * @throws GestoreNazioneException
	 */
	public Collection<INazioneView> getAllNazione(final String nome) throws GestoreNazioneException,RemoteException {
		final Hashtable<String ,String> searchCriteria = new Hashtable<String, String>();
		searchCriteria.put("NA_NOME", nome);
		return new NazioneDBAccessHelper().getNazione(searchCriteria);
	}


	/**
	 * This method to get List of Soggetto from Recapiti based on that value and type
	 * @param value
	 * @param type
	 * @return
	 * @throws GestoreRecapitoException
	 * @throws RemoteException
	 */
	public Collection<Long> getRecapitoSoggettoList(final String recapitiValue, final String recapitiType) throws GestoreRecapitoException, RemoteException{
		return new RecapitiDBAccessHelper().getRecapitoSoggettoList(recapitiValue, recapitiType);
	}

	public List<String> getAllNazioneWithCNCF() throws GestoreNazioneException,RemoteException {
		return new NazioneDBAccessHelper().getAllNazioneWithCNCF();
	}

	public Collection<ITAEView> getProfessioneTaeCompatability(final String professioneCausale) throws RemoteException, GestoreAnagrafeException {
		return new TAEHandler().getProfessioneTaeCompatability(professioneCausale);
	}

	public Collection<ITAEView> getAllTAE() throws GestoreAnagrafeException, RemoteException {
		return new TAEHandler().getAllTAE();
	}

	public Collection<IAPView> getAllAlbo(final String tipoSoggetto) throws GestoreAnagrafeException, RemoteException {
		return new AlboProfessioneHandler().getAllAlbo(tipoSoggetto);
	}

	public ITAEView getTAE(final Long taeId) throws GestoreAnagrafeException, RemoteException {
		return new TAEHandler().getTAE(taeId);
	}

	public IAPView getAlbo(final Long alboId) throws GestoreAnagrafeException, RemoteException {
		return new AlboProfessioneHandler().getAlbo(alboId);
	}

	public String setAttribute(final Long soggettoId, final String causale, final String value) throws GestoreAnagrafeException, RemoteException {
    	return new AttributiEsterniDBAccessHelper().setAttribute(soggettoId, causale, value);
    }

	public Collection<IRegione> getAllRegione() throws GestoreAnagrafeException, RemoteException {
		return new RegioneHandler().getAllRegione();
	}

	public IRegione getRegioneByRegionCode(final String regioneCode) throws GestoreAnagrafeException, RemoteException {
		return new RegioneHandler().getRegioneByRegionCode(regioneCode);
	}
	
	public List<IDocumentiView> getValidDocument(Long soggettoId,Boolean all) throws RemoteException, GestoreAnagrafeException {
		return new DocumentiDBAccessHelper().getValidDocument(soggettoId, all);
	}

	public ISoggettoBankView getSoggPerDoc(final String idDoc) throws GestoreAnagrafeException, RemoteException {
		return new DocumentiGetterHelper().getSoggPerDoc(idDoc);
	}

	public String setIss(final String idDoc ,final String issId) throws GestoreAnagrafeException, RemoteException {
		return new DocumentiUpdateHelper().setIss(idDoc, issId);
	}
	
	public Long createEventoForSoggetto(final Long soggettoId, final String tipoEventi, final String dataInizio, final String dataFine) throws GestoreAnagrafeException, RemoteException {
		return new EventiDBAccessHelper().createEventoForSoggetto(soggettoId, tipoEventi, dataInizio, dataFine);
	}
	
	public String modifyEventoForSoggetto(final Long soggettoId, final Long eventiId, final String dataInizio, final String dataFine) throws GestoreAnagrafeException, RemoteException {
		return new EventiDBAccessHelper().modifyEventoForSoggetto(soggettoId, eventiId, dataInizio, dataFine);
	}
	
	public String deleteEventoForSoggetto(final Long soggettoId, final Long eventiId) throws GestoreAnagrafeException, RemoteException {
		return new EventiDBAccessHelper().deleteEventoForSoggetto(soggettoId, eventiId);
	}
	
	public String getIdISS(final Long SoggettoId, final DocumentiView documentiView) throws GestoreAnagrafeException, RemoteException {
		return new DocumentiGetterHelper().getIdISS(SoggettoId, documentiView);		
	}
	
	public String getIdScansione(final Long SoggettoId, final DocumentiView documentiView) throws GestoreAnagrafeException, RemoteException {
		return new DocumentiGetterHelper().getIdScansione(SoggettoId, documentiView);
	}
	
	public String getDataFromCodiceFiscale(final String codiceFisicale) throws GestoreDatiFiscaliException, RemoteException {
		return new DatiFiscaliDBAccessHelper().getDataFromCodiceFiscale(codiceFisicale);
	}
	
	public String getSettorebyDate(final Long soggettoId,final String settoreDate ) throws GestoreAnagrafeException, RemoteException {
		String settoreValore = null;
		try {
			if (!new StringHandler().isEmpty(settoreDate)) {	
				new DateHandler().isValidDate(settoreDate, "dd/MM/yyyy");	
			}
			settoreValore = new SettoreHandler().getSettorebyDate(soggettoId, settoreDate);
		} catch (HelperException helperEx) {
        	log4Debug.debugStackTrace(helperEx);
            throw new GestoreAnagrafeException(helperEx.getMessage());
		}
		return settoreValore;
	}
	
	public Collection getAllSettore(final boolean isValid) throws GestoreAnagrafeException, RemoteException {
		return new SettoreHandler().getAllSettore(isValid);
	}
	
	public Collection<IPoteriDiFirmaDocumentView> getValidPoteriFirmaDocumet(final Long soggettoId) throws GestoreAnagrafeException, RemoteException{
		return new DocPoteriFirmaGetterHelper().getValidPoteriFirmaDocument(soggettoId);
	}
	
	/**
	 * Method to get list of all bank address names
	 * @return
	 * @throws GestoreAnagrafeException
	 * @throws RemoteException
	 */
	public Collection<String> getListOfBankAddressNames() throws GestoreAnagrafeException, RemoteException {
		final IBankAddressDAO addressDAO = new BankAddressDAOImpl();
		return addressDAO.getListOfBankAddressNames();
	}
	
	/**
	 * This method returns the collection of AZ SOGGETTO which belongs to given input SOGGETTO, as COLLEGATE. 
	 * @param soggettoId
	 * @return
	 * @throws GestoreCollegamentoException
	 * @throws RemoteException
	 */
	public Collection<ICollegatiAbilAziendaView> getCollegatiAbilAzienda(final Long soggettoId) throws GestoreCollegamentoException,RemoteException {
		return new CollegamentoDBAccessHelper().getCollegatiAbilAzienda(soggettoId);
	}
	
	/**
	 * This method will return the collection of ICapDetailView for the given capCode if the list is null it is invalid cap
	 * @param capCode
	 * @return Collection<ICapDetailView>
	 * @throws GestoreAnagrafeException
	 * @throws RemoteException
	 */
	public Collection<ICapDetailView> getCapDetForCapCode(final String capCode) throws GestoreAnagrafeException, RemoteException {
		return new CapTableHandler().getCapDetForCapCode(capCode);
	}
	
	
	/**
	 * This method returns Collection of Settore Attivita Economica for the Given Professione Causale.
	 * @param professioneCausale
	 * @return
	 * @throws GestoreAnagrafeException
	 * @throws RemoteException
	 */
	public Collection<ISAEView> getSettoreDiAttivitaForProfessione(final String professioneCausale) throws GestoreAnagrafeException, RemoteException {
		return new SettoreDiAttivitaHandler().getSettoreDiAttivitaForProfessione(professioneCausale);
	}
	
	/**
	 * This method returns Collection of compatible TAE of given professione and Settore Attivita Economica.
	 * @param professioneCausale
	 * @param settoreAttivitaDesc
	 * @return
	 * @throws RemoteException
	 * @throws GestoreAnagrafeException
	 */
	public Collection<ITAEView> getTAEForProfessioneAndSAE(final String professioneCausale, final String settoreAttivitaDesc) throws RemoteException, GestoreAnagrafeException {
		return new TAEHandler().getTAEForProfessioneAndSAE(professioneCausale, settoreAttivitaDesc);
	}
	
	/**
	 * Method to return ISogettiResidenteFiscaleView by calling the method getResidenteFiscale which is present in DatiFiscaliDBAccessHelper class.
	 * @param soggettoId
	 * @return
	 * @throws RemoteException
	 * @throws GestoreAnagrafeException
	 */
	public ISoggettiResidenteFiscaleView getResidenteFiscaleDetails(final Long soggettoId) throws RemoteException, GestoreAnagrafeException {
		return new DatiFiscaliDBAccessHelper().getResidenteFiscaleDetails(soggettoId);
	}
	
	/**
	 * This Method Returns the valid CanalePreferitoData View for the given input Subject.
	 * if no data in db NessunaPreferenza is returned or else the data in db is displayed
	 * @param soggettoId
	 * @return
	 * @throws RemoteException
	 * @throws GestoreAnagrafeException
	 */
	public ICanalePreferitoDataView getValidCanalePreferito (final Long soggettoId) throws RemoteException, GestoreAnagrafeException {
		CanalePreferitoDataView canalePreferitoDataView = null;
		try {
			if(soggettoId != null && new TipoSoggettoHandler().getTipoSoggetto(soggettoId) != null ) {
				canalePreferitoDataView = new CanalePreferitoDBAccessHelper().getValidCanalePreferitoForSoggettoId(soggettoId);
				if(canalePreferitoDataView ==null){
					canalePreferitoDataView = new CanalePreferitoDataView();
					canalePreferitoDataView.setCanale(ClassificazioneHandler.getClassificazioneView("NessunaPreferenza","CANALE_PREFERITO"));
					canalePreferitoDataView.setSoggettoId(soggettoId);
				}
			}
		} catch (final CanalePreferitoException e) {
			log4Debug.warnStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		}
		return canalePreferitoDataView;
	}
	
	/**
	 * This Method Returns the valid CanaleUtilizzato Data View for the given input Subject.
	 * @param soggettoId
	 * @return
	 * @throws RemoteException
	 * @throws GestoreAnagrafeException
	 */
	public ICanaleUtilizzatoView getValidCanaleUtilizzato (final Long soggettoId) throws RemoteException, GestoreAnagrafeException {
		try {
			return new CanalePreferitoDBAccessHelper().getCanaleUtilizzatoForSoggettoId(soggettoId);
		} catch (final CanalePreferitoException e) {
			log4Debug.warnStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		}
	}
	
	/**
	 * To get last inserted operation for document
	 * @param soggettoId
	 * @return
	 * @throws GestoreAnagrafeException
	 * @throws RemoteException
	 */
	public IUltimoAggiornamentoView getDataUltimoAggiornamentoQA(final Long soggettoId) throws GestoreAnagrafeException,RemoteException{
		try {
			return new LogDBAccessHelper().getDataUltimoAggiornamentoQA(soggettoId);
		} catch (final HostLoggerException e) {
			log4Debug.severeStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		}
	}
	/**
	 * To return last inserted document based on doc type,insertion date for a soggetto
	 * @param soggettoId
	 * @param date
	 * @return
	 * @throws GestoreAnagrafeException
	 * @throws RemoteException
	 */
	public IDocumentiView getLastInsertedDocument( final Long soggettoId,final String docType,final String date )throws GestoreAnagrafeException, RemoteException {
		   return new DocumentiDBAccessHelper().getLastInsertedDocument(soggettoId,docType,date);
	}
	
	/**
	 * @param soggettoId
	 * @throws GestoreAnagrafeException
	 * @throws RemoteException
	 */
	public Boolean calculateAndSetDAIForSoggetto (final Long soggettoId) throws GestoreAnagrafeException, RemoteException {
		return new GestoreAPIDAICalculatorHelper().calculateAndSetDAIForSoggetto(soggettoId);
	}
	
	/**
	 * This Method Returns Collection DAIRegole Data for the input Soggetto
	 * @param soggettoId
	 * @return
	 * @throws GestoreAnagrafeException 
	 */
	public Collection<IDAIRegoleDetail> getAnagrafeDAIDetails(final Long soggettoId) throws GestoreAnagrafeException, RemoteException {
		return new DAIDBAccessHelper().getDAIRegoleDetails(soggettoId);
	}
	
	/**
	 * This Method Returns Anagrafe DAI Soggetto Data for the input Soggetto
	 * @param soggettoId
	 * @return
	 * @throws GestoreAnagrafeException
	 * @throws RemoteException
	 */
	public IDAISoggettoData getAnagrafeDAISoggetto (final Long soggettoId) throws GestoreAnagrafeException, RemoteException {
		return new DAIDBAccessHelper().getAnagrafeDAISoggetto(soggettoId);
	}
	
	/**
	 * This Method Return Final DAI Storic Data.
	 * @param soggettoId
	 * @return
	 * @throws GestoreAnagrafeException
	 * @throws RemoteException
	 */
	public Collection<IDAIStoricDataView> getStoricoDAIComplete(final Long soggettoId, final String... daiCausale) throws GestoreAnagrafeException, RemoteException {
		return new DAIDBAccessHelper().getStoricoDAI(soggettoId, daiCausale);
	}
	
	/**
     * This method returns the socio operation details done for the soggetto for the causale socioBSE and socioSHB.
     * @param soggettoId
     * @return Collection<ISocioOperationView>
     * @throws GestoreAnagrafeException
     */
    public Collection<ISocioDetailsView> getSocioOperationDetails(final Long soggettoId) throws GestoreAnagrafeException, RemoteException {
    	return new AEValoreGetter().getSocioOperationDetails(soggettoId);
    }
    
    /**
     * This Method Calculates DAI Anagrafe and Returns DAI status for the soggetto (DAIOK, DAIKO, DAIALERT)
     * @param soggettoId
     * @return
     * @throws GestoreAnagrafeException
     * @throws RemoteException
     */
    public String calculateDAIAnagrafe (final Long soggettoId) throws GestoreAnagrafeException, RemoteException {
    	return new DAIDBAccessHelper().calculateDAIAnagrafe(soggettoId);
    }
    
    /**
     * This Method Calculates DAI Anagrafe Completo and Returns final DAI for the soggetto (true, false)
     * @param soggettoId
     * @return
     * @throws GestoreAnagrafeException
     * @throws RemoteException
     */
    public Boolean calculateDAICompleto (final Long soggettoId) throws GestoreAnagrafeException, RemoteException {
    	return new DAIDBAccessHelper().calculateDAICompleto(soggettoId);
    }
}

