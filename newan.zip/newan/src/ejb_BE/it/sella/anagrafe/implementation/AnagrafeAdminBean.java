package it.sella.anagrafe.implementation;


import it.sella.anagrafe.DocumentiPoteriFirmaException;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreClasseATECOException;
import it.sella.anagrafe.GestoreCollegamentoException;
import it.sella.anagrafe.GestoreDatiFiscaliException;
import it.sella.anagrafe.GestoreProvinciaException;
import it.sella.anagrafe.IDocPoteriFirmaView;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.az.DatiAnagraficiAZView;
import it.sella.anagrafe.common.Citta;
import it.sella.anagrafe.common.Nazione;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.datianagrafeazienda.DatiAnagrafeAzienda;
import it.sella.anagrafe.datianagrafeazienda.IDatiAnagrafeAziendaBeanManager;
import it.sella.anagrafe.datiprivacy.DatiPrivacy;
import it.sella.anagrafe.datiprivacy.IDatiPrivacyBeanManager;
import it.sella.anagrafe.datiprivacyfivelevel.DatiPrivacyFiveLevel;
import it.sella.anagrafe.datiprivacyfivelevel.IDatiPrivacyFiveLevelBeanManager;
import it.sella.anagrafe.dbaccess.ClasseATECOUpdateHelper;
import it.sella.anagrafe.dbaccess.CollegamentoDBAccessHelper;
import it.sella.anagrafe.dbaccess.CompSettoreClasseUpdateHelper;
import it.sella.anagrafe.dbaccess.DatiFiscaliDBAccessHelper;
import it.sella.anagrafe.dbaccess.DocEventiDBAccessHelper;
import it.sella.anagrafe.dbaccess.DocPoteriFirmaDBHelper;
import it.sella.anagrafe.dbaccess.ProvinciaUpdateHelper;
import it.sella.anagrafe.dbaccess.StoricDataUpdateHelper;
import it.sella.anagrafe.discriminator.EventoDiscriminatorException;
import it.sella.anagrafe.docpoterifirma.DocumentiPoteriFirma;
import it.sella.anagrafe.docpoterifirma.IDocumentiPoteriFirmaBeanManager;
import it.sella.anagrafe.docstatusaccess.DocumentStatusAccessHelper;
import it.sella.anagrafe.documento.Documento;
import it.sella.anagrafe.documento.IDocumentoBeanManager;
import it.sella.anagrafe.evento.Evento;
import it.sella.anagrafe.evento.EventoView;
import it.sella.anagrafe.evento.IEventoBeanManager;
import it.sella.anagrafe.factory.DocumentiPoteriFirmaFactory;
import it.sella.anagrafe.pf.SoggettoEventoView;
import it.sella.anagrafe.recapiti.IRecapitiBeanManager;
import it.sella.anagrafe.recapiti.Recapiti;
import it.sella.anagrafe.soggetto.ISoggettoBeanManager;
import it.sella.anagrafe.soggetto.Soggetto;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.ReflectionUtil;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.anagrafe.util.StringHandler;
import it.sella.anagrafe.util.xmlgen.BustaHelper;
import it.sella.anagrafe.view.ClasseATECOView;
import it.sella.anagrafe.view.CompSettoreClasseView;
import it.sella.anagrafe.view.IW8W8iView;
import it.sella.anagrafe.view.ProvinciaAdminView;
import it.sella.anagrafe.view.W8BenView;
import it.sella.anagrafe.view.W8iView;
import it.sella.ejb.SessionBeanAdapter;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;

import javax.ejb.FinderException;

public class AnagrafeAdminBean extends SessionBeanAdapter {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AnagrafeAdminBean.class);

    public void updateDatiAnagraficAZ(final Long soggettoId,final DatiAnagraficiAZView datiAnagraficiAZView) throws RemoteException,GestoreAnagrafeException {
        try {
        	final IDatiAnagrafeAziendaBeanManager manager = (IDatiAnagrafeAziendaBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.DatiAnagrafeAzienda");
        	final DatiAnagrafeAzienda datiAnagrafeAzienda = manager.findBySoggettoId(soggettoId);
		    final StringHandler stringHandler = new StringHandler();
		    final String nazioneId = datiAnagraficiAZView.getNazioneCostituzione() != null ? datiAnagraficiAZView.getNazioneCostituzione().getNazioneId().toString() : null;
	        String cittaId = null;
			if(datiAnagraficiAZView.getCittaCostituzione() != null){
				cittaId = datiAnagraficiAZView.getCittaCostituzione().getCittaId() != null ? datiAnagraficiAZView.getCittaCostituzione().getCittaId().toString() : datiAnagraficiAZView.getCittaCostituzione().getCommune();
			}
		    if (!stringHandler.checkForEquality(datiAnagrafeAzienda.getDenominazione(),datiAnagraficiAZView.getDenominazione()) ||
		    		!stringHandler.checkForEquality(datiAnagrafeAzienda.getDataDiCostituzione(),datiAnagraficiAZView.getDataDiCostituzione()) ||
		    		!(nazioneId != null ? nazioneId : "").equals(datiAnagrafeAzienda.getNazioneCostituzione() != null ? datiAnagrafeAzienda.getNazioneCostituzione() : "") || 
		    		!(cittaId != null ? cittaId : "").equals(datiAnagrafeAzienda.getCittaCostituzione() != null ? datiAnagrafeAzienda.getCittaCostituzione() : "")) {
		        datiAnagrafeAzienda.setDenominazione(datiAnagraficiAZView.getDenominazione());
		        datiAnagrafeAzienda.setNormalisedName(datiAnagraficiAZView.getNormalizedName());
		        datiAnagrafeAzienda.setDataDiCostituzione(datiAnagraficiAZView.getDataDiCostituzione());
		        final Nazione nazione = datiAnagraficiAZView.getNazioneCostituzione();
				datiAnagrafeAzienda.setNazioneCostituzione(nazione != null ? nazione.getNazioneId().toString() : null);
				final Citta citta = datiAnagraficiAZView.getCittaCostituzione();
				datiAnagrafeAzienda.setCittaCostituzione(citta != null ? (citta.getCittaId() != null ? citta.getCittaId().toString() : citta.getCommune()) : null);
		        datiAnagrafeAzienda.setOpId(datiAnagraficiAZView.getOpId());
		        manager.update(datiAnagrafeAzienda);
		    }
		} catch (final GestoreAnagrafeException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		} catch (final FinderException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		}
    }

    public void updateEventi(final Long eventId,final SoggettoEventoView soggettoEventoView) throws RemoteException, GestoreAnagrafeException {
    	Evento evento;
		try {
			final IEventoBeanManager eventoBeanManager = ((IEventoBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.Evento"));
			evento = eventoBeanManager.findByPrimaryKey(eventId);
			final StringHandler stringHandler = new StringHandler();
			if(!stringHandler.checkForEquality(evento.getDataFine(),soggettoEventoView.getDataFine()) ||
					!stringHandler.checkForEquality(evento.getDataInizio(),soggettoEventoView.getDataInizio()) ||
					!stringHandler.checkForEquality(evento.getNote(),soggettoEventoView.getNote()) ||
					!stringHandler.checkForEquality(evento.getTipoEvento(),soggettoEventoView.getTipoEvento() != null ? soggettoEventoView.getTipoEvento().getId() : null)) {
				evento.setNote(soggettoEventoView.getNote());
			    if(soggettoEventoView.getTipoEvento() != null) {
					evento.setTipoEvento(soggettoEventoView.getTipoEvento().getId());
				}
			    evento.setDataFine(soggettoEventoView.getDataFine());
			    evento.setDataInizio(soggettoEventoView.getDataInizio());
			    evento.setOpId(soggettoEventoView.getOpId());
			    eventoBeanManager.update(evento);
			}
		} catch (final FinderException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		}

    }

    public void updateSoggetto(final Long soggettoId, final Long tipoSoggettoId, final Long opId) throws RemoteException, GestoreAnagrafeException {
    	try {
    		final ISoggettoBeanManager iSoggettoBeanManager = (ISoggettoBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.Soggetto");
			final Soggetto soggetto = iSoggettoBeanManager.findByPrimaryKey(soggettoId);
			if(!new StringHandler().checkForEquality(soggetto.getTipoSoggettoId(), tipoSoggettoId)) {
				soggetto.setTipoSoggettoId(tipoSoggettoId);
        		soggetto.setOpId(opId);
        		iSoggettoBeanManager.update(soggetto);
			}
		} catch (final FinderException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		}
    }

    public void deleteEvento(final Long eventoId, final Long opId) throws RemoteException, EventoDiscriminatorException {
    	try {
    		final IEventoBeanManager eventoBeanManager = ((IEventoBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.Evento"));
			final Evento evento = eventoBeanManager.findByPrimaryKey(eventoId);
			new StoricDataUpdateHelper().updateEventi(evento.getEventoId(), evento.getSoggettoId(), evento.getTipoEvento(), evento.getDataInizio(), evento.getDataFine(), evento.getNote(), opId,evento.getOpId());
			eventoBeanManager.remove(evento);
		}catch (final FinderException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
            throw new EventoDiscriminatorException(e.getMessage());
		} catch (final GestoreAnagrafeException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
            throw new EventoDiscriminatorException(e.getMessage());
		} catch (final ControlloDatiException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
            throw new EventoDiscriminatorException(e.getMessage());
		}
    }

    public void deleteDocumento( final Long pkId, final Long opId ) throws RemoteException, GestoreAnagrafeException {
    	try {
    		final IDocumentoBeanManager iDocumentoBeanManager = ((IDocumentoBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.Documento"));
    		final Documento documento = iDocumentoBeanManager.findByPrimaryKey(pkId);
			if (documento != null) {
			    final String documentoCausale = ClassificazioneHandler.getClassificazioneView(documento.getTypeOfDocument()).getCausale();
				if("PS".equals(documentoCausale) || "RPS".equals(documentoCausale) ||
				   "CS".equals(documentoCausale) || "RRPS".equals(documentoCausale)
				   || "CRPS".equals(documentoCausale) ) {
					new DocEventiDBAccessHelper().terminateDocEventi(documento.getSoggettoId(), ClassificazioneHandler.getClassificazioneView(documento.getTypeOfDocument()).getDescrizione(), documento.getDocumentNumber(), documento.getDataEmissione(), opId);
				}
				new StoricDataUpdateHelper().updateDocumento(documento,opId);
				new DocumentStatusAccessHelper().removeDocumentStatus(documento.getDocumentoId()); // This code has been added to remove data from AN_TR_DOC_STATUS, when removing data from AN_TR_DOCUMENTI.
				iDocumentoBeanManager.remove(documento);
			}
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		} catch (final FinderException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		} catch (final ControlloDatiException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		}
    }

    public void removePrivacy(final Collection pkIds, final Long opId) throws RemoteException, GestoreAnagrafeException {
    	final int size = pkIds.size();
    	final Iterator iterator = pkIds.iterator();
        DatiPrivacy datiPrivacy = null;
        final StoricDataUpdateHelper storicDataUpdateHelper = new StoricDataUpdateHelper();
        try {
        	final IDatiPrivacyBeanManager manager = ((IDatiPrivacyBeanManager)ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.DatiPrivacy"));
			for (int i = 0; i < size; i++) {
				final Long pkId = Long.valueOf((String)iterator.next());
			    datiPrivacy = manager.findByPrimaryKey(pkId);
			    storicDataUpdateHelper.updatePrivacy(pkId, datiPrivacy.getSoggettoId(), datiPrivacy.getValue(), datiPrivacy.getRightPk(), opId,datiPrivacy.getOpId());
			    manager.remove(datiPrivacy);
			}
		} catch (final FinderException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		} catch (final ControlloDatiException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		}
    }

    public void removeRecapiti(final Long pkId, final Long opId) throws RemoteException, GestoreAnagrafeException {
    	try {
    		final IRecapitiBeanManager recapitiBeanManager = ((IRecapitiBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.Recapiti"));
        	final Recapiti recapiti = recapitiBeanManager.findByPrimaryKey(pkId);
			new StoricDataUpdateHelper().updateRecapiti(pkId, recapiti.getSoggettoId(),recapiti.getPrefissoCode(), recapiti.getValue(), recapiti.getRightPk(), recapiti.getRiferimento(), opId,recapiti.getOpId());
			recapitiBeanManager.remove(recapiti);
		}catch (final FinderException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		} catch (final ControlloDatiException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		} catch (final GestoreAnagrafeException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		}
    }

    public void replaceCollegamento(final Long oldSoggettoId, final Long newSoggettoId, final String motivCausale, final Long opId) throws GestoreAnagrafeException, RemoteException {
    	try {
			new CollegamentoDBAccessHelper().replaceCollegamento(oldSoggettoId, newSoggettoId, motivCausale, opId);
		} catch (final GestoreCollegamentoException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		}
    }

    public void terminateLink(final Long linkedSoggettoId, final Hashtable attributes, final Long opId) throws GestoreAnagrafeException, RemoteException {
    	try {
			new CollegamentoDBAccessHelper().terminateLink(linkedSoggettoId, attributes, opId);
		} catch (final GestoreCollegamentoException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		}
    }

    public void removePrivacyFiveLevel(final Long soggettoId, final Long opId) throws RemoteException, GestoreAnagrafeException {
    	 try {

    		final IDatiPrivacyFiveLevelBeanManager manager = ((IDatiPrivacyFiveLevelBeanManager)ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.DatiPrivacyFiveLevel"));
    		final Collection datiPrivacyFiveLevelColn = manager.findBySoggettoId(soggettoId);
             if( datiPrivacyFiveLevelColn != null && !datiPrivacyFiveLevelColn.isEmpty() ) {
            	 final Iterator iterator = datiPrivacyFiveLevelColn.iterator();
                DatiPrivacyFiveLevel datiPrivacyFiveLevelRemote = null ;
             	DatiPrivacyFiveLevel datiPrivacyFiveLevel = null ;
             	final int size = datiPrivacyFiveLevelColn.size();
             	String id = null;
             	final StoricDataUpdateHelper storicDataUpdateHelper = new StoricDataUpdateHelper();
            	for (int i = 0; i < size; i++) {
            		datiPrivacyFiveLevel = (DatiPrivacyFiveLevel) iterator.next();
            		datiPrivacyFiveLevelRemote = manager.findByPrimaryKey(datiPrivacyFiveLevel.getId());
            		id = datiPrivacyFiveLevelRemote.getId().toString().substring(3);
            		storicDataUpdateHelper.updatePrivacyFiveLevel(Long.valueOf(id), datiPrivacyFiveLevelRemote.getSoggettoId(), datiPrivacyFiveLevelRemote.getValue1(),datiPrivacyFiveLevelRemote.getValue2(),datiPrivacyFiveLevelRemote.getValue3(),datiPrivacyFiveLevelRemote.getValue4(),datiPrivacyFiveLevelRemote.getValue5(),datiPrivacyFiveLevelRemote.getProfil(),datiPrivacyFiveLevelRemote.getOpId(),opId);
            		manager.remove(datiPrivacyFiveLevelRemote);
            	}
            }
		} catch (final FinderException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		} catch (final ControlloDatiException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		}
    }

    public void setDatiFiscaliW8W8I(final Long soggettoId,
    		final IW8W8iView iView)  throws GestoreAnagrafeException, RemoteException {
    	try {
    		log4Debug.debug(" AnagrafeAdminBean: setDatiFiscaliW8W8I: soggettoId:===>>",soggettoId);
    		log4Debug.debug(" AnagrafeAdminBean: setDatiFiscaliW8W8I: iView:===>>",iView);
        	if ( iView != null ) {
        		W8BenView w8BenView = null;
        		final DatiFiscaliDBAccessHelper datiFiscaliDBAccessHelper = new DatiFiscaliDBAccessHelper();
        		final String clsAbiBanca = CommonPropertiesHandler.getValueFromProperty("CARTA_LISTA_BANK_ABI");
        		if (iView instanceof W8BenView) {
        			w8BenView = (W8BenView) iView;
        			log4Debug.debug(" AnagrafeAdminBean: setDatiFiscaliW8W8I: w8BenView:===>>",w8BenView);
        			log4Debug.debug(" AnagrafeAdminBean: setDatiFiscaliW8W8I: w8BenView.getCausale():===>>",w8BenView.getCausale());
        			log4Debug.debug(" AnagrafeAdminBean: setDatiFiscaliW8W8I: w8BenView.getW8():===>>",w8BenView.getW8());
        			log4Debug.debug(" AnagrafeAdminBean: setDatiFiscaliW8W8I: w8BenView.getDataScadenza():===>>",w8BenView.getDataScadenza());
        			log4Debug.debug(" AnagrafeAdminBean: setDatiFiscaliW8W8I: w8BenView.getOpId():===>>",w8BenView.getOpId());
        			log4Debug.debug(" AnagrafeAdminBean: setDatiFiscaliW8W8I: w8BenView.getCodiceHost():===>>",w8BenView.getCodiceHost());
        			log4Debug.debug(" AnagrafeAdminBean: setDatiFiscaliW8W8I: w8BenView.getBarCode():===>>",w8BenView.getBarCode());
        			log4Debug.debug(" AnagrafeAdminBean: setDatiFiscaliW8W8I: w8BenView.getIntestazione():===>>",w8BenView.getIntestazione());
        			log4Debug.debug(" AnagrafeAdminBean: setDatiFiscaliW8W8I: w8BenView.getBustaCode():===>>",w8BenView.getBustaCode());
        			datiFiscaliDBAccessHelper.setAltriDatiFiscali(soggettoId, w8BenView.getCausale(), w8BenView.getW8(),
        					w8BenView.getOpId());
        			datiFiscaliDBAccessHelper.setW8DataSadenza(soggettoId, w8BenView);
        			if ("true".equals(w8BenView.getW8()) && !clsAbiBanca.equals(SecurityHandler.getCodiceAbiBanca())) { // To Avoid Stampe, Busta and PDF For CLS Bank.. (This is W8 - Varia Case) 
        				BustaHelper.setBustaDeiciContratti(w8BenView.getCodiceHost(), w8BenView.getBarCode(),
        						w8BenView.getIntestazione(), w8BenView.getBustaCode());
        			}
    			} else {
	    			final W8iView view = (W8iView) iView;
    				new DatiFiscaliDBAccessHelper().setAltriDatiFiscali(soggettoId, view.getCausale(),
    						view.getW8i(), view.getOpId());
    				if ("true".equals(view.getW8i()) && !clsAbiBanca.equals(SecurityHandler.getCodiceAbiBanca())){	// To Avoid Stampe, Busta and PDF For CLS Bank.. (This is W8i - Varia Case) 
    					BustaHelper.setBustaDeiciContratti(iView.getCodiceHost(), view.getBarCode(),
    							view.getIntestazione(), view.getBustaCode());
    				}
    			}
        	}
    	} catch(final GestoreDatiFiscaliException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
    	}
    }

    public void createProvincia(final ProvinciaAdminView provincia ) throws GestoreAnagrafeException,  RemoteException {

    	try {
			new ProvinciaUpdateHelper().createProvincia(provincia);
		} catch (final GestoreProvinciaException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		}
    }

    public void updateProvincia(final ProvinciaAdminView provincia ) throws GestoreAnagrafeException, RemoteException {
    	try {
			new ProvinciaUpdateHelper().updateProvincia(provincia);
		} catch (final GestoreProvinciaException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		}
    }

    public Long createClasseATECO(final ClasseATECOView classeATECOView)
			throws GestoreAnagrafeException, RemoteException {
		try {
			return new ClasseATECOUpdateHelper().createClasseATECO(classeATECOView);
		} catch (final GestoreClasseATECOException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		}
	}

    public void updateClasseATECO(final ClasseATECOView classeATECOView)
			throws GestoreAnagrafeException, RemoteException {
		try {
			new ClasseATECOUpdateHelper().updateClasseATECO(classeATECOView);
		} catch (final GestoreClasseATECOException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		}
	}

    public void deleteClasseATECO(final Long classeATECOId)
			throws GestoreAnagrafeException, RemoteException {
		try {
			new ClasseATECOUpdateHelper().deleteClasseATECO(classeATECOId);
		} catch (final GestoreClasseATECOException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		}
	}

    public Long createCompSettoreClasse(
			final CompSettoreClasseView compSettoreClasseView)
			throws GestoreAnagrafeException, RemoteException {
		try {
			return new CompSettoreClasseUpdateHelper()
					.createCompSettoreClasse(compSettoreClasseView);
		} catch (final GestoreClasseATECOException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		}
	}

    public void deleteCompSettoreClasse(final Long compSettoreClasseId)
			throws GestoreAnagrafeException, RemoteException {
		try {
			new CompSettoreClasseUpdateHelper()
					.deleteCompSettoreClasse(compSettoreClasseId);
		} catch (final GestoreClasseATECOException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		}
	}

    public void createEvento(final EventoView eventoView) throws RemoteException, GestoreAnagrafeException {
		try {
			((IEventoBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.Evento")).create(eventoView);
		} catch (final GestoreAnagrafeException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		}
    }
    
   
	/**
	 * This Method is For Deleting of poteriFirma Data. (Used in Admin)
	 * @param pkId
	 * @param opID
	 * @throws RemoteException
	 * @throws GestoreAnagrafeException
	 */
	public void deleteDocumentPoteriFirma(final Long pkId, final Long opID) throws RemoteException, GestoreAnagrafeException{
		try {
			final IDocumentiPoteriFirmaBeanManager poteriFirmaBeanManager = DocumentiPoteriFirmaFactory.getInstance().getDocumentiPoteriFirmaBeanManager();
			final DocumentiPoteriFirma docPoteriFirmaView = poteriFirmaBeanManager.findByPrimaryKey(pkId);
			
			new StoricDataUpdateHelper().updateStoricDocumentiPoteriFirma(docPoteriFirmaView, opID);
			poteriFirmaBeanManager.remove(docPoteriFirmaView);
		} catch (final ControlloDatiException e) {
			this.getSessionContext().setRollbackOnly();
			log4Debug.warnStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} catch (final FinderException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		}
	}
	
	/**
     * This Method To create / link the PoteriFirmaDocument details With Collegate Subject 
     * @param soggettoId
     * @param docPoteriFirma
     * @throws DocumentiPoteriFirmaException
     * @throws RemoteException
     */
	public void createPoteriFirmaDocument(final Long soggettoId, final IDocPoteriFirmaView docPoteriFirma ) throws GestoreAnagrafeException, RemoteException {
        try {
			new DocPoteriFirmaDBHelper().createDocumentPoteriFirma(soggettoId, docPoteriFirma);
		} catch (final DocumentiPoteriFirmaException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		}
    }
	
	/**
     * This Method is To Update the PoteriFirma Document Details.
     * @param opId
     * @param docPoteriFirma
     * @param collegamentoId
     * @param soggettoId
	 * @throws GestoreAnagrafeException, RemoteException 
     * @throws DocumentiPoteriFirmaException
     * @throws RemoteException
     */
    public void setDocumentPoteriFirma(final Long opId, IDocPoteriFirmaView docPoteriFirma, final Long collegamentoId, final Long soggettoId) throws GestoreAnagrafeException, RemoteException {
    	try {
			new DocPoteriFirmaDBHelper().setDocumentPoteriFirma(opId, docPoteriFirma, collegamentoId, soggettoId);
		} catch (final DocumentiPoteriFirmaException e) {
			log4Debug.warnStackTrace(e);
			this.getSessionContext().setRollbackOnly();
			throw new GestoreAnagrafeException(e.getMessage());
		}
    }
}