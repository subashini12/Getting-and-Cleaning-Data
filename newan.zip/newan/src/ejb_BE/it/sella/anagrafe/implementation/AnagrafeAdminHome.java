package it.sella.anagrafe.implementation;

import it.sella.ejb.IEJBHome;

import java.rmi.RemoteException;

import javax.ejb.CreateException;

public interface AnagrafeAdminHome extends IEJBHome {
	
    AnagrafeAdmin create() throws CreateException, RemoteException;
}
