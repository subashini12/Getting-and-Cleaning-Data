package it.sella.anagrafe.implementation;

import it.sella.ejb.IEJBSessionHome;

import java.rmi.RemoteException;

import javax.ejb.CreateException;

public interface AnagrafeManagerHome extends IEJBSessionHome {

    AnagrafeManager create() throws CreateException, RemoteException;
}