package it.sella.anagrafe.datianagrafeazienda;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Date;
import java.util.Collection;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

/**
 * Manager Class to handle DatiAnagrafeAzienda
 *
 */
public class DatiAnagrafeAziendaBeanManager implements IDatiAnagrafeAziendaBeanManager {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DatiAnagrafeAziendaBeanManager.class);

	private static EntityManager entityManager;

	public DatiAnagrafeAziendaBeanManager(){
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datianagrafeazienda.IDatiAnagrafeAziendaBeanManager#create(it.sella.anagrafe.datianagrafeazienda.DatiAnagrafeAzienda)
	 */
	public DatiAnagrafeAzienda create(final DatiAnagrafeAzienda datiAnagrafeAzienda) throws GestoreAnagrafeException{
		final DatiAnagrafeAziendaBean anagrafeAziendaBean = new DatiAnagrafeAziendaBean();
		BeanUtil.copyProperties(anagrafeAziendaBean, datiAnagrafeAzienda);
		entityManager.persist(anagrafeAziendaBean);
		entityManager.flush();
		BeanUtil.copyProperties(datiAnagrafeAzienda,anagrafeAziendaBean);
		return datiAnagrafeAzienda;

	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datianagrafeazienda.IDatiAnagrafeAziendaBeanManager#update(it.sella.anagrafe.datianagrafeazienda.DatiAnagrafeAzienda)
	 */
	public DatiAnagrafeAzienda update(final DatiAnagrafeAzienda datiAnagrafeAzienda){
		entityManager.persist(datiAnagrafeAzienda);
		return datiAnagrafeAzienda;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datianagrafeazienda.IDatiAnagrafeAziendaBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public DatiAnagrafeAzienda findByPrimaryKey(final Long primaryKey) throws FinderException {
		if(primaryKey == null){
			throw new FinderException("PrimaryKey is null");
		}
		final DatiAnagrafeAzienda anagrafeAzienda = entityManager.find(DatiAnagrafeAziendaBean.class, primaryKey);
		if(anagrafeAzienda == null){
			throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return anagrafeAzienda;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datianagrafeazienda.IDatiAnagrafeAziendaBeanManager#findBySoggettoId(java.lang.Long)
	 */
	public DatiAnagrafeAzienda findBySoggettoId(final Long soggettoId) throws FinderException{
		try {
			final Query findBySoggettoId = entityManager.createNamedQuery("DatiAnagrafeAziendaBean.findBySoggettoId");
			findBySoggettoId.setParameter("soggettoId", soggettoId);
			return (DatiAnagrafeAziendaBean) findBySoggettoId.getSingleResult();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		} catch (final NonUniqueResultException e) {
			log4Debug.warnStackTrace(e);
				throw new FinderException("too_many_results_for_get_single_result");
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datianagrafeazienda.IDatiAnagrafeAziendaBeanManager#findByDatiAnagrafeAzienda(java.lang.String, java.sql.Date)
	 */
	@SuppressWarnings("unchecked")
	public Collection<DatiAnagrafeAzienda> findByDatiAnagrafeAzienda(final String normalisedName,final Date dataDiCostituzione) throws FinderException{
		try {
			final String query = "DatiAnagrafeAziendaBean.findByDatiAnagrafeAzienda";
			final Query findByDatiAnagrafeAzienda = entityManager.createNamedQuery(query);
			findByDatiAnagrafeAzienda.setParameter("normalisedName",normalisedName);
			findByDatiAnagrafeAzienda.setParameter("dataDiCostituzione", dataDiCostituzione);
			return findByDatiAnagrafeAzienda.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datianagrafeazienda.IDatiAnagrafeAziendaBeanManager#findByNormalisedName(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public Collection<DatiAnagrafeAzienda> findByNormalisedName(final String denominazione) throws FinderException{
		try {
			final String query = "DatiAnagrafeAziendaBean.findByNormalisedName";
			final Query findByNormalisedName = entityManager.createNamedQuery(query);
			findByNormalisedName.setParameter("normalisedName", denominazione);
			return findByNormalisedName.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datianagrafeazienda.IDatiAnagrafeAziendaBeanManager#findByDataDiCostituzione(java.sql.Date)
	 */
	@SuppressWarnings("unchecked")
	public Collection<DatiAnagrafeAzienda> findByDataDiCostituzione(final Date dataDiCostituzione) throws FinderException{
		try {
			final String query = "DatiAnagrafeAziendaBean.findByDataDiCostituzione";
			final Query findByDataDiCostituzione = entityManager.createNamedQuery(query);
			findByDataDiCostituzione.setParameter("dataDiCostituzione",dataDiCostituzione);
			return findByDataDiCostituzione.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}
}
