package it.sella.anagrafe.datianagrafeazienda;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="AN_TR_DATIANAGRAFE_AZIENDA")
@SequenceGenerator(name="AziendaSequenceGenerator" , sequenceName="SEQ_DATIANAGRAFEAZIENDAHOME" , allocationSize = 1 )
@NamedQueries({
	@NamedQuery(name="DatiAnagrafeAziendaBean.findBySoggettoId",query="select o from DatiAnagrafeAziendaBean o where o.soggettoId= :soggettoId"),
	@NamedQuery(name="DatiAnagrafeAziendaBean.findByDatiAnagrafeAzienda",query="select o from DatiAnagrafeAziendaBean o where o.normalisedName like :normalisedName and o.dataDiCostituzione =:dataDiCostituzione"),
	@NamedQuery(name="DatiAnagrafeAziendaBean.findByNormalisedName",query="select o from DatiAnagrafeAziendaBean o where o.normalisedName like :normalisedName"),
	@NamedQuery(name="DatiAnagrafeAziendaBean.findByDataDiCostituzione",query="select o from DatiAnagrafeAziendaBean o where o.dataDiCostituzione= :dataDiCostituzione")
})
public class DatiAnagrafeAziendaBean implements DatiAnagrafeAzienda{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="AziendaSequenceGenerator")
	@Column(name="AZ_AZIENDA_ID")
	private Long aziendaId;

	@Column(name="AZ_SOGGETTO_ID")
	private Long soggettoId;

	@Column(name="AZ_DENOMINAZIONE")
	private String denominazione;

	@Column(name="AZ_DATADICOSTITUZIONE")
	private Date dataDiCostituzione;

	@Column(name="AZ_NORMALISED_NAME")
	private String normalisedName;

	@Column(name="AZ_OP_ID")
	private Long opId;
	
	@Column(name="AZ_NAZIONE_COSTITUZIONE")
	private String nazioneCostituzione;
	
	@Column(name="AZ_CITTA_COSTITUZIONE")
	private String cittaCostituzione;

	public Long getAziendaId() {
		return aziendaId;
	}

	public void setAziendaId(final Long aziendaId) {
		this.aziendaId = aziendaId;
	}

	public Long getSoggettoId() {
		return soggettoId;
	}

	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}

	public String getDenominazione() {
		return denominazione;
	}

	public void setDenominazione(final String denominazione) {
		this.denominazione = denominazione;
	}

	public Date getDataDiCostituzione() {
		return dataDiCostituzione;
	}

	public void setDataDiCostituzione(final Date dataDiCostituzione) {
		this.dataDiCostituzione = dataDiCostituzione;
	}

	public String getNormalisedName() {
		return normalisedName;
	}

	public void setNormalisedName(final String normalisedName) {
		this.normalisedName = normalisedName;
	}

	public Long getOpId() {
		return opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}

	public String getNazioneCostituzione() {
		return nazioneCostituzione;
	}

	public void setNazioneCostituzione(final String nazioneCostituzione) {
		this.nazioneCostituzione = nazioneCostituzione;
	}

	public String getCittaCostituzione() {
		return cittaCostituzione;
	}

	public void setCittaCostituzione(final String cittaCostituzione) {
		this.cittaCostituzione = cittaCostituzione;
	}	

}
