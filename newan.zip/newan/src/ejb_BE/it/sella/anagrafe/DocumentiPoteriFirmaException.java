package it.sella.anagrafe;

public class DocumentiPoteriFirmaException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public DocumentiPoteriFirmaException() {
		// Explicit Empty Constructor
    }

    public DocumentiPoteriFirmaException(final String errMessage) {
        super(errMessage);
    }
    
    public DocumentiPoteriFirmaException(final String errMessage, final Throwable cause) {
        super(errMessage, cause);
    }

}
