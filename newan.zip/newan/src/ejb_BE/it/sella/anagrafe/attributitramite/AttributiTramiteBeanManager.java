package it.sella.anagrafe.attributitramite;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;


/**
 * Manager Class to handle AttributiTramite
 *
 */
public class AttributiTramiteBeanManager implements IAttributiTramiteBeanManager {

	private final EntityManager entityManager;

	public AttributiTramiteBeanManager(){
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.attributitramite.IAttributiTramiteBeanManager#create(it.sella.anagrafe.attributitramite.AttributiTramite)
	 */
	public AttributiTramite create(final AttributiTramite attributiTramiteView) throws GestoreAnagrafeException{

		final AttributiTramite attributiTramite = new AttributiTramiteBean();
		BeanUtil.copyProperties(attributiTramite, attributiTramiteView);
		entityManager.persist(attributiTramite);
		entityManager.flush();
		BeanUtil.copyProperties(attributiTramiteView,attributiTramite);
		return attributiTramiteView;
	}


	/* (non-Javadoc)
	 * @see it.sella.anagrafe.attributitramite.IAttributiTramiteBeanManager#update(it.sella.anagrafe.attributitramite.AttributiTramite)
	 */
	public AttributiTramite update(final AttributiTramite AttributiTramiteView){
		entityManager.persist(AttributiTramiteView);
		return AttributiTramiteView;
	}


	/* (non-Javadoc)
	 * @see it.sella.anagrafe.attributitramite.IAttributiTramiteBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public AttributiTramite findByPrimaryKey(final Long primaryKey) throws FinderException{
		if(primaryKey == null){
			throw new FinderException("PrimaryKey is null");
		}
		final AttributiTramite attributiTramite =  entityManager.find(AttributiTramiteBean.class, primaryKey);
		if(attributiTramite==null){
			throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return attributiTramite;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.attributitramite.IAttributiTramiteBeanManager#findBySoggettoId(java.lang.Long)
	 */
	public AttributiTramite findBySoggettoId(final Long soggettoId) throws FinderException{
		try{
			final Query findBySoggettoId = entityManager.createNamedQuery("AttributiTramiteBean.findBySoggettoId");
			findBySoggettoId.setParameter("soggettoId", soggettoId);
			final AttributiTramite attributiTramite =  (AttributiTramite) findBySoggettoId.getSingleResult();

			if(attributiTramite==null) {
				throw new FinderException("getSingleResult() did not retrieve any entities");
			}

			return attributiTramite;
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}
}
