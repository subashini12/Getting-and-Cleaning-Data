package it.sella.anagrafe.attributitramite;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="AN_TR_ATTRIBUTI_TRAMITE")
@SequenceGenerator(name="AttributiTramiteSequenceGenerator" , sequenceName="SEQ_ATTRIBUTITRAMITEHOME" , allocationSize = 1 )
@NamedQueries({
	@NamedQuery(name="AttributiTramiteBean.findBySoggettoId",query="select o from AttributiTramiteBean o where o.soggettoId= :soggettoId")
})
public class AttributiTramiteBean implements AttributiTramite{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="AttributiTramiteSequenceGenerator")
	@Column(name="AT_ATTRIBUTI_TRAMITE_ID")
	private Long attributitramiteId;

	@Column(name="AT_SOGGETTO_ID")
	private Long soggettoId;

	@Column(name="AT_NAZCM")
	private Long nazione;

	@Column(name="AT_SETTCM")
	private String settore;

	@Column(name="AT_AROB")
	private Long aROB;

	@Column(name="AT_EROB")
	private Long eROB;

	@Column(name="AT_OP_ID")
	private Long opId;

	public void setAttributitramiteId(final Long attributitramiteId) {
		this.attributitramiteId = attributitramiteId;
	}

	public Long getAttributitramiteId() {
		return attributitramiteId;
	}

	public Long getAROB() {
		return aROB;
	}

	public void setAROB(final Long arob) {
		aROB = arob;

	}

	public Long getEROB() {
		return eROB;
	}

	public void setEROB(final Long erob) {
		eROB = erob;

	}

	public Long getNazione() {
		return nazione;
	}

	public void setNazione(final Long nazione) {
		this.nazione = nazione;

	}

	public Long getOpId() {
		return opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;

	}

	public String getSettore() {
		return settore;
	}

	public void setSettore(final String settore) {
		this.settore = settore;

	}

	public Long getSoggettoId() {
		return soggettoId;
	}

	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;

	}

}
