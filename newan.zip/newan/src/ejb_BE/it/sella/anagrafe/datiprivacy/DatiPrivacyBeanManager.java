package it.sella.anagrafe.datiprivacy;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;

import java.util.Collection;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;


/**
 * Manager Class to handle DatiPrivacy
 *
 */
public class DatiPrivacyBeanManager implements IDatiPrivacyBeanManager {

	private final EntityManager entityManager;
	public DatiPrivacyBeanManager(){
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datiprivacy.IDatiPrivacyBeanManager#create(it.sella.anagrafe.datiprivacy.DatiPrivacy)
	 */
	public DatiPrivacy create(final DatiPrivacy datiPrivacy) throws GestoreAnagrafeException {
		final DatiPrivacy datiPrivacyBean = new DatiPrivacyBean();
		BeanUtil.copyProperties(datiPrivacyBean,datiPrivacy);
		entityManager.persist(datiPrivacyBean);
		entityManager.flush();
		BeanUtil.copyProperties(datiPrivacy,datiPrivacyBean);
		return datiPrivacy;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datiprivacy.IDatiPrivacyBeanManager#update(it.sella.anagrafe.datiprivacy.DatiPrivacy)
	 */
	public DatiPrivacy update(final DatiPrivacy datiPrivacy) {

		entityManager.persist(datiPrivacy);

		return datiPrivacy;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datiprivacy.IDatiPrivacyBeanManager#remove(it.sella.anagrafe.datiprivacy.DatiPrivacy)
	 */
	public void remove(final DatiPrivacy datiPrivacyView) {

		entityManager.remove(datiPrivacyView);

	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datiprivacy.IDatiPrivacyBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public DatiPrivacy findByPrimaryKey(final Long primaryKey) throws FinderException {
		if(primaryKey == null){
			throw new FinderException("PrimaryKey is null");
		}
		final DatiPrivacy datiPrivacy = entityManager.find(DatiPrivacyBean.class, primaryKey);
		if(datiPrivacy==null){
			throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return datiPrivacy;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.datiprivacy.IDatiPrivacyBeanManager#findBySoggettoId(java.lang.Long)
	 */
	public Collection<DatiPrivacy> findBySoggettoId(final Long soggettoId) throws FinderException {
		try{
			final Query findBySoggettoId = entityManager.createNamedQuery("it.sella.anagrafe.persistence.datiprivacy.findBySoggettoId");
			findBySoggettoId.setParameter("soggettoId", soggettoId);
			@SuppressWarnings("unchecked")
			final
			Collection<DatiPrivacy> datiPrivacyList = findBySoggettoId.getResultList();

			return datiPrivacyList;
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}

}
