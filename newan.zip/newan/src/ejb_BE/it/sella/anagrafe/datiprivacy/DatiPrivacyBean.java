package it.sella.anagrafe.datiprivacy;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="AN_TR_DATIPRIVACY")
@SequenceGenerator(name = "datiprivacyNewSequenceGenerator", sequenceName="SEQ_DatiPrivacyHome", allocationSize = 1)
@NamedQuery(name="it.sella.anagrafe.persistence.datiprivacy.findBySoggettoId",query="SELECT o FROM DatiPrivacyBean o WHERE o.soggettoId= :soggettoId")
public class DatiPrivacyBean implements DatiPrivacy {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="datiprivacyNewSequenceGenerator")
	@Column(name="PR_DATIPRIVACY_ID")
	private Long id;
	
	@Column(name="PR_SOGGETTO_ID")
	private Long soggettoId;
	
	@Column(name="PR_RIGHT_PK")
	private Long rightPk;
	
	@Column(name="PR_VALUE")
	private String value;
	
	@Column(name="PR_OP_ID")
	private Long opId;
	
	
	public Long getId() {
		return id;
	}
	public void setId(final Long id) {
		this.id = id;
	}
	public Long getSoggettoId() {
		return soggettoId;
	}
	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}
	public Long getRightPk() {
		return rightPk;
	}
	public void setRightPk(final Long rightPk) {
		this.rightPk = rightPk;
	}
	public String getValue() {
		return value;
	}
	public void setValue(final String value) {
		this.value = value;
	}
	public Long getOpId() {
		return opId;
	}
	public void setOpId(final Long opId) {
		this.opId = opId;
	}
}
