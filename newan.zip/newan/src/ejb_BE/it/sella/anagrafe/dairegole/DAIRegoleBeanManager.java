package it.sella.anagrafe.dairegole;

import java.util.Collection;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

/**
 * @author GBS03447
 *
 */
public class DAIRegoleBeanManager implements IDAIRegoleBeanManager {
	
	private static final Log4Debug log4Debug  = Log4DebugFactory.getLog4Debug(DAIRegoleBeanManager.class);
	private EntityManager entityManager = null;

	public DAIRegoleBeanManager() {
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.dairegole.IDAIRegoleBeanManager#create(it.sella.anagrafe.dairegole.DAIRegole)
	 */
	public DAIRegole create(final DAIRegole daiRegole) throws GestoreAnagrafeException {
		final DAIRegoleBean daiRegoleBean = new DAIRegoleBean();
		BeanUtil.copyProperties(daiRegoleBean, daiRegole);
		entityManager.persist(daiRegoleBean);
		entityManager.flush();
		BeanUtil.copyProperties(daiRegole, daiRegoleBean);
		return daiRegole;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.dairegole.IDAIRegoleBeanManager#update(it.sella.anagrafe.dairegole.DAIRegole)
	 */
	public DAIRegole update(final DAIRegole daiRegole) {
		entityManager.persist(daiRegole);
		return daiRegole;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.dairegole.IDAIRegoleBeanManager#remove(it.sella.anagrafe.dairegole.DAIRegole)
	 */
	public void remove(final DAIRegole daiRegole) {
		entityManager.remove(daiRegole);
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.dairegole.IDAIRegoleBeanManager#findBySoggettoId(java.lang.Long)
	 */
	@SuppressWarnings("unchecked")
	public Collection<DAIRegole> findBySoggettoId(final Long soggettoId) throws FinderException {
		try {
			final Query findBySoggettoId = entityManager.createNamedQuery("DAIRegoleBean.findBySoggettoId");
			findBySoggettoId.setParameter("soggettoId", soggettoId);
			return findBySoggettoId.getResultList();
		} catch (final NoResultException noResultExcep) {
			log4Debug.debugStackTrace(noResultExcep);
			throw new FinderException(noResultExcep.getMessage());
		}
	}
	
	/* (non-Javadoc)
	 * @see it.sella.anagrafe.dairegole.IDAIRegoleBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public DAIRegole findByPrimaryKey(final Long primaryKey) throws FinderException {
		if (primaryKey == null) {
			throw new FinderException("PrimaryKey is null");
		}
		final DAIRegole daiRegole = entityManager.find(DAIRegoleBean.class, primaryKey);
		if (daiRegole == null) {
			throw new FinderException("Record Not Found For PrimaryKey " + primaryKey);
		}
		return daiRegole;
	}
	
	/* (non-Javadoc)
	 * @see it.sella.anagrafe.dairegole.IDAIRegoleBeanManager#findBySoggettoIdAndPesoId(java.lang.Long, java.lang.Long)
	 */
	public DAIRegole findBySoggettoIdAndPesoId(final Long soggettoId, final Long pesoId) throws FinderException {
		try {
			final Query findBySoggettoAndPesoId = entityManager.createNamedQuery("DAIRegoleBean.findBySoggettoAndPesoId");
			findBySoggettoAndPesoId.setParameter("soggettoId", soggettoId);
			findBySoggettoAndPesoId.setParameter("pesoId", pesoId);
			return (DAIRegole) findBySoggettoAndPesoId.getSingleResult();
		} catch (final NoResultException noResultExcep) {
			log4Debug.debugStackTrace(noResultExcep);
			throw new FinderException(noResultExcep.getMessage());
		}
	}
}
