package it.sella.anagrafe.soggetto;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.Collection;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

/**
 * Manager Class to handle Soggetto
 *
 */
public class SoggettoBeanManager implements ISoggettoBeanManager {
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(SoggettoBeanManager.class);
	private static EntityManager entityManager;

	public SoggettoBeanManager(){
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.soggetto.ISoggettoBeanManager#create(it.sella.anagrafe.soggetto.Soggetto)
	 */
	public Soggetto create(final Soggetto soggetto) throws GestoreAnagrafeException {
		final SoggettoBean soggettoBean = new SoggettoBean();
		BeanUtil.copyProperties(soggettoBean, soggetto);
		entityManager.persist(soggettoBean);
		entityManager.flush();
		BeanUtil.copyProperties(soggetto, soggettoBean);
		return soggetto;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.soggetto.ISoggettoBeanManager#update(it.sella.anagrafe.soggetto.Soggetto)
	 */
	public Soggetto update(final Soggetto soggetto){
		entityManager.persist(soggetto);
		return soggetto;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.soggetto.ISoggettoBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public Soggetto findByPrimaryKey(final Long primaryKey) throws FinderException{
		if(primaryKey == null){
			throw new FinderException("PrimaryKey is null");
		}
		final Soggetto soggetto = entityManager.find(SoggettoBean.class, primaryKey);
		if(soggetto == null){
				throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return soggetto;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.soggetto.ISoggettoBeanManager#findByTipoSoggettoId(java.lang.Long)
	 */
	@SuppressWarnings("unchecked")
	public Collection<Soggetto> findByTipoSoggettoId(final Long tipoSoggettoId)throws FinderException {
		try {
			final String query = "SoggettoBean.findByTipoSoggettoId";
			final Query findByTipoSoggettoId = entityManager.createNamedQuery(query);
			findByTipoSoggettoId.setParameter("tipoSoggettoId", tipoSoggettoId);
			return findByTipoSoggettoId.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		} catch (final NonUniqueResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException("too_many_results_for_get_single_result");
		}
	}
}
