
package it.sella.anagrafe.soggetto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="AN_MA_SOGGETTO")
@SequenceGenerator(name="SoggettoSequenceGenerator" , sequenceName="SEQ_SOGGETTOHOME" , allocationSize = 1 )
@NamedQueries({
	@NamedQuery(name="SoggettoBean.findByTipoSoggettoId",query="select o from SoggettoBean o where o.tipoSoggettoId= :tipoSoggettoId")
})
public class SoggettoBean implements Soggetto {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SoggettoSequenceGenerator")
	@Column(name="SO_SOGGETTO_ID")
	private Long soggettoId;

	@Column(name="SO_TIPO_SOGGETTO_ID")
    private Long tipoSoggettoId;

	@Column(name="SO_OP_ID")
    private Long opId;

    public Long getSoggettoId() {
		return soggettoId;
	}
	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}
	public Long getTipoSoggettoId() {
		return tipoSoggettoId;
	}
	public void setTipoSoggettoId(final Long tipoSoggettoId) {
		this.tipoSoggettoId = tipoSoggettoId;
	}
	public Long getOpId() {
		return opId;
	}
	public void setOpId(final Long opId) {
		this.opId = opId;
	}

}
