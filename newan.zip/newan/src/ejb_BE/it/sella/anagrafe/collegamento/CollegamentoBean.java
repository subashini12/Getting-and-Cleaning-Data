package it.sella.anagrafe.collegamento;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="AN_TR_COLLAGAMENTO_SOGGETTO")
@SequenceGenerator(name="CollegamentoSequenceGenerator" , sequenceName="SEQ_COLLEGAMENTOHOME" , allocationSize = 1 )
@NamedQueries({
	@NamedQuery(name="CollegamentoBean.findBySoggettoId",query="select o from CollegamentoBean o where o.soggettoId= :soggettoId"),
	@NamedQuery(name="CollegamentoBean.findBySoggettoAndMotivo",query="select o from CollegamentoBean o where (o.soggettoId= :soggettoId and o.motivo=:motivo) and (o.dataFine is null or o.dataFine >:dataFine)"),
	@NamedQuery(name="CollegamentoBean.findBySoggettoMotivoAndLinked",query="select o from CollegamentoBean o where o.soggettoId= :soggettoId and o.motivo=:motivo and o.linkedSoggettoId =:linkedSoggettoId and o.dataFine is null"),
	@NamedQuery(name="CollegamentoBean.findByPrincipalMotivoAndLinked",query="select o from CollegamentoBean o where o.soggettoId= :soggettoId and o.motivo=:motivo and o.linkedSoggettoId =:linkedSoggettoId and o.dataFine is null"),
	@NamedQuery(name="CollegamentoBean.findByLinkedSoggetto",query="select o from CollegamentoBean o where o.linkedSoggettoId= :linkedSoggettoId and  o.dataFine is null"),
	@NamedQuery(name="CollegamentoBean.findBySoggettoCollegamento",query="select o from CollegamentoBean o where o.linkedSoggettoId= :linkedSoggettoId and o.motivo=:motivo and  o.dataFine is null")
})
public class CollegamentoBean  implements Collegamento {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="CollegamentoSequenceGenerator")
	@Column(name="CL_ID")
	private Long collegamentoId;

	@Column(name="CL_SOGGETTO_PRINCIPALE")
	private Long soggettoId;

	@Column(name="CL_MOTIVO")
	private Long motivo;

	@Column(name="CL_NOTE")
	private String note;

	@Column(name="CL_DATA_INIZIO")
	private Timestamp dataInizio;

	@Column(name="CL_DATA_FINE")
	private Timestamp dataFine;

	@Column(name="CL_LINKED_SOGGETTO")
	private Long linkedSoggettoId;

	@Column(name="CL_OP_ID")
	private Long opId;

	public void setCollegamentoId(final Long collegamentoId) {
		this.collegamentoId = collegamentoId;
	}

	public Long getCollegamentoId() {
		return collegamentoId;
	}
	public Long getSoggettoId()  {
	    return this.soggettoId;
	}

	public Long getMotivo() {
	    return this.motivo;
	}
	public String getNote() {
	    return this.note;
	}
	public Timestamp getDataInizio() {
	    return this.dataInizio;
	}
	public Timestamp getDataFine() {
	    return this.dataFine;
	}
	public Long getLinkedSoggettoId() {
	    return this.linkedSoggettoId;
	}

	public Long getOpId() {
		return this.opId;
	}

	public void setSoggettoId(final Long soggettoId) {
	    this.soggettoId=soggettoId;
	}
	public void setMotivo(final Long motivo) {
	    this.motivo=motivo;
	}
	public void setNote(final String note) {
	    this.note=note;
	}
	public void setDataInizio(final java.sql.Timestamp dataInizio) {
	    this.dataInizio=dataInizio;
	}
	public void setDataFine(final java.sql.Timestamp dataFine) {
	    this.dataFine=dataFine;
	}
	public void setLinkedSoggettoId(final Long linkedSoggettoId) {
	    this.linkedSoggettoId=linkedSoggettoId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}

}