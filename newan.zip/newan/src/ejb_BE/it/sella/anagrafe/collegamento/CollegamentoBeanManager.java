package it.sella.anagrafe.collegamento;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Timestamp;
import java.util.Collection;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

/**
 * Manager Class to handle Collegamento
 *
 */
public class CollegamentoBeanManager  implements ICollegamentoBeanManager{

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CollegamentoBeanManager.class);
	private final EntityManager entityManager;

	public CollegamentoBeanManager(){
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.collegamento.ICollegamentoBeanManager#create(it.sella.anagrafe.collegamento.Collegamento)
	 */
	public Collegamento create(final Collegamento collegamento) throws GestoreAnagrafeException{
		final CollegamentoBean collegamentoBean = new CollegamentoBean();
		BeanUtil.copyProperties(collegamentoBean, collegamento);
		entityManager.persist(collegamentoBean);
		entityManager.flush();
		BeanUtil.copyProperties(collegamento,collegamentoBean);
		return collegamento;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.collegamento.ICollegamentoBeanManager#update(it.sella.anagrafe.collegamento.Collegamento)
	 */
	public Collegamento update(final Collegamento collegamento){
		entityManager.persist(collegamento);
		return collegamento;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.collegamento.ICollegamentoBeanManager#remove(it.sella.anagrafe.collegamento.Collegamento)
	 */
	public void remove(final Collegamento collegamento){
		entityManager.remove(collegamento);
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.collegamento.ICollegamentoBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public Collegamento findByPrimaryKey(final Long primaryKey)throws FinderException{
		if(primaryKey == null){
			throw new FinderException("PrimaryKey is null");
		}
		final Collegamento collegamento= entityManager.find(CollegamentoBean.class, primaryKey);
		if(collegamento == null){
			throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return collegamento;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.collegamento.ICollegamentoBeanManager#findBySoggettoId(java.lang.Long)
	 */
	@SuppressWarnings("unchecked")
	public Collection<Collegamento> findBySoggettoId(final Long soggettoId)throws FinderException{
		final Query findBySoggettoId = entityManager.createNamedQuery("CollegamentoBean.findBySoggettoId");
		findBySoggettoId.setParameter("soggettoId", soggettoId);
		return findBySoggettoId.getResultList();
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.collegamento.ICollegamentoBeanManager#findBySoggettoAndMotivo(java.lang.Long, java.lang.Long, java.sql.Timestamp)
	 */
	@SuppressWarnings("unchecked")
	public Collection<Collegamento> findBySoggettoAndMotivo(final Long soggettoId , final Long motivo ,final Timestamp endDate)throws FinderException{
		try{
			final String query = "CollegamentoBean.findBySoggettoAndMotivo";
			final Query findBySoggettoAndMotivo = entityManager.createNamedQuery(query);
			findBySoggettoAndMotivo.setParameter("soggettoId", soggettoId);
			findBySoggettoAndMotivo.setParameter("motivo", motivo);
			findBySoggettoAndMotivo.setParameter("dataFine", endDate);
			return findBySoggettoAndMotivo.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}


	/* (non-Javadoc)
	 * @see it.sella.anagrafe.collegamento.ICollegamentoBeanManager#findBySoggettoMotivoAndLinked(java.lang.Long, java.lang.Long, java.lang.Long)
	 */
	public Collegamento findBySoggettoMotivoAndLinked(final Long principaleId , final Long motivo ,final Long linkedSoggettoId)throws FinderException{
		try {
			final String query = "CollegamentoBean.findBySoggettoMotivoAndLinked";
			final Query findBySoggettoMotivoAndLinked = entityManager.createNamedQuery(query);
			findBySoggettoMotivoAndLinked.setParameter("soggettoId", principaleId);
			findBySoggettoMotivoAndLinked.setParameter("motivo", motivo);
			findBySoggettoMotivoAndLinked.setParameter("linkedSoggettoId", linkedSoggettoId);
			return (Collegamento) findBySoggettoMotivoAndLinked.getSingleResult();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		} catch (final NonUniqueResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException("too_many_results_for_get_single_result");
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.collegamento.ICollegamentoBeanManager#findByPrincipalMotivoAndLinked(java.lang.Long, java.lang.Long, java.lang.Long)
	 */
	@SuppressWarnings("unchecked")
	public Collection<Collegamento> findByPrincipalMotivoAndLinked(final Long principaleId , final Long motivo ,final Long linkedSoggettoId)throws FinderException{
		try{
			final  String query = "CollegamentoBean.findByPrincipalMotivoAndLinked";
			final Query findByPrincipalMotivoAndLinked = entityManager.createNamedQuery(query);
			findByPrincipalMotivoAndLinked.setParameter("soggettoId", principaleId);
			findByPrincipalMotivoAndLinked.setParameter("motivo", motivo);
			findByPrincipalMotivoAndLinked.setParameter("linkedSoggettoId", linkedSoggettoId);
			return findByPrincipalMotivoAndLinked.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.collegamento.ICollegamentoBeanManager#findBySoggettoCollegamento(java.lang.Long, java.lang.Long)
	 */
	@SuppressWarnings("unchecked")
	public Collection<Collegamento> findBySoggettoCollegamento(final Long linkedSoggettoId , final Long motivo)throws FinderException{
		try{
			final  String query = "CollegamentoBean.findBySoggettoCollegamento";
			final Query findBySoggettoCollegamento = entityManager.createNamedQuery(query);
			findBySoggettoCollegamento.setParameter("linkedSoggettoId", linkedSoggettoId);
			findBySoggettoCollegamento.setParameter("motivo", motivo);
			final Collection<Collegamento> collegamentos =  findBySoggettoCollegamento.getResultList();
			return collegamentos;
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.collegamento.ICollegamentoBeanManager#findByLinkedSoggetto(java.lang.Long)
	 */
	@SuppressWarnings("unchecked")
	public Collection<Collegamento> findByLinkedSoggetto(final Long linkedSoggettoId)throws FinderException{
		try{
			final  String query = "CollegamentoBean.findByLinkedSoggetto";
			final Query findByLinkedSoggetto = entityManager.createNamedQuery(query);
			findByLinkedSoggetto.setParameter("linkedSoggettoId", linkedSoggettoId);
			final Collection<Collegamento> collegamentos =  findByLinkedSoggetto.getResultList();
			return collegamentos;
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}
}
