package it.sella.anagrafe.documentstatus;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;


public class DocumentStatusBeanManager implements IDocumentStatusBeanManager {
	private static EntityManager entityManager;
	
	public DocumentStatusBeanManager() {
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.documentstatus.IDocumentStatusBeanManager#create(it.sella.anagrafe.documentstatus.DocumentStatus)
	 */
	@Override
	public DocumentStatus create(final DocumentStatus documentoStatus) throws GestoreAnagrafeException {
		final DocumentStatusBean docStatusBean = new DocumentStatusBean();
		BeanUtil.copyProperties(docStatusBean, documentoStatus);
		entityManager.persist(docStatusBean);
		entityManager.flush();
		BeanUtil.copyProperties(documentoStatus, docStatusBean);
		return documentoStatus;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.documentstatus.IDocumentStatusBeanManager#update(it.sella.anagrafe.documentstatus.DocumentStatus)
	 */
	@Override
	public void update(final DocumentStatus documentoStatus) {
		entityManager.persist(documentoStatus);
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.documentstatus.IDocumentStatusBeanManager#remove(it.sella.anagrafe.documentstatus.DocumentStatus)
	 */
	@Override
	public void remove(DocumentStatus documentoStatus) {
		entityManager.remove(documentoStatus);
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.documentstatus.IDocumentStatusBeanManager#findByDocumentId(java.lang.Long)
	 */
	@Override
	public DocumentStatus findByDocumentId(Long documentId) throws FinderException {
		try {
			final String query = "DocumentStatusBean.findByDocumentId";
			final Query findByDocumentId = entityManager.createNamedQuery(query);
			findByDocumentId.setParameter("documentId", documentId);
			return (DocumentStatus) findByDocumentId.getSingleResult();
		} catch (final NoResultException e) {
			throw new FinderException(e.getMessage());
		}
	}

}
