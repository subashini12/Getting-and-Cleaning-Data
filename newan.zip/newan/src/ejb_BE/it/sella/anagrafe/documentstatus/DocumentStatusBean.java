package it.sella.anagrafe.documentstatus;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="AN_TR_DOC_STATUS")
@NamedQuery(name="DocumentStatusBean.findByDocumentId",query="select o from DocumentStatusBean o where o.documentId= :documentId")
public class DocumentStatusBean implements DocumentStatus {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="DS_DOCUMENT_ID")
	private Long documentId;
	
	@Column(name="DS_SOGGETTO_ID")
	private Long soggettoId;
	
	@Column(name="DS_CAUSALE")
	private String tipoDocumentCausale;
	
	@Column(name="DS_DESCRIZIONE")
	private String tipoDocumentDesc;
	
	@Column(name="DS_TIPO_SOGGETTO")
	private String tipoSoggetto;
	
	@Column(name="DS_DATA_EMISSIONE")
	private Timestamp dataEmissione;
	
	@Column(name="DS_DATA_SCADENZA")
	private Timestamp dataScadenza;
	
	@Column(name="DS_STATUS")
	private String status;
	
	@Column(name="DS_OP_ID")
	private Long opId;
	
	public Long getDocumentId() {
		return documentId;
	}
	public void setDocumentId(Long documentId) {
		this.documentId = documentId;
	}
	public Long getSoggettoId() {
		return soggettoId;
	}
	public void setSoggettoId(Long soggettoId) {
		this.soggettoId = soggettoId;
	}
	public String getTipoDocumentCausale() {
		return tipoDocumentCausale;
	}
	public void setTipoDocumentCausale(String tipoDocumentCausale) {
		this.tipoDocumentCausale = tipoDocumentCausale;
	}
	public String getTipoDocumentDesc() {
		return tipoDocumentDesc;
	}
	public void setTipoDocumentDesc(String tipoDocumentDesc) {
		this.tipoDocumentDesc = tipoDocumentDesc;
	}
	public String getTipoSoggetto() {
		return tipoSoggetto;
	}
	public void setTipoSoggetto(String tipoSoggetto) {
		this.tipoSoggetto = tipoSoggetto;
	}
	public Timestamp getDataEmissione() {
		return dataEmissione;
	}
	public void setDataEmissione(Timestamp dataEmissione) {
		this.dataEmissione = dataEmissione;
	}
	public Timestamp getDataScadenza() {
		return dataScadenza;
	}
	public void setDataScadenza(Timestamp dataScadenza) {
		this.dataScadenza = dataScadenza;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Long getOpId() {
		return opId;
	}
	public void setOpId(Long opId) {
		this.opId = opId;
	}
	
}
