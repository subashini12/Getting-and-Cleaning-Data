package it.sella.anagrafe.recapitinondisponibile;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @author GBS03447
 *
 */
@Entity
@Table(name = "AN_TR_RECAPITI_NON_DISP")
@SequenceGenerator(name = "RecapNonDispSequenceGenerator", sequenceName = "AN_SQ_RECAP_NON_DISP", allocationSize = 1)
@NamedQueries({ @NamedQuery(name = "RecapitiNonDisponibileBean.findBySoggettoId", query = "select o from RecapitiNonDisponibileBean o where o.soggettoId = :soggettoId and o.dataFine is null"),
	            @NamedQuery(name = "RecapitiNonDisponibileBean.findBySoggettoIdAndTipoRecapiti", query = "select o from RecapitiNonDisponibileBean o where o.soggettoId = :soggettoId and o.tipoRecapiti = :tipoRecapiti and o.dataFine is null")
			 })
public class RecapitiNonDisponibileBean implements RecapitiNonDisponibile {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RecapNonDispSequenceGenerator")
	@Column(name="RN_ID")
	private Long id;

	@Column(name="RN_SOGGETTO_ID")
	private Long soggettoId;
	
	@Column(name="RN_TIPO_RECAPITO")
	private Long tipoRecapiti;
	
	@Column(name="RN_DATA_INIZIO")
	private Timestamp dataInizio;
	
	@Column(name="RN_DATA_FINE")
	private Timestamp dataFine;
	
	@Column(name="RN_UTENTE_INSERIMENTO")
	private String utenteInserimento;
	
	@Column(name="RN_UTENTE_MODIFICA")
	private String utenteModifica;
	
	@Column(name="RN_OP_ID")
	private Long opId;
	
	public Long getId() {
		return id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public Long getSoggettoId() {
		return soggettoId;
	}

	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}

	public Long getTipoRecapiti() {
		return tipoRecapiti;
	}

	public void setTipoRecapiti(final Long tipoRecapiti) {
		this.tipoRecapiti = tipoRecapiti;
	}

	public Timestamp getDataInizio() {
		return dataInizio;
	}

	public void setDataInizio(final Timestamp dataInizio) {
		this.dataInizio = dataInizio;
	}

	public Timestamp getDataFine() {
		return dataFine;
	}

	public void setDataFine(final Timestamp dataFine) {
		this.dataFine = dataFine;
	}

	public String getUtenteInserimento() {
		return utenteInserimento;
	}

	public void setUtenteInserimento(final String utenteInserimento) {
		this.utenteInserimento = utenteInserimento;
	}

	public String getUtenteModifica() {
		return utenteModifica;
	}

	public void setUtenteModifica(final String utenteModifica) {
		this.utenteModifica = utenteModifica;
	}

	public Long getOpId() {
		return opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}
}
