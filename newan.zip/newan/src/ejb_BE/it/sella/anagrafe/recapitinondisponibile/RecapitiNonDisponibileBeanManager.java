package it.sella.anagrafe.recapitinondisponibile;

import java.util.Collection;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

/**
 * @author gbs03447
 *
 */
public class RecapitiNonDisponibileBeanManager implements IRecapitiNonDisponibileBeanManager {
	
	private static final Log4Debug log4Debug  = Log4DebugFactory.getLog4Debug(RecapitiNonDisponibileBeanManager.class);
	private EntityManager entityManager = null;
	
	public RecapitiNonDisponibileBeanManager() {
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}
	
	/* (non-Javadoc)
	 * @see it.sella.anagrafe.recapitinondisponibile.IRecapitiNonDisponibileBeanManager#create(it.sella.anagrafe.recapitinondisponibile.RecapitiNonDisponibile)
	 */
	public RecapitiNonDisponibile create(final RecapitiNonDisponibile recapNonDisp) throws GestoreAnagrafeException {
		log4Debug.debug("RecapitiNonDisponibile   ==============   CREATE ============");
		final RecapitiNonDisponibileBean recapNonDispBean = new RecapitiNonDisponibileBean();
		BeanUtil.copyProperties(recapNonDispBean, recapNonDisp);
		entityManager.persist(recapNonDispBean);
		entityManager.flush();
		BeanUtil.copyProperties(recapNonDisp, recapNonDispBean);
		return recapNonDisp;
	}
	
	/* (non-Javadoc)
	 * @see it.sella.anagrafe.recapitinondisponibile.IRecapitiNonDisponibileBeanManager#update(it.sella.anagrafe.recapitinondisponibile.RecapitiNonDisponibile)
	 */
	public RecapitiNonDisponibile update(final RecapitiNonDisponibile recapNonDisp) {
		entityManager.persist(recapNonDisp);
		return recapNonDisp;
	}
	
	/* (non-Javadoc)
	 * @see it.sella.anagrafe.recapitinondisponibile.IRecapitiNonDisponibileBeanManager#remove(it.sella.anagrafe.recapitinondisponibile.RecapitiNonDisponibile)
	 */
	public void remove(final RecapitiNonDisponibile recapNonDisp) {
		entityManager.remove(recapNonDisp);
	}
	
	/* (non-Javadoc)
	 * @see it.sella.anagrafe.recapitinondisponibile.IRecapitiNonDisponibileBeanManager#findBySoggettoId(java.lang.Long)
	 */
	public Collection<RecapitiNonDisponibile> findBySoggettoId(final Long soggettoId) throws FinderException {
		try {
			final Query findBySoggettoId = entityManager.createNamedQuery("RecapitiNonDisponibileBean.findBySoggettoId");
			findBySoggettoId.setParameter("soggettoId", soggettoId);
			return findBySoggettoId.getResultList();
		} catch (final NoResultException noResultExcep) {
			log4Debug.debugStackTrace(noResultExcep);
			throw new FinderException(noResultExcep.getMessage());
		}
	}
	
	/* (non-Javadoc)
	 * @see it.sella.anagrafe.recapitinondisponibile.IRecapitiNonDisponibileBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public RecapitiNonDisponibile findByPrimaryKey(final Long primaryKey) throws FinderException {
		if (primaryKey == null) {
			throw new FinderException("PrimaryKey is null");
		}
		final RecapitiNonDisponibile recapNonDisp = entityManager.find(RecapitiNonDisponibile.class, primaryKey);
		if (recapNonDisp == null) {
			throw new FinderException("Record Not Found For PrimaryKey " + primaryKey);
		}
		return recapNonDisp;
	}
	
	/* (non-Javadoc)
	 * @see it.sella.anagrafe.recapitinondisponibile.IRecapitiNonDisponibileBeanManager#findBySoggettoIdAndTipoRecapiti(java.lang.Long, java.lang.Long)
	 */
	public RecapitiNonDisponibile findBySoggettoIdAndTipoRecapiti (final Long soggettoId, final Long tipoRecapiti) throws FinderException {
		try {
			final Query findBySoggettoAndTipoRecap = entityManager.createNamedQuery("RecapitiNonDisponibileBean.findBySoggettoIdAndTipoRecapiti");
			findBySoggettoAndTipoRecap.setParameter("soggettoId", soggettoId);
			findBySoggettoAndTipoRecap.setParameter("tipoRecapiti", tipoRecapiti);
			return (RecapitiNonDisponibile) findBySoggettoAndTipoRecap.getSingleResult();
		} catch (final NoResultException noResultExcep) {
			log4Debug.debugStackTrace(noResultExcep);
			throw new FinderException(noResultExcep.getMessage());
		}
	}
}
