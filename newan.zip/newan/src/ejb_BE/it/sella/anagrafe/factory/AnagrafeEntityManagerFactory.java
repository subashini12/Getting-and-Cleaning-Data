package it.sella.anagrafe.factory;

import it.sella.anagrafe.OperazioneAnagrafeFactory;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;

import javax.naming.NamingException;
import javax.persistence.EntityManager;

public class AnagrafeEntityManagerFactory {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AnagrafeEntityManagerFactory.class);
	private static AnagrafeEntityManagerFactory angrafeEntityManagerFactory = null;
	private EntityManager entityManager = null;
//	private String persistenceUnitName = "AnagrafePersistence";

	public static AnagrafeEntityManagerFactory getInstance(){
		if(angrafeEntityManagerFactory == null) {
			angrafeEntityManagerFactory = new AnagrafeEntityManagerFactory();
		}
		return angrafeEntityManagerFactory;
	}

	public EntityManager getEntityManager(){
		if(entityManager == null || !entityManager.isOpen()){
			try {
				entityManager = OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager().getPersistenceEntityManager();
			} catch (final NamingException namingException) {
	        	log4Debug.severeStackTrace(namingException);
	        } catch (final RemoteException e) {
	        	log4Debug.severeStackTrace(e);
			}

//			EntityManagerFactory emf = Persistence.createEntityManagerFactory(persistenceUnitName);
//			entityManager = emf.createEntityManager();
		}
		return entityManager;
	}
}
