package it.sella.anagrafe.memo;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;

import java.util.Collection;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

/**
 * Manager Class to handle Memo
 *
 */
public class MemoBeanManager implements IMemoBeanManager {

	private final EntityManager entityManager;

	public MemoBeanManager(){
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.memo.IMemoBeanManager#create(it.sella.anagrafe.memo.Memo)
	 */
	public Memo create(final Memo memo) throws GestoreAnagrafeException {

		final Memo memoBean = new MemoBean();

		BeanUtil.copyProperties(memoBean,memo);
		entityManager.persist(memoBean);
		entityManager.flush();
		BeanUtil.copyProperties(memo,memoBean);
		return memo;

	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.memo.IMemoBeanManager#update(it.sella.anagrafe.memo.Memo)
	 */
	public Memo update(final Memo memo) {

		entityManager.persist(memo);

		return memo;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.memo.IMemoBeanManager#remove(it.sella.anagrafe.memo.Memo)
	 */
	public void remove(final Memo memo) {

		entityManager.remove(memo);

	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.memo.IMemoBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public Memo findByPrimaryKey(final Long primaryKey) throws FinderException {
		if(primaryKey == null){
			throw new FinderException("PrimaryKey is null");
		}
		final Memo memoBean = entityManager.find(MemoBean.class, primaryKey);
		if(memoBean==null){
			throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return memoBean;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.memo.IMemoBeanManager#findByMemoSoggettoId(java.lang.Long)
	 */
	public Collection<Memo> findByMemoSoggettoId(final Long soggettoId) throws FinderException {
		try{
			final Query findBySoggettoId = entityManager.createNamedQuery("it.sella.anagrafe.persistence.memo.findByMemoSoggettoId");
			findBySoggettoId.setParameter("soggettoId", soggettoId);
			@SuppressWarnings("unchecked")
			final
			Collection<Memo> memoBeanList = findBySoggettoId.getResultList();

			return memoBeanList;
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}
}
