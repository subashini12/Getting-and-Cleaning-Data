package it.sella.anagrafe.memo;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="an_tr_memo")
@SequenceGenerator(name = "memoNewSequenceGenerator", sequenceName="SEQ_MemoHome", allocationSize = 1)
@NamedQuery(name="it.sella.anagrafe.persistence.memo.findByMemoSoggettoId",query="SELECT o FROM MemoBean o WHERE o.soggettoId= :soggettoId")
public class MemoBean implements Memo {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="ME_MEMO_ID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="memoNewSequenceGenerator")
	private Long id;
	
	@Column(name="ME_TESTO")
	private String memoTesto;
	
	@Column(name="ME_MODALITA_PRESENTAZIONE")
	private String presentazione;
	
	@Column(name="ME_DATA_DECORRENZA")
	private Timestamp decorrenza;
	
	@Column(name="ME_DATA_SCADENZA")
	private Timestamp scadenza;
	
	@Column(name="ME_SOGGETTO_ID")
	private Long soggettoId;
	
	@Column(name="ME_OP_ID")
	private Long opId;

	
	public Long getId() {
		return id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public String getMemoTesto() {
		return memoTesto;
	}

	public void setMemoTesto(final String memoTesto) {
		this.memoTesto = memoTesto;
	}

	public String getPresentazione() {
		return presentazione;
	}

	public void setPresentazione(final String presentazione) {
		this.presentazione = presentazione;
	}

	public Timestamp getDecorrenza() {
		return decorrenza;
	}

	public void setDecorrenza(final Timestamp decorrenza) {
		this.decorrenza = decorrenza;
	}

	public Timestamp getScadenza() {
		return scadenza;
	}

	public void setScadenza(final Timestamp scadenza) {
		this.scadenza = scadenza;
	}

	public Long getSoggettoId() {
		return soggettoId;
	}

	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}

	public Long getOpId() {
		return opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}
}
