package it.sella.anagrafe.tipodatianagrafici;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="AN_TR_DATIANAGRAFE")
@SequenceGenerator(name="DatiAnagraficiSequenceGenerator" , sequenceName="SEQ_TIPODATIANAGRAFICIHOME" , allocationSize = 1 )
@NamedQueries({
	@NamedQuery(name="DatiAnagraficiBean.findBySoggettoId",query="select o from TipoDatiAnagraficiBean o where o.soggettoId= :soggettoId"),
	@NamedQuery(name="DatiAnagraficiBean.findByDatiAnagrafici",query="select o from TipoDatiAnagraficiBean o where o.nome like :nome or o.cognome like :cognome or o.cittaOfBirth like  :cittaOfBirth or o.nazioneOfBirth like :nazioneOfBirth or o.dateValue =:dateValue")
})
public class TipoDatiAnagraficiBean implements TipoDatiAnagrafici {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="DatiAnagraficiSequenceGenerator")
	@Column(name="DN_TIPODATIANAGRAFICI_ID")
	private Long datianagraficiId;

	@Column(name="DN_SOGGETTO_ID")
	private Long soggettoId;

	@Column(name="DN_NOME")
	private String nome;

	@Column(name="DN_COGNOME")
	private String cognome;


	@Column(name="DN_CITTA_OF_BIRTH")
	private String cittaOfBirth;

	@Column(name="DN_NAZIONE_OF_BIRTH")
	private String nazioneOfBirth;

	@Column(name="DN_DATE_OF_BIRTH")
	private Timestamp dateValue;

	@Column(name="DN_NORMALISEDSTRING")
	private String normalisedNome;

	@Column(name="DN_OP_ID")
	private Long opId;

	public Long getDatianagraficiId() {
		return datianagraficiId;
	}


	public Long getSoggettoId() {
		return this.soggettoId;
	}

	public String getNome() {
		return this.nome;
	}

	public String getNormalisedNome() {
		return this.normalisedNome;
	}

	public String getCognome() {
		return this.cognome;
	}

	public String getCittaOfBirth() {
		return this.cittaOfBirth;
	}

	public String getNazioneOfBirth() {
		return this.nazioneOfBirth;
	}

	public Timestamp getDateOfBirth() {
		return this.dateValue;
	}

	public Long getOpId() {
		return this.opId;
	}

	public void setDatianagraficiId(final Long datianagraficiId) {
		this.datianagraficiId = datianagraficiId;
	}


	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}

	public void setNome(final String nome) {
		this.nome = nome;
	}

	public void setNormalisedNome(final String normalisedNome) {
		this.normalisedNome = normalisedNome;
	}

	public void setCognome(final String cognome) {
		this.cognome = cognome;
	}

	public void setCittaOfBirth(final String cittaOfBirth) {
		this.cittaOfBirth = cittaOfBirth;
	}

	public void setNazioneOfBirth(final String nazioneOfBirth) {
		this.nazioneOfBirth = nazioneOfBirth;
	}

	public void setDateOfBirth(final Timestamp value) {
		this.dateValue = value;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}


}
