package it.sella.anagrafe.tipodatianagrafici;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Timestamp;
import java.util.Collection;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

/**
 * Manager Class to handle TipoDatiAnagrafici
 *
 */
public class TipoDatiAnagraficiBeanManager implements ITipoDatiAnagraficiBeanManager {
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(TipoDatiAnagraficiBeanManager.class);
	private static EntityManager entityManager;

	public TipoDatiAnagraficiBeanManager(){
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.tipodatianagrafici.ITipoDatiAnagraficiBeanManager#create(it.sella.anagrafe.tipodatianagrafici.TipoDatiAnagrafici)
	 */
	public TipoDatiAnagrafici create(final TipoDatiAnagrafici aatiAnagrafici) throws GestoreAnagrafeException{
		final TipoDatiAnagraficiBean tipoDatiAnagraficiBean = new TipoDatiAnagraficiBean();
		BeanUtil.copyProperties(tipoDatiAnagraficiBean, aatiAnagrafici);
		entityManager.persist(tipoDatiAnagraficiBean);
		entityManager.flush();
		BeanUtil.copyProperties(aatiAnagrafici,tipoDatiAnagraficiBean);
		return aatiAnagrafici;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.tipodatianagrafici.ITipoDatiAnagraficiBeanManager#update(it.sella.anagrafe.tipodatianagrafici.TipoDatiAnagrafici)
	 */
	public TipoDatiAnagrafici update(final TipoDatiAnagrafici aatiAnagrafici){
		entityManager.persist(aatiAnagrafici);
		return aatiAnagrafici;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.tipodatianagrafici.ITipoDatiAnagraficiBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public TipoDatiAnagrafici findByPrimaryKey(final Long primaryKey)throws FinderException{
		if(primaryKey == null){
			throw new FinderException("PrimaryKey is null");
		}
		final TipoDatiAnagrafici tipoDatiAnagrafici = entityManager.find(TipoDatiAnagraficiBean.class, primaryKey);
		if(tipoDatiAnagrafici == null){
			throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return tipoDatiAnagrafici;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.tipodatianagrafici.ITipoDatiAnagraficiBeanManager#findBySoggettoId(java.lang.Long)
	 */
	public TipoDatiAnagrafici findBySoggettoId(final Long soggettoId)throws FinderException{
		try{
			final String query = "DatiAnagraficiBean.findBySoggettoId";
			final Query findBySoggettoId = entityManager.createNamedQuery(query);
			findBySoggettoId.setParameter("soggettoId", soggettoId);
			return (TipoDatiAnagrafici) findBySoggettoId.getSingleResult();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}catch (final NonUniqueResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException("too_many_results_for_get_single_result");
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.tipodatianagrafici.ITipoDatiAnagraficiBeanManager#findByDatiAnagrafici(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.sql.Timestamp)
	 */
	@SuppressWarnings("unchecked")
	public Collection<TipoDatiAnagrafici> findByDatiAnagrafici(final String nome, final String cognome, final String citta, final String nazione, final Timestamp dataDiNascita)throws FinderException{
		try{
			final String query = "DatiAnagraficiBean.findByDatiAnagrafici";
			final Query findByDatiAnagrafici = entityManager.createNamedQuery(query);
			findByDatiAnagrafici.setParameter("nome", nome);
			findByDatiAnagrafici.setParameter("cognome", cognome);
			findByDatiAnagrafici.setParameter("cittaOfBirth", citta);
			findByDatiAnagrafici.setParameter("nazioneOfBirth", nazione);
			findByDatiAnagrafici.setParameter("dateValue", dataDiNascita);
			return findByDatiAnagrafici.getResultList();
		} catch (final NoResultException e) {
			log4Debug.warnStackTrace(e);
			throw new FinderException(e.getMessage());
		}
	}
}
