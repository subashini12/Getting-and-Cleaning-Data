package it.sella.anagrafe.tiposoggetto;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

/**
 * Manager Class to handle TipoSoggetto
 *
 */
public class TipoSoggettoBeanManager implements ITipoSoggettoBeanManager {

	private final EntityManager entityManager;

	public TipoSoggettoBeanManager(){
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.tiposoggetto.ITipoSoggettoBeanManager#create(it.sella.anagrafe.tiposoggetto.TipoSoggetto)
	 */
	public TipoSoggetto create(final TipoSoggetto tipoSoggettoView) throws GestoreAnagrafeException {

		final TipoSoggetto tipoSoggettoBean = new TipoSoggettoBean();
		BeanUtil.copyProperties(tipoSoggettoBean, tipoSoggettoView);
		entityManager.persist(tipoSoggettoBean);
		entityManager.flush();
		BeanUtil.copyProperties(tipoSoggettoView, tipoSoggettoBean);

		return tipoSoggettoView;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.tiposoggetto.ITipoSoggettoBeanManager#update(it.sella.anagrafe.tiposoggetto.TipoSoggetto)
	 */
	public TipoSoggetto update(final TipoSoggetto tipoSoggetto){
		entityManager.persist(tipoSoggetto);
		return tipoSoggetto;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.tiposoggetto.ITipoSoggettoBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public TipoSoggetto findByPrimaryKey(final Long pk) throws FinderException {
		if(pk == null){
			throw new FinderException("PrimaryKey is null");
		}
		final TipoSoggetto tipoSoggetto = entityManager.find(TipoSoggettoBean.class, pk);
		if(tipoSoggetto==null){
			throw new FinderException("Record Not Found For PrimaryKey "+ pk);
		}
		return tipoSoggetto;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.tiposoggetto.ITipoSoggettoBeanManager#findByName(java.lang.String)
	 */
	public TipoSoggetto findByName(final String description)throws FinderException {
		try{
			final Query findByName = entityManager.createNamedQuery("it.sella.anagrafe.persistence.tiposoggetto.findByName");
			findByName.setParameter("description", description);
			return (TipoSoggetto) findByName.getSingleResult();
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}

}
