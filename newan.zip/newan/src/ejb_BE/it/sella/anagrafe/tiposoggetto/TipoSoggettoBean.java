package it.sella.anagrafe.tiposoggetto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="AN_MA_TIPO_SOGGETTO")
@SequenceGenerator(name = "tiposoggettoNewSequenceGenerator", sequenceName="SEQ_TipoSoggettoHome", allocationSize = 1)
@NamedQuery(name="it.sella.anagrafe.persistence.tiposoggetto.findByName",query="SELECT o FROM TipoSoggettoBean o WHERE o.description= :description AND o.parentId IS NOT NULL")
public class TipoSoggettoBean implements TipoSoggetto {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="TS_TIPOSOGGETTO_ID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="tiposoggettoNewSequenceGenerator")
	private Long id;
	
	@Column(name="TS_DESC")
	private String description;
	
	@Column(name="TS_ALTRI_DESC")
	private String altriDesc;
	
	@Column(name="TS_PARENT_ID")
	private Long parentId;
	
	@Column(name="TS_TIPO_COLLEGAMENTO_SOGGETTO")
	private String collegamento;
	
	@Column(name="TS_TIPO_DATI_ANAGRAFICI")
	private Long datiAnagrafici;
	

	public Long getId() {
		return id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public String getDesc() {
		return description;
	}

	public void setDesc(final String description) {
		this.description = description;
	}

	public String getAltriDesc() {
		return altriDesc;
	}

	public void setAltriDesc(final String altriDesc) {
		this.altriDesc = altriDesc;
	}

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(final Long parentId) {
		this.parentId = parentId;
	}

	public String getCollegamento() {
		return collegamento;
	}

	public void setCollegamento(final String collegamento) {
		this.collegamento = collegamento;
	}

	public Long getDatiAnagrafici() {
		return datiAnagrafici;
	}

	public void setDatiAnagrafici(final Long datiAnagrafici) {
		this.datiAnagrafici = datiAnagrafici;
	}
}
