package it.sella.anagrafe.codicisoggetto;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;

import java.util.Collection;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

/**
 * Manager Class to handle CodiciSoggetto
 *
 */
public class CodiciSoggettoBeanManager implements ICodiciSoggettoBeanManager {

	private final EntityManager entityManager;

	public CodiciSoggettoBeanManager(){
		entityManager = AnagrafeEntityManagerFactory.getInstance().getEntityManager();
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.codicisoggetto.ICodiciSoggettoBeanManager#create(it.sella.anagrafe.codicisoggetto.CodiciSoggetto)
	 */
	public CodiciSoggetto create(final CodiciSoggetto codiciSoggetto) throws GestoreAnagrafeException {
		final CodiciSoggetto codiciSoggettoBean = new CodiciSoggettoBean();
		BeanUtil.copyProperties(codiciSoggettoBean, codiciSoggetto);
		entityManager.persist(codiciSoggettoBean);
		entityManager.flush();
		BeanUtil.copyProperties(codiciSoggetto, codiciSoggettoBean);
		return codiciSoggetto;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.codicisoggetto.ICodiciSoggettoBeanManager#update(it.sella.anagrafe.codicisoggetto.CodiciSoggetto)
	 */
	public CodiciSoggetto update(final CodiciSoggetto codiciSoggetto) {
		entityManager.persist(codiciSoggetto);
		return codiciSoggetto;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.codicisoggetto.ICodiciSoggettoBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public CodiciSoggetto findByPrimaryKey(final Long primaryKey) throws FinderException {
		if(primaryKey == null){
			throw new FinderException("PrimaryKey is null");
		}
		final CodiciSoggetto codiciSoggetto = entityManager.find(CodiciSoggettoBean.class, primaryKey);
		if(codiciSoggetto==null){
			throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return codiciSoggetto;
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.codicisoggetto.ICodiciSoggettoBeanManager#findBySoggettoId(java.lang.Long)
	 */
	public Collection<CodiciSoggetto> findBySoggettoId(final Long soggettoId) throws FinderException {
		try{
			final Query findBySoggettoId = entityManager.createNamedQuery("it.sella.anagrafe.persistence.codicisoggetto.findBySoggettoId");
			findBySoggettoId.setParameter("soggettoId", soggettoId);
			@SuppressWarnings("unchecked")
			final
			Collection<CodiciSoggetto> codiciSoggettoList = findBySoggettoId.getResultList();

			return codiciSoggettoList;
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.codicisoggetto.ICodiciSoggettoBeanManager#findByNDGNonOperativa(java.lang.String, java.lang.Long)
	 */
	public CodiciSoggetto findByNDGNonOperativa(final String ndg, final Long rightPK) throws FinderException {
		try{
			final Query findBySoggettoId = entityManager.createNamedQuery("it.sella.anagrafe.persistence.codicisoggetto.findByNDGNonOperativa");
			findBySoggettoId.setParameter("value", ndg);
			findBySoggettoId.setParameter("rightPk", rightPK);
			final CodiciSoggetto codiciSoggetto = (CodiciSoggetto) findBySoggettoId.getSingleResult();

			if(codiciSoggetto==null) {
				throw new FinderException("getSingleResult() did not retrieve any entities");
			}

			return codiciSoggetto;
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.codicisoggetto.ICodiciSoggettoBeanManager#findByCodiceDipendente(java.lang.String, java.lang.Long)
	 */
	public CodiciSoggetto findByCodiceDipendente(final String codice, final Long rightPK) throws FinderException {
		try{
			final Query findBySoggettoId = entityManager.createNamedQuery("it.sella.anagrafe.persistence.codicisoggetto.findByCodiceDipendente");
			findBySoggettoId.setParameter("value", codice);
			findBySoggettoId.setParameter("rightPk", rightPK);
			final CodiciSoggetto codiciSoggetto = (CodiciSoggetto) findBySoggettoId.getSingleResult();

			if(codiciSoggetto==null) {
				throw new FinderException("getSingleResult() did not retrieve any entities");
			}

			return codiciSoggetto;
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.codicisoggetto.ICodiciSoggettoBeanManager#findByCodicePromotore(java.lang.String, java.lang.Long)
	 */
	public CodiciSoggetto findByCodicePromotore(final String codice, final Long rightPK) throws FinderException {

		try{
			final Query findBySoggettoId = entityManager.createNamedQuery("it.sella.anagrafe.persistence.codicisoggetto.findByNDGNonOperativa");
			findBySoggettoId.setParameter("value", codice);
			findBySoggettoId.setParameter("rightPk", rightPK);
			final CodiciSoggetto codiciSoggetto = (CodiciSoggetto) findBySoggettoId.getSingleResult();

			if(codiciSoggetto==null) {
				throw new FinderException("getSingleResult() did not retrieve any entities");
			}

			return codiciSoggetto;
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.codicisoggetto.ICodiciSoggettoBeanManager#findBySoggettoIdAndRightPK(java.lang.Long, java.lang.Long)
	 */
	public CodiciSoggetto findBySoggettoIdAndRightPK(final Long soggettoId,
			final Long rightPk) throws FinderException {
		try{
			final Query findBySoggettoId = entityManager.createNamedQuery("it.sella.anagrafe.persistence.codicisoggetto.findBySoggettoIdAndRightPK");
			findBySoggettoId.setParameter("soggettoId", soggettoId);
			findBySoggettoId.setParameter("rightPk", rightPk);
			final CodiciSoggetto codiciSoggetto = (CodiciSoggetto) findBySoggettoId.getSingleResult();

			if(codiciSoggetto==null) {
				throw new FinderException("getSingleResult() did not retrieve any entities");
			}

			return codiciSoggetto;
		}catch(final NoResultException e){
			throw new FinderException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see it.sella.anagrafe.codicisoggetto.ICodiciSoggettoBeanManager#remove(it.sella.anagrafe.codicisoggetto.CodiciSoggetto)
	 */
	public void remove(final CodiciSoggetto codiciSoggetto){
		entityManager.remove(codiciSoggetto);
	}

}
