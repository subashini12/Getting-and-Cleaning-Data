package it.sella.anagrafe.codicisoggetto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="AN_TR_CODICISOGGETTO")
@SequenceGenerator(name = "codicisoggettoNewSequenceGenerator", sequenceName="SEQ_CodiciSoggettoHome", allocationSize = 1)
@NamedQueries({
	@NamedQuery(name="it.sella.anagrafe.persistence.codicisoggetto.findBySoggettoId",query="SELECT o FROM CodiciSoggettoBean o WHERE o.soggettoId= :soggettoId"),
	@NamedQuery(name="it.sella.anagrafe.persistence.codicisoggetto.findByNDGNonOperativa",query="SELECT o FROM CodiciSoggettoBean o WHERE o.value LIKE :value AND o.rightPk= :rightPk"),
	@NamedQuery(name="it.sella.anagrafe.persistence.codicisoggetto.findByCodiceDipendente",query="SELECT o FROM CodiciSoggettoBean o WHERE o.value LIKE :value AND o.rightPk= :rightPk"),
	@NamedQuery(name="it.sella.anagrafe.persistence.codicisoggetto.findByCodicePromotore",query="SELECT o FROM CodiciSoggettoBean o WHERE o.value LIKE :value AND o.rightPk= :rightPk"),
	@NamedQuery(name="it.sella.anagrafe.persistence.codicisoggetto.findBySoggettoIdAndRightPK",query="SELECT o FROM CodiciSoggettoBean o WHERE o.soggettoId= :soggettoId AND o.rightPk= :rightPk")
})
public class CodiciSoggettoBean implements CodiciSoggetto {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="codicisoggettoNewSequenceGenerator")
	@Column(name="CS_CODICIFISCALI_ID")
	private Long id;
	
	@Column(name="CS_SOGGETTO_ID")
	private Long soggettoId;
	
	@Column(name="CS_RIGHT_PK")
	private Long rightPk;
	
	@Column(name="CS_VALUE")
	private String value;
	
	@Column(name="CS_OP_ID")
	private Long opId;
	
	
	public Long getId() {
		return id;
	}
	public void setId(final Long id) {
		this.id = id;
	}
	public Long getSoggettoId() {
		return soggettoId;
	}
	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}
	public Long getRightPk() {
		return rightPk;
	}
	public void setRightPk(final Long rightPk) {
		this.rightPk = rightPk;
	}
	public String getValue() {
		return value;
	}
	public void setValue(final String value) {
		this.value = value;
	}
	public Long getOpId() {
		return opId;
	}
	public void setOpId(final Long opId) {
		this.opId = opId;
	}
}
