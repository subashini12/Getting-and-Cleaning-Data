package it.sella.anagrafe;

import it.sella.anagrafe.view.SoggettoView;

import java.util.Collection;

public interface AltriSoggettoView extends SoggettoView {

    DatiAnagraficiAltriTipiView getDatiAnagraficiView();
    void setDatiAnagraficiView(DatiAnagraficiAltriTipiView datiAnagraficiAltriTipiView);
    Collection getRecapitiAltriTipiView();
    void setRecapitiAltriTipiView(Collection recapitiAltriTipiView);
    CodiceSoggettoAltriTipiView getCodiceSoggettoAltriTipiView();
    void setCodiceSoggettoAltriTipiView(CodiceSoggettoAltriTipiView codiceSoggettoAltriTipiView);
    Collection getIndirizziView();
    void setIndirizziView(Collection indirizziView);
    //the description has to be passed (eg : "Succursale" or "Banca proprietaria del sistema") from an_ma_tipo_soggetto table
    void setTipoSoggetto(String tipoSoggetto);
    String getTipoSoggetto();
    void setAttributiEsterniView(AttributiEsterniATSView attributiEsterniATSView) ;
    AttributiEsterniATSView getAttributiEsterniView() ;
}
