package it.sella.anagrafe;

public class BeanHelperException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BeanHelperException() {
    }

    public BeanHelperException(final String errorMessage) {
        super(errorMessage);
    }
}
