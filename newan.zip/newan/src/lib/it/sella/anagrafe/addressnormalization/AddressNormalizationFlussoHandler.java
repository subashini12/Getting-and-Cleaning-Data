package it.sella.anagrafe.addressnormalization;

import it.sella.anagrafe.util.AddressNormalizationHelper;
import it.sella.gestione_flussi.ElementoFlusso;
import it.sella.gestione_flussi.FlussoHandler;
import it.sella.gestione_flussi.GestioneElementoFlussoException;
import it.sella.gestione_flussi.GestioneFlussoException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;

public class AddressNormalizationFlussoHandler extends FlussoHandler {
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(
    		AddressNormalizationFlussoHandler.class);

	public void gestisciElementoFlusso( final ElementoFlusso elementOfFlusso ) 
		throws GestioneFlussoException, RemoteException {
		try {
			String  addressOpId = null;
			if ( elementOfFlusso != null ) {
				addressOpId = (String) elementOfFlusso.getRealElementoFlusso() ;
			}
			if ( addressOpId != null ) {
				final String addressOpIdArray[] = addressOpId.split("\\$");
				AddressNormalizationHelper.updateNormalizedAddress(Long.valueOf(addressOpIdArray[0]) ,Long.valueOf(addressOpIdArray[1]));
			}
		} catch (final Exception e) {
			log4Debug.severeStackTrace(e);
			throw new GestioneElementoFlussoException(e.getMessage(), e);
		} 
	}
}