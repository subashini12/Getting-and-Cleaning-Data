package it.sella.anagrafe.addressnormalization;

import it.sella.gestorefasi.IFase;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

public class AddressNormalizationFlussoFase implements IFase {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Log4Debug log4Debug  = Log4DebugFactory.getLog4Debug(
			AddressNormalizationFlussoFase.class);

	public void execute() {
		// dummy implementation provide for testing fase call
		log4Debug.severe("AddressNormalizationFlussoFase invoked !!!!!!!!! >>>>");
	}
}
