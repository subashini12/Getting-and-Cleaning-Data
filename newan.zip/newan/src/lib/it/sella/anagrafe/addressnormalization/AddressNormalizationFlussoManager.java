package it.sella.anagrafe.addressnormalization;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.util.AddressNormalizationHelper;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.DateHandler;
import it.sella.gestione_flussi.FlussoDescriptor;
import it.sella.gestione_flussi.GestioneFlussiManagerFactory;
import it.sella.gestione_flussi.GestioneFlussoException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.List;

public class AddressNormalizationFlussoManager {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(
    		AddressNormalizationFlussoManager.class);

    public void createFlussi() throws RemoteException, GestoreAnagrafeException {
    	try {
    		log4Debug.debug(" AddressNormalizationFlussoManager : createFlussi : Entered ");
			final List allAddressOpId = AddressNormalizationHelper.getAllNormalizationAddressId();
        	if ( !allAddressOpId.isEmpty() ) {
            	final StringBuffer nomeFlusso = new StringBuffer("ADDRESSNORMALIZATION:COLLECTION(");
            	final DateHandler dateHandler = new DateHandler();
            	nomeFlusso .append(dateHandler.formatDate(dateHandler.getCurrentDateInTimeStampFormat(), 
            			"ddMMyyyy:hhmmss"));
            	final String addressNormalizationFlussiName = CommonPropertiesHandler.getValueFromProperty(
            			"ADDRESSNORMALIZATIONFLUSSINAME");
            	log4Debug.debug("addressNormalizationFlussiName ===>>> " , addressNormalizationFlussiName );
                final FlussoDescriptor descriptor = new FlussoDescriptor(nomeFlusso.toString(), 
                		addressNormalizationFlussiName, allAddressOpId , new AddressNormalizationFlussoHandler());
                GestioneFlussiManagerFactory.getInstance().getGestioneFlussiManager().gestisciFlusso(descriptor);
    			AddressNormalizationHelper.setAddressNormalizationStatus("IP");
        	}
    	} catch (final GestioneFlussoException e) {
			log4Debug.warnStackTrace(e);
		} 
    }
}
