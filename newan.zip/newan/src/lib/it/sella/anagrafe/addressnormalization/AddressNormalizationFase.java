package it.sella.anagrafe.addressnormalization;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.gestorefasi.IFase;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;

public class AddressNormalizationFase implements IFase {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressNormalizationFase.class);

	public void execute() {
		try {
			log4Debug.debug(" Called .....AddressNormalizationFase.execute()");
			new AddressNormalizationFlussoManager().createFlussi();
		} catch (final RemoteException e) {
			log4Debug.severeStackTrace(e);
		} catch (final GestoreAnagrafeException e) {
			log4Debug.severeStackTrace(e);
		}

	}
}
