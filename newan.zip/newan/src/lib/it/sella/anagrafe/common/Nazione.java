package it.sella.anagrafe.common;

import it.sella.classificazione.ClassificazioneView;

import java.io.Serializable;

public class Nazione implements Serializable {

    /**
	 *
	 */
	private static final long serialVersionUID = 1L;
	public ClassificazioneView getMembroUE() {
        return membroUE;
    }

    public void setMembroUE(final ClassificazioneView membroUE) {
        this.membroUE = membroUE;
    }

    public ClassificazioneView getAppartenenteBlackList() {
        return appartenenteBlackList;
    }

    public void setAppartenenteBlackList(final ClassificazioneView appartenenteBlackList) {
        this.appartenenteBlackList = appartenenteBlackList;
    }

    public String getCncf() {
        return cncf;
    }

    public void setCncf(final String cncf) {
        this.cncf = cncf;
    }

    public Long getNazioneId() {
        return nazioneId;
    }

    public void setNazioneId(final Long nazioneId) {
        this.nazioneId = nazioneId;
    }

    public ClassificazioneView getZonaBilanciEGrandiRischi() {
        return zonaBilanciEGrandiRischi;
    }

    public void setZonaBilanciEGrandiRischi(final ClassificazioneView zonaBilanciEGrandiRischi) {
        this.zonaBilanciEGrandiRischi = zonaBilanciEGrandiRischi;

    }

    public ClassificazioneView getMembroUME() {
        return membroUME;
    }

    public void setMembroUME(final ClassificazioneView membroUME) {
        this.membroUME = membroUME;
    }

    public String getNazionalita() {
        return nazionalita;
    }

    public void setNazionalita(final String nazionalita) {
        this.nazionalita = nazionalita;
    }

    public ClassificazioneView getLinguaParlata() {
        return linguaParlata;
    }

    public void setLinguaParlata(final ClassificazioneView linguaParlata) {
        this.linguaParlata = linguaParlata;
    }

    public ClassificazioneView getAderenteTarget() {
        return aderenteTarget;
    }

    public void setAderenteTarget(final ClassificazioneView aderenteTarget) {
        this.aderenteTarget = aderenteTarget;
    }

    public ClassificazioneView getValutario() {
        return valutario;
    }

    public void setValutario(final ClassificazioneView valutario) {
        this.valutario = valutario;
    }

    public ClassificazioneView getZcr() {
        return zcr;
    }

    public void setZcr(final ClassificazioneView zcr) {
        this.zcr = zcr;
    }

    public ClassificazioneView getAreaGeografica() {
        return areaGeografica;
    }

    public void setAreaGeografica(final ClassificazioneView areaGeografica) {
        this.areaGeografica = areaGeografica;
    }

    public String getCodiceISO() {
        return codiceISO;
    }

    public void setCodiceISO(final String codiceISO) {
        this.codiceISO = codiceISO;
    }

    public String getCodiceProvincia() {
        return codiceProvincia;
    }

    public void setCodiceProvincia(final String codiceProvincia) {
        this.codiceProvincia = codiceProvincia;
    }

    public String getSiglaInternazionale() {
        return siglaInternazionale;
    }

    public void setSiglaInternazionale(final String siglaInternazionale) {
        this.siglaInternazionale = siglaInternazionale;
    }

    public String getCodiceDivisa() {
        return codiceDivisa;
    }

    public void setCodiceDivisa(final String codiceDivisa) {
        this.codiceDivisa = codiceDivisa;
    }

    public String getCodiceUIC() {
        return codiceUIC;
    }

    public void setCodiceUIC(final String codiceUIC) {
        this.codiceUIC = codiceUIC;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(final String nome) {
        this.nome = nome;
    }

    public ClassificazioneView getStorico() {
        return storico;
    }

    public void setStorico(final ClassificazioneView storico) {
        this.storico = storico;
    }

    public ClassificazioneView getContinente() {
        return continente;
    }

    public void setContinente(final ClassificazioneView continente) {
        this.continente = continente;
    }

    public String getAltradenominazione() {
        return altradenominazione;
    }

    public void setAltradenominazione(final String altradenominazione) {
        this.altradenominazione = altradenominazione;
    }

    public String getDocAggiuntivi() {
        return docAggiuntivi;
    }

    public void setDocAggiuntivi(final String docAggiuntivi) {
        this.docAggiuntivi = docAggiuntivi;
    }

    public int hashCode() {
		return super.hashCode();
	}

    public boolean equals(final Object obj) {
        if(obj instanceof Nazione) {
        	final Nazione nazione = (Nazione)obj;
        	if(!checkEquality(nazione.getNome(),this.nome)){
        		return false;
        	}
        	return true;
        } else {
        	return false;
        }
    }

    private boolean checkEquality(final String newValue, final String thisValue) {
        if(newValue != null && thisValue != null) {
            if(!newValue.equals(thisValue)) {
				return false;
			}
        } else if(newValue != null || thisValue != null) {
			return false;
		}
        return true;
    }

	public Long getAppartenenteBlackListFisicale() {
		return appartenenteBlackListFisicale;
	}

	public void setAppartenenteBlackListFisicale(final Long appartenenteBlackListFisicale) {
		this.appartenenteBlackListFisicale = appartenenteBlackListFisicale;
	}

	public Long getAppartenenteWhiteListFisicale() {
		return appartenenteWhiteListFisicale;
	}

	public void setAppartenenteWhiteListFisicale(final Long appartenenteWhiteListFisicale) {
		this.appartenenteWhiteListFisicale = appartenenteWhiteListFisicale;
	}
	
	public String getPrefissoCode() {
		return prefissoCode;
	}

	public void setPrefissoCode(final String prefissoCode) {
		this.prefissoCode = prefissoCode;
	}

	public String getAccordoFatca() {
		return accordoFatca;
	}

	public void setAccordoFatca(final String accordoFatca) {
		this.accordoFatca = accordoFatca;
	}

	public String getCodiceIsoTre() {
		return codiceIsoTre;
	}

	public void setCodiceIsoTre(String codiceIsoTre) {
		this.codiceIsoTre = codiceIsoTre;
	}
	
	public String getTinCode() {
		return tinCode;
	}

	public void setTinCode(String tinCode) {
		this.tinCode = tinCode;
	}

	private ClassificazioneView membroUE;
    private ClassificazioneView appartenenteBlackList;
    private String cncf;
    private Long nazioneId;
    private ClassificazioneView zonaBilanciEGrandiRischi;
    private ClassificazioneView membroUME;
    private String nazionalita;
    private ClassificazioneView linguaParlata;
    private ClassificazioneView aderenteTarget;
    private ClassificazioneView valutario;
    private ClassificazioneView zcr;
    private ClassificazioneView areaGeografica;
    private String codiceISO;
    private String codiceProvincia;
    private String siglaInternazionale;
    private String codiceDivisa;
    private String codiceUIC;
    private String nome;
    private String altradenominazione;
    private ClassificazioneView continente;
    private ClassificazioneView storico;
    private String docAggiuntivi;
    //Added for issue BFWKAAE-376
	private Long appartenenteBlackListFisicale;
	private Long appartenenteWhiteListFisicale;
	private String prefissoCode;
	private String accordoFatca; // FATCA Calculation Usage
	//private String codiceISOTRE;
	private String codiceIsoTre;
	private String tinCode;
}


