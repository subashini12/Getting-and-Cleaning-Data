package it.sella.anagrafe.common;

import it.sella.anagrafe.ISoggettiResidenteFiscaleView;

import java.io.Serializable;

/**
 * SoggettiResidenteFiscaleView to gather data from DataBase
 * And serve through the API
 */
public class SoggettiResidenteFiscaleView implements ISoggettiResidenteFiscaleView, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long	soggettoId;
	private String	residenteItalia;
	private String	residenteItaliaNome;
	private String	residenteItaliaCodieFiscale;
	private String	residenteItalia2;
	private String	residenteItaliaNome2;
	private String	residenteItaliaCodieEstero2;
	private String	residenteItalia3;
	private String	residenteItaliaNome3;
	private String	residenteItaliaCodieEstero3;
	
	public Long getSoggettoId() {
		return soggettoId;
	}
	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}
	public String getResidenteItalia() {
		return residenteItalia;
	}
	public void setResidenteItalia(final String residenteItalia) {
		this.residenteItalia = residenteItalia;
	}
	public String getResidenteItaliaNome() {
		return residenteItaliaNome;
	}
	public void setResidenteItaliaNome(final String residenteItaliaNome) {
		this.residenteItaliaNome = residenteItaliaNome;
	}
	public String getResidenteItaliaCodieFiscale() {
		return residenteItaliaCodieFiscale;
	}
	public void setResidenteItaliaCodieFiscale(final String residenteItaliaCodieFiscale) {
		this.residenteItaliaCodieFiscale = residenteItaliaCodieFiscale;
	}
	public String getResidenteItalia2() {
		return residenteItalia2;
	}
	public void setResidenteItalia2(final String residenteItalia2) {
		this.residenteItalia2 = residenteItalia2;
	}
	public String getResidenteItaliaNome2() {
		return residenteItaliaNome2;
	}
	public void setResidenteItaliaNome2(final String residenteItaliaNome2) {
		this.residenteItaliaNome2 = residenteItaliaNome2;
	}
	public String getResidenteItaliaCodieEstero2() {
		return residenteItaliaCodieEstero2;
	}
	public void setResidenteItaliaCodieEstero2(final String residenteItaliaCodieEstero2) {
		this.residenteItaliaCodieEstero2 = residenteItaliaCodieEstero2;
	}
	public String getResidenteItalia3() {
		return residenteItalia3;
	}
	public void setResidenteItalia3(final String residenteItalia3) {
		this.residenteItalia3 = residenteItalia3;
	}
	public String getResidenteItaliaNome3() {
		return residenteItaliaNome3;
	}
	public void setResidenteItaliaNome3(final String residenteItaliaNome3) {
		this.residenteItaliaNome3 = residenteItaliaNome3;
	}
	public String getResidenteItaliaCodieEstero3() {
		return residenteItaliaCodieEstero3;
	}
	public void setResidenteItaliaCodieEstero3(final String residenteItaliaCodieEstero3) {
		this.residenteItaliaCodieEstero3 = residenteItaliaCodieEstero3;
	}

}
