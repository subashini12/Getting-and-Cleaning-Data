package it.sella.anagrafe.common;

import it.sella.anagrafe.ICapView;

import java.io.Serializable;

public class CAP implements Serializable, ICapView {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String getNote() {

        return note;

    }


    public void setNote(final String note) {

        this.note = note;

    }


    public String getProvincia() {

        return provincia;

    }


    public void setProvincia(final String provincia) {

        this.provincia = provincia;

    }


    public String getLocalita() {

        return localita;

    }


    public void setLocalita(final String localita) {

        this.localita = localita;

    }


    public String getCap() {

        return cap;

    }


    public void setCap(final String cap) {

        this.cap = cap;

    }


    public Long getCapId() {

        return capId;

    }


    public void setCapId(final Long capId) {

        this.capId = capId;

    }

    public boolean isLocalitaACitta() {
        return isLocalitaACitta;
    }

    public void setLocalitaACitta(final boolean localitaACitta) {
        isLocalitaACitta = localitaACitta;
    }

    private boolean isLocalitaACitta;

    private String note;

    private String provincia;

    private String localita;

    private String cap;

    private Long capId;

}


