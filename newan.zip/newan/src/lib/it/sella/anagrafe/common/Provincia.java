package it.sella.anagrafe.common;

import it.sella.anagrafe.IProvinciaView;

public class Provincia implements IProvinciaView {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Long getProvinciaId() {
        return provinciaId;
    }

    public void setProvinciaId(final Long provinciaId) {
        this.provinciaId = provinciaId;
    }

    public String getCodiceCab() {
        return codiceCab;
    }

    public void setCodiceCab(final String codiceCab) {
        this.codiceCab = codiceCab;
    }

    public String getCodicePuma2() {
        return codicePuma2;
    }

    public void setCodicePuma2(final String codicePuma2) {
        this.codicePuma2 = codicePuma2;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(final String nome) {
        this.nome = nome;
    }

    public String getCodiceArea() {
        return codiceArea;
    }

    public void setCodiceArea(final String codiceArea) {
        this.codiceArea = codiceArea;
    }

    public String getSigla() {
        return sigla;
    }

    public void setSigla(final String sigla) {
        this.sigla = sigla;
    }
    
    public int hashCode() {
		return super.hashCode();
	}
    
    public boolean equals(final Object obj) {
        if(obj instanceof Provincia) {
        	final Provincia provincia = (Provincia)obj;
        	if(!checkEquality(provincia.getSigla(),this.sigla)){
        		return false; 
        	}
        	return true;
        } else {
        	return false;
        }
    }
    
    private boolean checkEquality(final String newValue, final String thisValue) {
        if(newValue != null && thisValue != null) {
            if(!newValue.equals(thisValue)) {
				return false;
			}
        } else if(newValue != null || thisValue != null) {
			return false;
		}
        return true;
    }

    private Long provinciaId;
    private String codiceCab;
    private String codicePuma2;
    private String nome;
    private String codiceArea;
    private String sigla;
}


