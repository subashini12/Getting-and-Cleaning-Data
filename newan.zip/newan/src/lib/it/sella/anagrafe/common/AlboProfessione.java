package it.sella.anagrafe.common;

import it.sella.anagrafe.IAPView;

import java.io.Serializable;

public class AlboProfessione implements Serializable, IAPView {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long alboId;
	private String alboCode;
	private String alboDesc;
	
	public Long getAlboId() {
		return alboId;
	}
	public void setAlboId(final Long alboId) {
		this.alboId = alboId;
	}
	public String getAlboCode() {
		return alboCode;
	}
	public void setAlboCode(final String alboCode) {
		this.alboCode = alboCode;
	}
	public String getAlboDesc() {
		return alboDesc;
	}
	public void setAlboDesc(final String alboDesc) {
		this.alboDesc = alboDesc;
	}

	

}
