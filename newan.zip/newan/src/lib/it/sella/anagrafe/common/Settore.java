package it.sella.anagrafe.common;


import it.sella.anagrafe.ISettoreView;
import it.sella.anagrafe.util.StringHandler;

import java.io.Serializable;

public class Settore implements Serializable , ISettoreView {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Long getSettoreId() {
        return settoreId;
    }

    public void setSettoreId(final Long settoreId) {
        this.settoreId = settoreId;
    }

    public String getCodiceSettore() {
        return codiceSettore;
    }

    public void setCodiceSettore(final String codiceSettore) {
        this.codiceSettore = codiceSettore;
    }

    public String getCodiceSottoSettore() {
        return codiceSottoSettore;
    }

    public void setCodiceSottoSettore(final String codiceSottoSettore) {
        this.codiceSottoSettore = codiceSottoSettore;
    }

    public String getCodiceSottoGruppo() {
        return codiceSottoGruppo;
    }

    public void setCodiceSottoGruppo(final String codiceSottoGruppo) {
        this.codiceSottoGruppo = codiceSottoGruppo;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(final String descrizione) {
        this.descrizione = descrizione;
    }

    public String getTipoControParte() {
        return tipoControParte;
    }

    public void setTipoControParte(final String tipoControParte) {
        this.tipoControParte = tipoControParte;
    }

    public String getRamoRichiesto() {
        return ramoRichiesto;
    }

    public void setRamoRichiesto(final String ramoRichiesto) {
        this.ramoRichiesto = ramoRichiesto;
    }

    public String getNonResidente() {
        return nonResidente;
    }

    public void setNonResidente(final String nonResidente) {
        this.nonResidente = nonResidente;
    }

    public String getAntiriCiclaggioEscluso() {
        return antiriCiclaggioEscluso;
    }

    public void setAntiriCiclaggioEscluso(final String antiriCiclaggioEscluso) {
        this.antiriCiclaggioEscluso = antiriCiclaggioEscluso;
    }
	
    public String getUe() {
		return ue;
	}

	public void setUe(final String ue) {
		this.ue = ue;
	}

	public String getUm() {
		return um;
	}

	public void setUm(final String um) {
		this.um = um;
	}

    public String getClasATECO2007() {
		return clasATECO2007;
	}

	public void setClasATECO2007(final String clasATECO2007) {
		this.clasATECO2007 = clasATECO2007;
	}
	
	

	public String getSettoreFinancial() {
		return settoreFinancial;
	}

	public void setSettoreFinancial(final String settoreFinancial) {
		this.settoreFinancial = settoreFinancial;
	}	

	public Long getStorico() {
		return storico;
	}

	public void setStorico(final Long storico) {
		this.storico = storico;
	}

	public String getAllegato() {
		return allegato;
	}

	public void setAllegato(final String allegato) {
		this.allegato = allegato;
	}

	public boolean equals(final Object object) {
    	Settore settoreView = null;
    	if (object != null && object instanceof Settore) {
    		settoreView = (Settore)object;
			final StringHandler stringHandler = new StringHandler();
			if(!stringHandler.checkForEquality(settoreView.getCodiceSettore(),this.codiceSettore)) {
				return false;
			}
			if(!stringHandler.checkForEquality(settoreView.getCodiceSottoSettore(),this.codiceSottoSettore)) {
				return false;
			}
			if(!stringHandler.checkForEquality(settoreView.getCodiceSottoGruppo(),this.codiceSottoGruppo)) {
				return false;
			}
			if(!stringHandler.checkForEquality(settoreView.getDescrizione(),this.descrizione)) {
				return false;
			}
			if(!stringHandler.checkForEquality(settoreView.getTipoControParte(),this.tipoControParte)) {
				return false;
			}
			if(!stringHandler.checkForEquality(settoreView.getRamoRichiesto(),this.ramoRichiesto)) {
				return false;
			}
			if(!stringHandler.checkForEquality(settoreView.getNonResidente(),this.nonResidente)) {
				return false;
			}
			if(!stringHandler.checkForEquality(settoreView.getAntiriCiclaggioEscluso(),this.antiriCiclaggioEscluso)) {
				return false;
			}
			if(!stringHandler.checkForEquality(settoreView.getUe(),this.ue)) {
				return false;
			}
			if(!stringHandler.checkForEquality(settoreView.getUm(),this.um)) {
				return false;
			}
			if(!stringHandler.checkForEquality(settoreView.getClasATECO2007(),this.clasATECO2007)) {
				return false;
			}
			if(!stringHandler.checkForEquality(settoreView.getSettoreFinancial(),this.settoreFinancial)) {
				return false;
			}
			if(!stringHandler.checkForEquality(settoreView.getStorico(),this.storico)) {
				return false;
			}
			if(!stringHandler.checkForEquality(settoreView.getAllegato(),this.allegato)) {
				return false;
			}
			return true;
		} else {
			return false;
		}
    }
    
    public int hashCode() {
		return super.hashCode();
	}
	
    private Long settoreId;
    private String codiceSettore;
    private String codiceSottoSettore;
    private String codiceSottoGruppo;
    private String descrizione;
    private String tipoControParte;
    private String ramoRichiesto;
    private String nonResidente;
    private String antiriCiclaggioEscluso;
    private String ue;
    private String um;
    private String clasATECO2007;
    private String settoreFinancial;
    private Long storico;
    private String allegato;
	
}
