/**
 * Created by IntelliJ IDEA.
 * User: ssil72
 * Date: Jan 9, 2003
 * Time: 2:49:57 PM
 * To change this template use Options | File Templates.
 */
package it.sella.anagrafe.common;

import java.io.Serializable;

public class Attivita implements Serializable
{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String getCodiceISTAT() {
        return codiceISTAT;
    }

    public void setCodiceISTAT(final String codiceISTAT) {
        this.codiceISTAT = codiceISTAT;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(final String descrizione) {
        this.descrizione = descrizione;
    }

    String codiceISTAT ;
    String descrizione;

}
