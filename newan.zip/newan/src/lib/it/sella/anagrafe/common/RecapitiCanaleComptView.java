package it.sella.anagrafe.common;

import it.sella.classificazione.ClassificazioneView;

import java.io.Serializable;

public class RecapitiCanaleComptView implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private ClassificazioneView canale;
	private ClassificazioneView recapiti;
	
	public ClassificazioneView getCanale() {
		return canale;
	}
	
	public void setCanale(final ClassificazioneView canale) {
		this.canale = canale;
	}
	
	public ClassificazioneView getRecapiti() {
		return recapiti;
	}
	
	public void setRecapiti(final ClassificazioneView recapiti) {
		this.recapiti = recapiti;
	}
}
