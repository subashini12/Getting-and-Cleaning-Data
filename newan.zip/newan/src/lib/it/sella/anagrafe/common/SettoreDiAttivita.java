package it.sella.anagrafe.common;

import it.sella.anagrafe.ISAEView;

import java.io.Serializable;

public class SettoreDiAttivita implements Serializable, ISAEView {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long settoreAttivitaId;
	private String settoreAttivitaDescription;

	public Long getSettoreAttivitaId() {
		return settoreAttivitaId;
	}

	public void setSettoreAttivitaId(Long settoreAttivitaId) {
		this.settoreAttivitaId = settoreAttivitaId;
	}

	public String getSettoreAttivitaDescription() {
		return settoreAttivitaDescription;
	}

	public void setSettoreAttivitaDescription(String settoreAttivitaDescription) {
		this.settoreAttivitaDescription = settoreAttivitaDescription;
	}
}
