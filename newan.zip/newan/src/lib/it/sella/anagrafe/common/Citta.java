package it.sella.anagrafe.common;

import it.sella.classificazione.ClassificazioneView;

import java.io.Serializable;

public class Citta implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Long getCittaId() {
        return cittaId;
    }

    public void setCittaId(final Long cittaId) {
        this.cittaId = cittaId;
    }

    public Provincia getProvincia() {
        return provincia;
    }

    public void setProvincia(final Provincia provincia) {
        this.provincia = provincia;
    }

    public String getCncf() {
        return cncf;
    }

    public void setCncf(final String cncf) {
        this.cncf = cncf;
    }

    public String getCommune() {
        return commune;
    }

    public void setCommune(final String commune) {
        this.commune = commune;
    }

    public String getCab() {
        return cab;
    }

    public void setCab(final String cab) {
        this.cab = cab;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(final String region) {
        this.region = region;
    }

    public ClassificazioneView getCapoluogo() {
    	return capoluogo;
    }

    public void setCapoluogo(final ClassificazioneView capoluogo) {
        this.capoluogo = capoluogo;
    }

    public String getCinCab() {
        return cinCab;
    }

    public void setCinCab(final String cinCab) {
        this.cinCab = cinCab;
    }

    public String getCap() {
        return cap;
    }

    public void setCap(final String cap) {
        this.cap = cap;
    }


    public ClassificazioneView getStorico() {
        return storico;
    }

    public void setStorico(final ClassificazioneView storico) {
        this.storico = storico;
    }


    public String getAltraDenominazione() {
        return altraDenominazione;
    }

    public void setAltraDenominazione(final String altraDenominazione) {
        this.altraDenominazione = altraDenominazione;
    }

    public String getNormalizzato() {
        return normalizzato;
    }

    public void setNormalizzato(final String normalizzato) {
        this.normalizzato = normalizzato;
    }

    public String getCabStorico() {
        return cabStorico;
    }

    public void setCabStorico(final String cabStorico) {
        this.cabStorico = cabStorico;
    }
    
    public boolean equals(final Object obj) {
        if(obj instanceof Citta) {
        	final Citta citta = (Citta)obj;
        	 if(!isEqual(citta.getCommune(),this.commune)){
        		 return false; 
        	 } else if(!isEqual(citta.getProvincia(),this.provincia)) {
        		 return false;
        	 }
             	return true;
        } else {
        	return false;
        }
       
    }
    
    private boolean isEqual(final Object newValue, final Object thisValue) {
        if(newValue != null && thisValue != null) {
            if(!newValue.equals(thisValue)) {
				return false;
			}
        } else if(newValue != null || thisValue != null) {
			return false;
		}
        return true;
    }
    
    public int hashCode() {
		return super.hashCode();
	}
    
    private Long cittaId;
    private Provincia provincia;
    private String cncf;
    private String commune;
    private String cab;
    private String region;
    private ClassificazioneView capoluogo;
    private String cinCab;
    private String cap;
    private ClassificazioneView storico;
    private String altraDenominazione;
    private String normalizzato;
    private String cabStorico;
}
