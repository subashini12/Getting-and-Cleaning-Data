package it.sella.anagrafe.common;

import it.sella.anagrafe.ITAEView;
import it.sella.classificazione.ClassificazioneView;

import java.io.Serializable;

public class TAE implements Serializable, ITAEView {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long taeId;
	private String taeCode;
	private String taeDesc;
	private ClassificazioneView settoreCommerciale;
	
	public Long getTaeId() {
		return taeId;
	}
	public void setTaeId(final Long taeId) {
		this.taeId = taeId;
	}
	public String getTaeCode() {
		return taeCode;
	}
	public void setTaeCode(final String taeCode) {
		this.taeCode = taeCode;
	}
	public String getTaeDesc() {
		return taeDesc;
	}
	public void setTaeDesc(final String taeDesc) {
		this.taeDesc = taeDesc;
	}
	public ClassificazioneView getSettoreCommerciale() {
		return settoreCommerciale;
	}
	public void setSettoreCommerciale(ClassificazioneView settoreCommerciale) {
		this.settoreCommerciale = settoreCommerciale;
	}
	
	
	
	

	
}
