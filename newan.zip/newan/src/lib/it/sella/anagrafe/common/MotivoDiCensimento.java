package it.sella.anagrafe.common;

import java.io.Serializable;

public class MotivoDiCensimento implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MotivoDiCensimento() {
    }

    private String motivoCausale;

    public String getMotivoCausale() {
        return motivoCausale;
    }

    public void setMotivoCausale(final String motivoCausale) {
        this.motivoCausale = motivoCausale;
    }

    @Override
	public int hashCode() {
		return this.motivoCausale.hashCode();
	}

	@Override
	public boolean equals(final Object obj) {
		if(obj == null) {
			return false;
		}
		final MotivoDiCensimento motivoDiCensimento = (MotivoDiCensimento)obj;
		return this.motivoCausale.equals(motivoDiCensimento.getMotivoCausale());
	}
    
    
}