package it.sella.anagrafe.common;

import it.sella.anagrafe.util.StringHandler;

import java.io.Serializable;

public class Ramo implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String getCodiceGruppo() {
        return codiceGruppo;
    }

    public void setCodiceGruppo(final String codiceGruppo) {
        this.codiceGruppo = codiceGruppo;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(final String descrizione) {
        this.descrizione = descrizione;
    }

    public String getCodiceRamo() {
        return codiceRamo;
    }

    public void setCodiceRamo(final String codiceRamo) {
        this.codiceRamo = codiceRamo;
    }

    public Long getRamoId() {
        return ramoId;
    }

    public void setRamoId(final Long ramoId) {
        this.ramoId = ramoId;
    }

	public boolean equals(final Object object) {
    	Ramo ramoView = null;
    	if (object != null && object instanceof Ramo) {
    		ramoView = (Ramo)object;
			final StringHandler stringHandler = new StringHandler();
			if(!stringHandler.checkForEquality(ramoView.getCodiceGruppo(),this.codiceGruppo)) {
				return false;
			}
			if(!stringHandler.checkForEquality(ramoView.getCodiceRamo(),this.codiceRamo)) {
				return false;
			}
			if(!stringHandler.checkForEquality(ramoView.getDescrizione(),this.descrizione)) {
				return false;
			}
			return true;
		} else {
			return false;
		}
    }
    
    public int hashCode() {
		return super.hashCode();
	}
    
    private String codiceGruppo;
    private String descrizione;
    private String codiceRamo;
    private Long ramoId;
    
}
