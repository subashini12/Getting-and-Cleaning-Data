package it.sella.anagrafe;

/**
 * @author gbs03447
 *
 */
public class DAIWeightageView implements IDAIWeightageView {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;
	private String weightCode;
	private String weightCodeDescription;
	private IDAIConfigView daiGroupType;
	private IDAIConfigView daiCode;
	private IDAIConfigView daiwieghtage;
	private boolean valid;


	public Long getId() {
		return id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public String getWeightCode() {
		return weightCode;
	}

	public void setWeightCode(final String weightCode) {
		this.weightCode = weightCode;
	}

	public String getWeightCodeDescription() {
		return weightCodeDescription;
	}

	public void setWeightCodeDescription(final String weightCodeDescription) {
		this.weightCodeDescription = weightCodeDescription;
	}

	public IDAIConfigView getDaiGroupType() {
		return daiGroupType;
	}

	public void setDaiGroupType(final IDAIConfigView daiGroupType) {
		this.daiGroupType = daiGroupType;
	}

	public IDAIConfigView getDaiCode() {
		return daiCode;
	}

	public void setDaiCode(final IDAIConfigView daiCode) {
		this.daiCode = daiCode;
	}

	public IDAIConfigView getDaiwieghtage() {
		return daiwieghtage;
	}

	public void setDaiwieghtage(final IDAIConfigView daiwieghtage) {
		this.daiwieghtage = daiwieghtage;
	}

	public boolean isValid() {
		return valid;
	}

	public void setValid(final boolean valid) {
		this.valid = valid;
	}

}
