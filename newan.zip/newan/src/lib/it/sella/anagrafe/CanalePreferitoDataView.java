package it.sella.anagrafe;

import it.sella.classificazione.ClassificazioneView;

import java.sql.Timestamp;

/**
 * canalePreferito Data Transfer View
 * @author GBS03447
 *
 */
public class CanalePreferitoDataView implements ICanalePreferitoDataView {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private Long soggettoId;
	private ClassificazioneView canale;
	private String canaleValue;
	private Timestamp dataInizio;
	private Timestamp dataFine;
	private String utenteInserimento;
	private String utenteModificato;
	private ClassificazioneView tipoRecapiti;
	private Long canalePreferitoId;
	
	public Long getSoggettoId() {
		return soggettoId;
	}
	
	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}
	
	public ClassificazioneView getCanale() {
		return canale;
	}
	
	public void setCanale(final ClassificazioneView canale) {
		this.canale = canale;
	}
	
	public String getCanaleValue() {
		return canaleValue;
	}
	
	public void setCanaleValue(final String canaleValue) {
		this.canaleValue = canaleValue;
	}
	
	public Timestamp getDataInizio() {
		return dataInizio;
	}
	
	public void setDataInizio(final Timestamp dataInizio) {
		this.dataInizio = dataInizio;
	}
	
	public Timestamp getDataFine() {
		return dataFine;
	}
	
	public void setDataFine(final Timestamp dataFine) {
		this.dataFine = dataFine;
	}
	
	public String getUtenteInserimento() {
		return utenteInserimento;
	}
	
	public void setUtenteInserimento(final String utenteInserimento) {
		this.utenteInserimento = utenteInserimento;
	}
	
	public String getUtenteModificato() {
		return utenteModificato;
	}
	
	public void setUtenteModificato(final String utenteModificato) {
		this.utenteModificato = utenteModificato;
	}

	public ClassificazioneView getTipoRecapiti() {
		return tipoRecapiti;
	}

	public void setTipoRecapiti(final ClassificazioneView tipoRecapiti) {
		this.tipoRecapiti = tipoRecapiti;
	}
	
	public Long getCanalePreferitoId() {
		return canalePreferitoId;
	}

	public void setCanalePreferitoId(final Long canalePreferitoId) {
		this.canalePreferitoId = canalePreferitoId;
	}

	public boolean equals(final Object obj){
		boolean result = false;
		if (obj instanceof CanalePreferitoDataView) {
			final CanalePreferitoDataView view = (CanalePreferitoDataView) obj;
			result = checkEquality(view.getCanaleValue(), this.canaleValue) && checkCanaleEquality(view) && checkTipoRecapitiEquality(view.getTipoRecapiti());
		}
		return result;
	}
	
	public int hashCode() {
		int hashCode = 1;
		hashCode = hashCode * 10 + (this.getCanale() != null ? this.getCanale().getId().hashCode() : 0);
		hashCode = hashCode * 10 + (this.getCanaleValue() != null ? this.getCanaleValue().hashCode() : 0);		
		hashCode = hashCode * 10 + (this.getTipoRecapiti() != null ? this.getTipoRecapiti().hashCode() : 0);
		return hashCode;
	}
	
	private boolean checkEquality(final Object newValue, final Object thisValue) {
		boolean isEquality = false;
		if (newValue != null && thisValue != null && newValue.equals(thisValue)) {
			isEquality = true;
		} else if (newValue == null && thisValue == null) {
			isEquality = true;
		}
		return isEquality;
	}
	
	private boolean checkCanaleEquality(final CanalePreferitoDataView view) {
		return checkEquality(view.getCanale() != null ? view.getCanale().getCausale() : null,
				this.getCanale() != null ? this.getCanale().getCausale() : null);
	}
	
	private boolean checkTipoRecapitiEquality(final ClassificazioneView view) {
		return checkEquality(view != null ? view.getCausale() : null,
				this.getTipoRecapiti() != null ? this.getTipoRecapiti().getCausale() : null);
	}
}
