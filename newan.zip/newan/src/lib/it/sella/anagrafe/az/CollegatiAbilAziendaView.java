package it.sella.anagrafe.az;

/**
 * CollegatiAbilitati AZIENDA View
 *
 */
public class CollegatiAbilAziendaView implements ICollegatiAbilAziendaView {
	
	private Long soggetto;
	private String denominazione;
	private String motive;
	private String motiveDescription;
	
	public Long getSoggetto() {
		return soggetto;
	}
	public void setSoggetto(Long soggetto) {
		this.soggetto = soggetto;
	}
	public String getDenominazione() {
		return denominazione;
	}
	public void setDenominazione(String denominazione) {
		this.denominazione = denominazione;
	}
	public String getMotive() {
		return motive;
	}
	public void setMotive(String motive) {
		this.motive = motive;
	}
	public String getMotiveDescription() {
		return motiveDescription;
	}
	public void setMotiveDescription(String motiveDescription) {
		this.motiveDescription = motiveDescription;
	}

}
