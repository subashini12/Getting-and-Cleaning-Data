package it.sella.anagrafe.az;

import it.sella.anagrafe.common.Citta;
import it.sella.anagrafe.common.Nazione;

import java.sql.Date;

public class DatiAnagraficiAZView extends AZView implements Cloneable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String getDenominazione() {
        return denominazione;
    }

    public void setDenominazione(final String denominazione) {
        this.denominazione = denominazione;
    }

    public Date getDataDiCostituzione() {
        return dataDiCostituzione;
    }

    public void setDataDiCostituzione(final Date dataDiCostituzione) {
        this.dataDiCostituzione = dataDiCostituzione;
    }

    public String getNormalizedName() {
        return normalizedName;
    }

    public void setNormalizedName(final String normalizedName) {
        this.normalizedName = normalizedName;
    }
    
	public Long getOpId() {
		return opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}	

	public Citta getCittaCostituzione() {
		return cittaCostituzione;
	}

	public void setCittaCostituzione(Citta cittaCostituzione) {
		this.cittaCostituzione = cittaCostituzione;
	}

	public Nazione getNazioneCostituzione() {
		return nazioneCostituzione;
	}

	public void setNazioneCostituzione(Nazione nazioneCostituzione) {
		this.nazioneCostituzione = nazioneCostituzione;
	}

	public Object clone() {
		try {
			return super.clone();
		} catch (final CloneNotSupportedException e) {
			final DatiAnagraficiAZView datiAnagraficiAZView = new DatiAnagraficiAZView();
			datiAnagraficiAZView.setDataDiCostituzione(this.dataDiCostituzione);
			datiAnagraficiAZView.setDenominazione(this.denominazione);
			datiAnagraficiAZView.setNormalizedName(this.normalizedName);
			datiAnagraficiAZView.setNazioneCostituzione(this.nazioneCostituzione);
			datiAnagraficiAZView.setCittaCostituzione(this.cittaCostituzione);
			return datiAnagraficiAZView;
		}
	}
    
    public int hashCode() {
		return super.hashCode();
	}
    
    public boolean equals(final Object obj) {
    	if(obj instanceof DatiAnagraficiAZView) {
    		final DatiAnagraficiAZView argView = (DatiAnagraficiAZView)obj;
            if(this.denominazione != null) {
                if(!this.denominazione.equals(argView.getDenominazione())) {
					return false;
				}
            } else if(argView.getDenominazione() != null) {
				return false;
			}
            if(this.dataDiCostituzione != null) {
                if(!this.dataDiCostituzione.equals(argView.getDataDiCostituzione())) {
					return false;
				}
            } else if(argView.getDataDiCostituzione() != null) {
				return false;
			}
            if(argView.getCittaCostituzione() != null && this.cittaCostituzione != null) {
            	if(argView.getCittaCostituzione().getCommune() != null && this.cittaCostituzione.getCommune() != null) {
					if(!argView.getCittaCostituzione().getCommune().equals(this.cittaCostituzione.getCommune())) {
						return false;
					}
				} else if(argView.getCittaCostituzione().getCommune() != null || this.cittaCostituzione.getCommune() != null) {
					return false;
				}
            	if(argView.getCittaCostituzione().getCittaId() != null && this.cittaCostituzione.getCittaId() != null &&
            			!argView.getCittaCostituzione().getCittaId().equals(this.cittaCostituzione.getCittaId())) {
					return false;
				} 
            } else if(argView.getCittaCostituzione() != null || this.cittaCostituzione != null) {
				return false;
			}
            if(argView.getNazioneCostituzione() != null && this.nazioneCostituzione != null) {
            	// cncf equals check added for : some nazione are having same Name With Different Cncf.
            	final String oldCncf = argView.getNazioneCostituzione().getCncf() != null ? argView.getNazioneCostituzione().getCncf() : "";
            	final String newCncf = this.nazioneCostituzione.getCncf() != null ? this.nazioneCostituzione.getCncf() : "";
                if(!(argView.getNazioneCostituzione().getNome().equals(this.nazioneCostituzione.getNome()) && newCncf.equals(oldCncf))) {
					return false;
				}
            } else if(argView.getNazioneCostituzione() != null || this.nazioneCostituzione != null) {
				return false;
			}
            return true;
        } else {
            return false;
        }
    }

    private Date dataDiCostituzione;
    private String denominazione;
    private String normalizedName;
    private Long opId;
    private Citta cittaCostituzione;
    private Nazione nazioneCostituzione;

}
