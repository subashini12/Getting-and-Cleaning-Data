package it.sella.anagrafe.az;

import it.sella.anagrafe.pf.DatiFiscaliPFView;

public class RicercaResultAZView extends AZView {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private DatiAnagraficiAZView datiAnagraficiAZView;
    private DatiFiscaliPFView datiFiscaliAZView;
    private String tipoSocieta;
    private String tipoSoggettoDesc;

    private Long soggettoId;

    public RicercaResultAZView() {
    }

    public Long getId() {
        return soggettoId;
    }

    public void setId(final Long id) {
        soggettoId = id;
    }

    public DatiAnagraficiAZView getDatiAnagaficiAZView() {
        return datiAnagraficiAZView;
    }

    public DatiFiscaliPFView getDatiFiscaliAZView() {
        return datiFiscaliAZView;
    }

    public void setDatiAnagraficiAZView(final DatiAnagraficiAZView datiAnagraficiAZView) {
        this.datiAnagraficiAZView = datiAnagraficiAZView;
    }

    public void setDatiFiscaliAZView(final DatiFiscaliPFView datiFiscaliAZView) {
        this.datiFiscaliAZView = datiFiscaliAZView;
    }

    public void setTipoSocieta(final String tipoSocieta) {
        this.tipoSocieta = tipoSocieta;
    }

    public String getTipoSocieta() {
        return tipoSocieta;
    }

    public String getTipoSoggettoDescrizione() {
        return tipoSoggettoDesc;
    }

    public void setTipoSoggettoDescrizione(final String tipoSoggettoDesc) {
        this.tipoSoggettoDesc = tipoSoggettoDesc;
    }


}
