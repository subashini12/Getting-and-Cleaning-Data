package it.sella.anagrafe.az;

import java.io.Serializable;
import java.util.List;

/**
 * @author gbs03447
 * This View Class Will maintains the Parsed QuestionarioXML Data.
 *
 */
public class FatcaQuestionarioXMLView implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private String description;
	private List<SubQuestionarioView> subQuestionarioView;
	private String flowYes;
	private String flowNo;
	
	public String getName() {
		return name;
	}
	
	public void setName(final String name) {
		this.name = name;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(final String description) {
		this.description = description;
	}
	
	public List<SubQuestionarioView> getSubQuestionarioView() {
		return subQuestionarioView;
	}
	
	public void setSubQuestionarioView(final List<SubQuestionarioView> subQuestionarioView) {
		this.subQuestionarioView = subQuestionarioView;
	}

	public String getFlowYes() {
		return flowYes;
	}

	public void setFlowYes(final String flowYes) {
		this.flowYes = flowYes;
	}

	public String getFlowNo() {
		return flowNo;
	}

	public void setFlowNo(final String flowNo) {
		this.flowNo = flowNo;
	}
	
}
