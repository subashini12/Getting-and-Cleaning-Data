package it.sella.anagrafe.az;

import it.sella.anagrafe.pf.DatiPrivacyPFFiveLevelView;

public class DatiPrivacyAZFiveLevelView extends DatiPrivacyPFFiveLevelView {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
}
