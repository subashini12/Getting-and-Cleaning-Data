package it.sella.anagrafe.az;

import java.io.Serializable;

/**
 * @author GBS03447
 * This SubQuestionarioView class maintains the SubQuestion of The Main Questionario.
 *
 */
public class SubQuestionarioView implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String name;
	private String description;
	
	public Long getId() {
		return id;
	}
	
	public void setId(final Long id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(final String name) {
		this.name = name;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(final String description) {
		this.description = description;
	}
}
