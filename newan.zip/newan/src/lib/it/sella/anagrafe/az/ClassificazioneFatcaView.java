package it.sella.anagrafe.az;

import it.sella.anagrafe.common.Nazione;
import it.sella.anagrafe.implementation.IQuestionarioView;
import it.sella.classificazione.ClassificazioneView;

import java.io.Serializable;
import java.util.Collection;

public class ClassificazioneFatcaView extends AZView implements Cloneable, Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String denominazione;
	private Nazione nazioneDiCostituzione;
	private String nazioneSedeLegale;
	private String nazioneSedeAdministrativa;
	private String residenzaFiscale;
	private String settore;
	private String settoreDescription;
	private Boolean onlus;
	private String stampaModuloFatca;
	private boolean usOriginCustomer;
	private Collection<FatcaAZView> fatcaCalculatedAutomatica;
	private ClassificazioneView userChoiceFromFatcaAutomatica;
	private ClassificazioneView userChoiceFromFatcaConfermata;
	private String fatcaUserBarcode;
	private Boolean w9;
	private String cdEst;
	private String numSic;
	private String codice_GIIN;
	private String bustaStampaAllowed;
	private String giinMandatory;
	private String xmlTag;
	private ClassificazioneView w9NoReasonCertificate;
	private String einNumber;
	private boolean w9PageConfermaDone;
	private Collection<IQuestionarioView> fatcaQuestionarioList;
	private String residenzaFiscale2;
	private String residenzaFiscale3;
	
	public String getDenominazione() {
		return denominazione;
	}
	
	public void setDenominazione(final String denominazione) {
		this.denominazione = denominazione;
	}
	
	public Nazione getNazioneDiCostituzione() {
		return nazioneDiCostituzione;
	}
	
	public void setNazioneDiCostituzione(final Nazione nazioneDiCostituzione) {
		this.nazioneDiCostituzione = nazioneDiCostituzione;
	}
	
	public String getNazioneSedeLegale() {
		return nazioneSedeLegale;
	}
	
	public void setNazioneSedeLegale(final String nazioneSedeLegale) {
		this.nazioneSedeLegale = nazioneSedeLegale;
	}
	
	public String getNazioneSedeAdministrativa() {
		return nazioneSedeAdministrativa;
	}
	
	public void setNazioneSedeAdministrativa(final String nazioneSedeAdministrativa) {
		this.nazioneSedeAdministrativa = nazioneSedeAdministrativa;
	}
	
	public String getResidenzaFiscale() {
		return residenzaFiscale;
	}
	
	public void setResidenzaFiscale(final String residenzaFiscale) {
		this.residenzaFiscale = residenzaFiscale;
	}
	
	public String getSettore() {
		return settore;
	}
	
	public void setSettore(final String settore) {
		this.settore = settore;
	}
	
	public String getSettoreDescription() {
		return settoreDescription;
	}
	
	public void setSettoreDescription(final String settoreDescription) {
		this.settoreDescription = settoreDescription;
	}
	
	public Boolean getOnlus() {
		return onlus;
	}
	
	public void setOnlus(final Boolean onlus) {
		this.onlus = onlus;
	}	
	
	public String getStampaModuloFatca() {
		return stampaModuloFatca;
	}

	public void setStampaModuloFatca(final String stampaModuloFatca) {
		this.stampaModuloFatca = stampaModuloFatca;
	}

	public boolean isUsOriginCustomer() {
		return usOriginCustomer;
	}

	public void setUsOriginCustomer(boolean usOriginCustomer) {
		this.usOriginCustomer = usOriginCustomer;
	}

	public Collection<FatcaAZView> getFatcaCalculatedAutomatica() {
		return fatcaCalculatedAutomatica;
	}
	
	public void setFatcaCalculatedAutomatica(final Collection<FatcaAZView> fatcaCalculatedAutomatica) {
		this.fatcaCalculatedAutomatica = fatcaCalculatedAutomatica;
	}

	public ClassificazioneView getUserChoiceFromFatcaAutomatica() {
		return userChoiceFromFatcaAutomatica;
	}

	public void setUserChoiceFromFatcaAutomatica(final ClassificazioneView userChoiceFromFatcaAutomatica) {
		this.userChoiceFromFatcaAutomatica = userChoiceFromFatcaAutomatica;
	}

	public ClassificazioneView getUserChoiceFromFatcaConfermata() {
		return userChoiceFromFatcaConfermata;
	}

	public void setUserChoiceFromFatcaConfermata(final ClassificazioneView userChoiceFromFatcaConfermata) {
		this.userChoiceFromFatcaConfermata = userChoiceFromFatcaConfermata;
	}

	public String getFatcaUserBarcode() {
		return fatcaUserBarcode;
	}

	public void setFatcaUserBarcode(final String fatcaUserBarcode) {
		this.fatcaUserBarcode = fatcaUserBarcode;
	}

	public Boolean getW9() {
		return w9;
	}

	public void setW9(final Boolean w9) {
		this.w9 = w9;
	}

	public String getCdEst() {
		return cdEst;
	}

	public void setCdEst(final String cdEst) {
		this.cdEst = cdEst;
	}

	public String getNumSic() {
		return numSic;
	}

	public void setNumSic(final String numSic) {
		this.numSic = numSic;
	}

	public String getCodice_GIIN() {
		return codice_GIIN;
	}

	public void setCodice_GIIN(final String codice_GIIN) {
		this.codice_GIIN = codice_GIIN;
	}

	public String getBustaStampaAllowed() {
		return bustaStampaAllowed;
	}

	public void setBustaStampaAllowed(final String bustaStampaAllowed) {
		this.bustaStampaAllowed = bustaStampaAllowed;
	}

	public String getGiinMandatory() {
		return giinMandatory;
	}

	public void setGiinMandatory(final String giinMandatory) {
		this.giinMandatory = giinMandatory;
	}

	public String getXmlTag() {
		return xmlTag;
	}

	public void setXmlTag(final String xmlTag) {
		this.xmlTag = xmlTag;
	}
	
	public ClassificazioneView getW9NoReasonCertificate() {
		return w9NoReasonCertificate;
	}

	public void setW9NoReasonCertificate(final ClassificazioneView w9NoReasonCertificate) {
		this.w9NoReasonCertificate = w9NoReasonCertificate;
	}

	public String getEinNumber() {
		return einNumber;
	}

	public void setEinNumber(final String einNumber) {
		this.einNumber = einNumber;
	}
	
	public boolean isW9PageConfermaDone() {
		return w9PageConfermaDone;
	}

	public void setW9PageConfermaDone(final boolean w9PageConfermaDone) {
		this.w9PageConfermaDone = w9PageConfermaDone;
	}

	public Collection<IQuestionarioView> getFatcaQuestionarioList() {
		return fatcaQuestionarioList;
	}

	public void setFatcaQuestionarioList(final Collection<IQuestionarioView> fatcaQuestionarioList) {
		this.fatcaQuestionarioList = fatcaQuestionarioList;
	}
	// For now these two residenzaFiscali used in calculation of US Origin & Fatca base details changed validation case. not included in calculation Query.
	public String getResidenzaFiscale2() {
		return residenzaFiscale2;
	}

	public void setResidenzaFiscale2(final String residenzaFiscale2) {
		this.residenzaFiscale2 = residenzaFiscale2;
	}

	public String getResidenzaFiscale3() {
		return residenzaFiscale3;
	}

	public void setResidenzaFiscale3(final String residenzaFiscale3) {
		this.residenzaFiscale3 = residenzaFiscale3;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 * 
	 * This Method Compares the FATCA Base Details .. Nazione Di Costituzione, SLE Nazione, SAM Nazione, Residenza Fiscali, Settore, onlus, residenzaFiscale2, residenzaFiscale3
	 * 
	 */
	public boolean equals(final Object obj) {
		boolean result = false;
		if (obj instanceof ClassificazioneFatcaView) {
			final ClassificazioneFatcaView fatcaView = (ClassificazioneFatcaView) obj;
			result = equalNazioneDiCostituzione(fatcaView.getNazioneDiCostituzione())
					&& checkEquality(fatcaView.getNazioneSedeLegale(), this.nazioneSedeLegale)
					&& checkEquality(fatcaView.getNazioneSedeAdministrativa(), this.nazioneSedeAdministrativa)
					&& checkEquality(fatcaView.getResidenzaFiscale(), this.residenzaFiscale)
					&& checkEquality(fatcaView.getSettore(), this.settore)
					&& checkEquality(fatcaView.getOnlus(), this.onlus)
					&& checkEquality(fatcaView.getResidenzaFiscale2(), this.residenzaFiscale2)
					&& checkEquality(fatcaView.getResidenzaFiscale3(), this.residenzaFiscale3);
		}
		return result;
	}

	private boolean checkEquality(final Object newValue, final Object thisValue) {
		boolean isEquality = false;
		if (newValue != null && thisValue != null && newValue.equals(thisValue)) {
			isEquality = true;
		} else if (newValue == null && thisValue == null) {
			isEquality = true;
		}
		return isEquality;
	}
	
	private boolean equalNazioneDiCostituzione(final Nazione nazioneView){
		return checkEquality(nazioneView != null ? nazioneView.getNome() : null,
				this.nazioneDiCostituzione != null ? this.nazioneDiCostituzione.getNome() : null);
	}
	
	public Object clone() { // Not Used.
		try {
			return super.clone();
		} catch (final CloneNotSupportedException e) {
			final ClassificazioneFatcaView fatcaView = new ClassificazioneFatcaView();
			fatcaView.setDenominazione(this.denominazione);
			fatcaView.setNazioneDiCostituzione(this.nazioneDiCostituzione);
			fatcaView.setNazioneSedeLegale(this.nazioneSedeLegale);
			fatcaView.setNazioneSedeAdministrativa(this.nazioneSedeAdministrativa);
			fatcaView.setResidenzaFiscale(this.residenzaFiscale);
			fatcaView.setSettore(this.settore);
			fatcaView.setSettoreDescription(this.settoreDescription);
			fatcaView.setOnlus(this.onlus);
			fatcaView.setStampaModuloFatca(this.stampaModuloFatca);
			fatcaView.setUsOriginCustomer(this.usOriginCustomer);
			fatcaView.setFatcaCalculatedAutomatica(this.fatcaCalculatedAutomatica);
			fatcaView.setUserChoiceFromFatcaAutomatica(this.userChoiceFromFatcaAutomatica);
			fatcaView.setUserChoiceFromFatcaConfermata(this.userChoiceFromFatcaConfermata);
			fatcaView.setFatcaUserBarcode(this.fatcaUserBarcode);
			fatcaView.setW9(this.w9);
			fatcaView.setCdEst(this.cdEst);
			fatcaView.setNumSic(this.numSic);
			fatcaView.setCodice_GIIN(this.codice_GIIN);
			fatcaView.setBustaStampaAllowed(this.bustaStampaAllowed);
			fatcaView.setGiinMandatory(this.giinMandatory);
			fatcaView.setXmlTag(this.xmlTag);
			fatcaView.setEinNumber(this.einNumber);
			fatcaView.setW9NoReasonCertificate(this.w9NoReasonCertificate);
			fatcaView.setW9PageConfermaDone(this.w9PageConfermaDone);
			fatcaView.setFatcaQuestionarioList(this.fatcaQuestionarioList);
			fatcaView.setResidenzaFiscale2(this.residenzaFiscale2);
			fatcaView.setResidenzaFiscale3(this.residenzaFiscale3);
			return fatcaView;
		}
	}
}
