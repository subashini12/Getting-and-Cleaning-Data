package it.sella.anagrafe.az;

import it.sella.anagrafe.IDocPoteriFirmaView;
import it.sella.anagrafe.view.ICollegateView;

import java.sql.Timestamp;
import java.util.Collection;

public class CollegateAZView implements ICollegateView {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public CollegateAZView() {
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(final String cognome) {
        this.cognome = cognome;
    }

    public Long getId() {
        return soggettoId;
    }

    public void setId(final Long long1) {
        this.soggettoId = long1;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(final String nome) {
        this.nome = nome;
    }

    public void setTypeOfCollegate(final String typeOfCollegate) {
        this.typeOfCollegate = typeOfCollegate;
    }

    public String getTypeOfCollegate() {
        return typeOfCollegate;
    }

    public void setTypeOfCollegateDescrizione(final String typeOfCollegateDescrizione) {
        this.typeOfCollegateDescrizione = typeOfCollegateDescrizione;
    }

    public String getTypeOfCollegateDescrizione() {
        return typeOfCollegateDescrizione;
    }

    public Timestamp getDataDiNascita() {
        return dataDiNascita;
    }

    public void setDataDiNascita(final Timestamp dataDiNascita) {
        this.dataDiNascita = dataDiNascita;
    }

    public String getLuogoDiNascitaNazione() {
        return luogoDiNascitaNazione;
    }

    public void setLuogoDiNascitaNazione(final String luogoDiNascitaNazione) {
        this.luogoDiNascitaNazione = luogoDiNascitaNazione;
    }

    public String getNote() {
        return note;
    }

    public void setNote(final String note) {
        this.note = note;
    }
    
    public String getProfile() {
		return profile;
	}

	public void setProfile(final String profile) {
		this.profile = profile;
	}
	
	public Collection<IDocPoteriFirmaView> getDocPoteriFirmaList() {
		return docPoteriFirmaList;
	}

	public void setDocPoteriFirmaList(final Collection<IDocPoteriFirmaView> docPoteriFirmaList) {
		this.docPoteriFirmaList = docPoteriFirmaList;
	}

	public boolean isPoteriFirmaApplicable() {
		return poteriFirmaApplicable;
	}

	public void setPoteriFirmaApplicable(final boolean poteriFirmaApplicable) {
		this.poteriFirmaApplicable = poteriFirmaApplicable;
	}
	
	public IDocPoteriFirmaView getLastValidPoteriFirmaDocView() {
		return lastValidPoteriFirmaDocView;
	}

	public void setLastValidPoteriFirmaDocView(final IDocPoteriFirmaView lastValidPoteriFirmaDocView) {
		this.lastValidPoteriFirmaDocView = lastValidPoteriFirmaDocView;
	}

	public Object clone() {
		try {
			return super.clone();
		} catch (final CloneNotSupportedException e) {
			final CollegateAZView collegateAZView = new CollegateAZView();
			collegateAZView.setNome(this.nome);
			collegateAZView.setCognome(this.cognome);
			collegateAZView.setTypeOfCollegate(this.typeOfCollegate);
			collegateAZView.setTypeOfCollegateDescrizione(this.typeOfCollegateDescrizione);
			collegateAZView.setId(this.soggettoId);
			collegateAZView.setDataDiNascita(this.dataDiNascita);
			collegateAZView.setLuogoDiNascitaNazione(luogoDiNascitaNazione);
			collegateAZView.setNote(this.note);
			collegateAZView.setProfile(this.profile);
			collegateAZView.setDocPoteriFirmaList(this.docPoteriFirmaList);
			collegateAZView.setPoteriFirmaApplicable(this.poteriFirmaApplicable);
			collegateAZView.setLastValidPoteriFirmaDocView(this.lastValidPoteriFirmaDocView);
			return collegateAZView;
		}
	}

	private String nome;
    private String cognome;
    private String typeOfCollegate;
    private String typeOfCollegateDescrizione;
    private Long soggettoId;
    private Timestamp dataDiNascita;
    private String luogoDiNascitaNazione;
    private String note;
    private String profile;
    private Collection<IDocPoteriFirmaView> docPoteriFirmaList;
    private boolean poteriFirmaApplicable;
    private IDocPoteriFirmaView lastValidPoteriFirmaDocView;
}
