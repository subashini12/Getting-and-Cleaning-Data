package it.sella.anagrafe.az;

import it.sella.anagrafe.implementation.IQuestionarioView;
import it.sella.classificazione.ClassificazioneView;

/**
 * @author gbs03447
 * This Class is For to maintain all the FATCA Questionario Data.
 *
 */
public class QuestionarioView implements IQuestionarioView {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String name;
	private String questionarioXML;
	private String validQuestionario;
	private String questionarioStatus;
	private Long questionarioOrder;
	private FatcaQuestionarioXMLView fatcaQuestionarioXMLView;
	private ClassificazioneView optionYesFatca;
	private ClassificazioneView optionNoFatca;
	
	public Long getId() {
		return id;
	}
	
	public void setId(final Long id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(final String name) {
		this.name = name;
	}
	
	public String getQuestionarioXML() {
		return questionarioXML;
	}
	
	public void setQuestionarioXML(final String questionarioXML) {
		this.questionarioXML = questionarioXML;
	}
	
	public String getValidQuestionario() {
		return validQuestionario;
	}
	
	public void setValidQuestionario(final String validQuestionario) {
		this.validQuestionario = validQuestionario;
	}
	
	public String getQuestionarioStatus() {
		return questionarioStatus;
	}
	
	public void setQuestionarioStatus(final String questionarioStatus) {
		this.questionarioStatus = questionarioStatus;
	}
	public Long getQuestionarioOrder() {
		return questionarioOrder;
	}
	
	public void setQuestionarioOrder(final Long questionarioOrder) {
		this.questionarioOrder = questionarioOrder;
	}
	
	public FatcaQuestionarioXMLView getFatcaQuestionarioXMLView() {
		return fatcaQuestionarioXMLView;
	}
	
	public void setFatcaQuestionarioXMLView(final FatcaQuestionarioXMLView fatcaQuestionarioXMLView) {
		this.fatcaQuestionarioXMLView = fatcaQuestionarioXMLView;
	}
	
	public ClassificazioneView getOptionYesFatca() {
		return optionYesFatca;
	}

	public void setOptionYesFatca(final ClassificazioneView optionYesFatca) {
		this.optionYesFatca = optionYesFatca;
	}

	public ClassificazioneView getOptionNoFatca() {
		return optionNoFatca;
	}

	public void setOptionNoFatca(final ClassificazioneView optionNoFatca) {
		this.optionNoFatca = optionNoFatca;
	}
	
}
