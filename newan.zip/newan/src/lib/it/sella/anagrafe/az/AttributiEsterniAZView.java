package it.sella.anagrafe.az;

import it.sella.anagrafe.common.AlboProfessione;
import it.sella.classificazione.ClassificazioneView;

public class AttributiEsterniAZView extends AZView implements Cloneable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public ClassificazioneView getLingua() {
        return lingua;
    }

    public void setLingua(final ClassificazioneView lingua) {
        this.lingua = lingua;
    }

    public String getSettore() {
        return settore;
    }

    public void setSettore(final String settore) {
        this.settore = settore;
    }

    public String getStato() {
        return stato;
    }

    public void setStato(final String stato) {
        this.stato = stato;
    }

    public String getRamo() {
        return ramo;
    }

    public void setRamo(final String ramo) {
        this.ramo = ramo;
    }

    /*public String getAtt() {
        return att;
    }

    public void setAtt(String attivita) {
        this.att = attivita;
    }*/

    public String getTse() {
        return tse;
    }

    public void setTse(final String tipoSocietaEstera) {
        this.tse = tipoSocietaEstera;
    }

    public ClassificazioneView getTsf() {
        return tsf;
    }

    public void setTsf(final ClassificazioneView tipoSocietaFallita) {
        this.tsf = tipoSocietaFallita;
    }

    public Boolean getEcomm() {
        return ecomm;
    }

    public void setEcomm(final Boolean indicatoreEnteCommerciale) {
        this.ecomm = indicatoreEnteCommerciale;
    }

    public Boolean getOnlus() {
        return onlus;
    }

    public void setOnlus(final Boolean indicatoreOnlus) {
        this.onlus = indicatoreOnlus;
    }

    public Boolean getFinv() {
        return finv;
    }

    public void setFinv(final Boolean indicatoreFondoInvestimento) {
        this.finv = indicatoreFondoInvestimento;
    }

    public Boolean getFpens() {
        return fpens;
    }

    public void setFpens(final Boolean indicatoreFondoPensione) {
        this.fpens = indicatoreFondoPensione;
    }

    public ClassificazioneView getTipsoc() {
        return tipsoc;
    }

    public void setTipsoc(final ClassificazioneView tipoSocieta) {
        this.tipsoc = tipoSocieta;
    }

    public Boolean getDai() {
        return dai;
    }

    public void setDai(final Boolean dai) {
        this.dai = dai;
    }

    public void setTredieci(final Boolean tredieci) {
        this.tredieci = tredieci;
    }

    public Boolean getTredieci() {
        return this.tredieci;
    }

    public String getSconf() {
        return sconf;
    }

    public void setSconf(final String sconf) {
        this.sconf = sconf;
    }
    
	public Long getOpId() {
		return opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}
	public String getAttSezione() {
		return attSezione;
	}

	public void setAttSezione(final String attSezione) {
		this.attSezione = attSezione;
	}

	public String getAttDivisione() {
		return attDivisione;
	}

	public void setAttDivisione(final String attDivisione) {
		this.attDivisione = attDivisione;
	}

	public String getClasse() {
		return classe;
	}

	public void setClasse(final String classe) {
		this.classe = classe;
	}
    public String getCosg() {
		return cosg;
	}

	public void setCosg(final String cosg) {
		this.cosg = cosg;
	}

	public String getSusg() {
		return susg;
	}

	public void setSusg(final String susg) {
		this.susg = susg;
	}

	public String getDisg() {
		return disg;
	}

	public void setDisg(final String disg) {
		this.disg = disg;
	}

	public String getDfsg() {
		return dfsg;
	}

	public void setDfsg(final String dfsg) {
		this.dfsg = dfsg;
	}
	public String getSegdp() {
		return segdp;
	}

	public void setSegdp(final String segdp) {
		this.segdp = segdp;
	}
	
	public String getSegdpIntestazione() {
		return segdpIntestazione;
	}

	public void setSegdpIntestazione(final String segdpIntestazione) {
		this.segdpIntestazione = segdpIntestazione;
	}
	

	public String getFirmagraf() {
		return firmagraf;
	}

	public void setFirmagraf(final String firmagraf) {
		this.firmagraf = firmagraf;
	}

	public String getFirmadata() {
		return firmadata;
	}

	public void setFirmadata(final String firmadata) {
		this.firmadata = firmadata;
	}

	public Boolean getSTARTUP() {
		return STARTUP;
	}

	public void setSTARTUP(final Boolean sTARTUP) {
		STARTUP = sTARTUP;
	}

	public Boolean getINC_STARTUP() {
		return INC_STARTUP;
	}

	public void setINC_STARTUP(final Boolean iNC_STARTUP) {
		INC_STARTUP = iNC_STARTUP;
	}

	public Boolean getSTARTUP_SOC() {
		return STARTUP_SOC;
	}

	public void setSTARTUP_SOC(final Boolean sTARTUP_SOC) {
		STARTUP_SOC = sTARTUP_SOC;
	}
	
	
	public String getPOLIZZA_SELLA_LIFE() {
		return POLIZZA_SELLA_LIFE;
	}

	public void setPOLIZZA_SELLA_LIFE(final String POLIZZA_SELLA_LIFE) {
		this.POLIZZA_SELLA_LIFE = POLIZZA_SELLA_LIFE;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public Boolean getMoneyTransfer() {
		return moneyTransfer;
	}

	public void setMoneyTransfer(final Boolean moneyTransfer) {
		this.moneyTransfer = moneyTransfer;
	}

	public Boolean getSOC_QUOTATA() {
		return SOC_QUOTATA;
	}

	public void setSOC_QUOTATA(final Boolean sOC_QUOTATA) {
		SOC_QUOTATA = sOC_QUOTATA;
	}
	
	public AlboProfessione getAlbo_prof() {
		return albo_prof;
	}

	public void setAlbo_prof(final AlboProfessione albo_prof) {
		this.albo_prof = albo_prof;
	}

	public String getNumero_di_albo() {
		return numero_di_albo;
	}

	public void setNumero_di_albo(final String numero_di_albo) {
		this.numero_di_albo = numero_di_albo;
	}

	public String getUlteriori_annotazioni() {
		return ulteriori_annotazioni;
	}

	public void setUlteriori_annotazioni(final String ulteriori_annotazioni) {
		this.ulteriori_annotazioni = ulteriori_annotazioni;
	}

	
	public ClassificazioneView getSettorecommerciale() {
		return settorecommerciale;
	}

	public void setSettorecommerciale(ClassificazioneView settorecommerciale) {
		this.settorecommerciale = settorecommerciale;
	}
	
	public String getSocioBSE() {
		return socioBSE;
	}

	public void setSocioBSE(String socioBSE) {
		this.socioBSE = socioBSE;
	}

	public String getSocioSHB() {
		return socioSHB;
	}

	public void setSocioSHB(String socioSHB) {
		this.socioSHB = socioSHB;
	}
	
	public Boolean getNewDai() {
		return newDai;
	}

	public void setNewDai(final Boolean newDai) {
		this.newDai = newDai;
	}

	public Object clone() {
		try {
			return super.clone();
		} catch (final CloneNotSupportedException e) {
			final AttributiEsterniAZView attributiEsterniAZView = new AttributiEsterniAZView();
			//attributiEsterniAZView.setAtt(this.att);
			attributiEsterniAZView.setDai(this.dai);
			attributiEsterniAZView.setEcomm(ecomm);
			attributiEsterniAZView.setFinv(this.finv);
			attributiEsterniAZView.setFpens(this.fpens);
			attributiEsterniAZView.setLingua(this.lingua);
			attributiEsterniAZView.setOnlus(this.onlus);
			attributiEsterniAZView.setRamo(this.ramo);
			attributiEsterniAZView.setSconf(this.sconf);
			attributiEsterniAZView.setSettore(this.settore);
			attributiEsterniAZView.setStato(this.stato);
			attributiEsterniAZView.setTipsoc(this.tipsoc);
			attributiEsterniAZView.setTredieci(this.tredieci);
			attributiEsterniAZView.setTse(this.tse);
			attributiEsterniAZView.setTsf(this.tsf);
			attributiEsterniAZView.setOpId(this.opId);
			attributiEsterniAZView.setAttSezione(this.attSezione);
			attributiEsterniAZView.setAttDivisione(this.attDivisione);
			attributiEsterniAZView.setClasse(this.classe);
			attributiEsterniAZView.setCosg(this.cosg);
			attributiEsterniAZView.setSusg(this.susg);
			attributiEsterniAZView.setDisg(this.disg);
			attributiEsterniAZView.setDfsg(this.dfsg);
			attributiEsterniAZView.setSegdp(this.segdp);
			attributiEsterniAZView.setSegdpIntestazione(this.segdpIntestazione);
			attributiEsterniAZView.setFirmagraf(this.firmagraf);
			attributiEsterniAZView.setFirmadata(this.firmadata);
			// Attributes for Startup
			attributiEsterniAZView.setSTARTUP(this.STARTUP);
			attributiEsterniAZView.setINC_STARTUP(this.INC_STARTUP);
			attributiEsterniAZView.setSTARTUP_SOC(this.STARTUP_SOC);
			
			attributiEsterniAZView.setPOLIZZA_SELLA_LIFE(this.POLIZZA_SELLA_LIFE);
			
			attributiEsterniAZView.setMoneyTransfer(this.moneyTransfer);
			attributiEsterniAZView.setSOC_QUOTATA(this.SOC_QUOTATA);
			
			attributiEsterniAZView.setAlbo_prof(this.albo_prof);
			attributiEsterniAZView.setNumero_di_albo(this.numero_di_albo);
			attributiEsterniAZView.setUlteriori_annotazioni(this.ulteriori_annotazioni);
			
			attributiEsterniAZView.setSettorecommerciale(this.settorecommerciale);
			attributiEsterniAZView.setSocioBSE(this.socioBSE);
			attributiEsterniAZView.setSocioSHB(this.socioSHB);
			attributiEsterniAZView.setNewDai(this.newDai);
			return attributiEsterniAZView;
		}
	}

    private String sconf;
    private String settore;
    private ClassificazioneView lingua;
    private String ramo;
    private String stato;
    //private String att;
    private String tse;
    private ClassificazioneView tsf;
    private Boolean ecomm;
    private Boolean onlus;
    private Boolean finv;
    private Boolean fpens;
    private Boolean dai;
    private ClassificazioneView tipsoc;
    private Boolean tredieci;
    private Long opId;
    private String attSezione;
    private String attDivisione;
    private String classe;
    private String cosg;
    private String susg;
    private String disg;
    private String dfsg;
    private String segdp;
    private String segdpIntestazione;
    private String firmagraf;
    private String firmadata;
    
    private Boolean STARTUP;
    private Boolean INC_STARTUP;
    private Boolean STARTUP_SOC;
    
    private String POLIZZA_SELLA_LIFE;
    
    private Boolean moneyTransfer;
    private Boolean SOC_QUOTATA;
    
    private AlboProfessione albo_prof;
    private String numero_di_albo;
    private String ulteriori_annotazioni;
    
    private ClassificazioneView settorecommerciale;
    private String socioBSE;
    private String socioSHB;
	private Boolean newDai;
}
