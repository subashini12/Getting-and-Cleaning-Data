package it.sella.anagrafe.az;

import it.sella.anagrafe.pf.DatiFiscaliPFView;

public class DatiFiscaliAZView extends DatiFiscaliPFView {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}