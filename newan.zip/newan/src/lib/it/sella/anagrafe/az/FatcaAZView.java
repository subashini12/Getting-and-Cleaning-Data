package it.sella.anagrafe.az;

import it.sella.classificazione.ClassificazioneView;

import java.io.Serializable;

public class FatcaAZView implements Serializable{
	
	private ClassificazioneView fatca;
	private boolean bustaStampaAllowed;
	private boolean giinMandatory;
	private String xmlTag;
	
	public ClassificazioneView getFatca() {
		return fatca;
	}
	
	public void setFatca(final ClassificazioneView fatca) {
		this.fatca = fatca;
	}	
	
	public boolean isBustaStampaAllowed() {
		return bustaStampaAllowed;
	}

	public void setBustaStampaAllowed(final boolean bustaStampaAllowed) {
		this.bustaStampaAllowed = bustaStampaAllowed;
	}

	public boolean isGiinMandatory() {
		return giinMandatory;
	}
	
	public void setGiinMandatory(final boolean giinMandatory) {
		this.giinMandatory = giinMandatory;
	}
	
	public String getXmlTag() {
		return xmlTag;
	}
	
	public void setXmlTag(final String xmlTag) {
		this.xmlTag = xmlTag;
	}
}
