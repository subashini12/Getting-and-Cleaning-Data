package it.sella.anagrafe.az;

/**
 * Class for CollegatiAbilitatiAzienda Interface
 *
 */
public interface ICollegatiAbilAziendaView {
	
	public Long getSoggetto();
	public String getDenominazione();
	public String getMotive();
	public String getMotiveDescription();
}
