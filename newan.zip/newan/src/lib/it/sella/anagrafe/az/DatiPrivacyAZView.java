package it.sella.anagrafe.az;

import it.sella.anagrafe.pf.DatiPrivacyPFView;

public class DatiPrivacyAZView extends DatiPrivacyPFView {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
