package it.sella.anagrafe.az;

public class CodiceSoggettoAZView extends AZView implements Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String getCodiceHost() {
		return codiceHost;
	}

	public void setCodiceHost(final String codiceHost) {
		this.codiceHost = codiceHost;
	}

	public String getCodiceCentraleRischi() {
		return codiceCentraleRischi;
	}

	public void setCodiceCentraleRischi(final String codiceCentraleRischi) {
		this.codiceCentraleRischi = codiceCentraleRischi;
	}

	public String getCcra() {
		return ccra;
	}

	public void setCcra(final String codiceCentraleRischiAssociativa) {
		ccra = codiceCentraleRischiAssociativa;
	}

	public String getCcrg() {
		return ccrg;
	}

	public void setCcrg(final String codiceCentraleRischiDiGruppo) {
		ccrg = codiceCentraleRischiDiGruppo;
	}

	public String getNdg() {
		return ndg;
	}

	public void setNdg(final String ndg) {
		this.ndg = ndg;
	}

	public String getCnr() {
		return cnr;
	}

	public void setCnr(final String cnr) {
		this.cnr = cnr;
	}

	/*
	 * public String getCodcl(){ return codcl; }
	 * 
	 * public void setCodcl(String codcl){ this.codcl = codcl; }
	 */

	public String getCodfo() {
		return codfo;
	}

	public void setCodfo(final String codfo) {
		this.codfo = codfo;
	}

	public String getCce() {
		return this.cce;
	}

	public void setCce(final String cce) {
		this.cce = cce;
	}

	public String getMin() {
		return this.min;
	}

	public void setMin(final String min) {
		this.min = min;
	}

	public String getAcrnm() {
		return acrnm;
	}

	public void setAcrnm(final String acrnm) {
		this.acrnm = acrnm;
	}

	public String getCodtr() {
		return codtr;
	}

	public void setCodtr(final String codtr) {
		this.codtr = codtr;
	}

	public String getSwift() {
		return swift;
	}

	public void setSwift(final String swift) {
		this.swift = swift;
	}

	public String getAbi() {
		return abi;
	}

	public void setAbi(final String abi) {
		this.abi = abi;
	}

	public String getCab() {
		return cab;
	}

	public void setCab(final String cab) {
		this.cab = cab;
	}

	/*
	 * public String getTram() { return tram; }
	 * 
	 * public void setTram(String tram) { this.tram = tram; }
	 */

	public String getCedb() {
		return cedb;
	}

	public void setCedb(final String cedb) {
		this.cedb = cedb;
	}

	public String getCodSIA() {
		return codSIA;
	}

	public void setCodSIA(final String codSIA) {
		this.codSIA = codSIA;
	}

	public String getBK_CODE() {
		return BK_CODE;
	}

	public void setBK_CODE(String bK_CODE) {
		BK_CODE = bK_CODE;
	}

	public Object clone() {
		try {
			return super.clone();
		} catch (final CloneNotSupportedException e) {
			final CodiceSoggettoAZView codiceSoggettoAZView = new CodiceSoggettoAZView();
			codiceSoggettoAZView.setAbi(this.abi);
			codiceSoggettoAZView.setAcrnm(this.acrnm);
			codiceSoggettoAZView.setCab(this.cab);
			codiceSoggettoAZView.setCce(this.cce);
			codiceSoggettoAZView.setCcra(this.ccra);
			codiceSoggettoAZView.setCcrg(this.ccrg);
			codiceSoggettoAZView.setCedb(this.cedb);
			codiceSoggettoAZView.setCnr(this.cnr);
			codiceSoggettoAZView.setCodfo(this.codfo);
			codiceSoggettoAZView.setCodiceCentraleRischi(this.codiceCentraleRischi);
			codiceSoggettoAZView.setCodiceHost(this.codiceHost);
			codiceSoggettoAZView.setCodtr(this.codtr);
			codiceSoggettoAZView.setMin(this.min);
			codiceSoggettoAZView.setNdg(this.ndg);
			codiceSoggettoAZView.setSwift(this.swift);
			codiceSoggettoAZView.setCodSIA(this.codSIA);
			codiceSoggettoAZView.setBK_CODE(this.BK_CODE);
			return codiceSoggettoAZView;
		}
	}

	private String cedb;
	// private String tram;
	private String cab;
	private String codiceHost;
	private String codiceCentraleRischi;
	private String ccra;
	private String ccrg;
	private String ndg;
	private String cnr;
	private String codfo;
	private String cce;
	private String min;
	private String acrnm;
	private String codtr;
	private String swift;
	private String abi;
	private String codSIA;
	private String BK_CODE;
}
