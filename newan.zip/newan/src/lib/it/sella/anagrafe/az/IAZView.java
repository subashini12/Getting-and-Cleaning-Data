package it.sella.anagrafe.az;

import it.sella.anagrafe.implementation.IView;

public interface IAZView extends IView {

}
