package it.sella.anagrafe.az;

import it.sella.anagrafe.INazioneView;
import it.sella.anagrafe.util.StringHandler;


public class AttributiTramiteAZView extends AZView implements Cloneable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Long getAROB() {
		return aROB;
	}
	
	public void setAROB(final Long arob) {
		aROB = arob;
	}
	
	public Long getEROB() {
		return eROB;
	}
	
	public void setEROB(final Long erob) {
		eROB = erob;
	}
	
	public String getNazioneNome() {
		return nazioneNome;
	}
	
	public void setNazioneNome(final String nazioneNome) {
		this.nazioneNome = nazioneNome;
	}
	
	public Long getOpId() {
		return opId;
	}
	
	public void setOpId(final Long opId) {
		this.opId = opId;
	}
	
	public String getSettore() {
		return settore;
	}
	
	public void setSettore(final String settore) {
		this.settore = settore;
	}
	
	public Long getSoggettoId() {
		return soggettoId;
	}
	
	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}

	public Long getId() {
		return id;
	}
	
	public void setId(final Long id) {
		this.id = id;
	}

	public INazioneView getNazioneView() {
		return nazioneView;
	}

	public void setNazioneView(final INazioneView nazioneView) {
		this.nazioneView = nazioneView;
	}

	public String getTipoSoggettoDesc() {
		return tipoSoggettoDesc;
	}

	public void setTipoSoggettoDesc(final String tipoSoggettoDesc) {
		this.tipoSoggettoDesc = tipoSoggettoDesc;
	}

    public boolean equals(final Object obj) {
        if(obj != null && obj instanceof AttributiTramiteAZView) {
        	final AttributiTramiteAZView attributiTramiteAZView = (AttributiTramiteAZView) obj;
        	final StringHandler stringHandler = new StringHandler();
            if(!stringHandler.checkForEquality(attributiTramiteAZView.getNazioneView() != null ? 
            										attributiTramiteAZView.getNazioneView().getNome() : null ,
            										this.nazioneView != null ? this.nazioneView.getNome() : null)) {
				return false;
			}
            if(!stringHandler.checkForEquality(attributiTramiteAZView.getSettore(),this.settore)) {
				return false;
			}
            if(!stringHandler.checkForEquality(attributiTramiteAZView.getAROB(), this.aROB)) {
				return false;
			}
            if(!stringHandler.checkForEquality(attributiTramiteAZView.getEROB(), this.eROB)) {
				return false;
			}
            return true;
        } else {
            return false;
        }
    }

	
	
    
    public int hashCode() {
		return super.hashCode();
	}

    public Object clone() {
		try {
			return super.clone();
		} catch (final CloneNotSupportedException e) {
			final AttributiTramiteAZView attributiTramiteView = new AttributiTramiteAZView();
			attributiTramiteView.setSoggettoId(this.soggettoId);
			attributiTramiteView.setNazioneNome(this.nazioneNome);
			attributiTramiteView.setNazioneView(this.nazioneView);
			attributiTramiteView.setSettore(this.settore);
			attributiTramiteView.setAROB(this.aROB);
			attributiTramiteView.setEROB(this.eROB);
			attributiTramiteView.setOpId(this.opId);
			attributiTramiteView.setTipoSoggettoDesc(this.tipoSoggettoDesc);
			attributiTramiteView.setId(this.id);
			return attributiTramiteView;
		}
	}

	private Long soggettoId;
	private String tipoSoggettoDesc;
	private String nazioneNome;
	private INazioneView nazioneView;
	private String settore;
	private Long aROB;
	private Long eROB;
	private Long opId;
	private Long id;



}
