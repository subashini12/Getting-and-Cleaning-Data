package it.sella.anagrafe;

/**
 * @author GBS03447
 *
 */
public class DAIWeightageException extends AnagrafeDAIException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DAIWeightageException() {
		// Explicit Empty Constructor
	}

	public DAIWeightageException(final String errMessage) {
		super(errMessage);
	}

	public DAIWeightageException(final String errMessage, final Throwable cause) {
		super(errMessage, cause);
	}

}
