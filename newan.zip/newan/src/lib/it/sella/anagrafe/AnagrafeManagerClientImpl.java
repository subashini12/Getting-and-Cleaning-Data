package it.sella.anagrafe;

import it.sella.anagrafe.az.DatiAnagraficiAZView;
import it.sella.anagrafe.implementation.AnagrafeManager;
import it.sella.anagrafe.implementation.AnagrafeManagerHome;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.anagrafe.view.SoggettoView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Properties;

import javax.ejb.CreateException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

/**
 * This is a wrapper class for AnagrafeManager Session Bean. It contains all the methods as present in AnagrafeManager
 * @since 2.0
 */
public class AnagrafeManagerClientImpl implements Serializable {

    /**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private AnagrafeManager anagrafeManager = null;
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AnagrafeManagerClientImpl.class);

    public void init() throws AnagrafeManagerException, RemoteException {
        try {
            if( anagrafeManager == null ) {
                anagrafeManager = getAnagrafeManagerHome().create();
            }
        } catch(final NamingException ne) {
        	log4Debug.warnStackTrace(ne);
            throw new AnagrafeManagerException(ne.getLocalizedMessage());
        } catch(final CreateException ce) {
        	log4Debug.warnStackTrace(ce);
            throw new AnagrafeManagerException(ce.getLocalizedMessage());
        }
    }

    /**
     * This invokes the performCensimento in the AnagrafeManagerBean and
     * does the censito of the soggetto
     * @param soggettoView
     * @exception OperazioneCensimentoException
     * @exception RemoteException
     * @return Long soggettoId
     * @see AnagrafeManager
     */
    public Long performCensimento( final SoggettoView soggettoView ) throws OperazioneCensimentoException, RemoteException {
        try {
            return getAnagrafeManager().performCensimento(soggettoView);
        } catch(final AnagrafeManagerException ame) {
            log4Debug.severeStackTrace(ame);
            throw new OperazioneCensimentoException(ame.getMessage());
        }
    }

    /**
     * This invokes the performCensimentoModifica in the AnagrafeManagerBean
     * does the modification of the data of the soggetto
     * @param soggettoView
     * @exception OperazioneCensimentoException
     * @exception RemoteException
     * @see AnagrafeManager
     */

    public void performCensimentoModifica( final SoggettoView soggettoView ) throws OperazioneCensimentoException, RemoteException {
        try {
            getAnagrafeManager().performCensimentoModifica(soggettoView);
        } catch(final AnagrafeManagerException ame) {
            log4Debug.severeStackTrace(ame);
            throw new OperazioneCensimentoException(ame.getMessage());
        }
    }

    /**
     * This invokes the ricerca in the AnagrafeManagerBean
     * @param properties
     * @exception RicercaPFException
     * @exception RemoteException
     * @return java.util.Collection
     * @see AnagrafeManager
     */

    public Collection ricerca( final Properties properties ) throws RicercaPFException, RemoteException {
        try {
            return getAnagrafeManager().ricerca(properties);
        } catch(final AnagrafeManagerException ame) {
            log4Debug.severeStackTrace(ame);
            throw new RicercaPFException(ame.getMessage());
        }
    }

    /**
     * This invokes the getSoggetto in the AnagrafeManagerBean
     * @param soggettoId
     * @param properties
     * @exception RemoteException
     * @return SoggettoView
     * @see AnagrafeManager
     */

    public SoggettoView getSoggetto( final Long soggettoId, final Properties properties ) throws RemoteException {
        try {
            return getAnagrafeManager().getSoggetto(soggettoId, properties);
        } catch(final AnagrafeManagerException exception) {
            log4Debug.severeStackTrace(exception);
            throw new RemoteException(exception.getMessage());
        }
    }

    /**
     * @param xmlSoggetto  An xml data containing the soggetto details.
     * @exception OperazioneCensimentoException
     * @exception RemoteException
     * @return String : An xml data containing the soggetto id. The xml structure is as follows:
     * <?xml version='1.0' encoding='UTF-8'?>
     * <RISPOSTA>
     * <ESITO>0</ESITO>
     * <SOGGETTO_ID>1001</SOGGETTO_ID>
     * </RISPOSTA>
     * The below elements is being removed from the xml structure because the indirizzo id is not being returned to
     * the sub systems:
     *  <IRE_ID>1002</IRE_ID>
     *  <IDO_ID>1003</IDO_ID>
     *  <IPO_ID>1004</IPO_ID>
     * @see AnagrafeManagerFactory
     */

    /**
     * @deprecated This service is deprecated, and will be removed on 31-12-2009. Instead the method
     * createSoggetto(String xmlSoggetto) available in the same interface can be used.
     */

    public String createSoggetto( final String xmlSoggetto ) throws OperazioneCensimentoException, RemoteException {
        try {
            return getAnagrafeManager().createSoggetto(xmlSoggetto);
        } catch(final AnagrafeManagerException ame) {
            log4Debug.severeStackTrace(ame);
            throw new OperazioneCensimentoException(ame.getMessage());
        }
    }

    /**
     * @param xmlSoggetto  An xml data containing the soggetto details.
     * @exception OperazioneCensimentoException
     * @exception RemoteException
     * @return String : An xml data containing the soggetto id. The xml structure is as follows:
     * <?xml version='1.0' encoding='UTF-8'?>
     * <RISPOSTA>
     * <ESITO>0</ESITO>
     * <SOGGETTO_ID>1001</SOGGETTO_ID>
     * </RISPOSTA>
     */

    /**
     * @deprecated This service is deprecated, and will be removed on 31-12-2009. Instead the method
     * creaSoggettoXMLWithHost(String xmlSoggetto) available in the same interface can be used.
     */

    public String createSoggettoWithHost( final String xmlSoggetto ) throws OperazioneCensimentoException, RemoteException {
        try {
            return getAnagrafeManager().createSoggettoWithHost(xmlSoggetto);
        } catch(final AnagrafeManagerException ame) {
            log4Debug.severeStackTrace(ame);
            throw new OperazioneCensimentoException(ame.getMessage());
        }
    }

/**
 * This method to create soggetto with host through the xml and the dati privacy only five level.
 * @param xmlSoggetto
 * @return
 * @throws OperazioneCensimentoException
 * @throws RemoteException
 */
    public String creaSoggettoXML( final String xmlSoggetto ) throws OperazioneCensimentoException, RemoteException {
        try {
            return getAnagrafeManager().creaSoggettoXML(xmlSoggetto);
        } catch(final AnagrafeManagerException ame) {
            log4Debug.severeStackTrace(ame);
            throw new OperazioneCensimentoException(ame.getMessage());
        }
    }

/**
 * This method to create soggetto through the xml and the dati privacy only five level.
 * @param xmlSoggetto
 * @return
 * @throws OperazioneCensimentoException
 * @throws RemoteException
 */
    public String creaSoggettoXMLWithHost( final String xmlSoggetto ) throws OperazioneCensimentoException, RemoteException {
    	try {
            return getAnagrafeManager().creaSoggettoXMLWithHost(xmlSoggetto);
        } catch(final AnagrafeManagerException ame) {
            log4Debug.severeStackTrace(ame);
            throw new OperazioneCensimentoException(ame.getMessage());
        }
    }

    public String validateSoggettoXML( final String xmlSoggetto ) throws OperazioneCensimentoException, RemoteException {
    	try {
            return getAnagrafeManager().validateSoggettoXML(xmlSoggetto);
        } catch(final AnagrafeManagerException ame) {
            log4Debug.severeStackTrace(ame);
            throw new OperazioneCensimentoException(ame.getMessage());
        }
    }

    public String variaSoggettoXML( final String xmlSoggetto , final Long soggettoId ) throws OperazioneCensimentoException, RemoteException {
    	try {
            return getAnagrafeManager().variaSoggettoXML(xmlSoggetto , soggettoId);
        } catch(final AnagrafeManagerException ame) {
            log4Debug.severeStackTrace(ame);
            throw new OperazioneCensimentoException(ame.getMessage());
        }
    }

    public String variaSoggettoXMLCompleto(final String xmlSoggetto, final Long soggettoId) throws OperazioneCensimentoException, RemoteException {
    	try {
            return getAnagrafeManager().variaSoggettoXMLCompleto(xmlSoggetto, soggettoId);
        } catch(final AnagrafeManagerException ame) {
            log4Debug.severeStackTrace(ame);
            throw new OperazioneCensimentoException(ame.getMessage());
        }
    }
    public String creaSoggettoXMLWithXSDValidation(final String xmlSoggetto) throws OperazioneCensimentoException, RemoteException{
    	try {
            return getAnagrafeManager().creaSoggettoXMLWithXSDValidation(xmlSoggetto);
        } catch(final AnagrafeManagerException ame) {
            log4Debug.severeStackTrace(ame);
            throw new OperazioneCensimentoException(ame.getMessage());
        }
    }
    public String creaSoggettoXMLWithHostWithXSDValidation( final String xmlSoggetto ) throws OperazioneCensimentoException, RemoteException{
    	try {
            return getAnagrafeManager().creaSoggettoXMLWithHostWithXSDValidation(xmlSoggetto);
        } catch(final AnagrafeManagerException ame) {
            log4Debug.severeStackTrace(ame);
            throw new OperazioneCensimentoException(ame.getMessage());
        }
    }
    public String variaSoggettoXMLWithXSDValidation( final String xmlSoggetto , final Long soggettoId ) throws OperazioneCensimentoException, RemoteException{
    	try {
            return getAnagrafeManager().variaSoggettoXMLWithXSDValidation(xmlSoggetto,soggettoId);
        } catch(final AnagrafeManagerException ame) {
            log4Debug.severeStackTrace(ame);
            throw new OperazioneCensimentoException(ame.getMessage());
        }
    }
    public String variaSoggettoXMLCompletoWithXSDValidation( final String xmlSoggetto , final Long soggettoId ) throws OperazioneCensimentoException, RemoteException{
    	try {
            return getAnagrafeManager().variaSoggettoXMLCompletoWithXSDValidation(xmlSoggetto,soggettoId);
        } catch(final AnagrafeManagerException ame) {
            log4Debug.severeStackTrace(ame);
            throw new OperazioneCensimentoException(ame.getMessage());
        }
    }
    public String validateSoggettoXMLWithXSDValidation( final String xmlSoggetto ) throws OperazioneCensimentoException, RemoteException{
    	try {
            return getAnagrafeManager().validateSoggettoXMLWithXSDValidation(xmlSoggetto);
        } catch(final AnagrafeManagerException ame) {
            log4Debug.severeStackTrace(ame);
            throw new OperazioneCensimentoException(ame.getMessage());
        }
    }

    /**
    * This method has to be invoked using
    * AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().updateEventiEDipct()
    * This method is used to update eventi and dipct for a list of soggettos by reading from a file
    * using flussi
    */

    public void updateEventiEDipct() throws OperazioneAnagrafeManagerException, RemoteException {
        try {
            this.getAnagrafeManager().updateEventiEDipct();
        } catch(final AnagrafeManagerException e) {
            throw new OperazioneAnagrafeManagerException(e.getMessage());
        }
    }

    public Collection ricercaAZDenominazione(final Properties properties)
			throws RicercaException, RemoteException {
        try {
            return getAnagrafeManager().ricercaAZDenominazione(properties);
        } catch(final AnagrafeManagerException ame) {
            log4Debug.severeStackTrace(ame);
            throw new RicercaException(ame.getMessage());
        }
    }

    public Collection ricercaAZDenominazioneSuccursale(final Properties properties,
			final String codiceSuccursale) throws RicercaException, RemoteException {
        try {
            return getAnagrafeManager().ricercaAZDenominazioneSuccursale(properties,codiceSuccursale);
        } catch(final AnagrafeManagerException ame) {
            log4Debug.severeStackTrace(ame);
            throw new RicercaException(ame.getMessage());
        }
    }
    public String creaSoggettoXMLForBPAAutoCens( final String xmlSoggetto ) throws OperazioneCensimentoException, RemoteException{
    	try {
            return getAnagrafeManager().creaSoggettoXMLForBPAAutoCens(xmlSoggetto);
        } catch(final AnagrafeManagerException ame) {
            log4Debug.severeStackTrace(ame);
            throw new OperazioneCensimentoException(ame.getMessage());
        }
    }
    public Long createSellaLifeCustomer(final Long mainSoggettoId, final DatiAnagraficiAZView datiAnagraficiAZView) throws OperazioneCensimentoException, RemoteException {
    	try {
            return getAnagrafeManager().createSellaLifeCustomer(mainSoggettoId, datiAnagraficiAZView);
        } catch(final AnagrafeManagerException ame) {
            log4Debug.severeStackTrace(ame);
            throw new OperazioneCensimentoException(ame.getMessage());
        }
    }
    public AnagrafeManager getAnagrafeManager() throws AnagrafeManagerException, RemoteException {
        if( anagrafeManager == null ) {
        	init();
        }
        return anagrafeManager;
    }

    public AnagrafeManagerHome getAnagrafeManagerHome() throws NamingException {
        final Context context = getContext();
        return (AnagrafeManagerHome) PortableRemoteObject.narrow(context.lookup("it.sella.anagrafe.AnagrafeManagerHome"), AnagrafeManagerHome.class);
    }

    private Context getContext() throws NamingException {
        return new InitialContext();
    }
}
