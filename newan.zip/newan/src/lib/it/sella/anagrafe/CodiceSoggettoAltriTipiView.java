package it.sella.anagrafe;

import java.io.Serializable;

public class CodiceSoggettoAltriTipiView extends ASView implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String getAbi() {
        return abi;
    }

    public void setAbi(final String abi) {
        this.abi = abi;
    }

    public String getCab() {
        return cab;
    }

    public void setCab(final String cab) {
        this.cab = cab;
    }

    public String getSwift() {
        return swift;
    }

    public void setSwift(final String swift) {
        this.swift = swift;
    }

    public String getCodsu() {
        return codsu;
    }

    public void setCodsu(final String codsu) {
        this.codsu = codsu;
    }

    public String getCdr() {
        return cdr;
    }

    public void setCdr(final String cdr) {
        this.cdr = cdr;
    }

    public String getNdg() {
        return ndg;
    }

    public void setNdg(final String ndg) {
        this.ndg = ndg;
    }

    public String getCodtr() {
        return codtr;
    }

    public void setCodtr(final String codtr) {
        this.codtr = codtr;
    }

    public String getAcrnm() {
        return acrnm;
    }

    public void setAcrnm(final String acrnm) {
        this.acrnm = acrnm;
    }

    public String getCodArea() {
        return this.codArea;
    }

    public void setCodArea(final String codArea) {
        this.codArea = codArea;
    }

    public String getCodtp() {
        return codtp;
    }

    public void setCodtp(final String codtp) {
        this.codtp = codtp;
    }

    private String abi;
    private String cab;
    private String swift;
    private String codsu;
    private String cdr;
    private String ndg;
    private String codtr;
    private String acrnm;
    private String codArea;
    private String codtp;
}
