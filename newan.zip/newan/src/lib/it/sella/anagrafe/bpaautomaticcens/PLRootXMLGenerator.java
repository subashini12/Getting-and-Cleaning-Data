package it.sella.anagrafe.bpaautomaticcens;

import it.sella.anagrafe.AnagrafeManagerFactory;
import it.sella.anagrafe.pl.AttributiEsterniPLView;
import it.sella.anagrafe.soaservices.util.SetXMLHandler;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.SoggettiPromotoreException;
import it.sella.anagrafe.view.PersonaFisicaView;
import it.sella.anagrafe.view.PlurintestazioneView;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Properties;

public class PLRootXMLGenerator extends SetXMLHandler{
	
	final DateHandler dateHandler = new DateHandler();
	
	public String getXMLForBPAAutomaticCens(final PlurintestazioneView plurintestazioneView,final Long sogeetoId) throws RemoteException, SoggettiPromotoreException{
		final StringBuilder censimentoRootXML = new StringBuilder("<SOGGETTO_BPA>");
		setUserDeatails(censimentoRootXML, plurintestazioneView.getAttributiEsterniPLView());
		censimentoRootXML.append("<SOGGETTO_XML_LIST>");
		setCollegateSoggettoData(censimentoRootXML, plurintestazioneView.getSoggettoIds());
		setMainSoggettoData(censimentoRootXML, plurintestazioneView);
		censimentoRootXML.append("</SOGGETTO_XML_LIST>");
		censimentoRootXML.append("</SOGGETTO_BPA>");
		return censimentoRootXML.toString();
	}
	
	private void setUserDeatails(final StringBuilder censimentoRootXML,final AttributiEsterniPLView attributiEsterniPLView){
		censimentoRootXML.append(getTagWithValueCheck("TipoSoggetto", "PL"));
		if(attributiEsterniPLView != null){
			censimentoRootXML.append("<PLURINTESTAZIONE>");
			censimentoRootXML.append(getTagWithValueCheck("INTESTAZIONE",attributiEsterniPLView.getInstr()));
			censimentoRootXML.append("</PLURINTESTAZIONE>");
		}
	}
	
	private void setCollegateSoggettoData(final StringBuilder censimentoRootXML,final Collection<Long> intestarioIds) throws RemoteException, SoggettiPromotoreException{
		PersonaFisicaView personaFisicaView= null;
		if(intestarioIds!= null && !intestarioIds.isEmpty()){
			final Properties properties = new Properties();
			for (final Long intestarioId : intestarioIds) {
				censimentoRootXML.append("<SOGGETTO_XML>");
				personaFisicaView = (PersonaFisicaView)AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().getSoggetto(intestarioId, properties);
				censimentoRootXML.append(new PFCensimentoXMLGenerator().getCensimentoXML(personaFisicaView, intestarioId,true));
				censimentoRootXML.append("</SOGGETTO_XML>");
			}
		}
		
	}
	private void setMainSoggettoData(final StringBuilder censimentoRootXML,final PlurintestazioneView plurintestazioneView) throws RemoteException, SoggettiPromotoreException{
				censimentoRootXML.append("<SOGGETTO_XML>");
				censimentoRootXML.append(new PLCensimentoXMLGenerator().getCensimentoXML(plurintestazioneView, plurintestazioneView.getId(),false));
				censimentoRootXML.append("</SOGGETTO_XML>");
	}
	
}
