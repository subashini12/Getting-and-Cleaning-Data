package it.sella.anagrafe.bpaautomaticcens;

import it.sella.anagrafe.CollegamentoView;
import it.sella.anagrafe.GestoreCollegamentoException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.dao.ISoggettiPromotoreDAO;
import it.sella.anagrafe.dbaccess.CollegamentoDBAccessHelper;
import it.sella.anagrafe.factory.SoggettiPromotoreDAOFactory;
import it.sella.anagrafe.sm.admin.AdminConstants;
import it.sella.anagrafe.sm.censimentoautomaticoadmin.CensimentoAutomaticoHelper;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.DBPersonaleHandler;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.anagrafe.util.SoggettiPromotoreException;
import it.sella.anagrafe.view.AziendaView;
import it.sella.anagrafe.view.PersonaFisicaView;
import it.sella.anagrafe.view.PlurintestazioneView;
import it.sella.anagrafe.view.SoggettiPromtoreView;
import it.sella.anagrafe.view.SoggettoView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;

public class SoggettiPromtoreUtil {
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(SoggettiPromtoreUtil.class);
	public void setSoggettiPromtore(final SoggettoView soggettoView,final boolean isVaria) throws SoggettiPromotoreException {
		SoggettiPromtoreView soggettiPromtoreView = null;
		if ( soggettoView instanceof AziendaView ) {
			soggettiPromtoreView = ((AziendaView)soggettoView).getSoggettiPromtoreView();
        } else if ( soggettoView instanceof PersonaFisicaView ) {
        	soggettiPromtoreView = ((PersonaFisicaView)soggettoView).getSoggettiPromtoreView();
        } else if( soggettoView instanceof PlurintestazioneView ) {
        	soggettiPromtoreView = ((PlurintestazioneView)soggettoView).getSoggettiPromtoreView();
        }
		String errorMessage = null;
		try{
			if(soggettiPromtoreView != null){
				final ISoggettiPromotoreDAO promotoreDAO = (ISoggettiPromotoreDAO) SoggettiPromotoreDAOFactory.getInstance().getSoggettiPromotoreDAOFactoryFinder();
				soggettiPromtoreView.setSoggettoId(soggettoView.getId());
				soggettiPromtoreView.setOpId(soggettoView.getOpId());
				soggettiPromtoreView.setBankId(SecurityHandler.getLoginBancaId());
				soggettiPromtoreView.setStato(AdminConstants.IN_ATTESTA_DI_CONFERMA);
				if(!isVaria){
					promotoreDAO.insertSoggettiPromotore(soggettiPromtoreView, null);
				}else{
					final Collection<SoggettiPromtoreView> soggettiPromtoreOldViews = promotoreDAO.getSoggettiPromotore4SoggettoId(soggettoView.getId());
					SoggettiPromtoreView soggettiPromtoreOldView = null;
					if(soggettiPromtoreOldViews != null && !soggettiPromtoreOldViews.isEmpty()){
							soggettiPromtoreOldView = soggettiPromtoreOldViews.iterator().next();
					}
					if(soggettiPromtoreOldView == null){
						promotoreDAO.insertSoggettiPromotore(soggettiPromtoreView, null);
					}else{
						soggettiPromtoreView.setId(soggettiPromtoreOldView.getId());
						if(AdminConstants.CENSITO.equals(soggettiPromtoreOldView.getStato())){
							soggettiPromtoreView.setStato(soggettiPromtoreOldView.getStato());
						}
						promotoreDAO.updateSoggettiPromotore(soggettiPromtoreView, null);
					}
				}

			}
		}catch (final SoggettiPromotoreException e) {
			log4Debug.debugStackTrace(e);
			errorMessage = e.getMessage();
			throw new SoggettiPromotoreException(e);
		} catch (final SubSystemHandlerException e) {
			log4Debug.debugStackTrace(e);
			errorMessage = e.getMessage();
			throw new SoggettiPromotoreException(e);
		}finally{
			if(soggettiPromtoreView != null)
			{
				new CensimentoAutomaticoHelper().setSecurityLog("PREPARE AUTOMATIC CENSIMENTO XML FOR BPA", "ANAG-SOPRO-ORIG-CRE", errorMessage == null ? true : false, errorMessage, soggettiPromtoreView, null);
			}
		}
	}

	public void replaceDefaultDipctLink(final Long soggettoId,final Long opId) throws SoggettiPromotoreException, RemoteException{
		try{
			final CollegamentoDBAccessHelper dbAccessHelper = new CollegamentoDBAccessHelper();
			final Collection<CollegamentoView> linkedDipctColl = dbAccessHelper.getLinkedSoggetto(soggettoId, "DIPCT");
			if(linkedDipctColl != null && !linkedDipctColl.isEmpty()){
				final Long defaultDipenId = DBPersonaleHandler.getSoggettoIdFromCoddp(CommonPropertiesHandler.getValueFromProperty("BPA_DEFAULT_DIP_CODE"));
				final Long loginSoggettoId = SecurityHandler.getLoginSoggettoId();
				log4Debug.debug("SoggettiPromtoreUtil : replaceDefaultDipctLink : defaultDipenId ===>",defaultDipenId);
				log4Debug.debug("SoggettiPromtoreUtil : replaceDefaultDipctLink : loginSoggettoId ===>",loginSoggettoId);
				for (final CollegamentoView collegamentoView : linkedDipctColl) {
					log4Debug.debug("SoggettiPromtoreUtil : replaceDefaultDipctLink : LinkedSoggettoId ===>",collegamentoView.getLinkedSoggettoId());
					if(collegamentoView.getLinkedSoggettoId().equals(defaultDipenId) && !loginSoggettoId.equals(defaultDipenId)){
						//dbAccessHelper.replaceCollegamento(defaultDipenId, loginSoggettoId, "DIPCT", opId);
						dbAccessHelper.replaceCollegamento(defaultDipenId, loginSoggettoId, "DIPCT", opId,soggettoId);
					}
				}
			}
		}catch (final GestoreCollegamentoException e) {
			log4Debug.debugStackTrace(e);
			throw new SoggettiPromotoreException(e);
		} catch (final SubSystemHandlerException e) {
			log4Debug.debugStackTrace(e);
			throw new SoggettiPromotoreException(e);
		}



	}

}
