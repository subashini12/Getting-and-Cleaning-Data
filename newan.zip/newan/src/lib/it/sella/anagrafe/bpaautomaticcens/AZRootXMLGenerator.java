package it.sella.anagrafe.bpaautomaticcens;

import it.sella.anagrafe.AnagrafeManagerFactory;
import it.sella.anagrafe.az.CollegateAZView;
import it.sella.anagrafe.az.DatiAnagraficiAZView;
import it.sella.anagrafe.util.SoggettiPromotoreException;
import it.sella.anagrafe.view.AziendaView;
import it.sella.anagrafe.view.PersonaFisicaView;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Properties;

public class AZRootXMLGenerator extends CensimentoXMLGenerator{
		
	public String getXMLForBPAAutomaticCens(final AziendaView aziendaView,final Long sogeetoId) throws RemoteException, SoggettiPromotoreException{
		final StringBuilder censimentoRootXML = new StringBuilder("<SOGGETTO_BPA>");
		setUserDeatails(censimentoRootXML, aziendaView);
		censimentoRootXML.append("<SOGGETTO_XML_LIST>");
		setCollegateSoggettoData(censimentoRootXML, aziendaView.getCollegateViews());
		setMainSoggettoData(censimentoRootXML, aziendaView);
		censimentoRootXML.append("</SOGGETTO_XML_LIST>");
		censimentoRootXML.append("</SOGGETTO_BPA>");
		return censimentoRootXML.toString();
	}
	
	private void setUserDeatails(final StringBuilder censimentoRootXML,final AziendaView aziendaView){
		censimentoRootXML.append(getTagWithValueCheck("TipoSoggetto", "AZ"));
		final DatiAnagraficiAZView datiAnagraficiAZView = aziendaView.getDatiAnagraficiAZView();
		censimentoRootXML.append("<AZIENDA>");
			censimentoRootXML.append(getTagWithValueCheckWithCDATATag("DENOMINAZIONE", datiAnagraficiAZView != null ?datiAnagraficiAZView.getDenominazione() : ""));
			censimentoRootXML.append(getTagWithValueCheckWithCDATATag("AZ_TIPO_SOGGETTO", aziendaView.getTipoSoggettoDesc()));
			censimentoRootXML.append(getTagWithValueCheckWithCDATATag("AZ_TIPO_SOCIETA", aziendaView.getAttributiEsterniAZView()!= null && aziendaView.getAttributiEsterniAZView().getTipsoc() != null ?aziendaView.getAttributiEsterniAZView().getTipsoc().getDescrizione() : null ));
			censimentoRootXML.append(getTagWithValueCheck("DATA_CONSTITUZIONE", dateHandler.getDateSpecifiedFormat(datiAnagraficiAZView != null ? datiAnagraficiAZView.getDataDiCostituzione() : null, "dd/MM/yyyy")));
			censimentoRootXML.append(getTagWithValueCheck("PARTATIVA", aziendaView.getDatiFiscaliAZView() != null ? aziendaView.getDatiFiscaliAZView().getPartitaIva() : "" ));
		
		censimentoRootXML.append("</AZIENDA>");
	}
	
	private void setCollegateSoggettoData(final StringBuilder censimentoRootXML,final Collection<CollegateAZView> collegateAZViews) throws RemoteException, SoggettiPromotoreException{
		PersonaFisicaView personaFisicaView= null;
		if(collegateAZViews!= null && !collegateAZViews.isEmpty()){
			final Properties properties = new Properties();
			for (final CollegateAZView collegateAZView : collegateAZViews) {
				censimentoRootXML.append("<SOGGETTO_XML>");
				personaFisicaView = (PersonaFisicaView)AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().getSoggetto(collegateAZView.getId(), properties);
				censimentoRootXML.append(new PFCensimentoXMLGenerator().getCensimentoXML(personaFisicaView, collegateAZView.getId(),true));
				censimentoRootXML.append("</SOGGETTO_XML>");
			}
		}
		
	}
	private void setMainSoggettoData(final StringBuilder censimentoRootXML,final AziendaView aziendaView) throws RemoteException, SoggettiPromotoreException{
				censimentoRootXML.append("<SOGGETTO_XML>");
				censimentoRootXML.append(new AZCensimentoXMLGenerator().getCensimentoXML(aziendaView, aziendaView.getId(),false));
				censimentoRootXML.append("</SOGGETTO_XML>");
	}
	
	
}
