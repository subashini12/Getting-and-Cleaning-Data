package it.sella.anagrafe.bpaautomaticcens;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.anagrafe.GestoreDatiFiscaliException;
import it.sella.anagrafe.dbaccess.DatiFiscaliDBAccessHelper;
import it.sella.anagrafe.pf.DatiFiscaliPFView;
import it.sella.anagrafe.pl.AttributiEsterniPLView;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.SoggettiPromotoreException;
import it.sella.anagrafe.view.PlurintestazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.HashMap;

public class PLCensimentoXMLGenerator extends CensimentoXMLGenerator{
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(PLCensimentoXMLGenerator.class);
	
	public String getCensimentoXML(final PlurintestazioneView plurintestazioneView,final Long soggettoId, final boolean isForGollegate) throws SoggettiPromotoreException, RemoteException{
		try {
			final StringBuilder censimentoXML = new StringBuilder("<SOGGETTI>");
			censimentoXML.append("<SOGGETTO TipoSoggetto=\"Plurintestazione\">");
			setIntestariaData(censimentoXML, plurintestazioneView);
			setAttributiEsterniData(censimentoXML,plurintestazioneView.getAttributiEsterniPLView());
			setRecapitiData(censimentoXML, plurintestazioneView.getRecapitiPLView());
			setCanalePreferitoData(censimentoXML, plurintestazioneView.getCanalePreferitoDataview());
			setBankCollegamentiData(censimentoXML, plurintestazioneView.getMotiv(),CommonPropertiesHandler.getValueFromProperty("BPA_BANK_NAME"));
			setPromotoreData(censimentoXML, plurintestazioneView.getPromotoreIds(),plurintestazioneView.getIntermediariViews(),isForGollegate);
			setOrgineClinteData(censimentoXML, plurintestazioneView.getOrgcl());
			setDatiFiscaliData(censimentoXML,plurintestazioneView.getDatiFiscaliPFView());
			censimentoXML.append("</SOGGETTO></SOGGETTI>");
			log4Debug.debug("PLCensimentoXMLGenerator : getCensimentoXML : censimentoXML==>",censimentoXML);
		return censimentoXML.toString();
		} catch (final GestoreCodiciSoggettoException e) {
			log4Debug.debugStackTrace(e);
			throw new SoggettiPromotoreException(e);
		} catch (final GestoreAnagrafeException e) {
			log4Debug.debugStackTrace(e);
			throw new SoggettiPromotoreException(e);
		} 
		
	}
	
	/*private void setDatiAnagrafiData(final StringBuilder censimentoXML,final AttributiEsterniPLView attributiEsterniPLView){
	
		if(attributiEsterniPLView != null){
			censimentoXML.append("<PLURINTESTAZIONE>");
			censimentoXML.append(getTagWithValueCheck("INTESTAZIONE",attributiEsterniPLView.getInstr()));
			censimentoXML.append("</PLURINTESTAZIONE>");
		}
	}*/

	private void setAttributiEsterniData(final StringBuilder censimentoXML,final AttributiEsterniPLView attributiEsterniPLView){
		if(attributiEsterniPLView != null){
			censimentoXML.append("<ATTRIBUTI_ESTERNI>");
			final String intestazioneString = attributiEsterniPLView.getInstr();
			if(intestazioneString != null){
				final String intestazioneStringArr[] = intestazioneString.split(";");
				censimentoXML.append(getTagWithValueCheck("PRIMARIGAINTESTAZIONE",intestazioneStringArr[0]));
				if(intestazioneStringArr.length >1){
					censimentoXML.append(getTagWithValueCheck("SECONDRIGAINTESTAZIONE",intestazioneStringArr[1]));	
				}
			}
			censimentoXML.append("</ATTRIBUTI_ESTERNI>");
		}
	}
	private void setIntestariaData(final StringBuilder censimentoXML,final PlurintestazioneView plurintestazioneView) throws GestoreDatiFiscaliException, RemoteException{
		final HashMap<Long, String> soggettocodiceFiscaliMap = new HashMap<Long, String>();
		String codiceFiscali = null;
		if(plurintestazioneView != null){
			censimentoXML.append("<INTESTATARI>");
			final DatiFiscaliDBAccessHelper datiFiscaliDBAccessHelper = new DatiFiscaliDBAccessHelper();
			final Collection<Long> intestarioIds = plurintestazioneView.getSoggettoIds();
			if(intestarioIds != null && !intestarioIds.isEmpty()){
				for (final Long intestarioId : intestarioIds) {
					codiceFiscali = datiFiscaliDBAccessHelper.getDatiFiscali(intestarioId, "codiceFiscali");
					if(codiceFiscali != null){
						soggettocodiceFiscaliMap.put(intestarioId, codiceFiscali);
						censimentoXML.append(getTagWithValueCheck("CODICE_FISCALE_COLLEGATE", codiceFiscali));
					}
					
				}
			}
			censimentoXML.append(getTagWithValueCheck("CODICE_FISCALE_COLLEGATE_PRINCIPALE", soggettocodiceFiscaliMap.get(plurintestazioneView.getIntestatarioPrincipale())));
			
			censimentoXML.append("</INTESTATARI>");
		}
	}
	private void setDatiFiscaliData(final StringBuilder censimentoXML,final DatiFiscaliPFView datiFiscaliPFView){
		if(datiFiscaliPFView != null){
			censimentoXML.append("<DATI_FISCALI>");
			censimentoXML.append(getTagIfValueIsNotNull("REGIME_MINIMI", datiFiscaliPFView.getRegimeDeiMinimi() != null ? datiFiscaliPFView.getRegimeDeiMinimi().toString() : null));
			censimentoXML.append(getDateTag(datiFiscaliPFView.getRegimeDataAttivazione(),"DATA_ATTIVAZIONE"));
			censimentoXML.append(getDateTag(datiFiscaliPFView.getRegimeDataRevoca(),"DATA_REVOCA"));
			censimentoXML.append("</DATI_FISCALI>");
		}
	}
	
	
	/*private void setCodiciSoggettoData(final StringBuilder censimentoXML,final CodiceSoggettoPFView codiceSoggettoPFView){
		if(codiceSoggettoPFView != null){
			setCodiciSoggettoValue(censimentoXML,"min",codiceSoggettoPFView.getMin());
			setCodiciSoggettoValue(censimentoXML,"codpr",codiceSoggettoPFView.getCodpr());
			setCodiciSoggettoValue(censimentoXML,"codlm",codiceSoggettoPFView.getCodlm());
			setCodiciSoggettoValue(censimentoXML,"codsv",codiceSoggettoPFView.getCodsv());
		}
	}*/
	
	
	private void setBankCollegamentiData(final StringBuilder censimentoXML , final Collection<String> motivCollection,final String bankName){
		if(motivCollection != null){
			if(motivCollection.contains("CLINT")){
				censimentoXML.append("<COLLEGAMENTI>");
				censimentoXML.append(getTagWithValueCheck("TIPO_COLLEGAMENTO", "CLINT"));
				censimentoXML.append(getTagWithValueCheckWithCDATATag("SOGGETTO_COLLEGANTE", bankName));
				censimentoXML.append("</COLLEGAMENTI>");
			}	
		}
	}
	/*private void setLinkedSoggettoData(final StringBuilder censimentoXML , final Collection<CollegatePFView> collegatePFViews) throws GestoreDatiFiscaliException, RemoteException{
		
		if(collegatePFViews != null){
			final DatiFiscaliDBAccessHelper datiFiscaliDBAccessHelper = new DatiFiscaliDBAccessHelper();
			for (final CollegatePFView collegatePFView : collegatePFViews) {
				if(collegatePFView != null){
					censimentoXML.append("<SOGGETTO_COLLEGAMENTI>");
					censimentoXML.append(getTagWithValueCheck("TIPO_COLLEGAMENTO", collegatePFView.getTypeOfCollegate()));
					censimentoXML.append(getTagWithValueCheck("CODICE_FISCALE_COLLEGATE", datiFiscaliDBAccessHelper.getDatiFiscali(collegatePFView.getId(), "codiceFiscali")));
					censimentoXML.append("</SOGGETTO_COLLEGAMENTI>");
				}
			}	
		}
	}*/
}
