package it.sella.anagrafe.bpaautomaticcens;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreDatiAnagrafeException;
import it.sella.anagrafe.GestoreDatiFiscaliException;
import it.sella.anagrafe.InformazioneManagerException;
import it.sella.anagrafe.az.AttributiEsterniAZView;
import it.sella.anagrafe.az.CodiceSoggettoAZView;
import it.sella.anagrafe.az.CollegateAZView;
import it.sella.anagrafe.az.DatiAnagraficiAZView;
import it.sella.anagrafe.common.Settore;
import it.sella.anagrafe.dbaccess.ClasseATECODBAccessHelper;
import it.sella.anagrafe.dbaccess.CompatibilityHelper;
import it.sella.anagrafe.dbaccess.DatiAnagraficiGetterHelper;
import it.sella.anagrafe.dbaccess.DatiFiscaliDBAccessHelper;
import it.sella.anagrafe.dbaccess.SettoreHandler;
import it.sella.anagrafe.implementation.DAPFView;
import it.sella.anagrafe.pf.DatiFiscaliPFView;
import it.sella.anagrafe.sm.censimentoaz.IAziendaConstants;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.SoggettiPromotoreException;
import it.sella.anagrafe.view.AziendaView;
import it.sella.anagrafe.view.ClienteClassificazioneView;
import it.sella.anagrafe.view.FatturatoView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Date;
import java.util.Collection;

public class AZCensimentoXMLGenerator extends CensimentoXMLGenerator{
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AZCensimentoXMLGenerator.class);
	final DateHandler dateHandler = new DateHandler();
	public String getCensimentoXML(final AziendaView aziendaView,final Long soggettoId, final boolean isForGollegate) throws SoggettiPromotoreException, RemoteException{
		try {
			final StringBuilder censimentoXML = new StringBuilder("<SOGGETTI>");
			
			final String tipoSoggetto = aziendaView.getTipoSoggettoDesc();
			censimentoXML.append("<SOGGETTO TipoSoggetto='").append(tipoSoggetto).append("'>");
			setDatiAnagrafiData(censimentoXML, aziendaView.getDatiAnagraficiAZView());
			setAttributiEsterniData(censimentoXML, aziendaView.getAttributiEsterniAZView(),tipoSoggetto);
			setFatturatoDetails(censimentoXML, aziendaView.getFatturatoView(), aziendaView.getClientClassificazioneView());
			setDatiFiscaliData(censimentoXML, aziendaView.getDatiFiscaliAZView());
			setIndirizzoData(censimentoXML, aziendaView.getIndirizziView());
			setRecapitiData(censimentoXML, aziendaView.getRecapitiView());
			setCanalePreferitoData(censimentoXML, aziendaView.getCanalePreferitoDataview());
			setDocumentData(censimentoXML, aziendaView.getDocumentiView(), soggettoId);
			setCodiciSoggettoData(censimentoXML, aziendaView.getCodiceSoggettoAZView());
			setDatiPrivacyData(censimentoXML, aziendaView.getDatiPrivacyAZFiveLevelView());
			setBankCollegamentiData(censimentoXML, aziendaView.getMotiv(),CommonPropertiesHandler.getValueFromProperty("BPA_BANK_NAME"));
			setLinkedSoggettoData(censimentoXML, aziendaView.getCollegateViews());
			setPromotoreData(censimentoXML, aziendaView.getPromotoreIds(),aziendaView.getIntermediariViews(),isForGollegate);
			setOrgineClinteData(censimentoXML, aziendaView.getOrgcl());
			censimentoXML.append("</SOGGETTO></SOGGETTI>");
			log4Debug.debug("AZCensimentoXMLGenerator : getCensimentoXML : censimentoXML==>",censimentoXML);
		return censimentoXML.toString();
		} catch (final Exception e) {
			log4Debug.debugStackTrace(e);
			throw new SoggettiPromotoreException(e);
		} 
		
	}
	
	private void setDatiAnagrafiData(final StringBuilder censimentoXML,final DatiAnagraficiAZView  datiAnagraficiAZView){
		
		if(datiAnagraficiAZView != null){
			censimentoXML.append("<DATI_ANAGRAFICI>");
			censimentoXML.append(getTagIfValueIsNotNullWithCDATATag("DENOMINAZIONE", datiAnagraficiAZView.getDenominazione()));
			censimentoXML.append( getDateTag(datiAnagraficiAZView.getDataDiCostituzione(),"DATA_DI_COSTITUZIONE"));
			censimentoXML.append(getTagWithValueCheck("NAZIONE_COSTITUZIONE", datiAnagraficiAZView.getNazioneCostituzione() != null ? datiAnagraficiAZView.getNazioneCostituzione().getNome() : ""));
			censimentoXML.append(getTagWithValueCheckWithCDATATag("CITTA_COSTITUZIONE", datiAnagraficiAZView.getCittaCostituzione() != null ? datiAnagraficiAZView.getCittaCostituzione().getCommune() : "" ));
			censimentoXML.append(getTagWithValueCheck("PROVINCIA_COSTITUZIONE", datiAnagraficiAZView.getCittaCostituzione() != null && datiAnagraficiAZView.getCittaCostituzione().getProvincia() != null  ? 
					datiAnagraficiAZView.getCittaCostituzione().getProvincia().getSigla() : ""  ));
			censimentoXML.append("</DATI_ANAGRAFICI>");
		}
	}

	private void setAttributiEsterniData(final StringBuilder censimentoXML,final AttributiEsterniAZView attributiEsterniAZView,final String tipoSoggetto) throws InformazioneManagerException, GestoreAnagrafeException, RemoteException{
		if(attributiEsterniAZView != null){
			censimentoXML.append("<ATTRIBUTI_ESTERNI>");
			final Collection allowedProperties = new CompatibilityHelper().getCompatibleAttributiEsterni(tipoSoggetto);
			if(allowedProperties != null){
				if(allowedProperties.contains("lingua")){
					censimentoXML.append(getTagIfValueIsNotNull("LINGUA",attributiEsterniAZView.getLingua() != null ? attributiEsterniAZView.getLingua().getDescrizione() : null));
				}
				if(allowedProperties.contains("settore")){
					censimentoXML.append(getTagIfValueIsNotNullWithCDATATag("SETTORE",getSettoreDesc(attributiEsterniAZView.getSettore())));
				}
				if(allowedProperties.contains("classe")){
					censimentoXML.append(getTagIfValueIsNotNullWithCDATATag("CLASSE",getClasseDesc(attributiEsterniAZView.getClasse())));
				}
				if(allowedProperties.contains("tipsoc")){
					censimentoXML.append(getTagIfValueIsNotNullWithCDATATag("TIPO_SOCIETA",attributiEsterniAZView.getTipsoc() != null ? attributiEsterniAZView.getTipsoc().getDescrizione() : null));
				}
				if(allowedProperties.contains("tsf")){
					censimentoXML.append(getTagIfValueIsNotNullWithCDATATag("TIPO_SOCIETA_FALLITA",attributiEsterniAZView.getTsf() != null ? attributiEsterniAZView.getTsf().getDescrizione() : null));
				}
				if(allowedProperties.contains("onlus")){
					censimentoXML.append(getTagIfValueIsNotNull("INDICATORE_ONLUS", attributiEsterniAZView.getOnlus() != null ? attributiEsterniAZView.getOnlus().toString() : null));
				}
				if(allowedProperties.contains("ecomm")){
					censimentoXML.append(getTagIfValueIsNotNull("INDICATORE_ENTE_COMMERCIALE", attributiEsterniAZView.getEcomm() != null ? attributiEsterniAZView.getEcomm().toString() : null));
				}
				if(allowedProperties.contains("finv")){
					censimentoXML.append(getTagIfValueIsNotNull("INDICATORE_FONDO_INVESTIMENTO", attributiEsterniAZView.getFinv() != null ? attributiEsterniAZView.getFinv().toString() : null));
				}
				if(allowedProperties.contains("fpens")){
					censimentoXML.append(getTagIfValueIsNotNull("INDICATORE_FONDO_PENSIONE", attributiEsterniAZView.getFpens() != null ? attributiEsterniAZView.getFpens().toString() : null));
				}
				if(allowedProperties.contains("tse")){
					censimentoXML.append(getTagIfValueIsNotNullWithCDATATag("TIPO_SOCIETA_ESTERA", attributiEsterniAZView.getTse() != null ? attributiEsterniAZView.getTse() : null));
				}
				censimentoXML.append(getTagIfValueIsNotNull("DAI", attributiEsterniAZView.getDai() != null ? attributiEsterniAZView.getDai().toString() : null));
				if(allowedProperties.contains("tredieci")){
					censimentoXML.append(getTagIfValueIsNotNull("TREDIECI", attributiEsterniAZView.getTredieci() != null ? attributiEsterniAZView.getTredieci().toString() : null));
				}
				censimentoXML.append(getTagWithValueCheckWithCDATATag("ALBO_PROF", attributiEsterniAZView.getAlbo_prof() != null ? attributiEsterniAZView.getAlbo_prof().getAlboDesc() : null));
				censimentoXML.append(getTagIfValueIsNotNull("NUMERO_ISCR_ALBO", attributiEsterniAZView.getNumero_di_albo() != null ? attributiEsterniAZView.getNumero_di_albo() : null));
				censimentoXML.append(getTagWithValueCheckWithCDATATag("ULT_INFO_ALBO", attributiEsterniAZView.getUlteriori_annotazioni() != null ? attributiEsterniAZView.getUlteriori_annotazioni() : null));
				censimentoXML.append(getTagIfValueIsNotNull("MONEY_TRANSFER", attributiEsterniAZView.getMoneyTransfer() != null ? attributiEsterniAZView.getMoneyTransfer().toString() : null));
				if(allowedProperties.contains("SOC_QUOTATA")) {
					censimentoXML.append(getTagIfValueIsNotNull("SOC_QUOTATA", attributiEsterniAZView.getSOC_QUOTATA() != null ? attributiEsterniAZView.getSOC_QUOTATA().toString() : null));
				}
				if(allowedProperties.contains("STARTUP")) {
					censimentoXML.append(getTagIfValueIsNotNull("START_UP_INNOVATIVA", attributiEsterniAZView.getSTARTUP() != null ? attributiEsterniAZView.getSTARTUP().toString() : null));
				}
				if(allowedProperties.contains("INC_STARTUP")) {
					censimentoXML.append(getTagIfValueIsNotNull("INCUB_START_UP_INNOVATIVA", attributiEsterniAZView.getINC_STARTUP() != null ? attributiEsterniAZView.getINC_STARTUP().toString() : null));
				}
				if(allowedProperties.contains("STARTUP_SOC")) {
					censimentoXML.append(getTagIfValueIsNotNull("START_UP_SOCIALE", attributiEsterniAZView.getSTARTUP_SOC() != null ? attributiEsterniAZView.getSTARTUP_SOC().toString() : null));
				}				
			}
			
			censimentoXML.append("</ATTRIBUTI_ESTERNI>");
		}
	}
	private String getSettoreDesc(final String codiceSottoGruppo) throws InformazioneManagerException{
		Settore settore = null;
		String settoreDesc = null;
		if(codiceSottoGruppo != null && (settore=new SettoreHandler().getSettore(codiceSottoGruppo)) != null ){
			settoreDesc=  settore.getDescrizione();
		}
		return settoreDesc;
		
	}
	private String getClasseDesc(final String classeCode ) throws InformazioneManagerException, GestoreAnagrafeException{
		String classeDesc = null;
		if(classeCode != null){
			classeDesc = new ClasseATECODBAccessHelper().getDescrizioneAteco2007(classeCode);
		}
		return classeDesc;
		
	}
	private void setDatiFiscaliData(final StringBuilder censimentoXML,final DatiFiscaliPFView datiFiscaliPFView){
		if(datiFiscaliPFView != null){
			censimentoXML.append("<DATI_FISCALI>");
			censimentoXML.append(getTagIfValueIsNotNull("PARTITA_IVA", datiFiscaliPFView.getPartitaIva()));
			censimentoXML.append(getTagIfValueIsNotNull("RESIDENZA_VALUTARIA", datiFiscaliPFView.getRzVal() != null ?datiFiscaliPFView.getRzVal().getNome(): null ));
			censimentoXML.append(getTagIfValueIsNotNull("RESIDENZA_FISCALE", datiFiscaliPFView.getResidenteFiscali() != null ?datiFiscaliPFView.getResidenteFiscali().getNome(): null ));
			censimentoXML.append(getTagIfValueIsNotNull("CODICE_FISCALE", datiFiscaliPFView.getCodiceFiscali()));
			censimentoXML.append(getTagIfValueIsNotNull("INDICATORE_RV", datiFiscaliPFView.getCertRV()!= null ? datiFiscaliPFView.getCertRV().toString() : null));
			censimentoXML.append(getTagIfValueIsNotNull("INDICATORE_A97", datiFiscaliPFView.getIndicatoreA97()!= null ? datiFiscaliPFView.getIndicatoreA97().toString() : null));
			censimentoXML.append(getTagIfValueIsNotNull("INDICATORE_A96", datiFiscaliPFView.getIndicatoreA96() != null ? datiFiscaliPFView.getIndicatoreA96().toString() : null));
			censimentoXML.append(getTagIfValueIsNotNull("CODICE_QUALIFIED_INTERMEDIARY", datiFiscaliPFView.getCodQI()));
			censimentoXML.append(getTagWithValueCheckWithCDATATag("CF_ESTERO", datiFiscaliPFView.getCdEst()));
			censimentoXML.append(getTagIfValueIsNotNull("VIES", datiFiscaliPFView.getVIES()!= null ? datiFiscaliPFView.getVIES().toString() : null));
			censimentoXML.append(getTagIfValueIsNotNull("CONFERMA_VIES", datiFiscaliPFView.getC_VIES()!= null ? datiFiscaliPFView.getC_VIES().toString() : null));
			censimentoXML.append(getTagWithValueCheckWithCDATATag("PARTITA_IVA_ESTERO", datiFiscaliPFView.getPIvaEst()));
			censimentoXML.append(getTagIfValueIsNotNull("NUMERO_SICUREZZA_SOCIALE", datiFiscaliPFView.getNumSic()));
			censimentoXML.append(getTagIfValueIsNotNull("REGIME_MINIMI", datiFiscaliPFView.getRegimeDeiMinimi() != null ? datiFiscaliPFView.getRegimeDeiMinimi().toString() : null));
			censimentoXML.append(getDateTag(datiFiscaliPFView.getRegimeDataAttivazione(),"DATA_ATTIVAZIONE"));
			censimentoXML.append(getDateTag(datiFiscaliPFView.getRegimeDataRevoca(),"DATA_REVOCA"));
			// Censimento BPA Case AZ XML Generation .. Added Altre ResidenzaFiscali Details.
			censimentoXML.append(getTagIfValueIsNotNull("RESIDENZA_FISCALE_2", datiFiscaliPFView.getResidenteFiscali2() != null ? datiFiscaliPFView.getResidenteFiscali2().getNome(): null ));
			censimentoXML.append(getTagIfValueIsNotNullWithCDATATag("CODICE_FISCALE_ESTERO_2", datiFiscaliPFView.getCdEst2()));
			censimentoXML.append(getTagIfValueIsNotNull("RESIDENZA_FISCALE_3", datiFiscaliPFView.getResidenteFiscali3() != null ? datiFiscaliPFView.getResidenteFiscali3().getNome(): null ));
			censimentoXML.append(getTagIfValueIsNotNullWithCDATATag("CODICE_FISCALE_ESTERO_3", datiFiscaliPFView.getCdEst3()));
			censimentoXML.append("</DATI_FISCALI>");
		}
	}
	private void setFatturatoDetails(final StringBuilder censimentoXML,final FatturatoView fatturatoView , final ClienteClassificazioneView classificazioneView){
		if(classificazioneView != null || fatturatoView != null ){
			censimentoXML.append("<CLASSIFICAZIONE_CLIENTELA>");
			if(fatturatoView != null){
				censimentoXML.append(getTagIfValueIsNotNull("NUMERO_DIPENDENTI", fatturatoView.getNumeroDependenti() != null && (fatturatoView.getNumeroDependentiExistAt() != null ? IAziendaConstants.ANAGRAFE_SS.equals(fatturatoView.getNumeroDependentiExistAt()) : true) ? fatturatoView.getNumeroDependenti().toString() : null));
				censimentoXML.append(getTagIfValueIsNotNull("FATTURATO", fatturatoView.getFatturato() != null && (fatturatoView.getFatturatoExistAt() != null ? IAziendaConstants.ANAGRAFE_SS.equals(fatturatoView.getFatturatoExistAt()) : true) ? fatturatoView.getFatturato().toString() : null));
				censimentoXML.append(getTagIfValueIsNotNull("BILANCIO", fatturatoView.getBilancio() != null && (fatturatoView.getBilancioExistAt() != null ? IAziendaConstants.ANAGRAFE_SS.equals(fatturatoView.getBilancioExistAt()) : true) ? fatturatoView.getBilancio().toString() : null));
			}
			if(classificazioneView != null && classificazioneView.getMicroimpresa() != null){
				censimentoXML.append(getTagIfValueIsNotNull("MICROIMPRESA", "false".equalsIgnoreCase(classificazioneView.getMicroimpresa()) ? "NO" : "SI"));
			}
			censimentoXML.append("</CLASSIFICAZIONE_CLIENTELA>");
		}
	}
	
	


	
	private void setCodiciSoggettoData(final StringBuilder censimentoXML,final CodiceSoggettoAZView codiceSoggettoAZView){
		if(codiceSoggettoAZView != null){
			setCodiciSoggettoValue(censimentoXML,"codiceCentraleRischi",codiceSoggettoAZView.getCodiceCentraleRischi());
			setCodiciSoggettoValue(censimentoXML,"ccra",codiceSoggettoAZView.getCcra());
			setCodiciSoggettoValue(censimentoXML,"ccrg",codiceSoggettoAZView.getCcrg());
			setCodiciSoggettoValue(censimentoXML,"cnr",codiceSoggettoAZView.getCnr());
			setCodiciSoggettoValue(censimentoXML,"codfo",codiceSoggettoAZView.getCodfo());
			setCodiciSoggettoValue(censimentoXML,"cce",codiceSoggettoAZView.getCce());
			setCodiciSoggettoValue(censimentoXML,"min",codiceSoggettoAZView.getMin());
			setCodiciSoggettoValue(censimentoXML,"acrnm",codiceSoggettoAZView.getAcrnm());
			setCodiciSoggettoValue(censimentoXML,"codtr",codiceSoggettoAZView.getCodtr());
			setCodiciSoggettoValue(censimentoXML,"swift",codiceSoggettoAZView.getSwift());
			setCodiciSoggettoValue(censimentoXML,"abi",codiceSoggettoAZView.getAbi());
			setCodiciSoggettoValue(censimentoXML,"codSIA",codiceSoggettoAZView.getCodSIA());
		}
	}
	
	private void setBankCollegamentiData(final StringBuilder censimentoXML , final Collection<String> motivCollection,final String bankName){
		if(motivCollection != null){
			for (final String motiv : motivCollection) {
				censimentoXML.append("<COLLEGAMENTI>");
				censimentoXML.append(getTagWithValueCheck("TIPO_COLLEGAMENTO", motiv));
				censimentoXML.append(getTagIfValueIsNotNullWithCDATATag("SOGGETTO_COLLEGANTE", bankName));
				censimentoXML.append("</COLLEGAMENTI>");
			}
		}
	}
	private void setLinkedSoggettoData(final StringBuilder censimentoXML , final Collection<CollegateAZView> collegateAZViews) throws GestoreDatiAnagrafeException, RemoteException, GestoreDatiFiscaliException{
		if(collegateAZViews != null){
			DAPFView datiAnagraficiPFView = null;
			final DatiFiscaliDBAccessHelper datiFiscaliDBAccessHelper = new DatiFiscaliDBAccessHelper();
			final DatiAnagraficiGetterHelper anagraficiGetterHelper = new DatiAnagraficiGetterHelper();
			for (final CollegateAZView collegateAZView : collegateAZViews) {
				if(collegateAZView != null){
					if(!"ABIL8CIFRE".equals(collegateAZView.getTypeOfCollegate())){
						datiAnagraficiPFView = (DAPFView)anagraficiGetterHelper.getAnagraficiView(collegateAZView.getId());
						if(datiAnagraficiPFView != null){
							censimentoXML.append("<SOGGETTO_COLLEGAMENTI>");
							censimentoXML.append(getTagWithValueCheck("TIPO_COLLEGAMENTO", collegateAZView.getTypeOfCollegate()));
							censimentoXML.append("<DATI_ANAGRAFICI>");
							censimentoXML.append(getTagIfValueIsNotNullWithCDATATag("NOME", datiAnagraficiPFView.getNome()));
							censimentoXML.append(getTagIfValueIsNotNullWithCDATATag("COGNOME", datiAnagraficiPFView.getCognome()));
							censimentoXML.append( getDateTag(datiAnagraficiPFView.getDataDiNascita(),"DATA_NASCITA"));
							censimentoXML.append(getTagIfValueIsNotNullWithCDATATag("CITTA_NASCITA", datiAnagraficiPFView.getLuogoDiNascitaCitta()));
							censimentoXML.append(getTagWithValueCheck("PROVINCIA_NASCITA", datiAnagraficiPFView.getLuogoDiNascitaCittaView() != null && datiAnagraficiPFView.getLuogoDiNascitaCittaView().getProvincia() != null  ? 
									datiAnagraficiPFView.getLuogoDiNascitaCittaView().getProvincia() : ""  ));
							censimentoXML.append(getTagWithValueCheck("NAZIONE_NASCITA", datiAnagraficiPFView.getLuogoDiNascitaNazione()));
							censimentoXML.append("</DATI_ANAGRAFICI>");
							censimentoXML.append("<DATI_FISCALI>");
							censimentoXML.append(getTagIfValueIsNotNull("CODICE_FISCALE", datiFiscaliDBAccessHelper.getDatiFiscali(collegateAZView.getId(), "codiceFiscali")));
							censimentoXML.append("</DATI_FISCALI>");
							censimentoXML.append("</SOGGETTO_COLLEGAMENTI>");
						}
					
					}
					
				}
			}	
		}
	}
	
	
	
	private String getDateTag(final Date date,final String rootTagName) {
		final StringBuilder dateBuilder = new StringBuilder();
		if (date != null) {
			final String dateStrings[] = dateHandler.getDateSpecifiedFormat(date, "dd/MM/yyyy").split("/");
			dateBuilder.append("<").append(rootTagName).append(">");
			dateBuilder.append(getTagWithValueCheck("GIORNO", dateStrings[0]));
			dateBuilder.append(getTagWithValueCheck("MESE", dateStrings[1]));
			dateBuilder.append(getTagWithValueCheck("ANNO", dateStrings[2]));
			dateBuilder.append("</").append(rootTagName).append(">");
			return dateBuilder.toString();
		}
		return dateBuilder.toString();
		
	}
	
}
