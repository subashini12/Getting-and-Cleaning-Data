package it.sella.anagrafe;

public class AddressNormalizationException extends GestoreAnagrafeException {
    
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AddressNormalizationException() {
    }

    public AddressNormalizationException( final String errorMessage ) {
        super(errorMessage);
    }
}
