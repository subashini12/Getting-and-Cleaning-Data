package it.sella.anagrafe.datiprivacyfivelevel;

import java.io.Serializable;

public interface DatiPrivacyFiveLevel extends Serializable {
	
	public Long getId();
	public void setId(Long id);
    public Long getSoggettoId();
    public void setSoggettoId(Long soggettoId);
    public String getValue1();
    public void setValue2(String value);
    public String getValue2();
    public void setValue3(String value);
    public String getValue3();
    public void setValue4(String value);
    public String getValue4();
    public void setValue5(String value);
    public String getValue5();
    public void setValue1(String value);
    public String getProfil() ;
	public void setProfil(String profil) ;
    public Long getOpId();
    public void setOpId(Long opId);
}



