package it.sella.anagrafe.datiprivacyfivelevel;



public class DatiPrivacyFiveLevelView implements DatiPrivacyFiveLevel {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public DatiPrivacyFiveLevelView() {
    }

    public Long getSoggettoId() {
        return this.soggettoId;
    }

	public Long getOpId() {
		return this.opId;
	}

    public void setSoggettoId(final Long soggettoId) {
        this.soggettoId = soggettoId;
    }

	public void setOpId(final Long opId) {
		this.opId = opId;
	}

	protected String getParameterList() {
        return "Soggetto Id" + this.getSoggettoId();
    }

    protected String getShortParameterList() {
        return getParameterList();
    }

	public String getValue1() {
		return value1;
	}

	public void setValue1(final String value1) {
		this.value1 = value1;
	}

	public String getValue2() {
		return value2;
	}

	public void setValue2(final String value2) {
		this.value2 = value2;
	}

	public String getValue3() {
		return value3;
	}

	public void setValue3(final String value3) {
		this.value3 = value3;
	}

	public String getValue4() {
		return value4;
	}

	public void setValue4(final String value4) {
		this.value4 = value4;
	}

	public String getValue5() {
		return value5;
	}

	public void setValue5(final String value5) {
		this.value5 = value5;
	}
	

	public String getProfil() {
		return profil;
	}

	public void setProfil(final String profil) {
		this.profil = profil;
	}

	private Long soggettoId;
    private String value1;
    private String value2;
    private String value3;
    private String value4;
    private String value5;
    private String profil;
    private Long opId;
    private Long id;
	
    
    public Long getId() {
    	return id;
	}

	public void setId(final Long id) {
		this.id = id;
	}



	
}


