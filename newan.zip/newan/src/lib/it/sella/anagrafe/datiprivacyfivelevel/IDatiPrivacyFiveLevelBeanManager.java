package it.sella.anagrafe.datiprivacyfivelevel;

import it.sella.anagrafe.GestoreAnagrafeException;

import java.util.Collection;

import javax.ejb.FinderException;

public interface IDatiPrivacyFiveLevelBeanManager {
	
	/**
	 * Method to create DatiPrivacyFiveLevel
	 * @param datiPrivacyPFFiveLevelView
	 * @return
	 * @throws GestoreAnagrafeException
	 */
	DatiPrivacyFiveLevel create(DatiPrivacyFiveLevel datiPrivacyPFFiveLevelView) throws GestoreAnagrafeException;
	
	/**
	 * Method to update DatiPrivacyFiveLevel
	 * @param datiPrivacyPFFiveLevelView
	 * @return
	 */
	DatiPrivacyFiveLevel update(DatiPrivacyFiveLevel datiPrivacyPFFiveLevelView);
	
	/**
	 * Method to find data using PrimaryKey
	 * @param primaryKey
	 * @return
	 * @throws FinderException
	 */
	DatiPrivacyFiveLevel findByPrimaryKey(Long primaryKey) throws FinderException;
	
	/**
	 * Method to find data using SoggettoId
	 * @param soggettoId
	 * @return
	 * @throws FinderException
	 */
	Collection<DatiPrivacyFiveLevel> findBySoggettoId(Long soggettoId) throws FinderException;
	
	/**
	 * Method to remove DatiPrivacyFiveLevel
	 * @param datiPrivacyPFFiveLevelView
	 */
	void remove(DatiPrivacyFiveLevel datiPrivacyPFFiveLevelView);
}
