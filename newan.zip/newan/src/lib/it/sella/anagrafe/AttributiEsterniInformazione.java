package it.sella.anagrafe;

import it.sella.anagrafe.common.Ramo;
import it.sella.anagrafe.common.Settore;

import java.rmi.RemoteException;
import java.util.Collection;

public interface AttributiEsterniInformazione {

    Collection listLingua() throws RemoteException;

    Collection listTitolo1() throws RemoteException;

    Collection listTitolo2() throws RemoteException;

    Collection listSesso() throws RemoteException;

    Collection listProfessione() throws RemoteException;

    Collection listStatoCivile() throws RemoteException;

    Collection listRegimePatrimoniale() throws RemoteException;

    Collection listTitoloDiStudio() throws RemoteException;

    Collection listRamo() throws InformazioneManagerException, RemoteException;

    Collection listSettore(Long tipoSoggettoId) throws InformazioneManagerException, RemoteException;

    Ramo getRamo(String codiceGruppo) throws InformazioneManagerException, RemoteException;

    Settore getSettore(String codiceSottoGruppo) throws InformazioneManagerException, RemoteException;

    Collection listAttivita() throws InformazioneManagerException, RemoteException;

    Collection listTipoSocieta() throws InformazioneManagerException, RemoteException;

}
