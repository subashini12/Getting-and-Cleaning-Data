package it.sella.anagrafe;

/**
 * @author GBS03447
 *
 */
public class DAISoggettoData implements IDAISoggettoData { // API Purpose

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long soggettoId;
	private String daiStatus;

	public Long getSoggettoId() {
		return soggettoId;
	}

	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}

	public String getDaiStatus() {
		return daiStatus;
	}

	public void setDaiStatus(final String daiStatus) {
		this.daiStatus = daiStatus;
	}
}
