package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.classificazione.ClassificazioneView;

import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class CollegamentoViewBuilder {

    protected void setCollegamentoViewListFromResultSet( final ResultSet collegamentoResultSet, final List collegamentoViewList) throws SQLException, GestoreAnagrafeException, RemoteException {
    	it.sella.anagrafe.CollegamentoView collegamentoView = null;
        while (collegamentoResultSet.next()) {
            collegamentoView = new it.sella.anagrafe.CollegamentoView();
            collegamentoView.setCollegamentoId(Long.valueOf(collegamentoResultSet.getLong("CL_ID")));
            collegamentoView.setDataFine(collegamentoResultSet.getTimestamp("CL_DATA_FINE"));
            collegamentoView.setDataInizio(collegamentoResultSet.getTimestamp("CL_DATA_INIZIO"));
            final ClassificazioneView classificazioneView = ClassificazioneHandler.getClassificazioneView(Long.valueOf(collegamentoResultSet.getLong("CL_MOTIVO")));
            collegamentoView.setMotivoCollegamento(classificazioneView.getDescrizione());
            collegamentoView.setMotivoCausale(classificazioneView.getCausale());
            collegamentoView.setLinkedSoggettoId(Long.valueOf(collegamentoResultSet.getLong("CL_LINKED_SOGGETTO")));
            collegamentoView.setSoggettoPrincipaleId(Long.valueOf(collegamentoResultSet.getLong("CL_SOGGETTO_PRINCIPALE")));
            collegamentoView.setNote(collegamentoResultSet.getString("CL_NOTE"));
            collegamentoViewList.add(collegamentoView);
        }
    }
}
