package it.sella.anagrafe.dbaccess;

import it.sella.address.AddressException;
import it.sella.anagrafe.GestoreAttributiEsterniException;
import it.sella.anagrafe.GestoreCollegamentoException;
import it.sella.anagrafe.discriminator.AttributiEsterniDiscriminatorException;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Iterator;

public class CollegatiAbilitaiDAIHandler extends DBAccessHelper {
	
    protected void updateDaiForCollegatiAbilitati(final Long soggettoId, final Long pfSoggettoId, final Long opId) throws AttributiEsterniDiscriminatorException, RemoteException, AddressException, GestoreCollegamentoException, GestoreAttributiEsterniException {
    	final AEUpdateHelper aeHelper = new AEUpdateHelper(); 
        final Collection abilitati = new CollegamentoDBAccessHelper().getSoggettiCollegatiAbilitati(soggettoId);
        if(abilitati != null) {
            final int abilitatiSize = abilitati.size();
            final Iterator abilitatiIterator = abilitati.iterator();
            final AttributiEsterniDBAccessHelper attributiEsterniDBAccessHelper = new AttributiEsterniDBAccessHelper();
            for(int k=0; k<abilitatiSize; k++) {
                final Long abilitatiId = (Long)abilitatiIterator.next();
                if(!pfSoggettoId.equals(abilitatiId)) {
                    if("true".equals(attributiEsterniDBAccessHelper.getAttribuiEsterniValore(abilitatiId, "dai"))) {
                    	aeHelper.setAttributiEsterniValues(soggettoId, "true", "dai", opId);
                        break;
                    } else if(k == (abilitatiSize-1)) {
						aeHelper.setAttributiEsterniValues(soggettoId, "false", "dai", opId);
					}
                } else if(k == (abilitatiSize-1)) {
					aeHelper.setAttributiEsterniValues(soggettoId, "false", "dai",opId);
				}
            }
        }
    }
}


