package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreAttributiEsterniException;
import it.sella.anagrafe.ISocioDetailsView;
import it.sella.anagrafe.ISocioOperationView;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.implementation.AttributiEsterniView;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.implementation.SocioOperationView;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.anagrafe.view.CronistoriaVariazioniHistoryView;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Vector;

public class AEValoreGetter extends DBAccessHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AEValoreGetter.class);

    public String getAttribuiEsterniValore(final Long soggettoId, final String causale) throws GestoreAttributiEsterniException, RemoteException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        String strReturn = null;
        ResultSet attributiRset = null;
        try {
            connection = getConnection();
            selectStatement = connection.prepareStatement("Select AE.AE_VALUE from AN_TR_ATTRIBUTIESTERNI AE,AN_TR_COLLAGAMENTO_SOGGETTO CS where CS.CL_SOGGETTO_PRINCIPALE = ? AND CS.CL_MOTIVO = ? AND CS.CL_LINKED_SOGGETTO = AE.AE_SOGGETTO_ID and AE.AE_RIGHT_PK = ? AND AE.AE_SOGGETTO_ID = ?");
            selectStatement.setLong(1, SecurityHandler.getLoginBancaId().longValue());
            selectStatement.setLong(2, getClassificazioneIdFromCausale("CENST", "MOTIV").longValue());
            selectStatement.setLong(3, getClassificazioneIdFromCausale(causale, "AEDPF").longValue());
            selectStatement.setLong(4, soggettoId.longValue());
            attributiRset = selectStatement.executeQuery();
            if (attributiRset.next() && attributiRset.getString("AE_VALUE") != null) {
                if ("lingua".equals(causale) || "tsf".equals(causale) || "firmagraf".equals(causale)||"tipsoc".equals(causale) || "regimePatrimoniale".equals(causale) || "titolo1".equals(causale) ||
                        "professione".equals(causale) || "statoCivile".equals(causale) || "sesso".equals(causale) || "titolo2".equals(causale) || "tds".equals(causale) || "bollinoBlu".equals(causale)||"settorecommerciale".equals(causale)) {
                    if (attributiRset.getLong("AE_VALUE") > 0) {
						strReturn = ClassificazioneHandler.getClassificazioneView(Long.valueOf(attributiRset.getLong("AE_VALUE"))).getDescrizione();
					}
                } else {
                    strReturn = attributiRset.getString("AE_VALUE");
                }
            }
        } catch (final SQLException sqlEx) {
            log4Debug.severeStackTrace(sqlEx);
            throw new GestoreAttributiEsterniException(sqlEx.getMessage());
        } catch (final SubSystemHandlerException crEx) {
            log4Debug.severeStackTrace(crEx);
            throw new GestoreAttributiEsterniException(crEx.getMessage());
        } finally {
            cleanup(connection, selectStatement, attributiRset);
        }
        if (soggettoId != null && "sconf".equalsIgnoreCase(causale) && strReturn == null) {
            return "true";
        } else {
			return strReturn;
		}
    }

    public Collection getValuesForTipoAttributoEsterno(final String tipoAttributiEsterniCausale) throws GestoreAttributiEsterniException, RemoteException {
        try {
            return ClassificazioneHandler.getClassificazioneViews(tipoAttributiEsterniCausale);
        } catch (final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            throw new GestoreAttributiEsterniException(e.getMessage());
        }
    }

    public Collection getAttributiEsterniAndValues(final Long soggettoId) throws GestoreAttributiEsterniException, RemoteException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        Vector attributeVector = null;
        ResultSet attributiRset = null;
        try {
            final Long bancaId = SecurityHandler.getLoginBancaId();
            final Long censtId = getClassificazioneIdFromCausale("CENST", "MOTIV");
            connection = getConnection();
            final StringBuffer query = new StringBuffer("Select  AE_VALUE, AE_RIGHT_PK from  AN_TR_ATTRIBUTIESTERNI A WHERE AE_SOGGETTO_ID = ?");
            query.append(" AND EXISTS(SELECT 1 FROM AN_TR_COLLAGAMENTO_SOGGETTO WHERE CL_SOGGETTO_PRINCIPALE = ?");
            query.append(" AND CL_MOTIVO = ? AND CL_LINKED_SOGGETTO = A.AE_SOGGETTO_ID)");
            selectStatement = connection.prepareStatement(query.toString());
            selectStatement.setLong(1, soggettoId.longValue());
            selectStatement.setLong(2, bancaId.longValue());
            selectStatement.setLong(3, censtId.longValue());
            attributiRset = selectStatement.executeQuery();
            attributeVector = new Vector();
            getAttributiEsterniViewInResultSet(attributiRset,soggettoId,attributeVector);
        } catch (final SQLException sqlEx) {
            log4Debug.severeStackTrace(sqlEx);
            throw new GestoreAttributiEsterniException(sqlEx.getMessage());
        } catch (final SubSystemHandlerException crEx) {
            log4Debug.severeStackTrace(crEx);
            throw new GestoreAttributiEsterniException(crEx.getMessage());
        } finally {
            cleanup(connection, selectStatement, attributiRset);
        }
        return attributeVector;
    }

    /* This method only used for admin application. Here only consider soggettoId not loging bank */

    public Collection getAttributiEsterniValuesBasedOnSoggetto(final Long soggettoId) throws GestoreAttributiEsterniException, RemoteException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        Vector attributeVector = null;
        ResultSet attributiRset = null;
        try {
            connection = getConnection();
            final StringBuffer query = new StringBuffer("Select  AE_VALUE, AE_RIGHT_PK from  AN_TR_ATTRIBUTIESTERNI A WHERE AE_SOGGETTO_ID = ? ");
            selectStatement = connection.prepareStatement(query.toString());
            selectStatement.setLong(1, soggettoId.longValue());
            attributiRset = selectStatement.executeQuery();
            attributeVector = new Vector();
            getAttributiEsterniViewInResultSet(attributiRset,soggettoId,attributeVector);
        } catch (final SQLException sqlEx) {
            log4Debug.severeStackTrace(sqlEx);
            throw new GestoreAttributiEsterniException(sqlEx.getMessage());
        } catch (final SubSystemHandlerException crEx) {
            log4Debug.severeStackTrace(crEx);
            throw new GestoreAttributiEsterniException(crEx.getMessage());
        } finally {
            cleanup(connection, selectStatement, attributiRset);
        }
        return attributeVector;
    }

    public List<CronistoriaVariazioniHistoryView> getCronistoriaVariazioniHistory(final Long soggettoId)throws GestoreAttributiEsterniException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		CronistoriaVariazioniHistoryView cronistoriaVariazioniHistoryView = null;
		final List<CronistoriaVariazioniHistoryView> cronisVariaHistoryList = new ArrayList<CronistoriaVariazioniHistoryView>();
		try {
			final StringBuilder query = new StringBuilder("SELECT FIRMA_VALUE,FIRMA_DATE FROM TABLE(AN_FN_FIRMA_HISTORY(?)) ");
			connection = getConnection();
			preparedStatement = connection.prepareStatement(query.toString());
			preparedStatement.setLong(1, soggettoId);

			log4Debug.debug("AEValoreGetter: getCronistoriaVariazioniHistory: query:===>>",query);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				cronistoriaVariazioniHistoryView = new CronistoriaVariazioniHistoryView();
				cronistoriaVariazioniHistoryView.setFirmaValue(resultSet.getString("FIRMA_VALUE"));
				cronistoriaVariazioniHistoryView.setOperationDate(resultSet.getString("FIRMA_DATE"));
				cronisVariaHistoryList.add(cronistoriaVariazioniHistoryView);
			}
		} catch (final SQLException sqlEx) {
			log4Debug.warnStackTrace(sqlEx);
			throw new GestoreAttributiEsterniException(sqlEx.getMessage());

		} finally {
			cleanup(connection, preparedStatement, resultSet);
		}
		return cronisVariaHistoryList;
	}
    private void getAttributiEsterniViewInResultSet(final ResultSet attributiRset,final Long soggettoId,final Collection attributeVector) throws SubSystemHandlerException,SQLException,RemoteException {
    	boolean existsSconfino = false;
        ClassificazioneView rightPKView = null;
        while (attributiRset.next()) {
        	final String aeValue = attributiRset.getString("AE_VALUE");
			if (aeValue != null && aeValue.trim().length() > 0) {
        		rightPKView = ClassificazioneHandler .getClassificazioneView(Long.valueOf(attributiRset.getLong("AE_RIGHT_PK")));
        		final AttributiEsterniView attributiEsterniView = new AttributiEsterniView();
        		attributiEsterniView.setSoggettoId(soggettoId);
        		if ("lingua".equals(rightPKView.getCausale()) || "tsf".equals(rightPKView.getCausale()) ||
        				"tipsoc".equals(rightPKView.getCausale()) || "regimePatrimoniale".equals(rightPKView.getCausale()) ||
        				"titolo1".equals(rightPKView.getCausale()) || "professione".equals(rightPKView.getCausale()) ||
        				"statoCivile".equals(rightPKView.getCausale()) || "sesso".equals(rightPKView.getCausale()) ||
        				"titolo2".equals(rightPKView.getCausale()) || "tds".equals(rightPKView.getCausale()) ||"firmagraf".equals(rightPKView.getCausale())||
        				"bollinoBlu".equals(rightPKView.getCausale())) {
        			attributiEsterniView.setValore(ClassificazioneHandler.getClassificazioneView(Long.valueOf(aeValue)).getDescrizione());
        		} else {
        			if ("sconf".equals(rightPKView.getCausale())){
        				existsSconfino = true;
        			}
        			attributiEsterniView.setValore(aeValue);
        		}
        		attributiEsterniView.setTipoAttributiEsterni(rightPKView.getDescrizione());
        		attributiEsterniView.setCausaleTipoAttributiEsterni(rightPKView.getCausale());
        		attributiEsterniView.setDescrizioneTipoAttributiEsterni(rightPKView.getDescrizione());
        		attributiEsterniView.setActualValore(aeValue);
        		attributeVector.add(attributiEsterniView);

             }
         }
        if (!existsSconfino && attributeVector != null && attributeVector.size() >= 1) {
        	final ClassificazioneView sconfView = ClassificazioneHandler.getClassificazioneView("sconf", "AEDPF");
            final AttributiEsterniView aeView = new AttributiEsterniView();
            aeView.setSoggettoId(soggettoId);
            aeView.setValore("true");
            aeView.setActualValore("true");
            aeView.setTipoAttributiEsterni(sconfView.getDescrizione());
            aeView.setCausaleTipoAttributiEsterni(sconfView.getCausale());
            aeView.setDescrizioneTipoAttributiEsterni(sconfView.getDescrizione());
            attributeVector.add(aeView);
         }
    }
    
    /**
     * This method returns the socio operation details done for the soggetto for the causale socioBSE and socioSHB.
     * @param soggettoId
     * @return Collection<ISocioOperationView>
     * @throws GestoreAnagrafeException
     */
    public Collection<ISocioDetailsView> getSocioOperationDetails(final Long soggettoId) throws GestoreAttributiEsterniException {
    	Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        final Collection<ISocioDetailsView> socioViewList = new ArrayList<ISocioDetailsView>();
        final StringBuilder query = new StringBuilder();
        log4Debug.debug(">>>>>> getSocioOperationDetails>>>>> soggettoId ::::: ",soggettoId);
        try {
        	if(soggettoId != null) {
	            connection = getConnection();
	            query.append(" SELECT SOGGETTO_ID, CAUSALE, AE_VALUE, DATE_OF_OPERATION ");
	            query.append(" FROM TABLE ( AN_PKG_IGESTORE_ANAGRAFE.AN_FN_GET_SOCIO_VARIA( ? )) ");
	            preparedStatement = connection.prepareStatement(query.toString());
	            preparedStatement.setLong(1, soggettoId);
	            resultSet = preparedStatement.executeQuery();
	            ISocioOperationView socioView = null;
	            while(resultSet.next()) {
	            	socioView = new SocioOperationView();
	            	socioView.setSoggettoId(resultSet.getLong("SOGGETTO_ID"));
	            	socioView.setCausale(resultSet.getString("CAUSALE"));
	            	socioView.setSocioValue(resultSet.getString("AE_VALUE"));
	            	socioView.setDateOfOperation(resultSet.getTimestamp("DATE_OF_OPERATION"));
	            	socioViewList.add(socioView);
	            }
	            log4Debug.debug(">>>>>> getSocioOperationDetails>>>>> socioViewListSize ::::: ",socioViewList.size());
        	}
        } catch (final SQLException e) {
            log4Debug.debugStackTrace(e);
            throw new GestoreAttributiEsterniException(e.getMessage());
        } finally {
            cleanup(connection, preparedStatement, resultSet);
        }
        return socioViewList;
    }
}


