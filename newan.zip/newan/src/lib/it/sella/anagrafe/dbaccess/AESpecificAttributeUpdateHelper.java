package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.discriminator.AttributiEsterniDiscriminatorException;
import it.sella.anagrafe.tipoattributiesterni.ITipoAttributiEsterniBeanManager;
import it.sella.anagrafe.tipoattributiesterni.TipoAttributiEsterni;
import it.sella.anagrafe.tipoattributiesterni.TipoAttributiEsterniView;
import it.sella.anagrafe.util.AnagrafeLoggerHelper;
import it.sella.anagrafe.util.ReflectionUtil;
import it.sella.logserver.LoggerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;

import javax.ejb.FinderException;

public class AESpecificAttributeUpdateHelper extends DBAccessHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AESpecificAttributeUpdateHelper.class);

    public void setAttributiEsterniValues(final Long soggettoId, final String value, final String causale, final Long opId) throws AttributiEsterniDiscriminatorException, RemoteException {
        try {
        	final Long classificazioneId = getClassificazioneIdFromCausale(causale, "AEDPF");
        	final ITipoAttributiEsterniBeanManager tipoAttributiEsterniBeanManager =((ITipoAttributiEsterniBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.TipoAttributiEsterni"));
            try {
                final TipoAttributiEsterni tipoAttributiEsterni = tipoAttributiEsterniBeanManager.findBySoggettoIdAndRightPK(soggettoId, classificazioneId);
                if(!(value == null || value.length() == 0) && (!"sconf".equals(causale) || ("false".equalsIgnoreCase(value) || "SottoOsservazione".equalsIgnoreCase(value)))) {
                	if(!value.equals(tipoAttributiEsterni.getValue())) {
                		tipoAttributiEsterni.setValue(value);
                		tipoAttributiEsterni.setOpId(opId);
                		tipoAttributiEsterniBeanManager.update(tipoAttributiEsterni);
                	}
                } else {
                	new StoricDataUpdateHelper().updateAttributiEsterni(tipoAttributiEsterni.getAttributiesterniId(), tipoAttributiEsterni.getSoggettoId(), tipoAttributiEsterni.getValue(), tipoAttributiEsterni.getRightPk(), opId,tipoAttributiEsterni.getOpId());
                	tipoAttributiEsterniBeanManager.remove(tipoAttributiEsterni);
                }
            } catch (final FinderException fe) {
            	if ( fe.getMessage().indexOf("too_many_results_for_get_single_result") != -1 ) {
            		new StoricDataUpdateHelper().updateAttributiEsterni(soggettoId, classificazioneId, opId);
            		deleteAttributiEsterniForSpecificCausale(soggettoId, classificazioneId);
            	}
                if(!"sconf".equals(causale) || ("false".equalsIgnoreCase(value) || "SottoOsservazione".equalsIgnoreCase(value))) {
                    final TipoAttributiEsterniView datiView = new TipoAttributiEsterniView();
                    datiView.setSoggettoId(soggettoId);
                    if (value != null) {
                        datiView.setValue(value);
                        datiView.setRightPk(classificazioneId);
                        datiView.setOpId(opId);
                        tipoAttributiEsterniBeanManager.create(datiView);
                    }
                }
            }
        } catch (final ControlloDatiException e) {
            log4Debug.warnStackTrace(e);
            throw new AttributiEsterniDiscriminatorException(e.getLocalizedMessage());
		}  catch (final GestoreAnagrafeException e) {
            log4Debug.warnStackTrace(e);
            throw new AttributiEsterniDiscriminatorException(e.getLocalizedMessage());
        }
    }

    public void deleteAttributiEsterniForSpecificCausale(final Long soggettoId,final Long aeRightPk) throws ControlloDatiException {
    	Connection connection = null;
        PreparedStatement preparedStatement = null;
        final StringBuffer queryString = new StringBuffer("DELETE FROM AN_TR_ATTRIBUTIESTERNI AE WHERE AE.AE_SOGGETTO_ID = ? AND AE.AE_RIGHT_PK = ?");
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement(queryString.toString());
            checkForNullAndSetLongValue(preparedStatement, soggettoId, 1);
            checkForNullAndSetLongValue(preparedStatement, aeRightPk, 2);
            preparedStatement.executeUpdate();
        } catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new ControlloDatiException(e.getMessage());
        } finally {
            cleanup(connection, preparedStatement);
        }
	}
    
    public String setAttribute(final Long soggettoId, final String causale, final String value) throws GestoreAnagrafeException, RemoteException {
    	Connection connection = null;
    	CallableStatement statement = null;
    	
    	try {
    		final Long opId = new AnagrafeLoggerHelper().logAnagrafeOperation(null,false,"SET_ATTRIBUTI_API",soggettoId, null);
			connection = getConnection();
			statement = connection.prepareCall("{CALL ? := AN_PKG_ANAGRAFE_UPDATE.AN_FN_SET_ATTRIBUTE( ?, ?, ?, ? )}");
			statement.registerOutParameter(1, Types.VARCHAR);
			statement.setLong(2, soggettoId);
			statement.setString(3, causale);
			statement.setString(4, value);
			statement.setLong(5, opId);
			statement.execute();
			return statement.getString(1);
		} catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} catch (final LoggerException e) {
			log4Debug.warnStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} finally {
            cleanup(connection, statement);
        }
    }
    
    
    /**
     * Method to Set Document Identification Attribute if added newly
     * @param soggettoId
     * @param opId
     * @param value
     * @param causale
     * @throws RemoteException
     * @throws GestoreAnagrafeException
     */
    public void setIdentificationAttribute(final Long soggettoId,final Long opId, final String value, final String causale) throws RemoteException, GestoreAnagrafeException
    {
    	Connection connection = null;
        PreparedStatement preparedStatement = null;
        final Long classificazioneId = getClassificazioneIdFromCausale(causale, "AEDPF");
        final StringBuffer queryString = new StringBuffer("UPDATE AN_TR_ATTRIBUTIESTERNI AE SET AE.AE_VALUE = ? , AE.AE_OP_ID = ? WHERE AE.AE_SOGGETTO_ID = ? AND AE.AE_RIGHT_PK = ? AND AE.AE_OP_ID <> ?");
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement(queryString.toString());
            preparedStatement.setString(1, value);
            checkForNullAndSetLongValue(preparedStatement, opId, 2);
            checkForNullAndSetLongValue(preparedStatement, soggettoId, 3);
            checkForNullAndSetLongValue(preparedStatement, classificazioneId, 4);
            checkForNullAndSetLongValue(preparedStatement, opId, 5);
            final int rowUpdate = preparedStatement.executeUpdate();
            log4Debug.debug("Document Update Query : " , queryString.toString() , " Updated : " , rowUpdate);
        } catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreAnagrafeException(e.getMessage());
        } finally {
            cleanup(connection, preparedStatement);
        }

    }
}


