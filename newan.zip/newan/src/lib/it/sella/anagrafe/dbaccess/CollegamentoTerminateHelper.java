package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreCollegamentoException;
import it.sella.anagrafe.OperazioneCensimentoException;
import it.sella.anagrafe.codicisoggetto.CodiciSoggetto;
import it.sella.anagrafe.codicisoggetto.ICodiciSoggettoBeanManager;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.discriminator.CollegamentoException;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.AnagrafeLoggerHelper;
import it.sella.anagrafe.util.ReflectionUtil;
import it.sella.logserver.LoggerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;

import javax.ejb.FinderException;

public class CollegamentoTerminateHelper extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CollegamentoTerminateHelper.class);

    public void terminateLink( final Long id, final Timestamp dataFine ) throws GestoreCollegamentoException, RemoteException {
    	final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
    	Long opId = null;
    	String errorMessage = null;
        try {
			opId = anagrafeLoggerHelper.logAnagrafeOperation(null,false,"ANAG-API-COLL-TERM",id,null);
            if (id != null && new BancaCheckUtil().checkForBanca(id, null)) {
                new CollegamentoDBAccessHelper().setCollegamento(id, dataFine,opId);
            }
            anagrafeLoggerHelper.logAnagrafeOpDetails(opId,"","");
        } catch (final LoggerException e) {
        	errorMessage = e.getMessage();
            log4Debug.warnStackTrace(e);
            throw new GestoreCollegamentoException(errorMessage);
        } catch (final CollegamentoException e) {
        	errorMessage = e.getMessage();
            log4Debug.warnStackTrace(e);
            throw new GestoreCollegamentoException(errorMessage);
        } catch (final GestoreAnagrafeException e) {
        	errorMessage = e.getMessage();
            log4Debug.warnStackTrace(e);
            throw new GestoreCollegamentoException(errorMessage);
        } finally {
        	try {
				anagrafeLoggerHelper.updateAnagrafeLog(opId,id,errorMessage);
			} catch (final OperazioneCensimentoException e) {
	            log4Debug.warnStackTrace(e);
			}
        }
    }
    
    public void terminateLink( final Long id ) throws GestoreCollegamentoException, RemoteException {
    	terminateLink(id,new Timestamp(System.currentTimeMillis()));
    }

    public void terminateLink( final Long linkedSoggettoId, final Hashtable attributes, final Long opId ) throws GestoreCollegamentoException, RemoteException {
        try {
            if (linkedSoggettoId != null && new BancaCheckUtil().checkForBanca(linkedSoggettoId, null)) {
            	final Collection motivs = attributes.get("MOTIVE") != null ? (Collection) attributes.get("MOTIVE") : new ArrayList();
                if (motivs.contains("DIPEN") && !motivs.contains("APART")) {
                    motivs.add("APART");
                }
                final int size = motivs.size();
                final Iterator iterator = motivs.iterator();
                final CollegamentoDBAccessHelper collegamentoDBAccessHelper = new CollegamentoDBAccessHelper();
                final  StoricDataUpdateHelper storicDataUpdateHelper = new StoricDataUpdateHelper();
                for ( int i = 0; i < size; i++) {
                	final String motivCausale = (String) iterator.next();
                    Collection princCollection = null;
					if ("PROMT".equals(motivCausale)) {
                        princCollection = collegamentoDBAccessHelper.getSoggettoPrincipale(linkedSoggettoId, "PROCT");
                    } else if ("SVILP".equals(motivCausale)) {
                        princCollection = collegamentoDBAccessHelper.getSoggettoPrincipale(linkedSoggettoId, "SVICT");
                    }
                    if ( princCollection != null && !princCollection.isEmpty() ) {
                    	throw new GestoreCollegamentoException(new AnagrafeHelper().getMessage("ANAG-1330"));
                    }
					final Collection motivToBePassed = new ArrayList(1);
					motivToBePassed.add(motivCausale);
					collegamentoDBAccessHelper.setCollegamento(linkedSoggettoId, (Timestamp) attributes.get("ENDDATE"),motivToBePassed,opId);
                    if ("DIPEN".equals(motivCausale) || "PROMT".equals(motivCausale)) {
                        Long exCodiceId = null;
                        Long codiceId = null;
                        if ("DIPEN".equals(motivCausale)) {
                            codiceId = getClassificazioneIdFromCausale("coddp", "CSDPF");
                            exCodiceId = getClassificazioneIdFromCausale("excoddp", "CSDPF");
                        } else if ("PROMT".equals(motivCausale)) {
                            codiceId = getClassificazioneIdFromCausale("codpr", "CSDPF");
                            exCodiceId = getClassificazioneIdFromCausale("excodpr", "CSDPF");
                        }
						
                        final ICodiciSoggettoBeanManager manager = ((ICodiciSoggettoBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.CodiciSoggetto"));
                        final CodiciSoggetto codiciSoggetto = manager.findBySoggettoIdAndRightPK(linkedSoggettoId, codiceId);
                        try {
                        	final CodiciSoggetto exCodiciSoggetto = manager.findBySoggettoIdAndRightPK(linkedSoggettoId, exCodiceId);
                            exCodiciSoggetto.setValue(exCodiciSoggetto.getValue() + ";" + codiciSoggetto.getValue());
                            exCodiciSoggetto.setOpId(opId);
                            manager.update(exCodiciSoggetto);
                        } catch (final FinderException fe) {
                        	final it.sella.anagrafe.codicisoggetto.CodiciSoggettoView codiciSoggettoView = new it.sella.anagrafe.codicisoggetto.CodiciSoggettoView();
                            codiciSoggettoView.setSoggettoId(linkedSoggettoId);
                            codiciSoggettoView.setRightPk(exCodiceId);
                            codiciSoggettoView.setValue(codiciSoggetto.getValue());
                            codiciSoggettoView.setOpId(opId);
                            manager.create(codiciSoggettoView);
                        }
                        
                        storicDataUpdateHelper.updateCodiciSoggetto(codiciSoggetto.getId(), codiciSoggetto.getSoggettoId(), codiciSoggetto.getValue(), codiciSoggetto.getRightPk(), opId,codiciSoggetto.getOpId());
                        manager.remove(codiciSoggetto);
                    }
                }
            }
        } catch (final CollegamentoException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreCollegamentoException(e.getMessage());
        }catch (final GestoreAnagrafeException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreCollegamentoException(e.getMessage());
        } catch (final ControlloDatiException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreCollegamentoException(e.getMessage());
		} catch (final FinderException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreCollegamentoException(e.getMessage());
        }
    }
}
