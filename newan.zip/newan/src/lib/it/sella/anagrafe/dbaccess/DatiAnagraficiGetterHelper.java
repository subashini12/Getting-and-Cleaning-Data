package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreDatiAnagrafeException;
import it.sella.anagrafe.ICittaView;
import it.sella.anagrafe.IDatiAnagraficiView;
import it.sella.anagrafe.INazioneView;
import it.sella.anagrafe.implementation.DAPFView;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatiAnagraficiGetterHelper extends DatiAnagraficiPFGetterHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DatiAnagraficiGetterHelper.class);
    
    /**
     * Getting DatiAnagrafici Details of Soggetto for AZ,PF and PL.
     * @param soggettoId
     * @return
     * @throws GestoreDatiAnagrafeException
     * @throws RemoteException
     * IDatiAnagraficiView
     */
    public IDatiAnagraficiView getAnagraficiView( final Long soggettoId ) throws GestoreDatiAnagrafeException, RemoteException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        IDatiAnagraficiView iDatiAnagraficiView = null;
        DAPFView datiAnagraficiPFView = null;
        ResultSet datiResultSet = null;
        try {
            connection = getConnection();
            final String tipoSoggetto = new TipoSoggettoHandler().getParentTipoSoggetto(soggettoId);
            final Long bancaId = SecurityHandler.getLoginBancaId();
            final Long censtId = getClassificazioneIdFromCausale("CENST", "MOTIV");
            if ( "AZIENDE".equals(tipoSoggetto) ) {
                selectStatement = connection.prepareStatement("select AZ.AZ_DENOMINAZIONE, AZ.AZ_DATADICOSTITUZIONE, AZ.AZ_NAZIONE_COSTITUZIONE, AZ.AZ_CITTA_COSTITUZIONE from AN_TR_DATIANAGRAFE_AZIENDA AZ,AN_TR_COLLAGAMENTO_SOGGETTO CS where CS.CL_SOGGETTO_PRINCIPALE = ? and CS.CL_MOTIVO = ? and CS.CL_LINKED_SOGGETTO = AZ.AZ_SOGGETTO_ID AND CS.CL_DATA_FINE IS NULL AND AZ.AZ_SOGGETTO_ID = ?");
                selectStatement.setLong(1, bancaId.longValue());
                selectStatement.setLong(2, censtId.longValue());
                selectStatement.setLong(3, soggettoId.longValue());
                datiResultSet = selectStatement.executeQuery();
                if( datiResultSet.next() ) {
                    iDatiAnagraficiView = getDAAZViewFromResultSet(datiResultSet);
                }
            } else {
                selectStatement = connection.prepareStatement("select DN.DN_NOME, DN.DN_COGNOME, DN.DN_DATE_OF_BIRTH, DN.DN_CITTA_OF_BIRTH, DN.DN_NAZIONE_OF_BIRTH from an_tr_datianagrafe DN,an_tr_collagamento_soggetto CS where CS.cl_soggetto_principale = ? and CS.cl_motivo = ? and CS.cl_linked_soggetto = DN.dn_soggetto_id and DN.DN_SOGGETTO_ID = ?  ");
                selectStatement.setLong(1, bancaId.longValue());
                selectStatement.setLong(2, censtId.longValue());
                selectStatement.setLong(3, soggettoId.longValue());
                datiResultSet = selectStatement.executeQuery();
                if( datiResultSet.next() ) {
                    datiAnagraficiPFView = new DAPFView();
                    datiAnagraficiPFView.setNome(datiResultSet.getString("DN_NOME"));
                    datiAnagraficiPFView.setCognome(datiResultSet.getString("DN_COGNOME"));
                    datiAnagraficiPFView.setDataDiNascita(datiResultSet.getTimestamp("DN_DATE_OF_BIRTH"));
                    try {
                        if( datiResultSet.getString("DN_CITTA_OF_BIRTH") != null ) {
                        	final ICittaView cittaView = new CittaDBAccessHelper().getCitta(Long.valueOf(datiResultSet.getString("DN_CITTA_OF_BIRTH")));
                            datiAnagraficiPFView.setLuogoDiNascitaCittaView(cittaView);
                            if( cittaView != null ) {
                            	datiAnagraficiPFView.setLuogoDiNascitaCitta(cittaView.getCommune());
                            }
                        }
                    } catch (final NumberFormatException nx) {
                        datiAnagraficiPFView.setLuogoDiNascitaCitta(datiResultSet.getString("DN_CITTA_OF_BIRTH"));
                    }
                    if( datiResultSet.getString("DN_NAZIONE_OF_BIRTH") != null ) {
                        final INazioneView nazioneView = new NazioneDBAccessHelper().getNazione(Long.valueOf(datiResultSet.getString("DN_NAZIONE_OF_BIRTH")));
                        datiAnagraficiPFView.setLuogoDiNascitaNazioneView(nazioneView);
                        if( nazioneView != null ) {
                        	datiAnagraficiPFView.setLuogoDiNascitaNazione(nazioneView.getNome());
                        }
                    }
                } 
                iDatiAnagraficiView = datiAnagraficiPFView; 
            }
        } catch (final SQLException sqlEx) {
            log4Debug.warnStackTrace(sqlEx);
            throw new GestoreDatiAnagrafeException(sqlEx.getMessage());
        } catch (final GestoreAnagrafeException gne) {
            log4Debug.warnStackTrace(gne);
            throw new GestoreDatiAnagrafeException(gne.getMessage());
        } finally {
            cleanup(connection, selectStatement, datiResultSet);
        }
        return iDatiAnagraficiView;
    }
}
