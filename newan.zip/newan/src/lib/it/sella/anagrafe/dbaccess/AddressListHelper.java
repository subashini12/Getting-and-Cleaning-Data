package it.sella.anagrafe.dbaccess;

import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.common.CAP;
import it.sella.anagrafe.implementation.CittaView;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.implementation.NazioneView;
import it.sella.anagrafe.implementation.ProvinciaView;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Vector;

/**
 * Class Added to get Address using Address View without invoking Address API for managing Censimento of Sella Life
 *
 */
public class AddressListHelper extends DBAccessHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressListHelper.class);


	/**
	 * Public method to get the Address List
	 * @param soggettoId
	 * @param subSystemCl
	 * @return
	 * @throws AddressException
	 * @throws RemoteException
	 */
	public Collection listAddress( final Long soggettoId, final String subSystemCl ) throws AddressException, RemoteException {
		Connection connection = null;
		PreparedStatement addressStatement = null;
		ResultSet addressSet = null;
		final Vector addressVector = new Vector(1);
		try {
			connection = getConnection();
			final StringBuffer query = getSelectQueryForView();
			query.append(" AL_SOGGETTO_ID = ? AND AL_TYPE_SUBSYSTEM = ").append(ClassificazioneHandler.getClassificazioneView(subSystemCl, "SUBSYS").getId());
			addressStatement = connection.prepareStatement(query.toString());
			addressStatement.setLong(1, soggettoId.longValue());
			addressSet = addressStatement.executeQuery();
			while(addressSet.next()) {
				addressVector.add(getAddressViewFromResultSet(soggettoId, addressSet));
			}
		} catch(final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		} catch(final GestoreAnagrafeException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressException(e.getMessage());
		} finally {
			cleanup(connection, addressStatement, addressSet);
		}
		return addressVector;
	}

	private StringBuffer getSelectQueryForView() {
		final StringBuffer query = new StringBuffer();
		query.append("SELECT AL_SOGGETTO_ID, AL_LINKED_ID, AL_TYPE_SUBSYSTEM, AL_TYPE_ADDRESS, AD_ADDRESS_ID, AD_INDIRIZZO,AD_PROVINCIA, PR_ID, PR_SIGLA, PR_NOME, PR_CODICE_AREA, PR_CODICE_CAB, PR_CODICE_PUMA2, PR_STORICO,");
		query.append(" AD_CITTA, CI_ID, CI_COMMUNE, CI_PROVINCIA, CI_REGION, CI_CAPOLUOGO, CI_CAB, CI_CINCAB, CI_CAB_STORICO, CI_CNCF, CI_CAP, CI_STORICO, CI_ALTRADENOMINAZIONE,AD_CAP_VALUE, AD_NORM_STATUS, CAP_ID, CA_CAP, CA_LOCALITA, CA_NOTE, CA_PROVINCIA,");
		query.append(" NAZIONE_ID, NA_NOME, NA_NAZIONALITA, NA_CODICE_UIC, NA_CODICE_ISO, NA_CODICE_DIVISA, NA_CODICE_PROVINCIA, NA_SINGLA_INTERNAZIONALE, NA_LINGUA_PARLATA, NA_ZCR, NA_ZONA_BILANCI_GRANDI_RISCHI, NA_VALUTARIO, NA_AREA_GEOGRAFICA, NA_ADERENTE_TARGET, NA_MEMBRO_UE, NA_MEMBRO_UME, NA_APPARTENENTE_BLACK_LIST, NA_CNCF, NA_ALTRADENOMINAZIONE, NA_CONTINENTE, NA_STORICO, NA_NAZIONE, NA_NAZIONE_APPARTENENZA, NA_HA_EMBARGO, NA_DOC_AGGIUNTIVI, AE_RESERVED, AE_FREQUENCY, AE_INTERNAL FROM ADD_VW_ADDRESSVIEW WHERE");
		return query;
	}

	private AddressView getAddressViewFromResultSet(final Long soggettoId, final ResultSet addressSet) throws RemoteException, AddressException {
		ClassificazioneView addrClView = null;
		final AddressView addressView = new AddressView();
		try {
			addressView.setSoggettoId(soggettoId);
			setCapInAddressView(addressSet,addressView);
			addrClView = ClassificazioneHandler.getClassificazioneView(Long.valueOf(addressSet.getLong("AL_TYPE_SUBSYSTEM")));
			addressView.setCausaleSubsystem(addrClView.getCausale());
			addressView.setDescrizioneSubsystem(addrClView.getDescrizione());
			addrClView = ClassificazioneHandler.getClassificazioneView(Long.valueOf(addressSet.getLong("AL_TYPE_ADDRESS")));
			addressView.setCausaleTipoIndirizzo(addrClView.getCausale());
			addressView.setDescrizioneTipoIndirizzo(addrClView.getDescrizione());
			addressView.setTipoIndirrizo(addrClView.getId());
			setCittaInAddressView(addressSet,addressView);
			addressView.setIndirizzo(addressSet.getString("AD_INDIRIZZO"));
			if(addressSet.getString("AL_LINKED_ID") != null)
			{
				addressView.setProductContoId(Long.valueOf(addressSet.getLong("AL_LINKED_ID")));
			}
			setNazioneInAddressView(addressSet,addressView);
			setProvinciaInAddressView(addressSet,addressView);
			addressView.setInternal(getDBNumberValue(addressSet.getLong("AE_INTERNAL")));
			addressView.setFrequency(getDBNumberValue(addressSet.getLong("AE_FREQUENCY")));
			addressView.setReserved(getDBNumberValue(addressSet.getLong("AE_RESERVED")));
			addressView.setNormStatus(addressSet.getString("AD_NORM_STATUS"));
		} catch (final SQLException e) {
			log4Debug.severeStackTrace(e);
			throw new AddressException(e.getMessage());
		} catch(final SubSystemHandlerException e) {
			log4Debug.severeStackTrace(e);
			final String errorMsg = "Enter a valid causale for Sub System / Address Type !!!";
			throw new AddressException(errorMsg);
		}
		return addressView;
	}

	private Long getDBNumberValue(final long value) {
		if(value != 0) {
			return Long.valueOf(value);
		}
		return null;
	}

	private void setCapInAddressView(final ResultSet addressSet,final AddressView addressView) throws SQLException {
		try {
			if(Long.valueOf(addressSet.getString("CAP_ID")) != null) {
				final CAP cap = new CAP();
				cap.setCapId(Long.valueOf(addressSet.getString("CAP_ID")));
				cap.setCap(addressSet.getString("CA_CAP"));
				cap.setLocalita(addressSet.getString("CA_LOCALITA"));
				cap.setNote(addressSet.getString("CA_NOTE"));
				cap.setProvincia(addressSet.getString("CA_PROVINCIA"));
				addressView.setCapView(cap);
				addressView.setCap(addressSet.getString("CA_CAP"));
			} else {
				addressView.setCap(addressSet.getString("AD_CAP_VALUE"));
			}
		} catch (final NumberFormatException e) {
			addressView.setCap(addressSet.getString("AD_CAP_VALUE"));
		}
	}

	private void setCittaInAddressView(final ResultSet addressSet,final AddressView addressView) throws SQLException {
		try {
			if(addressSet.getLong("CI_ID") != 0) {
				final CittaView cittaView = new CittaView();
				cittaView.setCittaId(Long.valueOf(addressSet.getLong("CI_ID")));
				cittaView.setCommune(addressSet.getString("CI_COMMUNE"));
				cittaView.setProvincia(addressSet.getString("CI_PROVINCIA"));
				cittaView.setRegion(addressSet.getString("CI_REGION"));
				cittaView.setCapoluogo(Long.valueOf(addressSet.getLong("CI_CAPOLUOGO")));
				cittaView.setCab(addressSet.getString("CI_CAB"));
				cittaView.setCincab(addressSet.getString("CI_CINCAB"));
				cittaView.setCabStorico(addressSet.getString("CI_CAB_STORICO"));
				cittaView.setCncf(addressSet.getString("CI_CNCF"));
				cittaView.setCap(addressSet.getString("CI_CAP"));
				cittaView.setStorico(String.valueOf(addressSet.getLong("CI_STORICO")));
				cittaView.setAltraDenominazione(addressSet.getString("CI_ALTRADENOMINAZIONE"));
				addressView.setCittaView(cittaView);
				addressView.setCitta(addressSet.getString("CI_COMMUNE"));
			} else {
				addressView.setCitta(addressSet.getString("AD_CITTA"));
			}
		} catch (final NumberFormatException e) {
			addressView.setCitta(addressSet.getString("AD_CITTA"));
		}
	}

	private void setNazioneInAddressView(final ResultSet addressSet,final AddressView addressView) throws SQLException {
		final NazioneView nazioneView = new NazioneView();
		nazioneView.setNome(addressSet.getString("NA_NOME"));
		if(addressSet.getString("NA_ADERENTE_TARGET") != null) {
			nazioneView.setAderenteTarget(Long.valueOf(addressSet.getLong("NA_ADERENTE_TARGET")));
		}
		nazioneView.setAltradenominazione(addressSet.getString("NA_ALTRADENOMINAZIONE"));
		if(addressSet.getString("NA_APPARTENENTE_BLACK_LIST") != null) {
			nazioneView.setAppartenenteBlackList(Long.valueOf(addressSet.getLong("NA_APPARTENENTE_BLACK_LIST")));
		}
		nazioneView.setAreaGeografica(addressSet.getString("NA_AREA_GEOGRAFICA"));
		nazioneView.setCncf(addressSet.getString("NA_CNCF"));
		nazioneView.setCodiceDivisa(addressSet.getString("NA_CODICE_DIVISA"));
		nazioneView.setCodiceIso(addressSet.getString("NA_CODICE_ISO"));
		nazioneView.setCodiceProvincia(addressSet.getString("NA_CODICE_PROVINCIA"));
		nazioneView.setCodiceUic(addressSet.getString("NA_CODICE_UIC"));
		nazioneView.setContinente(String.valueOf(addressSet.getLong("NA_CONTINENTE")));
		if(addressSet.getString("NA_HA_EMBARGO") != null) {
			nazioneView.setHa_embargo(Long.valueOf(addressSet.getLong("NA_HA_EMBARGO")));
		}
		if(addressSet.getString("NA_LINGUA_PARLATA") != null) {
			nazioneView.setLinguaParlata((Long.valueOf(addressSet.getLong("NA_LINGUA_PARLATA"))).toString());
		}
		if(addressSet.getString("NA_MEMBRO_UE") != null) {
			nazioneView.setMembroUe(Long.valueOf(addressSet.getLong("NA_MEMBRO_UE")));
		}
		if(addressSet.getString("NA_MEMBRO_UME") != null) {
			nazioneView.setMembroUme(Long.valueOf(addressSet.getLong("NA_MEMBRO_UME")));
		}
		nazioneView.setNazionalita(addressSet.getString("NA_NAZIONALITA"));
		if(addressSet.getString("NA_NAZIONE") != null) {
			nazioneView.setNazione(Long.valueOf(addressSet.getString("NA_NAZIONE")));
		}
		nazioneView.setNazioneAppartenenza(addressSet.getString("NA_NAZIONE_APPARTENENZA"));
		nazioneView.setNazioneId(Long.valueOf(addressSet.getLong("NAZIONE_ID")));
		nazioneView.setSinglaInternazionale(addressSet.getString("NA_SINGLA_INTERNAZIONALE"));
		if(addressSet.getString("NA_STORICO") != null) {
			nazioneView.setStorico(Long.valueOf(addressSet.getLong("NA_STORICO")));
		}
		if(addressSet.getString("NA_VALUTARIO") != null) {
			nazioneView.setValutario(Long.valueOf(addressSet.getLong("NA_VALUTARIO")));
		}
		if(addressSet.getString("NA_ZCR") != null) {
			nazioneView.setZcr(Long.valueOf(addressSet.getLong("NA_ZCR")));
		}
		if(addressSet.getString("NA_ZONA_BILANCI_GRANDI_RISCHI") != null) {
			nazioneView.setZonaBilanciGrandiRischi(Long.valueOf(addressSet.getLong("NA_ZONA_BILANCI_GRANDI_RISCHI")));
		}
		if(addressSet.getString("NA_DOC_AGGIUNTIVI") != null) {
			nazioneView.setDocAggiuntivi(addressSet.getString("NA_DOC_AGGIUNTIVI"));
		}
		addressView.setNazioneView(nazioneView);
		addressView.setNazione(addressSet.getString("NA_NOME"));
	}

	private void setProvinciaInAddressView(final ResultSet addressSet,final AddressView addressView) throws SQLException {
		try {
			if (addressSet.getLong("PR_ID") != 0) {
				final ProvinciaView provinciaView = new ProvinciaView();
				provinciaView.setProvinciaId(Long.valueOf(addressSet.getLong("PR_ID")));
				provinciaView.setSigla(addressSet.getString("PR_SIGLA"));
				provinciaView.setNome(addressSet.getString("PR_NOME"));
				provinciaView.setCodiceArea(addressSet.getString("PR_CODICE_AREA"));
				provinciaView.setCodiceCab(addressSet.getString("PR_CODICE_CAB"));
				provinciaView.setCodicePuma2(addressSet.getString("PR_CODICE_PUMA2"));
				addressView.setProvinciaView(provinciaView);
				addressView.setProvincia(addressSet.getString("PR_SIGLA"));
			} else {
				addressView.setProvincia(addressSet.getString("AD_PROVINCIA"));
			}
		} catch (final NumberFormatException e) {
			addressView.setProvincia(addressSet.getString("AD_PROVINCIA"));
		}
	}
}