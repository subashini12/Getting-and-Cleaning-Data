package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.OperazioneCensimentoException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.discriminator.CodiceSoggettoDiscriminatorException;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.AnagrafeLoggerHelper;
import it.sella.logserver.LoggerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CSCifratiUpdateHelper extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CSCifratiUpdateHelper.class);

    protected void setCodiceSoggettoCifratiValues(final Long soggettoId, final String newValoreCodiceHost, Long opId) throws CodiceSoggettoDiscriminatorException, RemoteException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
    	final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
    	String errorMessage = null;
        try {
            if (soggettoId == null || newValoreCodiceHost == null) {
				throw new CodiceSoggettoDiscriminatorException(new AnagrafeHelper().getMessage("ANAG-1298"));
			}
            if(opId == null) {
				opId = anagrafeLoggerHelper.logAnagrafeOperation(null,false,"ANAG-API-CSCIF-SET",soggettoId,null);
			}
            connection = getConnection();
            preparedStatement = connection.prepareStatement("UPDATE AN_TR_CODICISOGGETTO_CIFRATI SET CS_VALUE = ?, CS_OP_ID = ? WHERE CS_SOGGETTO_ID = ? AND CS_RIGHT_PK = ?  ");
            preparedStatement.setString(1,newValoreCodiceHost);
            preparedStatement.setLong(2, opId.longValue());
            preparedStatement.setLong(3,soggettoId.longValue());
            preparedStatement.setLong(4, getClassificazioneIdFromCausale("codiceHost", "CSDPF").longValue());
            preparedStatement.executeUpdate();
            anagrafeLoggerHelper.logAnagrafeOpDetails(opId,"","");
        } catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            errorMessage = e.getMessage();
            throw new CodiceSoggettoDiscriminatorException(errorMessage);
        } catch (final LoggerException e) {
            log4Debug.warnStackTrace(e);
            errorMessage = e.getMessage();
            throw new CodiceSoggettoDiscriminatorException(errorMessage);
        } catch (final SubSystemHandlerException e) {
            log4Debug.warnStackTrace(e);
            errorMessage = e.getMessage();
            throw new CodiceSoggettoDiscriminatorException(errorMessage);
        } finally {
        	try {
        		cleanup(connection,preparedStatement);
				anagrafeLoggerHelper.updateAnagrafeLog(opId,soggettoId,errorMessage);
			} catch (final OperazioneCensimentoException e) {
	            log4Debug.warnStackTrace(e);
			}
        }
    }
    
    protected void removeCodiceSoggettoCifrati(final Long soggettoId, final Long opId) throws CodiceSoggettoDiscriminatorException, RemoteException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            if (soggettoId == null) {
				throw new CodiceSoggettoDiscriminatorException(new AnagrafeHelper().getMessage("ANAG-1300"));
			}
            new StoricDataUpdateHelper().updateCodiciSoggettoCifrati(soggettoId, opId);
            connection = getConnection();
            preparedStatement = connection.prepareStatement("DELETE FROM AN_TR_CODICISOGGETTO_CIFRATI  WHERE CS_SOGGETTO_ID = ? ");
            preparedStatement.setLong(1,soggettoId.longValue());
            preparedStatement.executeUpdate();
        } catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new CodiceSoggettoDiscriminatorException(e.getMessage());
        } catch (final ControlloDatiException e) {
            log4Debug.warnStackTrace(e);
            throw new CodiceSoggettoDiscriminatorException(e.getMessage());
        } finally {
        	cleanup(connection,preparedStatement);
        }
    }
    
}
