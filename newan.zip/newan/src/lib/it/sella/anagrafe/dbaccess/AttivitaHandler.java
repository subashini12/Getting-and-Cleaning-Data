package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreAttributiEsterniException;
import it.sella.anagrafe.InformazioneManagerException;
import it.sella.anagrafe.common.Attivita;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

public class AttivitaHandler extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AttivitaHandler.class);

    public Collection getCompatibleAttivita(final String ramo) throws InformazioneManagerException,RemoteException {
        final ArrayList attivitaList = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet attivitaResultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("SELECT AT_CODICEISTAT,AT_DESCRIZIONE FROM AN_MA_ATTIVITA AA, AN_MA_COMP_ATTIVITA AC WHERE CO_AT_RM_CODICEGRUPPO = ? AND AA.AT_CODICEISTAT = AC.CO_AT_CODICEISTAT");
            preparedStatement.setString(1,ramo);
            attivitaResultSet = preparedStatement.executeQuery();
            while(attivitaResultSet.next()) {
                final Attivita attivita = new Attivita();
                attivita.setCodiceISTAT(attivitaResultSet.getString("AT_CODICEISTAT"));
                attivita.setDescrizione(attivitaResultSet.getString("AT_DESCRIZIONE"));
                attivitaList.add(attivita);
            }
        } catch(final SQLException e) {
            log4Debug.severeStackTrace(e);
            throw new InformazioneManagerException(e.getMessage());
        } finally {
            cleanup(connection,preparedStatement,attivitaResultSet);
        }
        return attivitaList;
    }
    
    public String getAttivitaDescrizione(final String codiceISTAT) throws InformazioneManagerException,RemoteException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("SELECT AT_DESCRIZIONE FROM AN_MA_ATTIVITA WHERE AT_CODICEISTAT = ?");
            preparedStatement.setString(1,codiceISTAT);
            resultSet = preparedStatement.executeQuery();
            if(resultSet.next()) {
                return resultSet.getString("AT_DESCRIZIONE");
            }
        } catch(final SQLException e) {
            log4Debug.severeStackTrace(e);
            throw new InformazioneManagerException(e.getMessage());
        } finally {
            cleanup(connection,preparedStatement,resultSet);
        }
        return null;
    }

    public String getAttivita(final String codiceAttivita) throws GestoreAnagrafeException, RemoteException {
    	if(codiceAttivita == null) {
			final String errorMessage = "codiceAttivita ";
			throw new GestoreAnagrafeException(errorMessage + new AnagrafeHelper().getMessage("ANAG-1264"));
		}
        Connection connection = null;
        PreparedStatement selectStatement = null;
        String attivitaDescription = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            selectStatement = connection.prepareStatement("SELECT AT_DESCRIZIONE FROM AN_MA_ATTIVITA WHERE AT_CODICEISTAT = ?");
            selectStatement.setString(1, codiceAttivita);
            resultSet = selectStatement.executeQuery();
            if(resultSet.next()) {
				attivitaDescription = resultSet.getString("AT_DESCRIZIONE");
			}
        } catch (final SQLException sqlEx) {
            log4Debug.severeStackTrace(sqlEx);
            throw new GestoreAttributiEsterniException(sqlEx.getMessage());
        } finally {
            cleanup(connection, selectStatement, resultSet);
        }
        return attivitaDescription;
    }
}
