package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.discriminator.AttributiEsterniDiscriminatorException;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.implementation.IView;
import it.sella.anagrafe.tipoattributiesterni.ITipoAttributiEsterniBeanManager;
import it.sella.anagrafe.tipoattributiesterni.TipoAttributiEsterniView;
import it.sella.anagrafe.util.ReflectionUtil;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Iterator;

public class AECreateHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AECreateHelper.class);

    public void createAttributiEsterniPF(final Long soggettoId, final IView iView) throws AttributiEsterniDiscriminatorException, RemoteException {
        try {
            TipoAttributiEsterniView datiView = null;
            final Long parentClassificazioneId = ClassificazioneHandler.getClassificazioneParentId("AEDPF");
            Object object = null;
            String currentProperty = null;
            Long classificazioneId = null;
            final ITipoAttributiEsterniBeanManager tipoAttributiEsterniBeanManager =((ITipoAttributiEsterniBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.TipoAttributiEsterni"));
            final Collection collCausale = iView.getCausaleListFromViewProperties();
            collCausale.remove("attSezione");
            collCausale.remove("attDivisione");
            collCausale.remove("segdpIntestazione");
            collCausale.remove("POLIZZA_SELLA_LIFE");
            final int collCausaleSize = collCausale.size();
            final Iterator iterator = collCausale.iterator();
            for (int i = 0; i < collCausaleSize; i++) {
                currentProperty = (String) iterator.next();
                classificazioneId = ClassificazioneHandler.getClassificazioneChildId(currentProperty, parentClassificazioneId);
                datiView = new TipoAttributiEsterniView();
                datiView.setSoggettoId(soggettoId);
                datiView.setRightPk(classificazioneId);
                object = iView.getValueForThisProperty(currentProperty);
                if (object != null) {
                    if (object instanceof ClassificazioneView) {
                        datiView.setValue(((ClassificazioneView) object).getId().toString());
                    } else if(object instanceof it.sella.anagrafe.common.Nazione) {
						datiView.setValue(((it.sella.anagrafe.common.Nazione)object).getNazioneId().toString());
					}  else if(object instanceof it.sella.anagrafe.common.TAE) {
						datiView.setValue(((it.sella.anagrafe.common.TAE)object).getTaeId().toString());
					} else if(object instanceof it.sella.anagrafe.common.SettoreDiAttivita) {
						datiView.setValue(((it.sella.anagrafe.common.SettoreDiAttivita)object).getSettoreAttivitaId().toString());
					}
					 else if(object instanceof it.sella.anagrafe.common.AlboProfessione) {
							datiView.setValue(((it.sella.anagrafe.common.AlboProfessione)object).getAlboId().toString());
						}else {
                        datiView.setValue(object.toString());
                    }       // This not to insert the sconf value if the sconf value is equals to true
                    if (!"sconf".equals(currentProperty) || !"true".equals(datiView.getValue())) {
                    	datiView.setOpId(iView.getOpId());
                    	tipoAttributiEsterniBeanManager.create(datiView);
                    }
                }
            }
        } catch (final InvocationTargetException ie) {
            log4Debug.severeStackTrace(ie);
            throw new AttributiEsterniDiscriminatorException(ie.getLocalizedMessage());
        } catch (final IllegalAccessException ae) {
            log4Debug.severeStackTrace(ae);
            throw new AttributiEsterniDiscriminatorException(ae.getLocalizedMessage());
        } catch (final NoSuchMethodException me) {
            log4Debug.severeStackTrace(me);
            throw new AttributiEsterniDiscriminatorException(me.getLocalizedMessage());
        } catch (final GestoreAnagrafeException e) {
            log4Debug.severeStackTrace(e);
            throw new AttributiEsterniDiscriminatorException(e.getLocalizedMessage());
        }
    }

}


