package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.discriminator.AttributiEsterniDiscriminatorException;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.implementation.IView;
import it.sella.anagrafe.tipoattributiesterni.ITipoAttributiEsterniBeanManager;
import it.sella.anagrafe.tipoattributiesterni.TipoAttributiEsterni;
import it.sella.anagrafe.tipoattributiesterni.TipoAttributiEsterniView;
import it.sella.anagrafe.util.ReflectionUtil;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Iterator;

import javax.ejb.FinderException;

public class AEUpdateHelper extends AESpecificAttributeUpdateHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AEUpdateHelper.class);

    public void setAttributiEsterniPF(final Long soggettoId, final IView iView) throws AttributiEsterniDiscriminatorException, RemoteException {
        try {
            Object object = null;
            final ITipoAttributiEsterniBeanManager tipoAttributiEsterniBeanManager =((ITipoAttributiEsterniBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.TipoAttributiEsterni"));
            final Collection attributiEsterniColn = tipoAttributiEsterniBeanManager.findBySoggettoId(soggettoId);
            final Iterator iterator = attributiEsterniColn.iterator();
            final Collection causaleColn = iView.getCausaleListFromViewProperties();
            causaleColn.remove("attSezione");
    		causaleColn.remove("attDivisione");
    		causaleColn.remove("segdpIntestazione");
    		causaleColn.remove("POLIZZA_SELLA_LIFE");
            String causale =null;
            TipoAttributiEsterni tipoAttributiEsterni= null;
            final StoricDataUpdateHelper storicDataUpdateHelper = new StoricDataUpdateHelper();
            for (int i = 0; i < attributiEsterniColn.size(); i++) {
                tipoAttributiEsterni = (TipoAttributiEsterni) iterator.next();
                causale = ClassificazioneHandler.getClassificazioneView(tipoAttributiEsterni.getRightPk()).getCausale();
                if (causaleColn.contains(causale)){
                    object = iView.getValueForThisProperty(causale);
                    if (object != null) {
                        if (object instanceof ClassificazioneView) {
                        	if(!((ClassificazioneView) object).getId().toString().equals(tipoAttributiEsterni.getValue())) {
                        		tipoAttributiEsterni.setValue(((ClassificazioneView) object).getId().toString());
                        		tipoAttributiEsterni.setOpId(iView.getOpId());
                        		tipoAttributiEsterniBeanManager.update(tipoAttributiEsterni);
                        	}
                        } else if(object instanceof it.sella.anagrafe.common.Nazione) {
                        	if(!((it.sella.anagrafe.common.Nazione)object).getNazioneId().toString().equals(tipoAttributiEsterni.getValue())) {
                        		tipoAttributiEsterni.setValue(((it.sella.anagrafe.common.Nazione)object).getNazioneId().toString());
                        		tipoAttributiEsterni.setOpId(iView.getOpId());
                        		tipoAttributiEsterniBeanManager.update(tipoAttributiEsterni);
                        	}
						} else if(object instanceof it.sella.anagrafe.common.TAE) {
                        	if(!((it.sella.anagrafe.common.TAE)object).getTaeId().toString().equals(tipoAttributiEsterni.getValue())) {
                        		tipoAttributiEsterni.setValue(((it.sella.anagrafe.common.TAE)object).getTaeId().toString());
                        		tipoAttributiEsterni.setOpId(iView.getOpId());
                        		tipoAttributiEsterniBeanManager.update(tipoAttributiEsterni);
                        	}
						}
						else if(object instanceof it.sella.anagrafe.common.SettoreDiAttivita) {
                        	if(!((it.sella.anagrafe.common.SettoreDiAttivita)object).getSettoreAttivitaId().toString().equals(tipoAttributiEsterni.getValue())) {
                        		tipoAttributiEsterni.setValue(((it.sella.anagrafe.common.SettoreDiAttivita)object).getSettoreAttivitaId().toString());
                        		tipoAttributiEsterni.setOpId(iView.getOpId());
                        		tipoAttributiEsterniBeanManager.update(tipoAttributiEsterni);
                        	}
						}else if(object instanceof it.sella.anagrafe.common.AlboProfessione) {
                        	if(!((it.sella.anagrafe.common.AlboProfessione)object).getAlboId().toString().equals(tipoAttributiEsterni.getValue())) {
                        		tipoAttributiEsterni.setValue(((it.sella.anagrafe.common.AlboProfessione)object).getAlboId().toString());
                        		tipoAttributiEsterni.setOpId(iView.getOpId());
                        		tipoAttributiEsterniBeanManager.update(tipoAttributiEsterni);
                        	}
						}else {
                            if ("sconf".equals(causale)) {
                                if ("true".equals(object.toString())) {
                                	storicDataUpdateHelper.updateAttributiEsterni(tipoAttributiEsterni.getAttributiesterniId(), tipoAttributiEsterni.getSoggettoId(), tipoAttributiEsterni.getValue(), tipoAttributiEsterni.getRightPk(), iView.getOpId(),tipoAttributiEsterni.getOpId());
                                	tipoAttributiEsterniBeanManager.remove(tipoAttributiEsterni);
                                } else {
                                	if(!object.toString().equals(tipoAttributiEsterni.getValue())) {
                                		tipoAttributiEsterni.setValue(object.toString());
                                		tipoAttributiEsterni.setOpId(iView.getOpId());
                                		tipoAttributiEsterniBeanManager.update(tipoAttributiEsterni);
                                	}
                                }
                            } else {
                            	if(!object.toString().equals(tipoAttributiEsterni.getValue())) {
                            		tipoAttributiEsterni.setValue(object.toString());
                            		tipoAttributiEsterni.setOpId(iView.getOpId());
                            		tipoAttributiEsterniBeanManager.update(tipoAttributiEsterni);
                            	}
                            }
                        }
                    } else {
                    	storicDataUpdateHelper.updateAttributiEsterni(tipoAttributiEsterni.getAttributiesterniId(), tipoAttributiEsterni.getSoggettoId(), tipoAttributiEsterni.getValue(), tipoAttributiEsterni.getRightPk(), iView.getOpId(),tipoAttributiEsterni.getOpId());
                    	tipoAttributiEsterniBeanManager.remove(tipoAttributiEsterni);
					}
					causaleColn.remove(causale);
                }
            }
            final Iterator causaleIterator = causaleColn.iterator();
            final int causaleSize = causaleColn.size();
            TipoAttributiEsterniView  tipoAttributiEsterniView = null;
            for (int i = 0; i < causaleSize; i++) {
                causale = (String)causaleIterator.next();
                object = iView.getValueForThisProperty(causale);
                if (object != null) {
                    tipoAttributiEsterniView= new TipoAttributiEsterniView();
                    tipoAttributiEsterniView.setSoggettoId(soggettoId);
                    tipoAttributiEsterniView.setRightPk(getClassificazioneIdFromCausale(causale, "AEDPF"));
                    if (object instanceof ClassificazioneView) {
                        tipoAttributiEsterniView.setValue(((ClassificazioneView) object).getId().toString());
                    } else if(object instanceof it.sella.anagrafe.common.Nazione) {
						tipoAttributiEsterniView.setValue(((it.sella.anagrafe.common.Nazione)object).getNazioneId().toString());
					}else if(object instanceof it.sella.anagrafe.common.TAE) {
						tipoAttributiEsterniView.setValue(((it.sella.anagrafe.common.TAE)object).getTaeId().toString());
					}else if(object instanceof it.sella.anagrafe.common.SettoreDiAttivita) {
						tipoAttributiEsterniView.setValue(((it.sella.anagrafe.common.SettoreDiAttivita)object).getSettoreAttivitaId().toString());
					}else if(object instanceof it.sella.anagrafe.common.AlboProfessione) {
						tipoAttributiEsterniView.setValue(((it.sella.anagrafe.common.AlboProfessione)object).getAlboId().toString());
					} else {
                        tipoAttributiEsterniView.setValue(object.toString());
                    }
                    // This below handling is required in case of sconf. If the value of sconf is true it need not be inserted in the DB
                    tipoAttributiEsterniView.setOpId(iView.getOpId());
                    if (!"sconf".equals(causale)) {
                    	tipoAttributiEsterniBeanManager.create(tipoAttributiEsterniView);
                    } else {
                        if (!"true".equals(tipoAttributiEsterniView.getValue())) {
                        	tipoAttributiEsterniBeanManager.create(tipoAttributiEsterniView);
                        }
                    }
                }
            }
        }  catch (final InvocationTargetException ie) {
            log4Debug.warnStackTrace(ie);
            throw new AttributiEsterniDiscriminatorException(ie.getLocalizedMessage());
        } catch (final IllegalAccessException ae) {
            log4Debug.warnStackTrace(ae);
            throw new AttributiEsterniDiscriminatorException(ae.getLocalizedMessage());
        } catch (final NoSuchMethodException me) {
            log4Debug.warnStackTrace(me);
            throw new AttributiEsterniDiscriminatorException(me.getLocalizedMessage());
        } catch (final FinderException fe) {
            log4Debug.warnStackTrace(fe);
            throw new AttributiEsterniDiscriminatorException(fe.getLocalizedMessage());
        }  catch (final GestoreAnagrafeException e) {
            log4Debug.warnStackTrace(e);
            throw new AttributiEsterniDiscriminatorException(e.getLocalizedMessage());
        } catch (final ControlloDatiException e) {
            log4Debug.warnStackTrace(e);
            throw new AttributiEsterniDiscriminatorException(e.getLocalizedMessage());
		}
    }
}


