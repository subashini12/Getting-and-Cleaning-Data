package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BancaCheckUtil extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(BancaCheckUtil.class);

    public boolean checkForBanca(final Long soggettoId, Long bancaId) throws GestoreAnagrafeException, RemoteException {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet bancaResultSet = null;
        try {
            if (bancaId == null) {
				bancaId = SecurityHandler.getLoginBancaId();
			}
            final Long censtId = getClassificazioneIdFromCausale("CENST", "MOTIV");
            connection = getConnection();
            statement = connection.prepareStatement("select CL_LINKED_SOGGETTO from AN_TR_COLLAGAMENTO_SOGGETTO where CL_SOGGETTO_PRINCIPALE = ? and CL_LINKED_SOGGETTO = ? and CL_MOTIVO = ? and cl_data_fine is null");
            statement.setLong(1, bancaId.longValue());
            statement.setLong(2, soggettoId.longValue());
            statement.setLong(3, censtId.longValue());
            bancaResultSet = statement.executeQuery();
            return bancaResultSet.next();
        } catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreAnagrafeException(e.getMessage());
        } finally {
        	cleanup(connection, statement, bancaResultSet);
        }
    }

    
}
