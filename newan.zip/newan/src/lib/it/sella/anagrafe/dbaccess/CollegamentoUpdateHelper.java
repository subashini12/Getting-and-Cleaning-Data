package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.OperazioneCensimentoException;
import it.sella.anagrafe.collegamento.Collegamento;
import it.sella.anagrafe.collegamento.ICollegamentoBeanManager;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.discriminator.CollegamentoException;
import it.sella.anagrafe.implementation.SistemiEsterni;
import it.sella.anagrafe.util.PortafogliazioneClientelaAccessHelper;
import it.sella.anagrafe.util.PortafogliazioneClientelaException;
import it.sella.anagrafe.util.ReflectionUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;

import javax.ejb.FinderException;

public class CollegamentoUpdateHelper extends CollegamentoUpdateUtil {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CollegamentoUpdateHelper.class);

    public void deleteCollegamento(final Collection collegamentoViews, final String action, final Long opId) throws CollegamentoException, RemoteException {
        if (collegamentoViews != null) {
            final Iterator collIterator = collegamentoViews.iterator();
            final int collegamentoSize = collegamentoViews.size();
            it.sella.anagrafe.CollegamentoView collegamentoView = null;
            final Hashtable updateAccountHashtable = new Hashtable();
            try {
            	final ICollegamentoBeanManager collegamentoBeanManager = ((ICollegamentoBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.Collegamento"));
                final StoricDataUpdateHelper storicDataUpdateHelper = new StoricDataUpdateHelper();
                for (int i = 0; i < collegamentoSize; i++) {
                    collegamentoView = (it.sella.anagrafe.CollegamentoView) collIterator.next();
                    final Long principaleId = collegamentoView.getSoggettoPrincipaleId();
                    if (collegateAbilitatiMotivsExists(principaleId, collegamentoView.getMotivoCausale()) && (collegamentoView.getDataFine() == null)) {
                        if (updateAccountHashtable.get(String.valueOf(principaleId)) != null) {
                            String linkedIds = (String) updateAccountHashtable.get(String.valueOf(principaleId));
                            linkedIds = linkedIds + "," + collegamentoView.getLinkedSoggettoId();
                            updateAccountHashtable.put(String.valueOf(principaleId), linkedIds);
                        } else {
                            updateAccountHashtable.put(String.valueOf(principaleId), collegamentoView.getLinkedSoggettoId().toString());
                        }
                    }
                    if ("TERMINA".equals(action)) {
	                    collegamentoView.setDataFine(new Timestamp(System.currentTimeMillis()));
	                    collegamentoView.setOpId(opId);
	                    modifyCollegamento(collegamentoView.getCollegamentoId(), collegamentoView);
                    } else {
                        final Collegamento collegamento = collegamentoBeanManager.findByPrimaryKey(collegamentoView.getCollegamentoId());
                        storicDataUpdateHelper.updateCollegamentoSoggetto(collegamento.getCollegamentoId(), collegamento.getSoggettoId(), collegamento.getMotivo(), collegamento.getNote(), collegamento.getDataInizio(), collegamento.getDataFine(), collegamento.getLinkedSoggettoId(), opId,collegamento.getOpId());
                        collegamentoBeanManager.remove(collegamento);
                        new PortafogliazioneClientelaAccessHelper ().toRemoveClientWithPromoter(collegamento);
                    }
                }

                if (!updateAccountHashtable.isEmpty()) {
                    final Enumeration keys = updateAccountHashtable.keys();
                    while (keys.hasMoreElements()) {
                        final String principalSogIdString = (String) keys.nextElement();
                        final Long principalSoggettoId = Long.valueOf(principalSogIdString);
                        final Collection newCollegateCollection = getAbilitatiMotivCollection((String) updateAccountHashtable.get(principalSogIdString), ",", principalSoggettoId);
                        new SistemiEsterni().updateAccount(principalSoggettoId, newCollegateCollection);
                    }
                }
            } catch (final GestoreAnagrafeException e) {
                log4Debug.warnStackTrace(e);
                throw new CollegamentoException(e.getMessage());
            }  catch (final FinderException e) {
                log4Debug.warnStackTrace(e);
                throw new CollegamentoException(e.getMessage());
            } catch (final OperazioneCensimentoException e) {
                log4Debug.warnStackTrace(e);
                throw new CollegamentoException(e.getMessage());
            } catch (final ControlloDatiException e) {
                log4Debug.warnStackTrace(e);
                throw new CollegamentoException(e.getMessage());
			} catch (PortafogliazioneClientelaException e) {
				log4Debug.warnStackTrace(e);
			}
        }
    }
}

