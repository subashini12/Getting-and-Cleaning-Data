package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.UpdateAMMBALinkView;
import it.sella.anagrafe.UpdateAMMBAScanView;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.StringReader;
import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class AmministratoriBancaSetterHelper extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AmministratoriBancaSetterHelper.class);

    public void createExtractArt136( final List ammbaLinkList ) throws OperazioneAnagrafeManagerException, RemoteException {
        Connection connection = null;
        PreparedStatement progressStatement = null;
        final ResultSet ammbaResultSet = null;
    	try {
    		log4Debug.debug(" AmministratoriBancaSetterHelper : createExtractArt136 : ammbaLinkList size ===>",ammbaLinkList != null ? String.valueOf(ammbaLinkList.size()) : null);
    		if( ammbaLinkList != null && !ammbaLinkList.isEmpty()) {
    			final List codiceFiscaleList = new ArrayList(1);
                connection = getConnection();
                final int size = ammbaLinkList.size();
                UpdateAMMBALinkView updateAMMBALinkView = null;
                progressStatement = connection.prepareStatement("INSERT INTO AN_MA_EXART_136 ( ART_ID,  ART_CF, ART_INTESTAZIONE, ART_EXCEEDING_INTESTAZIONE, ART_OP_ID,ART_ABI_CODE ) VALUES ( ?, ?, ?, ?, ?, ?)");
                int count = 0;
                boolean skipExistInNull = false;
                boolean isInsert = false;
                String datiFiscali = null;
                String abiCode = null;
                String codiceFisOrPartitaIvaAbiCode = null;
                for( int i=0; i<size; i++ ) {
                	updateAMMBALinkView = (UpdateAMMBALinkView) ammbaLinkList.get(i);
                	skipExistInNull = false;
                	isInsert = false;
                	codiceFisOrPartitaIvaAbiCode = "";
                	if( updateAMMBALinkView != null ) {
                		datiFiscali = updateAMMBALinkView.getDatiFiscali() != null ? updateAMMBALinkView.getDatiFiscali().trim().toUpperCase() : null;
                		abiCode = updateAMMBALinkView.getAbiCode();
                		if( datiFiscali == null || datiFiscali.length() == 0 ) {
                			skipExistInNull = true;
                			isInsert = true;
                		} 
                		if( !skipExistInNull ){//added this line of code to insert same codiceFiscale/PartitaIva exists across banks (Records may exist with abicode or can be null) 
                			codiceFisOrPartitaIvaAbiCode = abiCode!= null ? datiFiscali +"_"+ abiCode : datiFiscali;
                		}
                		if( !skipExistInNull && !codiceFiscaleList.contains(codiceFisOrPartitaIvaAbiCode))  {
                			codiceFiscaleList.add(codiceFisOrPartitaIvaAbiCode);
                			isInsert = true;
                		}
                		if( isInsert ) {
                    		progressStatement.setLong(1,++count);
                    		progressStatement.setString(2,datiFiscali);
                    		progressStatement.setString(3,updateAMMBALinkView.getIntestazione() != null ? updateAMMBALinkView.getIntestazione().trim() : null);
                    		progressStatement.setString(4,updateAMMBALinkView.getExceedingIntestazione() != null ? updateAMMBALinkView.getExceedingIntestazione().trim() : null);
                    		if( updateAMMBALinkView.getOpId() != null ) {
                    			progressStatement.setLong(5, updateAMMBALinkView.getOpId().longValue());	
                    		} else {
                    			progressStatement.setNull(5, Types.NUMERIC);
                    		}
                    		progressStatement.setString(6,abiCode);
                    		progressStatement.addBatch();
                		}
                	}
                }
        		progressStatement.executeBatch();
    		}
    	} catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new OperazioneAnagrafeManagerException(se.getMessage());
        } finally {
            cleanup(connection, progressStatement, ammbaResultSet);
        }
    }
    
    public void deleteAllExtractArt136() throws OperazioneAnagrafeManagerException, RemoteException {
        Connection connection = null;
        PreparedStatement progressStatement = null;
        final ResultSet ammbaResultSet = null;
    	try {
    		deleteAllExtendArt136Scan();
            connection = getConnection();
    		progressStatement = connection.prepareStatement("DELETE FROM AN_MA_EXART_136");
    		progressStatement.executeUpdate();
    	} catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new OperazioneAnagrafeManagerException(se.getMessage());
        } finally {
            cleanup(connection, progressStatement, ammbaResultSet);
        }
    } 
    
    public void deleteAllExtendArt136Scan() throws OperazioneAnagrafeManagerException, RemoteException {
        Connection connection = null;
        PreparedStatement progressStatement = null;
        final ResultSet ammbaResultSet = null;
    	try {
            connection = getConnection();
    		progressStatement = connection.prepareStatement("DELETE FROM AN_TMP_ART136_EXTENDED_SCAN");
    		progressStatement.executeUpdate();
    	} catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new OperazioneAnagrafeManagerException(se.getMessage());
        } finally {
            cleanup(connection, progressStatement, ammbaResultSet);
        }
    }

    public void createExtendArt136Scan() throws OperazioneAnagrafeManagerException, RemoteException {
    	CallableStatement callableStatement = null;
    	 Connection connection = null;
    	try {
            connection = getConnection();
            log4Debug.warn(" AmministratoriBancaSetterHelper : createExtendArt136Scan : ==>>");
            callableStatement = connection.prepareCall("{call AN_PR_UPD_ART136LINK( ? )}");
            callableStatement.setLong(1, SecurityHandler.getLoginBancaId().longValue());
            callableStatement.executeUpdate();
    	} catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new OperazioneAnagrafeManagerException(se.getMessage());
        } catch (final SubSystemHandlerException se) {
            log4Debug.warnStackTrace(se);
            throw new OperazioneAnagrafeManagerException(se.getMessage());
        } finally {
            cleanup(connection, callableStatement);
        }
    }
    
    public void updateExtendArt136ScanStatus( final UpdateAMMBAScanView updateAMMBAScanView ) throws OperazioneAnagrafeManagerException, RemoteException {
        Connection connection = null;
        PreparedStatement progressStatement = null;
        try {
            connection = getConnection();
            log4Debug.debug(" AmministratoriBancaSetterHelper : updateExtendArt136ScanStatus : pkId ==>>",updateAMMBAScanView.getId());
            log4Debug.debug(" AmministratoriBancaSetterHelper : updateExtendArt136ScanStatus : ART_SC_HOST_DATA_FINE ==>>",updateAMMBAScanView.getHostDataFine());
            log4Debug.debug(" AmministratoriBancaSetterHelper : updateExtendArt136ScanStatus : ART_SC_HOST_STATUS ==>>",updateAMMBAScanView.getHostStatus());
            log4Debug.debug(" AmministratoriBancaSetterHelper : updateExtendArt136ScanStatus : ART_SC_MAPPER_MSG ==>>",updateAMMBAScanView.getMapperMessage());
            
            progressStatement = connection.prepareStatement(" UPDATE AN_TMP_ART136_EXTENDED_SCAN SET ART_SC_HOST_STATUS = ?, ART_SC_HOST_DATA_FINE = ?, ART_SC_MAPPER_MSG = ?, ART_SC_ALIGN_HOST = ?  WHERE ART_SC_ID = ? AND ART_SC_SOGGETTO_PRINCIPALE_ID = ? ");
            progressStatement.setString(1, updateAMMBAScanView.getHostStatus());
            progressStatement.setTimestamp(2,updateAMMBAScanView.getHostDataFine());
            progressStatement.setCharacterStream(3, new StringReader(updateAMMBAScanView.getMapperMessage()), updateAMMBAScanView.getMapperMessage().length());
            progressStatement.setString(4, updateAMMBAScanView.getAlignHost());
            if ( updateAMMBAScanView.getId() != null ) {
            	progressStatement.setLong(5, updateAMMBAScanView.getId().longValue());	
            } else {
            	progressStatement.setNull(5, Types.NUMERIC);
            }
            progressStatement.setLong(6, SecurityHandler.getLoginBancaId().longValue());
            progressStatement.executeUpdate();
    	} catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new OperazioneAnagrafeManagerException(se.getMessage());
        } catch (final SubSystemHandlerException se) {
            log4Debug.warnStackTrace(se);
            throw new OperazioneAnagrafeManagerException(se.getMessage());
        } finally {
            cleanup(connection, progressStatement);
        }
    }
}
