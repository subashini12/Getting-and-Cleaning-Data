package it.sella.anagrafe.dbaccess.dai;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import it.sella.anagrafe.DAIConfigException;
import it.sella.anagrafe.DAIPesoException;
import it.sella.anagrafe.DAIPesoView;
import it.sella.anagrafe.IDAIPesoView;
import it.sella.anagrafe.dbaccess.DBAccessHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

/**
 * @author GBS03447
 *
 */
public class DAIPesoGetterHelper extends DBAccessHelper {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DAIPesoGetterHelper.class);
	
	/**
	 * This Method Returns Peso View For the given Input Id.
	 * Not Used
	 * @param pesoId
	 * @return
	 * @throws DAIPesoException
	 */
	public IDAIPesoView getPesoViewById(final Long pesoId) throws DAIPesoException {
		
		IDAIPesoView pesoView = null;
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		query.append("SELECT DP_ID, DP_DAI_GR_TYPE_ID, DP_DAI_CODE_PR_ID, DP_DATA_INIZIO, DP_DATA_FINE FROM AN_MA_DAI_PESO WHERE DP_ID = ?");
		
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setLong(1, pesoId);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				pesoView = getPesoView(resultSet);
			}
		} catch (final SQLException e) {
			log4Debug.severeStackTrace(e);
			throw new DAIPesoException(e.getMessage(), e);
		} catch (final DAIConfigException e) {
			log4Debug.severeStackTrace(e);
			throw new DAIPesoException(e.getMessage(), e);
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return pesoView;
	}
	
	/**
	 * This Method Returns Peso View For the given Input of Group Id and Regoleconfig Id
	 * @param daiTypeId
	 * @param daiCodeId
	 * @return
	 * @throws DAIPesoException
	 */
	public IDAIPesoView getPesoView (final Long daiTypeId, final Long daiCodeId) throws DAIPesoException {
		IDAIPesoView pesoView = null;
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		query.append("SELECT DP_ID, DP_DAI_GR_TYPE_ID, DP_DAI_CODE_PR_ID, DP_DATA_INIZIO, DP_DATA_FINE FROM AN_MA_DAI_PESO WHERE DP_DAI_GR_TYPE_ID = ? AND DP_DAI_CODE_PR_ID = ? AND DP_DATA_FINE IS NULL");
		
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setLong(1, daiTypeId);
			statement.setLong(2, daiCodeId);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				pesoView = getPesoView(resultSet);
			}
		} catch (final SQLException e) {
			log4Debug.severeStackTrace(e);
			throw new DAIPesoException(e.getMessage(), e);
		} catch (DAIConfigException e) {
			log4Debug.severeStackTrace(e);
			throw new DAIPesoException(e.getMessage(), e);
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return pesoView;
	}

	/**
	 * @param resultSet
	 * @return
	 * @throws SQLException
	 * @throws DAIConfigException
	 */
	private IDAIPesoView getPesoView(ResultSet resultSet) throws SQLException, DAIConfigException {
		final IDAIPesoView pesoView = new DAIPesoView();
		pesoView.setPesoId(resultSet.getLong("DP_ID"));
		pesoView.setDaiGroupType(resultSet.getString("DP_DAI_GR_TYPE_ID") != null ? new DAIConfigGetterHelper().getDAIConfig(resultSet.getLong("DP_DAI_GR_TYPE_ID")) : null);
		pesoView.setDaiCode(resultSet.getString("DP_DAI_CODE_PR_ID") != null ? new DAIConfigGetterHelper().getDAIConfig(resultSet.getLong("DP_DAI_CODE_PR_ID")) : null);
		pesoView.setDataInizio(resultSet.getTimestamp("DP_DATA_INIZIO"));
		pesoView.setDatFine(resultSet.getTimestamp("DP_DATA_FINE"));
		return pesoView;
	}
}
