package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreProvinciaException;
import it.sella.anagrafe.view.CompSettoreClasseView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CompSettoreClasseDBAccessHelper extends DBAccessHelper {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CompSettoreClasseDBAccessHelper.class);
	
	public CompSettoreClasseView getCompSettoreClasse(final Long classeATECO2007Id , final Long settoreId) throws GestoreAnagrafeException {
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;
	    try {
	    	final StringBuilder queryBuilder = new StringBuilder("SELECT CP_ID,CP_SETT_ID,CP_CLAS_ID FROM ");
	        queryBuilder.append("AN_MA_COMP_SETTORE_CLASSE  WHERE CP_CLAS_ID=? AND CP_SETT_ID = ?");
	        connection = getConnection();
	        preparedStatement = connection.prepareStatement(queryBuilder.toString());
	        preparedStatement.setLong(1, classeATECO2007Id);
	        preparedStatement.setLong(2, settoreId);
	        resultSet = preparedStatement.executeQuery();
	        CompSettoreClasseView compSettoreClasseView = null;
	        if (resultSet.next()) {
	        	compSettoreClasseView = new CompSettoreClasseView();
	        	compSettoreClasseView.setCompSettoreClasseId(resultSet.getLong("CP_ID"));
	        	compSettoreClasseView.setSettoreId(resultSet.getLong("CP_SETT_ID"));
	        	compSettoreClasseView.setClasseATECO2007Id(resultSet.getLong("CP_CLAS_ID"));
	        }
	        return compSettoreClasseView;
	    } catch (final SQLException se) {
	    	log4Debug.severeStackTrace(se);
	        throw new GestoreProvinciaException(se.getMessage());
	    } finally {
	    	cleanup(connection, preparedStatement, resultSet);
	    }
   }
	
	public List<CompSettoreClasseView> getCompSettoreClasse(final String codiceSoggettoGruppo) throws GestoreAnagrafeException {
    	final List<CompSettoreClasseView> compSettoreClasseList = new ArrayList<CompSettoreClasseView>(); 
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;
	    try {
	    	final StringBuilder queryBuilder = new StringBuilder("SELECT CP_ID, CP_SETT_ID, CP_CLAS_ID, CA.CL_COD,CA.CL_DESC ");
	        queryBuilder.append("FROM AN_MA_COMP_SETTORE_CLASSE CP, AN_MA_SETTORE ST,AN_MA_CLASSE_ATECO2007 CA ");
	        queryBuilder.append("WHERE CP.CP_SETT_ID = ST.ST_SETTORE_ID AND CA.CL_ID = CP.CP_CLAS_ID ");
	        queryBuilder.append("AND ST.ST_CODICESOTTOGRUPPO = ?");
	        connection = getConnection();
	        preparedStatement = connection.prepareStatement(queryBuilder.toString());
	        preparedStatement.setString(1, codiceSoggettoGruppo);
	        resultSet = preparedStatement.executeQuery();
	        CompSettoreClasseView compSettoreClasseView = null;
	        while (resultSet.next()) {
	        	compSettoreClasseView = new CompSettoreClasseView();
	        	compSettoreClasseView.setCompSettoreClasseId(resultSet.getLong("CP_ID"));
	        	compSettoreClasseView.setSettoreId(resultSet.getLong("CP_SETT_ID"));
	        	compSettoreClasseView.setClasseATECO2007Id(resultSet.getLong("CP_CLAS_ID"));
	        	compSettoreClasseView.setCode(resultSet.getString("CL_COD"));
	        	compSettoreClasseView.setDescrpition(resultSet.getString("CL_DESC"));
	        	compSettoreClasseList.add(compSettoreClasseView);
	        }
	        return compSettoreClasseList;
	    } catch (final SQLException se) {
	    	log4Debug.severeStackTrace(se);
	        throw new GestoreProvinciaException(se.getMessage());
	    } finally {
	    	cleanup(connection, preparedStatement, resultSet);
	    }
   }
	
	
}
