package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAttributiEsterniException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

public class AESoggettoIdGetter extends DBAccessHelper {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AESoggettoIdGetter.class);
    
    public Collection getSoggettoIdForTipoAttributoEsterno(
			final String tipoAttributiCausale, final String valoreAttributiesterniCausale)
			throws GestoreAttributiEsterniException, RemoteException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet attributiRset = null;
        Collection attributeVector = null;
        final String[] attributiCausales = {"instr", "stato", "settore", "datareg", "ramo", "finv", "fpens", "tredieci", "onlus", "ecomm", "sconf","classe","cosg","susg","disg","dfsg","parpr","atrpr"};
        boolean check = false;
        for (int i = 0; i < attributiCausales.length; i++) {
            if (attributiCausales[i].equals(tipoAttributiCausale)) {
                check = true;
                break;
            }
        }
        try {
            connection = getConnection();
            final StringBuffer query = new StringBuffer("Select /*+ index(CS AN_COLL_LS_MOTIV_SP_IN1002) */ AE.AE_SOGGETTO_ID ");
            	query.append("from AN_TR_ATTRIBUTIESTERNI AE, AN_TR_COLLAGAMENTO_SOGGETTO CS where ");
            	query.append("CS.CL_SOGGETTO_PRINCIPALE =?  and CS.CL_MOTIVO = ?  and cs.cl_data_fine is null ");
            	query.append("and CS.CL_LINKED_SOGGETTO = AE.AE_SOGGETTO_ID   and AE.AE_VALUE =? ");
            	query.append("AND AE_RIGHT_PK =?");
            selectStatement = connection.prepareStatement(query.toString());
            selectStatement.setLong(1, SecurityHandler.getLoginBancaId().longValue());
            selectStatement.setLong(2, getClassificazioneIdFromCausale("CENST", "MOTIV").longValue());
            if (check) {
                selectStatement.setString(3, valoreAttributiesterniCausale);
            } else {
                selectStatement.setString(3, getClassificazioneIdFromCausale(valoreAttributiesterniCausale, tipoAttributiCausale).toString());
            }
            selectStatement.setLong(4, getClassificazioneIdFromCausale(tipoAttributiCausale, "AEDPF"));	
            attributiRset = selectStatement.executeQuery();
            attributeVector = new ArrayList();
            while (attributiRset.next()) {
                attributeVector.add(Long.valueOf(attributiRset.getLong("AE_SOGGETTO_ID")));
            }
        } catch (final SQLException sqlEx) {
            log4Debug.severeStackTrace(sqlEx);
            throw new GestoreAttributiEsterniException(sqlEx.getMessage());
        } catch (final SubSystemHandlerException findEx) {
            log4Debug.severeStackTrace(findEx);
            throw new GestoreAttributiEsterniException(findEx.getMessage());
        } finally {
            cleanup(connection, selectStatement, attributiRset);
        }
        return attributeVector;
    }

}


