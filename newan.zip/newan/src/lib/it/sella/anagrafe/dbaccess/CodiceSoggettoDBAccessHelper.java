package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.anagrafe.discriminator.CodiceSoggettoDiscriminatorException;
import it.sella.anagrafe.implementation.IView;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.List;

public class CodiceSoggettoDBAccessHelper {
	
    public String getValoreCodiciSoggetto( final Long soggettoId, final String causale ) throws GestoreCodiciSoggettoException, RemoteException {
    	return new CS_valoreGetter().getValoreCodiciSoggetto(soggettoId, causale);
    }

    public String getValoreCodiciSoggettoWithSpecificBank( final Long soggettoId, final Long bankSoggettoId, final String causale ) throws GestoreCodiciSoggettoException, RemoteException {
    	return new CS_valoreGetter().getValoreCodiciSoggettoWithSpecificBank(soggettoId, bankSoggettoId, causale);
    }
    
    public Collection getCodiciSoggetto( final Long soggettoId ) throws GestoreCodiciSoggettoException, RemoteException {
    	return new CS_valoreGetter().getCodiciSoggetto(soggettoId);
    }

    public Collection getCodiciSoggettoBasedOnSoggettoId( final Long soggettoId ) throws GestoreCodiciSoggettoException, RemoteException {
    	return new CS_valoreGetter().getCodiciSoggettoBasedOnSoggettoId(soggettoId);
    }
    
    public Long getSoggettoIdCS( final String causale, final String valoreCodiceSoggetto ) throws GestoreCodiciSoggettoException, RemoteException {
    	return new CSSoggettoIdGetter().getSoggettoIdCS(causale, valoreCodiceSoggetto);
    }

    public Collection getAllSoggettoIdCS( final String causale, final String valoreCodiceSoggetto ) throws GestoreCodiciSoggettoException, RemoteException {
    	return new CSSoggettoIdGetter().getAllSoggettoIdCS(causale, valoreCodiceSoggetto);
    }

    public void createCodiciSoggetto( final Long soggettoId, final IView iView ) throws CodiceSoggettoDiscriminatorException, RemoteException {
    	new CodiceSoggettoCreateHelper().createCodiciSoggetto(soggettoId, iView);
    }

    public void setCodiciSoggetto( final Long soggettoId, final IView iView ) throws CodiceSoggettoDiscriminatorException, RemoteException {
    	new CodiceSoggettoUpdateHelper().setCodiciSoggetto(soggettoId, iView);
    }

    public Long findByNDGNonOperativa( final IView iView ) throws CodiceSoggettoDiscriminatorException, RemoteException {
    	return new CodiceSoggettoFinder().findByNDGNonOperativa(iView);
    }

    public void setCodiceValues( final Long soggettoId, final String value, final String causale, final Long opId ) throws CodiceSoggettoDiscriminatorException, RemoteException {
    	new CodiceSoggettoUpdateHelper().setCodiceValues(soggettoId, value, causale, opId);
    }

    public IView getCodiciSoggettoForOPBean( final Long soggettoId ) throws CodiceSoggettoDiscriminatorException, RemoteException {
    	return new CodiceSoggettoPFViewBuilder().getCodiciSoggettoPFView(soggettoId);
    }

    public void createCodiciSoggettoCifrati( final Long soggettoId, final String valoreCodiceHost, final Long opId ) throws CodiceSoggettoDiscriminatorException, RemoteException {
    	new CodiceSoggettoCreateHelper().createCodiciSoggettoCifrati(soggettoId, valoreCodiceHost, opId);
    }

    public void setCodiceSoggettoCifratiValues( final Long soggettoId, final String newValoreCodiceHost, final Long opId ) throws CodiceSoggettoDiscriminatorException, RemoteException {
    	new CodiceSoggettoUpdateHelper().setCodiceSoggettoCifratiValues(soggettoId, newValoreCodiceHost, opId);
    }

    public void removeCodiceSoggettoCifrati( final Long soggettoId, final Long opId ) throws CodiceSoggettoDiscriminatorException, RemoteException {
    	new CodiceSoggettoUpdateHelper().removeCodiceSoggettoCifrati(soggettoId, opId);
    }
    public List getSoggettoIdListForCodiceHost(final String codiceHost) throws GestoreCodiciSoggettoException, RemoteException {
    	return new CSSoggettoIdGetter().getSoggettoIdListForCodiceHost(codiceHost);
    }
}
