package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.util.ConnectionHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

/**
 * Class to get data regarding Bank address from Data Base.
 *
 */
public class BankAddressDBAccess extends ConnectionHandler {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(BankAddressDBAccess.class);

	/**
	 * Method to get list of all the bank address names.
	 * @return
	 * @throws GestoreAnagrafeException 
	 */
	public Collection<String> getListOfBankAddressNames() throws GestoreAnagrafeException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		 Collection<String> bankNamesColl = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("SELECT  BA.BA_BANK_ADDRESS FROM AN_MA_BANK_ADDRESS BA");
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				if(bankNamesColl ==null ){
					bankNamesColl = new ArrayList<String>();
				}
				bankNamesColl.add(resultSet.getString("BA_BANK_ADDRESS"));
			}						
		}catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new GestoreAnagrafeException(sqlexception.getMessage());
		}
		finally {
			cleanup(connection, preparedStatement,resultSet);
		}
		return bankNamesColl;
	}
}
