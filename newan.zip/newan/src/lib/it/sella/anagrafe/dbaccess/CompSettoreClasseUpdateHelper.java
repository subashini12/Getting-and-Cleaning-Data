package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreClasseATECOException;
import it.sella.anagrafe.view.CompSettoreClasseView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CompSettoreClasseUpdateHelper extends DBAccessHelper {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CompSettoreClasseUpdateHelper.class);
	
	public Long createCompSettoreClasse(final CompSettoreClasseView compSettoreClasseView)
	throws GestoreClasseATECOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        final StringBuilder querybuilder = new StringBuilder();
        Long compSettoreClasseId = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("SELECT AN_CO_SQ_CP_ID.NEXTVAL FROM DUAL");
            resultSet = preparedStatement.executeQuery();
            if( resultSet.next() ) {
            	compSettoreClasseId = resultSet.getLong(1);
            }
            closeStatement(preparedStatement);
            
            querybuilder.append("INSERT INTO AN_MA_COMP_SETTORE_CLASSE (CP_ID,CP_SETT_ID,CP_CLAS_ID)");
            querybuilder.append("VALUES (?,?,?)");
            preparedStatement = connection.prepareStatement(querybuilder.toString());
            preparedStatement.setLong(1, compSettoreClasseId);
            preparedStatement.setLong(2, compSettoreClasseView.getSettoreId());
            preparedStatement.setLong(3, compSettoreClasseView.getClasseATECO2007Id());
            preparedStatement.executeUpdate();
            return compSettoreClasseId;
        } catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new GestoreClasseATECOException(se.getLocalizedMessage());
        } finally {
            cleanup(connection, preparedStatement, resultSet);
        }
	}

	public void updateCompSettoreClasse(final CompSettoreClasseView compSettoreClasseView)
	throws GestoreClasseATECOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        final StringBuilder querybuilder = new StringBuilder();
        try {
            connection = getConnection();
            querybuilder.append("UPDATE AN_MA_COMP_SETTORE_CLASSE SET CP_SETT_ID = ?, CP_CLAS_ID = ? ");
            querybuilder.append("WHERE CP_ID = ? ");
            preparedStatement = connection.prepareStatement(querybuilder.toString());
            preparedStatement.setLong(1, compSettoreClasseView.getSettoreId());
            preparedStatement.setLong(2, compSettoreClasseView.getClasseATECO2007Id());
            preparedStatement.setLong(3, compSettoreClasseView.getCompSettoreClasseId());
            preparedStatement.executeUpdate();
        } catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new GestoreClasseATECOException(se.getLocalizedMessage());
        } finally {
            cleanup(connection, preparedStatement);
        }
	}
	
	public void deleteCompSettoreClasse(final Long compSettoreClasseId ) throws GestoreClasseATECOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        final StringBuilder querybuilder = new StringBuilder();
        try {
            connection = getConnection();
            querybuilder.append("DELETE FROM AN_MA_COMP_SETTORE_CLASSE WHERE CP_ID = ?");
            preparedStatement = connection.prepareStatement(querybuilder.toString());
            preparedStatement.setLong(1, compSettoreClasseId);
            preparedStatement.executeUpdate();
        } catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new GestoreClasseATECOException(se.getLocalizedMessage());
        } finally {
            cleanup(connection, preparedStatement);
        }
	}
}