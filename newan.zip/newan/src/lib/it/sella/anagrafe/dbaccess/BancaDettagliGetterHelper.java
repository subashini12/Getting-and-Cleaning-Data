package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.discriminator.CollegamentoException;
import it.sella.anagrafe.view.BancaView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.StringTokenizer;

public class BancaDettagliGetterHelper extends DBAccessHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(BancaDettagliGetterHelper.class);

    public Collection getAllBanks() throws GestoreAnagrafeException, RemoteException {
        Connection connection = null;
        final Collection bancaViewsCollection = new ArrayList();
        CallableStatement callableStatement = null;
        String output = null;
        try {
            connection = getConnection();
            callableStatement = connection.prepareCall("{ CALL ? := An_Pkg_Anagrafe.AN_FN_ALLBANKIDS }");
            callableStatement.registerOutParameter(1, java.sql.Types.VARCHAR);
            callableStatement.executeUpdate();
            output = callableStatement.getString(1);
            if(output != null) {
                final StringTokenizer token = new StringTokenizer(output, ",");
                while(token.hasMoreTokens()) {
                    final StringTokenizer bancaToken = new StringTokenizer(token.nextToken(), ":");
                    while(bancaToken.hasMoreTokens()) {
                        final BancaView bancaView = new BancaView();
                        bancaView.setDenominazione(bancaToken.nextToken());
                        bancaView.setBancaId(Long.valueOf(bancaToken.nextToken()));
                        bancaView.setAbiCode(new CS_valoreGetter().getValoreCodiciSoggettoWithSpecificBank(
                        		bancaView.getBancaId(), bancaView.getBancaId(), "abi"));
                        bancaViewsCollection.add(bancaView);
                    }
                }
            }
        } catch (final SQLException e) {
            log4Debug.severeStackTrace(e);
            throw new GestoreAnagrafeException(e.getMessage());
        } finally {
            cleanup(connection, callableStatement);
        }
        return bancaViewsCollection;
    }
    
    public List<Long> getAllBankSoggettoIds() throws CollegamentoException {
    	final List<Long> collegamentoList = new ArrayList<Long>(1);
        Connection connection = null;
        PreparedStatement  preparedStatement = null;
        ResultSet collegamentoResultSet = null;
        final StringBuilder query = new StringBuilder();
        try {
        	connection = getConnection();
        	query.append("SELECT SOGGETTO_ID from table ( an_pkg_igestore_anagrafe.AN_FN_ALLBANKIDS())");
        	preparedStatement = connection.prepareStatement(query.toString());
        	collegamentoResultSet = preparedStatement.executeQuery();
        	while( collegamentoResultSet.next() ) {
        		collegamentoList.add(collegamentoResultSet.getLong("SOGGETTO_ID"));
        	}
        } catch (final SQLException se) {
        	 log4Debug.warnStackTrace(se);
             throw new CollegamentoException(se.getLocalizedMessage());
        } finally {
            cleanup(connection, preparedStatement, collegamentoResultSet);
        }
        return collegamentoList;
   }

    public String getCheckDipct(final Long bankId) throws GestoreAnagrafeException {
        Connection connection = null;
        CallableStatement callableStatement = null;
        String output = null;
        try {
            connection = getConnection();
            callableStatement = connection.prepareCall("{ CALL ? := AN_PKG_IGESTORE_ANAG_MASTER.AN_FN_CHECK_DIPCT(?) }");
            callableStatement.registerOutParameter(1, java.sql.Types.VARCHAR);
            callableStatement.setLong(2, bankId);
            callableStatement.executeUpdate();
            output = callableStatement.getString(1);
        } catch (final SQLException e) {
            log4Debug.severeStackTrace(e);
            throw new GestoreAnagrafeException(e.getMessage());
        } finally {
            cleanup(connection, callableStatement);
        }
        return output;
    }
}
