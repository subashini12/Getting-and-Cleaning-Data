package it.sella.anagrafe.dbaccess.dai;

import java.rmi.RemoteException;

import javax.ejb.FinderException;

import it.sella.anagrafe.AnagrafeDAIException;
import it.sella.anagrafe.DAIRegoleException;
import it.sella.anagrafe.DAISoggettoException;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.IDAIConfigView;
import it.sella.anagrafe.IDAIRegoleDetailsView;
import it.sella.anagrafe.IDAIWeightageView;
import it.sella.anagrafe.SoggettoDAIDataView;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.dairegole.DAIRegole;
import it.sella.anagrafe.dairegole.DAIRegoleView;
import it.sella.anagrafe.daisoggetto.DAISoggetto;
import it.sella.anagrafe.daisoggetto.DAISoggettoView;
import it.sella.anagrafe.dbaccess.StoricDataUpdateHelper;
import it.sella.anagrafe.factory.DAIRegoleFactory;
import it.sella.anagrafe.factory.DAISoggettoFactory;
import it.sella.anagrafe.util.UtilHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

/**
 * @author GBS03447
 *
 */
public class AnagrafeDAIUpdateHelper {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AnagrafeDAIUpdateHelper.class);
	
	/**
	 * To Create DAI Regole Data (Insert)
	 * @param regoleDetailsView
	 * @param soggettoId
	 * @throws AnagrafeDAIException
	 */
	public void createDAIRegole (final IDAIRegoleDetailsView regoleDetailsView, final Long soggettoId, final Long opId) throws AnagrafeDAIException, RemoteException {
		final DAIRegoleView daiRegoleView = new DAIRegoleView();
		daiRegoleView.setSoggettoId(soggettoId);
		daiRegoleView.setPesoId(regoleDetailsView.getDaiPeso().getPesoId());
		daiRegoleView.setDaiCodeId(regoleDetailsView.getDaiCodeId().getId());
		daiRegoleView.setDaiWeightId(regoleDetailsView.getDaiWeight().getDaiConfigId());
		daiRegoleView.setOpId(opId);
		try {
			final DAIRegole regole = DAIRegoleFactory.getInstance().getDAIRegoleBeanManager().create(daiRegoleView);
			regoleDetailsView.setId(regole != null ? regole.getDaiRegoleId() : null); // Based on this Id ..DAI SOggetto data will persist
		} catch (final GestoreAnagrafeException e) {
			log4Debug.severeStackTrace(e);
			throw new AnagrafeDAIException(e.getMessage(), e);
		}
	}
	
	/**
	 * To Update DAI Regole Data (Insert / update)
	 * @param regoleDetailView
	 * @param soggettoId
	 * @param opId
	 * @throws RemoteException
	 * @throws AnagrafeDAIException
	 */
	public void setDAIRegole(final IDAIRegoleDetailsView regoleDetailView, final Long soggettoId, final Long opId) throws RemoteException, AnagrafeDAIException {

		try {
			if(regoleDetailView.getDaiPeso() != null && regoleDetailView.getDaiPeso().getPesoId() != null) {
				final DAIRegole daiRegoleDBView = DAIRegoleFactory.getInstance().getDAIRegoleBeanManager().findBySoggettoIdAndPesoId(soggettoId, regoleDetailView.getDaiPeso().getPesoId());
				regoleDetailView.setId(daiRegoleDBView.getDaiRegoleId());  // Based on this Id ..DAI SOggetto data will persist
				if (!checkWeightCodeIdEquality( daiRegoleDBView.getDaiCodeId(), regoleDetailView.getDaiCodeId())
						|| !checkWeightIdEquality(daiRegoleDBView.getDaiWeightId(), regoleDetailView.getDaiWeight())) {
					
					daiRegoleDBView.setOpId(opId);
					daiRegoleDBView.setDaiCodeId(regoleDetailView.getDaiCodeId() != null ? regoleDetailView.getDaiCodeId().getId() : null);
					daiRegoleDBView.setDaiWeightId(regoleDetailView.getDaiWeight() != null ? regoleDetailView.getDaiWeight().getDaiConfigId() : null);
					
					DAIRegoleFactory.getInstance().getDAIRegoleBeanManager().update(daiRegoleDBView);
					
				}
			}
		} catch (final FinderException e) {
			log4Debug.debugStackTrace(e);
			createDAIRegole(regoleDetailView, soggettoId, opId);
		}
	}
	
	/**
	 * @param regoleDetailView
	 * @param soggettoId
	 * @param opId
	 * @throws DAIRegoleException
	 */
	public void removeDAIReole(final IDAIRegoleDetailsView regoleDetailView, final Long soggettoId, final Long opId) throws DAIRegoleException {
		
		try {
			if(regoleDetailView.getDaiPeso() != null && regoleDetailView.getDaiPeso().getPesoId() != null) {
				final DAIRegole daiRegoleDBView = DAIRegoleFactory.getInstance().getDAIRegoleBeanManager().findBySoggettoIdAndPesoId(soggettoId, regoleDetailView.getDaiPeso().getPesoId());
				
				new StoricDataUpdateHelper().updateStoricDAIRegoleData(daiRegoleDBView, opId);
				DAIRegoleFactory.getInstance().getDAIRegoleBeanManager().remove(daiRegoleDBView);
			}
		} catch (final FinderException e) {
			log4Debug.debugStackTrace(e);
		} catch (final ControlloDatiException e) {
			log4Debug.debugStackTrace(e);
			throw new DAIRegoleException(e.getMessage());
		}
	}
	
	/**
	 * To Create DAI Soggetto Data (Insert)
	 * @param daiSoggettoView
	 * @param soggettoId
	 * @param opId
	 * @throws DAISoggettoException
	 */
	public void createDAISoggetto (final SoggettoDAIDataView daiSoggettoView, final Long soggettoId, final Long opId) throws DAISoggettoException {
		try {
			if(daiSoggettoView != null) {
				final DAISoggettoView daiView = new DAISoggettoView();
				daiView.setSoggettoId(soggettoId);
				daiView.setRegoleId(daiSoggettoView.getDaiRegoleData() != null ? daiSoggettoView.getDaiRegoleData().getId() : null);
				daiView.setDaiWeightId(daiSoggettoView.getDaiWeightId() != null ? daiSoggettoView.getDaiWeightId().getDaiConfigId() : null );
				daiView.setOpId(opId);
				
				DAISoggettoFactory.getInstance().getDAISoggettoBeanManager().create(daiView);
			}
		} catch (final GestoreAnagrafeException e) {
			log4Debug.severeStackTrace(e);
			throw new DAISoggettoException(e.getMessage(), e);
		}
	}
	
	/**
	 * To update DAI Soggetto Data (update / Insert)
	 * @param daiSoggettoViewNew
	 * @param daiSoggettoViewOld
	 * @param soggettoId
	 * @param opId
	 * @throws DAISoggettoException 
	 */
	public void setDAISoggetto(final SoggettoDAIDataView daiSoggettoViewNew, final Long soggettoId, final Long opId) throws DAISoggettoException {
		try {
			if (daiSoggettoViewNew != null) {
				final DAISoggetto daiSoggettoDBView = DAISoggettoFactory.getInstance().getDAISoggettoBeanManager().findBySoggettoId(soggettoId);
				
				if(!checkDaiEquality(daiSoggettoDBView.getRegoleId(), daiSoggettoViewNew.getDaiRegoleData()) || !checkDaiEquality(daiSoggettoDBView.getDaiWeightId(), daiSoggettoViewNew.getDaiWeightId())) {
					daiSoggettoDBView.setOpId(opId);
					daiSoggettoDBView.setRegoleId(daiSoggettoViewNew.getDaiRegoleData() != null ? daiSoggettoViewNew.getDaiRegoleData().getId() : null);
					daiSoggettoDBView.setDaiWeightId(daiSoggettoViewNew.getDaiWeightId() != null ? daiSoggettoViewNew.getDaiWeightId().getDaiConfigId() : null);
					DAISoggettoFactory.getInstance().getDAISoggettoBeanManager().update(daiSoggettoDBView);
				}
				
			}
		} catch (final FinderException e) {
			log4Debug.debugStackTrace(e);
			createDAISoggetto(daiSoggettoViewNew, soggettoId, opId);
		}
	}
	
	/**
	 * @param weightCodeId
	 * @param daiWeightageNew
	 * @return
	 */
	private boolean checkWeightCodeIdEquality(final Long weightCodeId, final IDAIWeightageView daiWeightageNew) {
		return UtilHelper.checkEquality(weightCodeId != null ? weightCodeId : null,
				daiWeightageNew != null ? daiWeightageNew.getId(): null);
	}
	
	/**
	 * @param daiWeightId
	 * @param daiWeightNew
	 * @return
	 */
	private boolean checkWeightIdEquality(final Long daiWeightId, final IDAIConfigView daiWeightNew) {
		return UtilHelper.checkEquality(daiWeightId != null ? daiWeightId : null,
				daiWeightNew != null ? daiWeightNew.getDaiConfigId() : null);
	}
	
	/**
	 * @param id
	 * @param daiRegoleView
	 * @return
	 */
	private boolean checkDaiEquality(final Long id, final IDAIRegoleDetailsView daiRegoleView) {
		return UtilHelper.checkEquality(id != null ? id : null,
				daiRegoleView != null ? daiRegoleView.getId() : null);
	}
	
	/**
	 * @param id
	 * @param daiConfigView
	 * @return
	 */
	private boolean checkDaiEquality(final Long id, final IDAIConfigView daiConfigView) {
		return UtilHelper.checkEquality(id != null ? id : null,
				daiConfigView != null ? daiConfigView.getDaiConfigId() : null);
	}
}
