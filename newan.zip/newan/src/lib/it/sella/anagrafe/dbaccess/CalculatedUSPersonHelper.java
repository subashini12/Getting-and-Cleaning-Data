package it.sella.anagrafe.dbaccess;


import it.sella.anagrafe.GestoreDatiFiscaliException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

public class CalculatedUSPersonHelper extends DBAccessHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CalculatedUSPersonHelper.class);

    protected Boolean isUSorigin( final Long soggettoId ) throws GestoreDatiFiscaliException, RemoteException {
    	
        Connection connection = null;
        CallableStatement statement = null;
        try {
            connection =getConnection();
            statement = connection.prepareCall("{CALL ? := an_pkg_igestore_anagrafe.an_fn_calculatedusperson( ? )}");
            statement.registerOutParameter(1,Types.VARCHAR);
            statement.setLong(2,soggettoId.longValue());
            statement.execute() ;
            return Boolean.valueOf(statement.getString(1));
        } catch (final SQLException sqlEx) {
            log4Debug.severeStackTrace(sqlEx);
            throw new GestoreDatiFiscaliException(sqlEx.getMessage());
        } finally {
            cleanup(connection, statement);
        }
    }
}
