package it.sella.anagrafe.dbaccess;

import java.rmi.RemoteException;

import javax.ejb.FinderException;

import it.sella.anagrafe.CanalePreferitoDataView;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.OperazioneAnagrafeFactory;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.canalepreferito.CanalePreferito;
import it.sella.anagrafe.canalepreferito.CanalePreferitoView;
import it.sella.anagrafe.factory.CanalePreferitoFactory;
import it.sella.anagrafe.util.CanalePreferitoException;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

public class CanalePreferitoUpdateHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CanalePreferitoUpdateHelper.class);

	/**
	 * To Create CanalePreferito Data.
	 * @param canaleView
	 * @param opId
	 * @param soggettoId
	 * @throws CanalePreferitoException
	 */
	public void createCanalePreferito(final CanalePreferitoDataView canaleView, final Long opId, final Long soggettoId) throws CanalePreferitoException {
		try {
			if (canaleView != null && canaleView.getCanale() != null) {
				log4Debug.debug("=================== canaleView Not null =====================");
				final CanalePreferitoView view = new CanalePreferitoView();
				view.setCanaleId(canaleView.getCanale().getId());
				view.setCanaleValue(canaleView.getCanaleValue());
				view.setTipoRecapiti(canaleView.getTipoRecapiti() != null ? canaleView.getTipoRecapiti().getId() : null);
				view.setSoggettoId(soggettoId);
				view.setOpId(opId);
				view.setDataInizio(new DateHandler().getCurrentDateInTimeStampFormat());
				view.setUtenteInserimento(SecurityHandler.getLoginUserId());
				CanalePreferitoFactory.getInstance().getCanalePreferitoBeanManager().create(view);
			}
		} catch (final GestoreAnagrafeException e) {
			log4Debug.warnStackTrace(e);
			throw new CanalePreferitoException(e.getMessage());
		}
	}
	
	/**
	 * To Update /Insert canalePreferito in Varia Case.
	 * @param canaleNewView
	 * @param canaleOldView
	 * @param opId
	 * @param soggettoId
	 * @throws CanalePreferitoException
	 * @throws RemoteException 
	 */
	public void setCanalePreferito (final CanalePreferitoDataView canaleNewView, final Long opId, final Long soggettoId) throws CanalePreferitoException, RemoteException {
		try {
			final CanalePreferitoDataView canalePreferitoOldView = OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager().getValidCanalePreferitoForSoggettoId(soggettoId);
			
			if (canaleNewView != null) {
				if (canalePreferitoOldView != null && !canaleNewView.equals(canalePreferitoOldView)) {
					// update old
					final CanalePreferito findByPrimaryKey = CanalePreferitoFactory.getInstance().getCanalePreferitoBeanManager().findByPrimaryKey(canalePreferitoOldView.getCanalePreferitoId());
					findByPrimaryKey.setDataFine(new DateHandler().getCurrentDateInTimeStampFormat());
					findByPrimaryKey.setUtenteModificato(SecurityHandler.getLoginUserId());
					findByPrimaryKey.setOpId(opId);
					CanalePreferitoFactory.getInstance().getCanalePreferitoBeanManager().update(findByPrimaryKey);
					// Insert new
					createCanalePreferito(canaleNewView, opId, soggettoId);
				} else if (canalePreferitoOldView == null) {
					// Insert New
					createCanalePreferito(canaleNewView, opId, soggettoId);
				}
			} else if (canalePreferitoOldView != null) {
				// Update Old
				final CanalePreferito findByPrimaryKey = CanalePreferitoFactory.getInstance().getCanalePreferitoBeanManager().findByPrimaryKey(canalePreferitoOldView.getCanalePreferitoId());
				findByPrimaryKey.setDataFine(new DateHandler().getCurrentDateInTimeStampFormat());
				findByPrimaryKey.setUtenteModificato(SecurityHandler.getLoginUserId());
				findByPrimaryKey.setOpId(opId);
				CanalePreferitoFactory.getInstance().getCanalePreferitoBeanManager().update(findByPrimaryKey);
			}
		} catch (final FinderException e) {
			log4Debug.warnStackTrace(e);
			throw new CanalePreferitoException(e.getMessage());
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new CanalePreferitoException(e.getMessage());
		} 
	}
}
