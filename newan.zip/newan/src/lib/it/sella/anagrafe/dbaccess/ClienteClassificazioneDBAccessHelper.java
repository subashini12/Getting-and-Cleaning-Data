package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.view.ClienteClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;

public class ClienteClassificazioneDBAccessHelper extends DBAccessHelper {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(
			ClienteClassificazioneDBAccessHelper.class);
	
	 public void createClienteClassificazione( final ClienteClassificazioneView clientClassificazioneView ) throws GestoreAnagrafeException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			final StringBuilder query = new StringBuilder("INSERT INTO AN_TR_CLIENT_CLASSIFICAZIONE (CC_ID, ");
			 query.append("CC_SOGGETTO_ID,CC_CONSUMATORE,CC_CLIENTE_AL_DETTAGLIO,CC_DATA_INSERIMENTO,CC_OP_ID,CC_MICROIMPRESE) ");
			 query.append("VALUES(AN_CL_SQ_CC_ID.NEXTVAL,?,?,?,?,?,?)");

			connection = getConnection();
			preparedStatement = connection.prepareStatement(query.toString());
			preparedStatement.setLong(1, clientClassificazioneView.getSoggettoId());
			preparedStatement.setString(2, clientClassificazioneView.getConsumatore());
			preparedStatement.setString(3, clientClassificazioneView.getClienteAlDettaglio());
			preparedStatement.setTimestamp(4, clientClassificazioneView.getDataInserimento() != null ?
					clientClassificazioneView.getDataInserimento() : new DateHandler().getCurrentDateInTimeStampFormat());
			checkForNullAndSetLongValue(preparedStatement, clientClassificazioneView.getOpId(), 5);
			preparedStatement.setString(6, clientClassificazioneView.getMicroimpresa());
			
			log4Debug.debug("ClienteClassificazioneGetterHelper: getClienteClassificazioneBySoggetto: query:===>>",query);
			preparedStatement.executeUpdate();
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}
	}
	 
	
	public void updateClienteClassificazione( final ClienteClassificazioneView clientClassificazioneView ) 
	  throws GestoreAnagrafeException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			final StringBuilder query = new StringBuilder("UPDATE AN_TR_CLIENT_CLASSIFICAZIONE SET CC_CONSUMATORE = ?,");
			 query.append(" CC_CLIENTE_AL_DETTAGLIO = ?, CC_DATA_INSERIMENTO = ?, CC_OP_ID = ?,CC_MICROIMPRESE=?");
			 query.append(" WHERE CC_SOGGETTO_ID = ?");

			connection = getConnection();
			preparedStatement = connection.prepareStatement(query.toString());
			preparedStatement.setString(1, clientClassificazioneView.getConsumatore());
			preparedStatement.setString(2, clientClassificazioneView.getClienteAlDettaglio());
			preparedStatement.setTimestamp(3, clientClassificazioneView.getDataInserimento());
			checkForNullAndSetLongValue(preparedStatement, clientClassificazioneView.getOpId(), 4);
			preparedStatement.setString(5, clientClassificazioneView.getMicroimpresa());
			checkForNullAndSetLongValue(preparedStatement, clientClassificazioneView.getSoggettoId(), 6);
			log4Debug.debug("ClienteClassificazioneGetterHelper: getClienteClassificazioneBySoggetto: query:===>>",query);
			preparedStatement.executeUpdate();
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}
	}
	
	public void deleteClienteClassificazione( final ClienteClassificazioneView clientClassificazioneView ) throws GestoreAnagrafeException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			new StoricClienteClassificazioneUpdateHelper().updateClienteClassificazione(
					clientClassificazioneView.getId(), 
			   clientClassificazioneView.getSoggettoId(), clientClassificazioneView.getOpId());
			final StringBuilder query = new StringBuilder("DELETE AN_TR_CLIENT_CLASSIFICAZIONE WHERE CC_SOGGETTO_ID = ?");
			connection = getConnection();
			preparedStatement = connection.prepareStatement(query.toString());
			preparedStatement.setLong(1, clientClassificazioneView.getSoggettoId());
			log4Debug.debug("ClienteClassificazioneGetterHelper: getClienteClassificazioneBySoggetto: query:===>>",query);
			preparedStatement.executeUpdate();
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} catch (final ControlloDatiException se) {
			log4Debug.warnStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}
	}
	
	public void setClienteClassificazione(
			final ClienteClassificazioneView clientClassificazioneView)
			throws GestoreAnagrafeException {
		final ClienteClassificazioneView clientClassificazioneOldView = new ClienteClassificazioneGetterHelper()
				.getClienteClassificazioneBySoggetto(clientClassificazioneView.getSoggettoId());
		if (clientClassificazioneOldView == null) {
			createClienteClassificazione(clientClassificazioneView);
		} else if (!clientClassificazioneView.equals(clientClassificazioneOldView)) {
			log4Debug.info("call For update ", clientClassificazioneView != null ? clientClassificazioneView.getMicroimpresa():" Empty ");
			updateClienteClassificazione(clientClassificazioneView);
		}
	}

	public void setClienteClassificazione(final Long soggettoId,
			final Long numeroDependenti, final BigDecimal fatturato,
			final BigDecimal bilancio) throws RemoteException,
			GestoreAnagrafeException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		String status = null;
		try {
			connection = getConnection();
			callableStatement = connection
					.prepareCall("{CALL AN_PKG_ANAGRAFE_UPDATE.AN_PR_SET_CLASS_CLIENTE(?,?,?,?,?,?)}");
			checkForNullAndSetLongValue(callableStatement, soggettoId, 1);
			checkForNullAndSetLongValue(callableStatement, numeroDependenti, 2);
			checkForNullAndSetBigDecimalValue(callableStatement, fatturato, 3);
			checkForNullAndSetBigDecimalValue(callableStatement, bilancio, 4);
			callableStatement.registerOutParameter(5, Types.VARCHAR);
			callableStatement.registerOutParameter(6, Types.VARCHAR);
			callableStatement.execute();
			status = callableStatement.getString(5);
			if ("KO".equals(status)) {
				throw new GestoreAnagrafeException(callableStatement.getString(6));
			}

		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} finally {
			cleanup(connection, callableStatement);
		}
	}
}
