package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreCollegamentoException;
import it.sella.anagrafe.GestoreSoggettoException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.discriminator.CollegamentoException;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.anagrafe.util.StringHandler;
import it.sella.security.SecurityManagerFactory;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

public class CollegamentoPrincipaleGetterHelper extends DBAccessHelper {
	
    private static final String MOTIV = "MOTIV";
    private final String CENST ="CENST";
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CollegamentoPrincipaleGetterHelper.class);

    public Collection getSoggettoPrincipale( final Long soggettoId ) throws GestoreCollegamentoException, RemoteException {
        ArrayList soggettoPrincipale = null;
        try {
            if (soggettoId != null) {
                final Collection coll = getSoggettiColleganti(soggettoId);
                final Iterator collegamentoIterator = coll.iterator();
                for (int i = 0; i < coll.size(); i++) {
                    if (soggettoPrincipale == null) {
						soggettoPrincipale = new ArrayList();
					}
                    soggettoPrincipale.add(((it.sella.anagrafe.CollegamentoView) collegamentoIterator.next()).getSoggettoPrincipaleId());
                }
            }
        } catch (final CollegamentoException cnfe) {
            log4Debug.warnStackTrace(cnfe);
            throw new GestoreCollegamentoException(cnfe.getMessage());
        }
        return soggettoPrincipale;
    }
    
    public Collection getSoggettoPrincipale( final Long soggettoId, final String tipoCollegamento ) throws GestoreCollegamentoException, RemoteException {
        ArrayList soggettoPrincipale = null;
        try {
            if (soggettoId != null) {
                final Collection coll = getSoggettoCollegante(soggettoId, tipoCollegamento);
                final Iterator collegamentoIterator = coll.iterator();
                for (int i = 0; i < coll.size(); i++) {
                    if (soggettoPrincipale == null) {
						soggettoPrincipale = new ArrayList(1);
					}
                    soggettoPrincipale.add(((it.sella.anagrafe.CollegamentoView) collegamentoIterator.next()).getSoggettoPrincipaleId());
                }
            }
        } catch (final CollegamentoException cnfe) {
        	log4Debug.warnStackTrace(cnfe);
            throw new GestoreCollegamentoException(cnfe.getMessage());
        }
        return soggettoPrincipale;
    }
    
    // This method only used for Art136 Batch .. This method not having login bank check
    
    public List getSoggettoPrincipaleWithSpecifiBank( final Long soggettoId, final String tipoCollegamento, final Long bankSoggettoId ) throws GestoreCollegamentoException, RemoteException {
        ArrayList soggettoPrincipale = null;
        try {
            if ( soggettoId != null ) {
                final Collection coll = getSoggettoColleganteWithSpecifiBank(soggettoId, tipoCollegamento, bankSoggettoId );
                final Iterator collegamentoIterator = coll.iterator();
                for ( int i = 0; i < coll.size(); i++ ) {
                    if ( soggettoPrincipale == null ) {
                    	soggettoPrincipale = new ArrayList(1);
                    }
                    soggettoPrincipale.add(((it.sella.anagrafe.CollegamentoView) collegamentoIterator.next()).getSoggettoPrincipaleId());
                }
            }
        } catch (final CollegamentoException cnfe) {
        	log4Debug.warnStackTrace(cnfe);
            throw new GestoreCollegamentoException(cnfe.getMessage());
        }
        return soggettoPrincipale;
    }

    
    
    public Collection getAziendaPrincipalSoggetto( final Long soggettoId ) throws GestoreCollegamentoException, RemoteException {
        final ArrayList principaleSoggettoList = new ArrayList(1);
        try {
            if (soggettoId != null) {
                final Collection soggettoIds = getSoggettiColleganti(soggettoId);
                if (soggettoIds != null) {
                    final int size = soggettoIds.size();
                    final Iterator iterator = soggettoIds.iterator();
                    it.sella.anagrafe.CollegamentoView collegamentoView = null;
                    for (int i = 0; i < size; i++) {
                        collegamentoView = (it.sella.anagrafe.CollegamentoView) iterator.next();
                        if (!"DIPCT".equals(collegamentoView.getMotivoCausale()) && !"PROCT".equals(collegamentoView.getMotivoCausale()) &&
                                !"SVICT".equals(collegamentoView.getMotivoCausale()) && !"ORGCL".equals(collegamentoView.getMotivoCausale()) && ("AZIENDE".equals(new TipoSoggettoHandler().getParentTipoSoggetto(collegamentoView.getSoggettoPrincipaleId())))) {
                                principaleSoggettoList.add(collegamentoView);
                            }
                        }
                    }
                }
        } catch (final CollegamentoException cnfe) {
        	log4Debug.warnStackTrace(cnfe);
            throw new GestoreCollegamentoException(cnfe.getMessage());
        } catch (final GestoreSoggettoException ge) {
        	log4Debug.warnStackTrace(ge);
            throw new GestoreCollegamentoException(ge.getMessage());
        } 
        return principaleSoggettoList;
    }
    
    public Collection getSoggettoPrincipaleViews( final Long soggettoId ) throws GestoreCollegamentoException, RemoteException {
        Collection collegamentoViews = null;
        try {
            collegamentoViews = soggettoId != null ? 
            		getSoggettiColleganti(soggettoId) : null;
        } catch (final CollegamentoException cnfe) {
        	log4Debug.warnStackTrace(cnfe);
            throw new GestoreCollegamentoException(cnfe.getMessage());
        }
        return collegamentoViews;
    }
    
    public Collection getSoggettiColleganti( final Long linkedSoggettoId ) throws CollegamentoException, RemoteException {
        final List collegamentoViewList = new ArrayList(1);
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet collegamentoResultSet = null;
        try {
            connection = getConnection();
            final StringBuffer query = new StringBuffer("SELECT CL_ID, CL_SOGGETTO_PRINCIPALE, CL_MOTIVO, CL_NOTE, CL_DATA_INIZIO, CL_DATA_FINE, CL_LINKED_SOGGETTO FROM AN_TR_COLLAGAMENTO_SOGGETTO A WHERE CL_LINKED_SOGGETTO= ? AND CL_DATA_FINE IS NULL");
            query.append(" AND EXISTS (SELECT 1 FROM AN_TR_COLLAGAMENTO_SOGGETTO WHERE CL_SOGGETTO_PRINCIPALE = ? AND CL_MOTIVO = ? AND CL_LINKED_SOGGETTO = A.CL_LINKED_SOGGETTO AND CL_DATA_FINE IS NULL)");
            preparedStatement = connection.prepareStatement(query.toString());
            preparedStatement.setLong(1, linkedSoggettoId.longValue());
            preparedStatement.setLong(2, SecurityHandler.getLoginBancaId().longValue());
            preparedStatement.setLong(3, getClassificazioneIdFromCausale("CENST",MOTIV).longValue());
            collegamentoResultSet = preparedStatement.executeQuery();
	    logStackDumpForBankSoggettoIds(linkedSoggettoId);
            new CollegamentoViewBuilder().setCollegamentoViewListFromResultSet(collegamentoResultSet, collegamentoViewList);
        } catch (final GestoreAnagrafeException ce) {
        	log4Debug.warnStackTrace(ce);
            throw new CollegamentoException(ce.getLocalizedMessage());
        } catch (final SQLException se) {
        	log4Debug.warnStackTrace(se);
            throw new CollegamentoException(se.getLocalizedMessage());
        } finally {
            cleanup(connection, preparedStatement, collegamentoResultSet);
        }
        return collegamentoViewList;
    }
    
    public Collection getSoggettoCollegante( final Long linkedSoggettoId, final String motivoCollegamento ) throws CollegamentoException, RemoteException {
        final List collegamentoViewList = new ArrayList(1);
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet collegamentoResultSet = null;
        try {
            connection = getConnection();
            final StringBuffer query = new StringBuffer("SELECT CL_ID, CL_SOGGETTO_PRINCIPALE, CL_MOTIVO, CL_NOTE, CL_DATA_INIZIO, CL_DATA_FINE, CL_LINKED_SOGGETTO FROM AN_TR_COLLAGAMENTO_SOGGETTO A WHERE CL_LINKED_SOGGETTO= ? AND CL_MOTIVO=? AND CL_DATA_FINE IS NULL");
            query.append(" AND EXISTS (SELECT 1 FROM AN_TR_COLLAGAMENTO_SOGGETTO WHERE CL_SOGGETTO_PRINCIPALE = ? AND CL_MOTIVO = ? AND CL_LINKED_SOGGETTO = A.CL_LINKED_SOGGETTO AND CL_DATA_FINE IS NULL)");
            preparedStatement = connection.prepareStatement(query.toString());
            preparedStatement.setLong(1, linkedSoggettoId.longValue());
            preparedStatement.setLong(2, getClassificazioneIdFromCausale(motivoCollegamento, MOTIV).longValue());
            preparedStatement.setLong(3, SecurityHandler.getLoginBancaId().longValue());
            preparedStatement.setLong(4, getClassificazioneIdFromCausale("CENST",MOTIV).longValue());
            collegamentoResultSet = preparedStatement.executeQuery();
	    logStackDumpForBankSoggettoIds(linkedSoggettoId);
            new CollegamentoViewBuilder().setCollegamentoViewListFromResultSet(collegamentoResultSet, collegamentoViewList);
        }  catch (final SQLException se) {
        	log4Debug.warnStackTrace(se);
            throw new CollegamentoException(se.getLocalizedMessage());
        }  catch(final GestoreAnagrafeException e) {
        	log4Debug.warnStackTrace(e);
            throw new CollegamentoException(e.getLocalizedMessage());
        } finally {
            cleanup(connection, preparedStatement, collegamentoResultSet);
        }
        return collegamentoViewList;
    }
    
    private Collection getSoggettoColleganteWithSpecifiBank( final Long linkedSoggettoId, final String motivoCollegamento, final Long bankSoggettoId ) throws CollegamentoException, RemoteException {
        final List collegamentoViewList = new ArrayList(1);
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet collegamentoResultSet = null;
        try {
            connection = getConnection();
            final StringBuffer query = new StringBuffer("SELECT CL_ID, CL_SOGGETTO_PRINCIPALE, CL_MOTIVO, CL_NOTE, CL_DATA_INIZIO, CL_DATA_FINE, CL_LINKED_SOGGETTO FROM AN_TR_COLLAGAMENTO_SOGGETTO A WHERE CL_LINKED_SOGGETTO= ? AND CL_MOTIVO=? AND CL_DATA_FINE IS NULL");
            query.append(" AND EXISTS (SELECT 1 FROM AN_TR_COLLAGAMENTO_SOGGETTO WHERE CL_SOGGETTO_PRINCIPALE = ? AND CL_MOTIVO = ? AND CL_LINKED_SOGGETTO = A.CL_LINKED_SOGGETTO AND CL_DATA_FINE IS NULL)");
            preparedStatement = connection.prepareStatement(query.toString());
            preparedStatement.setLong(1, linkedSoggettoId.longValue());
            preparedStatement.setLong(2, getClassificazioneIdFromCausale(motivoCollegamento, MOTIV).longValue());
            preparedStatement.setLong(3, bankSoggettoId.longValue());
            preparedStatement.setLong(4, getClassificazioneIdFromCausale("CENST",MOTIV).longValue());
            collegamentoResultSet = preparedStatement.executeQuery();
	    logStackDumpForBankSoggettoIds(linkedSoggettoId);
            new CollegamentoViewBuilder().setCollegamentoViewListFromResultSet(collegamentoResultSet, collegamentoViewList);
        }  catch (final SQLException se) {
        	log4Debug.warnStackTrace(se);
            throw new CollegamentoException(se.getLocalizedMessage());
        }  catch(final GestoreAnagrafeException e) {
        	log4Debug.warnStackTrace(e);
            throw new CollegamentoException(e.getLocalizedMessage());
        } finally {
            cleanup(connection, preparedStatement, collegamentoResultSet);
        }
        return collegamentoViewList;
    }
   
    private static final Long BS = 1L;
    private static final Long BBC = 238L;
    private static final Long BAG = 57992L;
    private static final Long BDP = 57994L;
    private static final Long SIB = 1367924L;
    private static final Long SHB = 1483455L;
    private static final Long CLS = 1928634L;
    private static final Long SCS = 1994713L;
    
    private static final ArrayList<Long> bankIdArr = constructBankIdList();

    private static final ArrayList<Long> constructBankIdList() {
        final ArrayList<Long> list = new ArrayList<Long>();
        list.add(BS);
        list.add(BBC);
        list.add(BAG);
        list.add(BDP);
        list.add(SIB);
        list.add(SHB);
        list.add(CLS);
        list.add(SCS);
        return list;
    }
    
    private void logStackDumpForBankSoggettoIds(final Long linkedSoggettoId) {
        try {
            if ( bankIdArr.contains(linkedSoggettoId) ) {
                throw new Exception();
            }
        } catch ( final Exception ex ) {
		    log4Debug.severe("#####<ANAGSTACKDUMP>#####  " , "Input Soggetto Id : " , linkedSoggettoId);
		    log4Debug.severe("#####<ANAGSTACKDUMP>#####  " , "Logged In User Id : " , getUserId());
	        log4Debug.severeStackTrace(ex);
        }
    }    

   private static String getUserId() {
	   try {
		   return SecurityManagerFactory.getSecurityManager().getIdentity().getUserId();
	   } catch (final it.sella.security.SecurityException ex) {
		   log4Debug.severe(ex.getMessage());
	       log4Debug.severe("#####<ANAGSTACKDUMP>#####  " , " Not Possible to Retrieve User Id " );
	   }
	   return null;
   }
   
	/**
	 * @param soggettoId
	 * @return
	 * @throws CollegamentoException 
	 * @throws RemoteException 
	 */
	public boolean isCollegateSubjectHasLinkedTutoreOrEserc(final Long soggettoId) throws CollegamentoException, RemoteException {
		boolean result = false;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer("SELECT 1 FROM AN_TR_COLLAGAMENTO_SOGGETTO CS WHERE CS.CL_MOTIVO IN (?, ?) AND CS.CL_SOGGETTO_PRINCIPALE = ? AND CS.CL_DATA_FINE IS NULL AND EXISTS (SELECT 1 FROM AN_TR_COLLAGAMENTO_SOGGETTO CS1 WHERE CS1.CL_LINKED_SOGGETTO = CS.CL_LINKED_SOGGETTO AND CS1.CL_MOTIVO = ? AND CS1.CL_SOGGETTO_PRINCIPALE = ? AND CS1.CL_DATA_FINE IS NULL AND ROWNUM = 1)");
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(query.toString());
			preparedStatement.setLong(1, getClassificazioneIdFromCausale("TUTOR", MOTIV).longValue());
			preparedStatement.setLong(2, getClassificazioneIdFromCausale("ESERC", MOTIV).longValue());
			preparedStatement.setLong(3, soggettoId);
			preparedStatement.setLong(4, getClassificazioneIdFromCausale("CENST", MOTIV).longValue());
			preparedStatement.setLong(5, SecurityHandler.getLoginBancaId().longValue());
			resultSet = preparedStatement.executeQuery();
			result = resultSet.next();
		} catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new CollegamentoException(e.getMessage());
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new CollegamentoException(e.getMessage());
		} finally {
            cleanup(connection, preparedStatement, resultSet);
        }
		log4Debug.debug("result =======isSubjectHasLinkedTutoreOrEserc=======   ",result);
		return result;
	}
	
	/**
	 * @param soggettoId
	 * @return
	 * @throws CollegamentoException
	 * @throws RemoteException
	 */
	public boolean isSubjectLinkedAsTutoreOrEsercOrCuratCollegate(final Long soggettoId) throws CollegamentoException, RemoteException {
		boolean result = false;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer("SELECT 1 FROM AN_TR_COLLAGAMENTO_SOGGETTO CS WHERE CS.CL_MOTIVO IN (?, ?, ?) AND CS.CL_LINKED_SOGGETTO = ? AND CS.CL_DATA_FINE IS NULL AND EXISTS (SELECT 1 FROM AN_TR_COLLAGAMENTO_SOGGETTO CS1 WHERE CS1.CL_LINKED_SOGGETTO = CS.CL_SOGGETTO_PRINCIPALE AND CS1.CL_MOTIVO = ? AND CS1.CL_SOGGETTO_PRINCIPALE = ? AND CS1.CL_DATA_FINE IS NULL AND ROWNUM = 1)");
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(query.toString());
			preparedStatement.setLong(1, getClassificazioneIdFromCausale("TUTOR", MOTIV).longValue());
			preparedStatement.setLong(2, getClassificazioneIdFromCausale("ESERC", MOTIV).longValue());
			preparedStatement.setLong(3, getClassificazioneIdFromCausale("CURAT", MOTIV).longValue());
			preparedStatement.setLong(4, soggettoId);
			preparedStatement.setLong(5, getClassificazioneIdFromCausale("CENST", MOTIV).longValue());
			preparedStatement.setLong(6, SecurityHandler.getLoginBancaId().longValue());
			resultSet = preparedStatement.executeQuery();
			result = resultSet.next();
		} catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new CollegamentoException(e.getMessage());
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new CollegamentoException(e.getMessage());
		} finally {
            cleanup(connection, preparedStatement, resultSet);
        }
		log4Debug.debug("result =======isSubjectLinkedAsTutoreOrEserc=======   ",result);
		return result;
	}
	
	/**
	 * @param prinSoggettoId
	 * @param linkedSoggettoId
	 * @param motivoCollegamento
	 * @return
	 * @throws CollegamentoException
	 * @throws RemoteException
	 */
	public Long getCollegamentoId(final Long prinSoggettoId, final Long linkedSoggettoId, final String motivoCollegamento) throws CollegamentoException, RemoteException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		final String query = "SELECT CL_ID FROM AN_TR_COLLAGAMENTO_SOGGETTO A WHERE A.CL_SOGGETTO_PRINCIPALE = ? AND A.CL_DATA_FINE IS NULL AND A.CL_MOTIVO = ? AND A.CL_LINKED_SOGGETTO = ?";
		Long collegamentoId = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setLong(1, prinSoggettoId);
			preparedStatement.setLong(2, getClassificazioneIdFromCausale(motivoCollegamento, MOTIV).longValue());
			preparedStatement.setLong(3, linkedSoggettoId);
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				collegamentoId = resultSet.getLong("CL_ID");
			}
		} catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new CollegamentoException(e.getMessage());
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new CollegamentoException(e.getMessage());
		} finally {
            cleanup(connection, preparedStatement, resultSet);
        }
		return collegamentoId;
	}
	
	/**
	 * @param soggettoIds
	 * @param codiceFiscali
	 * @throws CollegamentoException
	 * @throws RemoteException 
	 */
	public void updateCodiceFiscaliForSoggetto(final Long [] soggettoIds, final String codiceFiscali, final Long opId) throws CollegamentoException, RemoteException {
		log4Debug.debug("updateCodiceFiscaliForSoggetto		==================   ",codiceFiscali);
		Connection connection = null;
		CallableStatement callableStatement = null;
		try {
			connection = getConnection();
			final ArrayDescriptor descriptor = ArrayDescriptor.createDescriptor("AN_SOGGETTOID_ARRAY", connection);
			final ARRAY soggettoIdArray = new ARRAY(descriptor,connection, soggettoIds);
			callableStatement = connection.prepareCall("{CALL AN_PR_SET_TIT_DF_FOR_DI(?,?,?,?)}");
			callableStatement.setArray(1, soggettoIdArray);
			callableStatement.setLong(2, getClassificazioneIdFromCausale("codiceFiscali", "DFDPF").longValue());
			callableStatement.setString(3, StringHandler.getUpperCase(codiceFiscali));
			callableStatement.setLong(4, opId);
			callableStatement.execute();
		} catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new CollegamentoException(e.getMessage());
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new CollegamentoException(e.getMessage());
		} finally {
            cleanup(connection, callableStatement);
        }
	}
	
	 public Collection<it.sella.anagrafe.CollegamentoView> getSoggettiPrincipaleForSpecificBank( final Long linkedSoggettoId ) throws CollegamentoException, RemoteException {
	        final List<it.sella.anagrafe.CollegamentoView> collegamentoViewList = new ArrayList<it.sella.anagrafe.CollegamentoView>(1);
	        Connection connection = null;
	        PreparedStatement preparedStatement = null;
	        ResultSet collegamentoResultSet = null;
	        Long bankId = null;
	        try {
	            connection = getConnection();
	            final StringBuffer query = new StringBuffer("SELECT CL_ID, CL_SOGGETTO_PRINCIPALE, CL_MOTIVO, CL_NOTE, CL_DATA_INIZIO, CL_DATA_FINE, CL_LINKED_SOGGETTO FROM AN_TR_COLLAGAMENTO_SOGGETTO A WHERE CL_LINKED_SOGGETTO= ? AND CL_DATA_FINE IS NULL AND CL_SOGGETTO_PRINCIPALE = ? ");
	            query.append(" AND EXISTS (SELECT 1 FROM AN_TR_COLLAGAMENTO_SOGGETTO WHERE CL_SOGGETTO_PRINCIPALE = ? AND CL_MOTIVO = ? AND CL_LINKED_SOGGETTO = A.CL_LINKED_SOGGETTO AND CL_DATA_FINE IS NULL)");
	            preparedStatement = connection.prepareStatement(query.toString());
	            bankId = SecurityHandler.getLoginBancaId().longValue();
	            preparedStatement.setLong(1, linkedSoggettoId.longValue());
	            preparedStatement.setLong(2, bankId);
	            preparedStatement.setLong(3, bankId);
	            preparedStatement.setLong(4, getClassificazioneIdFromCausale(CENST,MOTIV).longValue());
	            collegamentoResultSet = preparedStatement.executeQuery();
		    logStackDumpForBankSoggettoIds(linkedSoggettoId);
	            new CollegamentoViewBuilder().setCollegamentoViewListFromResultSet(collegamentoResultSet, collegamentoViewList);
	        } catch (final GestoreAnagrafeException ce) {
	        	log4Debug.warnStackTrace(ce);
	            throw new CollegamentoException(ce.getLocalizedMessage());
	        } catch (final SQLException se) {
	        	log4Debug.warnStackTrace(se);
	            throw new CollegamentoException(se.getLocalizedMessage());
	        } finally {
	            cleanup(connection, preparedStatement, collegamentoResultSet);
	        }
	        return collegamentoViewList;
	    }
}

