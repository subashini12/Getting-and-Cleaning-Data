package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.InformazioneManagerException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.implementation.CompatibleSettoreView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

public class CompatibleSettoreHandler extends DBAccessHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CompatibleSettoreHandler.class);
	
	public Collection listCompatibleSettore(final Long tipoSoggettoId,final String codiceSoggettoGruppo) throws InformazioneManagerException, RemoteException {
		Connection compConection  = null;
		ResultSet compResultSet = null;
		PreparedStatement compPreparedStatement = null;
		final Collection compSettoreCol = new ArrayList();
		try {
        	compConection = getConnection();
        	compPreparedStatement = compConection.prepareStatement("SELECT CS_TIPOSOGGETTOID, CS_TIPOSOCIETA_ID , CS_CODICESOGGETTOGRUPPO, ROWNUM FROM AN_MA_COMPATIBLE_SETTORE SE WHERE SE.CS_TIPOSOGGETTOID = ? AND SE.CS_CODICESOGGETTOGRUPPO = ? ORDER BY ROWNUM DESC ");
        	checkForNullAndSetLongValue(compPreparedStatement,tipoSoggettoId,1);
        	compPreparedStatement.setString(2,codiceSoggettoGruppo);
        	compResultSet = compPreparedStatement.executeQuery();
        	buildComptibleSettoreView(compResultSet,compSettoreCol);
		} catch(final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new InformazioneManagerException(se.getMessage());
		} catch(final SubSystemHandlerException se) {
			log4Debug.warnStackTrace(se);
			throw new InformazioneManagerException(se.getMessage());
		} finally {
			cleanup(compConection, compPreparedStatement, compResultSet);
		}
		return compSettoreCol;
	}
	
	public Collection listCompatibleSettore(final Long tipoSoggettoId) throws InformazioneManagerException, RemoteException {
		Connection compConection  = null;
		ResultSet compResultSet = null;
		PreparedStatement compPreparedStatement = null;
		final Collection compSettoreCol = new ArrayList();
		try {
        	compConection = getConnection();
        	compPreparedStatement = compConection.prepareStatement("SELECT CS_TIPOSOGGETTOID, CS_TIPOSOCIETA_ID , CS_CODICESOGGETTOGRUPPO, ROWNUM FROM AN_MA_COMPATIBLE_SETTORE SE WHERE SE.CS_TIPOSOGGETTOID = ? ORDER BY ROWNUM DESC ");
        	checkForNullAndSetLongValue(compPreparedStatement,tipoSoggettoId,1);
        	compResultSet = compPreparedStatement.executeQuery();
        	buildComptibleSettoreView(compResultSet,compSettoreCol);
		} catch(final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new InformazioneManagerException(se.getMessage());
		} catch(final SubSystemHandlerException se) {
			log4Debug.warnStackTrace(se);
			throw new InformazioneManagerException(se.getMessage());
		} finally {
			cleanup(compConection, compPreparedStatement, compResultSet);
		}
		return compSettoreCol;
	}
	
	public Collection listCompatibleSettore(final String codiceSoggettoGruppo) throws InformazioneManagerException, RemoteException {
		Connection compConection  = null;
		ResultSet compResultSet = null;
		PreparedStatement compPreparedStatement = null;
		final Collection compSettoreCol = new ArrayList();
		try {
        	compConection = getConnection();
        	compPreparedStatement = compConection.prepareStatement("SELECT CS_TIPOSOGGETTOID, CS_TIPOSOCIETA_ID , CS_CODICESOGGETTOGRUPPO, ROWNUM FROM AN_MA_COMPATIBLE_SETTORE SE WHERE SE.CS_CODICESOGGETTOGRUPPO = ? ORDER BY ROWNUM DESC ");
        	compPreparedStatement.setString(1,codiceSoggettoGruppo);
        	compResultSet = compPreparedStatement.executeQuery();
        	buildComptibleSettoreView(compResultSet,compSettoreCol);
		} catch(final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new InformazioneManagerException(se.getMessage());
		}  catch(final SubSystemHandlerException se) {
			log4Debug.warnStackTrace(se);
			throw new InformazioneManagerException(se.getMessage());
		} finally {
			cleanup(compConection, compPreparedStatement, compResultSet);
		}
		return compSettoreCol;
	}
	
	public void delteCompatibleSettore(final CompatibleSettoreView compatibleSettoreView) throws InformazioneManagerException {
		Connection compConection  = null;
		PreparedStatement compPreparedStatement = null;
		final StringBuffer query = new StringBuffer("DELETE FROM AN_MA_COMPATIBLE_SETTORE CS WHERE CS.CS_TIPOSOGGETTOID = ?  AND CS.CS_CODICESOGGETTOGRUPPO = ? ");
		int index = 0;
		try {
			if(compatibleSettoreView.getTipoSocieta() != null && compatibleSettoreView.getTipoSocieta().getId() != null ) {
				query.append("AND CS.CS_TIPOSOCIETA_ID = ? ");
			} else {
				query.append("AND CS.CS_TIPOSOCIETA_ID IS NULL ");
			}
        	compConection = getConnection();
        	compPreparedStatement = compConection.prepareStatement(query.toString());
        	checkForNullAndSetLongValue(compPreparedStatement,compatibleSettoreView.getTipoSoggettoId(),++index);
        	compPreparedStatement.setString(++index,compatibleSettoreView.getCodiceSoggettoGruppo());
        	if(compatibleSettoreView.getTipoSocieta() != null && compatibleSettoreView.getTipoSocieta().getId() != null ) {
        		checkForNullAndSetLongValue(compPreparedStatement,compatibleSettoreView.getTipoSocieta().getId(),++index);
        	}
        	compPreparedStatement.executeUpdate();
        } catch(final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new InformazioneManagerException(se.getMessage());
		}  finally {
			cleanup(compConection, compPreparedStatement);
		}
	}
	
	public void addCompatibleSettore(final CompatibleSettoreView compatibleSettoreView) throws InformazioneManagerException {
		Connection compConection  = null;
		PreparedStatement compPreparedStatement = null;
		int index = 0;
		try {
			compConection = getConnection();
			compPreparedStatement = compConection.prepareStatement("INSERT INTO AN_MA_COMPATIBLE_SETTORE (CS_TIPOSOGGETTOID,CS_TIPOSOCIETA_ID,CS_CODICESOGGETTOGRUPPO) VALUES ( ?, ?, ?)");
			checkForNullAndSetLongValue(compPreparedStatement,compatibleSettoreView.getTipoSoggettoId(),++index);
			checkForNullAndSetLongValue(compPreparedStatement,compatibleSettoreView.getTipoSocieta() != null ?
					compatibleSettoreView.getTipoSocieta().getId() : null ,++index);
			compPreparedStatement.setString(++index,compatibleSettoreView.getCodiceSoggettoGruppo());
			compPreparedStatement.executeUpdate();
		} catch(final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new InformazioneManagerException(se.getMessage());
		}   finally {
			cleanup(compConection, compPreparedStatement);
		}
	}
	
	
	private void buildComptibleSettoreView(final ResultSet compResultSet,final Collection compSettoreCol) throws SQLException, RemoteException, SubSystemHandlerException ,InformazioneManagerException {
		if(compResultSet.next()) {
			if(compResultSet.getLong("ROWNUM") > 21 ) {
				final String errorMessage = "Needed Specific Search!!!";
				throw new InformazioneManagerException(errorMessage);
			}
			setResultSetDataInView(compResultSet,compSettoreCol);
		}
		while (compResultSet.next()) {
			setResultSetDataInView(compResultSet,compSettoreCol);
		}
	}
	
	private void setResultSetDataInView(final ResultSet compResultSet,final Collection compSettoreCol) throws SQLException, RemoteException, SubSystemHandlerException {
		final CompatibleSettoreView compatibleSettoreView = new CompatibleSettoreView();
    	compatibleSettoreView.setTipoSoggettoId(Long.valueOf(compResultSet.getLong("CS_TIPOSOGGETTOID")));
    	compatibleSettoreView.setTipoSocieta( compResultSet.getLong("CS_TIPOSOCIETA_ID") == 0 ? null :
    			ClassificazioneHandler.getClassificazioneView(Long.valueOf(compResultSet.getLong("CS_TIPOSOCIETA_ID"))));
    	compatibleSettoreView.setCodiceSoggettoGruppo(compResultSet.getString("CS_CODICESOGGETTOGRUPPO"));
    	compSettoreCol.add(compatibleSettoreView);
	}
}
