package it.sella.anagrafe.dbaccess;


import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.anagrafe.GestoreSoggettoException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.AnagrafeLoggerHelper;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.logserver.LoggerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CSCifratiGetterHelper extends DBAccessHelper {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CSCifratiGetterHelper.class);

	public String getCodiceHostCifrati( final Long soggettoId ) throws GestoreCodiciSoggettoException, RemoteException {
		return getCodiceHostCifrati( soggettoId, null );
    }
	
	public String getCodiceHostCifratiWithSpecificBank( final Long soggettoId, final Long bankSoggettoId ) throws GestoreCodiciSoggettoException, RemoteException {
		return getCodiceHostCifrati( soggettoId, bankSoggettoId );
	}

    public Long getSoggettoIdCodiciCifrati( final String valoreCodiciCifrati ) throws GestoreCodiciSoggettoException, RemoteException {
 	   Long soggettoId = null;
	   if( valoreCodiciCifrati == null || valoreCodiciCifrati.trim().length() == 0 ) {
		final String errorMessage = "ValoreCodiciCifrati shoult not be NULL";
		throw new GestoreCodiciSoggettoException(errorMessage);
	   }
	   Connection connection = null;
	   PreparedStatement preparedStatement = null;
	   ResultSet resultSet = null;
	   
	   final StringBuffer queryBuffer  = new StringBuffer("SELECT CS_SOGGETTO_ID FROM AN_TR_CODICISOGGETTO_CIFRATI ");
	   queryBuffer.append("WHERE CS_VALUE LIKE '%'||LPAD(?,9,0)||'%' AND CS_RIGHT_PK = ? ");
	   queryBuffer.append("AND EXISTS ( SELECT 1 FROM AN_TR_COLLAGAMENTO_SOGGETTO WHERE CL_SOGGETTO_PRINCIPALE+0 = ? ");
	   queryBuffer.append("AND CL_MOTIVO = ? AND CL_DATA_FINE IS NULL AND CL_LINKED_SOGGETTO = CS_SOGGETTO_ID )");
	   try {
		   connection = getConnection();
		   preparedStatement = connection.prepareStatement(queryBuffer.toString());
		   preparedStatement.setString(1, valoreCodiciCifrati.trim());
		   preparedStatement.setLong(2, getClassificazioneIdFromCausale("codiceHost", "CSDPF").longValue());
		   preparedStatement.setLong(3, SecurityHandler.getLoginBancaId().longValue());
		   preparedStatement.setLong(4, getClassificazioneIdFromCausale("CENST", "MOTIV").longValue());
		   resultSet = preparedStatement.executeQuery();
		   if( resultSet.next() ) {
			   soggettoId = Long.valueOf(resultSet.getLong("CS_SOGGETTO_ID"));
		   }
		} catch (final SQLException e) {
		   log4Debug.warnStackTrace(e);
           throw new GestoreCodiciSoggettoException(e.getMessage());
	    } catch (final SubSystemHandlerException e) {
		   log4Debug.warnStackTrace(e);
	       throw new GestoreCodiciSoggettoException(e.getMessage());
		} finally {
            cleanup(connection, preparedStatement, resultSet);
        }
	    return soggettoId;
    }

    public void setOttoCifreCifrati( final Long soggettoId, final String valoreCifrati ) throws GestoreCodiciSoggettoException, RemoteException {
    	Connection connection = null;
        PreparedStatement preparedStatement = null;
        String strValoreCifrati = null;
        String existValoreCifrati = null;
        try {
			if( soggettoId == null || new TipoSoggettoHandler().getTipoSoggetto(soggettoId) == null ) {
				throw new GestoreCodiciSoggettoException(new AnagrafeHelper().getMessage("ANAG-1288"));
			}
			strValoreCifrati = valoreCifrati == null ? null : valoreCifrati.trim();
        	if ( strValoreCifrati == null || strValoreCifrati.length() != 9 || !strValoreCifrati.startsWith("0") ) {
        		throw new GestoreCodiciSoggettoException(new AnagrafeHelper().getMessage("ANAG-1475"));
        	}
        	existValoreCifrati = getCodiceHostCifrati(soggettoId);
        	if ( existValoreCifrati != null ) {
				if( existValoreCifrati.equals(strValoreCifrati) ) {
					throw new GestoreCodiciSoggettoException(new AnagrafeHelper().getMessage("ANAG-1476"));
				}
				connection = getConnection();
        		existValoreCifrati = existValoreCifrati.endsWith(";") ? 
        							 (existValoreCifrati + strValoreCifrati) : 
        							 (existValoreCifrati + ";" + strValoreCifrati);
        		preparedStatement = connection.prepareStatement("UPDATE AN_TR_CODICISOGGETTO_CIFRATI SET CS_VALUE = ?, CS_OP_ID = ? WHERE CS_SOGGETTO_ID = ?");
        		preparedStatement.setString(1,existValoreCifrati);
        		preparedStatement.setLong(2,getOpId(soggettoId,"ANAG-API-CSCF").longValue());
        		preparedStatement.setLong(3,soggettoId.longValue());
			} else {
				connection = getConnection();
				preparedStatement = connection.prepareStatement("INSERT INTO AN_TR_CODICISOGGETTO_CIFRATI(CS_CODICIFISCALI_ID,CS_SOGGETTO_ID,CS_VALUE,CS_RIGHT_PK,CS_OP_ID) VALUES (AN_SQ_CODICISOGGETTO_CIFRATI.NEXTVAL, ?, ?, ?, ?)");
        		preparedStatement.setLong(1,soggettoId.longValue());
        		preparedStatement.setString(2,valoreCifrati);
        		preparedStatement.setLong(3,getClassificazioneIdFromCausale("codiceHost", "CSDPF").longValue());
				preparedStatement.setLong(4,getOpId(soggettoId,"ANAG-API-CSCF").longValue());
			}
			preparedStatement.executeUpdate();
        } catch(final GestoreCodiciSoggettoException e) {
        	  log4Debug.warnStackTrace(e);
              throw new GestoreCodiciSoggettoException(e.getMessage());
   	    } catch (final SQLException e) {
   	    	  log4Debug.warnStackTrace(e);
   	    	  if ( e.getMessage().indexOf("ORA-00001") != -1 ) {
                 throw new GestoreCodiciSoggettoException(new AnagrafeHelper().getMessage("ANAG-1476"));
   	    	  } else { 
   	    		 throw new GestoreCodiciSoggettoException(e.getMessage());
   	    	  }	 
	    }  catch (final SubSystemHandlerException e) {
	    	  log4Debug.warnStackTrace(e);
	          throw new GestoreCodiciSoggettoException(e.getMessage());
		}  catch (final GestoreSoggettoException e) {
	    	  log4Debug.warnStackTrace(e);
	          throw new GestoreCodiciSoggettoException(e.getMessage());
		} finally {
        	cleanup(connection, preparedStatement);
        }
    }
    
    private String getCodiceHostCifrati( final Long soggettoId, final Long bankSoggettoId ) throws GestoreCodiciSoggettoException, RemoteException {
        if ( soggettoId == null ) {
        	throw new GestoreCodiciSoggettoException(new AnagrafeHelper().getMessage("ANAG-1300"));
        }
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String codiceHostCifrati = null;
        final StringBuffer query = new StringBuffer("SELECT CS_VALUE FROM AN_TR_CODICISOGGETTO_CIFRATI WHERE CS_SOGGETTO_ID = ?");
        query.append(" AND CS_RIGHT_PK = ? AND EXISTS ( SELECT 1 FROM AN_TR_COLLAGAMENTO_SOGGETTO WHERE CL_SOGGETTO_PRINCIPALE = ? ");
        query.append(" AND CL_MOTIVO = ? AND CL_DATA_FINE IS NULL AND CL_LINKED_SOGGETTO = CS_SOGGETTO_ID )");
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement(query.toString());
            preparedStatement.setLong(1, soggettoId.longValue());
            preparedStatement.setLong(2, getClassificazioneIdFromCausale("codiceHost", "CSDPF").longValue());
            preparedStatement.setLong(3, bankSoggettoId == null ? SecurityHandler.getLoginBancaId().longValue() : bankSoggettoId.longValue() );
            preparedStatement.setLong(4, getClassificazioneIdFromCausale("CENST", "MOTIV").longValue());
            resultSet = preparedStatement.executeQuery();
            if ( resultSet.next() ) {
            	codiceHostCifrati = resultSet.getString("CS_VALUE");
            }
        } catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreCodiciSoggettoException(e.getMessage());
        } catch (final SubSystemHandlerException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreCodiciSoggettoException(e.getMessage());
        } finally {
            cleanup(connection, preparedStatement, resultSet);
        }
        return codiceHostCifrati;
    }
    
    private Long getOpId( final Long soggettoId, final String operationCode )throws RemoteException, GestoreCodiciSoggettoException {
    	try {
			return new AnagrafeLoggerHelper().logAnagrafeOperation(null,false,operationCode,soggettoId,null);
		} catch (final LoggerException e) {
		    log4Debug.warnStackTrace(e);
	        throw new GestoreCodiciSoggettoException(e.getMessage());
		}
    }
}
