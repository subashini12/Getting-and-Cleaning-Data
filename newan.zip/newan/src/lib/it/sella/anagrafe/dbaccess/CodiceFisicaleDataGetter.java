package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreDatiFiscaliException;
import it.sella.anagrafe.util.StringHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CodiceFisicaleDataGetter extends DBAccessHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CodiceFisicaleDataGetter.class);

	/*
	 * Method to get the CodiceFisicale data's such as sesso,dateofbirth,citta,provincia 
    */
	public String getDataFromCodiceFiscale(final String codiceFisicale) throws GestoreDatiFiscaliException, RemoteException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String codiciFiscaliValue = null;
		ResultSet datifiscaliResultSet = null;
		if (!new StringHandler().isEmpty(codiceFisicale)) {
			try {
				connection = getConnection();
				preparedStatement = connection.prepareStatement("SELECT AN_PKG_IGESTORE_ANAGRAFE.AN_FN_DATAFROMCODICEFISCALE(?) OUTPUT FROM DUAL");
				preparedStatement.setString(1,codiceFisicale );
				datifiscaliResultSet = preparedStatement.executeQuery();
				while(datifiscaliResultSet.next()) {
					codiciFiscaliValue = datifiscaliResultSet.getString("OUTPUT");
				}
			} catch (SQLException sqlExcp) {
				log4Debug.debug("<<GA>> Exception From Method getDataFromCodiceFiscale :: ",sqlExcp.getMessage());
				throw new GestoreDatiFiscaliException(sqlExcp.getMessage());
			} finally {
				cleanup(connection, preparedStatement,datifiscaliResultSet);
			}
		}
		log4Debug.debug("CodiceFiscale data's",codiciFiscaliValue);
		return codiciFiscaliValue;
	}

}
