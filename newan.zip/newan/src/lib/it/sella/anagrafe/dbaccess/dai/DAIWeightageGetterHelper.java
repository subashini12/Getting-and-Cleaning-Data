package it.sella.anagrafe.dbaccess.dai;

import it.sella.anagrafe.DAIConfigException;
import it.sella.anagrafe.DAIWeightageException;
import it.sella.anagrafe.DAIWeightageView;
import it.sella.anagrafe.IDAIWeightageView;
import it.sella.anagrafe.dbaccess.DBAccessHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author GBS03447
 *
 */
public class DAIWeightageGetterHelper extends DBAccessHelper {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DAIWeightageGetterHelper.class);
	
	/**
	 * @param id
	 * @return
	 * @throws DAIWeightageException 
	 */
	public IDAIWeightageView getWeightageViewForId(final Long id) throws DAIWeightageException {
		
		IDAIWeightageView weightageView = null;
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		query.append("SELECT DW_CODE_ID, DW_DAI_CODE, DW_DAI_CODE_DESCRIPTION, DW_DAI_CODE_PARENT_ID, DW_DAI_GR_TYPE_ID, DW_DAI_WEIGHT_ID, DW_VALID FROM AN_MA_DAI_WEIGT_CODE WHERE DW_CODE_ID = ?");
		
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setLong(1, id);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				weightageView = getWeightageView(resultSet);
			}
		} catch (final SQLException e) {
			log4Debug.severeStackTrace(e);
			throw new DAIWeightageException(e.getMessage(), e);
		} catch (final DAIConfigException e) {
			log4Debug.severeStackTrace(e);
			throw new DAIWeightageException(e.getMessage(), e);
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return weightageView;
	}
	
	/**
	 * @param weightCode
	 * @return
	 * @throws DAIWeightageException
	 */
	public IDAIWeightageView getWeightageViewForCode (final String weightCode) throws DAIWeightageException {
		IDAIWeightageView weightageView = null;
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		query.append("SELECT DW_CODE_ID, DW_DAI_CODE, DW_DAI_CODE_DESCRIPTION, DW_DAI_CODE_PARENT_ID, DW_DAI_GR_TYPE_ID, DW_DAI_WEIGHT_ID, DW_VALID FROM AN_MA_DAI_WEIGT_CODE WHERE DW_DAI_CODE = ?");
		
		try {
			connection = getConnection();
			
			statement = connection.prepareStatement(query.toString());
			statement.setString(1, weightCode);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				weightageView = getWeightageView(resultSet);
			}
			
		}catch (final SQLException e) {
			log4Debug.severeStackTrace(e);
			throw new DAIWeightageException(e.getMessage(), e);
		} catch (final DAIConfigException e) {
			log4Debug.severeStackTrace(e);
			throw new DAIWeightageException(e.getMessage(), e);
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return weightageView;
	}
	
	/**
	 * @param resultSet
	 * @return
	 * @throws SQLException
	 * @throws DAIConfigException
	 */
	private IDAIWeightageView getWeightageView(ResultSet resultSet) throws SQLException, DAIConfigException {
		final IDAIWeightageView weightageView = new DAIWeightageView();
		weightageView.setId(resultSet.getLong("DW_CODE_ID"));
		weightageView.setWeightCode(resultSet.getString("DW_DAI_CODE"));
		weightageView.setWeightCodeDescription(resultSet.getString("DW_DAI_CODE_DESCRIPTION"));
		weightageView.setDaiCode(resultSet.getString("DW_DAI_CODE_PARENT_ID") != null ? new DAIConfigGetterHelper().getDAIConfig(resultSet.getLong("DW_DAI_CODE_PARENT_ID")) : null);
		weightageView.setDaiGroupType(resultSet.getString("DW_DAI_GR_TYPE_ID") != null ? new DAIConfigGetterHelper().getDAIConfig(resultSet.getLong("DW_DAI_GR_TYPE_ID")) : null);
		weightageView.setDaiwieghtage(resultSet.getString("DW_DAI_WEIGHT_ID") != null ? new DAIConfigGetterHelper().getDAIConfig(resultSet.getLong("DW_DAI_WEIGHT_ID")) : null);
		weightageView.setValid("Y".equals(resultSet.getString("DW_VALID")) ? true : false);
		return weightageView;
	}
}
