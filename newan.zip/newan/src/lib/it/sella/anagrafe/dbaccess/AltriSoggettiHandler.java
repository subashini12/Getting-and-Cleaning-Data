package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.AltriSoggettoView;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.altritiposoggetto.AltriTipoSoggetto;
import it.sella.anagrafe.altritiposoggetto.AltriTipoSoggettoView;
import it.sella.anagrafe.altritiposoggetto.IAltriTipoSoggettoBeanManager;
import it.sella.anagrafe.factory.AltriSoggettoViewImpl;
import it.sella.anagrafe.util.ReflectionUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;

public class AltriSoggettiHandler extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AltriSoggettiHandler.class);

    public void createAltriTipoSoggetto(final Long soggettoId, final AltriSoggettoView altriSoggettoView) throws CreateException, RemoteException {
        try {
            final AltriTipoSoggettoView altriTipoSoggettoView = new AltriTipoSoggettoView();
            altriTipoSoggettoView.setSoggettoId(soggettoId);
            altriTipoSoggettoView.setDenominazione(altriSoggettoView.getDatiAnagraficiView().getDenominazione());
            altriTipoSoggettoView.setOpId(altriSoggettoView.getOpId());
            ((IAltriTipoSoggettoBeanManager) getAltriSoggetto()).create(altriTipoSoggettoView);
            
        } catch (final GestoreAnagrafeException e) {
            log4Debug.severeStackTrace(e);
            throw new CreateException(e.getMessage());
        }
    }

    public void setAltriTipoSoggetto(final AltriSoggettoView altriSoggettoView) throws FinderException, RemoteException {
        try {
        	final IAltriTipoSoggettoBeanManager manager = (IAltriTipoSoggettoBeanManager) getAltriSoggetto();
        	final AltriTipoSoggetto altriTipoSoggetto = manager.findBySoggettoId(altriSoggettoView.getId());
            if (altriTipoSoggetto != null) {
                altriTipoSoggetto.setDenominazione(altriSoggettoView.getDatiAnagraficiView().getDenominazione());
                altriTipoSoggetto.setOpId(altriSoggettoView.getOpId());
                manager.update(altriTipoSoggetto);
            }
        }  catch (final GestoreAnagrafeException e) {
            log4Debug.severeStackTrace(e);
            throw new FinderException(e.getMessage());
        }
    }


    public AltriSoggettoView findByDenominazione(final String Denominazione) throws FinderException, RemoteException {
        final AltriSoggettoView altriSoggettoView = new AltriSoggettoViewImpl();
        try {
            AltriTipoSoggetto altriTipoSoggetto = null;
            altriTipoSoggetto = ((IAltriTipoSoggettoBeanManager) getAltriSoggetto()).findByDenominazione(Denominazione);
            altriSoggettoView.setId(altriTipoSoggetto.getSoggettoId());
        } catch (final GestoreAnagrafeException e) {
            log4Debug.severeStackTrace(e);
            throw new FinderException(e.getMessage());
        }
        return altriSoggettoView;
    }
    
	private Object getAltriSoggetto() throws GestoreAnagrafeException {
		return ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.AltriTipoSoggetto");
	}

}
