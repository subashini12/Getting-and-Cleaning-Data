package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Vector;

public class CSSoggettoIdGetter extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CSSoggettoIdGetter.class);

    public Collection getAllSoggettoIdCS(String causale, String valoreCodiceSoggetto) throws GestoreCodiciSoggettoException, RemoteException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet codiciSoggettoResultSet = null;
        final Vector soggettoIds = new Vector();
        logForDBP(causale,"getAllSoggettoIdCS(String causale, String valoreCodiceSoggetto)",valoreCodiceSoggetto);
        try {
            if ("cab6d".equals(causale)) {
                causale = "cab";
                valoreCodiceSoggetto = valoreCodiceSoggetto.substring(0, 5);
            }
            connection = getConnection();
            final StringBuffer query = new StringBuffer("SELECT CS_SOGGETTO_ID FROM an_tr_codicisoggetto AC WHERE");
            if ("cab".equals(causale) && valoreCodiceSoggetto.length() == 5) {
                valoreCodiceSoggetto = valoreCodiceSoggetto + "%";
                query.append(" CS_VALUE like ? AND  CS_RIGHT_PK = ?");
            } else {
                query.append(" CS_VALUE = ? AND  CS_RIGHT_PK = ?");
            }
            query.append(" AND EXISTS (SELECT 1 FROM AN_TR_COLLAGAMENTO_SOGGETTO WHERE CL_SOGGETTO_PRINCIPALE = ? and CL_MOTIVO = ?");
            query.append(" AND CL_LINKED_SOGGETTO = AC.CS_SOGGETTO_ID AND CL_DATA_FINE IS NULL)");
            selectStatement = connection.prepareStatement(query.toString());
            selectStatement.setString(1, valoreCodiceSoggetto);
            selectStatement.setLong(2, getClassificazioneIdFromCausale(causale, "CSDPF").longValue());
            selectStatement.setLong(3, SecurityHandler.getLoginBancaId().longValue());
            selectStatement.setLong(4, getClassificazioneIdFromCausale("CENST", "MOTIV").longValue());
            codiciSoggettoResultSet = selectStatement.executeQuery();
            while (codiciSoggettoResultSet.next()) {
                soggettoIds.add(Long.valueOf(codiciSoggettoResultSet.getLong("CS_SOGGETTO_ID")));
            }
        } catch (final SQLException sqlEx) {
            log4Debug.warnStackTrace(sqlEx);
            throw new GestoreCodiciSoggettoException(sqlEx.getMessage());
        } catch (final SubSystemHandlerException fe) {
            log4Debug.warnStackTrace(fe);
            throw new GestoreCodiciSoggettoException(fe.getMessage());
        } finally {
            cleanup(connection, selectStatement, codiciSoggettoResultSet);
        }
        return soggettoIds;
    }

    public Long getSoggettoIdCS(String causale, String valoreCodiceSoggetto) throws GestoreCodiciSoggettoException, RemoteException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet codiciSoggettoResultSet = null;
        Long soggettoID = null;
        logForDBP(causale,"getSoggettoIdCS(String causale, String valoreCodiceSoggetto)",valoreCodiceSoggetto);
        try {
            if ("abi6d".equals(causale)) {
                causale = "abi";
                valoreCodiceSoggetto = valoreCodiceSoggetto.substring(0, 5);
            } else if ("cab6d".equals(causale)) {
                causale = "cab";
                valoreCodiceSoggetto = valoreCodiceSoggetto.substring(0, 5);
            }
            final long causaleId = getClassificazioneIdFromCausale(causale, "CSDPF").longValue();
            connection = getConnection();
            if ("codiceHost".equals(causale)) {
                if (valoreCodiceSoggetto != null && valoreCodiceSoggetto.length() == 8) {
					valoreCodiceSoggetto = new StringBuffer("0").append(valoreCodiceSoggetto).toString();
				}
                final String query = "SELECT CO_SOGGETTO_ID FROM AN_TR_CODICIHOST WHERE EXISTS (SELECT /*+ INDEX ( AN_TR_COLLAGAMENTO_SOGGETTO AN_COLL_LS_MOTIV_SP_IN1002) */ 1  FROM AN_TR_COLLAGAMENTO_SOGGETTO WHERE DECODE(CL_SOGGETTO_PRINCIPALE, ?, CL_SOGGETTO_PRINCIPALE, NULL) IS NOT NULL AND CL_MOTIVO = ? AND CL_LINKED_SOGGETTO = CO_SOGGETTO_ID) AND CO_CODICIHOST = ?";
                selectStatement = connection.prepareStatement(query);
                selectStatement.setLong(1, SecurityHandler.getLoginBancaId().longValue());
                selectStatement.setLong(2, getClassificazioneIdFromCausale("CENST", "MOTIV").longValue());
                selectStatement.setString(3, valoreCodiceSoggetto);
                codiciSoggettoResultSet = selectStatement.executeQuery();
                soggettoID = codiciSoggettoResultSet.next() ? 
                		Long.valueOf(codiciSoggettoResultSet.getLong("CO_SOGGETTO_ID")) : null;
            } else {
                String query = null;
                if ("cab".equals(causale) && valoreCodiceSoggetto != null && valoreCodiceSoggetto.length() == 5) {
                    valoreCodiceSoggetto = valoreCodiceSoggetto + "%";
                    query = "SELECT  CS_SOGGETTO_ID, CS_OP_ID FROM an_tr_codicisoggetto ac WHERE CS_VALUE LIKE ? AND  CS_RIGHT_PK = ? and exists (select 1 from an_tr_collagamento_soggetto where CL_SOGGETTO_PRINCIPALE = ? AND CL_MOTIVO = ? and  CL_LINKED_SOGGETTO = ac.CS_SOGGETTO_ID AND cl_Data_fine is null)";
                } else {
                    query = "SELECT  CS_SOGGETTO_ID, CS_OP_ID FROM an_tr_codicisoggetto ac WHERE CS_VALUE = ? AND  CS_RIGHT_PK = ? and exists (select 1 from an_tr_collagamento_soggetto where CL_SOGGETTO_PRINCIPALE = ? AND CL_MOTIVO = ? and  CL_LINKED_SOGGETTO = ac.CS_SOGGETTO_ID AND cl_Data_fine is null)";
                }
                long motivId = 0;
                if ("coddp".equals(causale)) {
					motivId = getClassificazioneIdFromCausale("DIPEN", "MOTIV").longValue();
				} else if ("codpr".equals(causale)) {
					motivId = getClassificazioneIdFromCausale("PROMT", "MOTIV").longValue();
				} else {
					motivId = getClassificazioneIdFromCausale("CENST", "MOTIV").longValue();
				}
                selectStatement = connection.prepareStatement(query);
                selectStatement.setString(1, valoreCodiceSoggetto);
                selectStatement.setLong(2, causaleId);
                selectStatement.setLong(3, SecurityHandler.getLoginBancaId().longValue());
                selectStatement.setLong(4, motivId);
                codiciSoggettoResultSet = selectStatement.executeQuery();
                soggettoID = codiciSoggettoResultSet.next() ? 
                		Long.valueOf(codiciSoggettoResultSet.getLong("CS_SOGGETTO_ID")) : null;
            }
        } catch (final SQLException sqlEx) {
            log4Debug.warnStackTrace(sqlEx);
            throw new GestoreCodiciSoggettoException(sqlEx.getMessage());
        } catch (final SubSystemHandlerException fe) {
            log4Debug.warnStackTrace(fe);
            throw new GestoreCodiciSoggettoException(fe.getMessage());
        } finally {
            cleanup(connection, selectStatement, codiciSoggettoResultSet);
        }
        return soggettoID;
    }
    
    public Long getSoggettoIdForCodiceHost(final String codiceHost) throws GestoreCodiciSoggettoException, RemoteException {
		try {
			return getSoggettoIdForCodiceHost(codiceHost,SecurityHandler.getLoginBancaId());
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new GestoreCodiciSoggettoException(e.getMessage());
		}
	}

	// only to be used internally as it not supports multibanca.. written for GestoreAnagrafeLogger application to get soggettoid for selected bank
    public Long getSoggettoIdForCodiceHost(String codiceHost,final Long bancaId) throws GestoreCodiciSoggettoException, RemoteException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        Long soggettoId = null;

        if (codiceHost != null && codiceHost.length() == 8) {
			codiceHost = "0" + codiceHost;
		}
        try {
            connection = getConnection();
            final String query = "select co_Soggetto_id from an_tr_codicihost ac where co_codicihost = ? and exists (Select 1 from an_tr_collagamento_soggetto where CL_SOGGETTO_PRINCIPALE = ? and cl_motivo = ? and cl_linked_Soggetto = ac.CO_SOGGETTO_ID and cl_Data_fine is null)";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, codiceHost);
            preparedStatement.setLong(2, bancaId.longValue());
            preparedStatement.setLong(3, getClassificazioneIdFromCausale("CENST", "MOTIV").longValue());
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                soggettoId = Long.valueOf(resultSet.getLong("CO_SOGGETTO_ID"));
            }
        } catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreCodiciSoggettoException(e.getMessage());
        } catch (final SubSystemHandlerException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreCodiciSoggettoException(e.getMessage());
        } finally {
            cleanup(connection, preparedStatement, resultSet);
        }
        return soggettoId;
    }
    
    public List getSoggettoIdListForCodiceHost(String codiceHost) throws GestoreCodiciSoggettoException, RemoteException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        final List soggettoIdList = new ArrayList();

        if (codiceHost != null && codiceHost.length() == 8) {
			codiceHost = "0" + codiceHost;
		}
        try {
            connection = getConnection();
            final String query = "select co_Soggetto_id from an_tr_codicihost ac where co_codicihost = ? and exists (Select 1 from an_tr_collagamento_soggetto where CL_SOGGETTO_PRINCIPALE = ? and cl_motivo = ? and cl_linked_Soggetto = ac.CO_SOGGETTO_ID and cl_Data_fine is null)";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, codiceHost);
            preparedStatement.setLong(2, SecurityHandler.getLoginBancaId());
            preparedStatement.setLong(3, getClassificazioneIdFromCausale("CENST", "MOTIV").longValue());
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
            	soggettoIdList.add(Long.valueOf(resultSet.getLong("CO_SOGGETTO_ID")));
            }
        } catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreCodiciSoggettoException(e.getMessage());
        } catch (final SubSystemHandlerException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreCodiciSoggettoException(e.getMessage());
        } finally {
            cleanup(connection, preparedStatement, resultSet);
        }
        return soggettoIdList;
    }
    
    private void logForDBP(final String causale,final String methodName,final String codiciValue) {
    	if(causale != null && "codlm".equals(causale) || "coddp".equals(causale) || 
    			"excoddp".equals(causale) || "cdr".equals(causale) || "codsu".equals(causale) ||
    			"cab".equals(causale) || "codArea".equals(causale) || "abi".equals(causale)) {
			   try {
	   	   		   final String errorMessage = "<<<<<<<<<<< Anagrafe called for DBP data: ";
				   throw new Exception(errorMessage+ methodName + " " + causale + " " +codiciValue);
	   		   } catch (final Exception e) {
	   			   log4Debug.warnStackTrace(e);
	   		   }
    	}
    }
}
