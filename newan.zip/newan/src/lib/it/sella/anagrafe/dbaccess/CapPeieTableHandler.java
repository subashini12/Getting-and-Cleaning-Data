package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreCittaException;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.view.CapPeieView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

public class CapPeieTableHandler extends DBAccessHelper {
	
    private static final Log4Debug log = Log4DebugFactory.getLog4Debug(CapPeieTableHandler.class);
    
    public Collection getCapPeieCollection(final String sigle)throws GestoreCittaException {
    	Connection connection = null;
        PreparedStatement capPeieStatement = null;
        ResultSet capPeieResultSet = null;
        final Collection capPeieList = new ArrayList();
        try {
            connection = getConnection();
            capPeieStatement = connection.prepareStatement("Select CP_PE_ID, CP_PE_SIGLE, CP_PE_LOCALITA, CP_PE_DACAP, CP_PE_ACAP from AN_MA_CAP_PEIE where CP_PE_SIGLE = ? ");
            capPeieStatement.setString(1,sigle);
            capPeieResultSet = capPeieStatement.executeQuery();
            while(capPeieResultSet.next()) {
            	final CapPeieView capView = new CapPeieView();
            	capView.setId(Long.valueOf(capPeieResultSet.getLong("CP_PE_ID")));
            	capView.setSigle(capPeieResultSet.getString("CP_PE_SIGLE"));
            	capView.setLocalita(capPeieResultSet.getString("CP_PE_LOCALITA"));
            	capView.setDaCap(capPeieResultSet.getString("CP_PE_DACAP"));
            	capView.setACap(capPeieResultSet.getString("CP_PE_ACAP"));
            	capPeieList.add(capView);
            }
        } catch(final SQLException e) {
        	log.warnStackTrace(e);
        	throw new GestoreCittaException(e.getMessage());
        } catch(final NumberFormatException e) {
        	log.warnStackTrace(e);
        	throw new GestoreCittaException(new AnagrafeHelper().getMessage("ANAG-1430"));
        } finally {
        	cleanup(connection, capPeieStatement, capPeieResultSet);
        }
      return capPeieList;
    }
    
    public void setCapPeie(final CapPeieView capPeieView)throws GestoreCittaException {
    	Connection connection = null;
        PreparedStatement capPeieStatement = null;
        try {
        	connection = getConnection();
        	capPeieStatement = connection.prepareStatement("update AN_MA_CAP_PEIE set CP_PE_SIGLE = ?, CP_PE_LOCALITA = ?, CP_PE_DACAP = ?, CP_PE_ACAP = ? where CP_PE_ID = ? ");
        	capPeieStatement.setString(1,capPeieView.getSigle());
        	capPeieStatement.setString(2,capPeieView.getLocalita());
        	capPeieStatement.setString(3,capPeieView.getDaCap());
        	capPeieStatement.setString(4,capPeieView.getACap());
        	capPeieStatement.setLong(5,capPeieView.getId().longValue());
        	capPeieStatement.executeUpdate();
        } catch (final SQLException e) {
        	log.warnStackTrace(e);
        	throw new GestoreCittaException(e.getMessage());
        } finally {
        
        	cleanup(connection, capPeieStatement);
        }
    }
    
    public void removeCapPeie(final Long capId)throws GestoreCittaException {
    	Connection connection = null;
        PreparedStatement capDeleteStatement = null;
        try {
        	connection = getConnection();
        	capDeleteStatement =  connection.prepareStatement("delete from AN_MA_CAP_PEIE where CP_PE_ID = ? ");
        	capDeleteStatement.setLong(1,capId.longValue());
        	capDeleteStatement.executeUpdate();
        } catch (final SQLException e) {
        	log.warnStackTrace(e);
        	throw new GestoreCittaException(e.getMessage());
        } finally {
        	cleanup(connection, capDeleteStatement);
        }
    }
    
    public void createCapPeie(final CapPeieView capPeieView)throws GestoreCittaException {
    	Connection connection = null;
        PreparedStatement capInsertStatement = null;
        try {
        	connection = getConnection();
        	capInsertStatement = connection.prepareStatement("insert into AN_MA_CAP_PEIE (CP_PE_ID, CP_PE_SIGLE, CP_PE_LOCALITA, CP_PE_DACAP, CP_PE_ACAP) values (AN_SQ_CP_ID.NEXTVAL,?,?,?,?)");
        	capInsertStatement.setString(1,capPeieView.getSigle());
        	capInsertStatement.setString(2,capPeieView.getLocalita());
        	capInsertStatement.setString(3,capPeieView.getDaCap());
        	capInsertStatement.setString(4,capPeieView.getACap());
        	capInsertStatement.executeUpdate(); 
        } catch (final SQLException e) {
        	log.warnStackTrace(e);
        	throw new GestoreCittaException(e.getMessage());
        } finally {
        	cleanup(connection,capInsertStatement);
        }
    }   
        
    public CapPeieView getCapPeieView( final Long pkId )throws GestoreCittaException {
    	 Connection connection = null;
    	 PreparedStatement capSelectViewStatement = null;
    	 ResultSet capSelectResultSet = null;
    	 final CapPeieView capPeieView = new CapPeieView();
    	 try {
    		 connection = getConnection();
    		 capSelectViewStatement = connection.prepareStatement("select CP_PE_ID, CP_PE_SIGLE, CP_PE_LOCALITA, CP_PE_DACAP, CP_PE_ACAP from AN_MA_CAP_PEIE where CP_PE_ID = ? ");
    		 capSelectViewStatement.setLong(1,pkId.longValue());
    		 capSelectResultSet = capSelectViewStatement.executeQuery();
    		 if ( capSelectResultSet.next()) {
    			 capPeieView.setId(Long.valueOf(capSelectResultSet.getLong("CP_PE_ID")));
    			 capPeieView.setSigle(capSelectResultSet.getString("CP_PE_SIGLE"));
    			 capPeieView.setLocalita(capSelectResultSet.getString("CP_PE_LOCALITA"));
    			 capPeieView.setDaCap(capSelectResultSet.getString("CP_PE_DACAP"));
    			 capPeieView.setACap(capSelectResultSet.getString("CP_PE_ACAP"));
    		 }
    	 } catch (final SQLException e) {
        	log.warnStackTrace(e);
        	throw new GestoreCittaException(e.getMessage());
         } catch (final NumberFormatException e) {
        	 log.warnStackTrace(e);
        	 throw new GestoreCittaException(e.getMessage());
         } finally {
           	cleanup(connection,capSelectViewStatement,capSelectResultSet);
         } 
         return capPeieView;
    }	 
}
