package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.collegamento.Collegamento;
import it.sella.anagrafe.collegamento.ICollegamentoBeanManager;
import it.sella.anagrafe.discriminator.CollegamentoException;
import it.sella.anagrafe.util.ReflectionUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import javax.ejb.FinderException;

public class CollegamentoSoggettiHelper extends DBAccessHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CollegamentoSoggettiHelper.class);

    public Collegamento getColleganteMotivoAndLinked(final Long principaleId, final String motivoCollegamento, final Long linkedSoggettoId) throws CollegamentoException, RemoteException {
        Collegamento collegamento = null;
        try {
            final Long motivo = getClassificazioneIdFromCausale(motivoCollegamento, "MOTIV");
            final ICollegamentoBeanManager collegamentoBeanManager = ((ICollegamentoBeanManager) getCollegamento());
            collegamento = collegamentoBeanManager.findBySoggettoMotivoAndLinked(principaleId, motivo, linkedSoggettoId);
        } catch (final GestoreAnagrafeException ce) {
            log4Debug.severeStackTrace(ce);
            throw new CollegamentoException(ce.getLocalizedMessage());
        } catch (final FinderException fe) {
            log4Debug.severeStackTrace(fe);
            throw new CollegamentoException(fe.getLocalizedMessage());
        }
        final Timestamp currentDate = new Timestamp(System.currentTimeMillis());
        return (collegamento.getDataInizio().after(currentDate) || ((collegamento.getDataFine() != null) && ((collegamento.getDataFine().before(currentDate)) || collegamento.getDataFine().equals(currentDate)))) ?
        		null : collegamento;
    }

	private Object getCollegamento() throws GestoreAnagrafeException {
		return ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.Collegamento");
	}

    public Long getPrincipaleForSoggettiColleganti(final Collection linkedSoggettoIds, final String motivoCollegamento) throws CollegamentoException, RemoteException {
        /*for all linked soggettos get the principaleidsCollection, compare whether the same princiaple
          ids are existing in all the principaleidsCollection. If it exists call the getLinked soggetto
          and check the size for the retrieved collection and the passed collection size are the same,
          if so return the principale id else return null*/
        Long principaleId = null;
        final ArrayList commonPrincipaleIds = new ArrayList();
        try {
            if (linkedSoggettoIds != null) {
            	final ICollegamentoBeanManager collegamentoBeanManager = ((ICollegamentoBeanManager) getCollegamento());
                final Iterator linkedSoggettoIterator = linkedSoggettoIds.iterator();
                final int size = linkedSoggettoIds.size();
                final Hashtable principaleHashtable = new Hashtable();
                final Long motivId = getClassificazioneIdFromCausale(motivoCollegamento, "MOTIV");
                for (int i = 0; i < size; i++) {
                    final Long linkedSoggettoId = (Long) linkedSoggettoIterator.next();
                    final Collection principaleCollection = collegamentoBeanManager.findBySoggettoCollegamento(linkedSoggettoId, motivId);
                    if (principaleCollection != null && !principaleCollection.isEmpty()) {
                        final int principaleSize = principaleCollection.size();
                        final Iterator principaleIterator = principaleCollection.iterator();
                        final ArrayList principaleList = new ArrayList();
                        for (int j = 0; j < principaleSize; j++) {
                            final Collegamento collegamento = (Collegamento) principaleIterator.next();
                            principaleList.add(collegamento.getSoggettoId());
                        }
                        principaleHashtable.put(linkedSoggettoId, principaleList);
                    } else {
                        principaleHashtable.put(linkedSoggettoId, new ArrayList());
                    }
                }

                //  To check whether the same principale is existing in all the vectors

                if (principaleHashtable.size() > 0) {
                    final Collection principaleCollection = principaleHashtable.values();
                    final int count = principaleCollection.size();
                    Iterator iterator = principaleCollection.iterator();
                    final ArrayList firstVector = (ArrayList) iterator.next();
                    final int firstVectorSize = firstVector.size();
                    Long tempId = null;
                    for (int k = 0; k < firstVectorSize; k++) {
                        tempId = (Long) firstVector.get(k);
                        if (k > 0) {
                            iterator = principaleCollection.iterator();
                            iterator.next();
                        }
                        for (int j = 0; j < count - 1; j++) {
                        	final ArrayList nextVector = (ArrayList) iterator.next();
                            if (!nextVector.contains(tempId)) {
								break;
							} else if (j == count - 2) {
								commonPrincipaleIds.add(tempId);
							}
                        }
                    }
                    if (! commonPrincipaleIds.isEmpty()) {
                        Long checkId = null;
                        final int total = commonPrincipaleIds.size();
                        final TipoSoggettoHandler tipoSoggettoHandler = new TipoSoggettoHandler();
                        loopfirst:
                        for (int l = 0; l < total; l++) {
                            checkId = (Long) commonPrincipaleIds.get(l);
                            final Collection linkedCollection = collegamentoBeanManager.findBySoggettoAndMotivo(checkId, motivId, null);
                            if (linkedCollection != null && linkedCollection.size() == linkedSoggettoIds.size()) {
                                final int linkedSize = linkedCollection.size();
                                final Iterator linkedIterator = linkedCollection.iterator();
                                final ArrayList inputIdsVector = new ArrayList(linkedSoggettoIds);
                                Collegamento collegamento = null;
                                loopsecond:
                                for (int m = 0; m < linkedSize; m++) {
                                    collegamento = (Collegamento) linkedIterator.next();
                                    if (!inputIdsVector.contains(collegamento.getLinkedSoggettoId())) {
										break loopsecond;
									} else if (m == (linkedSize - 1) && tipoSoggettoHandler.getTipoSoggetto(checkId) != null ) {
                                        principaleId = checkId;
                                        break loopfirst;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (final FinderException fe) {
            log4Debug.severeStackTrace(fe);
            throw new CollegamentoException(fe.getLocalizedMessage());
        } catch (final GestoreAnagrafeException ce) {
            log4Debug.severeStackTrace(ce);
            throw new CollegamentoException(ce.getLocalizedMessage());
        }
        return principaleId;
    }
}

