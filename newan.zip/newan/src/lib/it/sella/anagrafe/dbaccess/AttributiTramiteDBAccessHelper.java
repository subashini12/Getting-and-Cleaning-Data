package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreNazioneException;
import it.sella.anagrafe.IAttributiTramiteView;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.az.AttributiTramiteAZView;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.discriminator.AttributiEsterniDiscriminatorException;
import it.sella.anagrafe.implementation.AttributiTramiteView;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AttributiTramiteDBAccessHelper extends DBAccessHelper {
    
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AttributiTramiteDBAccessHelper.class);
    
    public IAttributiTramiteView getAttributiTramite( final Long soggettoId, final Long bankId) 
    		throws AttributiEsterniDiscriminatorException, RemoteException {
        Connection connection = null;
        PreparedStatement attributiPreparedStatement = null;
        ResultSet attributiResultSet = null;
        AttributiTramiteView attributiTramiteView = null; 
        String aROB = null;
        String eROB = null;
        final it.sella.anagrafe.util.StringHandler stringHandler = new it.sella.anagrafe.util.StringHandler();
    	try {
            connection = getConnection();
            final StringBuffer queryBuffer = new StringBuffer("select AT.AT_NAZCM, AT.AT_SETTCM, AT.AT_AROB, ");
            queryBuffer.append("AT.AT_EROB, AT.AT_OP_ID from AN_TR_ATTRIBUTI_TRAMITE AT where ");
            queryBuffer.append("AT.AT_SOGGETTO_ID = ?");
            if(bankId != null) {
            	queryBuffer.append("AND EXISTS (SELECT 1 FROM AN_TR_COLLAGAMENTO_SOGGETTO WHERE ");
            	queryBuffer.append("CL_SOGGETTO_PRINCIPALE = ? AND CL_MOTIVO = ? AND CL_LINKED_SOGGETTO = ");
            	queryBuffer.append("AT.AT_SOGGETTO_ID AND CL_DATA_FINE IS NULL)");
            }
			attributiPreparedStatement = connection.prepareStatement(queryBuffer.toString());
            attributiPreparedStatement.setLong(1, soggettoId);
            if(bankId != null) {
                attributiPreparedStatement.setLong(2, bankId);
                attributiPreparedStatement.setLong(3, getClassificazioneIdFromCausale(
                		"CENST", "MOTIV").longValue());
            }
            attributiResultSet = attributiPreparedStatement.executeQuery();
            if(attributiResultSet.next()) {
            	attributiTramiteView = new AttributiTramiteView();
            	attributiTramiteView.setSoggettoId(soggettoId);
            	final Long nazioneId = Long.valueOf(attributiResultSet.getLong("AT_NAZCM"));
            	if(nazioneId != null) {
            		attributiTramiteView.setNazioneView(new NazioneDBAccessHelper().getNazione(nazioneId));
            	}
            	attributiTramiteView.setSettore(attributiResultSet.getString("AT_SETTCM"));
             	aROB = attributiResultSet.getString("AT_AROB");
            	if(stringHandler.isNumeric(aROB)) {
            		attributiTramiteView.setAROB(Long.valueOf(aROB));	
            	}
            	eROB = attributiResultSet.getString("AT_EROB");
            	if(stringHandler.isNumeric(eROB)) {
            		attributiTramiteView.setEROB(Long.valueOf(eROB));	
            	}
            	attributiTramiteView.setOpId(Long.valueOf(attributiResultSet.getLong("AT_OP_ID")));
            }
    	} catch (final SQLException se) {
            log4Debug.severeStackTrace(se);
            throw new AttributiEsterniDiscriminatorException(se.getMessage());
        } catch (final SubSystemHandlerException ce) {
            log4Debug.severeStackTrace(ce);
            throw new AttributiEsterniDiscriminatorException(ce.getMessage());
        } catch (final GestoreNazioneException ce) {
            log4Debug.severeStackTrace(ce);
            throw new AttributiEsterniDiscriminatorException(ce.getMessage());
        } finally {
            cleanup(connection, attributiPreparedStatement, attributiResultSet);
        }
        return attributiTramiteView;
    }

    public AttributiTramiteAZView getAttributiTramiteAZView( final Long soggettoId) throws AttributiEsterniDiscriminatorException, RemoteException {
        Connection connection = null;
        PreparedStatement attributiPreparedStatement = null;
        ResultSet attributiResultSet = null;
        AttributiTramiteAZView attributiTramiteAZView = null;
        String aROB = null;
        String eROB = null;
        final it.sella.anagrafe.util.StringHandler stringHandler = new it.sella.anagrafe.util.StringHandler();
    	try {
            connection = getConnection();
            attributiPreparedStatement = connection.prepareStatement(
            		"select AT.AT_ATTRIBUTI_TRAMITE_ID, AT.AT_NAZCM, AT.AT_SETTCM, AT.AT_AROB, AT.AT_EROB, AT.AT_OP_ID from AN_TR_ATTRIBUTI_TRAMITE AT, AN_TR_COLLAGAMENTO_SOGGETTO CS where CS.CL_SOGGETTO_PRINCIPALE = ? AND CS.CL_MOTIVO = ?  AND CS.CL_DATA_FINE IS NULL  AND CS.CL_LINKED_SOGGETTO = AT.AT_SOGGETTO_ID AND AT.AT_SOGGETTO_ID = ?");
            attributiPreparedStatement.setLong(1, SecurityHandler.getLoginBancaId().longValue());
            attributiPreparedStatement.setLong(2, getClassificazioneIdFromCausale("CENST", "MOTIV").longValue());
            attributiPreparedStatement.setLong(3, soggettoId.longValue());
            attributiResultSet = attributiPreparedStatement.executeQuery();
            if(attributiResultSet.next()) {
            	attributiTramiteAZView = new AttributiTramiteAZView();
            	attributiTramiteAZView.setSoggettoId(soggettoId);
            	attributiTramiteAZView.setId(Long.valueOf(attributiResultSet.getLong("AT_ATTRIBUTI_TRAMITE_ID")));
            	final Long nazioneId = Long.valueOf(attributiResultSet.getLong("AT_NAZCM"));
            	if(nazioneId != null) {
            		attributiTramiteAZView.setNazioneView(new NazioneDBAccessHelper().getNazione(nazioneId));
            	}
            	attributiTramiteAZView.setSettore(attributiResultSet.getString("AT_SETTCM"));
            	aROB = attributiResultSet.getString("AT_AROB");
            	if(stringHandler.isNumeric(aROB)) {
            		attributiTramiteAZView.setAROB(Long.valueOf(aROB));	
            	}
            	eROB = attributiResultSet.getString("AT_EROB");
            	if(stringHandler.isNumeric(eROB)) {
            		attributiTramiteAZView.setEROB(Long.valueOf(eROB));	
            	}
            	attributiTramiteAZView.setOpId(Long.valueOf(attributiResultSet.getLong("AT_OP_ID")));
            }
    	} catch (final SQLException se) {
            log4Debug.severeStackTrace(se);
            throw new AttributiEsterniDiscriminatorException(se.getMessage());
        } catch (final SubSystemHandlerException ce) {
            log4Debug.severeStackTrace(ce);
            throw new AttributiEsterniDiscriminatorException(ce.getMessage());
        } catch (final GestoreNazioneException ce) {
            log4Debug.severeStackTrace(ce);
            throw new AttributiEsterniDiscriminatorException(ce.getMessage());
        } finally {
            cleanup(connection, attributiPreparedStatement, attributiResultSet);
        }
        return attributiTramiteAZView;
    }
    
    public void updateAttributiTramite( final IAttributiTramiteView attributiTramiteView) throws OperazioneAnagrafeManagerException {    	
    	Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("UPDATE AN_TR_ATTRIBUTI_TRAMITE SET AT_NAZCM = ?  , AT_SETTCM = ? ,AT_AROB = ?,AT_EROB = ?,AT_OP_ID = ?  WHERE AT_SOGGETTO_ID = ? ");
            preparedStatement.setLong(1, attributiTramiteView.getNazioneView().getNazioneId());
            preparedStatement.setString(2, attributiTramiteView.getSettore());
            checkForNullAndSetLongValue(preparedStatement, attributiTramiteView.getAROB(), 3);
            checkForNullAndSetLongValue(preparedStatement, attributiTramiteView.getEROB(), 4);
        	preparedStatement.setLong(5, attributiTramiteView.getOpId());
            preparedStatement.setLong(6, attributiTramiteView.getSoggettoId());
            preparedStatement.executeUpdate();            
        } catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new OperazioneAnagrafeManagerException(se.getMessage());
        } finally {
            cleanup(connection, preparedStatement);
        }
    }
    public void removeAttributiTramite(  final Long soggettoId, final Long opId ) throws OperazioneAnagrafeManagerException {    	
    	Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
        	new StoricDataUpdateHelper().updateAttributiTramite(soggettoId, opId);
            connection = getConnection();
            preparedStatement = connection.prepareStatement("DELETE FROM AN_TR_ATTRIBUTI_TRAMITE WHERE AT_SOGGETTO_ID = ?");
            preparedStatement.setLong(1, soggettoId);
            preparedStatement.executeUpdate();            
        } catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new OperazioneAnagrafeManagerException(se.getMessage());
        } catch (final ControlloDatiException e) {
            log4Debug.warnStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage());
		} finally {
            cleanup(connection, preparedStatement);
        }
    }
    
    public void createAttributiTramite( final IAttributiTramiteView attributiTramiteView) throws OperazioneAnagrafeManagerException {    	
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("INSERT INTO AN_TR_ATTRIBUTI_TRAMITE (AT_ATTRIBUTI_TRAMITE_ID, AT_SOGGETTO_ID, AT_NAZCM, AT_SETTCM, AT_AROB ,AT_EROB,AT_OP_ID ) VALUES(SEQ_ATTRIBUTIESTERNIHOME.NEXTVAL, ?, ? , ?, ?, ?, ?)");
            preparedStatement.setLong(1, attributiTramiteView.getSoggettoId());
            preparedStatement.setLong(2, attributiTramiteView.getNazioneView().getNazioneId());
            preparedStatement.setString(3, attributiTramiteView.getSettore());
            checkForNullAndSetLongValue(preparedStatement, attributiTramiteView.getAROB(), 4);
            checkForNullAndSetLongValue(preparedStatement, attributiTramiteView.getEROB(), 5);
            preparedStatement.setLong(6, attributiTramiteView.getOpId());
            preparedStatement.executeUpdate();            
        } catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new OperazioneAnagrafeManagerException(se.getMessage());
        } finally {
            cleanup(connection, preparedStatement);
        }
    }
}

