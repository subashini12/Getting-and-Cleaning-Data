package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreCollegamentoException;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;

public class CollegamentoHistoryHelper extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CollegamentoHistoryHelper.class);

    public Collection getCollegamentoHistory(final Hashtable inputData) throws GestoreCollegamentoException, RemoteException {
        final ArrayList collegamentoViews = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        final AnagrafeHelper helper = new AnagrafeHelper();
        final Long linkedSoggettoId = (Long) inputData.get("LINKED_SOGGETTO_ID");
        final Long soggettoPrincipaleId = (Long) inputData.get("SOGGETTO_PRINCIPALE_ID");
        final String motiv = (String) inputData.get("MOTIV");
        final Timestamp dataFine = (Timestamp) inputData.get("DATA_FINE");
        final Timestamp dataInizio = (Timestamp) inputData.get("DATA_INIZIO");

        final String query = "SELECT CL_ID,CL_SOGGETTO_PRINCIPALE, CL_MOTIVO, CL_NOTE, CL_DATA_INIZIO, CL_DATA_FINE, CL_LINKED_SOGGETTO FROM AN_TR_COLLAGAMENTO_SOGGETTO WHERE ";
        final String countQuery = "SELECT COUNT(*) AS COUNT FROM AN_TR_COLLAGAMENTO_SOGGETTO WHERE ";
        String tempQuery = "";
        try {
            connection = getConnection();
            if (linkedSoggettoId == null && soggettoPrincipaleId == null) {
                throw new GestoreCollegamentoException(helper.getMessage("ANAG-1335"));
            }
            final Long motivId = motiv != null ?
            		getClassificazioneIdFromCausale(motiv, "MOTIV") : null;
            boolean isAndToBeAdded = false;
            try {
            	final BancaCheckUtil bancaHelper = new BancaCheckUtil();
                if (soggettoPrincipaleId != null) {
                    if (inputData.get("NO_CENST_CHECK") == null && !bancaHelper.checkForBanca(soggettoPrincipaleId, null)) {
						return collegamentoViews;
					}
                    tempQuery += " CL_SOGGETTO_PRINCIPALE = ? ";
                    isAndToBeAdded = true;
                }
                if (linkedSoggettoId != null) {
                    if (inputData.get("NO_CENST_CHECK") == null && !bancaHelper.checkForBanca(linkedSoggettoId, null)) {
						return collegamentoViews;
					}
                    tempQuery += isAndToBeAdded ? 
                    		" AND CL_LINKED_SOGGETTO = ? " : " CL_LINKED_SOGGETTO = ? " ; 
                }
                if (motivId != null) {
					tempQuery += " AND CL_MOTIVO = ?";
				}
            } catch (final GestoreAnagrafeException e) {
                log4Debug.severeStackTrace(e);
                throw new GestoreCollegamentoException(e.getMessage());
            }
            if (dataInizio != null) {
				tempQuery += " AND to_char(CL_DATA_INIZIO,'ddMMyyyy') = to_char(?,'ddMMyyyy') ";
			}
            if (dataFine != null) {
				tempQuery += " AND to_char(CL_DATA_FINE,'ddMMyyyy') = to_char(?,'ddMMyyyy') ";
			}


            preparedStatement = connection.prepareStatement(countQuery + tempQuery);
            preparedStatement = setPreparedStatementForCollegamentoHistory(preparedStatement, soggettoPrincipaleId, linkedSoggettoId, motivId, dataInizio, dataFine);
            resultSet = preparedStatement.executeQuery();
            final int count = resultSet.next() ? resultSet.getInt("COUNT") : -1;
            if (count < 200) {
                closeResultSet(resultSet);
                closeStatement(preparedStatement);
                preparedStatement = connection.prepareStatement(query + tempQuery);
                preparedStatement = setPreparedStatementForCollegamentoHistory(preparedStatement, soggettoPrincipaleId, linkedSoggettoId, motivId, dataInizio, dataFine);
                resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    final it.sella.anagrafe.CollegamentoView collegamentoView = new it.sella.anagrafe.CollegamentoView();
                    collegamentoView.setLinkedSoggettoId(Long.valueOf(resultSet.getLong("CL_LINKED_SOGGETTO")));
                    collegamentoView.setSoggettoPrincipaleId(Long.valueOf(resultSet.getLong("CL_SOGGETTO_PRINCIPALE")));
                    collegamentoView.setMotivoCausale(ClassificazioneHandler.getClassificazioneView(Long.valueOf(resultSet.getLong("CL_MOTIVO"))).getCausale());
                    collegamentoView.setDataInizio(resultSet.getDate("CL_DATA_INIZIO") != null ?
                    		new Timestamp(resultSet.getDate("CL_DATA_INIZIO").getTime()) : null);
                    collegamentoView.setDataFine(resultSet.getDate("CL_DATA_FINE") != null ? 
                    		new Timestamp(resultSet.getDate("CL_DATA_FINE").getTime()) : null);
                    collegamentoView.setCollegamentoId(Long.valueOf(resultSet.getLong("CL_ID")));
                    collegamentoViews.add(collegamentoView);
                }
            } else {
				throw new GestoreCollegamentoException(helper.getMessage("ANAG-1336"));
			}

        } catch (final SQLException e) {
            log4Debug.severeStackTrace(e);
            throw new GestoreCollegamentoException(e.getMessage());
        } catch (final GestoreAnagrafeException e) {
            log4Debug.severeStackTrace(e);
            throw new GestoreCollegamentoException(e.getMessage());
        } finally {
            cleanup(connection, preparedStatement, resultSet);
        }
        return collegamentoViews;
    }
    
    private PreparedStatement setPreparedStatementForCollegamentoHistory(final PreparedStatement preparedStatement, final Long soggettoPrincipaleId, final Long linkedSoggettoId, final Long motivId, final Timestamp dataInizio, final Timestamp dataFine) throws SQLException {
        int counter = 0;
        if (soggettoPrincipaleId != null) {
			preparedStatement.setLong(++counter, soggettoPrincipaleId.longValue());
		}
        if (linkedSoggettoId != null) {
			preparedStatement.setLong(++counter, linkedSoggettoId.longValue());
		}
        if (motivId != null) {
			preparedStatement.setLong(++counter, motivId.longValue());
		}
        if (dataInizio != null) {
			preparedStatement.setTimestamp(++counter, dataInizio);
		}
        if (dataFine != null) {
			preparedStatement.setTimestamp(++counter, dataFine);
		}
        return preparedStatement;
    }

}

