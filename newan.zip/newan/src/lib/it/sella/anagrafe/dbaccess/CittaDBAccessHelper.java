package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreCittaException;
import it.sella.anagrafe.ICittaView;
import it.sella.anagrafe.InformazioneManagerException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.common.Citta;
import it.sella.anagrafe.common.Provincia;
import it.sella.anagrafe.implementation.CittaView;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.util.StringHandler;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Vector;

import javax.ejb.EJBException;

public class CittaDBAccessHelper extends CittaUpdateHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CittaDBAccessHelper.class);

    public ICittaView getCitta( final Long cittaId ) throws GestoreCittaException {
        Connection connection = null;
        PreparedStatement preparedstatement = null;
        ResultSet resultset = null;
        try {
            connection = getConnection();
            preparedstatement = connection.prepareStatement("select CI_ID, CI_COMMUNE, CI_PROVINCIA, CI_REGION, CI_CAPOLUOGO, CI_CAB, CI_CINCAB, CI_CAB_STORICO, CI_CNCF, CI_CAP, CI_STORICO, CI_ALTRADENOMINAZIONE from  AN_MA_CITTA where CI_ID = ?");
            preparedstatement.setLong(1, cittaId.longValue());
            resultset = preparedstatement.executeQuery();
            return resultset.next() ? getCittaViewFromResultSet(resultset) : null;
        } catch (final SQLException sqlexception) {
            log4Debug.debug("<<GA>> Exception while getting the citta ", sqlexception.getMessage());
            throw new GestoreCittaException(sqlexception.getMessage());
        } finally {
            cleanup(connection, preparedstatement, resultset);
        }
    }

    public Collection getAllCitta() throws GestoreCittaException {
        Connection connection = null;
        PreparedStatement cittaStatement = null;
        final Vector cittaVector = new Vector();
        ResultSet cittaResultSet = null;
        try {
            connection = getConnection();
            cittaStatement = connection.prepareStatement("select CI_ID, CI_COMMUNE from  AN_MA_CITTA ORDER BY CI_COMMUNE");
            cittaResultSet = cittaStatement.executeQuery();
            CittaView cittaView = null;
            while (cittaResultSet.next()) {
                cittaView = new CittaView();
                cittaView.setCommune(cittaResultSet.getString("CI_COMMUNE"));
                cittaView.setCittaId(Long.valueOf(cittaResultSet.getLong("CI_ID")));
                cittaVector.add(cittaView);
            }
        } catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new GestoreCittaException(se.getMessage());
        } finally {
            cleanup(connection, cittaStatement, cittaResultSet);
        }
        return cittaVector;
    }

    public ICittaView getCitta( String commune, final String provinciaSigla ) throws GestoreCittaException {
        Connection connection = null;
        PreparedStatement preparedstatement = null;
        ResultSet resultset = null;
        try {
        	connection = getConnection();
            commune = new StringHandler().removeSpecifiedData(commune);
            //preparedstatement = connection.prepareStatement("select CI_COMMUNE, CI_ID, CI_REGION, CI_PROVINCIA,CI_CAPOLUOGO, CI_CAB, CI_CINCAB, CI_CAB_STORICO, CI_CNCF, CI_CAP, CI_STORICO, CI_ALTRADENOMINAZIONE from AN_MA_CITTA WHERE CI_NORMALIZZATO = ? and CI_PROVINCIA = ?");
            preparedstatement = connection.prepareStatement("select CI_COMMUNE, CI_ID, CI_REGION, CI_PROVINCIA,CI_CAPOLUOGO, CI_CAB, CI_CINCAB, CI_CAB_STORICO, CI_CNCF, CI_CAP, CI_STORICO, CI_ALTRADENOMINAZIONE from AN_MA_CITTA WHERE ( CI_NORMALIZZATO = ? or CI_LONG_NORMALIZZATO = ? ) and CI_PROVINCIA = ?");
            preparedstatement.setString(1, commune);
            preparedstatement.setString(2, commune);
            preparedstatement.setString(3, provinciaSigla);
            resultset = preparedstatement.executeQuery();
            return resultset.next() ? getCittaViewFromResultSet(resultset) : null;
            
        } catch (final SQLException sqlexception) {
            log4Debug.warnStackTrace(sqlexception);
            throw new GestoreCittaException(sqlexception.getMessage());
        } finally {
            cleanup(connection, preparedstatement, resultset);
        }
    }

    public boolean isValidCitta( String citta ) throws GestoreCittaException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet cittaResultSet = null;
        try {
            connection = getConnection();
            citta = new StringHandler().removeSpecifiedData(citta);
            //selectStatement = connection.prepareStatement("select CI_COMMUNE from AN_MA_CITTA where CI_STORICO = 0 and CI_NORMALIZZATO = ? ");
            selectStatement = connection.prepareStatement("select CI_COMMUNE from AN_MA_CITTA where CI_STORICO = 0 and (CI_NORMALIZZATO = ? or CI_LONG_NORMALIZZATO = ?)");
            selectStatement.setString(1, citta);
            selectStatement.setString(2, citta);
            cittaResultSet = selectStatement.executeQuery();
            return cittaResultSet.next();
        } catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new GestoreCittaException(se.getMessage());
        } finally {
            cleanup(connection, selectStatement, cittaResultSet);
        }
    }

    public boolean isValidAnagraficCitta( String citta ) {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet cittaResultSet = null;
        try {
            connection = getConnection();
            citta = new StringHandler().removeSpecifiedData(citta);
            //selectStatement = connection.prepareStatement("select CI_COMMUNE from AN_MA_CITTA where CI_NORMALIZZATO = ? ");
            selectStatement = connection.prepareStatement("select CI_COMMUNE from AN_MA_CITTA where (CI_NORMALIZZATO = ?  or CI_LONG_NORMALIZZATO = ?)");
            selectStatement.setString(1, citta);
            selectStatement.setString(2, citta);
            cittaResultSet = selectStatement.executeQuery();
            return cittaResultSet.next();
        } catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new EJBException(se);
        } finally {
            cleanup(connection, selectStatement, cittaResultSet);
        }
    }

    public boolean isValidCitta( String cittaName, final String provincia ) {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet cittaResultSet = null;
        boolean validCitta = false;
        try {
            connection = getConnection();
            cittaName = new StringHandler().removeSpecifiedData(cittaName);
            //selectStatement = connection.prepareStatement("select CI_STORICO from AN_MA_CITTA where CI_NORMALIZZATO = ? and CI_PROVINCIA = ?");
            selectStatement = connection.prepareStatement("select CI_STORICO from AN_MA_CITTA where ( CI_NORMALIZZATO = ? or CI_LONG_NORMALIZZATO = ? )and CI_PROVINCIA = ?");
            selectStatement.setString(1, cittaName);
            selectStatement.setString(2, cittaName);
            selectStatement.setString(3, provincia);
            cittaResultSet = selectStatement.executeQuery();
            while (cittaResultSet.next()) {
                if ("0".equals(cittaResultSet.getString("CI_STORICO"))) {
                    validCitta = true;
                    break;
                }
            }
        } catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new EJBException(se);
        } finally {
            cleanup(connection, selectStatement, cittaResultSet);
        }
        return validCitta;
    }

    public ICittaView getCitta( final String commune ) throws GestoreCittaException {
        Connection connection = null;
        PreparedStatement preparedstatement = null;
        ResultSet resultset = null;
        try {
            connection = getConnection();
            //preparedstatement = connection.prepareStatement("select CI_COMMUNE, CI_ID, CI_PROVINCIA, CI_REGION, CI_CAPOLUOGO, CI_CAB, CI_CINCAB, CI_CAB_STORICO, CI_CNCF, CI_CAP, CI_STORICO, CI_ALTRADENOMINAZIONE from  AN_MA_CITTA where CI_COMMUNE = ?");
            preparedstatement = connection.prepareStatement("select CI_COMMUNE, CI_ID, CI_PROVINCIA, CI_REGION, CI_CAPOLUOGO, CI_CAB, CI_CINCAB, CI_CAB_STORICO, CI_CNCF, CI_CAP, CI_STORICO, CI_ALTRADENOMINAZIONE from  AN_MA_CITTA where (CI_COMMUNE = ? or CI_LONG_COMMUNE = ?) and CI_STORICO = 0");
            preparedstatement.setString(1, commune);
            preparedstatement.setString(2, commune);
            resultset = preparedstatement.executeQuery();
            return resultset.next() ? getCittaViewFromResultSet(resultset) : null;
        } catch (final SQLException sqlexception) {
            log4Debug.warnStackTrace(sqlexception);
            throw new GestoreCittaException(sqlexception.getMessage());
        } finally {
            cleanup(connection, preparedstatement, resultset);
        }
    }

    public List<ICittaView> getCittaView( final String provincia ) throws GestoreCittaException, RemoteException {
        Connection connection = null;
        PreparedStatement preparedstatement = null;
        ResultSet resultset = null;
        final List<ICittaView> cittaList = new ArrayList<ICittaView>(1);
        final StringBuilder queryBuilder = new StringBuilder();
        try {
            connection = getConnection();
            queryBuilder.append("SELECT CI_ID, CI_COMMUNE, CI_PROVINCIA, CI_REGION, CI_CAPOLUOGO, CI_CAB, CI_CINCAB, CI_CAB_STORICO,");
            queryBuilder.append("CI_CNCF, CI_CAP, CI_STORICO, CI_ALTRADENOMINAZIONE, CI_NORMALIZZATO, CI_LONG_COMMUNE,CI_LONG_NORMALIZZATO");
            queryBuilder.append(" FROM AN_MA_CITTA WHERE CI_PROVINCIA = ?");
            preparedstatement = connection.prepareStatement(queryBuilder.toString());
            preparedstatement.setString(1, provincia);
            resultset = preparedstatement.executeQuery();
            while ( resultset.next() ) {
            	cittaList.add(getCittaViewFromResultSet(resultset));
            }
        } catch (final SQLException sqlexception) {
            log4Debug.warnStackTrace(sqlexception);
            throw new GestoreCittaException(sqlexception.getMessage());
        } finally {
            cleanup(connection, preparedstatement, resultset);
        }
        log4Debug.debug(" CittaDBAccessHelper : getCittaView( final String provincia ) : size:===>>>",String.valueOf(cittaList.size()));
    	return cittaList;
    }
    
    public Citta getAnagraficCitta( final String cittaName ) throws RemoteException {
        final String query = "SELECT  CI_ID, CI_COMMUNE, CI_CNCF, CI_CAB, CI_PROVINCIA, CI_REGION, CI_CAPOLUOGO, CI_CINCAB, CI_CAP, CI_STORICO, CI_ALTRADENOMINAZIONE,CI_NORMALIZZATO,CI_CAB_STORICO FROM AN_MA_CITTA WHERE (CI_NORMALIZZATO = ? OR CI_LONG_NORMALIZZATO = ?)";
        final String norCitta = new StringHandler().removeSpecifiedData(cittaName);
        final Collection cittaCollection = getCittaForInputQueryAndContition(query,norCitta,norCitta,null);
        return (cittaCollection != null && !cittaCollection.isEmpty()) ? 
        		(Citta)cittaCollection.iterator().next() : null;
    }

    public Collection getAnagraficValidCitta( final String cittaName ) throws RemoteException {
    	final String query = "SELECT CI_ID, CI_COMMUNE, CI_CNCF, CI_CAB, CI_PROVINCIA, CI_REGION, CI_CAPOLUOGO, CI_CINCAB, CI_CAP, CI_STORICO, CI_ALTRADENOMINAZIONE,CI_NORMALIZZATO,CI_CAB_STORICO FROM AN_MA_CITTA WHERE (CI_NORMALIZZATO = ? OR CI_LONG_NORMALIZZATO = ?)";
    	final String norCitta = new StringHandler().removeSpecifiedData(cittaName);
		return getCittaForInputQueryAndContition(query,norCitta,norCitta,null);
    }

    public Collection getCittaCollection( final String cittaName ) throws RemoteException {
        String query = null;
        String norCitta = null;
        if ( cittaName.endsWith("%") ) {
            query = "SELECT CI_ID, CI_COMMUNE, CI_CNCF, CI_CAB, CI_PROVINCIA, CI_REGION, CI_CAPOLUOGO, CI_CINCAB, CI_CAP, CI_STORICO, CI_ALTRADENOMINAZIONE,CI_NORMALIZZATO,CI_CAB_STORICO FROM AN_MA_CITTA WHERE (CI_NORMALIZZATO LIKE ? OR CI_LONG_NORMALIZZATO LIKE ? )";
            norCitta = new StringHandler().removeSpecifiedData(cittaName)+"%";
        } else {
            query = "SELECT CI_ID, CI_COMMUNE, CI_CNCF, CI_CAB, CI_PROVINCIA, CI_REGION, CI_CAPOLUOGO, CI_CINCAB, CI_CAP, CI_STORICO, CI_ALTRADENOMINAZIONE,CI_NORMALIZZATO,CI_CAB_STORICO FROM AN_MA_CITTA WHERE (CI_NORMALIZZATO = ? OR CI_LONG_NORMALIZZATO = ? )";
            norCitta = new StringHandler().removeSpecifiedData(cittaName);
        }
        return getCittaForInputQueryAndContition(query,norCitta,norCitta,null);
    }

    public Citta getCittaForCab( final String cab ) throws InformazioneManagerException, RemoteException {
    	final String query = "SELECT CI_ID, CI_COMMUNE, CI_CNCF, CI_CAB, CI_PROVINCIA, CI_REGION, CI_CAPOLUOGO, CI_CINCAB, CI_CAP, CI_STORICO, CI_ALTRADENOMINAZIONE,CI_NORMALIZZATO,CI_CAB_STORICO FROM AN_MA_CITTA WHERE CI_CAB = ?";
    	final Collection cittaCollection = getCittaForInputQueryAndContition(query,cab,null,null);
        return (cittaCollection != null && !cittaCollection.isEmpty()) ? 
        		(Citta)cittaCollection.iterator().next() : null;
    }

    
   public Citta getCittaOfGVBean( final String cittaName, final String province ) throws RemoteException {
	    final String query = "SELECT  CI_ID, CI_COMMUNE, CI_PROVINCIA, CI_CAB, CI_CNCF, CI_REGION, CI_CAPOLUOGO, CI_CINCAB, CI_CAP, CI_STORICO, CI_ALTRADENOMINAZIONE,CI_NORMALIZZATO,CI_CAB_STORICO  FROM AN_MA_CITTA WHERE (CI_NORMALIZZATO = ? OR CI_LONG_NORMALIZZATO = ? ) AND CI_PROVINCIA = ?";
	    final String norCitta = new StringHandler().removeSpecifiedData(cittaName);
	    final Collection cittaCollection = getCittaForInputQueryAndContition(query,norCitta,norCitta,province);
        return (cittaCollection != null && !cittaCollection.isEmpty()) ? 
        		(Citta)cittaCollection.iterator().next() : null;
    }
 
    public Citta getCittaOfGVBean( final String cittaName ) throws RemoteException {
    	final String query = "SELECT  CI_ID, CI_COMMUNE, CI_PROVINCIA, CI_CAB, CI_CNCF, CI_REGION, CI_CAPOLUOGO, CI_CINCAB, CI_CAP, CI_STORICO, CI_ALTRADENOMINAZIONE,CI_NORMALIZZATO,CI_CAB_STORICO  FROM AN_MA_CITTA WHERE CI_STORICO = 0  AND (CI_NORMALIZZATO = ? OR CI_LONG_NORMALIZZATO = ? )";
    	final String norCitta = new StringHandler().removeSpecifiedData(cittaName);
    	final Collection cittaCollection = getCittaForInputQueryAndContition(query,norCitta,norCitta,null); 
        return (cittaCollection != null && !cittaCollection.isEmpty()) ? 
        		(Citta)cittaCollection.iterator().next() : null;
    }

    public Citta getCittaOfGVBean( final Long cittaId ) throws RemoteException {
    	final String query = "SELECT CI_ID, CI_COMMUNE, CI_CNCF, CI_CAB, CI_PROVINCIA, CI_REGION, CI_CAPOLUOGO, CI_CINCAB, CI_CAP, CI_STORICO, CI_ALTRADENOMINAZIONE,CI_NORMALIZZATO,CI_CAB_STORICO FROM AN_MA_CITTA WHERE CI_ID = ?";
    	final Collection cittaCollection = getCittaForInputQueryAndContition(query,cittaId,null,null);
        return (cittaCollection != null && !cittaCollection.isEmpty()) ? 
        		(Citta)cittaCollection.iterator().next() : null;
    }

    private Collection getCittaForInputQueryAndContition( final String query, final Object whereConditionOne,
    		final String whereConditionTwo, final String whereConditionThree ) throws RemoteException {
        Connection connection = null;
        PreparedStatement cittaStatement = null;
        ResultSet cittaResultSet = null;
        PreparedStatement provinciaStatement = null;
        ResultSet provinceResultSet = null;
        final ArrayList cittaCollection = new ArrayList();
        try {
            connection = getConnection();
            cittaStatement = connection.prepareStatement(query);
            provinciaStatement = connection.prepareStatement("select PR_ID, PR_SIGLA, PR_NOME, PR_CODICE_AREA, PR_CODICE_CAB, PR_CODICE_PUMA2 from AN_MA_PROVINCE where PR_SIGLA = ? ");
            int counter = 0;
            if(whereConditionOne instanceof String) {
				cittaStatement.setString(++counter,whereConditionOne.toString());
			} else {
				cittaStatement.setLong(++counter,((Long)whereConditionOne).longValue());
			}
            if(whereConditionTwo != null) {
				cittaStatement.setString(++counter,whereConditionTwo);
			}
            if(whereConditionThree != null) {
				cittaStatement.setString(++counter,whereConditionThree);
			}
            cittaResultSet = cittaStatement.executeQuery();
            while(cittaResultSet.next()) {
                final Citta citta = new Citta();
                citta.setCabStorico(cittaResultSet.getString("CI_CAB_STORICO"));
                citta.setNormalizzato(cittaResultSet.getString("CI_NORMALIZZATO"));
                citta.setCittaId(Long.valueOf(cittaResultSet.getLong("CI_ID")));
                citta.setCommune(cittaResultSet.getString("CI_COMMUNE"));
                provinciaStatement.setString(1, cittaResultSet.getString("CI_PROVINCIA"));
                provinceResultSet = provinciaStatement.executeQuery();
                if(provinceResultSet.next()) {
                    final Provincia provincia = new Provincia();
                    provincia.setCodiceArea(provinceResultSet.getString("PR_CODICE_AREA"));
                    provincia.setCodiceCab(provinceResultSet.getString("PR_CODICE_CAB"));
                    provincia.setCodicePuma2(provinceResultSet.getString("PR_CODICE_PUMA2"));
                    provincia.setNome(provinceResultSet.getString("PR_NOME"));
                    provincia.setProvinciaId(Long.valueOf(provinceResultSet.getLong("PR_ID")));
                    provincia.setSigla(provinceResultSet.getString("PR_SIGLA"));
                    citta.setProvincia(provincia);
                }
                closeResultSet(provinceResultSet);
                provinciaStatement.clearParameters();
                citta.setCncf(cittaResultSet.getString("CI_CNCF"));
                citta.setCab(cittaResultSet.getString("CI_CAB"));
                citta.setRegion(cittaResultSet.getString("CI_REGION"));
                citta.setCinCab(cittaResultSet.getString("CI_CINCAB"));
                citta.setCap(cittaResultSet.getString("CI_CAP"));
                citta.setAltraDenominazione(cittaResultSet.getString("CI_ALTRADENOMINAZIONE"));
                if(cittaResultSet.getString("CI_CAPOLUOGO") != null) {
                	citta.setCapoluogo(getViewFromValue("CPL", String.valueOf(cittaResultSet.getLong("CI_CAPOLUOGO"))));
                }
                if(cittaResultSet.getString("CI_STORICO") != null) {
                	citta.setStorico(getViewFromValue("CST", String.valueOf(cittaResultSet.getLong("CI_STORICO"))));
                }
                cittaCollection.add(citta);
            }
        } catch(final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new EJBException(e);
        } catch(final SubSystemHandlerException e) {
            log4Debug.warnStackTrace(e);
            throw new EJBException(e);
        } finally {
            closeResultSet(provinceResultSet);
            closeStatement(provinciaStatement);
            cleanup(connection,cittaStatement,cittaResultSet);
        }
        return cittaCollection;
    }


    private ICittaView getCittaViewFromResultSet( final ResultSet resultset ) throws SQLException {
    	final CittaView cittaview = new CittaView();
        cittaview.setCommune(resultset.getString("CI_COMMUNE"));
        cittaview.setCittaId(Long.valueOf(resultset.getLong("CI_ID")));
        cittaview.setProvincia(resultset.getString("CI_PROVINCIA"));
        cittaview.setRegion(resultset.getString("CI_REGION"));
        cittaview.setCapoluogo(Long.valueOf(resultset.getLong("CI_CAPOLUOGO")));
        cittaview.setCab(resultset.getString("CI_CAB"));
        cittaview.setCincab(resultset.getString("CI_CINCAB"));
        cittaview.setCabStorico(resultset.getString("CI_CAB_STORICO"));
        cittaview.setCncf(resultset.getString("CI_CNCF"));
        cittaview.setCap(resultset.getString("CI_CAP"));
        cittaview.setStorico((Long.valueOf(resultset.getLong("CI_STORICO"))).toString());
        cittaview.setAltraDenominazione(resultset.getString("CI_ALTRADENOMINAZIONE"));
        return cittaview;
    }

    private ClassificazioneView getViewFromValue( final String parentCausale, final String value ) throws RemoteException, SubSystemHandlerException {
        return value != null ? ClassificazioneHandler.getClassificazioneViewForChildByParentCausale(parentCausale, value) : null;
    }
    
    /**
     * @param citta
     * @return
     * @throws GestoreCittaException
     */
    public boolean isCittaExists(final String citta) throws GestoreCittaException {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        
        try {
            connection = getConnection();
            final String cittaTemp = new StringHandler().removeSpecifiedData(citta);
            statement = connection.prepareStatement("SELECT CI_COMMUNE FROM AN_MA_CITTA WHERE (CI_NORMALIZZATO = ? OR CI_LONG_NORMALIZZATO = ?)");
            statement.setString(1, cittaTemp);
            statement.setString(2, cittaTemp);
            resultSet = statement.executeQuery();
            return resultSet.next();
        } catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreCittaException(e.getMessage());
        } finally {
            cleanup(connection, statement, resultSet);
        }
    }
    
    /**
     * @param cittaName
     * @param provincia
     * @return
     * @throws GestoreCittaException 
     */
    public boolean isCittaWithProvinciaExist(final String cittaName, final String provincia ) throws GestoreCittaException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet resultSet = null;
        boolean cittaWithProvinciaExist = false;
        try {
            connection = getConnection();
            final String cittaTemp = new StringHandler().removeSpecifiedData(cittaName);
            selectStatement = connection.prepareStatement("SELECT CI_STORICO FROM AN_MA_CITTA WHERE ( CI_NORMALIZZATO = ? or CI_LONG_NORMALIZZATO = ? )and CI_PROVINCIA = ?");
            selectStatement.setString(1, cittaTemp);
            selectStatement.setString(2, cittaTemp);
            selectStatement.setString(3, provincia);
            resultSet = selectStatement.executeQuery();
            while (resultSet.next()) {
                cittaWithProvinciaExist = true;
                break;
            }
        } catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreCittaException(e.getMessage());
        } finally {
            cleanup(connection, selectStatement, resultSet);
        }
        return cittaWithProvinciaExist;
    }
    
    
}
