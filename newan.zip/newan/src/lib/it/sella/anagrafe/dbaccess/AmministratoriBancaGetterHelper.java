package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.UpdateAMMBALinkView;
import it.sella.anagrafe.UpdateAMMBAScanView;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.anagrafe.util.StringHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.IOException;
import java.io.InputStream;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AmministratoriBancaGetterHelper extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AmministratoriBancaGetterHelper.class);
    
    public List getExtractArt136() throws OperazioneAnagrafeManagerException, RemoteException {
        Connection connection = null;
        PreparedStatement progressStatement = null;
        ResultSet ammbaResultSet = null;
        final List updatAmmbaList = new ArrayList(1);
    	try {
            connection = getConnection();
    		progressStatement = connection.prepareStatement("SELECT ART_ID, ART_CF, ART_INTESTAZIONE, ART_EXCEEDING_INTESTAZIONE, ART_OP_ID,ART_ABI_CODE FROM AN_MA_EXART_136");
    		ammbaResultSet = progressStatement.executeQuery();
    		while ( ammbaResultSet.next()) {
    			updatAmmbaList.add(getUpdateAMMBALinkViewInResultSet(ammbaResultSet));
    		}
    	} catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new OperazioneAnagrafeManagerException(se.getMessage());
        } finally {
            cleanup(connection, progressStatement, ammbaResultSet);
        }
    	return updatAmmbaList;
    }
    
    public List getAllExtendArt136Scan() throws OperazioneAnagrafeManagerException, RemoteException {
        Connection connection = null;
        PreparedStatement progressStatement = null;
        ResultSet ammbaResultSet = null;
        final List updatAmmbaScanList = new ArrayList(1);
        final StringBuffer query = new StringBuffer();
    	try {
    		query.append(" SELECT ART_SC_ID, ART_SC_SOGGETTO_ID, ART_SC_RE_AMMBA_SOGGETO_ID, ART_SC_SOGGETTO_PRINCIPALE_ID, ART_SC_MOTIVO, ART_SC_ALIGN_HOST, ");
    		query.append(" ART_SC_CODICEHOST, ART_SC_MAPPER_MSG, ART_SC_COL_DATA_FINE, ART_SC_HOST_DATA_FINE, ART_SC_HOST_STATUS, ART_SC_OP_ID  FROM AN_TMP_ART136_EXTENDED_SCAN ");
    		query.append(" WHERE ART_SC_ALIGN_HOST ='REQUIRED' AND ART_SC_ERR_MSG IS NULL AND ART_SC_CODICEHOST IS NOT NULL AND ART_SC_SOGGETTO_PRINCIPALE_ID = ? ");
    		query.append(" AND ART_SC_HOST_STATUS IS NULL OR ART_SC_HOST_STATUS = 'KO' ");
    		log4Debug.debug(" AmministratoriBancaGetterHelper : getAllExtendArt136Scan : query :==>>>",query);
            connection = getConnection();
    		progressStatement = connection.prepareStatement(query.toString());
    		progressStatement.setLong(1,SecurityHandler.getLoginBancaId().longValue());
    		ammbaResultSet = progressStatement.executeQuery();
    		while ( ammbaResultSet.next()) {
    			updatAmmbaScanList.add(getUpdateAMMBAScanViewInResultSet(ammbaResultSet));
    		}
    	} catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new OperazioneAnagrafeManagerException(se.getMessage());
        } catch (final SubSystemHandlerException se) {
            log4Debug.warnStackTrace(se);
            throw new OperazioneAnagrafeManagerException(se.getMessage());
        } catch (final IOException se) {
            log4Debug.warnStackTrace(se);
            throw new OperazioneAnagrafeManagerException(se.getMessage());
        } finally {
            cleanup(connection, progressStatement, ammbaResultSet);
        }
    	return updatAmmbaScanList;
    }
    
    private UpdateAMMBALinkView getUpdateAMMBALinkViewInResultSet( final ResultSet ammbaResultSet ) throws SQLException  {
    	final UpdateAMMBALinkView updateAMMBALinkView = new UpdateAMMBALinkView();
    	updateAMMBALinkView.setId(Long.valueOf(ammbaResultSet.getLong("ART_ID")));
    	updateAMMBALinkView.setDatiFiscali(ammbaResultSet.getString("ART_CF"));
    	updateAMMBALinkView.setExceedingIntestazione(ammbaResultSet.getString("ART_EXCEEDING_INTESTAZIONE"));
    	updateAMMBALinkView.setIntestazione(ammbaResultSet.getString("ART_INTESTAZIONE"));
   		updateAMMBALinkView.setOpId(StringHandler.getLongValue(ammbaResultSet.getString("ART_OP_ID")));	
   		updateAMMBALinkView.setAbiCode(ammbaResultSet.getString("ART_ABI_CODE"));
   		
    	return updateAMMBALinkView;
    }

    private UpdateAMMBAScanView getUpdateAMMBAScanViewInResultSet( final ResultSet ammbaResultSet ) throws SQLException, IOException  {
    	final UpdateAMMBAScanView updateAMMBAScanView = new UpdateAMMBAScanView();
    	updateAMMBAScanView.setId(Long.valueOf(ammbaResultSet.getLong("ART_SC_ID")));
   		updateAMMBAScanView.setSoggettoId(StringHandler.getLongValue(ammbaResultSet.getString("ART_SC_SOGGETTO_ID")));	
   		updateAMMBAScanView.setReSoggettoId(StringHandler.getLongValue(ammbaResultSet.getString("ART_SC_RE_AMMBA_SOGGETO_ID")));	
    	updateAMMBAScanView.setSoggettoPrincipaleId(Long.valueOf(ammbaResultSet.getLong("ART_SC_SOGGETTO_PRINCIPALE_ID")));
    	updateAMMBAScanView.setMotivoCausale(ammbaResultSet.getString("ART_SC_MOTIVO"));
    	updateAMMBAScanView.setAlignHost(ammbaResultSet.getString("ART_SC_ALIGN_HOST"));
    	updateAMMBAScanView.setCodiceHost(ammbaResultSet.getString("ART_SC_CODICEHOST"));
    	final InputStream mapperStream = ammbaResultSet.getAsciiStream("ART_SC_MAPPER_MSG");
    	updateAMMBAScanView.setMapperMessage( mapperStream != null ? getStringfromStream(mapperStream) : "");
    	updateAMMBAScanView.setCollgegamentoDataFine(ammbaResultSet.getTimestamp("ART_SC_COL_DATA_FINE"));
    	updateAMMBAScanView.setHostDataFine(ammbaResultSet.getTimestamp("ART_SC_HOST_DATA_FINE"));
    	updateAMMBAScanView.setHostStatus(ammbaResultSet.getString("ART_SC_HOST_STATUS"));
   		updateAMMBAScanView.setOpId(StringHandler.getLongValue(ammbaResultSet.getString("ART_SC_OP_ID")));	
    	return updateAMMBAScanView;
    }
}
