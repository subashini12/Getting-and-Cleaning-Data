package it.sella.anagrafe.dbaccess;

import it.sella.address.AddressView;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreDatiFiscaliException;
import it.sella.anagrafe.implementation.DAPFView;
import it.sella.anagrafe.util.AddressHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Iterator;

public class CalculatedUSPersonPFHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CalculatedUSPersonPFHelper.class);
 // This method not using we modified new logic for US handling.
    protected Boolean isPF_USorigin(final Long soggettoId) throws GestoreDatiFiscaliException, RemoteException {
        try {
        	final DatiFiscaliDBAccessHelper dfHelper = new DatiFiscaliDBAccessHelper();
            if ("true".equals(dfHelper.getDatiFiscali(soggettoId, "w8")) || "true".equals(dfHelper.getDatiFiscali(soggettoId, "w8i")) || "true".equals(dfHelper.getDatiFiscali(soggettoId, "w9"))) {
				return Boolean.TRUE;
			}
            if ("STATI UNITI".equals(((DAPFView) new DatiAnagraficiGetterHelper().getAnagraficiView(soggettoId)).getLuogoDiNascitaNazione())) {
				return Boolean.TRUE;
			}
            final Collection indirizzo = new AddressHandler().listAddress(soggettoId, "ANAG");
            if (indirizzo != null && !indirizzo.isEmpty()) {
                final Iterator iterator = indirizzo.iterator();
                AddressView addressView = null;
                for (int i = indirizzo.size(); i > 0; i--) {
                    addressView = (AddressView) iterator.next();
                    if (("IRE".equals(addressView.getCausaleTipoIndirizzo()) || "IDO".equals(addressView.getCausaleTipoIndirizzo())) && "STATI UNITI".equals(addressView.getNazione())) {
                    	return Boolean.TRUE;
                    }
                }
            }
            final AttributiEsterniDBAccessHelper aeHelper = new AttributiEsterniDBAccessHelper();
            final NazioneDBAccessHelper nazioneHelper = new NazioneDBAccessHelper();
            String nazioneId = aeHelper.getAttribuiEsterniValore(soggettoId, "cittadinanza");
            if(nazioneId != null && "STATI UNITI".equals(nazioneHelper.getNazione(Long.valueOf(nazioneId)).getNome())) {
				return Boolean.TRUE;
			}
            nazioneId = aeHelper.getAttribuiEsterniValore(soggettoId, "secondaCittadinanza");
            if(nazioneId != null && "STATI UNITI".equals(nazioneHelper.getNazione(Long.valueOf(nazioneId)).getNome())) {
				return Boolean.TRUE;
			}
            nazioneId = dfHelper.getDatiFiscali(soggettoId, "rzVal");
            if (nazioneId != null && "STATI UNITI".equals(nazioneHelper.getNazione(Long.valueOf(nazioneId)).getNome())) {
				return Boolean.TRUE;
			}
            nazioneId = dfHelper.getDatiFiscali(soggettoId, "residenteItalia");
            if (nazioneId != null && "STATI UNITI".equals(nazioneHelper.getNazione(Long.valueOf(nazioneId)).getNome())) {
				return Boolean.TRUE;
			}
        } catch (final GestoreAnagrafeException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreDatiFiscaliException(e.getMessage());
        } catch (final NumberFormatException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreDatiFiscaliException(e.getMessage());
        } 
        return Boolean.FALSE;
    }
}
