package it.sella.anagrafe.dbaccess;

import it.sella.address.AddressView;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreDatiFiscaliException;
import it.sella.anagrafe.util.AddressHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Iterator;

public class CalculatedUSPersonAZHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CalculatedUSPersonAZHelper.class);
    
//    Method is not used any where.
    protected Boolean isAziendaUSOrigin(final Long soggettoId) throws GestoreDatiFiscaliException, RemoteException {
        try {
        	final DatiFiscaliDBAccessHelper dfHelper = new DatiFiscaliDBAccessHelper();
            if ("true".equals(dfHelper.getDatiFiscali(soggettoId, "w8")) || "true".equals(dfHelper.getDatiFiscali(soggettoId, "w8i")) || "true".equals(dfHelper.getDatiFiscali(soggettoId, "w9"))) {
				return Boolean.TRUE;
			}
            final Collection indirizzo = new AddressHandler().listAddress(soggettoId, "ANAG");
            if (indirizzo != null && !indirizzo.isEmpty()) {
                final Iterator iterator = indirizzo.iterator();
                AddressView addressView = null;
                for (int i = indirizzo.size(); i > 0; i--) {
                    addressView = (AddressView) iterator.next();
                    if (("SLE".equals(addressView.getCausaleTipoIndirizzo()) || "SAM".equals(addressView.getCausaleTipoIndirizzo())) && "STATI UNITI".equals(addressView.getNazione())) {
                    	return Boolean.TRUE;
                    }
                }
            }
            final NazioneDBAccessHelper nazioneHelper = new NazioneDBAccessHelper();
            String nazioneId = dfHelper.getDatiFiscali(soggettoId, "rzVal");
            if (nazioneId != null && "STATI UNITI".equals(nazioneHelper.getNazione(Long.valueOf(nazioneId)).getNome())) {
				return Boolean.TRUE;
			}
            nazioneId = dfHelper.getDatiFiscali(soggettoId, "residenteItalia");
            if (nazioneId != null && "STATI UNITI".equals(nazioneHelper.getNazione(Long.valueOf(nazioneId)).getNome())) {
				return Boolean.TRUE;
			}
            final Collection abilitatiIds = new CollegamentoDBAccessHelper().getSoggettiCollegatiAbilitati(soggettoId);
            if (abilitatiIds != null && !abilitatiIds.isEmpty()) {
            	final CalculatedUSPersonPFHelper pfHelper = new CalculatedUSPersonPFHelper();
                final Iterator iterator = abilitatiIds.iterator();
                for (int i = abilitatiIds.size(); i > 0; i--) {
                    final Long abilitatiId = (Long) iterator.next();
                    if (pfHelper.isPF_USorigin(abilitatiId).booleanValue()) {
						return Boolean.TRUE;
					}
                }
            }
        } catch (final GestoreAnagrafeException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreDatiFiscaliException(e.getMessage());
        } catch (final NumberFormatException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreDatiFiscaliException(e.getMessage());
        } 
        return Boolean.FALSE;
    }

}
