package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.common.Citta;
import it.sella.anagrafe.common.Nazione;
import it.sella.anagrafe.discriminator.DatiAnagraficiDiscriminatorException;
import it.sella.anagrafe.implementation.IView;
import it.sella.anagrafe.pf.DatiAnagraficiPFView;
import it.sella.anagrafe.tipodatianagrafici.ITipoDatiAnagraficiBeanManager;
import it.sella.anagrafe.tipodatianagrafici.TipoDatiAnagrafici;
import it.sella.anagrafe.tipodatianagrafici.TipoDatiAnagraficiView;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.HelperException;
import it.sella.anagrafe.util.ReflectionUtil;
import it.sella.anagrafe.util.StringHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Timestamp;

import javax.ejb.FinderException;

public class DatiAnagraficiPFUpdateHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DatiAnagraficiPFUpdateHelper.class);

    public void createDatiAnagraficiPF(final Long soggettoId, final IView iView) throws DatiAnagraficiDiscriminatorException, RemoteException {
        try {
            final TipoDatiAnagraficiView datiView = new TipoDatiAnagraficiView();
            final DatiAnagraficiPFView datiAnagraficiView = (DatiAnagraficiPFView) iView;
            datiView.setSoggettoId(soggettoId);
            datiView.setCognome(datiAnagraficiView.getCognome());
            datiView.setNome(datiAnagraficiView.getNome());
            final Citta cityOfBirth = datiAnagraficiView.getLuogoDiNascitaCitta();
            if (cityOfBirth != null) {
                datiView.setCittaOfBirth(cityOfBirth.getCittaId() != null ? cityOfBirth.getCittaId().toString() : cityOfBirth.getCommune());
            }
            final Nazione nazione = datiAnagraficiView.getLuogoDiNascitaNazione();
            if (nazione != null) {
                datiView.setNazioneOfBirth(nazione.getNazioneId().toString());
            }
            datiView.setNormalisedNome(datiAnagraficiView.getNormalisedNome());
            if (datiAnagraficiView.getDataDiNascita() != null) {
            	final DateHandler dateHandler = new DateHandler();
                final String dateFormat = dateHandler.formatDate(datiAnagraficiView.getDataDiNascita(), "yyyyMMdd");
                datiView.setDateOfBirth(dateHandler.getTimestampFromDateString(dateFormat, "yyyyMMdd"));
            }
            datiView.setOpId(datiAnagraficiView.getOpId());
            ((ITipoDatiAnagraficiBeanManager) getTipoDatiAnagraficiManager()).create(datiView);
        } catch (final GestoreAnagrafeException ce) {
            log4Debug.severeStackTrace(ce);
            throw new DatiAnagraficiDiscriminatorException(ce.getLocalizedMessage());
        } catch (final HelperException he) {
            log4Debug.severeStackTrace(he);
            throw new DatiAnagraficiDiscriminatorException(he.getLocalizedMessage());
        }
    }

    public void setDatiAnagraficiPF(final Long soggettoId, final IView iView) throws DatiAnagraficiDiscriminatorException, RemoteException {
        try {
            final ITipoDatiAnagraficiBeanManager tipoDatiAnagraficiBeanManager = (ITipoDatiAnagraficiBeanManager) getTipoDatiAnagraficiManager();
			final TipoDatiAnagrafici datiAnagrafici = tipoDatiAnagraficiBeanManager.findBySoggettoId(soggettoId);
            final DatiAnagraficiPFView datiAnagraficiView = (DatiAnagraficiPFView) iView;
            final Citta luogoDiNascitaCitta = datiAnagraficiView.getLuogoDiNascitaCitta();
            final String citta = luogoDiNascitaCitta != null ? luogoDiNascitaCitta.getCittaId() != null ?
            		luogoDiNascitaCitta.getCittaId().toString() : luogoDiNascitaCitta.getCommune() : null;
            final StringHandler stringHandler = new StringHandler();
            final DateHandler dateHandler = new DateHandler();
            final Nazione nazioneObj = datiAnagraficiView.getLuogoDiNascitaNazione();
            final String nazione = nazioneObj != null ?
            		nazioneObj.getNazioneId() != null ? nazioneObj.getNazioneId().toString() : nazioneObj.getNome() :
            			null;
            if(!stringHandler.checkForEquality(citta,datiAnagrafici.getCittaOfBirth()) ||
            		!stringHandler.checkForEquality(datiAnagraficiView.getCognome(), datiAnagrafici.getCognome()) ||
            		!stringHandler.checkForEquality(dateHandler.formatDate(datiAnagraficiView.getDataDiNascita(),"dd-MM-yyyy"), dateHandler.formatDate(datiAnagrafici.getDateOfBirth(),"dd-MM-yyyy")) ||
            		!stringHandler.checkForEquality(nazione, datiAnagrafici.getNazioneOfBirth()) ||
            		!stringHandler.checkForEquality(datiAnagraficiView.getNome(), datiAnagrafici.getNome()) ||
            		!stringHandler.checkForEquality(datiAnagraficiView.getNormalisedNome(), datiAnagrafici.getNormalisedNome())) {
	            if (luogoDiNascitaCitta != null) {
	                datiAnagrafici.setCittaOfBirth(luogoDiNascitaCitta.getCittaId() != null ? luogoDiNascitaCitta.getCittaId().toString() : luogoDiNascitaCitta.getCommune());
	            }
	            datiAnagrafici.setCognome(datiAnagraficiView.getCognome());
	            final Timestamp dataDiNascita = datiAnagraficiView.getDataDiNascita();
	            if (dataDiNascita != null) {
	                final String dateFormat = dateHandler.formatDate(dataDiNascita, "yyyyMMdd");
	                datiAnagrafici.setDateOfBirth(dateHandler.getTimestampFromDateString(dateFormat, "yyyyMMdd"));
	            }
	            if (nazioneObj != null && nazioneObj.getNazioneId() != null) {
	                datiAnagrafici.setNazioneOfBirth(nazioneObj.getNazioneId().toString());
	            }
	            datiAnagrafici.setNome(datiAnagraficiView.getNome());
	            datiAnagrafici.setNormalisedNome(datiAnagraficiView.getNormalisedNome());
	            datiAnagrafici.setOpId(iView.getOpId());
	            tipoDatiAnagraficiBeanManager.update(datiAnagrafici);
            }
        } catch (final FinderException e) {
            log4Debug.severeStackTrace(e);
            throw new DatiAnagraficiDiscriminatorException(e.getLocalizedMessage());
        } catch (final GestoreAnagrafeException ne) {
            log4Debug.severeStackTrace(ne);
            throw new DatiAnagraficiDiscriminatorException(ne.getLocalizedMessage());
        } catch (final HelperException me) {
            log4Debug.severeStackTrace(me);
            throw new DatiAnagraficiDiscriminatorException(me.getLocalizedMessage());
        }
    }

	private Object getTipoDatiAnagraficiManager()
			throws GestoreAnagrafeException {
		return ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.TipoDatiAnagrafici");
	}
}
