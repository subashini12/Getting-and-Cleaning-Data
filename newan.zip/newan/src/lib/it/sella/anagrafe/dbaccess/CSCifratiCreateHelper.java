package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.OperazioneCensimentoException;
import it.sella.anagrafe.discriminator.CodiceSoggettoDiscriminatorException;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.AnagrafeLoggerHelper;
import it.sella.logserver.LoggerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CSCifratiCreateHelper extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CSCifratiCreateHelper.class);

    protected void createCodiciSoggettoCifrati(final Long soggettoId, final String valoreCodiceHost, Long opId) throws CodiceSoggettoDiscriminatorException, RemoteException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        final AnagrafeHelper helper = new AnagrafeHelper();
    	final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
    	String errorMessage = null;
        try {
            if (soggettoId == null || valoreCodiceHost == null) {
				throw new CodiceSoggettoDiscriminatorException(helper.getMessage("ANAG-1298"));
			}
            if(opId == null) {
				opId = anagrafeLoggerHelper.logAnagrafeOperation(null,false,"ANAG-API-CSCIF-CREAT",soggettoId,null);
			}
            connection = getConnection();
            preparedStatement = connection.prepareStatement("SELECT 1 FROM AN_TR_CODICISOGGETTO_CIFRATI WHERE CS_SOGGETTO_ID = ? ");
            preparedStatement.setLong(1,soggettoId.longValue());
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()){
                throw new CodiceSoggettoDiscriminatorException(helper.getMessage("ANAG-1299"));
            }
            closeResultSet(resultSet);
            closeStatement(preparedStatement);
            preparedStatement = connection.prepareStatement("INSERT INTO AN_TR_CODICISOGGETTO_CIFRATI(CS_CODICIFISCALI_ID,CS_SOGGETTO_ID,CS_VALUE,CS_RIGHT_PK,CS_OP_ID) VALUES (AN_SQ_CODICISOGGETTO_CIFRATI.NEXTVAL,?,?,?,?) ");
            preparedStatement.setLong(1, soggettoId.longValue());
            preparedStatement.setString(2, valoreCodiceHost);
            preparedStatement.setLong(3, getClassificazioneIdFromCausale("codiceHost", "CSDPF").longValue());
            preparedStatement.setLong(4, opId.longValue());
            preparedStatement.executeUpdate();
            anagrafeLoggerHelper.logAnagrafeOpDetails(opId,"","");
        } catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            errorMessage = e.getMessage();
            throw new CodiceSoggettoDiscriminatorException(errorMessage);
        } catch (final LoggerException e) {
            log4Debug.warnStackTrace(e);
            errorMessage = e.getMessage();
            throw new CodiceSoggettoDiscriminatorException(errorMessage);
        } catch (final GestoreAnagrafeException e) {
            log4Debug.warnStackTrace(e);
            errorMessage = e.getMessage();
            throw new CodiceSoggettoDiscriminatorException(errorMessage);
        } finally {
        	try {
        		cleanup(connection,preparedStatement,resultSet);
				anagrafeLoggerHelper.updateAnagrafeLog(opId,soggettoId,errorMessage);
			} catch (final OperazioneCensimentoException e) {
	            log4Debug.warnStackTrace(e);
			}
        }
    }
}


