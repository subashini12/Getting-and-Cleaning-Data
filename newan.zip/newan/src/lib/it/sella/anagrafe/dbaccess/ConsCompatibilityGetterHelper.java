package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.util.UtilHelper;
import it.sella.anagrafe.view.ConsCompatibilityView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ConsCompatibilityGetterHelper extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(ConsCompatibilityGetterHelper.class);

    public List<ConsCompatibilityView> getConsCompatibility( final String settore ) throws GestoreAnagrafeException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        final List<ConsCompatibilityView> consCompList = new ArrayList<ConsCompatibilityView>(1);
        try {
            final StringBuilder queryBuilder = new StringBuilder("SELECT CC.CO_ID, CC.CO_SETTORE, CC.CO_FATTURATO, ");
            	queryBuilder.append("CC.CO_NUMERO_DIPENDENTI, CC.CO_BILANCIO, CC.CO_CONSUMATORE, CC.CO_CLIENTE_AL_DETTAGLIO");
             	queryBuilder.append(" FROM AN_MA_CON_CLD_COMPATIBILITY CC WHERE CC.CO_SETTORE LIKE ?");
            connection = getConnection();
            preparedStatement = connection.prepareStatement(queryBuilder.toString());
            log4Debug.debug(" ConsCompatibilityGetterHelper: getConsCompatibility: queryBuilder:===>>",queryBuilder);
            preparedStatement.setString(1, settore+"%");
            resultSet = preparedStatement.executeQuery();
            ConsCompatibilityView consView = null;
            while ( resultSet.next() ) {
            	consView = new ConsCompatibilityView();
            	consView.setId(resultSet.getLong("CO_ID"));
            	consView.setSettore(resultSet.getString("CO_SETTORE"));
            	consView.setFatturato(UtilHelper.getBigDecimalValue(resultSet.getString("CO_FATTURATO")));
            	consView.setNumeroDipendenti(UtilHelper.getLongValue(resultSet.getString("CO_NUMERO_DIPENDENTI")));
            	consView.setBilancio(UtilHelper.getBigDecimalValue(resultSet.getString("CO_BILANCIO")));
            	consView.setConsumatore(UtilHelper.getLongValue(resultSet.getString("CO_CONSUMATORE")));
            	consView.setClienteAlDettaglio(UtilHelper.getLongValue(resultSet.getString("CO_CLIENTE_AL_DETTAGLIO")));
            	consCompList.add(consView);
            }
        } catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreAnagrafeException(e.getMessage());
        } finally {
            cleanup(connection, preparedStatement, resultSet);
        }
        return consCompList;
    }

}
