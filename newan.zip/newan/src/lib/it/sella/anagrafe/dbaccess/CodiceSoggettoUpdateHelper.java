package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.codicisoggetto.CodiciSoggetto;
import it.sella.anagrafe.codicisoggetto.ICodiciSoggettoBeanManager;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.discriminator.CodiceSoggettoDiscriminatorException;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.implementation.IView;
import it.sella.anagrafe.util.ReflectionUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Iterator;

import javax.ejb.FinderException;

public class CodiceSoggettoUpdateHelper extends CSCifratiUpdateHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CodiceSoggettoUpdateHelper.class);

    public void setCodiciSoggetto(final Long soggettoId, final IView iView) throws CodiceSoggettoDiscriminatorException, RemoteException {
        try {
            Object object = null;
            final ICodiciSoggettoBeanManager manager = ((ICodiciSoggettoBeanManager) getCodiceSoggettoManager());
            final Collection codiciSoggettoColn = manager.findBySoggettoId(soggettoId);
            final Iterator iterator = codiciSoggettoColn.iterator();
            final Collection causaleColn = iView.getCausaleListFromViewProperties();
            String causale =null;
            CodiciSoggetto codiciSoggetto = null;
            final StoricDataUpdateHelper storicDataUpdateHelper = new StoricDataUpdateHelper();
            for (int i = 0; i < codiciSoggettoColn.size(); i++) {
                codiciSoggetto = (CodiciSoggetto) iterator.next();
                causale= ClassificazioneHandler.getClassificazioneView(codiciSoggetto.getRightPk()).getCausale();
                if (causaleColn.contains(causale)){
                    object = iView.getValueForThisProperty(causale);
                    if (object != null) {
                    	final String value = ("codiceHost".equals(causale) && object.toString().length() == 8) ?
                    			"0"+object.toString() : object.toString();
                    	if(!value.equals(codiciSoggetto.getValue())) {
                    		codiciSoggetto.setValue(value);
                    		codiciSoggetto.setOpId(iView.getOpId());
                    		manager.update(codiciSoggetto);
                    	}
                    } else {
                    	storicDataUpdateHelper.updateCodiciSoggetto(codiciSoggetto.getId(),codiciSoggetto.getSoggettoId(), codiciSoggetto.getValue(), codiciSoggetto.getRightPk(), iView.getOpId(),codiciSoggetto.getOpId());
                    	manager.remove(codiciSoggetto);
                    }
                    causaleColn.remove(causale);
                }
            }
            final Iterator causaleIterator = causaleColn.iterator();
            it.sella.anagrafe.codicisoggetto.CodiciSoggettoView codiciSoggettoView =null;
            final int causaleSize = causaleColn.size();
            for (int i = 0; i < causaleSize; i++) {
                causale = (String)causaleIterator.next();
                object = iView.getValueForThisProperty(causale);
                if (object != null) {
                    codiciSoggettoView = new it.sella.anagrafe.codicisoggetto.CodiciSoggettoView();
                    codiciSoggettoView.setSoggettoId(soggettoId);
                    codiciSoggettoView.setRightPk(ClassificazioneHandler.getClassificazioneView(causale, "CSDPF").getId());
					if("codiceHost".equals(causale) && object.toString().length() == 8) {
						codiciSoggettoView.setValue("0"+object.toString());
					} else {
						codiciSoggettoView.setValue(object.toString());
					}
					codiciSoggettoView.setOpId(iView.getOpId());
					manager.create(codiciSoggettoView);
                }
            }
        } catch (final InvocationTargetException ie) {
            log4Debug.warnStackTrace(ie);
            throw new CodiceSoggettoDiscriminatorException(ie.getLocalizedMessage());
        } catch (final GestoreAnagrafeException ne) {
            log4Debug.warnStackTrace(ne);
            throw new CodiceSoggettoDiscriminatorException(ne.getLocalizedMessage());
        } catch (final IllegalAccessException ae) {
            log4Debug.warnStackTrace(ae);
            throw new CodiceSoggettoDiscriminatorException(ae.getLocalizedMessage());
        } catch (final NoSuchMethodException me) {
            log4Debug.warnStackTrace(me);
            throw new CodiceSoggettoDiscriminatorException(me.getLocalizedMessage());
        } catch (final FinderException fe) {
            log4Debug.warnStackTrace(fe);
            throw new CodiceSoggettoDiscriminatorException(fe.getLocalizedMessage());
        } catch (final ControlloDatiException e) {
            log4Debug.warnStackTrace(e);
            throw new CodiceSoggettoDiscriminatorException(e.getLocalizedMessage());
		}
    }

	private Object getCodiceSoggettoManager() throws GestoreAnagrafeException {
		return ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.CodiciSoggetto");
	}
    
    public void setCodiceValues(final Long soggettoId, String value, final String causale, final Long opId) throws CodiceSoggettoDiscriminatorException, RemoteException {
    	try {
            final Long classificazioneId = getClassificazioneIdFromCausale(causale, "CSDPF");
            final ICodiciSoggettoBeanManager manager = ((ICodiciSoggettoBeanManager) getCodiceSoggettoManager());
			value = ("codiceHost".equals(causale) && value.length() == 8) ? 
					"0"+value : value;
            try {
                final CodiciSoggetto codiciSoggetto = manager.findBySoggettoIdAndRightPK(soggettoId, classificazioneId);
                if(value != null && value.trim().length() > 0) {
                	if(!value.toUpperCase().equals(codiciSoggetto.getValue())) {
                		codiciSoggetto.setValue(value.toUpperCase());
                		codiciSoggetto.setOpId(opId);
                		manager.update(codiciSoggetto);
                	}
                } else {
                	new StoricDataUpdateHelper().updateCodiciSoggetto(codiciSoggetto.getId(), codiciSoggetto.getSoggettoId(), codiciSoggetto.getValue(), codiciSoggetto.getRightPk(), opId,codiciSoggetto.getOpId());
                	manager.remove(codiciSoggetto);
                }
            } catch (final FinderException re) {
                if (value != null && value.trim().length() > 0) {
                    final it.sella.anagrafe.codicisoggetto.CodiciSoggettoView datiView = new it.sella.anagrafe.codicisoggetto.CodiciSoggettoView();
                    datiView.setSoggettoId(soggettoId);
                    datiView.setValue(value);
                    datiView.setRightPk(classificazioneId);
                    datiView.setOpId(opId);
                    manager.create(datiView);
                }
            } catch (final ControlloDatiException e) {
                log4Debug.warnStackTrace(e);
                throw new CodiceSoggettoDiscriminatorException(e.getLocalizedMessage());
			}
        } catch (final GestoreAnagrafeException e) {
            log4Debug.warnStackTrace(e);
            throw new CodiceSoggettoDiscriminatorException(e.getLocalizedMessage());
        } 
    }
    
}


