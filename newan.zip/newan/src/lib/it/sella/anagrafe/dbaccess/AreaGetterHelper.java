package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreCollegamentoException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

public class AreaGetterHelper extends DBAccessHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AreaGetterHelper.class);
	
	public Long getArea(final Long soggettoId, final Long bancaId) throws GestoreCollegamentoException, RemoteException {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Long areaId = null;
        try {
            connection = getConnection();
            final Timestamp endDate = new Timestamp(System.currentTimeMillis());
            StringBuffer query = new StringBuffer("SELECT TS.TS_DESC,SO.SO_SOGGETTO_ID FROM AN_MA_TIPO_SOGGETTO TS,AN_MA_SOGGETTO SO WHERE TS.TS_TIPOSOGGETTO_ID = SO.SO_TIPO_SOGGETTO_ID AND SO.SO_SOGGETTO_ID = (SELECT CL_SOGGETTO_PRINCIPALE FROM AN_TR_COLLAGAMENTO_SOGGETTO");
            query.append(" WHERE CL_LINKED_SOGGETTO = ? AND CL_MOTIVO = ? AND (CL_DATA_FINE IS NULL OR TO_DATE(TO_CHAR(CL_DATA_FINE,'DDMMYY'),'DDMMYY') > TO_DATE(TO_CHAR(?,'DDMMYY'),'DDMMYY')))");
            query.append(" AND EXISTS (SELECT 1 FROM AN_TR_COLLAGAMENTO_SOGGETTO WHERE CL_SOGGETTO_PRINCIPALE = ? AND CL_MOTIVO = ? AND CL_LINKED_SOGGETTO = ? AND CL_DATA_FINE IS NULL)");
            final long apartId = getClassificazioneIdFromCausale("APART", "MOTIV").longValue();
            statement = connection.prepareStatement(query.toString());
            statement.setLong(1, soggettoId.longValue());
            statement.setLong(2, apartId);
            statement.setTimestamp(3, endDate);
            statement.setLong(4, bancaId.longValue());
            statement.setLong(5, getClassificazioneIdFromCausale("CENST", "MOTIV").longValue());
            statement.setLong(6, soggettoId.longValue());
            resultSet = statement.executeQuery();
            if (resultSet.next()) {
                final Long principaleId = Long.valueOf(resultSet.getLong("so_soggetto_id"));
                if (resultSet.getString("ts_desc").startsWith("Area")) {
					areaId = principaleId;
				} else {
                    closeResultSet(resultSet);
                    closeStatement(statement);
                    query = new StringBuffer("SELECT TS.TS_DESC, SO.SO_SOGGETTO_ID FROM AN_MA_TIPO_SOGGETTO TS,AN_MA_SOGGETTO SO WHERE TS.TS_TIPOSOGGETTO_ID = SO.SO_TIPO_SOGGETTO_ID AND SO.SO_SOGGETTO_ID = (SELECT CL_SOGGETTO_PRINCIPALE FROM AN_TR_COLLAGAMENTO_SOGGETTO");
                    query.append(" WHERE CL_LINKED_SOGGETTO = ? AND CL_MOTIVO = ? AND (CL_DATA_FINE IS NULL OR TO_DATE(TO_CHAR(CL_DATA_FINE,'DDMMYY'),'DDMMYY') > TO_DATE(TO_CHAR(?,'DDMMYY'),'DDMMYY')))");
                    statement = connection.prepareStatement(query.toString());
                    statement.setLong(1, principaleId.longValue());
                    statement.setLong(2, apartId);
                    statement.setTimestamp(3, endDate);
                    resultSet = statement.executeQuery();
                    if (resultSet.next() && resultSet.getString("ts_desc").startsWith("Area")) {
                    	areaId = Long.valueOf(resultSet.getLong("so_soggetto_id"));
                    }
                }
            }
        } catch (final SubSystemHandlerException exception) {
            log4Debug.warnStackTrace(exception);
            throw new GestoreCollegamentoException(exception.getLocalizedMessage());
        } catch (final SQLException exception) {
            log4Debug.warnStackTrace(exception);
            throw new GestoreCollegamentoException(exception.getLocalizedMessage());
        } finally {
            cleanup(connection, statement, resultSet);
        }
        return areaId;
    }
	
}

