package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.view.ConsCompatibilityView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ConsCompatibilityDBAccessHelper extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(
    		ConsCompatibilityDBAccessHelper.class);
    
    public void createConsCompatibility( final ConsCompatibilityView consCompatibilityView ) 
      throws GestoreAnagrafeException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
        	final StringBuilder queryBuilder = new StringBuilder("INSERT INTO AN_MA_CON_CLD_COMPATIBILITY CC (");
        	 	queryBuilder.append(" CC.CO_ID, CC.CO_SETTORE, CC.CO_FATTURATO,");
        	 	queryBuilder.append(" CC.CO_NUMERO_DIPENDENTI, CC.CO_BILANCIO, CC.CO_CONSUMATORE,");
        	 	queryBuilder.append(" CC.CO_CLIENTE_AL_DETTAGLIO, CC.CO_OP_ID)");
        	 	queryBuilder.append(" VALUES (AN_CO_SQ_CO_ID.NEXTVAL,?,?,?,?,?,?,?)");
            connection = getConnection();
            preparedStatement = connection.prepareStatement(queryBuilder.toString());
            log4Debug.debug("ConsCompatibilityDBAccessHelper: createConsCompatibility: queryBuilder:===>>>",queryBuilder);
            setConsCompValues(consCompatibilityView, preparedStatement);
            checkForNullAndSetLongValue(preparedStatement, consCompatibilityView.getOpId(), 7);
            preparedStatement.executeUpdate();
        } catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreAnagrafeException(e.getMessage());
        } finally {
            cleanup(connection, preparedStatement);
        }
    }

    public void updateConsCompatibility( final ConsCompatibilityView consCompatibilityView ) 
      throws GestoreAnagrafeException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
        	final StringBuilder queryBuilder = new StringBuilder("UPDATE AN_MA_CON_CLD_COMPATIBILITY CC SET");
	    	 	queryBuilder.append(" CC.CO_SETTORE = ?,");
	    	 	queryBuilder.append(" CC.CO_FATTURATO = ?,");
	    	 	queryBuilder.append(" CC.CO_NUMERO_DIPENDENTI = ?,");
	    	 	queryBuilder.append(" CC.CO_BILANCIO = ?,");
	    	 	queryBuilder.append(" CC.CO_CONSUMATORE = ?,");
	    	 	queryBuilder.append(" CC.CO_CLIENTE_AL_DETTAGLIO = ?,");
	    	 	queryBuilder.append(" CC.CO_OP_ID = ?");
	    	 	queryBuilder.append(" WHERE CC.CO_ID = ?");
            connection = getConnection();
            preparedStatement = connection.prepareStatement(queryBuilder.toString());
            setConsCompValues(consCompatibilityView, preparedStatement);
            checkForNullAndSetLongValue(preparedStatement, consCompatibilityView.getOpId(), 7);
            checkForNullAndSetLongValue(preparedStatement, consCompatibilityView.getId(), 8);
            log4Debug.debug("ConsCompatibilityDBAccessHelper: updateConsCompatibility: queryBuilder:===>>>",queryBuilder);
            preparedStatement.executeUpdate();
        } catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreAnagrafeException(e.getMessage());
        } finally {
            cleanup(connection, preparedStatement);
        }
    }

    public void deleteConsCompatibility( final ConsCompatibilityView consCompatibilityView ) throws GestoreAnagrafeException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
        	new StoricConsCompatibilityUpdateHelper().updateClienteClassificazione(consCompatibilityView.getId(), 
        			consCompatibilityView.getOpId());
            connection = getConnection();
            preparedStatement = connection.prepareStatement("DELETE AN_MA_CON_CLD_COMPATIBILITY CC WHERE CC.CO_ID = ?");
            checkForNullAndSetLongValue(preparedStatement, consCompatibilityView.getId(), 1);
            preparedStatement.executeUpdate();
        } catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreAnagrafeException(e.getMessage());
        } catch (final ControlloDatiException se) {
			log4Debug.warnStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} finally {
            cleanup(connection, preparedStatement);
        }
    }

	private void setConsCompValues( final ConsCompatibilityView consCompatibilityView, 
			final PreparedStatement preparedStatement) throws SQLException {
		preparedStatement.setString(1, consCompatibilityView.getSettore());
		checkForNullAndSetBigDecimalValue(preparedStatement, consCompatibilityView.getFatturato(), 2);
		checkForNullAndSetLongValue(preparedStatement, consCompatibilityView.getNumeroDipendenti(), 3);
		checkForNullAndSetBigDecimalValue(preparedStatement, consCompatibilityView.getBilancio(), 4);
		checkForNullAndSetLongValue(preparedStatement, consCompatibilityView.getConsumatore(), 5);
		checkForNullAndSetLongValue(preparedStatement, consCompatibilityView.getClienteAlDettaglio(), 6);
	}
}
