package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.IMapper;
import it.sella.anagrafe.MapperFactory;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.discriminator.AttributiEsterniDiscriminatorException;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.tipoattributiesterni.ITipoAttributiEsterniBeanManager;
import it.sella.anagrafe.tipoattributiesterni.TipoAttributiEsterni;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.MapperHelperException;
import it.sella.anagrafe.util.ReflectionUtil;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.StringTokenizer;

import javax.ejb.FinderException;

public class BollinoBluHandler extends DBAccessHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(BollinoBluHandler.class);

    public void updateBollinoBluWithHost(final Long soggettoId, final String bollinoValue, final String codiceHost, final Long opId,final boolean isHostCodeFromSecurity) throws AttributiEsterniDiscriminatorException, RemoteException {
        final StringBuffer mapperMsg = new StringBuffer();
        final AttributiEsterniDBAccessHelper aeHelper = new AttributiEsterniDBAccessHelper();
        try {
            if("Non E' ancora informato".equals(bollinoValue)) {
                TipoAttributiEsterni tipoAttributiEsterni = null;
                final Long clId = getClassificazioneIdFromCausale("bollinoBlu","AEDPF");
                final ITipoAttributiEsterniBeanManager tipoAttributiEsterniBeanManager =((ITipoAttributiEsterniBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.TipoAttributiEsterni"));
                try {
                    tipoAttributiEsterni = tipoAttributiEsterniBeanManager.findBySoggettoIdAndRightPK(soggettoId, clId);
                    new StoricDataUpdateHelper().updateAttributiEsterni(tipoAttributiEsterni.getAttributiesterniId(), tipoAttributiEsterni.getSoggettoId(), tipoAttributiEsterni.getValue(), tipoAttributiEsterni.getRightPk(), opId,tipoAttributiEsterni.getOpId());
                    tipoAttributiEsterniBeanManager.remove(tipoAttributiEsterni);
                } catch (final FinderException e) {
                	log4Debug.warnStackTrace(e);
                }
            } else {
                final ClassificazioneView clView =ClassificazioneHandler.getClassificazioneView(bollinoValue,"BOLLINO_BLU");
                aeHelper.setAttributiEsterniValues(soggettoId,clView.getId().toString(),"bollinoBlu", opId);
            }
            mapperMsg.append(alignBollinoBluInHost(soggettoId,codiceHost,bollinoValue,isHostCodeFromSecurity));
        } catch (final ControlloDatiException e) {
            log4Debug.severeStackTrace(e);
            throw new AttributiEsterniDiscriminatorException(e.getMessage());
        } catch (final GestoreAnagrafeException e) {
            log4Debug.severeStackTrace(e);
            throw new AttributiEsterniDiscriminatorException(e.getMessage());
        } catch (final MapperHelperException e) {
            log4Debug.severeStackTrace(e);
            throw new AttributiEsterniDiscriminatorException(e.getMessage());
        }
    }

    public String alignBollinoBluInHost(final Long soggettoId,final String codiceHost,final String bollinoValue,final boolean isHostCodeFromSecurity) throws RemoteException, MapperHelperException, GestoreAnagrafeException {
    	final StringBuffer mapperMsg = new StringBuffer();
        if(codiceHost != null) {
			mapperMsg.append(updateBollinoBluInHostForCodiciHost(bollinoValue,codiceHost,isHostCodeFromSecurity)).append("^");
        }
		final String codiceHostCifrati = new CSCifratiGetterHelper().getCodiceHostCifrati(soggettoId);
		if(codiceHostCifrati != null) {
			mapperMsg.append(updateBollinoBluInHostForCodiciHost(bollinoValue,codiceHostCifrati,isHostCodeFromSecurity));
		}
		return mapperMsg.toString();
    }

    private String updateBollinoBluInHostForCodiciHost(final String bollinoValue,final String codiceHost,final boolean isHostCodeFromSecurity) throws RemoteException, MapperHelperException {
        final StringBuffer output = new StringBuffer();
    	if(CommonPropertiesHandler.isHostAllowedForLoginBank()) {
    		final IMapper mapperHelper = MapperFactory.getMapper();
	        final StringTokenizer tokenizer = new StringTokenizer(codiceHost,";");
	        while (tokenizer.hasMoreTokens()) {
	            final String temp = tokenizer.nextToken();
	            if(temp.startsWith("0")) {
	        		output.append(mapperHelper.updateBollinoBluMapper(bollinoValue,temp.substring(1,9),isHostCodeFromSecurity)).append("^") ;
	            }
	        }
    	}
        return output.toString();
    }
}


