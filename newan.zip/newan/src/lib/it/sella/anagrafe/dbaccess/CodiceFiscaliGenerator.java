package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreDatiFiscaliException;
import it.sella.anagrafe.ICittaView;
import it.sella.anagrafe.INazioneView;
import it.sella.anagrafe.common.Citta;
import it.sella.anagrafe.common.Nazione;
import it.sella.anagrafe.controllo.ControlloDatiPFException;
import it.sella.anagrafe.controllo.ControlloPF;

import java.sql.Timestamp;

public class CodiceFiscaliGenerator {
	
    public String getCodiceFiscale(final String cogNome, final String nome, final Timestamp dataDiNascita, final ICittaView luogoDiNascitaCitta, final INazioneView luogoDiNascitaNazione, final String causaleSesso) throws GestoreDatiFiscaliException {
        try {
            final Citta citta = new Citta();
            citta.setCncf(luogoDiNascitaCitta != null ? luogoDiNascitaCitta.getCncf() : null);
            final Nazione nazione = new Nazione();
            nazione.setNome(luogoDiNascitaNazione != null ? luogoDiNascitaNazione.getNome() : null);
            nazione.setCncf(luogoDiNascitaNazione != null ? luogoDiNascitaNazione.getCncf() : null);
            return ControlloPF.creaCodiceFiscale(cogNome, nome, dataDiNascita, citta, nazione, causaleSesso, false);
        } catch (final ControlloDatiPFException exception) {
            throw new GestoreDatiFiscaliException(exception.getMessage());
        }
    }
}
