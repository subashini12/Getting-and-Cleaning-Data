package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.ConnectionHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 * Class to handle ART136 DB access methods.
 *
 */
public class ART136AlertDBAccess extends ConnectionHandler {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(ART136AlertDBAccess.class);
	
	/**
	 * Method to get alert data of ART136.
	 * @param opId
	 * @return
	 * @throws GestoreAnagrafeException
	 */
	public String processMail(final Long opId) throws GestoreAnagrafeException {
		
		Connection connection = null;
    	CallableStatement callableStatement = null;
    	final ResultSet resultSet = null;
    	String output ="";
		try {
			final String mailId = CommonPropertiesHandler.getValueFromProperty("MAIL_TO");
			connection = getConnection();
    		callableStatement = connection.prepareCall("{call AN_PR_ART136_ALERT(?,?,?)}");
    		callableStatement.setLong(1,opId);
    		callableStatement.setString(2,mailId);
    		callableStatement.registerOutParameter(3, Types.VARCHAR);
    		callableStatement.execute();
    		output = callableStatement.getString(3);						
		}catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new GestoreAnagrafeException(sqlexception.getMessage());
		}
		finally {
			cleanup(connection, callableStatement,resultSet);
		}
		return output;
	}
}
