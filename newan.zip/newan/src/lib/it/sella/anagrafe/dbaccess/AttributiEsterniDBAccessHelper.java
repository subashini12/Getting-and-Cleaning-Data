package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreAttributiEsterniException;
import it.sella.anagrafe.discriminator.AttributiEsterniDiscriminatorException;
import it.sella.anagrafe.implementation.IView;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;

import java.rmi.RemoteException;
import java.util.Collection;

public class AttributiEsterniDBAccessHelper {
	
    public String getAttribuiEsterniValore(final Long soggettoId, final String causale) throws GestoreAttributiEsterniException, RemoteException {
    	return new AEValoreGetter().getAttribuiEsterniValore(soggettoId, causale);
    }

    public Collection getSoggettoIdForTipoAttributoEsterno(final String tipoAttributiCausale, final String valoreAttributiesterniCausale) throws GestoreAttributiEsterniException, RemoteException {
    	return new AESoggettoIdGetter().getSoggettoIdForTipoAttributoEsterno(tipoAttributiCausale, valoreAttributiesterniCausale);
    }

    public Collection getValuesForTipoAttributoEsterno(final String tipoAttributiEsterniCausale) throws GestoreAttributiEsterniException, RemoteException {
    	return new AEValoreGetter().getValuesForTipoAttributoEsterno(tipoAttributiEsterniCausale);
    }

    public Collection getAttributiEsterniAndValues(final Long soggettoId) throws GestoreAttributiEsterniException, RemoteException {
    	return new AEValoreGetter().getAttributiEsterniAndValues(soggettoId);
    }

    public Collection getAttributiEsterniValuesBasedOnSoggetto(final Long soggettoId) throws GestoreAttributiEsterniException, RemoteException {
    	return new AEValoreGetter().getAttributiEsterniValuesBasedOnSoggetto(soggettoId);
    }
    public void createAttributiEsterniPF(final Long soggettoId, final IView iView) throws AttributiEsterniDiscriminatorException, RemoteException {
    	new AECreateHelper().createAttributiEsterniPF(soggettoId, iView);
    }

    public IView getAttributiEsterniPF(final Long soggettoId) throws AttributiEsterniDiscriminatorException, RemoteException {
    	return new AttributiEsterniPFViewBuilder().getAttributiEsterniPF(soggettoId);
    }

    public void setAttributiEsterniPF(final Long soggettoId, final IView iView) throws AttributiEsterniDiscriminatorException, RemoteException {
    	new AEUpdateHelper().setAttributiEsterniPF(soggettoId, iView);
    }

    public Collection findByStato(final Collection soggettiIdColl, final String stato) throws AttributiEsterniDiscriminatorException, RemoteException {
    	return new AttributiEsterniFinder().findByStato(soggettiIdColl, stato);
    }

    public void updateBollinoBluWithHost(final Long soggettoId, final String bollinoValue, final String codiceHost, final Long opId,final boolean isHostCodeFromSecurity) throws AttributiEsterniDiscriminatorException, RemoteException {
    	new BollinoBluHandler().updateBollinoBluWithHost(soggettoId, bollinoValue, codiceHost, opId,isHostCodeFromSecurity);
    }

    public void updateSconfWithHost(final Long soggettoId, final String newSconfValue, final String codiceHost, final Long opId,final boolean isHostCodeFromSecurity) throws OperazioneAnagrafeManagerException, RemoteException {
    	new SconfHandler().updateSconfWithHost(soggettoId, newSconfValue, codiceHost, opId,isHostCodeFromSecurity);
    }

    public void updateDaiForPrincipalIds(final Long pfSoggettoId, final boolean oldDai, final boolean newDai, final Long opId) throws  RemoteException {
    	new DaiUpdateHelper().updateDaiForPrincipalIds(pfSoggettoId, oldDai, newDai, opId);
    }

    public void setAttributiEsterniValues(final Long soggettoId, final String value, final String causale, final Long opId) throws AttributiEsterniDiscriminatorException, RemoteException {
    	new AEUpdateHelper().setAttributiEsterniValues(soggettoId, value, causale, opId);
    }
    
    public String setAttribute(final Long soggettoId, final String causale, final String value) throws GestoreAnagrafeException, RemoteException {
    	return new AEUpdateHelper().setAttribute(soggettoId, causale, value);
    }
    
    public void setIdentificationAttribute(final Long soggettoId,final Long opId, final String value, final String causale) throws RemoteException, GestoreAnagrafeException {
    	new AEUpdateHelper().setIdentificationAttribute(soggettoId, opId, value, causale);
    }
    
}

