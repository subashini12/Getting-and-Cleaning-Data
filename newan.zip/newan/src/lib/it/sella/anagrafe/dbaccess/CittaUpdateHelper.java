package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.common.Citta;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CittaUpdateHelper extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CittaUpdateHelper.class);

    public void createCitta(final Citta citta) throws OperazioneAnagrafeManagerException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        final ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("INSERT INTO AN_MA_CITTA(CI_ID,CI_COMMUNE,CI_PROVINCIA,CI_REGION,CI_CAPOLUOGO,CI_CAB,CI_CINCAB,CI_CAB_STORICO,CI_CNCF,CI_CAP,CI_STORICO,CI_ALTRADENOMINAZIONE,CI_NORMALIZZATO) VALUES(SEQ_CITTA.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?)");
                preparedStatement.setString(1, citta.getCommune() != null ? citta.getCommune().toUpperCase() : null);
                preparedStatement.setString(2, citta.getProvincia().getSigla() != null ? citta.getProvincia().getSigla().toUpperCase() : null);
                preparedStatement.setString(3, citta.getRegion() != null ? citta.getRegion().toUpperCase() : null);
                checkForNullAndSetInPreparedStatement(preparedStatement, citta.getCapoluogo(),4);
                preparedStatement.setString(5, citta.getCab() != null ? citta.getCab().toUpperCase() : null);
                preparedStatement.setString(6, citta.getCinCab() != null ? citta.getCinCab().toUpperCase() : null);
                preparedStatement.setString(7, citta.getCabStorico() != null ? citta.getCabStorico().toUpperCase() : null);
                preparedStatement.setString(8, citta.getCncf() != null ? citta.getCncf().toUpperCase() : null);
                preparedStatement.setString(9, citta.getCap() != null ? citta.getCap().toUpperCase() : null);
                checkForNullAndSetInPreparedStatement(preparedStatement, citta.getStorico(),10);
                preparedStatement.setString(11, citta.getAltraDenominazione() != null ? citta.getAltraDenominazione().toUpperCase() : null);
                preparedStatement.setString(12, citta.getNormalizzato() != null ? citta.getNormalizzato().toUpperCase() : null);
            preparedStatement.executeUpdate();
        } catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new OperazioneAnagrafeManagerException(se.getLocalizedMessage());
        } finally {
            cleanup(connection, preparedStatement, resultSet);
        }
    }

    public void setCitta(final Citta citta) throws OperazioneAnagrafeManagerException {
        Connection connection = null;
        PreparedStatement updateStatement = null;
        try {
            connection = getConnection();
            updateStatement = connection.prepareStatement("update AN_MA_CITTA set CI_COMMUNE = ?, CI_PROVINCIA  = ?, " +
                    " CI_REGION = ?, CI_CAPOLUOGO = ?, CI_CAB = ?, CI_CINCAB = ?, CI_CAB_STORICO = ? , CI_CNCF = ?, CI_CAP = ?, " +
                    " CI_STORICO = ?, CI_ALTRADENOMINAZIONE = ?, CI_NORMALIZZATO = ?  where CI_ID = ? ");
                updateStatement.setString(1, citta.getCommune() != null ? citta.getCommune().toUpperCase() : null);
                updateStatement.setString(2, citta.getProvincia().getSigla() != null ? citta.getProvincia().getSigla().toUpperCase() : null);
                updateStatement.setString(3, citta.getRegion() != null ? citta.getRegion().toUpperCase() : null);
                checkForNullAndSetInPreparedStatement(updateStatement, citta.getCapoluogo(),4);
                updateStatement.setString(5, citta.getCab() != null ? citta.getCab().toUpperCase() : null);
                updateStatement.setString(6, citta.getCinCab() != null ? citta.getCinCab().toUpperCase() : null);
                updateStatement.setString(7, citta.getCabStorico() != null ? citta.getCabStorico().toUpperCase() : null);
                updateStatement.setString(8, citta.getCncf() != null ? citta.getCncf().toUpperCase() : null);
                updateStatement.setString(9, citta.getCap() != null ? citta.getCap().toUpperCase() : null);
                checkForNullAndSetInPreparedStatement(updateStatement, citta.getStorico(),10);
                updateStatement.setString(11, citta.getAltraDenominazione() != null ? citta.getAltraDenominazione().toUpperCase() : null);
                updateStatement.setString(12, citta.getNormalizzato() != null ? citta.getNormalizzato().toUpperCase(): null);

            if (citta.getCittaId() != null) {
				updateStatement.setLong(13, citta.getCittaId().longValue());
			}
            updateStatement.executeUpdate();
        } catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new OperazioneAnagrafeManagerException(se.getLocalizedMessage());
        } finally {
            cleanup(connection, updateStatement);
        }
    }

    private void checkForNullAndSetInPreparedStatement(final PreparedStatement preparedStatement, final ClassificazioneView value,final int index) throws SQLException {
        if (value != null) {
			preparedStatement.setLong(index, Long.parseLong(value.getCausale()));
		} else {
			preparedStatement.setString(index, null);
		}
    }
}
