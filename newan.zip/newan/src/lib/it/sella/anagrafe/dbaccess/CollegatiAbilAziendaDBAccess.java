package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreCollegamentoException;
import it.sella.anagrafe.az.CollegatiAbilAziendaView;
import it.sella.anagrafe.az.ICollegatiAbilAziendaView;
import it.sella.anagrafe.util.ConnectionHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

/**
 * Class for CollegatiAbilitatiAzienda DB Helper
 *
 */
public class CollegatiAbilAziendaDBAccess extends ConnectionHandler {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CollegatiAbilAziendaDBAccess.class);
	
	/**
	 * This method returns the collection of AZ SOGGETTO which belongs to given input SOGGETTO, as COLLEGATE.
	 * @param soggettoId
	 * @return
	 * @throws GestoreCollegamentoException
	 */
	public Collection<ICollegatiAbilAziendaView> getCollegatiAbilAzienda(final Long soggettoId) throws GestoreCollegamentoException {
		final Collection<ICollegatiAbilAziendaView> collegatiAbilAzList = new ArrayList<ICollegatiAbilAziendaView>();
        Connection connection = null;
        PreparedStatement statement = null;
        final StringBuilder query = new StringBuilder();
        ResultSet resultSet = null;
        try {
            if (soggettoId != null) {
                connection = getConnection();
                query.append(" SELECT SOGGETTO, DENOMINAZIONE, MOTIVE, MOTIVE_DESCRIPTION ");
                query.append(" FROM TABLE ( AN_PKG_IGESTORE_ANAGRAFE.AN_FN_COLL_ABIL_PRINCIPLE( ? )) ");
                statement = connection.prepareStatement(query.toString());
                statement.setLong(1, soggettoId);
                resultSet = statement.executeQuery();
                CollegatiAbilAziendaView collegatiAbilAziendaView = null;
                 while (resultSet.next()) {
                	 	collegatiAbilAziendaView = new CollegatiAbilAziendaView();
                	 	collegatiAbilAziendaView.setSoggetto(resultSet.getLong("SOGGETTO"));
                	 	collegatiAbilAziendaView.setDenominazione(resultSet.getString("DENOMINAZIONE"));
                	 	collegatiAbilAziendaView.setMotive(resultSet.getString("MOTIVE"));
                	 	collegatiAbilAziendaView.setMotiveDescription(resultSet.getString("MOTIVE_DESCRIPTION"));
                	 	collegatiAbilAzList.add(collegatiAbilAziendaView);
                    }
             }
        } catch (final SQLException se) {
            log4Debug.severe("<<GA>> Exception while calling AN_PKG_IGESTORE_ANAGRAFE.AN_FN_COLL_ABIL_PRINCIPLE  " , se.getMessage());
            throw new GestoreCollegamentoException(se.getMessage());
        } finally {
            cleanup(connection, statement, resultSet);
        }
        return collegatiAbilAzList;
	}

}
