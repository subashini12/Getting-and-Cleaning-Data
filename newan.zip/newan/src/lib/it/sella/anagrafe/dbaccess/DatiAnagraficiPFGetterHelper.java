package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.ICittaView;
import it.sella.anagrafe.INazioneView;
import it.sella.anagrafe.common.Citta;
import it.sella.anagrafe.discriminator.DatiAnagraficiDiscriminatorException;
import it.sella.anagrafe.implementation.DAAZView;
import it.sella.anagrafe.pf.DatiAnagraficiPFView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatiAnagraficiPFGetterHelper extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DatiAnagraficiPFGetterHelper.class);

    public DatiAnagraficiPFView getDatiAnagraficiPF(final Long soggettoId) throws DatiAnagraficiDiscriminatorException, RemoteException {
        DatiAnagraficiPFView datiAnagraficiPFView = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select DN_NOME, DN_COGNOME, DN_DATE_OF_BIRTH, DN_CITTA_OF_BIRTH, " +
                    " DN_NAZIONE_OF_BIRTH, DN_NORMALISEDSTRING  from AN_TR_DATIANAGRAFE where DN_SOGGETTO_ID = ? ");
            preparedStatement.setLong(1, soggettoId.longValue());
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                datiAnagraficiPFView = new DatiAnagraficiPFView();
                datiAnagraficiPFView.setCognome(resultSet.getString("DN_COGNOME"));
                if (resultSet.getDate("DN_DATE_OF_BIRTH") != null) {
					datiAnagraficiPFView.setDataDiNascita((new java.sql.Timestamp(resultSet.getDate("DN_DATE_OF_BIRTH").getTime())));
				}
                datiAnagraficiPFView.setNome(resultSet.getString("DN_NOME"));
                Citta citta = null;
                try {
                    final Long tempCittaId = Long.valueOf(resultSet.getString("DN_CITTA_OF_BIRTH"));
                    citta = new CittaDBAccessHelper().getCittaOfGVBean(tempCittaId);
                } catch (final NumberFormatException nfe) {
                	log4Debug.warnStackTrace(nfe);
                }
                if (citta == null) {
                    citta = new Citta();
                    citta.setCommune(resultSet.getString("DN_CITTA_OF_BIRTH"));
                }
                datiAnagraficiPFView.setLuogoDiNascitaCitta(citta);
                if (resultSet.getString("DN_NAZIONE_OF_BIRTH") != null) {
                    final Long nazioneId = Long.valueOf(resultSet.getString("DN_NAZIONE_OF_BIRTH"));
                    datiAnagraficiPFView.setLuogoDiNascitaNazione(new NazioneDBAccessHelper().getNazioneOfGVBean(nazioneId));
                }
                datiAnagraficiPFView.setNormalisedNome(resultSet.getString("DN_NORMALISEDSTRING"));
            }
        } catch (final SQLException se) {
            log4Debug.severeStackTrace(se);
            throw new DatiAnagraficiDiscriminatorException(se.getLocalizedMessage());
        } finally {
            cleanup(connection, preparedStatement, resultSet);
        }
        return datiAnagraficiPFView;
    }
    
    /**
     * @param datiResultSet
     * @return
     * @throws SQLException
     * @throws GestoreAnagrafeException
     * DAAZView
     */
    protected DAAZView getDAAZViewFromResultSet(final ResultSet datiResultSet) throws SQLException, GestoreAnagrafeException {
        final DAAZView datiAnagraficiAZView = new DAAZView();
        datiAnagraficiAZView.setDataDiCostituzione(datiResultSet.getTimestamp("AZ_DATADICOSTITUZIONE"));
        datiAnagraficiAZView.setDenominazione(datiResultSet.getString("AZ_DENOMINAZIONE"));
        // Setting Nazione and Citta in DAAZView .. Added newly
        if( datiResultSet.getString("AZ_NAZIONE_COSTITUZIONE") != null ) {
            final INazioneView nazioneView = new NazioneDBAccessHelper().getNazione(Long.valueOf(datiResultSet.getString("AZ_NAZIONE_COSTITUZIONE")));
            datiAnagraficiAZView.setNazioneCostituzioneView(nazioneView);
            if( nazioneView != null ) {
            	datiAnagraficiAZView.setNazioneCostituzione(nazioneView.getNome());
            }
        }
        if(datiResultSet.getString("AZ_CITTA_COSTITUZIONE") != null){
        	try {
				final ICittaView cittaView = new CittaDBAccessHelper().getCitta(Long.valueOf(datiResultSet.getString("AZ_CITTA_COSTITUZIONE")));
				datiAnagraficiAZView.setCittaCostituzioneView(cittaView);
				if(cittaView != null){
					datiAnagraficiAZView.setCittaCostituzione(cittaView.getCommune());
				}
			} catch (NumberFormatException e) {
				datiAnagraficiAZView.setCittaCostituzione(datiResultSet.getString("AZ_CITTA_COSTITUZIONE"));
			}
        }
        return datiAnagraficiAZView;
    }
}
