package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreCollegamentoException;
import it.sella.anagrafe.collegamento.Collegamento;
import it.sella.anagrafe.collegamento.ICollegamentoBeanManager;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.discriminator.CollegamentoException;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.PortafogliazioneClientelaAccessHelper;
import it.sella.anagrafe.util.PortafogliazioneClientelaException;
import it.sella.anagrafe.util.ReflectionUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Iterator;

import javax.ejb.FinderException;

public class CollegamentoSetterHelper extends DBAccessHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CollegamentoSetterHelper.class);

    public void setCollegamento( final Long linkedSoggettoId, Timestamp dataFine, final Long opId ) throws CollegamentoException, RemoteException {
        try {
            Collegamento collegamento = null;
            final ICollegamentoBeanManager collegamentoBeanManager = ((ICollegamentoBeanManager) getCollegamentoManager());
            final Collection collegamentoColl = collegamentoBeanManager.findByLinkedSoggetto(linkedSoggettoId);
            if( collegamentoColl != null ) {
            	final Iterator collegamentoIterator = collegamentoColl.iterator();
            	final int collegamentoSize = collegamentoColl.size();
                dataFine = dataFine == null ? new Timestamp(System.currentTimeMillis()) : dataFine;
                for( int i = 0; i < collegamentoSize; i++ ) {
                    collegamento = (Collegamento) collegamentoIterator.next();
                    collegamento.setDataFine(dataFine);
                    collegamento.setOpId(opId);
                    collegamentoBeanManager.update(collegamento);
                    log4Debug.debug("=============Remove Cliente With Promoter In setCollegamentoone in CollegamentoSetterHelper=====================");
                    new PortafogliazioneClientelaAccessHelper ().toRemoveClientWithPromoter(collegamento);
                }
            }
        } catch (final FinderException fe) {
            log4Debug.warnStackTrace(fe);
            throw new CollegamentoException(fe.getMessage());
        } catch (final GestoreAnagrafeException fe) {
            log4Debug.warnStackTrace(fe);
            throw new CollegamentoException(fe.getMessage());
        } catch (PortafogliazioneClientelaException e) {
        	 log4Debug.warnStackTrace(e);
		}
    }

	private Object getCollegamentoManager() throws GestoreAnagrafeException {
		return ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.Collegamento");
	}

    public void replaceCollegamento( final Long oldSoggettoId, final Long newSoggettoId, final String motivCausale, final Long opId ) throws GestoreCollegamentoException, RemoteException {
        try {
        	final Timestamp currentDate = new Timestamp(System.currentTimeMillis());
        	final Long motivoId = getClassificazioneIdFromCausale(motivCausale, "MOTIV");
        	final ICollegamentoBeanManager collegamentoBeanManager = ((ICollegamentoBeanManager) getCollegamentoManager());
        	final Collection collegamentoColl = collegamentoBeanManager.findBySoggettoCollegamento(oldSoggettoId, motivoId);
        	
        	final Iterator collegamentoIterator = collegamentoColl.iterator();
        	it.sella.anagrafe.collegamento.Collegamento collegamento = null;
            for( int i = collegamentoColl.size(); i > 0; i-- ) {
                collegamento = (it.sella.anagrafe.collegamento.Collegamento) collegamentoIterator.next();
                setCollagamentoValues(newSoggettoId, motivCausale, opId,
						currentDate, collegamento,collegamentoBeanManager);
        		log4Debug.debug("=============Remove Cliente With Promoter In replaceCollegamento in CollegamentoSetterHelper=====================");
                new PortafogliazioneClientelaAccessHelper ().toRemoveClientWithPromoter(collegamento);
            }
        } catch (final FinderException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreCollegamentoException(e.getMessage());
        } catch (final GestoreAnagrafeException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreCollegamentoException(e.getMessage());
        } catch (PortafogliazioneClientelaException e) {
        	log4Debug.warnStackTrace(e);
		}
    }

    public void setCollegamento( final Long linkedSoggettoId, Timestamp dataFine, final Collection motiv, final Long opId ) throws CollegamentoException, RemoteException {
        try {
        	final ICollegamentoBeanManager collegamentoBeanManager = ((ICollegamentoBeanManager) getCollegamentoManager());
            if( motiv != null ) {
                final Iterator motivIterator = motiv.iterator();
                final int size = motiv.size();
                String motivCausale = null;
                for( int i = 0; i < size; i++ ) {
                	motivCausale = (String) motivIterator.next();
                	final Long motivoId = getClassificazioneIdFromCausale(motivCausale, "MOTIV");
                    if( "CENST".equals(motivCausale) ) {
                    	setCollegamentoForCENST(linkedSoggettoId,dataFine,opId);
                    } else {
                    	final Collection collegamentoColl = collegamentoBeanManager.findBySoggettoCollegamento(linkedSoggettoId, motivoId);
                    	if( collegamentoColl != null ) {
                    		final Iterator collegamentoIterator = collegamentoColl.iterator();
                    		final int collegamentoSize = collegamentoColl.size();
                    		Collegamento collegamento = null;
                    		final DateHandler dateHandler = new DateHandler();
                    		dataFine = dataFine == null ? dateHandler.getCurrentDateInTimeStampFormat() : dataFine;
                    		for( int j = 0; j < collegamentoSize; j++ ) {
                    			final Timestamp currentDate = dateHandler.getCurrentDateInTimeStampFormat();
                    			collegamento = (Collegamento) collegamentoIterator.next();
                    			if( collegamento.getDataFine() == null || currentDate.before(collegamento.getDataFine()) ) {
                    				collegamento.setDataFine(dataFine);
                    				collegamento.setOpId(opId);
                    				collegamentoBeanManager.update(collegamento);
                    				log4Debug.debug("=============Remove Cliente With Promoter In setCollegamento in CollegamentoSetterHelper=====================");
                    				new PortafogliazioneClientelaAccessHelper ().toRemoveClientWithPromoter(collegamento);
                    			}
                    		}
                    	}
                    }
                }
            }
        } catch (final FinderException fe) {
            log4Debug.warnStackTrace(fe);
            throw new CollegamentoException(fe.getMessage());
        } catch (final GestoreAnagrafeException ce) {
            log4Debug.warnStackTrace(ce);
            throw new CollegamentoException(ce.getMessage());
        } catch (PortafogliazioneClientelaException e) {
        	log4Debug.warnStackTrace(e);
		}
    }

    public void setCollegamento( final Long principaleId, final Long linkedSoggettoId, final Timestamp dataFine,
    		final String motiv, final Long opId, final String note ) throws CollegamentoException, RemoteException {
        try {
        	final ICollegamentoBeanManager collegamentoBeanManager = ((ICollegamentoBeanManager) getCollegamentoManager());
            if ( motiv != null ) {
            	final Long motivoId = getClassificazioneIdFromCausale(motiv, "MOTIV");
            	final Collection collegamentoColl = collegamentoBeanManager.findByPrincipalMotivoAndLinked(principaleId, motivoId, linkedSoggettoId);

                if( collegamentoColl != null ) {
                	final int collegamentoSize = collegamentoColl.size();
                	final Iterator collegamentoIterator = collegamentoColl.iterator();
                	Collegamento collegamento = null;
                    for( int i = 0; i < collegamentoSize; i++ ) {
                    	collegamento = (Collegamento) collegamentoIterator.next();
                        collegamento.setDataFine(dataFine != null ? dataFine : new Timestamp(System.currentTimeMillis()));
                        collegamento.setOpId(opId);
                        collegamento.setNote(note);
                        collegamentoBeanManager.update(collegamento);
                        log4Debug.debug("=============Remove Cliente With Promoter In setCollegamento in CollegamentoSetterHelper=====================");
        				new PortafogliazioneClientelaAccessHelper ().toRemoveClientWithPromoter(collegamento);
                    }
                }
            }
        } catch (final FinderException fe) {
            log4Debug.warnStackTrace(fe);
            throw new CollegamentoException(fe.getMessage());
        } catch (final GestoreAnagrafeException ce) {
            log4Debug.warnStackTrace(ce);
            throw new CollegamentoException(ce.getMessage());
        } catch (PortafogliazioneClientelaException e) {
        	log4Debug.warnStackTrace(e);
		}
    }

    public void removeCollegamento( final Long principaleId, final Long linkedSoggettoId,
    		final String motiv, final Long opId ) throws CollegamentoException, RemoteException {
        try {
        	final ICollegamentoBeanManager collegamentoBeanManager = ((ICollegamentoBeanManager) getCollegamentoManager());
            if( motiv != null ) {
            	final Long motivoId = getClassificazioneIdFromCausale(motiv, "MOTIV");
            	final Collection collegamentoColl = collegamentoBeanManager.findByPrincipalMotivoAndLinked(principaleId, motivoId, linkedSoggettoId);
            	final StoricDataUpdateHelper storicDataUpdateHelper = new StoricDataUpdateHelper();
                if( collegamentoColl != null ) {
                	final int collegamentoSize = collegamentoColl.size();
                	final Iterator collegamentoIterator = collegamentoColl.iterator();
                	Collegamento collegamento = null;
                    for( int i = 0; i < collegamentoSize; i++ ) {
                    	collegamento = (Collegamento) collegamentoIterator.next();
                    	storicDataUpdateHelper.updateCollegamentoSoggetto(collegamento.getCollegamentoId(), collegamento.getSoggettoId(), collegamento.getMotivo(), collegamento.getNote(), collegamento.getDataInizio(), collegamento.getDataFine(), collegamento.getLinkedSoggettoId(), opId,collegamento.getOpId());
                    	collegamentoBeanManager.remove(collegamento);
                    //	new PortafogliazioneClientelaAccessHelper ().toRemoveClientWithPromoter(collegamento);
                    }
                }
            }
        } catch (final FinderException fe) {
            log4Debug.warnStackTrace(fe);
            throw new CollegamentoException(fe.getMessage());
        } catch (final GestoreAnagrafeException ce) {
            log4Debug.warnStackTrace(ce);
            throw new CollegamentoException(ce.getMessage());
        }  catch (final ControlloDatiException e) {
            log4Debug.warnStackTrace(e);
            throw new CollegamentoException(e.getMessage());
		}
    }


    private void setCollegamentoForCENST( final Long linkedSoggettoId, final Timestamp dataFine, final Long opId ) throws CollegamentoException {
    	Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = getConnection();
            final String query = "UPDATE AN_TR_COLLAGAMENTO_SOGGETTO SET CL_DATA_FINE = ?,CL_OP_ID = ?  WHERE ( CL_SOGGETTO_PRINCIPALE = ?  OR CL_LINKED_SOGGETTO = ? ) AND CL_DATA_FINE IS NULL";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setTimestamp(1, dataFine == null ? new Timestamp(System.currentTimeMillis()) : dataFine );
            preparedStatement.setLong(2,opId.longValue());
            preparedStatement.setLong(3,linkedSoggettoId.longValue());
            preparedStatement.setLong(4,linkedSoggettoId.longValue());
        }  catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new CollegamentoException(se.getMessage());
        } finally {
            cleanup(connection,preparedStatement);
        }
    }

    public void replaceCollegamento( final Long oldSoggettoId, final Long newSoggettoId, final String motivCausale, final Long opId ,final Long soggettoId) throws GestoreCollegamentoException, RemoteException {
        try {
        	final Timestamp currentDate = new Timestamp(System.currentTimeMillis());
        	final Long motivoId = getClassificazioneIdFromCausale(motivCausale, "MOTIV");
        	final ICollegamentoBeanManager collegamentoBeanManager = ((ICollegamentoBeanManager) getCollegamentoManager());
        	final Collection collegamentoColl = collegamentoBeanManager.findBySoggettoCollegamento(oldSoggettoId, motivoId);
        	final Iterator collegamentoIterator = collegamentoColl.iterator();
        	it.sella.anagrafe.collegamento.Collegamento collegamento = null;
        	for( int i = collegamentoColl.size(); i > 0; i-- ) {
        		collegamento = (it.sella.anagrafe.collegamento.Collegamento) collegamentoIterator.next();
        		if ( soggettoId.equals( collegamento.getSoggettoId() )) {
        			setCollagamentoValues(newSoggettoId, motivCausale, opId,
							currentDate, collegamento,collegamentoBeanManager);
        		}
        	}
        } catch (final FinderException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreCollegamentoException(e.getMessage());
        } catch (final GestoreAnagrafeException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreCollegamentoException(e.getMessage());
        }
    }

	private void setCollagamentoValues(final Long newSoggettoId,final String motivCausale, final Long opId,final Timestamp currentDate,
			final Collegamento collegamento ,final ICollegamentoBeanManager collegamentoBeanManager) throws RemoteException, GestoreCollegamentoException {
		final it.sella.anagrafe.CollegamentoView collegamentoView = new it.sella.anagrafe.CollegamentoView();
		collegamentoView.setSoggettoPrincipaleId(collegamento.getSoggettoId());
		collegamentoView.setMotivoCausale(motivCausale);
		collegamentoView.setLinkedSoggettoId(newSoggettoId);
		collegamentoView.setOpId(opId);
		new CollegamentoDBAccessHelper().createCollegamento(collegamentoView);
		collegamento.setDataFine(currentDate);
		collegamento.setOpId(opId);
		collegamentoBeanManager.update(collegamento);
		
	}
}

