package it.sella.anagrafe.dbaccess.dai;

import it.sella.anagrafe.AnagrafeDAIException;
import it.sella.anagrafe.DAISoggettoData;
import it.sella.anagrafe.DAIStoricDataView;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.IDAISoggettoData;
import it.sella.anagrafe.IDAIStoricDataView;
import it.sella.anagrafe.SoggettoDAIDataView;
import it.sella.anagrafe.dbaccess.DBAccessHelper;
import it.sella.anagrafe.dbaccess.DocPoteriFirmaGetterHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

/**
 * @author GBS03447
 *
 */
public class DAISoggettoGetterHelper extends DBAccessHelper {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DAISoggettoGetterHelper.class);
	
	/**
	 * Get DAI Soggetto Data For the Given Input Soggetto.. API purpose Method
	 * @param soggettoId
	 * @return
	 * @throws GestoreAnagrafeException
	 */
	public IDAISoggettoData getAnagrafeDAISoggetto (final Long soggettoId) throws GestoreAnagrafeException {
		DAISoggettoData daiSoggetto = null;
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		query.append("SELECT DS.DS_SOGGETTO_ID, (SELECT DAI_DESCRIZIONE FROM AN_MA_DAI_CONFIG WHERE DC_DAI_ID = DS.DS_DAI_WEIGHT_ID_ID) DAI_STATUS FROM AN_TR_DAI_SOGGETTO DS WHERE DS.DS_SOGGETTO_ID = ?");
		
		try {
			
			if(soggettoId != null && new DocPoteriFirmaGetterHelper().getSoggettoPrincipale(soggettoId, "CENST") != null) {
				daiSoggetto = new DAISoggettoData();
				connection = getConnection();
				statement = connection.prepareStatement(query.toString());
				statement.setLong(1, soggettoId);
				resultSet = statement.executeQuery();
				if (resultSet.next()) {
					daiSoggetto.setSoggettoId(resultSet.getLong("DS_SOGGETTO_ID"));
					daiSoggetto.setDaiStatus(resultSet.getString("DAI_STATUS"));
				} else {
					daiSoggetto.setSoggettoId(soggettoId);
					daiSoggetto.setDaiStatus("NA");
				}
			}
		} catch (final SQLException e) {
			log4Debug.severeStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return daiSoggetto;
	}
	
	/**
	 * This Method Returns collection Of Final DAI Storic Data
	 * @param soggettoId
	 * @return
	 * @throws GestoreAnagrafeException
	 * @throws RemoteException
	 */
	public Collection<IDAIStoricDataView> getStoricoDAI (final Long soggettoId, final String... daiCausale) throws GestoreAnagrafeException, RemoteException {
		final Collection<IDAIStoricDataView> daiStoricDataColl = new ArrayList<IDAIStoricDataView>();
		DAIStoricDataView daiStroricView = null;
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		Long daiId = null;
		query.append("SELECT AE_SOGGETTO_ID, AE_VALUE, AE_OP_ID, OP_DATE_OF_OPERATION FROM AN_TR_ATTRIBUTIESTERNI AE, ANADD_LG_OPERATION LG WHERE AE_RIGHT_PK = ? ");
		query.append(" AND AE_OP_ID = OP_ID(+) AND AE_SOGGETTO_ID = ? UNION ");
		query.append(" SELECT AE_SOGGETTO_ID, AE_VALUE, AE_OLD_OP_ID, OP_DATE_OF_OPERATION FROM ANSE_TR_ATTRIBUTIESTERNI, ANADD_LG_OPERATION LG WHERE AE_RIGHT_PK = ? ");
		query.append(" AND AE_OLD_OP_ID = OP_ID(+) AND AE_SOGGETTO_ID = ? ORDER BY AE_OP_ID DESC NULLS LAST, OP_DATE_OF_OPERATION DESC NULLS LAST ");
		
		try {
			if(daiCausale.length == 0 || "dai".equals(daiCausale[0])) {
				daiId = getClassificazioneIdFromCausale("dai", "AEDPF");
			} else {
				daiId = getClassificazioneIdFromCausale("newDai", "AEDPF"); // Get Confirmation
			}
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setLong(1, daiId);
			statement.setLong(2, soggettoId);
			statement.setLong(3, daiId);
			statement.setLong(4, soggettoId);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				daiStroricView = new DAIStoricDataView();
				daiStroricView.setSoggettoId(resultSet.getLong("AE_SOGGETTO_ID"));
				final Boolean value = resultSet.getString("AE_VALUE") == null ? null : ("false".equals(resultSet.getString("AE_VALUE")) ? Boolean.FALSE : Boolean.TRUE);
				daiStroricView.setValue(value);
				daiStroricView.setDateOfOperation(resultSet.getTimestamp("OP_DATE_OF_OPERATION"));
				daiStoricDataColl.add(daiStroricView);
			}
		} catch (final SQLException e) {
			log4Debug.severeStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return daiStoricDataColl;
	}
	
	/**
	 * This Mesthod Returns DAISoggetto View For the given Soggetto Id
	 * @param soggettoId
	 * @return
	 * @throws AnagrafeDAIException
	 */
	public SoggettoDAIDataView getDAISoggettoView (final Long soggettoId) throws AnagrafeDAIException {
		SoggettoDAIDataView daiSoggettoView = null;
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		query.append("SELECT DS_ID, DS_SOGGETTO_ID, DS_REGOLE_ID, DS_DAI_WEIGHT_ID_ID, DS_OP_ID FROM AN_TR_DAI_SOGGETTO WHERE DS_SOGGETTO_ID = ?");
		final DAIDBAccessHelper helper = new DAIDBAccessHelper();
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setLong(1, soggettoId);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				daiSoggettoView = new SoggettoDAIDataView();
				daiSoggettoView.setId(resultSet.getLong("DS_ID"));
				daiSoggettoView.setSoggettoId(resultSet.getLong("DS_SOGGETTO_ID"));
				daiSoggettoView.setDaiRegoleData(resultSet.getString("DS_REGOLE_ID") != null ? helper.getDAIRegoleForRegoleId(resultSet.getLong("DS_REGOLE_ID")) : null);
				daiSoggettoView.setDaiWeightId(resultSet.getString("DS_DAI_WEIGHT_ID_ID") != null ? helper.getDAIConfig(resultSet.getLong("DS_DAI_WEIGHT_ID_ID")) : null);
				daiSoggettoView.setOpId(resultSet.getLong("DS_OP_ID"));
			}
		} catch (final SQLException e) {
			log4Debug.severeStackTrace(e);
			throw new AnagrafeDAIException(e.getMessage(), e);
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return daiSoggettoView;
	}
	
	/**
	 * @param soggettoId
	 * @return
	 * @throws GestoreAnagrafeException
	 */
	public String calculateDAIAnagrafe (final Long soggettoId) throws GestoreAnagrafeException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		String anagrafeDAI = null;
		try {
			connection = getConnection();
			callableStatement = connection.prepareCall("{call AN_PKG_IGESTORE_ANAGRAFE.AN_PR_CALCULATE_DAI_ANAGRAFE( ?, ?)}");
			if(soggettoId != null) {
				callableStatement.setLong(1, soggettoId);
			}else {
				callableStatement.setNull(1, Types.NUMERIC);
			}
			callableStatement.registerOutParameter(2, Types.VARCHAR);
			callableStatement.executeUpdate();
	        anagrafeDAI = callableStatement.getString(2);
	        
		} catch (final SQLException e) {
			log4Debug.severeStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} finally {
			cleanup(connection, callableStatement);
		}
		log4Debug.debug("DAISoggettoGetterHelper  =====  calculateDAIAnagrafe  ===== anagrafeDAI ======   ",anagrafeDAI);
		return anagrafeDAI;
	}
	
	/**
	 * @param soggettoId
	 * @return
	 * @throws GestoreAnagrafeException
	 */
	public Boolean calculateDAICompleto (final Long soggettoId) throws GestoreAnagrafeException  {
		Connection connection = null;
		CallableStatement callableStatement = null;
		Boolean finalDAI = null;
		try {
			connection = getConnection();
			callableStatement = connection.prepareCall("{call AN_PKG_IGESTORE_ANAGRAFE.AN_PR_CALCULATE_COMPLETE_DAI( ?, ?)}");
			if(soggettoId != null) {
				callableStatement.setLong(1, soggettoId);
			}else {
				callableStatement.setNull(1, Types.NUMERIC);
			}
			callableStatement.registerOutParameter(2, Types.VARCHAR);
			callableStatement.executeUpdate();
	        final String daiValue = callableStatement.getString(2);
	        log4Debug.debug("DAISoggettoGetterHelper  =====  calculateDAIAnagrafe  ===== daiValue ======   ",daiValue);
	        if("false".equals(daiValue)){
	        	finalDAI = Boolean.FALSE;
	        } else if("true".equals(daiValue)) {
	        	finalDAI = Boolean.TRUE;
	        }
		} catch (final SQLException e) {
			log4Debug.severeStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} finally {
			cleanup(connection, callableStatement);
		}
		log4Debug.debug("DAISoggettoGetterHelper  =====  calculateDAIAnagrafe  ===== finalDAI ======   ",finalDAI);
		return finalDAI;
	}
}