package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.collegamento.Collegamento;
import it.sella.anagrafe.collegamento.ICollegamentoBeanManager;
import it.sella.anagrafe.discriminator.CollegamentoException;
import it.sella.anagrafe.util.AbilitatiMotivHelper;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.PortafogliazioneClientelaAccessHelper;
import it.sella.anagrafe.util.PortafogliazioneClientelaException;
import it.sella.anagrafe.util.ReflectionUtil;
import it.sella.anagrafe.util.StringHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.ejb.FinderException;

public class CollegamentoUpdateUtil extends DBAccessHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CollegamentoUpdateUtil.class);

    public void modifyCollegamento(final Long id, final it.sella.anagrafe.CollegamentoView collegamentoView) throws CollegamentoException, RemoteException {
        try {
        	final ICollegamentoBeanManager collegamentoBeanManager = ((ICollegamentoBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.Collegamento"));
            final Collegamento collegamento = collegamentoBeanManager.findByPrimaryKey(id);
            final Long motivoId = getClassificazioneIdFromCausale(collegamentoView.getMotivoCausale(), "MOTIV");
            final StringHandler stringHandler = new StringHandler();
            final DateHandler dateHandler = new DateHandler();
            if(!stringHandler.checkForEquality(dateHandler.formatDate(collegamentoView.getDataFine(),"dd-MM-yyyy"), dateHandler.formatDate(collegamento.getDataFine(),"dd-MM-yyyy")) ||
            		!stringHandler.checkForEquality(dateHandler.formatDate(collegamentoView.getDataInizio(),"dd-MM-yyyy"), dateHandler.formatDate(collegamento.getDataInizio(),"dd-MM-yyyy")) ||
            		!stringHandler.checkForEquality(collegamentoView.getLinkedSoggettoId(), collegamento.getLinkedSoggettoId()) ||
            		!stringHandler.checkForEquality(motivoId, collegamento.getMotivo()) ||
            		!stringHandler.checkForEquality(collegamentoView.getNote(), collegamento.getNote()) ||
            		!stringHandler.checkForEquality(collegamentoView.getSoggettoPrincipaleId(), collegamento.getSoggettoId())) {
	            collegamento.setDataFine(collegamentoView.getDataFine());
	            collegamento.setDataInizio(collegamentoView.getDataInizio());
	            collegamento.setLinkedSoggettoId(collegamentoView.getLinkedSoggettoId());
	            collegamento.setMotivo(motivoId);
	            collegamento.setNote(collegamentoView.getNote());
	            collegamento.setSoggettoId(collegamentoView.getSoggettoPrincipaleId());
	            collegamento.setOpId(collegamentoView.getOpId());
	            collegamentoBeanManager.update(collegamento);
	            if(collegamentoView.getDataFine() != null )
	            {
	            	new PortafogliazioneClientelaAccessHelper ().toRemoveClientWithPromoter(collegamento);
	            }
	            if (("DIPEN".equals(collegamentoView.getMotivoCausale()) || "CENST".equals(collegamentoView.getMotivoCausale()) || "SVILP".equals(collegamentoView.getMotivoCausale())) && (collegamentoView.getDataFine() != null)) {
	                updateAllLinks(motivoId, collegamentoView.getLinkedSoggettoId(), collegamentoView.getDataFine());
	            }
            }
        } catch (final GestoreAnagrafeException e) {
            log4Debug.severeStackTrace(e);
            throw new CollegamentoException(e.getMessage());
        } catch (final SQLException se) {
            log4Debug.severeStackTrace(se);
            throw new CollegamentoException(se.getMessage());
        } catch (final FinderException e) {
            log4Debug.severeStackTrace(e);
            throw new CollegamentoException(e.getMessage());
        } catch (PortafogliazioneClientelaException e) {
        	log4Debug.warnStackTrace(e);
		}
    }

    protected void updateAllLinks(final Long motivId, final Long soggettoId, final Timestamp dataFine) throws SQLException {
        Connection connection = null;
        CallableStatement callableStatement = null;
        try {
            connection = getConnection();
            callableStatement = connection.prepareCall("{call an_pr_UpdateLinkDate( ?, ?, ?)}");
            callableStatement.setDate(1, new java.sql.Date(dataFine.getTime()));
            callableStatement.setLong(2, soggettoId.longValue());
            callableStatement.setLong(3, motivId.longValue());
            callableStatement.executeUpdate();
        } finally {
            cleanup(connection, callableStatement);
        }
    }

    protected Collection getAbilitatiMotivCollection(final String inputString, final String separator, final Long principalId) throws CollegamentoException, RemoteException {
        Collection amCollection = null;
        Collection newSoggettoIdCollection = null;
        final StringTokenizer stringTokenizer = new StringTokenizer(inputString, separator);
        while (stringTokenizer.hasMoreTokens()) {
            if (amCollection == null) {
				amCollection = new Vector();
			}
            amCollection.add(Long.valueOf((String) stringTokenizer.nextElement()));
        }

        Collection collegamentoCollection = null;
        collegamentoCollection = new CollegamentoLinkedSoggettiHandler().listCollegamento(principalId);
        if (collegamentoCollection != null && amCollection != null) {
            final Iterator collIterator = collegamentoCollection.iterator();
            final int collSize = collegamentoCollection.size();
            for (int i = 0; i < collSize; i++) {
                final it.sella.anagrafe.CollegamentoView collegamentoView = (it.sella.anagrafe.CollegamentoView) collIterator.next();
                if (newSoggettoIdCollection == null) {
					newSoggettoIdCollection = new Vector();
				}
                if (collegateAbilitatiMotivsExists(principalId, collegamentoView.getMotivoCausale()) && (!amCollection.contains(collegamentoView.getLinkedSoggettoId()))) {
                    newSoggettoIdCollection.add(collegamentoView.getLinkedSoggettoId());
                }
            }
        }
        return newSoggettoIdCollection;
    }

    protected boolean collegateAbilitatiMotivsExists(final Long soggettoId, final String motivCausale) {
        boolean isCAMExists = false;
        try {
            final String[] motivArray = new AbilitatiMotivHelper().getTipoCollegamentoArray(new TipoSoggettoHandler().getTipoSoggetto(soggettoId));
            if (motivArray != null) {
                final int motivArraySize = motivArray.length;
                for (int i = 0; i < motivArraySize; i++) {
                    if (motivCausale.equals(motivArray[i])) {
                        isCAMExists = true;
                        break;
                    }
                }
            }
        } catch (final GestoreAnagrafeException e) {
            log4Debug.severeStackTrace(e);
        } catch (final RemoteException e) {
            log4Debug.severeStackTrace(e);
        }
        return isCAMExists;
    }
}

