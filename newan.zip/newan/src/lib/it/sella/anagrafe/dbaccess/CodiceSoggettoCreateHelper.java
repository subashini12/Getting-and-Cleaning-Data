package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.az.CodiceSoggettoAZView;
import it.sella.anagrafe.codicisoggetto.ICodiciSoggettoBeanManager;
import it.sella.anagrafe.discriminator.CodiceSoggettoDiscriminatorException;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.implementation.IView;
import it.sella.anagrafe.pf.CodiceSoggettoPFView;
import it.sella.anagrafe.pl.CodiceSoggettoPLView;
import it.sella.anagrafe.util.ReflectionUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Iterator;

public class CodiceSoggettoCreateHelper extends CSCifratiCreateHelper {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CodiceSoggettoCreateHelper.class);

    public void createCodiciSoggetto(final Long soggettoId, final IView iView) throws CodiceSoggettoDiscriminatorException, RemoteException {
        try {
            it.sella.anagrafe.codicisoggetto.CodiciSoggettoView datiView = null; //new it.sella.anagrafe.codicisoggetto.CodiciSoggettoView();
            String currentProperty = null;
            Long classificazioneId = null;
            final Long parentClassificazioneId = ClassificazioneHandler.getClassificazioneParentId("CSDPF");
            final ICodiciSoggettoBeanManager manager = ((ICodiciSoggettoBeanManager) ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.CodiciSoggetto"));
            final String ndgValue = new CodiceSoggettoFinder().findByMaxNDG();
            final Collection collCausale = iView.getCausaleListFromViewProperties();
            final int collCausaleSize = collCausale.size();
            final Iterator iterator = collCausale.iterator();
            for (int i = 0; i < collCausaleSize; i++) {
            	datiView = new it.sella.anagrafe.codicisoggetto.CodiciSoggettoView();
                currentProperty = (String) iterator.next();
                classificazioneId = ClassificazioneHandler.getClassificazioneChildId(currentProperty, parentClassificazioneId);
                datiView.setSoggettoId(soggettoId);
                Object object = null;
                if("ndg".equals(currentProperty)) {
                    object = ndgValue;
                } else {
                    object = iView.getValueForThisProperty(currentProperty);
                }    
                if (object != null) {
					if("codiceHost".equals(currentProperty) && object.toString().length() == 8) {
						datiView.setValue("0"+object.toString());
					} else {
						datiView.setValue(object.toString());
					}
                    datiView.setRightPk(classificazioneId);
                    datiView.setOpId(iView.getOpId());
                    manager.create(datiView);
                }
            }
            // This logic only used for Busta calling in CensimentoPF and CensimentoAZ
            if( iView instanceof CodiceSoggettoPFView ) {
            	((CodiceSoggettoPFView) iView).setNdg(ndgValue);
			} else if( iView instanceof CodiceSoggettoAZView ) {
				((CodiceSoggettoAZView) iView).setNdg(ndgValue);
			} else if( iView instanceof CodiceSoggettoPLView ) {
				((CodiceSoggettoPLView) iView).setNdg(ndgValue);
			}
        } catch (final GestoreAnagrafeException fe) {
            log4Debug.warnStackTrace(fe);
            throw new CodiceSoggettoDiscriminatorException(fe.getLocalizedMessage());
        } catch (final InvocationTargetException ie) {
            log4Debug.warnStackTrace(ie);
            throw new CodiceSoggettoDiscriminatorException(ie.getLocalizedMessage());
        } catch (final IllegalAccessException ae) {
            log4Debug.warnStackTrace(ae);
            throw new CodiceSoggettoDiscriminatorException(ae.getLocalizedMessage());
        } catch (final NoSuchMethodException me) {
            log4Debug.warnStackTrace(me);
            throw new CodiceSoggettoDiscriminatorException(me.getLocalizedMessage());
        }
    }
}


