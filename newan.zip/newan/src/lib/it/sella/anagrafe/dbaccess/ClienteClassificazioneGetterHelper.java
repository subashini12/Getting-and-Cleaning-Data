package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.UtilHelper;
import it.sella.anagrafe.view.ClienteClassificazioneHistoryView;
import it.sella.anagrafe.view.ClienteClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class ClienteClassificazioneGetterHelper extends DBAccessHelper {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(
			ClienteClassificazioneGetterHelper.class);
	
	public ClienteClassificazioneView getClienteClassificazioneBySoggetto( final Long soggettoId )
		throws GestoreAnagrafeException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ClienteClassificazioneView classificazioneView = null;
		try {
			final StringBuilder query = new StringBuilder("SELECT CC_ID, CC_CONSUMATORE, CC_CLIENTE_AL_DETTAGLIO, ");
			 query.append("CC_DATA_INSERIMENTO,CC_MICROIMPRESE FROM AN_TR_CLIENT_CLASSIFICAZIONE ");
			 query.append("WHERE CC_SOGGETTO_ID = ?");
		
			connection = getConnection();
			preparedStatement = connection.prepareStatement(query.toString());
			preparedStatement.setLong(1, soggettoId);
			log4Debug.debug("ClienteClassificazioneGetterHelper: getClienteClassificazioneBySoggetto: query:===>>",query);
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				classificazioneView = new ClienteClassificazioneView();
				classificazioneView.setId(resultSet.getLong("CC_ID"));
				classificazioneView.setConsumatore(resultSet.getString("CC_CONSUMATORE"));
				classificazioneView.setClienteAlDettaglio(resultSet.getString("CC_CLIENTE_AL_DETTAGLIO"));
				classificazioneView.setDataInserimento(resultSet.getTimestamp("CC_DATA_INSERIMENTO"));
				classificazioneView.setMicroimpresa(resultSet.getString("CC_MICROIMPRESE"));
				classificazioneView.setSoggettoId(soggettoId);
			}
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} finally {
			cleanup(connection, preparedStatement, resultSet);
		}
		return classificazioneView;
	}
	
	public List<ClienteClassificazioneView> getClienteClassificazione( final Long soggettoId )
		throws GestoreAnagrafeException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ClienteClassificazioneView classificazioneView = null;
		final List<ClienteClassificazioneView> clientClassList = new ArrayList<ClienteClassificazioneView>(1);
		try {
			final StringBuilder query = new StringBuilder("SELECT CC_ID, CC_CONSUMATORE, CC_CLIENTE_AL_DETTAGLIO, ");
			 query.append("CC_DATA_INSERIMENTO,CC_MICROIMPRESE FROM AN_TR_CLIENT_CLASSIFICAZIONE ");
			 query.append("WHERE CC_SOGGETTO_ID = ?");
		
			connection = getConnection();
			preparedStatement = connection.prepareStatement(query.toString());
			preparedStatement.setLong(1, soggettoId);
			log4Debug.debug("ClienteClassificazioneGetterHelper: getClienteClassificazione: query:===>>",query);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				classificazioneView = new ClienteClassificazioneView();
				classificazioneView.setId(resultSet.getLong("CC_ID"));
				classificazioneView.setConsumatore(resultSet.getString("CC_CONSUMATORE"));
				classificazioneView.setClienteAlDettaglio(resultSet.getString("CC_CLIENTE_AL_DETTAGLIO"));
				classificazioneView.setDataInserimento(resultSet.getTimestamp("CC_DATA_INSERIMENTO"));
				classificazioneView.setMicroimpresa(resultSet.getString("CC_MICROIMPRESE"));
				classificazioneView.setSoggettoId(soggettoId);
				clientClassList.add(classificazioneView);
			}
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} finally {
			cleanup(connection, preparedStatement, resultSet);
		}
		return clientClassList;
	}

	public String getClienteAlDettaglio(final String settore,
			final BigDecimal fatturato, final Long numeroDipendenti,
			final BigDecimal bilancio) throws GestoreAnagrafeException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		try {
			log4Debug.debug("ClienteClassificazioneGetterHelper: getClienteAlDettaglio: settore:===>>",settore);
			log4Debug.debug("ClienteClassificazioneGetterHelper: getClienteAlDettaglio: fatturato:===>>",fatturato);
			log4Debug.debug("ClienteClassificazioneGetterHelper: getClienteAlDettaglio: bilancio:===>>",bilancio);
			log4Debug.debug("ClienteClassificazioneGetterHelper: getClienteAlDettaglio: numeroDipendenti:===>>",numeroDipendenti);
			connection = getConnection();
			callableStatement = connection
					.prepareCall("{CALL ? := AN_FN_CLIENTE_AL_DETTAGLIO(?,?,?,?)}");
			callableStatement.registerOutParameter(1, Types.NUMERIC);
			callableStatement.setString(2, settore);
			checkForNullAndSetBigDecimalValue(callableStatement, fatturato, 3);
			checkForNullAndSetLongValue(callableStatement, numeroDipendenti, 4);
			checkForNullAndSetBigDecimalValue(callableStatement, bilancio, 5);
			callableStatement.execute();
			return callableStatement.getString(1);
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} finally {
			cleanup(connection, callableStatement);
		}
	}
	
	
	public List<ClienteClassificazioneHistoryView> getClienteClassificazioneHistory(final Long soggettoId) throws GestoreAnagrafeException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ClienteClassificazioneHistoryView classificazioneHistoryView = null;
		final List<ClienteClassificazioneHistoryView> clientClassList = new ArrayList<ClienteClassificazioneHistoryView>(1);
		try {
			final StringBuilder query = new StringBuilder("SELECT DATE_OF_OPERATION,NUMERO_DIPENDENTI,FATTURATO,BILANCIO,CONSUMATORE,CLIENTE_AL_DETTAGLIO, ");
			 query.append("MICROIMPRESE FROM TABLE(AN_FN_CLIENTE_CLASSI_HISTORY(?)) ORDER BY DATE_OF_OPERATION DESC ");
		
			connection = getConnection();
			preparedStatement = connection.prepareStatement(query.toString());
			preparedStatement.setLong(1, soggettoId);
			log4Debug.debug("ClienteClassificazioneGetterHelper: getClienteClassificazione: query:===>>",query);
			resultSet = preparedStatement.executeQuery();
			final DateHandler dateHandler =new DateHandler();
			while (resultSet.next()) {
				classificazioneHistoryView = new ClienteClassificazioneHistoryView();
				classificazioneHistoryView.setDateOfOperation(dateHandler.getDateSpecifiedFormat(resultSet.getDate("DATE_OF_OPERATION"), "dd/MM/yyyy"));
				classificazioneHistoryView.setNumeroDipendenti(UtilHelper.getLongValue(resultSet.getString("NUMERO_DIPENDENTI")));
				classificazioneHistoryView.setFatturato(UtilHelper.getBigDecimalValue(resultSet.getString("FATTURATO")));
				classificazioneHistoryView.setBilancio(UtilHelper.getBigDecimalValue(resultSet.getString("BILANCIO")));
				classificazioneHistoryView.setConsumatore(resultSet.getString("CONSUMATORE"));
				classificazioneHistoryView.setClienteAlDettaglio(resultSet.getString("CLIENTE_AL_DETTAGLIO"));
				classificazioneHistoryView.setMicroimpresa(resultSet.getString("MICROIMPRESE"));
				clientClassList.add(classificazioneHistoryView);
			}
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} finally {
			cleanup(connection, preparedStatement, resultSet);
		}
		return clientClassList;
	}
}
