package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.az.CodiceSoggettoAZView;
import it.sella.anagrafe.codicisoggetto.ICodiciSoggettoBeanManager;
import it.sella.anagrafe.discriminator.CodiceSoggettoDiscriminatorException;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.implementation.IView;
import it.sella.anagrafe.pf.CodiceSoggettoPFView;
import it.sella.anagrafe.pl.CodiceSoggettoPLView;
import it.sella.anagrafe.util.ReflectionUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.ejb.FinderException;

public class CodiceSoggettoFinder extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CodiceSoggettoFinder.class);

    public Long findByNDGNonOperativa(final IView iView) throws CodiceSoggettoDiscriminatorException, RemoteException {
        Long parentClassificazioneId = null;
        it.sella.anagrafe.codicisoggetto.CodiciSoggetto codiciSoggetto = null;
        try {
            parentClassificazioneId = ClassificazioneHandler.getClassificazioneParentId("CSDPF");
            final String currentProperty = "ndg";
            final Long rightPK = ClassificazioneHandler.getClassificazioneChildId(currentProperty, parentClassificazioneId);
            
            if(iView instanceof CodiceSoggettoPFView)
            {
            	codiciSoggetto = ((ICodiciSoggettoBeanManager) getCodiceSoggettoManager()).findByNDGNonOperativa(((CodiceSoggettoPFView) iView).getNdg(), rightPK);
            }
            else if (iView instanceof CodiceSoggettoPLView)
            {
            	codiciSoggetto = ((ICodiciSoggettoBeanManager) getCodiceSoggettoManager()).findByNDGNonOperativa(((CodiceSoggettoPLView) iView).getNdg(), rightPK);
            }
            else
            {
            	codiciSoggetto = ((ICodiciSoggettoBeanManager) getCodiceSoggettoManager()).findByNDGNonOperativa(((CodiceSoggettoAZView) iView).getNdg(), rightPK);
            }
            
        } catch (final FinderException re) {
            log4Debug.warnStackTrace(re);
            throw new CodiceSoggettoDiscriminatorException(re.getLocalizedMessage());
        } catch (final GestoreAnagrafeException ne) {
            log4Debug.warnStackTrace(ne);
            throw new CodiceSoggettoDiscriminatorException(ne.getLocalizedMessage());
        } 
        return codiciSoggetto.getSoggettoId();
    }

	private Object getCodiceSoggettoManager() throws GestoreAnagrafeException {
		return ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.CodiciSoggetto");
	}

    protected String findByMaxNDG() throws CodiceSoggettoDiscriminatorException {
        Connection connection = null;
        PreparedStatement maxStatement = null;
        ResultSet maxResultSet = null;
        String maxNDG = null;
        try {
            connection = getConnection();
            maxStatement = connection.prepareStatement("select an_fn_ndggeneration from dual");
            maxResultSet = maxStatement.executeQuery();
            if (maxResultSet.next()) {
				maxNDG = maxResultSet.getString(1);
			}
        } catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new CodiceSoggettoDiscriminatorException(se.getLocalizedMessage());
        } finally {
            cleanup(connection, maxStatement, maxResultSet);
        }
        return maxNDG;
    }
    
}


