package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.anagrafe.OperazioneAnagrafeFactory;
import it.sella.anagrafe.OperazioneAnagrafeManager;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.UpdateAMMBAScanView;
import it.sella.anagrafe.collegamento.CollegamentoView;
import it.sella.anagrafe.discriminator.CollegamentoException;
import it.sella.anagrafe.hostlog.LogOperationDataView;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.anagrafe.util.MapperHelperException;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Iterator;

public class AmministratoriBancaUpdateHelper extends AmministratoriBancaHostUpdateHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AmministratoriBancaUpdateHelper.class);

    public String updateAmministratoriBanca( final Long soggettoId,  
    		final ClassificazioneView classificazioneView,  final String codiceHost,  
    		final Collection existingCausales,  final Long opId,final boolean isHostCodeFromSecurity ) throws OperazioneAnagrafeManagerException, RemoteException {
        try {
        	updateAmministratoreBancaInH2o(soggettoId,classificazioneView,existingCausales,opId);
			final String selectedCausale = classificazioneView != null ? classificazioneView.getCausale() : null;
			return updateAmministratoreBancaInHost(soggettoId,codiceHost,selectedCausale,isHostCodeFromSecurity);
        } catch (final NumberFormatException e) {
            log4Debug.warnStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage());
        } catch (final MapperHelperException e) {
            log4Debug.warnStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage() + " From Mapper");
        } catch (final GestoreCodiciSoggettoException e) {
            log4Debug.warnStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage() + " From Mapper");
		} 
    }

    public  void updateAmministratoreBancaInH2o( final Long soggettoId,  final ClassificazioneView classificazioneView,  final Collection existingCausales,  final Long opId ) throws OperazioneAnagrafeManagerException, RemoteException {
    	try {
			boolean toInsertNewMotiv = true;
			final String selectedCausale = classificazioneView != null ? classificazioneView.getCausale() : null;
			final Long bancaId = SecurityHandler.getLoginBancaId();
			//final Timestamp currentDate = new Timestamp(System.currentTimeMillis());
			if( existingCausales != null ) {
				final Iterator iterator = existingCausales.iterator();
				final int size = existingCausales.size();
			    for( int i=0;i<size;i++ ) {
			    	final String existingCausale = ((ClassificazioneView)iterator.next()).getCausale();
			        if( existingCausale.equals(selectedCausale) ) {
			        	toInsertNewMotiv = false;
			        } else {
			        	// new CollegamentoDBAccessHelper().setCollegamento(bancaId, soggettoId, currentDate ,existingCausale,opId);
			        	new CollegamentoDBAccessHelper().removeCollegamento(bancaId, soggettoId, existingCausale, opId);
			        }
			    }
			}
			if( selectedCausale != null && toInsertNewMotiv ) {
			    final CollegamentoView collegamentoView = new CollegamentoView();
			    collegamentoView.setSoggettoId(bancaId);
			    collegamentoView.setMotivo(classificazioneView.getId());
			    collegamentoView.setLinkedSoggettoId(soggettoId);
			    collegamentoView.setOpId(opId);
			    new CollegamentoDBAccessHelper().createCollegamento(collegamentoView);
			}
		} catch (final SubSystemHandlerException e) {
            log4Debug.warnStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage());
		} catch (final CollegamentoException e) {
            log4Debug.warnStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage());
		}
    }
    
    public void updateAmministratoriBancaInHost( final UpdateAMMBAScanView updateAMMBAScanView, 
    		final String hostUserCode,final boolean isHostCodeFromSecurity ) throws OperazioneAnagrafeManagerException, RemoteException {
        try {
        	if( updateAMMBAScanView != null ) {
        		
        		final String mapperMessage = updateAmministratoreBancaInHostThroughFlussi( updateAMMBAScanView, hostUserCode,isHostCodeFromSecurity);
				log4Debug.debug(" AmministratoriBancaUpdateHelper : updateAmministratoriBancaInHost : mapperMessage:>>",mapperMessage);
				log4Debug.debug(" AmministratoriBancaUpdateHelper : updateAmministratoriBancaInHost : getOpId:>>",updateAMMBAScanView.getOpId());
				final OperazioneAnagrafeManager operazioneAnagrafeManager = OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager();
				if( updateAMMBAScanView.getOpId() != null && mapperMessage != null &&
						mapperMessage.trim().length() > 0 ) {
					operazioneAnagrafeManager.createLogHOSTOperationData( getLogOperationDataView(updateAMMBAScanView.getOpId(), mapperMessage) );
				}
				log4Debug.debug(" AmministratoriBancaUpdateHelper : updateAmministratoriBancaInHost : After HostOperation:>>");
				operazioneAnagrafeManager.updateExtendArt136ScanStatus( updateAMMBAScanView);
        	}
        } catch (final GestoreCodiciSoggettoException e) {
            log4Debug.warnStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage() + " From Mapper");
		} catch (final SubSystemHandlerException e) {
            log4Debug.warnStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage());
		} 
    }

    private LogOperationDataView getLogOperationDataView( final Long opId, final String mapperMessage ) {
    	final LogOperationDataView logOperationDataView = new LogOperationDataView();
    	log4Debug.debug(" AmministratoriBancaUpdateHelper :  getLogOperationDataView : opId :",opId);
    	logOperationDataView.setHostCallViewPK(opId);
    	logOperationDataView.setMapperMessage(mapperMessage != null ? mapperMessage : " ");
    	logOperationDataView.setXmlOperation(" ");
    	return logOperationDataView;
    }
}
