package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.CodiceSoggettoAltriTipiView;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.az.CodiceSoggettoAZView;
import it.sella.anagrafe.discriminator.CodiceSoggettoDiscriminatorException;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.implementation.IView;
import it.sella.anagrafe.pf.CodiceSoggettoPFView;
import it.sella.anagrafe.pl.CodiceSoggettoPLView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CodiceSoggettoPFViewBuilder extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CodiceSoggettoPFViewBuilder.class);

    public IView getCodiciSoggettoPFView(final Long soggettoId) throws CodiceSoggettoDiscriminatorException, RemoteException {
        IView iView = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            String causale = null;
            connection = getConnection();
            final String typeOfSoggetto = new TipoSoggettoHandler().getTipoSoggetto(soggettoId);
            preparedStatement = connection.prepareStatement("select CS_VALUE, CS_RIGHT_PK from AN_TR_CODICISOGGETTO where CS_SOGGETTO_ID = ? ");
            preparedStatement.setLong(1, soggettoId.longValue());
            resultSet = preparedStatement.executeQuery();
            if ("Semplice".equals(typeOfSoggetto)) {
                CodiceSoggettoPFView codiceSoggettoPFView = null;
                while (resultSet.next()) {
                    if (codiceSoggettoPFView == null) {
						codiceSoggettoPFView = new CodiceSoggettoPFView();
					}
                    causale = ClassificazioneHandler.getClassificazioneView(Long.valueOf(resultSet.getLong("CS_RIGHT_PK"))).getCausale();
                    codiceSoggettoPFView.setValueForThisProperty(causale, resultSet.getString("CS_VALUE"));
                }
                iView = codiceSoggettoPFView;
            } else if ("Plurintestazione".equals(typeOfSoggetto)) {
                CodiceSoggettoPLView codiceSoggettoPLView = null;
                while (resultSet.next()) {
                    if (codiceSoggettoPLView == null) {
						codiceSoggettoPLView = new CodiceSoggettoPLView();
					}
                    causale = ClassificazioneHandler.getClassificazioneView(Long.valueOf(resultSet.getLong("CS_RIGHT_PK"))).getCausale();
                    codiceSoggettoPLView.setValueForThisProperty(causale, resultSet.getString("CS_VALUE"));
                }
                iView = codiceSoggettoPLView;
            } else if ("UNITA' ORGANIZZATIVA".equals(new TipoSoggettoHandler().getParentTipoSoggetto(soggettoId))) {
                CodiceSoggettoAltriTipiView codiceSoggettoAltriTipiView = null;
                while (resultSet.next()) {
                    if (codiceSoggettoAltriTipiView == null) {
						codiceSoggettoAltriTipiView = new CodiceSoggettoAltriTipiView();
					}
                    causale = ClassificazioneHandler.getClassificazioneView(Long.valueOf(resultSet.getLong("CS_RIGHT_PK"))).getCausale();
                    codiceSoggettoAltriTipiView.setValueForThisProperty(causale, resultSet.getString("CS_VALUE"));
                }
                iView = codiceSoggettoAltriTipiView;
            } else {
                CodiceSoggettoAZView codiceSoggettoAZView = null;
                while (resultSet.next()) {
                    if (codiceSoggettoAZView == null) {
						codiceSoggettoAZView = new CodiceSoggettoAZView();
					}
                    causale = ClassificazioneHandler.getClassificazioneView(Long.valueOf(resultSet.getLong("CS_RIGHT_PK"))).getCausale();
                    codiceSoggettoAZView.setValueForThisProperty(causale, resultSet.getString("CS_VALUE"));
                }
                iView = codiceSoggettoAZView;
            }
        } catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new CodiceSoggettoDiscriminatorException(se.getLocalizedMessage());
        } catch (final GestoreAnagrafeException ce) {
            log4Debug.warnStackTrace(ce);
            throw new CodiceSoggettoDiscriminatorException(ce.getLocalizedMessage());
        } catch (final InvocationTargetException ie) {
            log4Debug.warnStackTrace(ie);
            throw new CodiceSoggettoDiscriminatorException(ie.getLocalizedMessage());
        } catch (final IllegalAccessException ae) {
            log4Debug.warnStackTrace(ae);
            throw new CodiceSoggettoDiscriminatorException(ae.getLocalizedMessage());
        } catch (final NoSuchMethodException me) {
            log4Debug.warnStackTrace(me);
            throw new CodiceSoggettoDiscriminatorException(me.getLocalizedMessage());
        } catch (final InstantiationException ie) {
            log4Debug.warnStackTrace(ie);
            throw new CodiceSoggettoDiscriminatorException(ie.getLocalizedMessage());
        } catch (final ClassNotFoundException cnfe) {
            log4Debug.warnStackTrace(cnfe);
            throw new CodiceSoggettoDiscriminatorException(cnfe.getLocalizedMessage());
        } finally {
            cleanup(connection, preparedStatement, resultSet);
        }
        return iView;
    }
}


