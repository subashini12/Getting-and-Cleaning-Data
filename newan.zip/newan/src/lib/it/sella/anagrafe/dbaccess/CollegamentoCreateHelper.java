package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreAnagrafeFactory;
import it.sella.anagrafe.GestoreCollegamentoException;
import it.sella.anagrafe.collegamento.Collegamento;
import it.sella.anagrafe.collegamento.CollegamentoView;
import it.sella.anagrafe.collegamento.ICollegamentoBeanManager;
import it.sella.anagrafe.discriminator.CollegamentoException;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.PortafogliazioneClientelaAccessHelper;
import it.sella.anagrafe.util.ReflectionUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;

import javax.ejb.FinderException;

public class CollegamentoCreateHelper extends DBAccessHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CollegamentoCreateHelper.class);

    public Long createCollegamento( final it.sella.anagrafe.CollegamentoView collegamentoView ) throws GestoreCollegamentoException, RemoteException {
        Long collegamentoId = null;
        try {
            final Long motivoCollagamentoId = getClassificazioneIdFromCausale(collegamentoView.getMotivoCausale(), "MOTIV");
            final it.sella.anagrafe.collegamento.CollegamentoView collView = new it.sella.anagrafe.collegamento.CollegamentoView();
            collView.setSoggettoId(collegamentoView.getSoggettoPrincipaleId());
            collView.setLinkedSoggettoId(collegamentoView.getLinkedSoggettoId());
            collView.setMotivo(motivoCollagamentoId);
            collView.setDataInizio(collegamentoView.getDataInizio());
            collView.setDataFine(collegamentoView.getDataFine());
            collView.setNote(collegamentoView.getNote());
            collView.setOpId(collegamentoView.getOpId());
            collegamentoId = createCollegamento(collView);
        }  catch (final GestoreAnagrafeException ne) {
            log4Debug.severeStackTrace(ne);
            throw new GestoreCollegamentoException(ne.getLocalizedMessage());
        } catch (final CollegamentoException fe) {
            log4Debug.severeStackTrace(fe);
            throw new GestoreCollegamentoException(fe.getLocalizedMessage());
        }
        return collegamentoId;
    }

    public Long createCollegamento( final CollegamentoView collegamentoView ) throws CollegamentoException, RemoteException {
    	Long collegamentoId = null;
    	ICollegamentoBeanManager collegamentoBeanManager =null;
    	try {
    		collegamentoBeanManager = ((ICollegamentoBeanManager) getCollegamento());
    		collegamentoBeanManager.findBySoggettoMotivoAndLinked(collegamentoView.getSoggettoId(), collegamentoView.getMotivo(), collegamentoView.getLinkedSoggettoId());
    	} catch (final FinderException ne) {
    		try {
    			if (collegamentoView.getDataInizio() == null) {
    				collegamentoView.setDataInizio(new DateHandler().getCurrentDateInTimeStampFormat());
    			}
    			final Collegamento collegamento = collegamentoBeanManager.create(collegamentoView);
    			collegamentoId =collegamento.getCollegamentoId();
    			// Code to align Portofoglizione for Promotore call made through XML, Application , BIBO , Admin and other process where insertion in Anagrafe done
    			log4Debug.debug("collegamentoView.getMotivo()===============",collegamentoView.getMotivo());
    			log4Debug.debug("collegamentoView.getMotivo()===============",collegamentoView.getMotivo().equals(getClassificazioneIdFromCausale("PROCT", "MOTIV")));
    			if(collegamentoView.getMotivo() != null && collegamentoView.getMotivo().equals(getClassificazioneIdFromCausale("PROCT", "MOTIV")))
    			{
    				final Long soggettoId = collegamentoView.getSoggettoId() ; //customer soggetto
    				final Long promoId = collegamentoView.getLinkedSoggettoId(); // Promotore Soggetto
    				log4Debug.debug("soggettoId===============",soggettoId);
    				log4Debug.debug("promoId===============",promoId);
    				// Code to check is the creation process , so we invoke our Own API to check and if Null we expect as Censimento
    				Collection<Long>principaleId = GestoreAnagrafeFactory.getInstance().getGestoreAnagrafe().getSoggettoPrincipale(soggettoId, "CENST");
    				log4Debug.debug("principaleIdColl===============",principaleId);
    				if(principaleId != null){
    					log4Debug.debug("================Called From Colleaget Create============");
    					new PortafogliazioneClientelaAccessHelper().registerClientWithPromoter(soggettoId,promoId);
    				}
    			}
    		} catch (final GestoreAnagrafeException e) {
    			log4Debug.severeStackTrace(e);
    			throw new CollegamentoException(e.getLocalizedMessage());
    		}
    	}catch (final GestoreAnagrafeException e) {
    		log4Debug.severeStackTrace(e);
    		throw new CollegamentoException(e.getLocalizedMessage());
    	}
    	return collegamentoId;
    }

	private Object getCollegamento() throws GestoreAnagrafeException {
		return ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.Collegamento");
	}
}

