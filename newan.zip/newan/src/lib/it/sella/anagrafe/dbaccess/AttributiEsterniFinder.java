package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.discriminator.AttributiEsterniDiscriminatorException;
import it.sella.anagrafe.util.SmartRicercaResultPFViewCollection;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;

public class AttributiEsterniFinder extends DBAccessHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AttributiEsterniFinder.class);

    public Collection findByStato(final Collection soggettiIdColl, final String stato) throws AttributiEsterniDiscriminatorException, RemoteException {
        final SmartRicercaResultPFViewCollection smartColl = new SmartRicercaResultPFViewCollection();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            if (soggettiIdColl != null) {
                final int soggettoIdCollSize = soggettiIdColl.size();
                if (!soggettiIdColl.isEmpty()) {
                    final Iterator it = soggettiIdColl.iterator();
                    preparedStatement = connection.prepareStatement("Select AE_SOGGETTO_ID from AN_TR_ATTRIBUTIESTERNI where AE_SOGGETTO_ID = ? and AE_VALUE = ? ");
                    for (int i = 0; i < soggettoIdCollSize; i++) {
                        final Long tipoDatiAnagraficiId = (Long) it.next();
                        preparedStatement.setLong(1, tipoDatiAnagraficiId.longValue());
                        preparedStatement.setString(2, stato);
                        resultSet = preparedStatement.executeQuery();
                        while (resultSet.next()) {
                            final Long id = Long.valueOf(resultSet.getLong("AE_SOGGETTO_ID"));
                            smartColl.add(id.toString());
                        }
                        closeResultSet(resultSet);
                        preparedStatement.clearParameters();
                    }
                }
            }
        } catch (final SQLException se) {
            log4Debug.severeStackTrace(se);
            throw new AttributiEsterniDiscriminatorException(se.getLocalizedMessage());
        } finally {
            cleanup(connection, preparedStatement, resultSet);
        }
        return smartColl;
    }
    
}


