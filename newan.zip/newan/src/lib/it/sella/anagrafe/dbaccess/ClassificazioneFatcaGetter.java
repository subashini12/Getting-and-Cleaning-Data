package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.az.FatcaAZView;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

public class ClassificazioneFatcaGetter extends DBAccessHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(ClassificazioneFatcaGetter.class);

	/**
	 * This Method Return the FATCA Automatica Calculated Collection by taking the input details : Nazione Di Constitizione,Sede legale Nazione, Sede Admin nazione, settore, Residenza Fiscali, onlus
	 * @param inputDetails
	 * @return
	 * @throws GestoreAnagrafeException
	 * Collection<FatcaAZView>
	 */
	public Collection<FatcaAZView> getFatcaCalculatedAutomatica(final Map inputDetails) throws GestoreAnagrafeException {
		final Collection<FatcaAZView> fatcaConfermataList = new ArrayList<FatcaAZView>();
		Connection connection = null;
		PreparedStatement selectStatement = null;
		ResultSet fatcaResultSet = null;
		final String fatcaQuery = getFatcaCalculatedAutomaticaQuery(inputDetails);
		log4Debug.debug("ClassificazioneFatcaGetter ======  getFatcaCalculatedAutomatica =====  fatcaQuery ====== ", fatcaQuery);
		try {
			connection = getConnection();
			selectStatement = connection.prepareStatement(fatcaQuery);
			setDataInSelectStatement(inputDetails, selectStatement);
			fatcaResultSet = selectStatement.executeQuery();
			while (fatcaResultSet.next()) {
				final FatcaAZView fatcaView = new FatcaAZView();
				fatcaView.setFatca(ClassificazioneHandler.getClassificazioneView(fatcaResultSet.getLong("FS_FATCA_CLASS_ID")));
				fatcaView.setBustaStampaAllowed("Y".equals(fatcaResultSet.getString("FS_IS_BUSTA_STAMPA_ALLOWED")) ? true : false);
				fatcaView.setGiinMandatory("Y".equals(fatcaResultSet.getString("FS_IS_GIIN_MANDATE")) ? true : false);
				fatcaView.setXmlTag(fatcaResultSet.getString("FS_XML_TAG"));
				fatcaConfermataList.add(fatcaView);
			}
		} catch (SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} catch (RemoteException e) {
			log4Debug.severeStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} catch (SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} finally {
			cleanup(connection, selectStatement, fatcaResultSet);
		}
		return fatcaConfermataList;
	}
	
	/**
	 * This Method Returns the Compatible FATCA Details for the corresponding input TipoSoggetto
	 * @param tipoSoggetto
	 * @return
	 * @throws GestoreAnagrafeException
	 * Collection<FatcaAZView>
	 */
	public Collection<FatcaAZView> getAZClassificazioneFatca(final String tipoSoggetto) throws GestoreAnagrafeException {
		final Collection<FatcaAZView> fatcaConfermataList = new ArrayList<FatcaAZView>();
		Connection connection = null;
		PreparedStatement selectStatement = null;
		ResultSet fatcaResultSet = null;
		final StringBuffer fatcaCalQuery = new StringBuffer();
		fatcaCalQuery.append("SELECT ST.FT_CLASS_ID, FS.FS_IS_BUSTA_STAMPA_ALLOWED, FS.FS_IS_GIIN_MANDATE, FS.FS_XML_TAG ");
		fatcaCalQuery.append("FROM AN_MA_COMP_FATCA_STATUS_TIPO ST, AN_MA_COMPAT_FATCA_AZ_STAMPA FS, CL_VW_CLASSIFICAZIONE CV ");
		fatcaCalQuery.append("WHERE ST.FT_TIPO_SOGGETTO = ? and ST.FT_CLASS_ID = FS.FS_FATCA_CLASS_ID ");
		fatcaCalQuery.append("AND ST.FT_CLASS_ID = CV.CL_ID ORDER BY (CASE CV.CL_CAUSALE WHEN 'NC' THEN '' ELSE CL_CAUSALE END)");// Order By of Causale & NC should be displayed always at the End of the List
		
		try {
			connection = getConnection();
			selectStatement = connection.prepareStatement(fatcaCalQuery.toString());
			selectStatement.setString(1, tipoSoggetto);
			fatcaResultSet = selectStatement.executeQuery();
			while (fatcaResultSet.next()) {
				final FatcaAZView fatcaView = new FatcaAZView();
				fatcaView.setFatca(ClassificazioneHandler.getClassificazioneView(fatcaResultSet.getLong("FT_CLASS_ID")));
				fatcaView.setBustaStampaAllowed("Y".equals(fatcaResultSet.getString("FS_IS_BUSTA_STAMPA_ALLOWED")) ? true : false);
				fatcaView.setGiinMandatory("Y".equals(fatcaResultSet.getString("FS_IS_GIIN_MANDATE")) ? true : false);
				fatcaView.setXmlTag(fatcaResultSet.getString("FS_XML_TAG"));
				fatcaConfermataList.add(fatcaView);
			}
		} catch (SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} catch (RemoteException e) {
			log4Debug.severeStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} catch (SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} finally {
			cleanup(connection, selectStatement, fatcaResultSet);
		}
		return fatcaConfermataList;
	}
	
	private String getFatcaCalculatedAutomaticaQuery(final Map inputDetails){
		final StringBuffer fatcaCalQuery = new StringBuffer();
		if("Y".equals((String) inputDetails.get("NAZIONE_USA"))) {
			
			fatcaCalQuery.append("SELECT DISTINCT FS.FS_FATCA_CLASS_ID, FS.FS_IS_BUSTA_STAMPA_ALLOWED, FS.FS_IS_GIIN_MANDATE, FS.FS_XML_TAG ");
			fatcaCalQuery.append("FROM AN_MA_COMPAT_FATCA_AZ FA, AN_MA_COMPAT_FATCA_AZ_STAMPA FS ");
			fatcaCalQuery.append("WHERE (? IS NULL OR FA.FC_NAZIONE_IS_US = ?) ");
			fatcaCalQuery.append("AND (? IS NULL OR FA.FC_SLE_IS_US = ?) ");
			fatcaCalQuery.append("AND (? IS NULL OR FA.FC_SAM_IS_US = ?) ");
			fatcaCalQuery.append("AND (? IS NULL OR FA.FC_RESFIS_IS_US = ?) ");
			fatcaCalQuery.append("AND FS.FS_FATCA_CLASS_ID = FA.FC_CLASS_ID");
		} else {
			fatcaCalQuery.append("SELECT DISTINCT FS.FS_FATCA_CLASS_ID, FS.FS_IS_BUSTA_STAMPA_ALLOWED, FS.FS_IS_GIIN_MANDATE, FS.FS_XML_TAG ");
			fatcaCalQuery.append("FROM AN_MA_COMPAT_FATCA_AZ FA, AN_MA_COMPAT_FATCA_AZ_STAMPA FS ");
			fatcaCalQuery.append("WHERE (? IS NULL OR FA.FC_NAZIONE_IS_ITALIA = ?) ");
			fatcaCalQuery.append("AND (? IS NULL OR FA.FC_NAZIONE_IS_US = ?) ");
			fatcaCalQuery.append("AND (? IS NULL OR FA.FC_NAZIONE_IS_IGA1 = ?) ");
			fatcaCalQuery.append("AND (? IS NULL OR FA.FC_NAZIONE_IS_IGA2 = ?) ");
			fatcaCalQuery.append("AND (? IS NULL OR FA.FC_SLE_IS_US = ?) ");
			fatcaCalQuery.append("AND (? IS NULL OR FA.FC_SAM_IS_US = ?) ");
			fatcaCalQuery.append("AND (? IS NULL OR FA.FC_RESFIS_IS_US = ?) ");
			fatcaCalQuery.append("AND (? IS NULL OR FA.FC_SETTORE_IS_ALLEAGA_B = ?) ");
			fatcaCalQuery.append("AND (? IS NULL OR FA.FC_SETTORE_IS_ALLEGA_C = ?) ");
			fatcaCalQuery.append("AND (? IS NULL OR FA.FC_SETTORE_IS_ALLEGA_B1 = ?) ");
			fatcaCalQuery.append("AND (FA.FC_SETTORE_IS_EQUAL IS NULL OR (? IS NOT NULL AND FA.FC_SETTORE_IS_EQUAL = ?)) ");
			fatcaCalQuery.append("AND (FA.FC_SETTORE_IS_NOT_EQUAL IS NULL OR (? IS NOT NULL AND FA.FC_SETTORE_IS_NOT_EQUAL <> ?)) ");
			fatcaCalQuery.append("AND (? IS NULL OR (FA.FC_IS_ONLUS = ?) OR FA.FC_IS_ONLUS IS NULL) ");
			fatcaCalQuery.append("AND FS.FS_FATCA_CLASS_ID = FA.FC_CLASS_ID");
		}
		return fatcaCalQuery.toString();
	}
	
	private void setDataInSelectStatement(final Map inputDetails, PreparedStatement selectStatement) throws SQLException {
		
		if("Y".equals((String)inputDetails.get("NAZIONE_USA"))) {
			
			selectStatement.setString(1, (String) inputDetails.get("NAZIONE_USA"));		// Condition 1
			selectStatement.setString(2, (String) inputDetails.get("NAZIONE_USA"));		// Condition 1
			selectStatement.setString(3, (String) inputDetails.get("SLE_USA"));			// Condition 2
			selectStatement.setString(4, (String) inputDetails.get("SLE_USA"));			// Condition 2
			selectStatement.setString(5, (String) inputDetails.get("SAM_USA"));			// Condition 3
			selectStatement.setString(6, (String) inputDetails.get("SAM_USA"));     	// Condition 3
			selectStatement.setString(7, (String) inputDetails.get("RESI_FISCALE_USA"));	// Condition 4
			selectStatement.setString(8, (String) inputDetails.get("RESI_FISCALE_USA"));	// Condition 4
		}else {
			selectStatement.setString(1, (String) inputDetails.get("NAZIONE_ITALIA")); // Condition 1
			selectStatement.setString(2, (String) inputDetails.get("NAZIONE_ITALIA")); // Condition 1
			selectStatement.setString(3, (String) inputDetails.get("NAZIONE_USA"));		// Condition 2
			selectStatement.setString(4, (String) inputDetails.get("NAZIONE_USA"));		// Condition 2
			selectStatement.setString(5, (String) inputDetails.get("NAZIONE_IGA1"));	// Condition 3
			selectStatement.setString(6, (String) inputDetails.get("NAZIONE_IGA1"));	// Condition 3
			selectStatement.setString(7, (String) inputDetails.get("NAZIONE_IGA2"));	// Condition 4
			selectStatement.setString(8, (String) inputDetails.get("NAZIONE_IGA2"));	// Condition 4
			selectStatement.setString(9, (String) inputDetails.get("SLE_USA"));			// Condition 5
			selectStatement.setString(10, (String) inputDetails.get("SLE_USA"));		// Condition 5
			selectStatement.setString(11, (String) inputDetails.get("SAM_USA"));		// Condition 6
			selectStatement.setString(12, (String) inputDetails.get("SAM_USA"));		// Condition 6
			selectStatement.setString(13, (String) inputDetails.get("RESI_FISCALE_USA"));// Condition 7
			selectStatement.setString(14, (String) inputDetails.get("RESI_FISCALE_USA"));// Condition 7
			selectStatement.setString(15, (String) inputDetails.get("SETTORE_ALLEGA_B"));// Condition 8
			selectStatement.setString(16, (String) inputDetails.get("SETTORE_ALLEGA_B"));// Condition 8
			selectStatement.setString(17, (String) inputDetails.get("SETTORE_ALLEGA_C"));// Condition 9
			selectStatement.setString(18, (String) inputDetails.get("SETTORE_ALLEGA_C"));// Condition 9
			selectStatement.setString(19, (String) inputDetails.get("SETTORE_ALLEGA_B1"));// Condition 10
			selectStatement.setString(20, (String) inputDetails.get("SETTORE_ALLEGA_B1"));// Condition 10
			final String settore = (String) inputDetails.get("SETTORE");
			selectStatement.setString(21, settore);// Condition 11
			selectStatement.setString(22, settore);// Condition 11
			selectStatement.setString(23, settore);// Condition 12
			selectStatement.setString(24, settore);// Condition 12
			selectStatement.setString(25, (String) inputDetails.get("ONLUS"));// Condition 13
			selectStatement.setString(26, (String) inputDetails.get("ONLUS"));// Condition 13
		}
	}
	
	/**
	 * This Method Return the FATCA Automatica Based on the TipoSoggetto Id.
	 * @param tipoSoggettoId
	 * @return
	 * @throws GestoreAnagrafeException
	 */
	public Collection<FatcaAZView> getFatcaAutomatocaBasedOnTipoSoggetto(final Long tipoSoggettoId) throws GestoreAnagrafeException {
		final Collection<FatcaAZView> fatcaConfermataList = new ArrayList<FatcaAZView>();
		Connection connection = null;
		PreparedStatement selectStatement = null;
		ResultSet fatcaResultSet = null;
		final StringBuffer fatcaCalQuery = new StringBuffer();
		fatcaCalQuery.append("SELECT T.FT_FATCA_ID, S.FS_IS_BUSTA_STAMPA_ALLOWED, S.FS_IS_GIIN_MANDATE, S.FS_XML_TAG ");
		fatcaCalQuery.append("FROM AN_MA_COMPAT_FATCA_AZ_TIPOSOG T, AN_MA_COMPAT_FATCA_AZ_STAMPA S WHERE T.FT_TIPO_SOGG_ID = ? AND T.FT_FATCA_ID = S.FS_FATCA_CLASS_ID ");
		try {
			connection = getConnection();
			selectStatement = connection.prepareStatement(fatcaCalQuery.toString());
			selectStatement.setLong(1, tipoSoggettoId);
			fatcaResultSet = selectStatement.executeQuery();
			while (fatcaResultSet.next()) {
				final FatcaAZView fatcaView = new FatcaAZView();
				fatcaView.setFatca(ClassificazioneHandler.getClassificazioneView(fatcaResultSet.getLong("FT_FATCA_ID")));
				fatcaView.setBustaStampaAllowed("Y".equals(fatcaResultSet.getString("FS_IS_BUSTA_STAMPA_ALLOWED")) ? true : false);
				fatcaView.setGiinMandatory("Y".equals(fatcaResultSet.getString("FS_IS_GIIN_MANDATE")) ? true : false);
				fatcaView.setXmlTag(fatcaResultSet.getString("FS_XML_TAG"));
				fatcaConfermataList.add(fatcaView);
			}
		} catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} catch (final RemoteException e) {
			log4Debug.warnStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} finally {
			cleanup(connection, selectStatement, fatcaResultSet);
		}
		return fatcaConfermataList;
	}
}
