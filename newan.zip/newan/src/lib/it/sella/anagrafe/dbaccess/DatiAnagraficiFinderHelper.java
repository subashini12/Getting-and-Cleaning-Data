package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.BeanHelperException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.dipendente.RicercaDipendenteView;
import it.sella.anagrafe.discriminator.DatiAnagraficiDiscriminatorException;
import it.sella.anagrafe.pf.DatiAnagraficiPFView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

public class DatiAnagraficiFinderHelper extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DatiAnagraficiFinderHelper.class);

    public Collection findByDatiAnagraficiPF(final DatiAnagraficiPFView datiAnagraficiPFView) throws DatiAnagraficiDiscriminatorException, RemoteException {
        Connection conn = null;
        PreparedStatement ufficioStatement = null;
        ResultSet ufficioResultSet = null;
        Collection soggettoIds = null;
        try {
            conn = getConnection();
            final HashMap properties = new HashMap();
            properties.put("View",datiAnagraficiPFView);
            properties.put("Stato","Operativa");
            soggettoIds = new PFSoggettoIdGetter().getPFSoggettoIdsForInput(properties);
            if (datiAnagraficiPFView instanceof RicercaDipendenteView) {
            	final RicercaDipendenteView ricercaDipendenteView = (RicercaDipendenteView)datiAnagraficiPFView;
                if (ricercaDipendenteView.getUfficio() != null && !soggettoIds.isEmpty()) {
                	final Iterator iterator = soggettoIds.iterator();
                	final int size = soggettoIds.size();
                	Long pfId = null;
                    final ArrayList output = new ArrayList();
                    ufficioStatement = conn.prepareStatement("SELECT CL_SOGGETTO_PRINCIPALE FROM AN_TR_ALTRITIPOSOGGETTO AL, AN_TR_COLLAGAMENTO_SOGGETTO AC where AC.CL_LINKED_SOGGETTO = ? and AC.CL_MOTIVO = ? AND AC.CL_DATA_FINE IS NULL AND AL.AT_SOGGETTO_ID = AC.CL_SOGGETTO_PRINCIPALE AND AL.AT_DENOMINAZIONE LIKE ?");
                    for(int i=0; i<size; i++) {
                    	pfId = (Long)iterator.next();
                        ufficioStatement.setLong(1,pfId.longValue());
                        ufficioStatement.setLong(2,getClassificazioneIdFromCausale("APART","MOTIV").longValue());
                        ufficioStatement.setString(3,ricercaDipendenteView.getUfficio()+"%");
                        ufficioResultSet = ufficioStatement.executeQuery();
                        if(ufficioResultSet.next()) {
							output.add(pfId);
						}
                        closeResultSet(ufficioResultSet);
                        ufficioStatement.clearParameters();
                    }
                    soggettoIds = output;
                } 
            } 
        } catch (final SubSystemHandlerException ne) {
            log4Debug.severeStackTrace(ne);
            throw new DatiAnagraficiDiscriminatorException(ne.getMessage());
        } catch (final SQLException se) {
            log4Debug.severeStackTrace(se);
            throw new DatiAnagraficiDiscriminatorException(se.getMessage());
        } catch (final BeanHelperException se) {
            log4Debug.warnStackTrace(se);
            throw new DatiAnagraficiDiscriminatorException(se.getMessage());
        } finally {
            cleanup(conn, ufficioStatement, ufficioResultSet);
        }
        return soggettoIds;
    }
}
