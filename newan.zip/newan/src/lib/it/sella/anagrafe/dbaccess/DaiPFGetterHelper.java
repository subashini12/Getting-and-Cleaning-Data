package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.DAIPFHelper;
import it.sella.anagrafe.util.HelperException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;

public class DaiPFGetterHelper {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DaiPFGetterHelper.class);

	public String getDaiPFOnAnagrafici( final Long soggettoId ) throws RemoteException, GestoreAnagrafeException {
		final AnagrafeHelper helper = new AnagrafeHelper();
        if ( soggettoId == null ) {
        	throw new GestoreAnagrafeException(helper.getMessage("ANAG-1300"));	
        }
        if ( !"Semplice".equals(new TipoSoggettoHandler().getTipoSoggetto(soggettoId)) ) {
        	throw new GestoreAnagrafeException(helper.getMessage("ANAG-1254"));	
        }
        try {
            return new DAIPFHelper().calculateDaiForPFAnagrafici(soggettoId);
        } catch (final HelperException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreAnagrafeException(e.getMessage());
        }
    }
}


