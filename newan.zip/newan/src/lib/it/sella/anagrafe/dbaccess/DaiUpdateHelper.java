package it.sella.anagrafe.dbaccess;

import it.sella.address.AddressException;
import it.sella.address.AddressView;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.discriminator.AttributiEsterniDiscriminatorException;
import it.sella.anagrafe.discriminator.CollegamentoException;
import it.sella.anagrafe.util.AddressHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class DaiUpdateHelper extends CollegatiAbilitaiDAIHandler {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DaiUpdateHelper.class);

    public void updateDaiForPrincipalIds(final Long pfSoggettoId, final boolean oldDai, final boolean newDai, final Long opId) throws  RemoteException {
        Iterator iterator = null;
        final ArrayList filteredPrincipale = new ArrayList();
        try {
            final Collection abilitatiMotivs = getSoggettiCollegatiAbilitatiMotivs();
            final Collection allPrincipale = getOperazioneAnagrafeManager().getSoggettiColleganti(pfSoggettoId);
            iterator = allPrincipale.iterator();
            final int principaleSize = allPrincipale.size();
            it.sella.anagrafe.CollegamentoView collegamentoView = null;
            for (int i = 0; i < principaleSize; i++) {
                collegamentoView = (it.sella.anagrafe.CollegamentoView) iterator.next();
                final String motiv = collegamentoView.getMotivoCausale();
                if (abilitatiMotivs.contains(motiv)) {
                    filteredPrincipale.add(collegamentoView.getSoggettoPrincipaleId());
                }
            }

            iterator = filteredPrincipale.iterator();
            final int prinSize = filteredPrincipale.size();
            Long id = null;
            final AEUpdateHelper aeHelper = new AEUpdateHelper(); 
            final TipoSoggettoHandler tipoSoggettoHandler = new TipoSoggettoHandler();
            final CollegamentoDBAccessHelper collegamentoDBAccessHelper = new CollegamentoDBAccessHelper();
            final AttributiEsterniDBAccessHelper attributiEsterniDBAccessHelper = new AttributiEsterniDBAccessHelper();
            for (int i = 0; i < prinSize; i++) {
                try {
                    id = (Long) iterator.next();
                    final String soggettoDesc = tipoSoggettoHandler.getTipoSoggetto(id);
                    if ("Plurintestazione".equals(soggettoDesc)) {
                        if (newDai) {
                        	aeHelper.setAttributiEsterniValues(id, "true", "dai", opId);
                        } else {
                            final Collection linkedSoggettos = collegamentoDBAccessHelper.getSoggettiCollegatiAbilitati(id);
                            if (linkedSoggettos != null) {
                                final int size = linkedSoggettos.size();
                                final Iterator linkedIterator = linkedSoggettos.iterator();
                                Long linkedIdToPL = null;
                                for (int j = 0; j < size; j++) {
                                    linkedIdToPL = (Long)linkedIterator.next();
                                    if (!linkedIdToPL.equals(pfSoggettoId)) {
                                        if ("true".equals(attributiEsterniDBAccessHelper.getAttribuiEsterniValore(linkedIdToPL, "dai"))) {
                                        	aeHelper.setAttributiEsterniValues(id, "true", "dai", opId);
                                            break;
                                        } else if (j == (size - 1)) {
                                        	aeHelper.setAttributiEsterniValues(id, "false", "dai", opId);
                                        }
                                    } else if(j == (size - 1)) {
										aeHelper.setAttributiEsterniValues(id, "false", "dai", opId);
									}
                                }
                            }
                        }
                    } else {
                        final String tsDesc = tipoSoggettoHandler.getParentTipoSoggetto(id);
                        if ("AZIENDE".equals(tsDesc)) {
                            if (newDai) {
                            	aeHelper.setAttributiEsterniValues(id, "true", "dai", opId);
                            } else {
                                final AddressView addressView = new AddressHandler().getDefaultPostalAddress(id);
                                if (addressView == null || addressView.getNazione() == null || addressView.getIndirizzo() == null ||
                                        "MANCANTE".equals(addressView.getIndirizzo()) || addressView.getCitta() == null ||
                                        "MANCANTE".equals(addressView.getCitta())) {
                                	aeHelper.setAttributiEsterniValues(id, "true", "dai", opId);
                                    break;
                                }
                                if ("ITALIA".equals(addressView.getNazione()) && addressView.getProvincia() == null) {
                                	aeHelper.setAttributiEsterniValues(id, "true", "dai", opId);
                                    break;
                                }
                                //Dai calculation based on classe is commented now .. it will be used when its need .
								/*if (new DatiAttributiEsterniValidator()
										.isClasseNotExistInMandatorySettore(
												attributiEsterniDBAccessHelper.getAttribuiEsterniValore(id, "settore"),
												attributiEsterniDBAccessHelper.getAttribuiEsterniValore(id, "classe"))) {
									aeHelper.setAttributiEsterniValues(id,"true", "dai", opId);
									break;
								}*/
                                updateDaiForCollegatiAbilitati(id,pfSoggettoId,opId);
                            }
                        }
                    }
                } catch (final AttributiEsterniDiscriminatorException e) {
                    log4Debug.severeStackTrace(e);
                    aeHelper.setAttributiEsterniValues(id, "true", "dai", opId);
                } catch (final GestoreAnagrafeException e) {
                    log4Debug.severeStackTrace(e);
                    aeHelper.setAttributiEsterniValues(id, "true", "dai", opId);
                } catch (final AddressException e) {
                    log4Debug.severeStackTrace(e);
                    aeHelper.setAttributiEsterniValues(id, "true", "dai", opId);
                }
            }
        } catch (final CollegamentoException e) {
        	log4Debug.warnStackTrace(e);
        } catch (final AttributiEsterniDiscriminatorException e) {
        	log4Debug.warnStackTrace(e);
        }
    }

    private Collection getSoggettiCollegatiAbilitatiMotivs() {
        final ArrayList output = new ArrayList();
        output.add("ABIL8CIFRE"); output.add("DELEG"); output.add("TITOL"); output.add("SOCIO");
        output.add("PCDA"); output.add("VCDA"); output.add("MCDA"); output.add("AMMDE"); output.add("AMMUN");
        output.add("PROCU"); output.add("DIRGE"); output.add("SARIO"); output.add("LIQUI"); output.add("CFALL");
        output.add("COMMI"); output.add("AMMCO"); output.add("INTST"); output.add("CURAT");
        output.add("TUTOR");  output.add("ESERC");
        return output;
    }
}


