package it.sella.anagrafe.dbaccess.dai;

import it.sella.anagrafe.AnagrafeDAIException;
import it.sella.anagrafe.DAIConfigException;
import it.sella.anagrafe.DAIConfigView;
import it.sella.anagrafe.DAIPesoException;
import it.sella.anagrafe.DAIRegoleException;
import it.sella.anagrafe.DAISoggettoException;
import it.sella.anagrafe.DAIWeightageException;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.IDAIConfigView;
import it.sella.anagrafe.IDAIPesoView;
import it.sella.anagrafe.IDAIRegoleDetail;
import it.sella.anagrafe.IDAIRegoleDetailsView;
import it.sella.anagrafe.IDAISoggettoData;
import it.sella.anagrafe.IDAIStoricDataView;
import it.sella.anagrafe.IDAIWeightageView;
import it.sella.anagrafe.SoggettoDAIDataView;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Map;

/**
 * @author GBS03447
 *
 */
public class DAIDBAccessHelper {
	
	
	public Collection<IDAIRegoleDetail> getDAIRegoleDetails(final Long soggettoId) throws GestoreAnagrafeException {
		return new DAIRegoleGetterHelper().getDAIRegoleDetails(soggettoId);
	}
	
	public IDAISoggettoData getAnagrafeDAISoggetto (final Long soggettoId) throws GestoreAnagrafeException {
		return new DAISoggettoGetterHelper().getAnagrafeDAISoggetto(soggettoId);
	}
	
	public Collection<IDAIStoricDataView> getStoricoDAI (final Long soggettoId, final String... daiCausale) throws GestoreAnagrafeException, RemoteException {
		return new DAISoggettoGetterHelper().getStoricoDAI(soggettoId, daiCausale);
	}
	
	public DAIConfigView getDAIConfig(final Long configId) throws DAIConfigException {
		return new DAIConfigGetterHelper().getDAIConfig(configId);
	}
	
	public DAIConfigView getDAIConfig(final String configCode) throws DAIConfigException {
		return new DAIConfigGetterHelper().getDAIConfig(configCode);
	}
	
	//Not Used
	public Collection<DAIConfigView> listDAIConfigCodes(final String parentConfigCode) throws DAIConfigException {
		return new DAIConfigGetterHelper().listDAIConfigCodes(parentConfigCode);
	}
	
	public Map<String, Collection<IDAIConfigView>> getCompatibleDAICodesWithGroup (final String tipoSoggetto) throws DAIConfigException {
		return new DAIConfigGetterHelper().getCompatibleDAICodesWithGroup(tipoSoggetto);
	}
	
	public IDAIWeightageView getWeightageViewForId(final Long id) throws DAIWeightageException {
		return new DAIWeightageGetterHelper().getWeightageViewForId(id);
	}
	
	// Not Used
	public IDAIPesoView getPesoViewById(final Long pesoId) throws DAIPesoException {
		return new DAIPesoGetterHelper().getPesoViewById(pesoId);
	}
	
	public Collection<IDAIRegoleDetailsView> getDAIRegoleDetailsForSoggetto(final Long soggettoId) throws DAIRegoleException {
		return new DAIRegoleGetterHelper().getDAIRegoleDetailsForSoggetto(soggettoId);
	}
	
	public void createDAIRegole (final IDAIRegoleDetailsView regoleDetailsView, final Long soggettoId, final Long opId) throws RemoteException, AnagrafeDAIException {
		new AnagrafeDAIUpdateHelper().createDAIRegole(regoleDetailsView, soggettoId, opId);
	}
	
	public void setDAIRegole(final IDAIRegoleDetailsView regoleDetailView, final Long soggettoId, final Long opId) throws RemoteException, AnagrafeDAIException {
		new AnagrafeDAIUpdateHelper().setDAIRegole(regoleDetailView, soggettoId, opId);
	}
	
	public void createDAISoggetto (final SoggettoDAIDataView daiSoggettoView, final Long soggettoId, final Long opId) throws DAISoggettoException, RemoteException  {
		new AnagrafeDAIUpdateHelper().createDAISoggetto(daiSoggettoView, soggettoId, opId);
	}
	
	public void setDAISoggetto(final SoggettoDAIDataView daiSoggettoView, final Long soggettoId, final Long opId) throws DAISoggettoException, RemoteException {
		new AnagrafeDAIUpdateHelper().setDAISoggetto(daiSoggettoView, soggettoId, opId);
	}
	
	public IDAIWeightageView getWeightageViewForCode (final String weightCode) throws DAIWeightageException {
		return new DAIWeightageGetterHelper().getWeightageViewForCode(weightCode);
	}
	
	public IDAIPesoView getPesoView (final Long daiTypeId, final Long daiCodeId) throws DAIPesoException {
		return new DAIPesoGetterHelper().getPesoView(daiTypeId, daiCodeId);
	}
	
	public SoggettoDAIDataView getDAISoggettoView (final Long soggettoId) throws AnagrafeDAIException {
		return new DAISoggettoGetterHelper().getDAISoggettoView(soggettoId);
	}
	
	public IDAIRegoleDetailsView getDAIRegoleForRegoleId(final Long regoleId) throws DAIRegoleException {
		return new DAIRegoleGetterHelper().getDAIRegoleForRegoleId(regoleId);
	}
	
	public String calculateDAIAnagrafe (final Long soggettoId) throws GestoreAnagrafeException {
		return new DAISoggettoGetterHelper().calculateDAIAnagrafe(soggettoId);
	}
	
	public Boolean calculateDAICompleto (final Long soggettoId) throws GestoreAnagrafeException {
		return new DAISoggettoGetterHelper().calculateDAICompleto(soggettoId);
	}
}
