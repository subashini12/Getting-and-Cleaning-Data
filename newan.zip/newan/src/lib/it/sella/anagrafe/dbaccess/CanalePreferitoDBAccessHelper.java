package it.sella.anagrafe.dbaccess;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import it.sella.anagrafe.CanalePreferitoDataView;
import it.sella.anagrafe.CanaleUtilizzatoView;
import it.sella.anagrafe.ICanaleUtilizzatoView;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.common.RecapitiCanaleComptView;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.util.CanalePreferitoException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

public class CanalePreferitoDBAccessHelper extends DBAccessHelper {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CanalePreferitoDBAccessHelper.class);
	
	
	/**
	 * This method returns the Compatible Recapiti For the CanalePreferito.
	 * @return
	 * @throws CanalePreferitoException
	 * @throws RemoteException
	 */
	public Collection<RecapitiCanaleComptView> getCompatibleRecapitiCanale() throws CanalePreferitoException, RemoteException {
		
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final Collection<RecapitiCanaleComptView> list = new ArrayList<RecapitiCanaleComptView>();
		final StringBuffer query = new StringBuffer();
		query.append("SELECT CR_CANALE_ID, CR_RECAPITO_ID FROM AN_MA_COMP_RECAP_CANALE");
		
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			resultSet = statement.executeQuery();
			RecapitiCanaleComptView compatView = null;
			while (resultSet.next()) {
				compatView = new RecapitiCanaleComptView();
				compatView.setCanale(resultSet.getString("CR_CANALE_ID") != null ? ClassificazioneHandler.getClassificazioneView(Long.valueOf(resultSet.getString("CR_CANALE_ID"))) : null);
				compatView.setRecapiti(resultSet.getString("CR_RECAPITO_ID") != null ? ClassificazioneHandler.getClassificazioneView(Long.valueOf(resultSet.getString("CR_RECAPITO_ID"))) : null);
				list.add(compatView);
			}
		} catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new CanalePreferitoException(e.getMessage(),e);
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new CanalePreferitoException(e.getMessage(),e);
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return list;
	}
	
	/**
	 * @return
	 * @throws CanalePreferitoException
	 * @throws RemoteException
	 */
	public CanalePreferitoDataView getValidCanalePreferitoForSoggettoId (final Long soggettoId) throws CanalePreferitoException, RemoteException {
		CanalePreferitoDataView view = null;
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		query.append("SELECT CP_ID, CP_ID_SOGGETTO, CP_CANALE_ID, CP_CANALE_VALUE, CP_TIPO_RECAPITI, CP_DATA_INIZIO_VALIDITA, CP_UTENTE_INSERIMENTO FROM AN_TR_CANALE_PREFERITO WHERE CP_ID_SOGGETTO = ? AND CP_DATA_FINE_VALIDITA IS NULL");
		
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setLong(1, soggettoId);
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				view = new CanalePreferitoDataView();
				view.setCanalePreferitoId(Long.valueOf(resultSet.getString("CP_ID")));
				view.setSoggettoId(Long.valueOf(resultSet.getString("CP_ID_SOGGETTO")));
				view.setCanale(resultSet.getString("CP_CANALE_ID") != null ? ClassificazioneHandler.getClassificazioneView(Long.valueOf(resultSet.getString("CP_CANALE_ID"))) : null);
				view.setCanaleValue(resultSet.getString("CP_CANALE_VALUE"));
				view.setTipoRecapiti(resultSet.getString("CP_TIPO_RECAPITI") != null ? ClassificazioneHandler.getClassificazioneView(Long.valueOf(resultSet.getString("CP_TIPO_RECAPITI"))) : null);
				view.setDataInizio(resultSet.getTimestamp("CP_DATA_INIZIO_VALIDITA"));
				view.setUtenteInserimento(resultSet.getString("CP_UTENTE_INSERIMENTO"));
			}
		} catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new CanalePreferitoException(e.getMessage(),e);
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new CanalePreferitoException(e.getMessage(),e);
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return view;
	}
	
	/**
	 * @param canaleId
	 * @param recapitiId
	 * @return
	 * @throws CanalePreferitoException
	 */
	public Boolean isCanaleSpecifiExists(final Long canaleId, final Long recapitiId) throws CanalePreferitoException  {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		query.append("SELECT 1 FROM AN_MA_COMP_RECAP_CANALE WHERE CR_CANALE_ID = ? AND CR_RECAPITO_ID = ?");
		Boolean result = Boolean.FALSE;
		
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setLong(1, canaleId);
			statement.setLong(2, recapitiId);
			resultSet = statement.executeQuery();
			if(resultSet.next()) {
				result = Boolean.TRUE;
			}
		} catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new CanalePreferitoException(e.getMessage(), e);
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return result;
	}
	
	/**
	 * Not USED
	 * @param canaleId
	 * @return
	 * @throws CanalePreferitoException
	 */
	public List<Long> getCompatibilityRecapitiListForCanale(final Long canaleId) throws CanalePreferitoException  {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		query.append("SELECT CR_RECAPITO_ID FROM AN_MA_COMP_RECAP_CANALE WHERE CR_CANALE_ID = ?");
		final List<Long> result = new ArrayList<Long>();

		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setLong(1, canaleId);
			resultSet = statement.executeQuery();
			while(resultSet.next()) {
				result.add(Long.valueOf(resultSet.getString("CR_RECAPITO_ID")));
			}
		} catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new CanalePreferitoException(e.getMessage(), e);
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return result;
	}
	
	/**
	 * @param soggettoId
	 * @throws CanalePreferitoException 
	 * @throws RemoteException 
	 * @throws  
	 */
	public ICanaleUtilizzatoView getCanaleUtilizzatoForSoggettoId (final Long soggettoId) throws CanalePreferitoException, RemoteException {
		CanaleUtilizzatoView canaleUtilizzatoview = null;
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		query.append("SELECT CU_ID, CU_ID_SOGGETTO, CU_CANALE_UTILIZZATO, CU_DATA_INIZIO_VALIDITA, CU_OP_ID FROM AN_TR_CANALE_UTILIZZATO WHERE CU_ID_SOGGETTO = ? AND CU_DATA_FINE_VALIDITA IS NULL");
		
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setLong(1, soggettoId);
			resultSet = statement.executeQuery();
			
			if (resultSet.next()) {
				canaleUtilizzatoview = new CanaleUtilizzatoView();
				canaleUtilizzatoview.setId(Long.valueOf(resultSet.getString("CU_ID")));
				canaleUtilizzatoview.setSoggettoId(Long.valueOf(resultSet.getString("CU_ID_SOGGETTO")));
				canaleUtilizzatoview.setCanaleUtilizzato(resultSet.getString("CU_CANALE_UTILIZZATO"));
				canaleUtilizzatoview.setDataInizio(resultSet.getTimestamp("CU_DATA_INIZIO_VALIDITA"));
				canaleUtilizzatoview.setOpId(resultSet.getString("CU_OP_ID") != null ? Long.valueOf(resultSet.getString("CU_OP_ID")) : null);
			}
		} catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new CanalePreferitoException(e.getMessage(), e);
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return canaleUtilizzatoview;
	}
}
