package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreCollegamentoException;
import it.sella.anagrafe.GestoreDatiAnagrafeException;
import it.sella.anagrafe.az.ICollegatiAbilAziendaView;
import it.sella.anagrafe.collegamento.Collegamento;
import it.sella.anagrafe.collegamento.CollegamentoView;
import it.sella.anagrafe.discriminator.CollegamentoException;
import it.sella.anagrafe.pf.ICollegatiAbilSoggView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Hashtable;
import java.util.List;

public class CollegamentoDBAccessHelper extends DBAccessHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CollegamentoDBAccessHelper.class);

    public Collection getLinkedSoggetto(final Long soggettoId) throws GestoreCollegamentoException, RemoteException {
    	return new CollegamentoLinkedSoggettiHandler().getLinkedSoggetto(soggettoId);
    }

    public Collection getLinkedSoggetto( final Long soggettoId, final String tipoCollagamentoCausale ) throws GestoreCollegamentoException, RemoteException {
    	logSoggettoAndMotiv(soggettoId,tipoCollagamentoCausale,"getLinkedSoggetto(Long soggettoId, String tipoCollagamentoCausale)");
    	return new CollegamentoLinkedSoggettiHandler().getLinkedSoggetto(soggettoId, tipoCollagamentoCausale);
    }

    public void TerminateLink( final Long id, final Timestamp dataFine ) throws GestoreCollegamentoException, RemoteException {
    	new CollegamentoTerminateHelper().terminateLink(id, dataFine);
    }

    public void TerminateLink( final Long id ) throws GestoreCollegamentoException, RemoteException {
    	new CollegamentoTerminateHelper().terminateLink(id);
    }

    public void terminateLink( final Long linkedSoggettoId, final Hashtable attributes, final Long opId) throws GestoreCollegamentoException, RemoteException {
    	new CollegamentoTerminateHelper().terminateLink(linkedSoggettoId, attributes,opId);
    }

    public Long createCollegamento( final it.sella.anagrafe.CollegamentoView collegamentoView ) throws GestoreCollegamentoException, RemoteException {
		return new CollegamentoCreateHelper().createCollegamento(collegamentoView);
    }

    public Collection getSoggettoPrincipale( final Long soggettoId ) throws GestoreCollegamentoException, RemoteException {
    	return new CollegamentoPrincipaleGetterHelper().getSoggettoPrincipale(soggettoId);
    }

    public Collection getSoggettoPrincipale( final Long soggettoId, final String tipoCollegamento ) throws GestoreCollegamentoException, RemoteException {
    	logSoggettoAndMotiv(soggettoId,tipoCollegamento,"getSoggettoPrincipale(Long soggettoId, String tipoCollegamento)");
    	return new CollegamentoPrincipaleGetterHelper().getSoggettoPrincipale(soggettoId, tipoCollegamento);
    }

    public List getSoggettoPrincipaleWithSpecifiBank( final Long soggettoId, final String tipoCollegamento, final Long bankSoggettoId ) throws GestoreCollegamentoException, RemoteException {
    	return new CollegamentoPrincipaleGetterHelper().getSoggettoPrincipaleWithSpecifiBank( soggettoId, tipoCollegamento, bankSoggettoId );
    }

    public Collection getAziendaPrincipalSoggetto( final Long soggettoId ) throws GestoreCollegamentoException, RemoteException {
    	return new CollegamentoPrincipaleGetterHelper().getAziendaPrincipalSoggetto(soggettoId);
    }

    public Collection getSoggettiOfMotiv( final String nome, final String cogNome, final Long bancaId, final String motiv ) throws GestoreDatiAnagrafeException, RemoteException {
    	return new SoggettoDBAccessHelper().getSoggettiOfMotiv(nome, cogNome, bancaId, motiv);
    }

    public Collection getSoggettiCollegatiAbilitati( final Long principalSoggettoId ) throws GestoreCollegamentoException, RemoteException {
    	return new SoggettiCollegatiAbilitatiHelper().getSoggettiCollegatiAbilitati(principalSoggettoId);
    }

    public Collection getSoggettoPrincipaleViews( final Long soggettoId ) throws GestoreCollegamentoException, RemoteException {
    	return new CollegamentoPrincipaleGetterHelper().getSoggettoPrincipaleViews(soggettoId);
    }

    public void gestoreIntermediariFlussiAnagrafe( final String motivoIntermediari, final String codiceIntermediariCausale, final String soggettoDetails, final String valore, final String hostUserCode, final String hostMessageType ) throws GestoreAnagrafeException, RemoteException {
    	new FlussiIntermediariHelper().gestoreIntermediariFlussiAnagrafe(motivoIntermediari, codiceIntermediariCausale, soggettoDetails, valore, hostUserCode, hostMessageType);
    }

    public Collection getCollegamentoHistory( final Hashtable inputData ) throws GestoreCollegamentoException, RemoteException {
    	return new CollegamentoHistoryHelper().getCollegamentoHistory(inputData);
    }

    public void replaceCollegamento( final Long oldSoggettoId, final Long newSoggettoId, final String motivCausale, final Long opId ) throws GestoreCollegamentoException, RemoteException {
    	new CollegamentoSetterHelper().replaceCollegamento(oldSoggettoId, newSoggettoId, motivCausale, opId);
    }

    public Collection listCollegamento( final Long soggettoPrincipaleId ) throws CollegamentoException, RemoteException {
    	return new CollegamentoLinkedSoggettiHandler().listCollegamento(soggettoPrincipaleId);
    }

    public Collection listForPrincipalAndLinked( final Long principalId, final Long linkedId ) throws CollegamentoException, RemoteException {
    	return new CollegamentoLinkedSoggettiHandler().listForPrincipalAndLinked(principalId, linkedId);
    }

    public Collection listCollegamento( final Long soggettoId, final Long motivoCollegamento ) throws CollegamentoException, RemoteException {
    	return new CollegamentoLinkedSoggettiHandler().listCollegamento(soggettoId, motivoCollegamento);
    }

    public void gestoreCollegamento( final Long principaleSoggettoId, final Collection existCollIds, final String motiv, final Long opId ) throws CollegamentoException, RemoteException {
    	new GestoreCollegamento().gestoreCollegamento(principaleSoggettoId, existCollIds, motiv, opId);
    }

    public void setCollegamento( final Long linkedSoggettoId, final Timestamp dataFine, final Long opId ) throws CollegamentoException, RemoteException {
    	new CollegamentoSetterHelper().setCollegamento(linkedSoggettoId, dataFine,opId);
    }

    public void setCollegamento( final Long linkedSoggettoId, final Timestamp dataFine, final Collection motiv, final Long opId ) throws CollegamentoException, RemoteException {
    	new CollegamentoSetterHelper().setCollegamento(linkedSoggettoId, dataFine, motiv,opId);
    }

    public void modifyCollegamento( final Long id, final it.sella.anagrafe.CollegamentoView collegamentoView ) throws CollegamentoException, RemoteException {
    	new CollegamentoUpdateHelper().modifyCollegamento(id, collegamentoView);
    }

    public void setCollegamento( final Long principaleId, final Long linkedSoggettoId, final Timestamp dataFine, final String motiv, final Long opId, final String note ) throws CollegamentoException, RemoteException {
    	new CollegamentoSetterHelper().setCollegamento(principaleId, linkedSoggettoId, dataFine, motiv, opId, note);
    }

    public void removeCollegamento( final Long principaleId, final Long linkedSoggettoId, final String motiv, final Long opId ) throws CollegamentoException, RemoteException {
    	new CollegamentoSetterHelper().removeCollegamento(principaleId, linkedSoggettoId, motiv, opId );
    }

    public Collection getSoggettiColleganti( final Long linkedSoggettoId ) throws CollegamentoException, RemoteException {
    	return new CollegamentoPrincipaleGetterHelper().getSoggettiColleganti(linkedSoggettoId);
    }

    public Collection getSoggettoCollegante( final Long linkedSoggettoId, final String motivoCollegamento ) throws CollegamentoException, RemoteException {
    	return new CollegamentoPrincipaleGetterHelper().getSoggettoCollegante(linkedSoggettoId, motivoCollegamento);
    }

    public Collegamento getColleganteMotivoAndLinked( final Long principaleId, final String motivoCollegamento, final Long linkedSoggettoId ) throws CollegamentoException, RemoteException {
    	return new CollegamentoSoggettiHelper().getColleganteMotivoAndLinked(principaleId, motivoCollegamento, linkedSoggettoId);
    }

    public Long getPrincipaleForSoggettiColleganti( final Collection linkedSoggettoIds, final String motivoCollegamento ) throws CollegamentoException, RemoteException {
    	return new CollegamentoSoggettiHelper().getPrincipaleForSoggettiColleganti(linkedSoggettoIds, motivoCollegamento);
    }

    public void deleteCollegamento( final Collection collegamentoViews, final String action, final Long opId ) throws CollegamentoException, RemoteException {
    	new CollegamentoUpdateHelper().deleteCollegamento(collegamentoViews, action, opId);
    }

    public Long createCollegamento( final CollegamentoView collegamentoView ) throws CollegamentoException, RemoteException {
    	return new CollegamentoCreateHelper().createCollegamento(collegamentoView);
    }

    public List listCollegamento( final Long linkedSoggettoId, final String motivoCollegamento ) throws CollegamentoException, RemoteException {
    	return new CollegamentoLinkedSoggettiHandler().listCollegamento(linkedSoggettoId, motivoCollegamento);
    }

    private void logSoggettoAndMotiv( final Long soggettoId, final String motivCausale, final String methodName ) {
   	   if("DIPEN".equals(motivCausale) || "DIPSG".equals(motivCausale) ||
   			   "APART".equals(motivCausale) || "CDR".equals(motivCausale) || "AREA".equals(motivCausale) ||
   			   "CDRSG".equals(motivCausale) || "AREASG".equals(motivCausale) || "SOCGR".equals(motivCausale) ||
   			   "TECC".equals(motivCausale) || "CABPR".equals(motivCausale) ) {
   		   try {
   	   		   final String errorMessage = "<<<<<<<<<<< Anagrafe called for DBP data:";
   	   		   throw new Exception(errorMessage+methodName+" " + soggettoId + " " +motivCausale);
   		   } catch (final Exception e) {
   			   log4Debug.warnStackTrace(e);
   		   }
   		}
     }

    public Collection<ICollegatiAbilSoggView> getSoggettiCollegatiAbilitatiWithPFCheck( final Long principalSoggettoId ) throws GestoreCollegamentoException, RemoteException {
    	return new SoggettiCollegatiAbilitatiHelper().getSoggettiCollegatiAbilitatiWithPFCheck(principalSoggettoId);
    }

    //added this method for Censimento Soggetto BPA
    //this method is added because to avoid updation of linked soggetto to all other than the created soggetto
    public void replaceCollegamento( final Long oldSoggettoId, final Long newSoggettoId, final String motivCausale, final Long opId ,final Long soggettoId) throws GestoreCollegamentoException, RemoteException {
    	new CollegamentoSetterHelper().replaceCollegamento(oldSoggettoId, newSoggettoId, motivCausale, opId , soggettoId);
    }
    
    /**
     * This method returns the collection of AZ SOGGETTO which belongs to given input SOGGETTO, as COLLEGATE. 
     * @param soggettoId
     * @return
     * @throws GestoreCollegamentoException
     * @throws RemoteException
     */
    public Collection<ICollegatiAbilAziendaView> getCollegatiAbilAzienda(final Long soggettoId) throws GestoreCollegamentoException,RemoteException {
    	return new CollegatiAbilAziendaDBAccess().getCollegatiAbilAzienda(soggettoId);
    }
    
    /**
     * @param principalSoggettoId
     * @return
     * @throws CollegamentoException 
     * @throws RemoteException 
     */
    public boolean isCollegateSubjectHasLinkedTutoreOrEserc(final Long principalSoggettoId) throws CollegamentoException, RemoteException {
		return new CollegamentoPrincipaleGetterHelper().isCollegateSubjectHasLinkedTutoreOrEserc(principalSoggettoId);
    }
    
    /**
     * @param linkedSoggettoId
     * @return
     * @throws CollegamentoException
     * @throws RemoteException
     */
    public boolean isSubjectLinkedAsTutoreOrEsercOrCuratCollegate(final Long linkedSoggettoId) throws CollegamentoException, RemoteException {
		return new CollegamentoPrincipaleGetterHelper().isSubjectLinkedAsTutoreOrEsercOrCuratCollegate(linkedSoggettoId);
    }
    
    /**
     * @param prinSoggettoId
     * @param linkedSoggettoId
     * @param motivoCollegamento
     * @return
     * @throws RemoteException
     * @throws CollegamentoException
     */
    public Long getCollegamentoId(final Long prinSoggettoId, final Long linkedSoggettoId, final String motivoCollegamento) throws RemoteException, CollegamentoException {
    	return new CollegamentoPrincipaleGetterHelper().getCollegamentoId(prinSoggettoId, linkedSoggettoId, motivoCollegamento);
    }
    
    /**
     * @param soggettoIds
     * @param codiceFiscali
     * @param opId
     * @throws CollegamentoException
     * @throws RemoteException 
     */
    public void updateCodiceFiscaliForSoggetto(final Long [] soggettoIds, final String codiceFiscali, final Long opId) throws CollegamentoException, RemoteException {
    	new CollegamentoPrincipaleGetterHelper().updateCodiceFiscaliForSoggetto(soggettoIds, codiceFiscali, opId);
    }

    /**
     * This method is returns the Collection<it.sella.anagrafe.CollegamentoView> motive linked to bankid
     * @param linkedSoggettoId
     * @return Collection<it.sella.anagrafe.CollegamentoView>
     * @throws CollegamentoException
     * @throws RemoteException
     */
    public Collection<it.sella.anagrafe.CollegamentoView> getSoggettiPrincipaleForSpecificBank( final Long linkedSoggettoId ) throws CollegamentoException, RemoteException {
    	return new CollegamentoPrincipaleGetterHelper().getSoggettiPrincipaleForSpecificBank(linkedSoggettoId);
    }
}
