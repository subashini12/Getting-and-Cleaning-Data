package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.common.Nazione;
import it.sella.anagrafe.datifiscali.IDatiFiscaliBeanManager;
import it.sella.anagrafe.discriminator.DatiFiscaliDiscriminatorException;
import it.sella.anagrafe.implementation.IView;
import it.sella.anagrafe.pf.DatiFiscaliPFView;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.ReflectionUtil;
import it.sella.anagrafe.view.W8BenView;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Iterator;

public class DatiFiscaliCreateHelper extends DBAccessHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DatiFiscaliCreateHelper.class);

    public void createDatiFiscaliPF( final Long soggettoId, final IView iView ) throws DatiFiscaliDiscriminatorException, RemoteException {
        try {
        	final DatiFiscaliPFView datiFiscaliPFView = (DatiFiscaliPFView) iView;
        	final Collection collCausale = datiFiscaliPFView.getCausaleListFromViewProperties();
        	collCausale.remove("tipoSoggetto"); // tipoSoggetto is not a causale under Fiscali. this is used for w9NoCase validation.Thats removing here.
        	collCausale.remove("skipW9Validation"); // skipW9Validation is not a causale under Fiscali.  this is used for w9 validation need to skip in Attributi Page For Fatca Legale Motivs except Ditta Induviduale
        	final int collCausaleSize = collCausale.size();
        	final IDatiFiscaliBeanManager manager = (IDatiFiscaliBeanManager)ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.DatiFiscali");
            String currentProperty = null;
            Object object = null;
            final DateHandler dateHandler = new DateHandler();
            final Iterator it = collCausale.iterator();
            for ( int i = 0; i < collCausaleSize; i++ ) {
                currentProperty = (String) it.next();
                if ( !("residenteFiscali".equals(currentProperty)||"residenteFiscali2".equals(currentProperty)||"residenteFiscali3".equals(currentProperty))) { // residenteFiscali2, residenteFiscali3 are not the Causales
                    object = datiFiscaliPFView.getValueForThisProperty(currentProperty);
                    if ( object != null ) {
                        final it.sella.anagrafe.datifiscali.DatiFiscaliView datiView = new it.sella.anagrafe.datifiscali.DatiFiscaliView();
                        datiView.setSoggettoId(soggettoId);
                        if ( object instanceof Nazione ) {
                        	datiView.setValue(((Nazione) object).getNazioneId().toString());
                        } else if(object instanceof ClassificazioneView){
							if(!((ClassificazioneView) object).getId().toString().equals(datiView.getValue())) {
								datiView.setValue(((ClassificazioneView) object).getId().toString());
								datiView.setOpId(iView.getOpId());
                        	}
						}else if(object instanceof Timestamp){
							datiView.setValue(dateHandler.formatDate((Timestamp)object, "dd/MM/yyyy"));
							datiView.setOpId(iView.getOpId());
						}
                        else {
                        	datiView.setValue(object.toString());
                        }
                        if ( !("indicatoreA96".equals(currentProperty) || "indicatoreA97".equals(currentProperty) ||
                        		"w8".equals(currentProperty) || "w8i".equals(currentProperty) ||
                        		"w9".equals(currentProperty) || "certRV".equals(currentProperty)|| "regimeDeiMinimi".equals(currentProperty)) ||
                                !"false".equals(datiView.getValue())) {
                            datiView.setRightPk(getClassificazioneIdFromCausale(currentProperty,"DFDPF"));
                            datiView.setOpId(iView.getOpId());
                            manager.create(datiView);
                        }
                    }
                }
            }  //end of while loop
        } catch (final InvocationTargetException ie) {
            log4Debug.severeStackTrace(ie);
            throw new DatiFiscaliDiscriminatorException(ie.getLocalizedMessage());
        } catch (final GestoreAnagrafeException e) {
            log4Debug.severeStackTrace(e);
            throw new DatiFiscaliDiscriminatorException(e.getLocalizedMessage());
        } catch (final IllegalAccessException ae) {
            log4Debug.severeStackTrace(ae);
            throw new DatiFiscaliDiscriminatorException(ae.getLocalizedMessage());
        } catch (final NoSuchMethodException me) {
            log4Debug.severeStackTrace(me);
            throw new DatiFiscaliDiscriminatorException(me.getLocalizedMessage());
        }
    }

    public void createW8DataScadenza(final Long soggettoId,
			final W8BenView benView) throws DatiFiscaliDiscriminatorException, RemoteException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        final StringBuilder queryBuilder =  new StringBuilder("INSERT INTO AN_TR_DATIFISCALI " );
        queryBuilder.append("(DF_DATIFISCALI_ID, DF_SOGGETTO_ID, DF_VALUE, DF_RIGHT_PK, DF_OP_ID) ");
        queryBuilder.append("VALUES(SEQ_DATIFISCALIHOME.NEXTVAL, ?, ?, ?, ?)");
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement(queryBuilder.toString());
            preparedStatement.setLong(1, soggettoId);
            preparedStatement.setString(2, new DateHandler().formatDate(benView.getDataScadenza(),"dd/MM/yyyy"));
            preparedStatement.setLong(3, getClassificazioneIdFromCausale("D_W8BEN","DFDPF"));
            preparedStatement.setLong(4, benView.getOpId());
            preparedStatement.executeUpdate();
        } catch(final SQLException se) {
			log4Debug.warnStackTrace(se);
            throw new DatiFiscaliDiscriminatorException(se.getMessage());
        } catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
            throw new DatiFiscaliDiscriminatorException(e.getMessage());
		} finally {
            cleanup(connection, preparedStatement);
        }
    }
}
