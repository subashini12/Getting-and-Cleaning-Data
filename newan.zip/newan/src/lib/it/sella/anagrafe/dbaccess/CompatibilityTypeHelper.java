package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;


/**
 * DAO Class to handle insert and fetch operation of tipo soggetto compatbility table
 * @author gbs02406
 *
 */
public class CompatibilityTypeHelper extends DBAccessHelper {
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CompatibilityTypeHelper.class);

	
	/**
	 * Method to insert compatible links based on Tipo Sogetto and Compatible type
	 * @param tipoSoggettoId
	 * @param compatibilityType
	 * @param compatibilityValues
	 * @throws GestoreAnagrafeException
	 */
	public void createCompatibilityType(final Long tipoSoggettoId,final String compatibilityType, final Collection<Long> compatibilityValues) throws GestoreAnagrafeException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		final ResultSet resultSet = null;
		try {
			connection = getConnection();
			final StringBuilder queryBuilder = new StringBuilder("insert into an_ma_compatible_tipo_soggetto ");
			queryBuilder.append("select an_sq_ts_compatible_id.nextval, ?, ");
			queryBuilder.append("(select ct.ct_compatible_id  from an_ma_compatible_types ct where ct.ct_compatible_type = ?),? from dual ");
			preparedStatement = connection.prepareStatement(queryBuilder.toString());
			for (final Long compatibilityValue : compatibilityValues) {
				preparedStatement.setLong(1, tipoSoggettoId);
				preparedStatement.setString(2, compatibilityType);
				preparedStatement.setLong(3, compatibilityValue);
				preparedStatement.addBatch();
			}
			preparedStatement.executeBatch();
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} finally {
			cleanup(connection, preparedStatement, resultSet);
		}
	}

	
	/**
	 * Method to insert compatible links based on Tipo Sogetto id and Compatible type
	 * @param tipoSoggetto
	 * @param compatibilityType
	 * @param compatibilityValues
	 * @throws GestoreAnagrafeException
	 */
	public void createCompatibilityType(final String tipoSoggetto,final String compatibilityType, final Collection<Long> compatibilityValues) throws GestoreAnagrafeException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		final ResultSet resultSet = null;
		try {
			connection = getConnection();
			final StringBuilder queryBuilder = new StringBuilder("insert into an_ma_compatible_tipo_soggetto ");
			queryBuilder.append("select an_sq_ts_compatible_id.nextval, ");
			queryBuilder.append("(select ts.ts_tiposoggetto_id  from an_ma_tipo_soggetto ts where ts.ts_desc = ?), ");
			queryBuilder.append("(select ct.ct_compatible_id  from an_ma_compatible_types ct where ct.ct_compatible_type = ?),? from dual ");
			preparedStatement = connection.prepareStatement(queryBuilder.toString());
			for (final Long compatibilityValue : compatibilityValues) {
				preparedStatement.setString(1, tipoSoggetto);
				preparedStatement.setString(2, compatibilityType);
				preparedStatement.setLong(3, compatibilityValue);
				preparedStatement.addBatch();
			}
			preparedStatement.executeBatch();
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} finally {
			cleanup(connection, preparedStatement, resultSet);
		}
	}

	
	/**
	 * Method to get Compatible values based on Tipo Soggetto Id
	 * @param tipoSoggettoId
	 * @param compatibilityType
	 * @return
	 * @throws GestoreAnagrafeException
	 */
	public Collection<Long> getCompatibleValues(final Long tipoSoggettoId,final String compatibilityType) throws GestoreAnagrafeException {
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;
	    final Collection<Long> compCollection = new ArrayList<Long>();
	    try {
	    	final StringBuilder queryBuilder = new StringBuilder("select tc_value  from an_ma_compatible_tipo_soggetto tc, an_ma_compatible_types ct ");
	        queryBuilder.append("where tc.tc_compatible_type_id = ct.ct_compatible_id   and tc.tc_tipo_soggetto_id = ? ");
	        queryBuilder.append("and ct.ct_compatible_type = ? order by tc_id");
	        connection = getConnection();
	        preparedStatement = connection.prepareStatement(queryBuilder.toString());
	        preparedStatement.setLong(1, tipoSoggettoId);
	        preparedStatement.setString(2, compatibilityType);
	        resultSet = preparedStatement.executeQuery();
	        while (resultSet.next()) {
	        	compCollection.add(resultSet.getLong("tc_value"));
	        }
	        return compCollection;
	    } catch (final SQLException se) {
	    	log4Debug.warnStackTrace(se);
	    	throw new GestoreAnagrafeException(se.getMessage());
	    } finally {
	    	cleanup(connection, preparedStatement, resultSet);
	    }
	}

	
	/**
	 * Method to get Compatible values based on Tipo Soggetto 
	 * @param tipoSoggetto
	 * @param compatibilityType
	 * @return
	 * @throws GestoreAnagrafeException
	 */
	public Collection<Long> getCompatibleValues(final String tipoSoggetto,final String compatibilityType) throws GestoreAnagrafeException {

		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;
	    final Collection<Long> compCollection = new ArrayList<Long>();
	    try {
	    	final StringBuilder queryBuilder = new StringBuilder("select tc_value from an_ma_compatible_tipo_soggetto tc, an_ma_compatible_types ct,an_ma_tipo_soggetto ts ");
	        queryBuilder.append("where tc.tc_compatible_type_id = ct.ct_compatible_id ");
	        queryBuilder.append("and tc.tc_tipo_soggetto_id = ts.ts_tiposoggetto_id  ");
	        queryBuilder.append("and ts.ts_desc = ? and ct.ct_compatible_type = ? order by tc_id ");
	        connection = getConnection();
	        preparedStatement = connection.prepareStatement(queryBuilder.toString());
	        preparedStatement.setString(1, tipoSoggetto);
	        preparedStatement.setString(2, compatibilityType);
	        resultSet = preparedStatement.executeQuery();
	        while (resultSet.next()) {
	        	compCollection.add(resultSet.getLong("tc_value"));
	        }
	        return compCollection;
	    } catch (final SQLException se) {
	    	log4Debug.warnStackTrace(se);
	    	throw new GestoreAnagrafeException(se.getMessage());
	    } finally {
	    	cleanup(connection, preparedStatement, resultSet);
	    }
	}

	
	/**
	 * Method to get Not associated Compatible values based on Tipo Soggetto Id
	 * @param tipoSoggettoId
	 * @param casuale
	 * @param compatibilityType
	 * @return
	 * @throws GestoreAnagrafeException
	 */
	public Collection<Long> getNonExistingCompatibleValues(final Long tipoSoggettoId,final String casuale ,final String compatibilityType) throws GestoreAnagrafeException {
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;
	    final Collection<Long> compCollection = new ArrayList<Long>();
	    try {
	    	final StringBuilder queryBuilder = new StringBuilder("select cl_id from cl_vw_classificazione ");
	        queryBuilder.append("where cl_classificazione_id in (select cl_id from cl_vw_classificazione where cl_causale = ?) ");
	        queryBuilder.append("and cl_id not in (select tc_value from an_ma_compatible_tipo_soggetto tc, an_ma_compatible_types ct ");
	        queryBuilder.append("where tc.tc_compatible_type_id = ct.ct_compatible_id and tc.tc_tipo_soggetto_id = ? ");
	        queryBuilder.append("and ct.ct_compatible_type = ?) ");
	        connection = getConnection();
	        preparedStatement = connection.prepareStatement(queryBuilder.toString());
	        preparedStatement.setString(1, casuale);
	        preparedStatement.setLong(2, tipoSoggettoId);
	        preparedStatement.setString(3, compatibilityType);
	        resultSet = preparedStatement.executeQuery();
	        while (resultSet.next()) {
	        	compCollection.add(resultSet.getLong("cl_id"));
	        }
	        return compCollection;
	    } catch (final SQLException se) {
	    	log4Debug.warnStackTrace(se);
	    	throw new GestoreAnagrafeException(se.getMessage());
	    } finally {
	    	cleanup(connection, preparedStatement, resultSet);
	    }
	}
}
