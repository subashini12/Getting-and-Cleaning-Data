package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.anagrafe.IMapper;
import it.sella.anagrafe.MapperFactory;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.UpdateAMMBAScanView;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.MapperHelperException;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.StringTokenizer;

public class AmministratoriBancaHostUpdateHelper extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AmministratoriBancaHostUpdateHelper.class);

    public String updateAmministratoreBancaInHost( final Long soggettoId, final String codiceHost, final String selectedCausale,final boolean isHostCodeFromSecurity ) throws RemoteException, MapperHelperException, GestoreCodiciSoggettoException {
        final StringBuffer output = new StringBuffer();
        if( CommonPropertiesHandler.isHostAllowedForLoginBank() ) {
			if( codiceHost != null ) {
				output.append(updateArt136ForCodiceHost(codiceHost,selectedCausale,null,isHostCodeFromSecurity)).append("^");
			}
			final String codiceHostCifrati = new CSCifratiGetterHelper().getCodiceHostCifrati(soggettoId);
			if( codiceHostCifrati != null ) {
				output.append(updateArt136ForCodiceHost(codiceHostCifrati,selectedCausale,null,isHostCodeFromSecurity));
			}
        }
        return output.toString();
    }

    public String updateAmministratoreBancaInHostThroughFlussi( final UpdateAMMBAScanView updateAMMBAScanView, final String hostUserCode,final boolean isHostCodeFromSecurity ) throws RemoteException, GestoreCodiciSoggettoException, SubSystemHandlerException {
        log4Debug.debug(" AmministratoriBancaHostUpdateHelper : updateAmministratoreBancaInHostThroughFlussi : codiceHost:===>",updateAMMBAScanView.getCodiceHost());
        log4Debug.debug(" AmministratoriBancaHostUpdateHelper : updateAmministratoreBancaInHostThroughFlussi : bankSoggettoId:===>",updateAMMBAScanView.getSoggettoPrincipaleId());
        log4Debug.debug(" AmministratoriBancaHostUpdateHelper : updateAmministratoreBancaInHostThroughFlussi : selectedCausale:===>",updateAMMBAScanView.getMotivoCausale());
        log4Debug.debug(" AmministratoriBancaHostUpdateHelper : updateAmministratoreBancaInHostThroughFlussi : hostUserCode:===>",hostUserCode);
        String mapperMessage = null;
        if( CommonPropertiesHandler.isHostAllowedForSpecifiedBank( updateAMMBAScanView.getSoggettoPrincipaleId() ) && updateAMMBAScanView.getSoggettoPrincipaleId().equals(SecurityHandler.getLoginBancaId())) {
        	log4Debug.debug(" AmministratoriBancaHostUpdateHelper : updateAmministratoreBancaInHostThroughFlussi : codiceHost:===>",updateAMMBAScanView.getCodiceHost());
        	String hostStatus = null;
        	String alignHost = null;
			if( updateAMMBAScanView.getCodiceHost() != null ) {
				try {
					mapperMessage = MapperFactory.getMapper().updateAmministratoriBanca( updateAMMBAScanView.getCodiceHost(),
							updateAMMBAScanView.getReSoggettoId() != null ? null : updateAMMBAScanView.getMotivoCausale(), hostUserCode,isHostCodeFromSecurity);
					hostStatus = "OK";
					alignHost = "SUCCESS";
					updateAMMBAScanView.setMapperMessage(mapperMessage);
				} catch (final Exception e) {
					hostStatus = "KO";
					alignHost = "REQUIRED";
					log4Debug.severeStackTrace(e);
					log4Debug.severe(" < == updateAmministratoreBancaInHostThroughFlussi : Failure Doest not affect parent transactions : codiceHost==>",updateAMMBAScanView.getCodiceHost());
					updateAMMBAScanView.setMapperMessage(e.getMessage());
				}
				updateAMMBAScanView.setHostStatus(hostStatus);
				updateAMMBAScanView.setHostDataFine(new DateHandler().getCurrentDateInTimeStampFormat());
				updateAMMBAScanView.setAlignHost(alignHost);
			}
        }
        return mapperMessage;
    }
    
    
    
    private String updateArt136ForCodiceHost( final String codiceHost, final String selectedCausale, final String hostUserCode,final boolean isHostCodeFromSecurity ) throws RemoteException, MapperHelperException {
        final StringBuffer output = new StringBuffer();
        final IMapper mapperHelper = MapperFactory.getMapper();
        String codiceHostToBePassed = null;
        final StringTokenizer tokenizer = new StringTokenizer(codiceHost,";");
        while ( tokenizer.hasMoreTokens() ) {
            codiceHostToBePassed = tokenizer.nextToken();
            if (codiceHostToBePassed.startsWith("0")) {
                if( codiceHostToBePassed.length() == 9 ) {
                	codiceHostToBePassed = codiceHostToBePassed.substring(1,9);
                }
            	output.append(mapperHelper.updateAmministratoriBanca(codiceHostToBePassed,
            			selectedCausale,hostUserCode,isHostCodeFromSecurity)).append("^");
            }
        }
        return output.toString();
    }
}
