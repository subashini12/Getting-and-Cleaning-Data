package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreProvinciaException;
import it.sella.anagrafe.IClasseATECOView;
import it.sella.anagrafe.common.Ramo;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.view.ClasseATECOView;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

public class ClasseATECODBAccessHelper extends DBAccessHelper {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(ClasseATECODBAccessHelper.class);
	
	public List<IClasseATECOView> getClasseATECO(final String code) throws GestoreAnagrafeException {
    	final List<IClasseATECOView> classeATECOList = new ArrayList<IClasseATECOView>(); 
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;
	    try {
	    	final StringBuilder queryBuilder = new StringBuilder("SELECT CL_ID,CL_COD,CL_DESC,CL_PARENT_ID,CL_LEVEL ");
	        queryBuilder.append("FROM AN_MA_CLASSE_ATECO2007 WHERE CL_COD = ? ");
	        connection = getConnection();
	        preparedStatement = connection.prepareStatement(queryBuilder.toString());
	        preparedStatement.setString(1, code);
	        resultSet = preparedStatement.executeQuery();
	        ClasseATECOView classeATECOView = null;
	        while (resultSet.next()) {
	        	classeATECOView = new ClasseATECOView();
	        	classeATECOView.setId(resultSet.getLong("CL_ID"));
	        	classeATECOView.setCode(resultSet.getString("CL_COD"));
	        	classeATECOView.setDescrpition(resultSet.getString("CL_DESC"));
	        	setParentIdIfNotNull(classeATECOView, resultSet.getString("CL_PARENT_ID"));
	        	classeATECOView.setLevel(resultSet.getLong("CL_LEVEL"));
	        	classeATECOList.add(classeATECOView);
	        }
	        return classeATECOList;
	    } catch (final SQLException se) {
	    	log4Debug.severeStackTrace(se);
	        throw new GestoreProvinciaException(se.getMessage());
	    } finally {
	    	cleanup(connection, preparedStatement, resultSet);
	    }
   }
  
	public List<IClasseATECOView> getAllAteco2007() throws GestoreAnagrafeException {
    	Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;
	    final List<IClasseATECOView> ateList = new ArrayList<IClasseATECOView>(1);
	    try {
	    	final String query = "SELECT CL_ID, CL_COD, CL_DESC, CL_PARENT_ID, CL_LEVEL FROM AN_MA_CLASSE_ATECO2007  ORDER BY CL_LEVEL,CL_COD ";
	    	log4Debug.debug(" ClasseATECODBAccessHelper: getAllAteco2007: query:===>>",query);
	        connection = getConnection();
	        preparedStatement = connection.prepareStatement(query);
	        resultSet = preparedStatement.executeQuery();
	        ClasseATECOView classeATECOView = null;
	        while (resultSet.next()) {
	        	classeATECOView = new ClasseATECOView();
	        	classeATECOView.setId(resultSet.getLong("CL_ID"));
	        	classeATECOView.setCode(resultSet.getString("CL_COD"));
	        	classeATECOView.setDescrpition(resultSet.getString("CL_DESC"));
	        	setParentIdIfNotNull(classeATECOView, resultSet.getString("CL_PARENT_ID"));
	        	classeATECOView.setLevel(resultSet.getLong("CL_LEVEL"));
	        	ateList.add(classeATECOView);
	        }
	    } catch (final SQLException se) {
	    	log4Debug.severeStackTrace(se);
	        throw new GestoreProvinciaException(se.getMessage());
	    } finally {
	    	cleanup(connection, preparedStatement, resultSet);
	    }
	    log4Debug.debug(" ClasseATECODBAccessHelper: getAllAteco2007: ateList:===>>",ateList.size());
	    return ateList;
	}
	
	public String getDescrizioneAteco2007(final String codice) throws GestoreAnagrafeException {
    	Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;
	    String desc = null;
	    try {
	    	final String query = "SELECT CL_DESC FROM AN_MA_CLASSE_ATECO2007 WHERE CL_COD = ? AND CL_LEVEL=3";
	    	log4Debug.debug(" ClasseATECODBAccessHelper: getDescrizioneAteco2007: codice:===>>",codice);
	    	log4Debug.debug(" ClasseATECODBAccessHelper: getDescrizioneAteco2007: query:===>>",query);
	    	connection = getConnection();
	        preparedStatement = connection.prepareStatement(query);
	        preparedStatement.setString(1, codice);
	        resultSet = preparedStatement.executeQuery();
	        if (resultSet.next()) {
	        	desc = resultSet.getString("CL_DESC");
	        }
	    } catch (final SQLException se) {
	    	log4Debug.severeStackTrace(se);
	        throw new GestoreProvinciaException(se.getMessage());
	    } finally {
	    	cleanup(connection, preparedStatement, resultSet);
	    }
		log4Debug.debug(" ClasseATECODBAccessHelper: getDescrizioneAteco2007: desc:===>>",desc);
	    return desc;
	}
	
	public String getCodiceAteco2007(final String descrizione) throws GestoreAnagrafeException {
    	Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;
	    String code = null;
	    try {
	    	final String query = "SELECT CL_COD FROM AN_MA_CLASSE_ATECO2007 WHERE CL_DESC = ? AND CL_LEVEL=3";
	    	log4Debug.debug(" ClasseATECODBAccessHelper: getCodiceAteco2007: descrizione:===>>",descrizione);
	    	log4Debug.debug(" ClasseATECODBAccessHelper: getCodiceAteco2007: query:===>>",query);
	    	connection = getConnection();
	        preparedStatement = connection.prepareStatement(query);
	        preparedStatement.setString(1, descrizione);
	        resultSet = preparedStatement.executeQuery();
	        if (resultSet.next()) {
	          code = resultSet.getString("CL_COD");
	        }
	    } catch (final SQLException se) {
	    	log4Debug.severeStackTrace(se);
	        throw new GestoreProvinciaException(se.getMessage());
	    } finally {
	    	cleanup(connection, preparedStatement, resultSet);
	    }
	    log4Debug.debug(" ClasseATECODBAccessHelper: getCodiceAteco2007: code:===>>",code);
	    return code;
	}

	public Long getCodiceAteco2007Id(final String descrizione) throws GestoreAnagrafeException {
    	Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;
	    Long id = null;
	    try {
	    	final String query = "SELECT CL_ID FROM AN_MA_CLASSE_ATECO2007 WHERE CL_DESC = ?";
	    	log4Debug.debug(" ClasseATECODBAccessHelper: getCodiceAteco2007Id: descrizione:===>>",descrizione);
	    	log4Debug.debug(" ClasseATECODBAccessHelper: getCodiceAteco2007Id: query:===>>",query);
	    	connection = getConnection();
	        preparedStatement = connection.prepareStatement(query);
	        preparedStatement.setString(1, descrizione);
	        resultSet = preparedStatement.executeQuery();
	        if (resultSet.next()) {
	          id = resultSet.getLong("CL_ID");
	        }
	    } catch (final SQLException se) {
	    	log4Debug.severeStackTrace(se);
	        throw new GestoreProvinciaException(se.getMessage());
	    } finally {
	    	cleanup(connection, preparedStatement, resultSet);
	    }
	    log4Debug.debug(" ClasseATECODBAccessHelper: getCodiceAteco2007Id: id:===>>",id);
	    return id;
	}

	public List<IClasseATECOView> getCompatibleAteco2007(final String codiceSottoGruppo)  throws GestoreAnagrafeException {
    	Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;
	    final List<IClasseATECOView> ateList = new ArrayList<IClasseATECOView>(1);
	    try {
	    	/*final StringBuilder queryBuilder = new StringBuilder("with TEMP as ");
	    	queryBuilder.append("(select CP_CLAS_ID from AN_MA_COMP_SETTORE_CLASSE CS where CS.CP_SETT_ID =");
	    	queryBuilder.append("(SELECT SE.ST_SETTORE_ID FROM AN_MA_SETTORE SE WHERE SE.ST_CODICESOTTOGRUPPO = ?)) ");
	    	queryBuilder.append("select CL_ID, CL_COD, CL_DESC, CL_PARENT_ID, CL_LEVEL FROM AN_MA_CLASSE_ATECO2007 WHERE ( 0 = (SELECT COUNT(*) FROM TEMP) ");
	    	queryBuilder.append("OR CL_ID IN (SELECT CP_CLAS_ID FROM TEMP)) AND CL_LEVEL =1 ORDER BY CL_COD ");*/
	    	
	    	final StringBuilder queryBuilder = new StringBuilder("SELECT CL_ID, CL_COD, CL_DESC, CL_PARENT_ID, CL_LEVEL ");
	    	queryBuilder.append("FROM (WITH TEMP AS (SELECT CP_CLAS_ID   FROM AN_MA_COMP_SETTORE_CLASSE CS ");
	    	queryBuilder.append("WHERE CS.CP_SETT_ID = (SELECT SE.ST_SETTORE_ID  FROM AN_MA_SETTORE SE   WHERE SE.ST_CODICESOTTOGRUPPO = ? AND SE.ST_STORICO = 0)) ");
	    	queryBuilder.append("SELECT CL_ID, CL_COD, CL_DESC, CL_PARENT_ID, CL_LEVEL  FROM AN_MA_CLASSE_ATECO2007 ");
	    	queryBuilder.append("WHERE (0 = (SELECT COUNT(*) FROM TEMP) OR  CL_ID IN (SELECT CP_CLAS_ID FROM TEMP)) ");
	    	queryBuilder.append("AND CL_LEVEL = 1 ) ");
	    	queryBuilder.append("MINUS ");
	    	queryBuilder.append("SELECT CL_ID, CL_COD, CL_DESC, CL_PARENT_ID, CL_LEVEL ");
	    	queryBuilder.append("FROM AN_MA_COMP_SETTORE_CLASSE CS, AN_MA_CLASSE_ATECO2007 CA ");
	    	queryBuilder.append("WHERE CA.CL_ID = CS.CP_CLAS_ID  AND CS.CP_SETT_ID NOT IN ");
	    	queryBuilder.append("(SELECT SE.ST_SETTORE_ID  FROM AN_MA_SETTORE SE  WHERE SE.ST_CODICESOTTOGRUPPO = ? AND SE.ST_STORICO = 0) ORDER BY CL_COD ");
	    	log4Debug.debug(" ClasseATECODBAccessHelper: getCompatibleAteco2007: queryBuilder:===>>",queryBuilder);
	    	connection = getConnection();
	        preparedStatement = connection.prepareStatement(queryBuilder.toString());
	        preparedStatement.setString(1, codiceSottoGruppo);
	        preparedStatement.setString(2, codiceSottoGruppo);
	        resultSet = preparedStatement.executeQuery();
	        ClasseATECOView classeATECOView = null;
	        while (resultSet.next()) {
	        	classeATECOView = new ClasseATECOView();
	        	classeATECOView.setId(resultSet.getLong("CL_ID"));
	        	classeATECOView.setCode(resultSet.getString("CL_COD"));
	        	classeATECOView.setDescrpition(resultSet.getString("CL_DESC"));
	        	classeATECOView.setLevel(resultSet.getLong("CL_LEVEL"));
	        	setParentIdIfNotNull(classeATECOView, resultSet.getString("CL_PARENT_ID"));
	        	ateList.add(classeATECOView);
	        }
	    } catch (final SQLException se) {
	    	log4Debug.severeStackTrace(se);
	        throw new GestoreProvinciaException(se.getMessage());
	    } finally {
	    	cleanup(connection, preparedStatement, resultSet);
	    }
	    log4Debug.debug(" ClasseATECODBAccessHelper: getCompatibleAteco2007: ateList:===>>",ateList.size());
	    return ateList;
	}
	
	public List<IClasseATECOView> getClasseAteco2007(final Long level, final Long parentId) throws GestoreAnagrafeException {
    	Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;
	    final List<IClasseATECOView> ateList = new ArrayList<IClasseATECOView>(1);
	    try {
	    	final StringBuilder queryBuilder = new StringBuilder("SELECT CL_ID,CL_COD,CL_DESC,CL_PARENT_ID,CL_LEVEL ");
	    	queryBuilder.append("FROM AN_MA_CLASSE_ATECO2007 WHERE CL_LEVEL = ? ");
	    	if (parentId != null ) {
	    	 queryBuilder.append("AND CL_PARENT_ID = ?");	
	    	}
	    	log4Debug.debug(" ClasseATECODBAccessHelper: getClasseAteco2007: queryBuilder:===>>",queryBuilder);
	        connection = getConnection();
	        preparedStatement = connection.prepareStatement(queryBuilder.toString());
	        preparedStatement.setLong(1, level);
	    	if (parentId != null ) {
	    		preparedStatement.setLong(2, parentId);
	    	}
	        resultSet = preparedStatement.executeQuery();
	        ClasseATECOView classeATECOView = null;
	        while (resultSet.next()) {
	        	classeATECOView = new ClasseATECOView();
	        	classeATECOView.setId(resultSet.getLong("CL_ID"));
	        	classeATECOView.setCode(resultSet.getString("CL_COD"));
	        	classeATECOView.setDescrpition(resultSet.getString("CL_DESC"));
	        	classeATECOView.setLevel(resultSet.getLong("CL_LEVEL"));
	        	setParentIdIfNotNull(classeATECOView, resultSet.getString("CL_PARENT_ID"));
	        	ateList.add(classeATECOView);
	        }
	    } catch (final SQLException se) {
	    	log4Debug.severeStackTrace(se);
	        throw new GestoreProvinciaException(se.getMessage());
	    } finally {
	    	cleanup(connection, preparedStatement, resultSet);
	    }
	    log4Debug.debug(" ClasseATECODBAccessHelper: getCompatibleAteco2007: ateList:===>>",ateList.size());
	    return ateList;
	}
   
	// no reference
	public List<IClasseATECOView> getClasseAteco2007(final String code) throws GestoreAnagrafeException {
    	Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;
	    final List<IClasseATECOView> ateList = new ArrayList<IClasseATECOView>(1);
	    try {
	    	/*final StringBuilder queryBuilder = new StringBuilder("with TEMP as ");
	    	queryBuilder.append("(select CP_CLAS_ID from AN_MA_COMP_SETTORE_CLASSE CS where CS.CP_SETT_ID =");
	    	queryBuilder.append("(SELECT SE.ST_SETTORE_ID FROM AN_MA_SETTORE SE WHERE SE.ST_CODICESOTTOGRUPPO = ?)) ");
	    	queryBuilder.append("select CL_ID, CL_COD, CL_DESC, CL_PARENT_ID, CL_LEVEL FROM AN_MA_CLASSE_ATECO2007 WHERE ( 0 = (SELECT COUNT(*) FROM TEMP) ");
	    	queryBuilder.append("OR CL_ID IN (SELECT CP_CLAS_ID FROM TEMP)) AND CL_LEVEL =1 ");*/
	    	
	    	final StringBuilder queryBuilder = new StringBuilder("SELECT CL_ID, CL_COD, CL_DESC, CL_PARENT_ID, CL_LEVEL ");
	    	queryBuilder.append("FROM (WITH TEMP AS (SELECT CP_CLAS_ID   FROM AN_MA_COMP_SETTORE_CLASSE CS ");
	    	queryBuilder.append("WHERE CS.CP_SETT_ID = (SELECT SE.ST_SETTORE_ID  FROM AN_MA_SETTORE SE   WHERE SE.ST_CODICESOTTOGRUPPO = ?)) ");
	    	queryBuilder.append("SELECT CL_ID, CL_COD, CL_DESC, CL_PARENT_ID, CL_LEVEL  FROM AN_MA_CLASSE_ATECO2007 ");
	    	queryBuilder.append("WHERE (0 = (SELECT COUNT(*) FROM TEMP) OR  CL_ID IN (SELECT CP_CLAS_ID FROM TEMP)) ");
	    	queryBuilder.append("AND CL_LEVEL = 1 ) ");
	    	queryBuilder.append("MINUS ");
	    	queryBuilder.append("SELECT CL_ID, CL_COD, CL_DESC, CL_PARENT_ID, CL_LEVEL ");
	    	queryBuilder.append("FROM AN_MA_COMP_SETTORE_CLASSE CS, AN_MA_CLASSE_ATECO2007 CA ");
	    	queryBuilder.append("WHERE CA.CL_ID = CS.CP_CLAS_ID  AND CS.CP_SETT_ID NOT IN ");
	    	queryBuilder.append("(SELECT SE.ST_SETTORE_ID  FROM AN_MA_SETTORE SE  WHERE SE.ST_CODICESOTTOGRUPPO = ?) ORDER BY CL_COD ");
	    	log4Debug.debug(" ClasseATECODBAccessHelper: getClasseAteco2007: queryBuilder:===>>",queryBuilder);
	        connection = getConnection();
	        preparedStatement = connection.prepareStatement(queryBuilder.toString());
	        preparedStatement.setString(1, code);
	        preparedStatement.setString(2, code);
	        resultSet = preparedStatement.executeQuery();
	        ClasseATECOView classeATECOView = null;
	        while (resultSet.next()) {
	        	classeATECOView = new ClasseATECOView();
	        	classeATECOView.setId(resultSet.getLong("CL_ID"));
	        	classeATECOView.setCode(resultSet.getString("CL_COD"));
	        	classeATECOView.setDescrpition(resultSet.getString("CL_DESC"));
	        	classeATECOView.setLevel(resultSet.getLong("CL_LEVEL"));
	        	setParentIdIfNotNull(classeATECOView, resultSet.getString("CL_PARENT_ID"));
	        	ateList.add(classeATECOView);
	        }
	    } catch (final SQLException se) {
	    	log4Debug.severeStackTrace(se);
	        throw new GestoreProvinciaException(se.getMessage());
	    } finally {
	    	cleanup(connection, preparedStatement, resultSet);
	    }
	    log4Debug.debug(" ClasseATECODBAccessHelper: getCompatibleAteco2007: ateList:===>>",ateList.size());
	    return ateList;
	}
	
	public ClasseATECOView getClasseATECOView(final Long pkId) throws GestoreAnagrafeException {
    	Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;
	    ClasseATECOView classeATECOView = null;
	    try {
	    	final StringBuilder queryBuilder = new StringBuilder("SELECT CL_ID,CL_COD,CL_DESC,CL_PARENT_ID,CL_LEVEL ");
	    	queryBuilder.append("FROM AN_MA_CLASSE_ATECO2007 WHERE CL_ID = ? ");
	    	log4Debug.debug(" ClasseATECODBAccessHelper: getClasseATECOView: queryBuilder:===>>",queryBuilder);
	        connection = getConnection();
	        preparedStatement = connection.prepareStatement(queryBuilder.toString());
	        preparedStatement.setLong(1, pkId);
	        resultSet = preparedStatement.executeQuery();
	        if (resultSet.next()) {
	        	classeATECOView = new ClasseATECOView();
	        	classeATECOView.setId(resultSet.getLong("CL_ID"));
	        	classeATECOView.setCode(resultSet.getString("CL_COD"));
	        	classeATECOView.setDescrpition(resultSet.getString("CL_DESC"));
	        	classeATECOView.setLevel(resultSet.getLong("CL_LEVEL"));
	        	setParentIdIfNotNull(classeATECOView, resultSet.getString("CL_PARENT_ID"));
	        }
	    } catch (final SQLException se) {
	    	log4Debug.severeStackTrace(se);
	        throw new GestoreProvinciaException(se.getMessage());
	    } finally {
	    	cleanup(connection, preparedStatement, resultSet);
	    }
	    return classeATECOView;
	}

	public List<IClasseATECOView> getClasseATECOByLevel(final Long level) throws GestoreAnagrafeException {
    	final List<IClasseATECOView> classeATECOList = new ArrayList<IClasseATECOView>(); 
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;

	    try {
	    	final StringBuilder queryBuilder = new StringBuilder("SELECT CL_ID, CL_COD, CL_DESC ,CL_PARENT_ID,CL_LEVEL ");
	        queryBuilder.append("FROM  AN_MA_CLASSE_ATECO2007 WHERE CL_LEVEL = ? ORDER BY CL_COD  ");

	        connection = getConnection();
	        preparedStatement = connection.prepareStatement(queryBuilder.toString());
	        preparedStatement.setLong(1, level);
	        resultSet = preparedStatement.executeQuery();
	        ClasseATECOView classeATECOView = null;
	        while (resultSet.next()) {
	        	classeATECOView = new ClasseATECOView();
	        	classeATECOView.setId(resultSet.getLong("CL_ID"));
	        	classeATECOView.setCode(resultSet.getString("CL_COD"));
	        	classeATECOView.setDescrpition(resultSet.getString("CL_DESC"));
	        	setParentIdIfNotNull(classeATECOView, resultSet.getString("CL_PARENT_ID"));
	        	classeATECOView.setLevel(resultSet.getLong("CL_LEVEL"));
	        	classeATECOList.add(classeATECOView);
	        }
	        return classeATECOList;
	    } catch (final SQLException se) {
	    	log4Debug.severeStackTrace(se);
	        throw new GestoreProvinciaException(se.getMessage());
	    } finally {
	    	cleanup(connection, preparedStatement, resultSet);
	    }
   }
	public Hashtable<String, String> getClasseATECOParentCodeByLevel3Code(final String classeCode ) throws GestoreAnagrafeException {
		Hashtable<String, String> parentCodeTable = null;
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;

	    try {
	    	final StringBuilder queryBuilder = new StringBuilder("SELECT TEMP.ATT_SEZIONE, TEMP.ATT_DIVISIONE ");
	        queryBuilder.append("FROM (SELECT MAX(DECODE(LEVEL, 3, CL_COD, NULL)) AS ATT_SEZIONE, ");
	        queryBuilder.append("MAX(DECODE(LEVEL, 2, CL_COD, NULL)) AS ATT_DIVISIONE ");
	        queryBuilder.append("FROM AN_MA_CLASSE_ATECO2007 ");
	        queryBuilder.append("CONNECT BY PRIOR CL_PARENT_ID = CL_ID ");
	        queryBuilder.append("START WITH CL_COD = ?) TEMP ");
	        queryBuilder.append("WHERE TEMP.ATT_SEZIONE IS NOT NULL ");
	        queryBuilder.append("AND TEMP.ATT_DIVISIONE IS NOT NULL");
	        log4Debug.debug(" ClasseATECODBAccessHelper: getClasseATECOParentCodeByLevel3Code: queryBuilder:===>>"
	        		,queryBuilder);
	        connection = getConnection();
	        preparedStatement = connection.prepareStatement(queryBuilder.toString());
	        preparedStatement.setString(1, classeCode);
	        resultSet = preparedStatement.executeQuery();
	        if (resultSet.next()) {
	        	parentCodeTable = new Hashtable<String, String>();
	        	parentCodeTable.put("ATT_SEZIONE", resultSet.getString("ATT_SEZIONE"));
	        	parentCodeTable.put("ATT_DIVISIONE", resultSet.getString("ATT_DIVISIONE"));
	        }
	        return parentCodeTable;
	    } catch (final SQLException se) {
	    	log4Debug.severeStackTrace(se);
	        throw new GestoreProvinciaException(se.getMessage());
	    } finally {
	    	cleanup(connection, preparedStatement, resultSet);
	    }
   }
	
	public List<IClasseATECOView> getClasseATECOByParentCode(final String parentClasseCode) throws GestoreAnagrafeException {
    	final List<IClasseATECOView> classeATECOList = new ArrayList<IClasseATECOView>(); 
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;
	    try {
	    	final StringBuilder queryBuilder = new StringBuilder("SELECT CL_ID,CL_COD,CL_DESC,CL_PARENT_ID,CL_LEVEL,CS.CS_SETTORE_COMM_ID FROM AN_MA_CLASSE_ATECO2007 , AN_MA_COMP_CLAS_SETCOMM CS WHERE CL_PARENT_ID = ");
	    	queryBuilder.append("(SELECT CL_ID FROM AN_MA_CLASSE_ATECO2007 WHERE CL_COD = ?)AND CS.CS_CLASSE_ID(+) = CL_ID ORDER BY CL_COD ");
	        log4Debug.debug(" ClasseATECODBAccessHelper: getClasseATECOByParentCode: queryBuilder:===>>"
	        		,queryBuilder);
	        connection = getConnection();
	        preparedStatement = connection.prepareStatement(queryBuilder.toString());
	        preparedStatement.setString(1, parentClasseCode);
	        resultSet = preparedStatement.executeQuery();
	        ClasseATECOView classeATECOView = null;
	        while (resultSet.next()) {
	        	classeATECOView = new ClasseATECOView();
	        	classeATECOView.setId(resultSet.getLong("CL_ID"));
	        	classeATECOView.setCode(resultSet.getString("CL_COD"));
	        	classeATECOView.setDescrpition(resultSet.getString("CL_DESC"));
	        	setParentIdIfNotNull(classeATECOView, resultSet.getString("CL_PARENT_ID"));
	        	classeATECOView.setLevel(resultSet.getLong("CL_LEVEL"));
	        	if(resultSet.getString("CS_SETTORE_COMM_ID") != null){
	        		final ClassificazioneView classificazioneView = ClassificazioneHandler.getClassificazioneView(Long.valueOf(resultSet.getString("CS_SETTORE_COMM_ID"))); 
	        		classeATECOView.setSettoreCommerciale(classificazioneView);
	        	}
	        	classeATECOList.add(classeATECOView);
	        }
	        return classeATECOList;
	    } catch (final SQLException se) {
	    	log4Debug.severeStackTrace(se);
	        throw new GestoreProvinciaException(se.getMessage());
	    } catch (NumberFormatException e) {
	    	log4Debug.severeStackTrace(e);
	        throw new GestoreProvinciaException(e.getMessage());
		} catch (RemoteException e) {
			log4Debug.severeStackTrace(e);
	        throw new GestoreProvinciaException(e.getMessage());
		} finally {
	    	cleanup(connection, preparedStatement, resultSet);
	    }
   }
	
	
	public Ramo getRemoByClasse(final String classeCode) throws GestoreAnagrafeException {
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;
	    try {
	    	final StringBuilder queryBuilder = new StringBuilder("SELECT RM_CODICEGRUPPO, RM_DESCRIZIONE   FROM AN_MA_RAMO ");
	    	queryBuilder.append("WHERE RM_RAMO_ID = (SELECT CR_RAMO_ID FROM AN_MA_RAMO_CLASSE WHERE CR_CLAS_ID =");
	        queryBuilder.append("(SELECT CL_ID  FROM AN_MA_CLASSE_ATECO2007 WHERE CL_COD = ? AND ROWNUM =1 ) AND ROWNUM =1 )");
	        log4Debug.debug(" ClasseATECODBAccessHelper: getRemoByClasse: queryBuilder:===>>"
	        		,queryBuilder);
	        connection = getConnection();
	        preparedStatement = connection.prepareStatement(queryBuilder.toString());
	        preparedStatement.setString(1, classeCode);
	        resultSet = preparedStatement.executeQuery();
	        Ramo ramo = null;
	        if (resultSet.next()) {
	        	ramo = new Ramo();
	        	ramo.setCodiceGruppo(resultSet.getString("RM_CODICEGRUPPO"));
	        	ramo.setDescrizione(resultSet.getString("RM_DESCRIZIONE"));
	        }
	        return ramo;
	    } catch (final SQLException se) {
	    	log4Debug.severeStackTrace(se);
	        throw new GestoreProvinciaException(se.getMessage());
	    } finally {
	    	cleanup(connection, preparedStatement, resultSet);
	    }
   }
  
	public List<IClasseATECOView> getLeve3ClasseCode(final String codiceSottoGruppo) throws GestoreAnagrafeException {
    	final List<IClasseATECOView> classeATECOList = new ArrayList<IClasseATECOView>(); 
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;
	    try {
	    	/*StringBuilder queryBuilder = new StringBuilder("with temp as ( ");
	    	queryBuilder.append("select CP_CLAS_ID from AN_MA_COMP_SETTORE_CLASSE CS where CS.CP_SETT_ID = ");
	    	queryBuilder.append("(SELECT SE.ST_SETTORE_ID FROM AN_MA_SETTORE SE WHERE SE.ST_CODICESOTTOGRUPPO = ?)) ");
	    	queryBuilder.append("select CL_ID, CL_COD,CL_DESC, CL_PARENT_ID,CL_LEVEL FROM AN_MA_CLASSE_ATECO2007 WHERE ( 0 = (SELECT COUNT(*) FROM TEMP) OR ");
	    	queryBuilder.append("CL_ID IN (select CL_ID from AN_MA_CLASSE_ATECO2007 CONNECT BY PRIOR  CL_ID = CL_PARENT_ID start with cl_id  ");
	    	queryBuilder.append("in(SELECT CP_CLAS_ID FROM TEMP)) ) AND CL_LEVEL=3 ORDER BY CL_COD ");*/
	        
	        final StringBuilder queryBuilder = new StringBuilder("SELECT CL_ID, CL_COD, CL_DESC, CL_PARENT_ID, CL_LEVEL  FROM AN_MA_CLASSE_ATECO2007 ");
	        queryBuilder.append("WHERE LEVEL > 2 CONNECT BY PRIOR CL_ID = CL_PARENT_ID ");
	        queryBuilder.append("START WITH CL_ID IN( ");
	        queryBuilder.append("SELECT CL_ID ");
	        queryBuilder.append("FROM (WITH TEMP AS (SELECT CP_CLAS_ID   FROM AN_MA_COMP_SETTORE_CLASSE CS ");
	        queryBuilder.append("WHERE CS.CP_SETT_ID = (SELECT SE.ST_SETTORE_ID  FROM AN_MA_SETTORE SE   WHERE SE.ST_CODICESOTTOGRUPPO = ?)) ");
	        queryBuilder.append("SELECT CL_ID, CL_COD, CL_DESC, CL_PARENT_ID, CL_LEVEL  FROM AN_MA_CLASSE_ATECO2007 ");
	        queryBuilder.append("WHERE (0 = (SELECT COUNT(*) FROM TEMP) OR  CL_ID IN (SELECT CP_CLAS_ID FROM TEMP)) ");
	        queryBuilder.append("AND CL_LEVEL = 1  ) ");
	        queryBuilder.append("MINUS ");
	        queryBuilder.append("SELECT CL_ID ");
	        queryBuilder.append("FROM AN_MA_COMP_SETTORE_CLASSE CS, AN_MA_CLASSE_ATECO2007 CA ");
	        queryBuilder.append("WHERE CA.CL_ID = CS.CP_CLAS_ID  AND CS.CP_SETT_ID NOT IN ");
	        queryBuilder.append("(SELECT SE.ST_SETTORE_ID  FROM AN_MA_SETTORE SE  WHERE SE.ST_CODICESOTTOGRUPPO = ?) ) ORDER BY CL_COD");
	        log4Debug.debug(" ClasseATECODBAccessHelper: getClasseATECOByParentCode: queryBuilder:===>>"
	        		,queryBuilder);
	        connection = getConnection();
	        preparedStatement = connection.prepareStatement(queryBuilder.toString());
	        preparedStatement.setString(1, codiceSottoGruppo);
	        preparedStatement.setString(2, codiceSottoGruppo);
	        resultSet = preparedStatement.executeQuery();
	        ClasseATECOView classeATECOView = null;
	        while (resultSet.next()) {
	        	classeATECOView = new ClasseATECOView();
	        	classeATECOView.setId(resultSet.getLong("CL_ID"));
	        	classeATECOView.setCode(resultSet.getString("CL_COD"));
	        	classeATECOView.setDescrpition(resultSet.getString("CL_DESC"));
	        	setParentIdIfNotNull(classeATECOView, resultSet.getString("CL_PARENT_ID"));
	        	classeATECOView.setLevel(resultSet.getLong("CL_LEVEL"));
	        	classeATECOList.add(classeATECOView);
	        }
	        return classeATECOList;
	    } catch (final SQLException se) {
	    	log4Debug.severeStackTrace(se);
	        throw new GestoreProvinciaException(se.getMessage());
	    } finally {
	    	cleanup(connection, preparedStatement, resultSet);
	    }
   }
  public void setParentIdIfNotNull(final ClasseATECOView classeATECOView , final String parentIdStr){
	  if(parentIdStr != null ){
		  classeATECOView.setParentId(Long.valueOf(parentIdStr));
	  }
  }
}
