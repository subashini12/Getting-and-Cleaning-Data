package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.InformazioneManagerException;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.anagrafe.view.CompDocumentView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

public class CompDocumentDBAccessHelper extends DBAccessHelper {
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CompDocumentDBAccessHelper.class);

	public List<CompDocumentView> getPFCompDocumentList(final Long bankId,final boolean isValid)
	throws GestoreAnagrafeException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		final List<CompDocumentView> compDocViewList = new ArrayList<CompDocumentView>();
		CompDocumentView compDocumentView = null;
		final StringBuilder query = new StringBuilder("SELECT CC.CD_ID,CD_DOC_CLASS_ID,VC.CL_CAUSALE, VC.CL_DESCRIZIONE,CD_ENTE_EMISSIONE, ");
		query.append("CD_BANK_ID, CD_DOC_CLASS, CD_DOC_TIPO,CD_STORICO,CC_ITALIANO_MAN, ");
		query.append("CC_ITALIANO_ADD, CC_COM_MAN,CC_COM_ADD,CC_EXTRA_COM_NORES_IT_MAN, ");
		query.append("CC_EXTRA_COM_NORES_IT_ADD,CC_EXTRA_COM_RES_IT_MAN, CC_EXTRA_COM_RES_IT_ADD, ");
		query.append("CC_MAGGIORENNE,CC_ALLOWED_FOR_MIN_FROM_MAJ,CD_RIF_DATE,CD_APPLICABLE_NAZIONE,CC_VALID_BUFFER_DAYS ");
		query.append("FROM AN_MA_COMP_DOCUMENTI CC, CL_VW_CLASSIFICAZIONE VC WHERE CC.CD_DOC_CLASS_ID = VC.CL_ID ");
		query.append("AND CD_BANK_ID = ? AND CD_STORICO = ? ORDER BY VC.CL_DESCRIZIONE");
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(query.toString());
			preparedStatement.setLong(1, bankId == null ? SecurityHandler.getLoginBancaId() : bankId);
			preparedStatement.setLong(2, isValid ? 0L : 1L);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				compDocumentView = new CompDocumentView();
				constructCompDocumentView(resultSet, compDocumentView);
				compDocViewList.add(compDocumentView);
			}
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new GestoreAnagrafeException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement,resultSet);
		}
		return compDocViewList;
	}

	public Map getCompDocumentViewAsMap(final Long bankId,final boolean isValid) throws GestoreAnagrafeException{
		final Map compDocMainMap = new HashMap();
		final List<CompDocumentView> compDocViewList = getPFCompDocumentList(bankId,isValid);
		final Map<String, CompDocumentView> italianManMap = new HashMap<String, CompDocumentView>();
		final Map<String, CompDocumentView> italianAddMap = new HashMap<String, CompDocumentView>();
		final Map<String, CompDocumentView> europenManMap = new HashMap<String, CompDocumentView>();
		final Map<String, CompDocumentView> europenAddMap = new HashMap<String, CompDocumentView>();
		final Map<String, CompDocumentView> nonUENoResItalyManMap = new HashMap<String, CompDocumentView>();
		final Map<String, CompDocumentView> nonUENoResItalyAddMap = new HashMap<String, CompDocumentView>();
		final Map<String, CompDocumentView> nonUEResItalyManMap = new HashMap<String, CompDocumentView>();
		final Map<String, CompDocumentView> nonUEResItalyAddMap = new HashMap<String, CompDocumentView>();


		final String italianMan = "italianMan";
		final String italianAdd = "italianAdd";
		final String europenMan = "europenMan";
		final String europenAdd = "europenAdd";
		final String nonUENoResItalyMan = "nonUENoResItalyMan";
		final String nonUENoResItalyAdd = "nonUENoResItalyAdd";
		final String nonUEResItalyMan = "nonUEResItalyMan";
		final String nonUEResItalyAdd = "nonUEResItalyAdd";

		for (final CompDocumentView compDocumentView : compDocViewList) {
			compDocMainMap.put(compDocumentView.getClassificazioneId(), compDocumentView);
			compDocMainMap.put(compDocumentView.getClassificazioneCausale(), compDocumentView);

			if("Y".equals(compDocumentView.getItalianoMandatory())){
				italianManMap.put(compDocumentView.getClassificazioneCausale(), compDocumentView);
			}
			if("Y".equals(compDocumentView.getItalianoAdditionaly())){
				italianAddMap.put(compDocumentView.getClassificazioneCausale(), compDocumentView);
			}

			if("Y".equals(compDocumentView.getComunitarioMandatory())){
				europenManMap.put(compDocumentView.getClassificazioneCausale(), compDocumentView);
			}

			if("Y".equals(compDocumentView.getComunitarioAdditionaly())){
				europenAddMap.put(compDocumentView.getClassificazioneCausale(), compDocumentView);
			}

			if("Y".equals(compDocumentView.getExtraComunitarioNoResITMandatory())){
				nonUENoResItalyManMap.put(compDocumentView.getClassificazioneCausale(), compDocumentView);
			}
			if("Y".equals(compDocumentView.getExtraComunitarioNoresITAdditionaly())){
				nonUENoResItalyAddMap.put(compDocumentView.getClassificazioneCausale(), compDocumentView);
			}

			if("Y".equals(compDocumentView.getExtraComunitarioResITMandatory())){
				nonUEResItalyManMap.put(compDocumentView.getClassificazioneCausale(), compDocumentView);
			}
			if("Y".equals(compDocumentView.getExtraComunitarioResITAdditionaly())){
				nonUEResItalyAddMap.put(compDocumentView.getClassificazioneCausale(), compDocumentView);
			}

		}
		compDocMainMap.put(italianMan, italianManMap);
		compDocMainMap.put(italianAdd, italianAddMap);
		compDocMainMap.put(europenMan, europenManMap);
		compDocMainMap.put(europenAdd, europenAddMap);
		compDocMainMap.put(nonUENoResItalyMan, nonUENoResItalyManMap);
		compDocMainMap.put(nonUENoResItalyAdd, nonUENoResItalyAddMap);
		compDocMainMap.put(nonUEResItalyMan, nonUEResItalyManMap);
		compDocMainMap.put(nonUEResItalyAdd, nonUEResItalyAddMap);

		return compDocMainMap;
	}
	/**
	 * To check if document is applicable or not 
	 * @param bancaId
	 * @param causaleId
	 * @return
	 * @throws GestoreAnagrafeException
	 */
	public static boolean isValidDocument(Long bancaId,Long causaleId)throws GestoreAnagrafeException
	{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet result = null;
		boolean isValid=false;

		final StringBuilder queryString = new StringBuilder("SELECT 1 FROM AN_MA_COMP_DOCUMENTI WHERE CD_BANK_ID =? AND CD_DOC_CLASS_ID = ? AND CD_STORICO = ?");

		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(queryString.toString());
			preparedStatement.setLong(1, bancaId == null ? SecurityHandler.getLoginBancaId() : bancaId);
			if(causaleId!=null)
			{
				preparedStatement.setLong(2, causaleId);
			}
			else 
			{
				preparedStatement.setNull(2,Types.NUMERIC);
			}
			preparedStatement.setLong(3,0L);
			result = preparedStatement.executeQuery();
			if (result.next()) 
			{
				isValid=true;
			}

		} catch (SQLException e) {
			log4Debug.warnStackTrace(e);
		}
		finally {
			cleanup(connection, preparedStatement,result);
		}
		return isValid;

	}

	/**
	 * 
	 * @param resultSet
	 * @param compDocViewList
	 * @param compDocumentView
	 * @throws SQLException
	 */
	public void constructCompDocumentView(final ResultSet resultSet,final CompDocumentView compDocumentView) throws SQLException {
		if(compDocumentView !=null){
			compDocumentView.setId(resultSet.getLong("CD_ID"));
			compDocumentView.setClassificazioneId(resultSet.getLong("CD_DOC_CLASS_ID"));
			compDocumentView.setClassificazioneCausale(resultSet.getString("CL_CAUSALE"));
			compDocumentView.setClassificazioneDescription(resultSet.getString("CL_DESCRIZIONE"));
			compDocumentView.setEnteEmissione(resultSet.getString("CD_ENTE_EMISSIONE"));
			compDocumentView.setIdBanca(resultSet.getLong("CD_BANK_ID"));
			compDocumentView.setDocClass(resultSet.getString("CD_DOC_CLASS"));
			compDocumentView.setTipoDocument(resultSet.getString("CD_DOC_TIPO"));
			compDocumentView.setStorico(resultSet.getLong("CD_STORICO"));
			compDocumentView.setItalianoMandatory(resultSet.getString("CC_ITALIANO_MAN"));
			compDocumentView.setItalianoAdditionaly(resultSet.getString("CC_ITALIANO_ADD"));
			compDocumentView.setComunitarioMandatory(resultSet.getString("CC_COM_MAN"));
			compDocumentView.setComunitarioAdditionaly(resultSet.getString("CC_COM_ADD"));
			compDocumentView.setExtraComunitarioNoResITMandatory(resultSet.getString("CC_EXTRA_COM_NORES_IT_MAN"));
			compDocumentView.setExtraComunitarioNoresITAdditionaly(resultSet.getString("CC_EXTRA_COM_NORES_IT_ADD"));
			compDocumentView.setExtraComunitarioResITMandatory(resultSet.getString("CC_EXTRA_COM_RES_IT_MAN"));
			compDocumentView.setExtraComunitarioResITAdditionaly(resultSet.getString("CC_EXTRA_COM_RES_IT_ADD"));
			compDocumentView.setMaggiorenne(resultSet.getString("CC_MAGGIORENNE"));
			compDocumentView.setAllowedForMinorFromMajor(resultSet.getString("CC_ALLOWED_FOR_MIN_FROM_MAJ"));
			compDocumentView.setRifdate(resultSet.getDate("CD_RIF_DATE"));
			compDocumentView.setApplicableNazione(getLongObjectFromPrimitive(resultSet.getString("CD_APPLICABLE_NAZIONE")));
			compDocumentView.setValidBufferDays(getLongObjectFromPrimitive(resultSet.getString("CC_VALID_BUFFER_DAYS")));
		}
	}

	/**
	 * 
	 * @param value
	 * @return
	 */
	protected Long getLongObjectFromPrimitive(final String value) {
		return value != null ? Long.valueOf(value) : null;
	}
	
	/**
	 * This Method Returns Compatible documents For all the banks.
	 * key : docCausale-bankId
	 * @throws GestoreAnagrafeException
	 */
	public Map<String, CompDocumentView> getPFCompatibleDocumentForAllBanks() throws InformazioneManagerException {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		CompDocumentView compDocumentView = null;
		final StringBuilder query = new StringBuilder();
		final Map<String, CompDocumentView> compDocTable = new Hashtable<String, CompDocumentView>();
		query.append("SELECT CC.CD_ID, CD_DOC_CLASS_ID, VC.CL_CAUSALE, VC.CL_DESCRIZIONE, CD_ENTE_EMISSIONE, CD_BANK_ID, CD_DOC_CLASS, CD_DOC_TIPO, CD_STORICO, CC_ITALIANO_MAN, CC_ITALIANO_ADD, ");
		query.append("CC_COM_MAN, CC_COM_ADD, CC_EXTRA_COM_NORES_IT_MAN,CC_EXTRA_COM_NORES_IT_ADD, CC_EXTRA_COM_RES_IT_MAN, CC_EXTRA_COM_RES_IT_ADD, CC_MAGGIORENNE, CC_ALLOWED_FOR_MIN_FROM_MAJ, ");
		query.append("CD_RIF_DATE, CD_APPLICABLE_NAZIONE, CC_VALID_BUFFER_DAYS FROM AN_MA_COMP_DOCUMENTI CC, CL_VW_CLASSIFICAZIONE VC WHERE CC.CD_DOC_CLASS_ID = VC.CL_ID");
		
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				compDocumentView = new CompDocumentView();
				constructCompDocumentView(resultSet, compDocumentView);
				final String key = compDocumentView.getClassificazioneCausale() + "-" + (compDocumentView.getIdBanca() != null ? compDocumentView.getIdBanca() : "");
				compDocTable.put(key, compDocumentView);
			}
		} catch (final SQLException e) {
			log4Debug.severeStackTrace(e);
			throw new InformazioneManagerException(e.getMessage());
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return compDocTable;
	}
}
