package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.AddressNormalizationException;
import it.sella.anagrafe.util.DateHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class AddressNormDBAccessHelper extends DBAccessHelper   {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AddressNormDBAccessHelper.class);

	public void insertAddressNormInputData( final List<String> adddressNormInData , 
			final  Long opId  ) throws AddressNormalizationException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        final StringBuilder queryBuilder =  new StringBuilder("INSERT INTO ADD_TE_NORM_ADDRESS AD " );
        queryBuilder.append("( NA_IN_DATA , NA_INSERTION_DATE , NA_OP_ID  ) VALUES (  ? , ? , ? )");
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement(queryBuilder.toString());
            final int size = adddressNormInData.size();
            final DateHandler dateHandler = new DateHandler();
        	final Timestamp sysdate = dateHandler.getCurrentDateInTimeStampFormat();
            for ( int i=0; i < size ; i++ ) {
            	preparedStatement.setString(1, adddressNormInData.get(i));
				preparedStatement.setTimestamp(2, sysdate);
             	preparedStatement.setLong(3 , opId);
            	preparedStatement.addBatch();
            }
        	final int count [] = preparedStatement.executeBatch();
        	log4Debug.debug(" AddressNormDBAccessHelper : addAddressNormData : record count : ===>>>",
        			count.length);
        } catch(final SQLException se) {
			log4Debug.warnStackTrace(se);
            throw new AddressNormalizationException(se.getMessage());
        } finally {
            cleanup(connection, preparedStatement);
        }
    }
	
	public void updateNormalizedAddress( final  Long addressId , final  Long opId  ) 
		throws AddressNormalizationException {
        Connection connection = null;
        CallableStatement callableStatement = null;
        try {
        	connection = getConnection();
        	callableStatement = connection.prepareCall("{ CALL ADD_PKG_NORM_ADDRESS.ADD_PR_UPDATE_NORM_ADDRESS( ? , ? ) } ");
        	callableStatement.setLong(1, addressId);
        	callableStatement.setLong(2, opId);
            callableStatement.executeUpdate();
        } catch(final SQLException se) {
        	log4Debug.warnStackTrace(se);
            throw new AddressNormalizationException(se.getMessage());
        } finally {
            cleanup(connection, callableStatement);
        }
    }
	
	public void setAddressNormalizationStatus( final String status  ) 
			throws AddressNormalizationException{
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        final StringBuilder query = new StringBuilder("UPDATE ADD_TR_NORM_ADDRESS_BATCH NB" );
        query.append(" SET NB.NB_STATUS =  ?  WHERE NB.NB_STATUS IS NULL ");

        try {
        	connection = getConnection();
        	preparedStatement = connection.prepareStatement(query.toString());
        	preparedStatement.setString(1, status);
        	preparedStatement.executeUpdate();
        } catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressNormalizationException(e.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}
	}
	
	public  void clearAddressNormInputData( final String deleteType ) throws AddressNormalizationException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        final StringBuilder queryBuilder = new StringBuilder("DELETE FROM ADD_TE_NORM_ADDRESS ");
        try {
            connection = getConnection();
            if ( "PROCESSED".equals(deleteType) ) {
            	queryBuilder.append(" WHERE NOT EXISTS (SELECT 1 FROM ADD_TR_NORM_ADDRESS_BATCH ");
            	queryBuilder.append(" WHERE (NB_STATUS IS NULL OR NB_STATUS = 'IP') ");
            	queryBuilder.append(" AND NB_OP_ID = NA_OP_ID) AND NA_STATUS = 'OK'");
            	
            }
            preparedStatement = connection.prepareStatement(queryBuilder.toString());
            preparedStatement.executeUpdate();
        } catch(final SQLException se) {
        	log4Debug.warnStackTrace(se);            
            throw new AddressNormalizationException(se.getMessage());
        } finally {
            cleanup(connection, preparedStatement);
        }
    }

	public  void clearAddressData( final String deleteType ) throws AddressNormalizationException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        final StringBuilder queryBuilder = new StringBuilder(" DELETE FROM ADD_TR_NORM_ADDRESS_BATCH ");
        try {
            connection = getConnection();
            if ( "PROCESSED".equals(deleteType) ) {
            	queryBuilder.append(" WHERE NB_STATUS IN ('OK','KO') ");
            }
            preparedStatement = connection.prepareStatement(queryBuilder.toString());
            preparedStatement.executeUpdate();
        } catch(final SQLException se) {
        	log4Debug.warnStackTrace(se);            
            throw new AddressNormalizationException(se.getMessage());
        } finally {
            cleanup(connection, preparedStatement);
        }
    }
	
	public String getNormalizedData() throws AddressNormalizationException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rsResultSet = null;
        final StringBuilder normalizedData =  new StringBuilder();
        
        final StringBuilder query = new StringBuilder("SELECT ADS.AD_ADDRESS_ID || '$' ");
        query.append(" || ADS.AD_PROVINCIA || '$' || ADS.AD_CITTA || '$' ||  ");
        query.append(" ADS.AD_NAZIONE || '$' || ADS.AD_INDIRIZZO || '$' || ADS.AD_CAP_VALUE || '$' || ");
        query.append(" ADS.AD_OP_ID || '$$' || AD.AD_ADDRESS_ID || '$' || AD.AD_PROVINCIA || '$' || ");
        query.append(" AD.AD_CITTA || '$' || AD.AD_NAZIONE || '$' || AD.AD_INDIRIZZO || '$' || ");
        query.append(" AD.AD_CAP_VALUE || '$' || AD.AD_OP_ID || '$' || AD.AD_NORM_STATUS AS NORMALIZED_DATA ");
        query.append(" FROM ADD_TR_ADDRESS  AD, ADDSE_TR_ADDRESS  ADS, ADD_TR_NORM_ADDRESS_BATCH NB ");
        query.append(" WHERE  NB.NB_STATUS = 'OK' AND  AD.AD_ADDRESS_ID = NB.NB_ADDRESS_ID  AND  ");
        query.append(" AD.AD_ADDRESS_ID = ADS.AD_ADDRESS_ID AND  ADS.AD_OP_ID = AD.AD_OP_ID  ");
        query.append(" UNION ");
        query.append(" SELECT AD.AD_ADDRESS_ID || '$' || AD.AD_PROVINCIA || '$' || AD.AD_CITTA || '$' || ");
        query.append(" AD.AD_NAZIONE || '$' || AD.AD_INDIRIZZO || '$' || AD.AD_CAP_VALUE || '$' || ");
        query.append(" AD.AD_OP_ID || '$$$$$$$$$' AS UNNORMALIZED_DATA ");
        query.append(" FROM ADD_TR_ADDRESS  AD , ADD_TR_NORM_ADDRESS_BATCH NB ");
        query.append(" WHERE  AD.AD_ADDRESS_ID = NB.NB_ADDRESS_ID  ");
        query.append(" AND NB.NB_STATUS = 'KO' ");
        
        try {
        	connection = getConnection();
        	log4Debug.debug(" AddressNormDBAccessHelper : setAddressNormalizationStatus : query :===>>>",query);
        	preparedStatement = connection.prepareStatement(query.toString());
        	rsResultSet = preparedStatement.executeQuery();
        	  while( rsResultSet.next() ) {
                  normalizedData.append(rsResultSet.getString("NORMALIZED_DATA")).append("\n");
               }
               if ( normalizedData.lastIndexOf("\n") != -1 ){
                  normalizedData.replace(normalizedData.lastIndexOf("\n"), normalizedData.length() , "");	
               }
               
        } catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressNormalizationException(e.getMessage());
		} finally {
			cleanup(connection, preparedStatement, rsResultSet);
		}
		return normalizedData.toString();
	}

	public List<String> getAllNormalizationAddressId() throws AddressNormalizationException {
        Connection connection = null;
        PreparedStatement migPreparedStatement = null;
        final List<String> addressOpId = new ArrayList<String>(1);
        ResultSet resultSet = null;
        try {
			connection = getConnection();
			migPreparedStatement = connection.prepareStatement(
					"SELECT NB_ADDRESS_ID || '$' || NB_OP_ID AS ADDRESS_OP_ID  FROM ADD_TR_NORM_ADDRESS_BATCH  WHERE NB_STATUS IS NULL");
			resultSet = migPreparedStatement.executeQuery();
			while ( resultSet.next() ) {
				addressOpId.add(resultSet.getString("ADDRESS_OP_ID"));
			}
		} catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new AddressNormalizationException(e.getMessage());
		} finally {
			cleanup(connection, migPreparedStatement, resultSet);
		}
		return addressOpId;
	}
}
