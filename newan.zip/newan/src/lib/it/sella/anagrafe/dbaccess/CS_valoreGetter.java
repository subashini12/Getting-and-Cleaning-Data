package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.implementation.CodiciSoggettoView;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

public class CS_valoreGetter extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CS_valoreGetter.class);

    public String getValoreCodiciSoggetto( final Long soggettoId, final String causale ) throws GestoreCodiciSoggettoException, RemoteException {
    	return getValoreCodiciSoggetto( soggettoId, null, causale);
    }

    /* This method to getValorecodiciSoggetto for all banks */
    
    public String getValoreCodiciSoggettoWithSpecificBank( final Long soggettoId, final Long bankSoggettoId, final String causale ) throws GestoreCodiciSoggettoException, RemoteException {
    	return getValoreCodiciSoggetto( soggettoId, bankSoggettoId, causale );
    }
    
    public Collection getCodiciSoggetto( final Long soggettoId ) throws GestoreCodiciSoggettoException, RemoteException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        final Collection codiciSoggettoList = new ArrayList(1);
        ResultSet codiciResultSet = null;
        try {
            connection = getConnection();
            selectStatement = connection.prepareStatement("SELECT CS.CS_VALUE, CS.CS_RIGHT_PK FROM AN_TR_CODICISOGGETTO CS, AN_TR_COLLAGAMENTO_SOGGETTO CO WHERE CO.CL_SOGGETTO_PRINCIPALE = ? and CO.CL_MOTIVO = ? and CO.cl_data_fine is null and CO.CL_LINKED_SOGGETTO = CS.CS_SOGGETTO_ID and CS.CS_SOGGETTO_ID = ? ");
            selectStatement.setLong(1, SecurityHandler.getLoginBancaId().longValue());
            selectStatement.setLong(2, getClassificazioneIdFromCausale("CENST", "MOTIV").longValue());
            selectStatement.setLong(3, soggettoId.longValue());
            codiciResultSet = selectStatement.executeQuery();
            getCodiciSoggettoViewOnResultSet(soggettoId,codiciSoggettoList,codiciResultSet);
        } catch (final SQLException sqlEx) {
            log4Debug.warnStackTrace(sqlEx);
            throw new GestoreCodiciSoggettoException(sqlEx.getMessage());
        } catch (final SubSystemHandlerException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreCodiciSoggettoException(e.getMessage());
        } finally {
            cleanup(connection, selectStatement, codiciResultSet);
        }
        return codiciSoggettoList;
    }
    
    public Collection getCodiciSoggettoBasedOnSoggettoId( final Long soggettoId ) throws GestoreCodiciSoggettoException, RemoteException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        final Collection codiciSoggettoList = new ArrayList(1);
        ResultSet codiciResultSet = null;
        try {
            connection = getConnection();
            selectStatement = connection.prepareStatement("SELECT CS.CS_VALUE, CS.CS_RIGHT_PK FROM AN_TR_CODICISOGGETTO CS WHERE CS.CS_SOGGETTO_ID = ? ");
            selectStatement.setLong(1, soggettoId.longValue());
            codiciResultSet = selectStatement.executeQuery();
            getCodiciSoggettoViewOnResultSet(soggettoId,codiciSoggettoList,codiciResultSet);
        } catch (final SQLException sqlEx) {
            log4Debug.warnStackTrace(sqlEx);
            throw new GestoreCodiciSoggettoException(sqlEx.getMessage());
        } catch (final SubSystemHandlerException e) {
            log4Debug.warnStackTrace(e);
            throw new GestoreCodiciSoggettoException(e.getMessage());
        } finally {
            cleanup(connection, selectStatement, codiciResultSet);
        }
        return codiciSoggettoList;
    }
    
    private void getCodiciSoggettoViewOnResultSet( final Long soggettoId, final Collection codiciSoggettoList, final ResultSet codiciResultSet )throws SQLException,RemoteException,SubSystemHandlerException {
    	ClassificazioneView classificazioneView = null;
    	CodiciSoggettoView codiciSoggettoView = null;
    	 while( codiciResultSet.next() ) {
             codiciSoggettoView = new CodiciSoggettoView();
             codiciSoggettoView.setSoggettoId(soggettoId);
             if ( codiciResultSet.getString("CS_VALUE") != null ) {
            	 codiciSoggettoView.setValore(codiciResultSet.getString("CS_VALUE"));
             }
             if ( codiciResultSet.getLong("CS_RIGHT_PK") != 0 ) {
                 classificazioneView = ClassificazioneHandler.getClassificazioneView(Long.valueOf(codiciResultSet.getLong("CS_RIGHT_PK")));
                 codiciSoggettoView.setTipoCodiciSoggetto(classificazioneView.getDescrizione());
                 codiciSoggettoView.setCausaleTipoCodiciSoggetto(classificazioneView.getCausale());
                 codiciSoggettoView.setDescrizioneTipoCodiciSoggetto(classificazioneView.getDescrizione());
             }
             codiciSoggettoList.add(codiciSoggettoView);
         }
    }
    
    private String getValoreCodiciSoggetto( final Long soggettoId, final Long bankSoggettoId, final String causale ) throws GestoreCodiciSoggettoException, RemoteException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet codiciSoggettoResultSet = null;
        String cSvalue = null;
        logValoreCodiciSoggetto(soggettoId,"getValoreCodiciSoggetto(Long soggettoId, String causale)",causale);
        try {
            if ("abi6d".equals(causale) || "cab6d".equals(causale)) {
                int lastCharacter = 0;
                String output = null;
                if ("abi6d".equals(causale)) {
                    output = getValoreCodiciSoggetto(soggettoId, "abi");
                } else {
                    output = getValoreCodiciSoggetto(soggettoId, "cab");
                    if (output != null) {
						output = output.substring(0, 5);
					}
                }
                if ( output != null ) {
                    for ( int i = 0; i < 5; i++ ) {
                        int number = Integer.parseInt(String.valueOf(output.charAt(i)));
                        if (i % 2 == 0) {
                            number = number * 2;
                            final String strNumber = String.valueOf(number);
                            if (strNumber.length() > 1) {
                                number = Integer.parseInt(String.valueOf(strNumber.charAt(0)));
                                number += Integer.parseInt(String.valueOf(strNumber.charAt(1)));
                            }
                        }
                        lastCharacter += number;
                    }
                    if ( lastCharacter % 10 == 0 ) {
                    	lastCharacter = 0;
                    } else {
                    	lastCharacter = (((lastCharacter / 10) + 1) * 10) - lastCharacter;
                    }
                    cSvalue = output + lastCharacter;
                }
            } else {
                connection = getConnection();
                selectStatement = connection.prepareStatement("SELECT CS.CS_VALUE FROM an_tr_codicisoggetto CS, AN_TR_COLLAGAMENTO_SOGGETTO CO WHERE CO.CL_SOGGETTO_PRINCIPALE = ? AND CO.CL_MOTIVO = ? and CO.CL_LINKED_SOGGETTO = CS.CS_SOGGETTO_ID and CS.CS_RIGHT_PK = ? and CS.CS_SOGGETTO_ID = ?");
                selectStatement.setLong(1, bankSoggettoId == null ? SecurityHandler.getLoginBancaId().longValue() : bankSoggettoId.longValue() );
                selectStatement.setLong(2, getClassificazioneIdFromCausale("CENST", "MOTIV").longValue());
                selectStatement.setLong(3, getClassificazioneIdFromCausale(causale, "CSDPF").longValue());
                selectStatement.setLong(4, soggettoId.longValue());
                codiciSoggettoResultSet = selectStatement.executeQuery();
                if (codiciSoggettoResultSet.next()) {
                    cSvalue = codiciSoggettoResultSet.getString("CS_VALUE");
                }
            }
        } catch (final SQLException sqlEx) {
            log4Debug.warnStackTrace(sqlEx);
            throw new GestoreCodiciSoggettoException(sqlEx.getMessage());
        } catch (final SubSystemHandlerException fe) {
            log4Debug.warnStackTrace(fe);
            throw new GestoreCodiciSoggettoException(fe.getMessage());
        } finally {
            cleanup(connection, selectStatement, codiciSoggettoResultSet);
        }
        return cSvalue;
    }
    
    private void logValoreCodiciSoggetto( final Long soggettoId, final String methodName, final String causale ) {
		if( "codlm".equals(causale) || "coddp".equals(causale) || 
				"excoddp".equals(causale) || "cdr".equals(causale) || "codsu".equals(causale) ||
				"cab".equals(causale) || "codArea".equals(causale) || "abi".equals(causale)) {
		   try {
	   		   final String errorMessage = "<<<<<<<<<<< Anagrafe called for DBP data: ";
	   		   throw new SubSystemHandlerException(errorMessage+ methodName + " " + soggettoId + " " +causale);
		   } catch (final SubSystemHandlerException e) {
			   log4Debug.warnStackTrace(e);
		   }
		}
    }
}
