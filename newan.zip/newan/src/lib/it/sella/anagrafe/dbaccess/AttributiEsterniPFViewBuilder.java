package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.AttributiEsterniATSView;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.az.AttributiEsterniAZView;
import it.sella.anagrafe.discriminator.AttributiEsterniDiscriminatorException;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.implementation.IView;
import it.sella.anagrafe.pf.AttributiEsterniPFView;
import it.sella.anagrafe.pl.AttributiEsterniPLView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Hashtable;

public class AttributiEsterniPFViewBuilder extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AttributiEsterniPFViewBuilder.class);

    public IView getAttributiEsterniPF(final Long soggettoId) throws AttributiEsterniDiscriminatorException, RemoteException {
        IView iView = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        boolean isSconfExists = false;
        try {
            connection = getConnection();
            final String typeOfSoggetto = new TipoSoggettoHandler().getTipoSoggetto(soggettoId);
            String causale = null;
            preparedStatement = connection.prepareStatement("select AE_VALUE, AE_RIGHT_PK from AN_TR_ATTRIBUTIESTERNI where AE_SOGGETTO_ID = ? ");
            preparedStatement.setLong(1, soggettoId.longValue());
            resultSet = preparedStatement.executeQuery();
            if ("Semplice".equals(typeOfSoggetto)) {
                final AttributiEsterniPFView attributiEsterniPFView = new AttributiEsterniPFView();
                while (resultSet.next()) {
                    causale = ClassificazioneHandler.getClassificazioneView(Long.valueOf(resultSet.getLong("AE_RIGHT_PK"))).getCausale();
                    if ("sconf".equals(causale)) {
						isSconfExists = true;
					}
                    attributiEsterniPFView.setValueForThisProperty(causale, resultSet.getString("AE_VALUE"));
                }
                if (!isSconfExists) {
					attributiEsterniPFView.setSconf("true");
				}
                iView = attributiEsterniPFView;
            } else if ("Plurintestazione".equals(typeOfSoggetto)) {
                final AttributiEsterniPLView attributiEsterniPLView = new AttributiEsterniPLView();
                while (resultSet.next()) {
                    causale = ClassificazioneHandler.getClassificazioneView(Long.valueOf(resultSet.getLong("AE_RIGHT_PK"))).getCausale();
                    if ("sconf".equals(causale)) {
						isSconfExists = true;
					}
                    attributiEsterniPLView.setValueForThisProperty(causale, resultSet.getString("AE_VALUE"));
                }
                if (!isSconfExists) {
					attributiEsterniPLView.setSconf("true");
				}
                iView = attributiEsterniPLView;
            } else if ("UNITA' ORGANIZZATIVA".equals(new TipoSoggettoHandler().getParentTipoSoggetto(soggettoId))) {
                final AttributiEsterniATSView attributiEsterniATSView = new AttributiEsterniATSView();
                while (resultSet.next()) {
                    causale = ClassificazioneHandler.getClassificazioneView(Long.valueOf(resultSet.getLong("AE_RIGHT_PK"))).getCausale();
                    attributiEsterniATSView.setValueForThisProperty(causale, resultSet.getString("AE_VALUE"));
                }
                iView = attributiEsterniATSView;
            } else {
                final AttributiEsterniAZView attributiEsterniAZView = new AttributiEsterniAZView();
                while (resultSet.next()) {
                    causale = ClassificazioneHandler.getClassificazioneView(Long.valueOf(resultSet.getLong("AE_RIGHT_PK"))).getCausale();
                    if ("sconf".equals(causale)) {
						isSconfExists = true;
					}
                    attributiEsterniAZView.setValueForThisProperty(causale, resultSet.getString("AE_VALUE"));
                }
                if (!isSconfExists){
                	attributiEsterniAZView.setSconf("true");
                }
                if(attributiEsterniAZView.getClasse() != null){
                	final Hashtable<String, String> parentCodeTable = new ClasseATECODBAccessHelper()
							.getClasseATECOParentCodeByLevel3Code(attributiEsterniAZView.getClasse());
                	if(parentCodeTable != null){
                		attributiEsterniAZView.setAttSezione(parentCodeTable.get("ATT_SEZIONE"));
                		attributiEsterniAZView.setAttDivisione(parentCodeTable.get("ATT_DIVISIONE"));
                	}
                }
                
                iView = attributiEsterniAZView;
            }
        } catch (final SQLException se) {
            log4Debug.severeStackTrace(se);
            throw new AttributiEsterniDiscriminatorException(se.getLocalizedMessage());
        } catch (final InvocationTargetException ie) {
            log4Debug.severeStackTrace(ie);
            throw new AttributiEsterniDiscriminatorException(ie.getLocalizedMessage());
        } catch (final IllegalAccessException ae) {
            log4Debug.severeStackTrace(ae);
            throw new AttributiEsterniDiscriminatorException(ae.getLocalizedMessage());
        } catch (final NoSuchMethodException me) {
            log4Debug.severeStackTrace(me);
            throw new AttributiEsterniDiscriminatorException(me.getLocalizedMessage());
        } catch (final InstantiationException ie) {
            log4Debug.severeStackTrace(ie);
            throw new AttributiEsterniDiscriminatorException(ie.getLocalizedMessage());
        } catch (final ClassNotFoundException cnfe) {
            log4Debug.severeStackTrace(cnfe);
            throw new AttributiEsterniDiscriminatorException(cnfe.getLocalizedMessage());
        } catch (final GestoreAnagrafeException cnfe) {
            log4Debug.severeStackTrace(cnfe);
            throw new AttributiEsterniDiscriminatorException(cnfe.getLocalizedMessage());
        } finally {
            cleanup(connection, preparedStatement, resultSet);
        }
        return iView;
    }
    
}


