package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreClasseATECOException;
import it.sella.anagrafe.view.ClasseATECOView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ClasseATECOUpdateHelper extends DBAccessHelper {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(ClasseATECOUpdateHelper.class);
	
	public Long createClasseATECO(final ClasseATECOView classeATECOView ) throws GestoreClasseATECOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        final StringBuilder querybuilder = new StringBuilder();
        Long classeATECOId = null;
        try {
            connection = getConnection();
            
            preparedStatement = connection.prepareStatement("SELECT AN_CL_SQ_CL_ID.NEXTVAL FROM DUAL");
            resultSet = preparedStatement.executeQuery();
            if( resultSet.next() ) {
            	classeATECOId = resultSet.getLong(1);
            }
            closeStatement(preparedStatement);
            
            querybuilder.append("INSERT INTO AN_MA_CLASSE_ATECO2007 (CL_ID,CL_COD,CL_DESC,CL_PARENT_ID,CL_LEVEL) ");
            querybuilder.append("VALUES(?, ? , ?, ?, ?)");
            
            preparedStatement = connection.prepareStatement(querybuilder.toString());
            preparedStatement.setLong(1, classeATECOId);
            preparedStatement.setString(2, classeATECOView.getCode());
            preparedStatement.setString(3, classeATECOView.getDescrpition());
            checkForNullAndSetLongValue(preparedStatement ,classeATECOView.getParentId() ,4);
            checkForNullAndSetLongValue(preparedStatement ,classeATECOView.getLevel() ,5);
            preparedStatement.executeUpdate();
            return classeATECOId;
        } catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new GestoreClasseATECOException(se.getLocalizedMessage());
        } finally {
            cleanup(connection, preparedStatement, resultSet);
        }
	}

	public void updateClasseATECO(final ClasseATECOView classeATECOView ) throws GestoreClasseATECOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        final StringBuilder querybuilder = new StringBuilder();
        try {
            connection = getConnection();
            querybuilder.append("UPDATE AN_MA_CLASSE_ATECO2007 SET CL_COD = ?, CL_DESC = ? ,CL_PARENT_ID=?, ");
            querybuilder.append("CL_LEVEL=? WHERE CL_ID = ? ");
            preparedStatement = connection.prepareStatement(querybuilder.toString());
            preparedStatement.setString(1, classeATECOView.getCode());
            preparedStatement.setString(2, classeATECOView.getDescrpition());
            checkForNullAndSetLongValue(preparedStatement ,classeATECOView.getParentId() ,3);
            checkForNullAndSetLongValue(preparedStatement ,classeATECOView.getLevel() ,4);
            preparedStatement.setLong(5, classeATECOView.getId());
            preparedStatement.executeUpdate();
        } catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new GestoreClasseATECOException(se.getLocalizedMessage());
        } finally {
            cleanup(connection, preparedStatement);
        }
	}
	
	public void deleteClasseATECO(final Long classeATECOId ) throws GestoreClasseATECOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        final StringBuilder querybuilder = new StringBuilder();
        try {
            connection = getConnection();
            querybuilder.append("DELETE FROM AN_MA_CLASSE_ATECO2007 WHERE CL_ID = ?");
            preparedStatement = connection.prepareStatement(querybuilder.toString());
            preparedStatement.setLong(1, classeATECOId);
            preparedStatement.executeUpdate();
        } catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new GestoreClasseATECOException(se.getLocalizedMessage());
        } finally {
            cleanup(connection, preparedStatement);
        }
	}
}