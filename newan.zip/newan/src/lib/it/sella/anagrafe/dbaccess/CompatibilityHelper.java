package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.InformazioneManagerException;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.anagrafe.util.CompatibilityTypeService;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import javax.ejb.EJBException;

public class CompatibilityHelper extends DBAccessHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CompatibilityHelper.class);

    public Collection getCompatibleMotivi( final Long tipoSoggettoId, final Long tipoSocietaId ) throws InformazioneManagerException, RemoteException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        final Vector motiviVector = new Vector(1);
        ResultSet selectResultSet = null;
        try {
            connection = getConnection();
            if( tipoSocietaId == null ) {
                selectStatement = connection.prepareStatement(" SELECT DISTINCT(CM_MOTIVO_ID) FROM AN_MA_COMPATIBLE_MOTIVO WHERE CM_TIPOSOGGETTO_ID = ?");
                selectStatement.setLong(1, tipoSoggettoId.longValue());
            } else {
                selectStatement = connection.prepareStatement(" SELECT CM_MOTIVO_ID FROM AN_MA_COMPATIBLE_MOTIVO WHERE CM_TIPOSOGGETTO_ID = ? AND CM_TIPOSOCIETA_ID = ?");
                selectStatement.setLong(1, tipoSoggettoId.longValue());
                selectStatement.setLong(2, tipoSocietaId.longValue());
            }
            selectResultSet = selectStatement.executeQuery();
            while( selectResultSet.next() ) {
                motiviVector.add(ClassificazioneHandler.getClassificazioneView(Long.valueOf(selectResultSet.getLong("CM_MOTIVO_ID"))));
            }
        } catch(final SQLException exception) {
            log4Debug.warnStackTrace(exception);
            throw new EJBException(exception.getMessage());
        } catch(final GestoreAnagrafeException e) {
            log4Debug.warnStackTrace(e);
            throw new EJBException(e.getMessage());
        } finally {
            cleanup(connection, selectStatement, selectResultSet);
        }
        return !motiviVector.isEmpty() ? motiviVector : null;
    }

    public Collection getCompatibleAttributiEsterni( final String tipoSoggetto ) throws RemoteException {
    	Vector causaleVec = new Vector(1);
        try {
        	final Collection attributiEsterniColl = CompatibilityTypeService.getCompatibleAttributiEsterniAttributi(tipoSoggetto);
            if ( attributiEsterniColl != null ) {
            	final int attributiEsterniCollSize = attributiEsterniColl.size();
            	final Iterator it = attributiEsterniColl.iterator();
                ClassificazioneView classificazioneView = null;
                for( int i = 0; i < attributiEsterniCollSize; i++ ) {
                    classificazioneView = (ClassificazioneView) it.next();
                    causaleVec.add(classificazioneView.getCausale());
                }
            } else {
                causaleVec = null;
            }
        } catch (final GestoreAnagrafeException e) {
            log4Debug.severeStackTrace(e);
            throw new RemoteException(e.getMessage());
        }
        return causaleVec;
    }

    public Collection getCompatibleTipoIntermediari() throws OperazioneAnagrafeManagerException {
    	final Collection compatibleIntermediari = new Vector(3);
        try {
        	if("Y".equals(new BancaDettagliGetterHelper().getCheckDipct(SecurityHandler.getLoginBancaId()))){
        		compatibleIntermediari.add(ClassificazioneHandler.getClassificazioneView("DIPCT", "MOTIV"));
        	}
            compatibleIntermediari.add(ClassificazioneHandler.getClassificazioneView("PROCT", "MOTIV"));
            compatibleIntermediari.add(ClassificazioneHandler.getClassificazioneView("SVICT", "MOTIV"));
        } catch (final GestoreAnagrafeException e) {
            log4Debug.severeStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage());
        }  catch (final RemoteException e) {
            log4Debug.severeStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage());
        }
        return compatibleIntermediari;
    }

    public Hashtable getCompatibleTipoSoggetto() throws InformazioneManagerException {
        final Hashtable compatibleTipoSoggetto = new Hashtable(1);
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            final String query = "SELECT TS_TIPOSOGGETTO_ID, TS_DESC,TS_ALTRI_DESC FROM AN_MA_TIPO_SOGGETTO WHERE TS_PARENT_ID IN ( SELECT TS_TIPOSOGGETTO_ID FROM AN_MA_TIPO_SOGGETTO WHERE TS_PARENT_ID = (SELECT TS_TIPOSOGGETTO_ID FROM AN_MA_TIPO_SOGGETTO WHERE TS_DESC = 'AZIENDE')) ";
            statement = connection.prepareStatement(query);
            resultSet = statement.executeQuery();
            getCompatibleTipoSoggettoInResultSet(compatibleTipoSoggetto,resultSet);
          /*  String temp = "";
            while(resultSet.next()) {
                if(compatibleTipoSoggetto == null)
                    compatibleTipoSoggetto = new Hashtable();
                temp = resultSet.getString("TS_DESC")+"^"+resultSet.getString("TS_ALTRI_DESC");
                compatibleTipoSoggetto.put(new Long(resultSet.getLong("TS_TIPOSOGGETTO_ID")), temp);
            }*/
        } catch(final SQLException se) {
            log4Debug.severeStackTrace(se);
            throw new InformazioneManagerException(se.getMessage());
        } finally {
            cleanup(connection, statement, resultSet);
        }
        return compatibleTipoSoggetto;
    }

    public Hashtable getCompatibleTipoSoggetto( final String parentTipoSoggettoDesc ) throws InformazioneManagerException {
    	final Hashtable compatibleTipoSoggetto = new Hashtable(1);
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            final String query = " SELECT TS_TIPOSOGGETTO_ID, TS_DESC,TS_ALTRI_DESC FROM AN_MA_TIPO_SOGGETTO WHERE TS_PARENT_ID = ( SELECT TS_TIPOSOGGETTO_ID FROM AN_MA_TIPO_SOGGETTO WHERE TS_DESC = ? )";
            statement = connection.prepareStatement(query);
            statement.setString(1,parentTipoSoggettoDesc);
            resultSet = statement.executeQuery();
            getCompatibleTipoSoggettoInResultSet(compatibleTipoSoggetto,resultSet);
        } catch(final SQLException se) {
            log4Debug.severeStackTrace(se);
            throw new InformazioneManagerException(se.getMessage());
        } finally {
            cleanup(connection, statement, resultSet);
        }
        return compatibleTipoSoggetto;
    }

    private void getCompatibleTipoSoggettoInResultSet( final Hashtable compatibleTipoSoggetto, final ResultSet resultSet ) throws SQLException {
    	while( resultSet.next() ) {
          compatibleTipoSoggetto.put(Long.valueOf(resultSet.getLong("TS_TIPOSOGGETTO_ID")), (resultSet.getString("TS_DESC")+"^"+resultSet.getString("TS_ALTRI_DESC")));
        }
    }

    public Collection getCompatibleTipoSocieta( final Long tipoSoggettoId ) throws RemoteException {
        Collection tipoSocieta = null;
        try {
            tipoSocieta = CompatibilityTypeService.getCompatibleTipoSocieta(tipoSoggettoId);
        } catch (final GestoreAnagrafeException e) {
            log4Debug.warnStackTrace(e);
            throw new RemoteException(e.getMessage());
        }
        return tipoSocieta;
    }

    /* This method only used for GestoreAnagrafeImplBecan */

    public Collection getCompatibleTipoSocietaForTipoSoggetto( final Long tipoSoggettoId ) throws InformazioneManagerException,RemoteException {
        Collection tipoSocieta = null;
        try {
            tipoSocieta = CompatibilityTypeService.getCompatibleTipoSocieta(tipoSoggettoId);
        }catch (final GestoreAnagrafeException e) {
        	log4Debug.warnStackTrace(e);
            throw new InformazioneManagerException(e.getMessage());
        }
        return tipoSocieta;
    }

    public Collection getCompatibleTipoRecapiti( final String tipoSoggettoSecondLevelName ) throws RemoteException {
        Collection recapitiCollection = null;
        try {
            recapitiCollection =CompatibilityTypeService.getCompatibleTipoRecapiti(tipoSoggettoSecondLevelName);
        } catch (final GestoreAnagrafeException e) {
            log4Debug.severeStackTrace(e);
            throw new RemoteException(e.getMessage());
        }
        return recapitiCollection;
    }
}
