package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.ICapDetailView;
import it.sella.anagrafe.ICapView;
import it.sella.anagrafe.common.CAP;
import it.sella.anagrafe.common.Citta;
import it.sella.anagrafe.implementation.CapDetailView;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.StringHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Vector;

import javax.ejb.EJBException;

public class CapTableHandler extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CapTableHandler.class);

    public CAP getCap(final String capValue) {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet capResultSet = null;
        CAP cap = null;
        try {
            connection = getConnection();
            selectStatement = connection.prepareStatement("SELECT CAP_ID, CA_CAP, CA_LOCALITA, CA_NOTE, CA_PROVINCIA FROM AN_MA_CAP WHERE CA_CAP = ?");
            selectStatement.setString(1, capValue);
            capResultSet = selectStatement.executeQuery();
            if(capResultSet.next()) {
				cap = getCapFromResultSet(capResultSet);
			}
        } catch(final SQLException se) {
            log4Debug.severeStackTrace(se);
            throw new EJBException(se);
        } finally {
            cleanup(connection, selectStatement, capResultSet);
        }
        if(cap == null) {
            cap = new CAP();
            cap.setCap(capValue);
        }
        return cap;
    }

    public CAP getCap(final Long capId) {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet capResultSet = null;
        CAP cap = null;
        try {
            connection = getConnection();
            selectStatement = connection.prepareStatement("SELECT CAP_ID, CA_CAP, CA_LOCALITA, CA_NOTE, CA_PROVINCIA FROM AN_MA_CAP WHERE CAP_ID = ?");
            selectStatement.setLong(1, capId.longValue());
            capResultSet = selectStatement.executeQuery();
            cap = capResultSet.next() ? getCapFromResultSet(capResultSet) : null;
        } catch(final SQLException se) {
            log4Debug.severeStackTrace(se);
            throw new EJBException(se);
        } finally {
            cleanup(connection, selectStatement, capResultSet);
        }
        return cap;
    }

    public ICapView getCap(final String capValue, final String citta) throws GestoreAnagrafeException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet capResultSet = null;
        try {
            connection = getConnection();
            selectStatement = connection.prepareStatement("select CAP_ID, CA_NOTE, CA_PROVINCIA, CA_CAP, CA_LOCALITA from AN_MA_CAP where CA_CAP = ? and  CA_LOCALITA = ?");
            selectStatement.setString(1, capValue);
            selectStatement.setString(2, citta);
            capResultSet = selectStatement.executeQuery();
            return capResultSet.next() ? getCapFromResultSet(capResultSet) : null;
        } catch (final SQLException se) {
            log4Debug.severeStackTrace(se);
            throw new GestoreAnagrafeException(se.getMessage());
        } finally {
            cleanup(connection, selectStatement, capResultSet);
        }
    }

    public boolean isValidCAP(final String cap) throws GestoreAnagrafeException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet capResultSet = null;
        try {
            connection = getConnection();
            selectStatement = connection.prepareStatement("select CA_CAP from AN_MA_CAP where CA_CAP = ? ");
            selectStatement.setString(1, cap);
            capResultSet = selectStatement.executeQuery();
            return capResultSet.next();
        } catch (final SQLException se) {
            log4Debug.severeStackTrace(se);
            throw new GestoreAnagrafeException(se.getMessage());
        } finally {
            cleanup(connection, selectStatement, capResultSet);
        }
    }

    public boolean isValidCAP(final String cap, final String provinciaSigla) throws GestoreAnagrafeException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet capResultSet = null;
        boolean isValidCap = false;
        try {
            connection = getConnection();
            selectStatement = connection.prepareStatement("SELECT 1 FROM AN_MA_CAP C WHERE C.CA_PROVINCIA = ? and SUBSTR(CA_CAP,0,2) = ? AND ROWNUM = 1");
            selectStatement.setString(1, provinciaSigla);
            selectStatement.setString(2, cap.substring(0,2));
            capResultSet = selectStatement.executeQuery();
            isValidCap = capResultSet.next();
            return isValidCap;
        } catch (final SQLException se) {
            log4Debug.severeStackTrace(se);
            throw new GestoreAnagrafeException(se.getMessage());
        } finally {
            cleanup(connection, selectStatement, capResultSet);
        }
    }

    public void setCap(final CAP cap) throws OperazioneAnagrafeManagerException {
        Connection connection = null;
        PreparedStatement updateStatement = null;
        try {
            connection = getConnection();
            updateStatement = connection.prepareStatement("update AN_MA_CAP set CA_CAP = ?, CA_LOCALITA = ?, CA_NOTE = ?, CA_PROVINCIA = ? where CAP_ID =? ");
            if (cap.getCap() != null) {
				updateStatement.setString(1, cap.getCap().toUpperCase());
			} else {
				updateStatement.setString(1, null);
			}
            if (cap.getLocalita() != null) {
				updateStatement.setString(2, cap.getLocalita().toUpperCase());
			} else {
				updateStatement.setString(2, null);
			}
            if (cap.getNote() != null) {
				updateStatement.setString(3, cap.getNote().toUpperCase());
			} else {
				updateStatement.setString(3, null);
			}
            if (cap.getProvincia() != null) {
				updateStatement.setString(4, cap.getProvincia().toUpperCase());
			} else {
				updateStatement.setString(4, null);
			}
            if (cap.getCapId() != null) {
				updateStatement.setLong(5, cap.getCapId().longValue());
			}
            updateStatement.executeUpdate();
        } catch (final SQLException se) {
            log4Debug.severeStackTrace(se);
            throw new OperazioneAnagrafeManagerException(se.getLocalizedMessage());
        } finally {
            cleanup(connection, updateStatement);
        }
    }
    
    public Collection getAllCaps(final String capValue) throws RemoteException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet capResultSet = null;
        final Vector caps = new Vector();
        try {
            connection = getConnection();
            String query = null;
            if(capValue.endsWith("%")) {
				query = "SELECT CAP_ID, CA_CAP, CA_LOCALITA, CA_NOTE, CA_PROVINCIA FROM AN_MA_CAP WHERE CA_CAP LIKE ?";
			} else {
				query = "SELECT CAP_ID, CA_CAP, CA_LOCALITA, CA_NOTE, CA_PROVINCIA FROM AN_MA_CAP WHERE CA_CAP = ?";
			}
            selectStatement = connection.prepareStatement(query);
            selectStatement.setString(1, capValue);
            capResultSet = selectStatement.executeQuery();
            while(capResultSet.next()) {
                final CAP cap = getCapFromResultSet(capResultSet);
                cap.setLocalitaACitta(new CittaDBAccessHelper().getCittaOfGVBean(cap.getLocalita()) != null ? true : false);
                caps.add(cap);
            }
        } catch(final SQLException se) {
            log4Debug.severeStackTrace(se);
            throw new EJBException(se);
        } finally {
            cleanup(connection, selectStatement, capResultSet);
        }
        return caps;
    }
    
    public CAP getCap(final String caCap, final Citta citta) {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet capResultSet = null;
        CAP cap = null;
        try {
            if(citta == null) {
                final String errorMessage = "Citta ";
				throw new IllegalArgumentException(errorMessage + new AnagrafeHelper().getMessage("ANAG-1264"));
            }
            connection = getConnection();
            selectStatement = connection.prepareStatement("SELECT CAP_ID, CA_CAP, CA_LOCALITA, CA_NOTE, CA_PROVINCIA FROM AN_MA_CAP WHERE CA_CAP = ? AND  CA_LOCALITA = ?");
            selectStatement.setString(1, caCap);
            selectStatement.setString(2, citta.getCommune());
            capResultSet = selectStatement.executeQuery();
            while(capResultSet.next()) {
				cap = getCapFromResultSet(capResultSet);
			}
        } catch(final SQLException se) {
            log4Debug.severeStackTrace(se);
            throw new EJBException(se);
        } finally {
            cleanup(connection, selectStatement, capResultSet);
        }
        return cap;
    }
    
    public Collection<ICapDetailView> getCapDetForCapCode(final String capCode) throws GestoreAnagrafeException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet capResultSet = null;
        CapDetailView capDetView = null;
        Collection<ICapDetailView> capDetail = new ArrayList<ICapDetailView>();
        try {
            if(new StringHandler().isEmpty(capCode) ) {
				throw new IllegalArgumentException( new AnagrafeHelper().getMessage("ANAG-1379"));
            }
            connection = getConnection();
            selectStatement = connection.prepareStatement("SELECT CAPCODE, LOCALITA, PROVINCIA, STATE, VALID FROM TABLE(CAST(AN_PKG_IGESTORE_ANAG_MASTER.AN_FN_GETCAP_DET_FOR_CAPCODE(?) as AN_TY_CAP_DET_TBL))");
            selectStatement.setString(1, capCode);
            capResultSet = selectStatement.executeQuery();
            while(capResultSet.next()) {
            	capDetView = new CapDetailView();
            	capDetView.setCapCode(capResultSet.getString("CAPCODE"));
            	capDetView.setLocalita(capResultSet.getString("LOCALITA"));
            	capDetView.setProvincia(capResultSet.getString("PROVINCIA"));
            	capDetView.setState(capResultSet.getString("STATE"));
            	capDetView.setIsCapValid(capResultSet.getString("VALID"));
            	capDetail.add(capDetView);
			}
        } catch(final SQLException se) {
            log4Debug.severeStackTrace(se);
            throw new GestoreAnagrafeException(se.getMessage());
        } finally {
            cleanup(connection, selectStatement, capResultSet);
        }
        return capDetail;
    }

    private CAP getCapFromResultSet(final ResultSet capResultSet) throws SQLException {
        final CAP cap = new CAP();
        cap.setCap(capResultSet.getString("CA_CAP"));
        cap.setCapId(Long.valueOf(capResultSet.getLong("CAP_ID")));
        cap.setLocalita(capResultSet.getString("CA_LOCALITA"));
        cap.setNote(capResultSet.getString("CA_NOTE"));
        cap.setProvincia(capResultSet.getString("CA_PROVINCIA"));
        return cap;
    }

}
