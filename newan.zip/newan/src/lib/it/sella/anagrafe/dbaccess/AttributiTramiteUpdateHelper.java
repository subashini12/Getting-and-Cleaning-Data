package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.attributitramite.AttributiTramite;
import it.sella.anagrafe.attributitramite.AttributiTramiteView;
import it.sella.anagrafe.attributitramite.IAttributiTramiteBeanManager;
import it.sella.anagrafe.az.AttributiTramiteAZView;
import it.sella.anagrafe.discriminator.AttributiEsterniDiscriminatorException;
import it.sella.anagrafe.implementation.IView;
import it.sella.anagrafe.util.ReflectionUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;

import javax.ejb.FinderException;

public class AttributiTramiteUpdateHelper extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AttributiTramiteUpdateHelper.class);
    
    public void createAttributiTramite( final Long soggettoId, final IView iView) throws AttributiEsterniDiscriminatorException, RemoteException { 
        try {        	
        	final AttributiTramiteAZView attributiTramiteAZView = (AttributiTramiteAZView) iView;
        	
        	final AttributiTramiteView attributiTramiteView = new AttributiTramiteView();
            attributiTramiteView.setSoggettoId(soggettoId);
            attributiTramiteView.setAROB(attributiTramiteAZView.getAROB());
            attributiTramiteView.setEROB(attributiTramiteAZView.getEROB());
            attributiTramiteView.setNazione(attributiTramiteAZView.getNazioneView() != null ? attributiTramiteAZView.getNazioneView().getNazioneId() : null );
            attributiTramiteView.setOpId(iView.getOpId());
            attributiTramiteView.setSettore(attributiTramiteAZView.getSettore());
            ((IAttributiTramiteBeanManager)getAttributiTramiteInstance()).create(attributiTramiteView);
            
        }  catch (final GestoreAnagrafeException e) {
            log4Debug.warnStackTrace(e);
            throw new AttributiEsterniDiscriminatorException(e.getMessage());
        } 
    }

	private Object getAttributiTramiteInstance()
			throws GestoreAnagrafeException {
		return ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.AttributiTramite");
	}
    
    public void setAttributiTramite(final Long soggettoId, final IView iView) throws AttributiEsterniDiscriminatorException, RemoteException {
    	final AttributiTramiteAZView attributiTramiteAZView = (AttributiTramiteAZView) iView;
    	try {
    		final AttributiTramite attributiTramiteRemote = ((IAttributiTramiteBeanManager)getAttributiTramiteInstance()).findBySoggettoId(soggettoId);
        	attributiTramiteRemote.setAROB(attributiTramiteAZView.getAROB());
        	attributiTramiteRemote.setEROB(attributiTramiteAZView.getEROB());
        	attributiTramiteRemote.setSettore(attributiTramiteAZView.getSettore());
        	attributiTramiteRemote.setNazione(attributiTramiteAZView.getNazioneView() != null ? attributiTramiteAZView.getNazioneView().getNazioneId() : null);
        	attributiTramiteRemote.setOpId(attributiTramiteAZView.getOpId());
        	((IAttributiTramiteBeanManager)getAttributiTramiteInstance()).update(attributiTramiteRemote);
        } catch (final FinderException ce) {
            log4Debug.warnStackTrace(ce);
            createAttributiTramite(soggettoId, iView);
        }  catch (final GestoreAnagrafeException e) {
            log4Debug.warnStackTrace(e);
            throw new AttributiEsterniDiscriminatorException(e.getLocalizedMessage());
        }
    }
    


}
