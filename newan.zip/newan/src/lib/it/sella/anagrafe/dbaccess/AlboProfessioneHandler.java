package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.IAPView;
import it.sella.anagrafe.common.AlboProfessione;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class AlboProfessioneHandler extends DBAccessHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory
			.getLog4Debug(AlboProfessioneHandler.class);

	/**
	 * Here collecting albo professione belongs to give tipo soggetto from DataBase, it should order by based on albo desc,
	 * and 'Non iscritto ad alcun albo' should come first.
	 * @param tipoSoggettoId
	 * @return
	 * @throws GestoreAnagrafeException
	 */
	public List<AlboProfessione> getAlboProfessioneList(final Long tipoSoggettoId)
			throws GestoreAnagrafeException {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final List<AlboProfessione> alboProfessiones = new ArrayList<AlboProfessione>();
		final StringBuffer query = new StringBuffer();
		query.append("SELECT AP.AP_ID, AP.AP_CODE, AP.AP_DESCRIPTION ");
		query.append("FROM AN_MA_ALBO_PROFESSIONE AP, AN_MA_COMP_ALBO_PROFESSIONE CAP ");
		query.append("WHERE AP.AP_ID = CAP.CA_PROF_ID AND CAP.CA_TIPOSOGGETTO_ID = ? ");
		query.append("ORDER BY CASE WHEN AP.AP_DESCRIPTION = 'Non iscritto ad alcun albo' THEN ");
		query.append("1 ELSE 2 END, AP.AP_DESCRIPTION ");
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setLong(1, tipoSoggettoId.longValue());
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				final AlboProfessione albo = new AlboProfessione();
				
				albo.setAlboId(Long.valueOf(resultSet.getLong("AP_ID")));
				albo.setAlboCode(resultSet.getString("AP_CODE"));
				albo.setAlboDesc(resultSet.getString("AP_DESCRIPTION"));
				alboProfessiones.add(albo);
				
			}
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return alboProfessiones;
	}
	
	public AlboProfessione getAlbo(final Long id) throws GestoreAnagrafeException {
		
		if(id == null) {
			throw new GestoreAnagrafeException("Albo Professione ID should not be null");
		}
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final AlboProfessione albo = new AlboProfessione();
		try {
			connection = getConnection();
			statement = connection.prepareStatement("SELECT AN_PKG_IGESTORE_ANAG_MASTER.AN_FN_ALBO( ? ) FROM DUAL");
			statement.setLong(1, id);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				final oracle.sql.STRUCT resultSetObj = wrapperForSTRUCT(resultSet.getObject(1));
				final Object[] alboProfessioneValues = resultSetObj.getAttributes();
				albo.setAlboId(Long.valueOf(alboProfessioneValues[0].toString()));
				albo.setAlboCode((String) alboProfessioneValues[1]);
				albo.setAlboDesc((String) alboProfessioneValues[2]);
			}
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return albo;
	}
	public AlboProfessione getAlboProfessioneById(final Long id) throws GestoreAnagrafeException {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final AlboProfessione albo = new AlboProfessione();
		final StringBuffer query = new StringBuffer();
		query.append("SELECT AP.AP_ID, AP.AP_CODE, AP.AP_DESCRIPTION FROM AN_MA_ALBO_PROFESSIONE AP WHERE AP.AP_ID = ? ");
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setLong(1, id.longValue());
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				albo.setAlboId(Long.valueOf(resultSet.getLong("AP_ID")));
				albo.setAlboCode(resultSet.getString("AP_CODE"));
				albo.setAlboDesc(resultSet.getString("AP_DESCRIPTION"));
			}
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return albo;
	}
	public AlboProfessione getAlboProfessioneByDesc(final String desc, final int tipoSoggetto) throws GestoreAnagrafeException {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final AlboProfessione albo = new AlboProfessione();
		final StringBuffer query = new StringBuffer();
		query.append("SELECT AP.AP_ID, AP.AP_CODE, AP.AP_DESCRIPTION FROM AN_MA_ALBO_PROFESSIONE AP, AN_MA_COMP_ALBO_PROFESSIONE CP ");
		query.append("WHERE AP.AP_ID = CP.CA_PROF_ID AND AP.AP_DESCRIPTION = ? AND CP.CA_TIPOSOGGETTO_ID = ? ");
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setString(1, desc);
			statement.setInt(2, tipoSoggetto);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				albo.setAlboId(Long.valueOf(resultSet.getLong("AP_ID")));
				albo.setAlboCode(resultSet.getString("AP_CODE"));
				albo.setAlboDesc(resultSet.getString("AP_DESCRIPTION"));
			}
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return albo;
	}
	
	public Collection<IAPView> getAllAlbo(final String tipoSoggetto) throws GestoreAnagrafeException{
		
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		AlboProfessione albo = null;
		final Collection<IAPView> alboList = new ArrayList<IAPView>();
		final StringBuffer query = new StringBuffer();
		query.append("SELECT ALBO_ID, ALBO_CODE, ALBO_DESC FROM TABLE(AN_PKG_IGESTORE_ANAG_MASTER.AN_FN_LIST_ALBO( ?  ))");
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setString(1, tipoSoggetto);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				albo = new AlboProfessione();
				albo.setAlboId(Long.valueOf(resultSet.getLong("ALBO_ID")));
				albo.setAlboCode(resultSet.getString("ALBO_CODE"));
				albo.setAlboDesc(resultSet.getString("ALBO_DESC"));
				alboList.add(albo);
			}
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return alboList;
	}
	/*public List<AlboProfessione> getAlboProfessione() throws GestoreAnagrafeException {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final List<AlboProfessione> alboProfessiones = new ArrayList<AlboProfessione>();
		final StringBuffer query = new StringBuffer();
		query.append("SELECT AP.AP_ID, AP.AP_CODE, AP.AP_DESCRIPTION FROM AN_MA_ALBO_PROFESSIONE AP ");
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				final AlboProfessione albo = new AlboProfessione();
				albo.setAlboId(Long.valueOf(resultSet.getLong("AP_ID")));
				albo.setAlboCode(resultSet.getString("AP_CODE"));
				albo.setAlboDesc(resultSet.getString("AP_DESCRIPTION"));
				alboProfessiones.add(albo);
			}
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return alboProfessiones;
	}*/
}