package it.sella.anagrafe.dbaccess.dai;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import it.sella.anagrafe.AnagrafeDAIException;
import it.sella.anagrafe.DAIConfigException;
import it.sella.anagrafe.DAIPesoException;
import it.sella.anagrafe.DAIRegoleDetail;
import it.sella.anagrafe.DAIRegoleDetailsView;
import it.sella.anagrafe.DAIRegoleException;
import it.sella.anagrafe.DAIWeightageException;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.IDAIRegoleDetail;
import it.sella.anagrafe.IDAIRegoleDetailsView;
import it.sella.anagrafe.dbaccess.DBAccessHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

/**
 * @author GBS03447
 *
 */
public class DAIRegoleGetterHelper extends DBAccessHelper {
	
	private static final String DR_DAI_WEIGHT_ID = "DR_DAI_WEIGHT_ID";
	private static final String DR_DAI_CODE_ID = "DR_DAI_CODE_ID";
	private static final String DR_PESO_ID = "DR_PESO_ID";
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DAIRegoleGetterHelper.class);
	
	/**
	 * This Method Returns collection of Regole Data of Given Input Soggetto. API Purpose Method
	 * @param soggettoId
	 * @return
	 * @throws AnagrafeDAIException 
	 */
	public Collection<IDAIRegoleDetail> getDAIRegoleDetails(final Long soggettoId) throws GestoreAnagrafeException {
		
		final Collection<IDAIRegoleDetail> daiRegoleList = new ArrayList<IDAIRegoleDetail>();
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		query.append("SELECT RD.DR_SOGGETTO_ID, DW.DW_DAI_CODE, DW.DW_DAI_CODE_DESCRIPTION, (SELECT DC_DAI_CONFIG_CODE FROM AN_MA_DAI_CONFIG WHERE DC_DAI_ID = DW.DW_DAI_GR_TYPE_ID) DAIGROUP, (SELECT DAI_DESCRIZIONE FROM AN_MA_DAI_CONFIG WHERE DC_DAI_ID = DW.DW_DAI_WEIGHT_ID) DAIWEIGHTAGE FROM AN_TR_DAI_REGOLE_DETT RD, AN_MA_DAI_WEIGT_CODE DW WHERE DR_SOGGETTO_ID = ? AND DR_DAI_CODE_ID = DW_CODE_ID ORDER BY DW_DAI_CODE");
		
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setLong(1, soggettoId);
			resultSet = statement.executeQuery();
			DAIRegoleDetail regoleDetail = null;
			while (resultSet.next()) {
				regoleDetail = new DAIRegoleDetail();
				regoleDetail.setSoggettoId(resultSet.getLong("DR_SOGGETTO_ID"));
				regoleDetail.setDaiCode(resultSet.getString("DW_DAI_CODE"));
				regoleDetail.setDaiCodeDesc(resultSet.getString("DW_DAI_CODE_DESCRIPTION"));
				regoleDetail.setDaiGroup(resultSet.getString("DAIGROUP"));
				regoleDetail.setDaiWeightage(resultSet.getString("DAIWEIGHTAGE"));
				daiRegoleList.add(regoleDetail);
			}
		} catch (final SQLException e) {
			log4Debug.severeStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return daiRegoleList;
	}
	
	/**
	 * This Method Return the List Of DAIRegole Data With weightage For the given Input Soggetto Id
	 * @param soggettoId
	 * @return
	 * @throws DAIRegoleException
	 */
	public Collection<IDAIRegoleDetailsView> getDAIRegoleDetailsForSoggetto(final Long soggettoId) throws DAIRegoleException {
		final Collection<IDAIRegoleDetailsView> daiRegoleList = new ArrayList<IDAIRegoleDetailsView>();
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		query.append("SELECT DR_ID, DR_SOGGETTO_ID, DR_PESO_ID, DR_DAI_CODE_ID, DR_DAI_WEIGHT_ID, DR_OP_ID FROM AN_TR_DAI_REGOLE_DETT WHERE DR_SOGGETTO_ID = ? ORDER BY DR_PESO_ID");
		
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setLong(1, soggettoId);
			resultSet = statement.executeQuery();
			IDAIRegoleDetailsView regoleView = null;
			while (resultSet.next()) {
				regoleView = new DAIRegoleDetailsView();
				regoleView.setId(resultSet.getLong("DR_ID"));
				regoleView.setSoggettoId(resultSet.getLong("DR_SOGGETTO_ID"));
				regoleView.setDaiPeso(resultSet.getString(DR_PESO_ID) != null ? new DAIPesoGetterHelper().getPesoViewById(resultSet.getLong(DR_PESO_ID)) : null);
				regoleView.setDaiCodeId(resultSet.getString(DR_DAI_CODE_ID) != null ? new DAIWeightageGetterHelper().getWeightageViewForId(resultSet.getLong(DR_DAI_CODE_ID)) : null);
				regoleView.setDaiWeight(resultSet.getString(DR_DAI_WEIGHT_ID) != null ? new DAIConfigGetterHelper().getDAIConfig(resultSet.getLong(DR_DAI_WEIGHT_ID)) : null);
				regoleView.setOpId(resultSet.getLong("DR_OP_ID"));
				daiRegoleList.add(regoleView);
			}
		} catch (final SQLException e) {
			log4Debug.severeStackTrace(e);
			throw new DAIRegoleException(e.getMessage(), e);
		} catch (final DAIConfigException e) {
			log4Debug.severeStackTrace(e);
			throw new DAIRegoleException(e.getMessage(), e);
		} catch (final DAIWeightageException e) {
			log4Debug.severeStackTrace(e);
			throw new DAIRegoleException(e.getMessage(), e);
		} catch (final DAIPesoException e) {
			log4Debug.severeStackTrace(e);
			throw new DAIRegoleException(e.getMessage(), e);
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return daiRegoleList;
	}
	
	/**
	 * This Method Returns Regole Data WIth Weightage For the Given regole Id
	 * @param regoleId
	 * @return
	 * @throws DAIRegoleException
	 */
	public IDAIRegoleDetailsView getDAIRegoleForRegoleId(final Long regoleId) throws DAIRegoleException {
		IDAIRegoleDetailsView regoleView = null;
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		query.append("SELECT DR_ID, DR_SOGGETTO_ID, DR_PESO_ID, DR_DAI_CODE_ID, DR_DAI_WEIGHT_ID, DR_OP_ID FROM AN_TR_DAI_REGOLE_DETT WHERE DR_ID = ? ");
		
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setLong(1, regoleId);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				regoleView = new DAIRegoleDetailsView();
				regoleView.setId(resultSet.getLong("DR_ID"));
				regoleView.setSoggettoId(resultSet.getLong("DR_SOGGETTO_ID"));
				regoleView.setDaiPeso(resultSet.getString(DR_PESO_ID) != null ? new DAIPesoGetterHelper().getPesoViewById(resultSet.getLong(DR_PESO_ID)) : null);
				regoleView.setDaiCodeId(resultSet.getString(DR_DAI_CODE_ID) != null ? new DAIWeightageGetterHelper().getWeightageViewForId(resultSet.getLong(DR_DAI_CODE_ID)) : null);
				regoleView.setDaiWeight(resultSet.getString(DR_DAI_WEIGHT_ID) != null ? new DAIConfigGetterHelper().getDAIConfig(resultSet.getLong(DR_DAI_WEIGHT_ID)) : null);
				regoleView.setOpId(resultSet.getLong("DR_OP_ID"));
			}
		} catch (final SQLException e) {
			log4Debug.severeStackTrace(e);
			throw new DAIRegoleException(e.getMessage(), e);
		} catch (final DAIConfigException e) {
			log4Debug.severeStackTrace(e);
			throw new DAIRegoleException(e.getMessage(), e);
		} catch (final DAIWeightageException e) {
			log4Debug.severeStackTrace(e);
			throw new DAIRegoleException(e.getMessage(), e);
		} catch (final DAIPesoException e) {
			log4Debug.severeStackTrace(e);
			throw new DAIRegoleException(e.getMessage(), e);
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return regoleView;
	}
}
