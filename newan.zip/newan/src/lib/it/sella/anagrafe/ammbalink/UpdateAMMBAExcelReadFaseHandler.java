package it.sella.anagrafe.ammbalink;

import it.sella.anagrafe.ExcelReaderWriterException;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.OperazioneAnagrafeFactory;
import it.sella.anagrafe.OperazioneAnagrafeManager;
import it.sella.anagrafe.UpdateAMMBALinkView;
import it.sella.anagrafe.dbaccess.ART136AlertDBAccess;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.anagrafe.util.AmmbaHelper;
import it.sella.anagrafe.util.excel.FTPHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.List;

public class UpdateAMMBAExcelReadFaseHandler {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(UpdateAMMBAExcelReadFaseHandler.class);

    private static final UpdateAMMBAExcelReadFaseHandler instance = new UpdateAMMBAExcelReadFaseHandler();
    
    private UpdateAMMBAExcelReadFaseHandler() {
    	
    }

    public static UpdateAMMBAExcelReadFaseHandler getInstance() {
    	return instance;
    }
    
    public void parseXLS( final String removeFileName ) throws ExcelReaderWriterException, RemoteException {
		try {
	        String fileName = null;
	        int count = -1;
	        log4Debug.debug(" UpdateAMMBAExcelReadFaseHandler : parseXLS : removeFileName : ==>>>",removeFileName);
	        final String[] fileNamesList = FTPHelper.getInstance().getFileList();
	        log4Debug.debug(" UpdateAMMBAExcelReadFaseHandler : parseXLS : fileNamesList : ==>>>",fileNamesList);
	        final OperazioneAnagrafeManager operazioneAnagrafeManager = OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager();
	        String[] removeAMMBAFileList = null;
	        Long opId = null;
	        if( fileNamesList != null && fileNamesList.length > 0 ) {
	        	final int fileLength = fileNamesList.length;
	        	log4Debug.debug(" UpdateAMMBAExcelReadFaseHandler : parseXLS : fileLength : ==>>>",String.valueOf(fileLength));
	        	List updateAMMBAList = null;
	        	removeAMMBAFileList = new String[fileLength];
	        	for( int i=0; i<fileLength; i++ ) {
	        		fileName = fileNamesList[i];
	        		log4Debug.debug(" UpdateAMMBAExcelReadFaseHandler : parseXLS : fileName ==>>>",fileName);		
	        		if( fileName != null && fileName.indexOf("ART136") != -1 && fileName.indexOf(".xls") != -1 ) {
	        			removeAMMBAFileList[++count] = fileName;
	        		}
	        	}
	        	final String excelFileName = AmmbaHelper.getLatestExcelFileNameWithPath(removeAMMBAFileList);
	        	log4Debug.debug(" UpdateAMMBAExcelReadFaseHandler : parseXLS : excelFileName : ==>>>",excelFileName);
	        	
	        	if( excelFileName != null ) {
	        		updateAMMBAList = FTPHelper.getInstance().readFile(excelFileName);
		        	if( updateAMMBAList != null && !updateAMMBAList.isEmpty() ) {
		        		operazioneAnagrafeManager.deleteAllExtractArt136();
		        		operazioneAnagrafeManager.createExtractArt136(updateAMMBAList);
		        		final Object obj = updateAMMBAList.get(0);
		        		opId = (Long) (obj != null ? ((UpdateAMMBALinkView) obj).getOpId() : obj);

		        	}
	        	}
	        }
	        if( removeAMMBAFileList == null ) {
	        	removeAMMBAFileList = new String[1];
	        }
	        removeAMMBAFileList[++count] = removeFileName;
	        FTPHelper.getInstance().removeFiles(removeAMMBAFileList);
	        String status = null;
	        if(opId != null)
	        {
	        	try {
					status = new ART136AlertDBAccess().processMail(opId);
				} catch (GestoreAnagrafeException e) {
					log4Debug.warnStackTrace(e);
				}
	        }
	        log4Debug.debug(" UpdateAMMBAExcelReadFaseHandler : Mail Status==>>>",status);
		} catch (final OperazioneAnagrafeManagerException e) {
			log4Debug.warnStackTrace(e);
			throw new ExcelReaderWriterException(e.getMessage());
		} 
	}
}
