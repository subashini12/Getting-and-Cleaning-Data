package it.sella.anagrafe.ammbalink;

import it.sella.anagrafe.OperazioneAnagrafeFactory;
import it.sella.anagrafe.UpdateAMMBAScanView;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.gestione_flussi.ElementoFlusso;
import it.sella.gestione_flussi.GestioneElementoFlussoException;
import it.sella.gestione_flussi.GestioneFlussoException;
import it.sella.gestione_flussi.MailNotificationHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;

public class UpdateAMMBALinkFlussoHandler extends MailNotificationHandler {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(UpdateAMMBALinkFlussoHandler.class);

	public void gestisciElementoFlusso( final ElementoFlusso elementOfFlusso ) throws GestioneFlussoException, RemoteException {
		try {
			UpdateAMMBAScanView updateAMMBAScanView = null;
			log4Debug.warn(" Start Flussi in UpdateAMMBALinkFlusso ====================> ");
			if( elementOfFlusso != null ) {
				updateAMMBAScanView = (UpdateAMMBAScanView) elementOfFlusso.getRealElementoFlusso() ;
			}
			if( updateAMMBAScanView != null ) {
				final String hostUserCode = CommonPropertiesHandler.getValueFromProperty("HOST_USERCODE");
				OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager().updateAmministratoriBancaInHost(updateAMMBAScanView,hostUserCode); 
			}
			log4Debug.warn(" End Flussi in UpdateAMMBALinkFlusso ====================> ");
		} catch (final OperazioneAnagrafeManagerException e) {
			log4Debug.severeStackTrace(e);
			throw new GestioneElementoFlussoException(e.getMessage(), e);
		} 
	}
}
