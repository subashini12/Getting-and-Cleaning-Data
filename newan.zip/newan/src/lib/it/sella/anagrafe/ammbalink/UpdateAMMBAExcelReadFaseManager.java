package it.sella.anagrafe.ammbalink;

import it.sella.anagrafe.ExcelReaderWriterException;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.excel.FTPHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.ByteArrayInputStream;
import java.rmi.RemoteException;

public class UpdateAMMBAExcelReadFaseManager {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(UpdateAMMBAExcelReadFaseManager.class);

    private static final UpdateAMMBAExcelReadFaseManager instance = new UpdateAMMBAExcelReadFaseManager();
    
    private UpdateAMMBAExcelReadFaseManager() {
    	
    }

    public static UpdateAMMBAExcelReadFaseManager getInstance() {
    	return instance;
    }
    
    public void createFase() throws RemoteException, ExcelReaderWriterException {
		log4Debug.severe(" <===== UpdateAMMBAExcelReadFase started ======>");
		final boolean isWorkingDay = DateHandler.isWorkingDay();
		log4Debug.debug(" UpdateAMMBAExcelReadFlussoManager : createFase : isWorkingDay ==>>",String.valueOf(isWorkingDay));
		if( isWorkingDay ) {
			FTPHelper.getInstance().writeFile(new ByteArrayInputStream(new byte[1]), "AMMBAExcelLoad.txt");
			final String fileUploadPath = CommonPropertiesHandler.getValueFromProperty("ANAG_FTP_FILEUPLOAD_PATH");
			UpdateAMMBAExcelReadFaseHandler.getInstance().parseXLS(fileUploadPath + "AMMBAExcelLoad.txt");
		}  
		log4Debug.severe(" <===== UpdateAMMBAExcelReadFase Ended ======>");
    }
}
