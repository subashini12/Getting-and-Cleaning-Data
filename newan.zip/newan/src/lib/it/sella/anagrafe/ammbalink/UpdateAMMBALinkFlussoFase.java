package it.sella.anagrafe.ammbalink;

import it.sella.anagrafe.ExcelReaderWriterException;
import it.sella.gestorefasi.IFase;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;

public class UpdateAMMBALinkFlussoFase  implements  IFase {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Log4Debug log4Debug  = Log4DebugFactory.getLog4Debug(UpdateAMMBALinkFlussoFase.class);

	public void execute() {
		try {
			UpdateAMMBALinkFlussoManager.getInstance().createFlussi();
		} catch (final RemoteException e) {
			log4Debug.severeStackTrace(e);
		} catch (final ExcelReaderWriterException e) {
			log4Debug.severeStackTrace(e);
		}
	}
}
