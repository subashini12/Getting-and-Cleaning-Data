package it.sella.anagrafe.ammbalink;

import it.sella.anagrafe.ExcelReaderWriterException;
import it.sella.anagrafe.OperazioneAnagrafeFactory;
import it.sella.anagrafe.OperazioneAnagrafeManager;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.excel.FTPHelper;
import it.sella.gestione_flussi.FlussoDescriptor;
import it.sella.gestione_flussi.GestioneFlussiManager;
import it.sella.gestione_flussi.GestioneFlussiManagerFactory;
import it.sella.gestione_flussi.GestioneFlussoException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.List;

public class UpdateAMMBALinkFlussoManager {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(UpdateAMMBALinkFlussoManager.class);

    private static final UpdateAMMBALinkFlussoManager instance = new UpdateAMMBALinkFlussoManager();
    
    private UpdateAMMBALinkFlussoManager() {
    	
    }

    public static UpdateAMMBALinkFlussoManager getInstance() {
    	return instance;
    }
    
    public void createFlussi() throws RemoteException, ExcelReaderWriterException {
    	try {
    		log4Debug.severe(" <===== UpdateAMMBALinkFlussi started ======>");
    		final boolean isWorkingDay = DateHandler.isWorkingDay();
    		log4Debug.debug(" UpdateAMMBALinkFlussoManager : createFlussi : isWorkingDay ==>>",String.valueOf(isWorkingDay));
    		if( isWorkingDay ) {
    			boolean isExistAMMBALoadFile = false;
    			log4Debug.debug(" UpdateAMMBALinkFlussoManager : createFlussi : To check is not exist  AMMBAExcelLoad.txt==>>");
    			do {
        			final String[] fileNamesList = FTPHelper.getInstance().getFileList();
        			if( fileNamesList != null && fileNamesList.length > 0 ) {
        				final int size = fileNamesList.length;
        				String fileName = null;
        				isExistAMMBALoadFile = false;
        				for ( int i=0; i<size; i++ ) {
        					fileName = fileNamesList[i];
        					if( fileName != null && fileName.indexOf("AMMBAExcelLoad.txt") != -1 ) {
        						isExistAMMBALoadFile = true;
        					}
        				}
        			}
        			log4Debug.debug(" UpdateAMMBALinkFlussoManager : createFlussi : isExistAMMBALoadFile ==>>", String.valueOf(isExistAMMBALoadFile));	
    			} while ( isExistAMMBALoadFile );
    			final OperazioneAnagrafeManager operazioneAnagrafeManager = OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager();
    			operazioneAnagrafeManager.createExtendArt136Scan();
    			final List exartScanList = operazioneAnagrafeManager.getAllExtendArt136Scan();
    			if( exartScanList != null && !exartScanList.isEmpty() ) {
		        	final StringBuffer nomeFlusso = new StringBuffer("UPDATEAMMBALINK:COLLECTION(");
		        	final DateHandler dateHandler = new DateHandler();
		        	nomeFlusso .append(dateHandler.formatDate(dateHandler.getCurrentDateInTimeStampFormat(), "ddMMyyyy:hhmmss"));
		        	final GestioneFlussiManager gestioneFlussiManager = GestioneFlussiManagerFactory.getInstance().getGestioneFlussiManager();
		        	final String ammbaFlussiName = CommonPropertiesHandler.getValueFromProperty("AMMBAFLUSSINAME");
		        	log4Debug.debug(" ammbaFlussiName =================>",ammbaFlussiName);
		            final UpdateAMMBALinkFlussoHandler updateAMMBALinkFlussoHandler = new UpdateAMMBALinkFlussoHandler();
		            final String anagrafeGroupMailId = CommonPropertiesHandler.getValueFromProperty("ANAGRAFE_GROUP_MAIL_ID");
		            log4Debug.debug(" anagrafeGroupMailId =================>",anagrafeGroupMailId);
		            updateAMMBALinkFlussoHandler.addToUserName(anagrafeGroupMailId);
					final FlussoDescriptor descriptor = new FlussoDescriptor(nomeFlusso.toString(), ammbaFlussiName, exartScanList, updateAMMBALinkFlussoHandler);
					gestioneFlussiManager.gestisciFlusso(descriptor);
    			} 
    		}  
    		log4Debug.severe(" <===== UpdateAMMBALinkFlussi Ended ======>");
		} catch (final GestioneFlussoException e) {
			log4Debug.warnStackTrace(e);
			throw new ExcelReaderWriterException(e.getMessage());
		} catch (final OperazioneAnagrafeManagerException e) {
			log4Debug.warnStackTrace(e);
			throw new ExcelReaderWriterException(e.getMessage());
		} 
    }
}
