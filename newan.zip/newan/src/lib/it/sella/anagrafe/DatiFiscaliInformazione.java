package it.sella.anagrafe;

import java.rmi.RemoteException;

public interface DatiFiscaliInformazione { 

    Long getSoggettoIdForDatiFiscali(String s, String s1) throws RemoteException;

    boolean isExistsDatiFiscali(String code, String causale) throws RemoteException;

}
