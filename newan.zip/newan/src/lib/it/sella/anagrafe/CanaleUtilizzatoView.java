package it.sella.anagrafe;

import java.sql.Timestamp;

public class CanaleUtilizzatoView implements ICanaleUtilizzatoView {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private Long soggettoId;
	private String canaleUtilizzato;
	private Timestamp dataInizio;
	private Timestamp dataFine;
	private Long opId;
	
	public Long getId() {
		return id;
	}
	
	public void setId(final Long id) {
		this.id = id;
	}
	
	public Long getSoggettoId() {
		return soggettoId;
	}
	
	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}
	
	public String getCanaleUtilizzato() {
		return canaleUtilizzato;
	}
	
	public void setCanaleUtilizzato(final String canaleUtilizzato) {
		this.canaleUtilizzato = canaleUtilizzato;
	}
	
	public Timestamp getDataInizio() {
		return dataInizio;
	}
	
	public void setDataInizio(final Timestamp dataInizio) {
		this.dataInizio = dataInizio;
	}
	
	public Timestamp getDataFine() {
		return dataFine;
	}
	
	public void setDataFine(final Timestamp dataFine) {
		this.dataFine = dataFine;
	}
	
	public Long getOpId() {
		return opId;
	}
	
	public void setOpId(final Long opId) {
		this.opId = opId;
	}

}
