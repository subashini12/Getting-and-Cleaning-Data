package it.sella.anagrafe;

import java.sql.Timestamp;

/**
 * @author GBS03447
 *
 */
public class DAIPesoView implements IDAIPesoView {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long pesoId;
	private IDAIConfigView daiGroupType;
	private IDAIConfigView daiCode;
	private Timestamp dataInizio;
	private Timestamp datFine;

	public Long getPesoId() {
		return pesoId;
	}

	public void setPesoId(final Long pesoId) {
		this.pesoId = pesoId;
	}

	public IDAIConfigView getDaiGroupType() {
		return daiGroupType;
	}

	public void setDaiGroupType(final IDAIConfigView daiGroupType) {
		this.daiGroupType = daiGroupType;
	}

	public IDAIConfigView getDaiCode() {
		return daiCode;
	}

	public void setDaiCode(final IDAIConfigView daiCode) {
		this.daiCode = daiCode;
	}

	public Timestamp getDataInizio() {
		return dataInizio;
	}

	public void setDataInizio(final Timestamp dataInizio) {
		this.dataInizio = dataInizio;
	}

	public Timestamp getDatFine() {
		return datFine;
	}

	public void setDatFine(final Timestamp datFine) {
		this.datFine = datFine;
	}

}
