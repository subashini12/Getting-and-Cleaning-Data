package it.sella.anagrafe.codicisoggetto;

import it.sella.anagrafe.GestoreAnagrafeException;

import java.util.Collection;

import javax.ejb.FinderException;

public interface ICodiciSoggettoBeanManager {
	
	/**
	 * Method to create CodiciSoggetto
	 * @param codiciSoggetto
	 * @return
	 * @throws GestoreAnagrafeException
	 */
	CodiciSoggetto create (CodiciSoggetto codiciSoggetto) throws GestoreAnagrafeException;
	
	/**
	 * Method to update CodiciSoggetto
	 * @param codiciSoggetto
	 * @return
	 */
	CodiciSoggetto update (CodiciSoggetto codiciSoggetto);

	/**
	 * Method to find data using primary key
	 * @param primaryKey
	 * @return
	 * @throws FinderException
	 */
	CodiciSoggetto findByPrimaryKey (Long primaryKey) throws FinderException;

    /**
     * Method to find data using SoggettoId
     * @param soggettoId
     * @return
     * @throws FinderException
     */
    Collection<CodiciSoggetto> findBySoggettoId (Long soggettoId) throws FinderException;

    /**
     * Method to find data using NDG and NonOperativa
     * @param ndg
     * @param rightPK
     * @return
     * @throws FinderException
     */
    CodiciSoggetto findByNDGNonOperativa (String ndg, Long rightPK) throws FinderException;

    /**
     * Method to find data using CodiceDipendente
     * @param codice
     * @param rightPK
     * @return
     * @throws FinderException
     */
    CodiciSoggetto findByCodiceDipendente (String codice, Long rightPK) throws FinderException;

    /**
     * Method to find data using CodicePromotore
     * @param codice
     * @param rightPK
     * @return
     * @throws FinderException
     */
    CodiciSoggetto findByCodicePromotore (String codice, Long rightPK) throws FinderException;

    /**
     * Method to find data using SogettoId and RightPK
     * @param soggettoId
     * @param rightPk
     * @return
     * @throws FinderException
     */
    CodiciSoggetto findBySoggettoIdAndRightPK (Long soggettoId, Long rightPk) throws FinderException;
    
    /**
     * Method to remove data fom CodiciSoggetto
     * @param codiciSoggetto
     */
    void remove(CodiciSoggetto codiciSoggetto);
}
