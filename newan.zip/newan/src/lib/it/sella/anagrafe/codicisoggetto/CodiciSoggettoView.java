package it.sella.anagrafe.codicisoggetto;

public class CodiciSoggettoView implements CodiciSoggetto{ //extends EJBViewAdapter {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long id;
    private Long soggettoId;
    private String value;
    private Long rightPk;
    private Long opId;

    public CodiciSoggettoView() {
    }

    public CodiciSoggettoView(final Long soggettoId, final String value, final Long opId) {
        this.setSoggettoId(soggettoId);
        this.setValue(value);
        this.setOpId(opId);
    }

//public getter methods
    public Long getSoggettoId() {
        return this.soggettoId;
    }

    public String getValue() {
        return this.value;
    }

    public Long getRightPk() {
        return this.rightPk;
    }

	public Long getOpId() {
		return this.opId;
	}

//public setter methods
    public void setSoggettoId(final Long soggettoId) {
        this.soggettoId = soggettoId;
    }

    public void setValue(final String value) {
        this.value = value;
    }

    public void setRightPk(final Long rightPk) {
        this.rightPk = rightPk;
    }

	public void setOpId(final Long opId) {
		this.opId = opId;
	}

//protected parameterlist methods
    protected String getParameterList() {
        return "Soggetto Id";
    }

    protected String getShortParameterList() {
        return getParameterList();
    }

	public Long getId() {
		return id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

}

