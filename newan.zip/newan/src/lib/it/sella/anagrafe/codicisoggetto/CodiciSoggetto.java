package it.sella.anagrafe.codicisoggetto;

import java.io.Serializable;

public interface CodiciSoggetto extends Serializable {
	
	Long getId();
	
    Long getSoggettoId ();

    String getValue ();

    Long getRightPk ();

    Long getOpId();
    
    void setId(Long id);
    
    void setSoggettoId (Long soggettoId);

    void setValue (String value);

    void setRightPk (Long rightId);

    void setOpId(Long opId);    
}