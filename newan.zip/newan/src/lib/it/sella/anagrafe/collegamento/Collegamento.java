package it.sella.anagrafe.collegamento;

import java.io.Serializable;
import java.sql.Timestamp;

public interface Collegamento extends Serializable {
	
	Long getCollegamentoId();
    Long getSoggettoId();
    Long getMotivo();
    String getNote();
    Timestamp getDataInizio();
    Timestamp getDataFine();
    Long getLinkedSoggettoId();
    Long getOpId();
    
    void setCollegamentoId(Long collegamentoId);
    void setSoggettoId(Long soggettoId);
    void setMotivo(Long motivo);
    void setNote(String note);
    void setDataInizio(java.sql.Timestamp dataInizio);
    void setDataFine(java.sql.Timestamp dataFine);
    void setLinkedSoggettoId(Long linkedSoggettoId);
    void setOpId(Long opId);
}


