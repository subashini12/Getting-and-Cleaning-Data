package it.sella.anagrafe.collegamento;

import java.sql.Timestamp;

public class CollegamentoView  implements Collegamento {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long collegamentoId;
	public Long soggettoId;
    public Long motivo;
    public String note;
    public Timestamp dataInizio;
    public Timestamp dataFine;
    public Long linkedSoggettoId;
    public Long opId;

	public CollegamentoView() {
    }

//public getter methods
	public Long getCollegamentoId() {
		return collegamentoId;
	}
    public Long getSoggettoId() {
        return this.soggettoId;
    }

    public Long getMotivo() {
        return this.motivo;
    }

    public String getNote() {
        return this.note;
    }

    public Timestamp getDataInizio() {
        return this.dataInizio;
    }

    public Timestamp getDataFine() {
        return this.dataFine;
    }

    public Long getLinkedSoggettoId() {
        return this.linkedSoggettoId;
    }

    public Long getOpId() {
		return this.opId;
	}

//public setter methods
    public void setCollegamentoId(final Long collegamentoId) {
		this.collegamentoId = collegamentoId;
	}

    public void setSoggettoId(final Long soggettoId) {
        this.soggettoId = soggettoId;
    }

    public void setMotivo(final Long motivo) {
        this.motivo = motivo;
    }

    public void setNote(final String note) {
        this.note = note;
    }

    public void setDataInizio(final java.sql.Timestamp dataInizio) {
        this.dataInizio = dataInizio;
    }

    public void setDataFine(final java.sql.Timestamp dataFine) {
        this.dataFine = dataFine;
    }

    public void setLinkedSoggettoId(final Long linkedSoggettoId) {
        this.linkedSoggettoId = linkedSoggettoId;
    }

	public void setOpId(final Long opId) {
		this.opId = opId;
	}

}