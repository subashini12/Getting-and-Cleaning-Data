package it.sella.anagrafe.collegamento;

import it.sella.anagrafe.GestoreAnagrafeException;

import java.sql.Timestamp;
import java.util.Collection;

import javax.ejb.FinderException;

public interface ICollegamentoBeanManager {
	/**
	 * Method to create Collegamento
	 * @param collegamento
	 * @return
	 * @throws GestoreAnagrafeException
	 */
	Collegamento create(Collegamento collegamento) throws GestoreAnagrafeException;
	
	/**
	 * Method to update Collegamento
	 * @param collegamento
	 * @return
	 */
	Collegamento update(Collegamento collegamento);
	
	/**
	 * Method to remove Collegamento
	 * @param collegamento
	 */
	void remove(Collegamento collegamento);
	
	/**
	 * Method to find by using PrimaryKey
	 * @param primaryKey
	 * @return
	 * @throws FinderException
	 */
	Collegamento findByPrimaryKey(Long primaryKey)throws FinderException;
	
	/**
	 * Method to find by using SoggettoId
	 * @param soggettoId
	 * @return
	 * @throws FinderException
	 */
	Collection<Collegamento> findBySoggettoId(Long soggettoId)throws FinderException;
	
	/**
	 * Method to find by using Soggetto, Motivo and endDate
	 * @param soggettoId
	 * @param motivo
	 * @param endDate
	 * @return
	 * @throws FinderException
	 */
	Collection<Collegamento> findBySoggettoAndMotivo(Long soggettoId , Long motivo ,Timestamp endDate)throws FinderException;
	
	/**
	 * @param principaleId
	 * @param motivo
	 * @param linkedSoggettoId
	 * @return
	 * @throws FinderException
	 */
	Collegamento findBySoggettoMotivoAndLinked(Long principaleId , Long motivo ,Long linkedSoggettoId)throws FinderException;
	
	/**
	 * Method to find by using Principal, Motivo and linked SoggettoId
	 * @param principaleId
	 * @param motivo
	 * @param linkedSoggettoId
	 * @return
	 * @throws FinderException
	 */
	Collection<Collegamento> findByPrincipalMotivoAndLinked(Long principaleId , Long motivo ,Long linkedSoggettoId)throws FinderException;
	
	/**
	 * Method to find by using LinkedSoggettoId and motivo
	 * @param linkedSoggettoId
	 * @param motivo
	 * @return
	 * @throws FinderException
	 */
	Collection<Collegamento> findBySoggettoCollegamento(Long linkedSoggettoId , Long motivo)throws FinderException;
	
	/**
	 * Method to find by using linkedSoggettoId
	 * @param linkedSoggettoId
	 * @return
	 * @throws FinderException
	 */
	Collection<Collegamento> findByLinkedSoggetto(Long linkedSoggettoId)throws FinderException;
}
