package it.sella.anagrafe;

/**
 * @author GBS03447
 *
 */
public class DAIConfigView implements IDAIConfigView {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long daiConfigId;
	private String daiConfigCode;
	private Long daiParentId;
	private String daiDescription;

	public Long getDaiConfigId() {
		return daiConfigId;
	}

	public void setDaiConfigId(final Long daiConfigId) {
		this.daiConfigId = daiConfigId;
	}

	public String getDaiConfigCode() {
		return daiConfigCode;
	}

	public void setDaiConfigCode(final String daiConfigCode) {
		this.daiConfigCode = daiConfigCode;
	}

	public Long getDaiParentId() {
		return daiParentId;
	}

	public void setDaiParentId(final Long daiParentId) {
		this.daiParentId = daiParentId;
	}

	public String getDaiDescription() {
		return daiDescription;
	}

	public void setDaiDescription(final String daiDescription) {
		this.daiDescription = daiDescription;
	}
}
