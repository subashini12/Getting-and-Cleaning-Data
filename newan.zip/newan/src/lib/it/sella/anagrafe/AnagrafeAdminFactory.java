package it.sella.anagrafe;

import it.sella.anagrafe.implementation.AnagrafeAdmin;
import it.sella.anagrafe.implementation.AnagrafeAdminHome;
import it.sella.anagrafe.util.ResourceLookupHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;

import javax.ejb.CreateException;

public class AnagrafeAdminFactory {

	private final static Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AnagrafeAdminFactory.class);
	
	private static AnagrafeAdminFactory factory;
	
	 private AnagrafeAdminFactory() {
	 }
	
    public static AnagrafeAdminFactory getInstance() {
        if (factory == null) {
        	factory = new AnagrafeAdminFactory();
        }
        return factory;
    }
    
    public AnagrafeAdmin create() throws RemoteException, GestoreAnagrafeException {
    	try {
			return ((AnagrafeAdminHome) ResourceLookupHelper.getHomeObject("ANAGRAFEADMINHOMENAME", "it.sella.anagrafe.implementation.AnagrafeAdminHome")).create();
		} catch (final ResourceLookupException e) {
			log4Debug.warnStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} catch (final CreateException e) {
			log4Debug.warnStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		}
    }
}
