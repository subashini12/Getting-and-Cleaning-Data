package it.sella.anagrafe;

/**
 * @author GBS03447
 *
 */
public enum DatiFiscaliClassificazioneCausales {

	apiva("APIVA"), 
	fatca_soggetto_usa("FATCA_SOGGETTO_USA"),
	fatca_status("FATCA_STATUS"),
	fatca_status_calculato("FATCA_STATUS"),
	w9NoReasonCertificate_PF("W9NOREASONCERTIFICATE"),
	w9NoReasonCertificate_AZ("ESENZIONEFATCA");
	

	private DatiFiscaliClassificazioneCausales(final String value) {
		this.value = value;
	}

	private String value;

	public String getValue() {
		return value;
	}
}
