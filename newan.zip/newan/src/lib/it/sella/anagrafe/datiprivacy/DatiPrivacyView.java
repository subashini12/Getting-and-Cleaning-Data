package it.sella.anagrafe.datiprivacy;



public class DatiPrivacyView implements DatiPrivacy {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long id;
    private Long soggettoId;
    private Long rightPk;
    private String value;
    private Long opId;
    
    public DatiPrivacyView() {
    }

    public DatiPrivacyView(final Long soggettoId, final Long rightPk, final String value, final Long opId) {
        this.setSoggettoId(soggettoId);
        this.setRightPk(rightPk);
        this.setValue(value);
        this.setOpId(opId);
    }

    public Long getSoggettoId() {
        return this.soggettoId;
    }

    public Long getRightPk() {
        return this.rightPk;
    }

	public Long getOpId() {
		return this.opId;
	}

    public void setRightPk(final Long rightPk) {
        this.rightPk = rightPk;
    }

    public void setSoggettoId(final Long soggettoId) {
        this.soggettoId = soggettoId;
    }

    public String getValue() {
        return this.value;
    }

    public void setValue(final String value) {
        this.value = value;
    }

	public void setOpId(final Long opId) {
		this.opId = opId;
	}

    protected String getParameterList() {
        return "Soggetto Id" + this.getSoggettoId();
    }

    protected String getShortParameterList() {
        return getParameterList();
    }

	public Long getId() {
		return id;
	}

	public void setId(final Long id) {
		this.id = id;
	}
}


