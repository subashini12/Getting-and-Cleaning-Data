package it.sella.anagrafe.datiprivacy;

import it.sella.anagrafe.GestoreAnagrafeException;

import java.util.Collection;

import javax.ejb.FinderException;

public interface IDatiPrivacyBeanManager {
	
	/**
	 * Method to create DatiPrivacy
	 * @param datiPrivacyView
	 * @return
	 * @throws GestoreAnagrafeException
	 */
	DatiPrivacy create(DatiPrivacy datiPrivacyView) throws GestoreAnagrafeException;
	
	/**
	 * Method to update DatiPrivacy
	 * @param datiPrivacyView
	 * @return
	 */
	DatiPrivacy update(DatiPrivacy datiPrivacyView);
	
	/**
	 * Method to remove DatiPrivacy
	 * @param datiPrivacyView
	 */
	void remove(DatiPrivacy datiPrivacyView);
	
	/**
	 * Method to find using PrimaryKey
	 * @param primaryKey
	 * @return
	 * @throws FinderException
	 */
	DatiPrivacy findByPrimaryKey(Long primaryKey) throws FinderException;
	
	/**
	 * Method to find using SoggettoId
	 * @param soggettoId
	 * @return
	 * @throws FinderException
	 */
	Collection<DatiPrivacy> findBySoggettoId(Long soggettoId) throws FinderException;
}
