package it.sella.anagrafe.datiprivacy;

import java.io.Serializable;

public interface DatiPrivacy extends Serializable {
	
	Long getId();
	void setId(Long id);
    Long getSoggettoId();
    void setSoggettoId(Long soggettoId);
    Long getRightPk() ;
    void setRightPk(Long typeId);
    String getValue();
    void setValue(String value);
    Long getOpId();
    void setOpId(Long opId);
}



