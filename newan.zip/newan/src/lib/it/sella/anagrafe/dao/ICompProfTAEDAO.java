package it.sella.anagrafe.dao;

import it.sella.anagrafe.util.CompProfTAEException;
import it.sella.anagrafe.view.CompProfTAEAdminView;

import java.util.List;

public interface ICompProfTAEDAO {

	/**
	 * To get all the compatabile professione Id and bank Id
	 * @param profClassficazioneId
	 * @param bankId
	 * @return
	 * @throws CompProfTAEException
	 */
	public List<CompProfTAEAdminView> getCompProfTAE4ProfId (final Long profClassficazioneId,final Long bankId) throws CompProfTAEException;
	/**
	 * Creation of new compatabile professione for TAE
	 * @param compProfTAEAdminViewList
	 * @throws CompProfTAEException
	 */
	public void createCompProfTAE4ProfId(final List<CompProfTAEAdminView> compProfTAEAdminViewList) throws CompProfTAEException;
	/**
	 * Deletion for compatabile professione for TAE
	 * @param compProfTAEAdminViewList
	 * @throws CompProfTAEException
	 */
	public void deleteCompProfTAE4ProfId(final List<CompProfTAEAdminView> compProfTAEAdminViewList) throws CompProfTAEException;
	/**
	 * Getting the non existing compatabile professione for TAE
	 * @param profClassficazioneId
	 * @param bankId
	 * @return
	 * @throws CompProfTAEException
	 */
	public List<CompProfTAEAdminView> getNonExitingTAE4Professione(final Long profClassficazioneId,final Long bankId) throws CompProfTAEException;
	/**
	 * Getting the compatabile professione primary key for Professione Classificazione Id
	 * @param profClassficazioneId
	 * @param bankId
	 * @return
	 * @throws CompProfTAEException
	 */
	public Long getProfessioneId (final Long profClassficazioneId,final Long bankId) throws CompProfTAEException;
}
