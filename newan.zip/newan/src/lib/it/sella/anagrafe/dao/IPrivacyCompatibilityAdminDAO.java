package it.sella.anagrafe.dao;

import it.sella.anagrafe.implementation.PrivacyCompatibilityView;
import it.sella.anagrafe.util.PrivacyAdminHelperException;

import java.util.List;

public interface IPrivacyCompatibilityAdminDAO {
	
	
	public List<PrivacyCompatibilityView> getAllBanks() throws PrivacyAdminHelperException ;
    
	
	public void updateDipctCompatibility(PrivacyCompatibilityView view)	throws PrivacyAdminHelperException;

}
