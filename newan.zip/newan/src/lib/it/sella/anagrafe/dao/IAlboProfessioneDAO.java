package it.sella.anagrafe.dao;

import it.sella.anagrafe.util.AlboProfessioneException;
import it.sella.anagrafe.view.AlboProfessioneView;

public interface IAlboProfessioneDAO {
	
	/**The method returns AlboProfessione details based on AlboProfessione Code
	 * @param AlboProfessione
	 * @return List
	 * @throws AlboProfessioneException
	 */
	
	public AlboProfessioneView getAlboProfDetails4alboProfCode (final String alboProfCode) throws AlboProfessioneException;
	
	/**
	 * To insert new Albo Professione values into the table an_ma_albo_professione.
	 * @param alboProAdminView
	 * @throws AlboProfessioneException
	 */
	public void insertAlboProfessione(final AlboProfessioneView alboProAdminView) throws AlboProfessioneException;
	
	/**
	 * To modify the TAE values from the table an_ma_albo_professione.
	 * @param alboProAdminView
	 * @throws AlboProfessioneException
	 */
	public void modifyAlboProfDetails(final AlboProfessioneView alboProAdminView) throws AlboProfessioneException;
	
	/**
	 * This method added to check whether the entered alboprofessione Code already exist.
	 * @param albo professioneId
	 * @return boolean
	 * @throws AlboProfessioneException
	 */
	public boolean isAlboProfAlreadyExist(final String alboProfCode) throws AlboProfessioneException;
	
	/**The method deltes AlboProfessione details based on AlboProfessione Id
	 * @param alboProfId long
	 * @throws AlboProfessioneException
	 */
	
	public void deleteAlboProfessioneDetails(final Long alboProfId) throws AlboProfessioneException;
	
	/**
	 * This method added to check whether the entered alboprofessione is alreay mapped to TipoSoggetto
	 * @param albo professioneId
	 * @return boolean
	 * @throws AlboProfessioneException
	 */	
	public boolean isAlboMappedToTipoSoggetto(final Long alboId) throws AlboProfessioneException;
}
