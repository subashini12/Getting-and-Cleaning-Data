package it.sella.anagrafe.dao.impl;

import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.anagrafe.dao.ICensimentoAutomaticoDAO;
import it.sella.anagrafe.dbaccess.CodiceSoggettoDBAccessHelper;
import it.sella.anagrafe.dbaccess.DBAccessHelper;
import it.sella.anagrafe.implementation.ElencoAziendaView;
import it.sella.anagrafe.implementation.ElencoPersoneFisicheView;
import it.sella.anagrafe.implementation.ElencoPlurintestazioniView;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.SoggettiPromotoreException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.IOException;
import java.io.Reader;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleResultSet;

public class CensimentoAutomaticoImpl extends DBAccessHelper implements ICensimentoAutomaticoDAO{

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CensimentoAutomaticoImpl.class);


	/* (non-Javadoc)
	 * @see it.sella.anagrafe.dao.ICensimentoAutomaticoDAO#getAllPersonaFisicaDetails(java.lang.String)
	 */
	public List<ElencoPersoneFisicheView> listPersonaFisicaDetails(
			final String rifDate) throws SoggettiPromotoreException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		final List<ElencoPersoneFisicheView> elencoPFView = new ArrayList<ElencoPersoneFisicheView> ();
		try {
			connection = getConnection();
			final StringBuffer query = new StringBuffer("SELECT SP_ID , EXTRACTVALUE(SP_XML, '/SOGGETTO_BPA/PERSONA_FISICA/NOME') PF_NOME,");
			query.append("EXTRACTVALUE(SP_XML, '/SOGGETTO_BPA/PERSONA_FISICA/COGNOME') PF_COGNOME,");
			query.append("EXTRACTVALUE(SP_XML, '/SOGGETTO_BPA/PERSONA_FISICA/DATA_DI_NASCITA') PF_DATA_DI_NASCITA,");
			query.append("EXTRACTVALUE(SP_XML, '/SOGGETTO_BPA/PERSONA_FISICA/LUOGO_DI_NASCITA') PF_LUOGO_DI_NASCITA,");
			query.append("EXTRACTVALUE(SP_XML, '/SOGGETTO_BPA/PERSONA_FISICA/CODICEFISCALE') PF_CODICEFISCALE,");
			query.append("SP_TIPO_SOGGETTO TIPO_SOGGETTO, SP_BANK_ID ORIGIN_BANK_ID,SP_STATO STATO,");
			query.append("SP_ERRORE ERROR,SP_DATA_RIF DATA_RIF");
			query.append(" FROM AN_TR_SOGGETTI_FOL_PROCT");
			query.append(" WHERE  TO_CHAR(SP_DATA_RIF , 'DD/MM/YYYY')=?");
			query.append("AND SP_TIPO_SOGGETTO = ?  order by SP_DATA_RIF desc");
			log4Debug.info("Query For PF ==================",query);
			preparedStatement = connection.prepareStatement(query.toString());
			preparedStatement.setString(1,rifDate);
			preparedStatement.setString(2, "PF");
			resultSet = preparedStatement.executeQuery();
			while ( resultSet.next() ) {
				final ElencoPersoneFisicheView pfView = new ElencoPersoneFisicheView  () ;
				final CodiceSoggettoDBAccessHelper dbAccessHelper = new CodiceSoggettoDBAccessHelper ();
				final Long bankId = resultSet.getLong("ORIGIN_BANK_ID");
				final String abiCode = dbAccessHelper.getValoreCodiciSoggettoWithSpecificBank(bankId, bankId, "abi");
				pfView.setSP_ID(resultSet.getLong("SP_ID"));
				pfView.setBancaDiOrigine(abiCode);
				pfView.setCodiceFiscali(resultSet.getString("PF_CODICEFISCALE"));
				pfView.setCognome(resultSet.getString("PF_COGNOME"));
				pfView.setDataDiNascita(resultSet.getString("PF_DATA_DI_NASCITA"));
				final Date rifdate = resultSet.getDate("DATA_RIF");
				final String rifdateInString = new DateHandler().getDateSpecifiedFormat(rifdate, "dd/MM/yyyy");
				pfView.setDataDiRiferimento(rifdateInString);
				pfView.setError(resultSet.getString("ERROR"));
				pfView.setLuogoDiNascitaCitta(resultSet.getString("PF_LUOGO_DI_NASCITA"));
				pfView.setNome(resultSet.getString("PF_NOME"));
				pfView.setStato(resultSet.getString("STATO"));
				elencoPFView.add(pfView);
			}
		} catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new SoggettiPromotoreException(e);
		} catch (final GestoreCodiciSoggettoException e) {
			log4Debug.warnStackTrace(e);
			throw new SoggettiPromotoreException(e);
		} catch (final RemoteException e) {
			log4Debug.warnStackTrace(e);
			throw new SoggettiPromotoreException(e);
		} finally {
			cleanup(connection, preparedStatement, resultSet);
		}
		return elencoPFView;
	}



	/* (non-Javadoc)
	 * @see it.sella.anagrafe.dao.ICensimentoAutomaticoDAO#getAllAziendaDetails(java.lang.String)
	 */
	public List<ElencoAziendaView> listAziendaDetails(final String rifDate) throws SoggettiPromotoreException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		final List<ElencoAziendaView> elencoAZView = new ArrayList<ElencoAziendaView> ();
		try {
			connection = getConnection();
			final StringBuffer query = new StringBuffer("SELECT SP_ID , EXTRACTVALUE(SP_XML, '/SOGGETTO_BPA/AZIENDA/DENOMINAZIONE') AZ_DENOMINAZIONE,");
			query.append("EXTRACTVALUE(SP_XML, '/SOGGETTO_BPA/AZIENDA/AZ_TIPO_SOGGETTO') AZ_TIPO_SOGGETTO,");
			query.append("EXTRACTVALUE(SP_XML, '/SOGGETTO_BPA/AZIENDA/AZ_TIPO_SOCIETA') AZ_TIPO_SOCIETA,");
			query.append("EXTRACTVALUE(SP_XML, '/SOGGETTO_BPA/AZIENDA/DATA_CONSTITUZIONE') AZ_DATA_CONSTITUZIONE,");
			query.append("EXTRACTVALUE(SP_XML, '/SOGGETTO_BPA/AZIENDA/PARTATIVA') AZ_PARTATIVA,");
			query.append("SP_TIPO_SOGGETTO TIPO_SOGGETTO, SP_BANK_ID ORIGIN_BANK_ID,SP_STATO STATO,");
			query.append("SP_ERRORE ERROR,SP_DATA_RIF DATA_RIF");
			query.append(" FROM AN_TR_SOGGETTI_FOL_PROCT");
			query.append(" WHERE  TO_CHAR(SP_DATA_RIF , 'DD/MM/YYYY')=?");
			query.append("AND SP_TIPO_SOGGETTO = ? order by SP_DATA_RIF desc");
			log4Debug.info("Query For AZ ==================",query);
			preparedStatement = connection.prepareStatement(query.toString());
			preparedStatement.setString(1, rifDate);
			preparedStatement.setString(2, "AZ");
			resultSet = preparedStatement.executeQuery();
			while ( resultSet.next() ) {
				final ElencoAziendaView azView = new ElencoAziendaView() ;
				final CodiceSoggettoDBAccessHelper dbAccessHelper = new CodiceSoggettoDBAccessHelper ();
				final Long bankId = resultSet.getLong("ORIGIN_BANK_ID");
				final String abiCode = dbAccessHelper.getValoreCodiciSoggettoWithSpecificBank(bankId, bankId, "abi");
				azView.setBancaDiOrigine(abiCode);
				azView.setDataConstituzione(resultSet.getString("AZ_DATA_CONSTITUZIONE"));
				final Date rifdate = resultSet.getDate("DATA_RIF");
				final String rifdateInString = new DateHandler().getDateSpecifiedFormat(rifdate, "dd/MM/yyyy");
				azView.setSP_ID(resultSet.getLong("SP_ID"));
				azView.setDataDiRiferimento(rifdateInString);
				azView.setDenominazione(resultSet.getString("AZ_DENOMINAZIONE"));
				azView.setError(resultSet.getString("ERROR"));
				azView.setPartitaIva(resultSet.getString("AZ_PARTATIVA"));
				azView.setStato(resultSet.getString("STATO"));
				azView.setTipoSocieta(resultSet.getString("AZ_TIPO_SOCIETA"));
				azView.setTipoSoggetto(resultSet.getString("AZ_TIPO_SOGGETTO"));
				elencoAZView.add(azView);

			}
		} catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new SoggettiPromotoreException(e);
		} catch (final GestoreCodiciSoggettoException e) {
			log4Debug.warnStackTrace(e);
			throw new SoggettiPromotoreException(e);
		} catch (final RemoteException e) {
			log4Debug.warnStackTrace(e);
			throw new SoggettiPromotoreException(e);
		}finally {
			cleanup(connection, preparedStatement, resultSet);
		}
		return elencoAZView;
	}




	/* (non-Javadoc)
	 * @see it.sella.anagrafe.dao.ICensimentoAutomaticoDAO#getAllPlurintestazioniDetails(java.lang.String)
	 */
	public List<ElencoPlurintestazioniView> listPlurintestazioniDetails(final
			String rifDate) throws SoggettiPromotoreException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		final List<ElencoPlurintestazioniView> elencoPLView = new ArrayList<ElencoPlurintestazioniView> ();
		try {
			connection = getConnection();
			final StringBuffer query = new StringBuffer(" SELECT SP_ID , EXTRACTVALUE(SP_XML, '/SOGGETTO_BPA/PLURINTESTAZIONE/INTESTAZIONE') PL_INTESTAZIONE,");
			query.append("SP_TIPO_SOGGETTO TIPO_SOGGETTO, SP_BANK_ID ORIGIN_BANK_ID,SP_STATO STATO,");
			query.append("SP_ERRORE ERROR,SP_DATA_RIF DATA_RIF");
			query.append(" FROM AN_TR_SOGGETTI_FOL_PROCT");
			query.append(" WHERE  TO_CHAR(SP_DATA_RIF , 'DD/MM/YYYY')=?");
			query.append("AND SP_TIPO_SOGGETTO = ? order by SP_DATA_RIF desc");
			log4Debug.info("Query For PL ==================",query);
			preparedStatement = connection.prepareStatement(query.toString());
			preparedStatement.setString(1, rifDate);
			preparedStatement.setString(2, "PL");
			resultSet = preparedStatement.executeQuery();
			while ( resultSet.next() ) {
				final ElencoPlurintestazioniView plView = new ElencoPlurintestazioniView() ;
				final CodiceSoggettoDBAccessHelper dbAccessHelper = new CodiceSoggettoDBAccessHelper ();
				final Long bankId = resultSet.getLong("ORIGIN_BANK_ID");
				final String abiCode = dbAccessHelper.getValoreCodiciSoggettoWithSpecificBank(bankId, bankId, "abi");
				final Date rifdate = resultSet.getDate("DATA_RIF");
				final String rifdateInString = new DateHandler().getDateSpecifiedFormat(rifdate, "dd/MM/yyyy");
				plView.setSP_ID(resultSet.getLong("SP_ID"));
				plView.setError(resultSet.getString("ERROR"));
				plView.setIntestazione(resultSet.getString("PL_INTESTAZIONE"));
				plView.setBancaDiOrigine(abiCode);
				plView.setStato(resultSet.getString("STATO"));
				plView.setDataDiRiferimento(rifdateInString);

				elencoPLView.add(plView);
			}
		} catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new SoggettiPromotoreException(e);
		} catch (final GestoreCodiciSoggettoException e) {
			log4Debug.warnStackTrace(e);
			throw new SoggettiPromotoreException(e);
		} catch (final RemoteException e) {
			log4Debug.warnStackTrace(e);
			throw new SoggettiPromotoreException(e);
		}finally {
			cleanup(connection, preparedStatement, resultSet);
		}
		return elencoPLView;
	}



	/* (non-Javadoc)
	 * @see it.sella.anagrafe.dao.ICensimentoAutomaticoDAO#getCollectionOfXMLForTheId(java.lang.Long)
	 */
	public 	Collection<String> listSoggettiXMLForCensimento(final Long soggettoPromotoreId) throws SoggettiPromotoreException{
		Connection connection = null;
		OraclePreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		final List<String> xmlColl = new ArrayList<String> ();
		try {
			connection = getConnection();

			final StringBuffer query = new StringBuffer("SELECT XMLSerialize(DOCUMENT VALUE(XML) AS CLOB) as XML_DATA   FROM AN_TR_SOGGETTI_FOL_PROCT SP, ");
			query.append("TABLE(XMLSEQUENCE(EXTRACT(SP.SP_XML,'/SOGGETTO_BPA/SOGGETTO_XML_LIST/SOGGETTO_XML/SOGGETTI'))) XML");
			query.append(" WHERE SP.SP_ID = ?");
			log4Debug.info("Query For SoggettoList ==================",query);
			preparedStatement = (OraclePreparedStatement) connection.prepareStatement(query.toString());
			preparedStatement.setLong(1, soggettoPromotoreId);
			resultSet = preparedStatement.executeQuery();
			final weblogic.jdbc.wrapper.ResultSet wlsResultSet = (weblogic.jdbc.wrapper.ResultSet)resultSet;
			final OracleResultSet oracleResultSet = (OracleResultSet)wlsResultSet.getVendorObj();
			while ( resultSet.next() ) {
				xmlColl.add(getStringFromClob(oracleResultSet.getCLOB("XML_DATA")));
			}
		} catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new SoggettiPromotoreException(e);
		} catch (final IOException e) {
			log4Debug.warnStackTrace(e);
			throw new SoggettiPromotoreException(e);
		}finally {
			cleanup(connection, preparedStatement, resultSet);
		}
		return xmlColl;

	}


	/* (non-Javadoc)
	 * @see it.sella.anagrafe.dao.ICensimentoAutomaticoDAO#updateSoggettiPromotore(java.lang.Long, java.lang.String, java.lang.String, java.lang.String, java.lang.Long)
	 */
	public void updateAutoCensitoStatus(final Long soggettoPromotoreId,final String error, final String stato,final String rifDate,final Long opId) throws SoggettiPromotoreException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = getConnection();
			final StringBuilder query = new StringBuilder("UPDATE AN_TR_SOGGETTI_FOL_PROCT SET SP_STATO=?,");
			if(error != null ||"".equals(error)|| "CENSITO".equals(stato)){
				query.append("SP_ERRORE=?,");
			}
			query.append("SP_DATA_RIF=?,SP_OP_ID=? WHERE SP_ID=?");
					preparedStatement = connection.prepareStatement(query.toString());
			int statementCount = 1;
			preparedStatement.setString(statementCount, stato);
			if(error != null ||"".equals(error)|| "CENSITO".equals(stato)){
				
				preparedStatement.setString(++statementCount, error);
			}
			preparedStatement.setTimestamp(++statementCount,new DateHandler().getCurrentDateInTimeStampFormat() );
			checkForNullAndSetLongValue(preparedStatement, opId, ++statementCount);
			checkForNullAndSetLongValue(preparedStatement, soggettoPromotoreId, ++statementCount);
			preparedStatement.executeUpdate();
		}  catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new SoggettiPromotoreException(e);
		} finally {
			cleanup(connection, preparedStatement);
		}
	}



	/**
	 * Private Method to convert Clob to String
	 * @param clob
	 * @return
	 * @throws SQLException
	 * @throws IOException
	 */
	private String getStringFromClob(final oracle.sql.CLOB clob) throws SQLException, IOException {
		final StringBuffer data = new StringBuffer();

		if (clob != null) {
			final Reader reader = clob.getCharacterStream();
			int ch;
			while ((ch = reader.read()) != -1) {
				{
					data.append((char) ch);
				}
			}
		}

		return data.toString();
	}
}	



