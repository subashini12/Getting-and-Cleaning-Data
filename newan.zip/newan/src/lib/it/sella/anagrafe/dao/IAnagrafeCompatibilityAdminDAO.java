package it.sella.anagrafe.dao;

import it.sella.anagrafe.implementation.AnagrafeCompatibilityView;
import it.sella.anagrafe.util.AnagrafeConfigException;

import java.util.List;
/**
 * 
 * @author gbs03109
 *
 */
public interface IAnagrafeCompatibilityAdminDAO {
	/**
	 * To get list of banks
	 * @return
	 * @throws AnagrafeConfigException
	 */
	public List<AnagrafeCompatibilityView> getListOfBanks() throws AnagrafeConfigException ;

	/**
	 * To update compatability for attributes
	 * @param view
	 * @throws AnagrafeConfigException
	 */
	public void updateCompatibilityForAttributes(final AnagrafeCompatibilityView view)	throws AnagrafeConfigException;
	/**
	 * To get bank id and correspoding details for particular causale
	 * @param classId
	 * @return
	 * @throws AnagrafeConfigException
	 */
	public List<AnagrafeCompatibilityView> getListOfBanksByClassId(final Long classId) throws AnagrafeConfigException;

}
