package it.sella.anagrafe.dao.impl;

import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.dao.IFATCAAZCompDAO;
import it.sella.anagrafe.dbaccess.DBAccessHelper;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.util.FATCAAZCompException;
import it.sella.anagrafe.view.FATCAAZAdminView;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
/**
 * DAO Class For Master AN_MA_COMPAT_FATCA_AZ
 * @author gbs03109
 *
 */
public class FATCAAZAdminDAOImpl extends DBAccessHelper implements IFATCAAZCompDAO{

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(FATCAAZAdminDAOImpl.class);

	/**
	 * To fetch the list from table AN_MA_COMPAT_FATCA_AZ by passing classificazione id
	 */

	public List<FATCAAZAdminView> getDetailsForClassId(final Long classId)throws FATCAAZCompException {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		final List<FATCAAZAdminView> list = new ArrayList<FATCAAZAdminView>();
		query.append("SELECT FC_COMP_ID,FC_NAZIONE_IS_ITALIA,FC_NAZIONE_IS_US,FC_NAZIONE_IS_IGA1,FC_NAZIONE_IS_IGA2,FC_SLE_IS_US,FC_SAM_IS_US,FC_RESFIS_IS_US, ");
		query.append(" FC_SETTORE_IS_ALLEAGA_B,FC_SETTORE_IS_ALLEGA_C,FC_SETTORE_IS_ALLEGA_B1,FC_SETTORE_IS_EQUAL,FC_SETTORE_IS_NOT_EQUAL,FC_IS_ONLUS,FC_CLASS_ID ");
		query.append(" FROM AN_MA_COMPAT_FATCA_AZ TT  WHERE FC_CLASS_ID=? ");
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setLong(1, classId);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				final FATCAAZAdminView adminView = new FATCAAZAdminView();
				final ClassificazioneView classificazioneView = setCompFATCAAZ(resultSet);
				if(classificazioneView !=null ){
					adminView.setClassId(classificazioneView);
				}
				adminView.setFatcaId(Long.valueOf(resultSet.getString("FC_COMP_ID")));
				adminView.setNazioneGA1(resultSet.getString("FC_NAZIONE_IS_IGA1"));
				adminView.setNazioneGA2(resultSet.getString("FC_NAZIONE_IS_IGA2"));
				adminView.setNazioneItalia(resultSet.getString("FC_NAZIONE_IS_ITALIA"));
				adminView.setNazioneUs(resultSet.getString("FC_NAZIONE_IS_US"));
				adminView.setOnlus(resultSet.getString("FC_IS_ONLUS"));
				adminView.setResidFiscUS(resultSet.getString("FC_RESFIS_IS_US"));
				adminView.setSamUS(resultSet.getString("FC_SAM_IS_US"));
				adminView.setSettoreB(resultSet.getString("FC_SETTORE_IS_ALLEAGA_B"));
				adminView.setSettoreB1(resultSet.getString("FC_SETTORE_IS_ALLEGA_B1"));
				adminView.setSettoreC(resultSet.getString("FC_SETTORE_IS_ALLEGA_C"));
				adminView.setSettoreEqual(resultSet.getString("FC_SETTORE_IS_EQUAL"));
				adminView.setSettoreNotEqual(resultSet.getString("FC_SETTORE_IS_NOT_EQUAL"));
				adminView.setSleUS(resultSet.getString("FC_SLE_IS_US"));
				list.add(adminView);

			}
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new FATCAAZCompException(se.getMessage());
		} catch (RemoteException e) {
			log4Debug.warnStackTrace(e);
			throw new FATCAAZCompException(e.getMessage());
		} catch (SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new FATCAAZCompException(e.getMessage());
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return list;
	}

	/**
	 * To get details for particular FATCA ID
	 */

	public FATCAAZAdminView getDetailsForCompId(final Long compId)throws FATCAAZCompException {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		FATCAAZAdminView adminView = null;
		final StringBuffer query = new StringBuffer();
		query.append("SELECT FC_COMP_ID,FC_NAZIONE_IS_ITALIA,FC_NAZIONE_IS_US,FC_NAZIONE_IS_IGA1,FC_NAZIONE_IS_IGA2,FC_SLE_IS_US,FC_SAM_IS_US,FC_RESFIS_IS_US, ");
		query.append(" FC_SETTORE_IS_ALLEAGA_B,FC_SETTORE_IS_ALLEGA_C,FC_SETTORE_IS_ALLEGA_B1,FC_SETTORE_IS_EQUAL,FC_SETTORE_IS_NOT_EQUAL,FC_IS_ONLUS,FC_CLASS_ID ");
		query.append(" FROM AN_MA_COMPAT_FATCA_AZ TT  WHERE FC_COMP_ID=? ");
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setLong(1, compId);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				adminView = new FATCAAZAdminView();
				final ClassificazioneView classificazioneView = setCompFATCAAZ(resultSet);
				if(classificazioneView !=null ){
					adminView.setClassId(classificazioneView);
				}
				adminView.setFatcaId(Long.valueOf(resultSet.getString("FC_COMP_ID")));
				adminView.setNazioneGA1(resultSet.getString("FC_NAZIONE_IS_IGA1"));
				adminView.setNazioneGA2(resultSet.getString("FC_NAZIONE_IS_IGA2"));
				adminView.setNazioneItalia(resultSet.getString("FC_NAZIONE_IS_ITALIA"));
				adminView.setNazioneUs(resultSet.getString("FC_NAZIONE_IS_US"));
				adminView.setOnlus(resultSet.getString("FC_IS_ONLUS"));
				adminView.setResidFiscUS(resultSet.getString("FC_RESFIS_IS_US"));
				adminView.setSamUS(resultSet.getString("FC_SAM_IS_US"));
				adminView.setSettoreB(resultSet.getString("FC_SETTORE_IS_ALLEAGA_B"));
				adminView.setSettoreB1(resultSet.getString("FC_SETTORE_IS_ALLEGA_B1"));
				adminView.setSettoreC(resultSet.getString("FC_SETTORE_IS_ALLEGA_C"));
				adminView.setSettoreEqual(resultSet.getString("FC_SETTORE_IS_EQUAL"));
				adminView.setSettoreNotEqual(resultSet.getString("FC_SETTORE_IS_NOT_EQUAL"));
				adminView.setSleUS(resultSet.getString("FC_SLE_IS_US"));

			}
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new FATCAAZCompException(se.getMessage());
		} catch (RemoteException e) {
			log4Debug.warnStackTrace(e);
			throw new FATCAAZCompException(e.getMessage());
		} catch (SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new FATCAAZCompException(e.getMessage());
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return adminView;
	}

	/**
	 * To fetch all details from master AN_MA_COMPAT_FATCA_AZ 
	 */    

	public Collection<FATCAAZAdminView> getAllDetails()throws FATCAAZCompException {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		final List<FATCAAZAdminView> list = new ArrayList<FATCAAZAdminView>();
		FATCAAZAdminView adminView = null;
		query.append("SELECT FC_COMP_ID,FC_NAZIONE_IS_ITALIA,FC_NAZIONE_IS_US,FC_NAZIONE_IS_IGA1,FC_NAZIONE_IS_IGA2,FC_SLE_IS_US,FC_SAM_IS_US,FC_RESFIS_IS_US, ");
		query.append(" FC_SETTORE_IS_ALLEAGA_B,FC_SETTORE_IS_ALLEGA_C,FC_SETTORE_IS_ALLEGA_B1,FC_SETTORE_IS_EQUAL,FC_SETTORE_IS_NOT_EQUAL,FC_IS_ONLUS,FC_CLASS_ID ");
		query.append(" FROM AN_MA_COMPAT_FATCA_AZ  ");
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				adminView = new FATCAAZAdminView();
				final ClassificazioneView classificazioneView = setCompFATCAAZ(resultSet);
				if(classificazioneView !=null ){
					adminView.setClassId(classificazioneView);
				}
				adminView.setFatcaId(Long.valueOf(resultSet.getString("FC_COMP_ID")));
				adminView.setNazioneGA1(resultSet.getString("FC_NAZIONE_IS_IGA1"));
				adminView.setNazioneGA2(resultSet.getString("FC_NAZIONE_IS_IGA2"));
				adminView.setNazioneItalia(resultSet.getString("FC_NAZIONE_IS_ITALIA"));
				adminView.setNazioneUs(resultSet.getString("FC_NAZIONE_IS_US"));
				adminView.setOnlus(resultSet.getString("FC_IS_ONLUS"));
				adminView.setResidFiscUS(resultSet.getString("FC_RESFIS_IS_US"));
				adminView.setSamUS(resultSet.getString("FC_SAM_IS_US"));
				adminView.setSettoreB(resultSet.getString("FC_SETTORE_IS_ALLEAGA_B"));
				adminView.setSettoreB1(resultSet.getString("FC_SETTORE_IS_ALLEGA_B1"));
				adminView.setSettoreC(resultSet.getString("FC_SETTORE_IS_ALLEGA_C"));
				adminView.setSettoreEqual(resultSet.getString("FC_SETTORE_IS_EQUAL"));
				adminView.setSettoreNotEqual(resultSet.getString("FC_SETTORE_IS_NOT_EQUAL"));
				adminView.setSleUS(resultSet.getString("FC_SLE_IS_US"));
				list.add(adminView);

			}
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new FATCAAZCompException(se.getMessage());
		} catch (RemoteException se) {
			log4Debug.warnStackTrace(se);
			throw new FATCAAZCompException(se.getMessage());
		} catch (SubSystemHandlerException se) {
			log4Debug.warnStackTrace(se);
			throw new FATCAAZCompException(se.getMessage());
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return list;
	}

	/**
	 * To update a  record in AN_MA_COMPAT_FATCA_AZ for particular FATCA ID
	 */

	public void updateForComId(final FATCAAZAdminView view)throws FATCAAZCompException {
		Connection connection = null;
		PreparedStatement statement = null;
		final StringBuffer query = new StringBuffer();
		query.append("UPDATE AN_MA_COMPAT_FATCA_AZ SET FC_NAZIONE_IS_ITALIA = ? ,FC_NAZIONE_IS_US =? ,FC_NAZIONE_IS_IGA1 =? ,FC_NAZIONE_IS_IGA2 =? , FC_SLE_IS_US =? ,FC_SAM_IS_US =? , FC_RESFIS_IS_US =? , FC_SETTORE_IS_ALLEAGA_B = ? , FC_SETTORE_IS_ALLEGA_C =? , FC_SETTORE_IS_ALLEGA_B1 =? , FC_SETTORE_IS_EQUAL =? , FC_SETTORE_IS_NOT_EQUAL = ? , FC_IS_ONLUS =? , FC_CLASS_ID = ? ");
		query.append(" WHERE FC_COMP_ID = ? ");
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());

			int statementCount = 1;
			statement.setString(statementCount, view.getNazioneItalia());
			statement.setString(++statementCount, view.getNazioneUs());
			statement.setString(++statementCount, view.getNazioneGA1());
			statement.setString(++statementCount, view.getNazioneGA2());
			statement.setString(++statementCount, view.getSleUS());
			statement.setString(++statementCount, view.getSamUS());
			statement.setString(++statementCount, view.getResidFiscUS());
			statement.setString(++statementCount, view.getSettoreB());
			statement.setString(++statementCount, view.getSettoreC());
			statement.setString(++statementCount, view.getSettoreB1());
			statement.setString(++statementCount, view.getSettoreEqual());
			statement.setString(++statementCount, view.getSettoreNotEqual());
			statement.setString(++statementCount, view.getOnlus());
			statement.setLong(++statementCount, Long.valueOf(view.getClassId().getId()));
			statement.setLong(++statementCount, Long.valueOf(view.getFatcaId()));
			statement.executeUpdate();
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new FATCAAZCompException(se.getMessage());
		} finally {
			cleanup(connection, statement);
		}
	}


	/**
	 * To delete record from AN_MA_COMPAT_FATCA_AZ by passing FATCA ID
	 */

	public void deleteRecordForCompId(final Long compId) throws FATCAAZCompException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(" DELETE FROM AN_MA_COMPAT_FATCA_AZ WHERE FC_COMP_ID = ?");
			preparedStatement.setLong(1, compId);
			preparedStatement.execute();

		}
		catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new FATCAAZCompException(e.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}

	}

	/**
	 * To insert data in to master AN_MA_COMPAT_FATCA_AZ
	 */

	public void insertFatcaStampa(final FATCAAZAdminView view)
	throws FATCAAZCompException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(" INSERT INTO AN_MA_COMPAT_FATCA_AZ (FC_COMP_ID,FC_NAZIONE_IS_ITALIA,FC_NAZIONE_IS_US,FC_NAZIONE_IS_IGA1,FC_NAZIONE_IS_IGA2,FC_SLE_IS_US,FC_SAM_IS_US,FC_RESFIS_IS_US,FC_SETTORE_IS_ALLEAGA_B,FC_SETTORE_IS_ALLEGA_C,FC_SETTORE_IS_ALLEGA_B1,FC_SETTORE_IS_EQUAL,FC_SETTORE_IS_NOT_EQUAL,FC_IS_ONLUS,FC_CLASS_ID) VALUES (AN_SQ_FATCA_AZ_COMP.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ");
			preparedStatement.setString(1, view.getNazioneItalia());
			preparedStatement.setString(2, view.getNazioneUs());
			preparedStatement.setString(3, view.getNazioneGA1());
			preparedStatement.setString(4, view.getNazioneGA2());
			preparedStatement.setString(5, view.getSleUS());
			preparedStatement.setString(6, view.getSamUS());
			preparedStatement.setString(7, view.getResidFiscUS());
			preparedStatement.setString(8, view.getSettoreB());
			preparedStatement.setString(9, view.getSettoreC());
			preparedStatement.setString(10, view.getSettoreB1());
			preparedStatement.setString(11, view.getSettoreEqual());
			preparedStatement.setString(12, view.getSettoreNotEqual());
			preparedStatement.setString(13, view.getOnlus());
			if(view.getClassId() !=null){
				preparedStatement.setLong(14, view.getClassId().getId());
			}else{
				preparedStatement.setNull(14, Types.NUMERIC);
			}
			preparedStatement.executeUpdate();

		}
		catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new FATCAAZCompException(e.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}

	}


	/**
	 * To get classificazione view
	 * @param resultSet
	 * @return
	 * @throws SQLException
	 * @throws RemoteException
	 * @throws SubSystemHandlerException
	 */

	private ClassificazioneView setCompFATCAAZ(final ResultSet resultSet) throws  RemoteException, SubSystemHandlerException, SQLException {
		ClassificazioneView classificazioneView = null;
		if(resultSet.getString("FC_CLASS_ID") !=null){
			classificazioneView= ClassificazioneHandler.getClassificazioneView(Long.valueOf(resultSet.getString("FC_CLASS_ID")));
		}
		return classificazioneView;
	}
}
