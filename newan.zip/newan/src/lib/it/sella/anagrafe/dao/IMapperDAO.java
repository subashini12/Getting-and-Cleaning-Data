package it.sella.anagrafe.dao;

import it.sella.anagrafe.util.MapperHelperException;

import java.util.Map;

public interface IMapperDAO {
	
	/**
	 * To get all banks for the mapper
	 * @return Map<Long,String>
	 * @throws MapperHelperException
	 */
	public Map<Long,String> getAllBanks() throws MapperHelperException;
    
	/**
	 * To update the mapper class name based on bank id
	 * @param mapperClassName
	 * @throws MapperHelperException
	 */
	public void updateMapperByBank(String[] mapperClassName)	throws MapperHelperException;

}
