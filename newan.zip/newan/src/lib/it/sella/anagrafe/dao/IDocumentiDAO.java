package it.sella.anagrafe.dao;

import it.sella.anagrafe.util.DocumentiException;
import it.sella.anagrafe.view.CompDocumentView;
import it.sella.anagrafe.view.IDocumentiMasterView;

import java.util.List;
public interface IDocumentiDAO {
	/**
	 * To get the document master details from AN_MA_COMP_DOCUMENTI for the bank id and valid classficazione id  as input
	 * @param bankId
	 * @param classificazioneId
	 * @return List<CompDocumentView>
	 * @throws DocumentiException
	 */
	public List<CompDocumentView> getDocument4bankAndClassificazione( final Long bankId,final Long classificazioneId)throws DocumentiException;
	/**
	 * This method is used for deleting documenti details of table AN_MA_COMP_DOCUMENTI
	 * @param documentId
	 * @throws DocumentiException
	 */
	public void deleteCompDocumentView4Id( final Long documentId) throws DocumentiException;
	/**
	 * This method is used for modify documenti details of table AN_MA_COMP_DOCUMENTI
	 * @param compDocumentAdminView
	 * @throws DocumentiException
	 */
	public void modifyDocumentDetails(final CompDocumentView compDocumentAdminView)throws DocumentiException;
	/**
	 *  This method is used for insert documenti details to table AN_MA_COMP_DOCUMENTI
	 * @param compDocumentAdminView
	 * @throws DocumentiException
	 */
	public void insertDocumentDetails(final CompDocumentView compDocumentAdminView)throws DocumentiException;
	/**
	 * To get the document master details from AN_MA_COMP_DOCUMENTI for the bank id and true or false for valid or invalid as input 
	 * @param bankId
	 * @param isValid
	 * @return List<IDocumentiMasterView>
	 * @throws DocumentiException
	 */
	public List<IDocumentiMasterView> listDocumentMaster(final Long bankId,final Boolean isValid) throws DocumentiException;
	/**
	 * This method is used for get the documenti details from table AN_MA_COMP_DOCUMENTI for the document id selected
	 * @param documentId
	 * @throws DocumentiException
	 */
	public CompDocumentView getCompDocumentView4Id( final Long documentId) throws DocumentiException;
}


