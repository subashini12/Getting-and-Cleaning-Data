package it.sella.anagrafe.dao;

import it.sella.anagrafe.implementation.DipctCompatibilityView;
import it.sella.anagrafe.util.DipctAdminHelperException;

import java.util.List;

public interface IDipctCompatibilityAdminDAO {
	
	
	public List<DipctCompatibilityView> getAllBanks() throws DipctAdminHelperException ;
    
	
	public void updateDipctCompatibility(DipctCompatibilityView view)	throws DipctAdminHelperException;

}
