package it.sella.anagrafe.dao.impl;

import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.dao.IProfessioneDAO;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.util.ConnectionHandler;
import it.sella.anagrafe.util.ProfessioneException;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.anagrafe.view.CompProfessioneAdminView;
import it.sella.anagrafe.view.ProfessionView;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * @author gbs02551
 *
 */
public class ProfessioneDAOImpl  extends ConnectionHandler implements IProfessioneDAO{  

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(ProfessioneDAOImpl.class);

	 /**
     * The method returns professione details based on storico
     * @param storico
     * @return collection
     * @throws ProfessioneException
     */
	public Collection<ClassificazioneView> listProfessione(final boolean isValid,final Long bankid)throws ProfessioneException {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ProfessionView professionView = null;
		 final Collection<ClassificazioneView>  collection= new ArrayList<ClassificazioneView>();
		try {
			connection = getConnection();
			final Long storicoval=isValid?0L:1L;
			//Long bankid=SecurityHandler.getLoginBancaId();
			preparedStatement = connection.prepareStatement("select cl.CL_CAUSALE,cl.Cl_DESCRIZIONE,cl.CL_classificazione_ID,cl.Cl_PARENT_ID,cl.Cl_ID from AN_MA_COMP_PROFESSIONE cp , cl_vw_classificazione cl where cl.cl_id = cp.cp_prof_class_id and CP_BANK_ID=? and cp_storico=?");
			preparedStatement.setLong(1, bankid.longValue());
			preparedStatement.setLong(2, storicoval);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				professionView = new ProfessionView();
				professionView.setCausale(resultSet.getString("CL_CAUSALE"));
				professionView.setDescrizione(resultSet.getString("Cl_DESCRIZIONE"));
				professionView.setClassificazioneId(resultSet.getLong("CL_classificazione_ID"));
				professionView.setParentId(resultSet.getLong("Cl_PARENT_ID"));
				professionView.setId(resultSet.getLong("Cl_ID"));
				collection.add(professionView);
			}
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new ProfessioneException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement,resultSet);
		}
		
		
		return collection;
	}

	public ClassificazioneView gettProfessionebyCausale(final String causale,final boolean isValid,final Long bankid) throws ProfessioneException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ProfessionView professionView = null;
		try {
			connection = getConnection();
			//Long bankid=SecurityHandler.getLoginBancaId();
			final Long storicoval=isValid?0L:1L;
			preparedStatement = connection.prepareStatement("select cl.CL_CAUSALE,cl.Cl_DESCRIZIONE,cl.CL_classificazione_ID,cl.Cl_PARENT_ID,cl.Cl_ID from AN_MA_COMP_PROFESSIONE cp, cl_vw_classificazione cl where cl.cl_causale=? and CP_BANK_ID = ? and cl.cl_id = cp.cp_prof_class_id and cp_storico=?");
			preparedStatement.setString(1, causale);
			preparedStatement.setLong(2, bankid.longValue());
			preparedStatement.setLong(3, storicoval);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				professionView = new ProfessionView();
				professionView.setCausale(resultSet.getString("CL_CAUSALE"));
				professionView.setDescrizione(resultSet.getString("Cl_DESCRIZIONE"));
				professionView.setClassificazioneId(resultSet.getLong("CL_classificazione_ID"));
				professionView.setParentId(resultSet.getLong("Cl_PARENT_ID"));
				professionView.setId(resultSet.getLong("Cl_ID"));
			}
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new ProfessioneException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement,resultSet);
		}
		return professionView;
	}

	
	public ClassificazioneView getProfessionebyCausaleNuova(final String causale,final boolean isValid,final Long bankid) throws ProfessioneException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ProfessionView professionView = null;
		try {
			connection = getConnection();
			//Long bankid=SecurityHandler.getLoginBancaId();
			final Long storicoval=isValid?0L:1L;
			final StringBuffer selectQuery = new StringBuffer("select cl2.CL_CAUSALE, cl2.Cl_DESCRIZIONE, cl2.CL_classificazione_ID, cl2.Cl_PARENT_ID, cl2.Cl_ID from AN_MA_COMP_PROFESSIONE cp, AN_MA_COMP_PROFESSIONE cp1,");
			selectQuery.append("cl_vw_classificazione  cl, cl_vw_classificazione  cl2 where cl.cl_causale = ? and cp.CP_BANK_ID = ? and cl.cl_id = cp.cp_prof_class_id ");
			selectQuery.append("and cl2.cl_id = cp.cp_nuova_voce  and cp.cp_storico = ? and cp1.cp_storico = 0 and cp1.cp_bank_id = ?  and cp1.cp_prof_class_id = cl2.cl_id");
			preparedStatement = connection.prepareStatement(selectQuery.toString());
			preparedStatement.setString(1, causale);
			preparedStatement.setLong(2, bankid.longValue());
			preparedStatement.setLong(3, storicoval);
			preparedStatement.setLong(4, bankid.longValue());
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				professionView = new ProfessionView();
				professionView.setCausale(resultSet.getString("CL_CAUSALE"));
				professionView.setDescrizione(resultSet.getString("Cl_DESCRIZIONE"));
				professionView.setClassificazioneId(resultSet.getLong("CL_classificazione_ID"));
				professionView.setParentId(resultSet.getLong("Cl_PARENT_ID"));
				professionView.setId(resultSet.getLong("Cl_ID"));
			}
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new ProfessioneException(sqlexception.getMessage());
		}  finally {
			cleanup(connection, preparedStatement,resultSet);
		}
		return professionView;
	}
	
	
	public ClassificazioneView gettProfessionebyDesc(final String descrizione,final boolean isValid,final Long bankid) throws ProfessioneException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ProfessionView professionView = null;
		try {
			connection = getConnection();
			//Long bankid=SecurityHandler.getLoginBancaId();
			final Long storicoval=isValid?0L:1L;
			preparedStatement = connection.prepareStatement("select cl.CL_CAUSALE,cl.Cl_DESCRIZIONE,cl.CL_classificazione_ID,cl.Cl_PARENT_ID,cl.Cl_ID from AN_MA_COMP_PROFESSIONE cp, cl_vw_classificazione cl where cl.cl_descrizione = ? and CP_BANK_ID = ? and cl.cl_id = cp.cp_prof_class_id and cp_storico=?");
			preparedStatement.setString(1, descrizione);
			preparedStatement.setLong(2, bankid.longValue());
			preparedStatement.setLong(3, storicoval);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				professionView = new ProfessionView();
				professionView.setCausale(resultSet.getString("CL_CAUSALE"));
				professionView.setDescrizione(resultSet.getString("Cl_DESCRIZIONE"));
				professionView.setClassificazioneId(resultSet.getLong("CL_classificazione_ID"));
				professionView.setParentId(resultSet.getLong("Cl_PARENT_ID"));
				professionView.setId(resultSet.getLong("Cl_ID"));
			}
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new ProfessioneException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement,resultSet);
		}
		return professionView;
	}
	
	/**
	 * To insert new professione classificazione values into the table AN_MA_COMP_PROFESSIONE.New Classfificazione id changed should be present in the classificazione table
	 * @param compProfessioneAdminView
	 * @throws ProfessioneException
	 */
	public void insertProfessioneClassficazione(final CompProfessioneAdminView compProfessioneAdminView)throws ProfessioneException{

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(" INSERT INTO AN_MA_COMP_PROFESSIONE (CP_ID,CP_PROF_CLASS_ID,CP_BANK_ID,CP_STORICO,CP_NUOVA_VOCE) VALUES (AN_SQ_COMP_PROF.NEXTVAL,?,?,?,?)");
			preparedStatement.setLong(1, compProfessioneAdminView.getProfClassficazioneId());
			preparedStatement.setLong(2, compProfessioneAdminView.getBankId());
			preparedStatement.setLong(3, compProfessioneAdminView.getStorico());
			if (compProfessioneAdminView.getNuovaVoceClassficazioneId()!= null) {
				preparedStatement.setLong(4, compProfessioneAdminView.getNuovaVoceClassficazioneId());
			} else {
				preparedStatement.setNull(4, java.sql.Types.INTEGER);
			}
			preparedStatement.executeUpdate();
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",
					sqlexception.getMessage());
			throw new ProfessioneException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}
	}
	/**
	 * To modify the professione classificazione values into the table AN_MA_COMP_PROFESSIONE .New Classfificazione id changed should be present in the classificazione table
	 * @param compProfessioneAdminView
	 * @throws ProfessioneException
	 */
	public void modifyProfessioneDetails(final CompProfessioneAdminView compProfessioneAdminView)throws ProfessioneException{

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(" UPDATE AN_MA_COMP_PROFESSIONE SET CP_PROF_CLASS_ID =? ,CP_STORICO =? ,CP_BANK_ID=? , CP_NUOVA_VOCE = ? WHERE CP_ID =? ");
			preparedStatement.setLong(1, compProfessioneAdminView.getProfClassficazioneId());
			preparedStatement.setLong(2, compProfessioneAdminView.getStorico());
			preparedStatement.setLong(3, compProfessioneAdminView.getBankId());
			if (compProfessioneAdminView.getNuovaVoceClassficazioneId()!= null) {
				preparedStatement.setLong(4, compProfessioneAdminView.getNuovaVoceClassficazioneId());
			} else {
				preparedStatement.setNull(4, java.sql.Types.INTEGER);
			}
			preparedStatement.setLong(5, compProfessioneAdminView.getProfessioneId());
			preparedStatement.executeUpdate();
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",
					sqlexception.getMessage());
			throw new ProfessioneException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}
	}

	/**
	 * To delete the associated Professione classificazione values
	 * @param professioneId
	 * @throws ProfessioneException
	 */
	public void deleteProfessioneDetails(final Long professioneId)throws ProfessioneException{

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(" DELETE FROM AN_MA_COMP_PROFESSIONE WHERE CP_ID = ?");
			preparedStatement.setLong(1, professioneId);
			preparedStatement.execute();
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",
					sqlexception.getMessage());
			throw new ProfessioneException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}
	}
	/**
	 * To get the professione classificazione details based on selected professione id
	 * @param professioneId
	 * @return CompProfessioneAdminView
	 * @throws ProfessioneException
	 */
	public CompProfessioneAdminView getProfessioneClassificazione4Id(final Long professioneId)throws ProfessioneException{

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		CompProfessioneAdminView compProfessioneAdminView = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(" SELECT CP_PROF_CLASS_ID,CP_BANK_ID,CP_STORICO,CL.CL_DESCRIZIONE,CP_NUOVA_VOCE FROM AN_MA_COMP_PROFESSIONE , CL_VW_CLASSIFICAZIONE CL WHERE CP_ID = ? AND CL.CL_ID = CP_PROF_CLASS_ID ");
			preparedStatement.setLong(1, professioneId);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				compProfessioneAdminView = new CompProfessioneAdminView();
				compProfessioneAdminView.setProfessioneId(professioneId);
				compProfessioneAdminView.setProfClassficazioneId(resultSet.getLong("CP_PROF_CLASS_ID"));
				compProfessioneAdminView.setBankId(resultSet.getLong("CP_BANK_ID"));
				compProfessioneAdminView.setStorico(resultSet.getLong("CP_STORICO"));
				compProfessioneAdminView.setProfClassficazioneDesc(resultSet.getString("CL_DESCRIZIONE"));
				compProfessioneAdminView.setNuovaVoceClassficazioneId(resultSet.getLong("CP_NUOVA_VOCE"));
				getClasificazioneDesc(compProfessioneAdminView);
			}
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",
					sqlexception.getMessage());
			throw new ProfessioneException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement,resultSet);
		}
		return compProfessioneAdminView;
	}
	
	/**
	 * This method is used to get professione details for the entered bank id
	 * @param bankId and classificazioneId
	 * @return List<CompProfessioneAdminView>
	 * @throws ProfessioneException
	 */
	public List<CompProfessioneAdminView> getProfessione4bankAndClassficazioneId(final Long bankId,final Long profClassificazioneeId)throws ProfessioneException{

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		CompProfessioneAdminView compProfessioneAdminView = null;
		List<CompProfessioneAdminView> compProfessioneList = null;
		String sqlQuery = "SELECT CP_ID,CP_PROF_CLASS_ID,CP_BANK_ID,CP_STORICO,CL.CL_DESCRIZIONE,CP_NUOVA_VOCE FROM AN_MA_COMP_PROFESSIONE , CL_VW_CLASSIFICAZIONE CL WHERE CP_BANK_ID = ? AND CL.CL_ID = CP_PROF_CLASS_ID";
		try {
			connection = getConnection();
			if ( profClassificazioneeId != null) {
				sqlQuery = sqlQuery + " AND CP_PROF_CLASS_ID = ?";
			}
			preparedStatement = connection.prepareStatement(sqlQuery);
			preparedStatement.setLong(1, bankId);
			if ( profClassificazioneeId != null ) {
				preparedStatement.setLong(2, profClassificazioneeId);
			}
			resultSet = preparedStatement.executeQuery();
			compProfessioneList = new ArrayList<CompProfessioneAdminView>();
			while (resultSet.next()) {
				compProfessioneAdminView = new CompProfessioneAdminView();
				compProfessioneAdminView.setProfessioneId(resultSet.getLong("CP_ID"));
				compProfessioneAdminView.setProfClassficazioneId(resultSet.getLong("CP_PROF_CLASS_ID"));
				compProfessioneAdminView.setBankId(resultSet.getLong("CP_BANK_ID"));
				compProfessioneAdminView.setStorico(resultSet.getLong("CP_STORICO"));
				compProfessioneAdminView.setProfClassficazioneDesc(resultSet.getString("CL_DESCRIZIONE"));
				compProfessioneAdminView.setNuovaVoceClassficazioneId(resultSet.getLong("CP_NUOVA_VOCE"));
				getClasificazioneDesc(compProfessioneAdminView);
				compProfessioneList.add(compProfessioneAdminView);
			}
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",
					sqlexception.getMessage());
			throw new ProfessioneException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement,resultSet);
		}
		return compProfessioneList;
	}
	
	/**
	 * This method added to check whether the professione entered is valid method is called in Attributi admin while adding new or modifying professione
	 * @param professioneId
	 * @return
	 * @throws ProfessioneException
	 */
	public boolean isProfessioneValid(final Long classificazioneId)throws ProfessioneException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		boolean isValid = false;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("SELECT COUNT(1) result FROM AN_MA_COMP_PROFESSIONE WHERE CP_PROF_CLASS_ID = ? AND CP_BANK_ID = ? ");
			preparedStatement.setLong(1, classificazioneId);
			preparedStatement.setLong(2, SecurityHandler.getLoginBancaId());
			resultSet = preparedStatement.executeQuery();
			if ( resultSet.next() & (Integer.parseInt(resultSet.getString("result")) > 0)) {
				isValid = true;
			}
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",
					sqlexception.getMessage());
			throw new ProfessioneException(sqlexception.getMessage());
		} catch (final SubSystemHandlerException subsystemException) {
			throw new ProfessioneException(subsystemException.getMessage());
		} finally {
			cleanup(connection, preparedStatement,resultSet);
		}
		return isValid;
	}
	
	/**
	 * This method is used to get professione details for the entered bank id and classficazione Id
	 * @param bankId and classificazioneId
	 * @return List<CompProfessioneAdminView>
	 * @throws ProfessioneException
	 */
	public CompProfessioneAdminView getProfessioneView4bankAndClassficazioneId(final Long bankId,final Long profClassificazioneeId)throws ProfessioneException{

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		CompProfessioneAdminView compProfessioneAdminView = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("SELECT CP_ID,CP_PROF_CLASS_ID,CP_BANK_ID,CP_STORICO,CL.CL_DESCRIZIONE,CP_NUOVA_VOCE FROM AN_MA_COMP_PROFESSIONE , CL_VW_CLASSIFICAZIONE CL WHERE CP_BANK_ID = ? AND CL.CL_ID = CP_PROF_CLASS_ID AND CP_PROF_CLASS_ID = ? ");
			preparedStatement.setLong(1, bankId);
			preparedStatement.setLong(2, profClassificazioneeId);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				compProfessioneAdminView = new CompProfessioneAdminView();
				compProfessioneAdminView.setProfessioneId(resultSet.getLong("CP_ID"));
				compProfessioneAdminView.setProfClassficazioneId(resultSet.getLong("CP_PROF_CLASS_ID"));
				compProfessioneAdminView.setBankId(resultSet.getLong("CP_BANK_ID"));
				compProfessioneAdminView.setStorico(resultSet.getLong("CP_STORICO"));
				compProfessioneAdminView.setProfClassficazioneDesc(resultSet.getString("CL_DESCRIZIONE"));
				compProfessioneAdminView.setNuovaVoceClassficazioneId(resultSet.getLong("CP_NUOVA_VOCE"));
				getClasificazioneDesc(compProfessioneAdminView);
			}
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",
					sqlexception.getMessage());
			throw new ProfessioneException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement,resultSet);
		}
		return compProfessioneAdminView;
	}

	/**
	 * @param compProfessioneAdminView
	 * @throws ProfessioneException 
	 * @throws RemoteException
	 * @throws SubSystemHandlerException
	 */
	private void getClasificazioneDesc( final CompProfessioneAdminView compProfessioneAdminView) throws ProfessioneException
	{
		if (compProfessioneAdminView!= null && compProfessioneAdminView.getNuovaVoceClassficazioneId() >0 ) {
			try {
				compProfessioneAdminView.setNuovaVoceClassficazioneDesc(new ClassificazioneHandler().getClassificazioneView(compProfessioneAdminView.getNuovaVoceClassficazioneId()).getDescrizione());
			} catch (final RemoteException remoteException) {
				log4Debug.debug("<<GA>> Exception while getting details ",
						remoteException.getMessage());
				throw new ProfessioneException(remoteException.getMessage());
			} catch (final SubSystemHandlerException subSystemException) {
				log4Debug.debug("<<GA>> Exception while getting details ",
						subSystemException.getMessage());
				throw new ProfessioneException(subSystemException.getMessage());
			}
		}
	}
	
	/* (non-Javadoc)
	 * @see it.sella.anagrafe.dao.IProfessioneDAO#getCompatibleProfessioneTAE(java.lang.Long, java.lang.String, boolean, java.lang.Long)
	 */
	public boolean getCompatibleProfessioneTAE(final Long comProfessioneId,final String taeCode, final boolean isValid,final Long bankid) throws ProfessioneException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			connection = getConnection();
			final Long storicoval=isValid?0L:1L;
			preparedStatement = connection.prepareStatement("SELECT 1 FROM AN_MA_COMP_PROFESSIONE_TAE CT, AN_MA_TAE TA,AN_MA_COMP_PROFESSIONE CP WHERE CT.CT_PROF_COMP_ID = CP.CP_ID AND CT.CT_TAE_ID = TA.TA_ID AND CP.CP_BANK_ID = ? AND CP.CP_STORICO = ? AND CP.CP_PROF_CLASS_ID = ? AND TA.TA_CODE = ?");
			preparedStatement.setLong(1, bankid.longValue());
			preparedStatement.setLong(2, storicoval);
			preparedStatement.setLong(3, comProfessioneId);
			preparedStatement.setString(4, taeCode);
			resultSet = preparedStatement.executeQuery();
			return resultSet.next();
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new ProfessioneException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement,resultSet);
		}
	}
	
	/* (non-Javadoc)
	 * @see it.sella.anagrafe.dao.IProfessioneDAO#isCompatibleProfessioneTAE(java.lang.Long, boolean, java.lang.Long)
	 */
	public boolean isCompatibleProfessioneTAE(final Long comProfessioneId, final boolean isValid,final Long bankid) throws ProfessioneException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			connection = getConnection();
			final Long storicoval=isValid?0L:1L;
			preparedStatement = connection.prepareStatement("SELECT 1 FROM AN_MA_COMP_PROFESSIONE_TAE CT, AN_MA_COMP_PROFESSIONE CP WHERE CT.CT_PROF_COMP_ID = CP.CP_ID AND CP.CP_BANK_ID = ? AND CP.CP_STORICO = ? AND CP.CP_PROF_CLASS_ID = ? AND ROWNUM=1");
			preparedStatement.setLong(1, bankid.longValue());
			preparedStatement.setLong(2, storicoval);
			preparedStatement.setLong(3, comProfessioneId);
			resultSet = preparedStatement.executeQuery();
			return resultSet.next();
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new ProfessioneException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement,resultSet);
		}
	}
	
	/* (non-Javadoc)
	 * @see it.sella.anagrafe.dao.IProfessioneDAO#getCompatibleAlboProfessione(java.lang.String)
	 */
	public boolean getCompatibleAlboProfessione(final Long tipoSoggettoId,final String alboCode) throws ProfessioneException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("SELECT 1 FROM AN_MA_COMP_ALBO_PROFESSIONE CA, AN_MA_ALBO_PROFESSIONE AP WHERE CA.CA_PROF_ID = AP.AP_ID AND CA.CA_TIPOSOGGETTO_ID=? AND AP.AP_CODE = ?");
			preparedStatement.setLong(1, tipoSoggettoId);
			preparedStatement.setString(2, alboCode);
			resultSet = preparedStatement.executeQuery();
			return resultSet.next();
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new ProfessioneException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement,resultSet);
		}
	}
}


