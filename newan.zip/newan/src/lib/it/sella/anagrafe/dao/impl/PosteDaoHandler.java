package it.sella.anagrafe.dao.impl;

import it.sella.anagrafe.dao.IPosteDAOHandler;
import it.sella.anagrafe.dbaccess.DBAccessHelper;
import it.sella.anagrafe.poste.builder.PosteXMLBuilder;
import it.sella.anagrafe.poste.exception.PosteException;
import it.sella.anagrafe.view.PosteCustomerView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
/**
 * The implementation part of PosteDaoHandler
 * @author gbs03109
 *
 */
public class PosteDaoHandler extends DBAccessHelper implements IPosteDAOHandler{

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(PosteDaoHandler.class);

	/**
	 * To get list of poste for the current date with status as inserted and soggetto is null
	 */
	public List<PosteCustomerView> getAllInsertedPosteListToProcess(final Long opId) throws  PosteException {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuilder query = new StringBuilder();
		final List<PosteCustomerView> posteViews= new ArrayList<PosteCustomerView>();
		query.append(" SELECT PST.SP_ID,PST.SP_DA_NOME,PST.SP_DA_COGNOME,PST.SP_AE_SESSO,PST.SP_AE_CITTADENZA,PST.SP_DA_DATE_OF_BIRTH,PST.SP_DA_CITTA_OF_BIRTH,PST.SP_DA_NAZIONE_OF_BIRTH,PST.SP_DA_PROVINCE_OF_BIRTH,PST.SP_CODICEFISCALE,PST.SP_DOC_TIPO_DOCUMENTO,PST.SP_DOC_NUMERO_DOCUMENTO,PST.SP_DOC_LUOGO_EMISSIONE,PST.SP_DOC_ENTE_SMISSIONE,PST.SP_DOC_DATA_EMISSIONE,PST.SP_DOC_DATA_SCADENZA,PST.SP_ADD_INDIRIZZO,PST.SP_ADD_NAZIONE,PST.SP_ADD_CITTA,PST.SP_ADD_CAP,PST.SP_ADD_PROVINCIA  FROM AN_TR_SOGGETTO_POSTE PST ");
		query.append(" WHERE PST.SP_SOGGETTO_ID IS NULL AND PST.SP_STATUS='INSERTED'   AND TRUNC(PST.SP_INSERTION_DATE) = TRUNC(SYSDATE)");
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				final PosteCustomerView poste = setInPosteView(resultSet);
				poste.setInputCensimentoXML(PosteXMLBuilder.buildXMLForPosteCreation(poste));
				poste.setOpId(opId);
				posteViews.add(poste);
			}
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new PosteException(se.getMessage(),se);
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return posteViews;
	}

	/**
	 * To build the view for poste
	 * @param resultSet
	 * @return
	 * @throws SQLException
	 */
	private PosteCustomerView setInPosteView(ResultSet resultSet) throws SQLException {
		final PosteCustomerView poste = new PosteCustomerView();
		poste.setId(Long.valueOf(resultSet.getLong("SP_ID")));
		poste.setNome(resultSet.getString("SP_DA_NOME"));
		poste.setCognome(resultSet.getString("SP_DA_COGNOME"));
		poste.setSesso(resultSet.getString("SP_AE_SESSO"));
		poste.setCittadenza(resultSet.getString("SP_AE_CITTADENZA"));
		poste.setDateOfBirth(resultSet.getTimestamp("SP_DA_DATE_OF_BIRTH"));
		poste.setCittaOfBirth(resultSet.getString("SP_DA_CITTA_OF_BIRTH"));
		poste.setNazioneOfBirth(resultSet.getString("SP_DA_NAZIONE_OF_BIRTH"));
		poste.setProvinceOfBirth(resultSet.getString("SP_DA_PROVINCE_OF_BIRTH"));
		poste.setCodiceFiscale(resultSet.getString("SP_CODICEFISCALE"));
		poste.setTipoDocumento(resultSet.getString("SP_DOC_TIPO_DOCUMENTO"));
		poste.setNumeroDocumento(resultSet.getString("SP_DOC_NUMERO_DOCUMENTO"));
		poste.setLuogoEmissione(resultSet.getString("SP_DOC_LUOGO_EMISSIONE"));
		poste.setEnteEmissione(resultSet.getString("SP_DOC_ENTE_SMISSIONE"));
		poste.setDataEmissione(resultSet.getTimestamp("SP_DOC_DATA_EMISSIONE"));
		poste.setDataScandenza(resultSet.getTimestamp("SP_DOC_DATA_SCADENZA"));
		poste.setIndirizzo(resultSet.getString("SP_ADD_INDIRIZZO"));
		poste.setNazione(resultSet.getString("SP_ADD_NAZIONE"));
		poste.setCitta(resultSet.getString("SP_ADD_CITTA"));
		poste.setCap(resultSet.getString("SP_ADD_CAP"));
		poste.setProvincia(resultSet.getString("SP_ADD_PROVINCIA"));
		return poste;
	}

	/**
	 * To update the process Poste staus as SUCCESS as CREATED and ALREADY EXISTS and Failure as ERROR
	 */

	public void updateProcessedPosteStatus(final PosteCustomerView view) throws PosteException  {
		Connection connection = null;
		PreparedStatement statement = null;
		final StringBuffer query = new StringBuffer();
		query.append("UPDATE an_tr_soggetto_poste SET SP_SOGGETTO_ID = ? , SP_STATUS = ? , SP_ERROR = ?,SP_CODICE_HOST = ? , SP_OPERATION_DATE = ?, SP_OP_ID = ? WHERE SP_ID = ? ");
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			int statementCount = 1;
			if(view.getSoggettoId()!=null){
				statement.setLong(statementCount, Long.valueOf(view.getSoggettoId()));
			}else{
				statement.setNull(statementCount, Types.NUMERIC);
			}
			statement.setString(++statementCount, view.getStatus());
			statement.setString(++statementCount, view.getError());
			statement.setString(++statementCount, view.getCodiceHost());
			statement.setTimestamp(++statementCount, view.getOperationDate());
			statement.setLong(++statementCount, Long.valueOf(view.getOpId()));
			statement.setLong(++statementCount, Long.valueOf(view.getId()));
			statement.executeUpdate();
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new PosteException(se.getMessage(),se);
		} finally {
			cleanup(connection, statement);
		}

	}
}
