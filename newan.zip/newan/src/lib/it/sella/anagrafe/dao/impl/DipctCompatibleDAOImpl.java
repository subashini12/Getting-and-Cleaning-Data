package it.sella.anagrafe.dao.impl;

import it.sella.anagrafe.dao.IDipctCompatibilityAdminDAO;
import it.sella.anagrafe.dbaccess.DBAccessHelper;
import it.sella.anagrafe.implementation.DipctCompatibilityView;
import it.sella.anagrafe.util.DipctAdminHelperException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DipctCompatibleDAOImpl extends DBAccessHelper implements IDipctCompatibilityAdminDAO {

	final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DipctCompatibleDAOImpl.class);
	
	public List<DipctCompatibilityView> getAllBanks() throws DipctAdminHelperException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		final List<DipctCompatibilityView> adminViewList = new ArrayList<DipctCompatibilityView>();
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("SELECT DC_ID,DC_ID_BANCA,DC_DIPCT_ALLOWED FROM AN_MA_DIPCT_COMP ");
			resultSet=preparedStatement.executeQuery();
			while ( resultSet.next() ) {
				final DipctCompatibilityView view = new DipctCompatibilityView  () ;
				view.setId(Long.valueOf(resultSet.getLong("DC_ID")));
				view.setBankId(Long.valueOf(resultSet.getLong("DC_ID_BANCA")));
				view.setDipctAllowed(Long.valueOf(resultSet.getLong("DC_DIPCT_ALLOWED")));
				adminViewList.add(view);
			}
		} catch (final SQLException e) {
			log4Debug.debug(" Exception while getting the bank Id ", e.getMessage());
			throw new DipctAdminHelperException(e.getMessage());
		}finally {
			cleanup(connection, preparedStatement, resultSet);
		}
		return adminViewList;
	}
	
	public void updateDipctCompatibility(final DipctCompatibilityView view) throws DipctAdminHelperException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		final ResultSet resultSet = null;
		try {
				connection = getConnection();
				
				preparedStatement = connection.prepareStatement("UPDATE AN_MA_DIPCT_COMP SET DC_DIPCT_ALLOWED = ? WHERE DC_ID_BANCA = ?");
				checkForNullAndSetLongValue(preparedStatement, view.getDipctAllowed(), 1);
				 if (view.getBankId() != null) {
					preparedStatement.setLong(2, view.getBankId().longValue());
				}
				preparedStatement.executeUpdate();
			} catch (final SQLException e) {
				log4Debug.debug(" Exception while Updating with bank Id ", e.getMessage());
				throw new DipctAdminHelperException(e.getMessage());
			}finally {
				cleanup(connection, preparedStatement, resultSet);
			}
			
		
	}

	

}
