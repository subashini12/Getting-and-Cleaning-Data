package it.sella.anagrafe.dao;

import it.sella.anagrafe.util.ProfessioneException;
import it.sella.anagrafe.view.CompProfessioneAdminView;
import it.sella.classificazione.ClassificazioneView;

import java.util.Collection;
import java.util.List;

/**
 * @author gbs02551
 *
 */
public interface IProfessioneDAO {

	/**The method returns profession details based on storico value
	 *@param storico
	 * @return collection
	 * @throws ProfessioneException
	 */
	public Collection<ClassificazioneView> listProfessione(boolean storico,Long bankid) throws ProfessioneException;
	public ClassificazioneView gettProfessionebyCausale(String causale,boolean storico,Long bankid) throws ProfessioneException;
	public ClassificazioneView gettProfessionebyDesc(String descrizione, boolean storico,Long bankid) throws ProfessioneException;
	
	/** To get classificazione view with newly assined values when storico expired
	 * @param causale
	 * @param storico
	 * @param bankid
	 * @return
	 * @throws ProfessioneException
	 */
	public ClassificazioneView getProfessionebyCausaleNuova(String causale,boolean storico,Long bankid) throws ProfessioneException;
	
	/**
	 * To insert new professione classificazione values into the table AN_MA_COMP_PROFESSIONE.New Classfificazione id changed should be present in the classificazione table
	 * @param compProfessioneAdminView
	 * @throws ProfessioneException
	 */
	public void insertProfessioneClassficazione(CompProfessioneAdminView compProfessioneAdminView)throws ProfessioneException;
	/**
	 * To modify the professione classificazione values into the table AN_MA_COMP_PROFESSIONE .New Classfificazione id changed should be present in the classificazione table
	 * @param compProfessioneAdminView
	 * @throws ProfessioneException
	 */
	public void modifyProfessioneDetails(CompProfessioneAdminView compProfessioneAdminView)throws ProfessioneException;
	/**
	 * To delete the associated Professione classificazione values
	 * @param professioneId
	 * @throws ProfessioneException
	 */
	public void deleteProfessioneDetails(Long professioneId)throws ProfessioneException;
	/**
	 * To get the professione classificazione details based on selected professione id
	 * @param professioneId
	 * @return CompProfessioneAdminView
	 * @throws ProfessioneException
	 */
	public CompProfessioneAdminView getProfessioneClassificazione4Id(Long professioneId)throws ProfessioneException;
	/**
	 * This method is used to get professione details for the entered bank id and classificazioneId
	 * @param bankId
	 * @return List<CompProfessioneAdminView>
	 * @throws ProfessioneException
	 */
	public List<CompProfessioneAdminView> getProfessione4bankAndClassficazioneId(Long bankId,Long profClassificazioneeId)throws ProfessioneException;
	/**
	 * This method added to check whether the professione entered is valid method is called in Attributi admin while adding new or modifying professione
	 * @param professioneId
	 * @return
	 * @throws ProfessioneException
	 */
	public boolean isProfessioneValid(final Long professioneId)throws ProfessioneException;
	/**
	 * This method is used to get professione details for the entered bank id and classficazione Id
	 * @param bankId and classificazioneId
	 * @return List<CompProfessioneAdminView>
	 * @throws ProfessioneException
	 */
	public CompProfessioneAdminView getProfessioneView4bankAndClassficazioneId(final Long bankId,final Long profClassificazioneeId)throws ProfessioneException;
	
	/**
	 * This method to check the compatibility of Professione and selected TAE
	 * @param comProfessioneId
	 * @param taeCode
	 * @param isValid
	 * @param bankid
	 * @return
	 * @throws ProfessioneException
	 */
	public boolean getCompatibleProfessioneTAE(final Long comProfessioneId,final String taeCode, final boolean isValid,final Long bankid) throws ProfessioneException;
	/**
	 * This method to check the compatibility of Professione and TAE
	 * @param comProfessioneId
	 * @param isValid
	 * @param bankid
	 * @return
	 * @throws ProfessioneException
	 */
	public boolean isCompatibleProfessioneTAE(final Long comProfessioneId, final boolean isValid,final Long bankid) throws ProfessioneException;
	
	/**
	 * This method to check the compatibility of Albo Professione
	 * @param alboCode
	 * @return
	 * @throws ProfessioneException
	 */
	public boolean getCompatibleAlboProfessione(final Long tipoSoggettoId,final String alboCode) throws ProfessioneException;
}
