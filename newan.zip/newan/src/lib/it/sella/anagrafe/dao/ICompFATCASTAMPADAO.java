package it.sella.anagrafe.dao;

import it.sella.anagrafe.util.FatcaStampaException;
import it.sella.anagrafe.view.FatcaStampaView;

/**
 * Interface for AN_MA_COMPAT_FATCA_AZ_STAMPA
 * @author gbs03109
 *
 */
public interface ICompFATCASTAMPADAO {

	public FatcaStampaView getFATCAForClassId(final Long classId)	throws FatcaStampaException; 

	public void updateFatcaStampa(final FatcaStampaView fatcaStampaView)	throws FatcaStampaException; 

	public void deleteFatcaStampaForClassId(final Long classId)	throws FatcaStampaException;

	public void insertFatcaStampa(final FatcaStampaView fatcaStampaView)	throws FatcaStampaException;

	public Boolean isRecordExists(final Long classId)throws FatcaStampaException;

}
