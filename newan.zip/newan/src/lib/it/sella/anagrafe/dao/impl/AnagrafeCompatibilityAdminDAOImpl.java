package it.sella.anagrafe.dao.impl;

import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.dao.IAnagrafeCompatibilityAdminDAO;
import it.sella.anagrafe.dbaccess.DBAccessHelper;
import it.sella.anagrafe.implementation.AnagrafeCompatibilityView;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.util.AnagrafeConfigException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 * 
 * @author gbs03109
 *
 */
public class AnagrafeCompatibilityAdminDAOImpl extends DBAccessHelper implements IAnagrafeCompatibilityAdminDAO{

	final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AnagrafeCompatibilityAdminDAOImpl.class);

	/**
	 * To get list of banks
	 */
	public List<AnagrafeCompatibilityView> getListOfBanks() throws AnagrafeConfigException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		final List<AnagrafeCompatibilityView> adminViewList = new ArrayList<AnagrafeCompatibilityView>();
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("SELECT CC.CC_BANCA_ID,CC.CC_ATTR_ID,CC.CC_ALLOWED FROM AN_MA_CONFIG_CHECK CC");
			resultSet=preparedStatement.executeQuery();
			while ( resultSet.next() ) {
				final AnagrafeCompatibilityView view = new AnagrafeCompatibilityView  () ;
				view.setBankId(Long.valueOf(resultSet.getLong("CC_BANCA_ID")));
				view.setAttributeName(ClassificazioneHandler.getClassificazioneView(resultSet.getLong("CC_ATTR_ID")));
				view.setAllowed(resultSet.getString("CC_ALLOWED"));
				adminViewList.add(view);
			}
		} catch (final SQLException e) {
			log4Debug.debug( e.getMessage());
			throw new AnagrafeConfigException(e.getMessage());
		} catch (RemoteException e) {
			log4Debug.debug( e.getMessage());
			throw new AnagrafeConfigException(e.getMessage());
		} catch (SubSystemHandlerException e) {
			log4Debug.debug( e.getMessage());
			throw new AnagrafeConfigException(e.getMessage());
		}finally {
			cleanup(connection, preparedStatement, resultSet);
		}
		return adminViewList;
	}
	
	/**
	 * To get bank id and corresponding details for selected causale
	 */
	public List<AnagrafeCompatibilityView> getListOfBanksByClassId(final Long classId) throws AnagrafeConfigException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		final List<AnagrafeCompatibilityView> adminViewList = new ArrayList<AnagrafeCompatibilityView>();
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("SELECT CC.CC_BANCA_ID,CC.CC_ATTR_ID,CC.CC_ALLOWED FROM AN_MA_CONFIG_CHECK CC WHERE CC.CC_ATTR_ID = ?");
			preparedStatement.setLong(1, Long.valueOf(classId));
			resultSet=preparedStatement.executeQuery();
			while ( resultSet.next() ) {
				final AnagrafeCompatibilityView view = new AnagrafeCompatibilityView  () ;
				view.setBankId(Long.valueOf(resultSet.getLong("CC_BANCA_ID")));
				view.setAttributeName(ClassificazioneHandler.getClassificazioneView(resultSet.getLong("CC_ATTR_ID")));
				view.setAllowed(resultSet.getString("CC_ALLOWED"));
				adminViewList.add(view);
			}
		} catch (final SQLException e) {
			log4Debug.debug( e.getMessage());
			throw new AnagrafeConfigException(e.getMessage());
		} catch (RemoteException e) {
			log4Debug.debug( e.getMessage());
			throw new AnagrafeConfigException(e.getMessage());
		} catch (SubSystemHandlerException e) {
			log4Debug.debug( e.getMessage());
			throw new AnagrafeConfigException(e.getMessage());
		}finally {
			cleanup(connection, preparedStatement, resultSet);
		}
		return adminViewList;
	}

	/**
	 * To update compatability for attributes
	 * @param view
	 * @throws AnagrafeConfigException
	 */
	public void updateCompatibilityForAttributes(final AnagrafeCompatibilityView view)	throws AnagrafeConfigException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("UPDATE AN_MA_CONFIG_CHECK SET CC_ALLOWED = ? WHERE CC_BANCA_ID = ? AND CC_ATTR_ID = ?");
			preparedStatement.setString(1, view.getAllowed());
			preparedStatement.setLong(2, Long.valueOf(view.getBankId()));
			preparedStatement.setLong(3, Long.valueOf(view.getAttributeName().getId()));
			preparedStatement.executeUpdate();
		} catch (final SQLException e) {
			log4Debug.debug(" Exception while Updating with bank Id ", e.getMessage());
			throw new AnagrafeConfigException(e.getMessage());
		}finally {
			cleanup(connection, preparedStatement);
		}


	}
/**
 * To check whether configuration allowed for particular bank or not
 * @param bankId
 * @return
 * @throws AnagrafeConfigException
 */
	public Boolean isConfigurationAllowed(final Long bankId,final Long classId) throws AnagrafeConfigException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Boolean isAllowed= false;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("SELECT CC_ALLOWED FROM AN_MA_CONFIG_CHECK CC WHERE CC_BANCA_ID = ? AND CC_ATTR_ID = ? ");
			preparedStatement.setLong(1, Long.valueOf(bankId));
			preparedStatement.setLong(2, Long.valueOf(classId));
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next()) {
				isAllowed = "true".equals(resultSet.getString("CC_ALLOWED"))?Boolean.TRUE:Boolean.FALSE;
			}
		} catch (final SQLException e) {
			log4Debug.debug(" Exception while getting the bank Id ", e.getMessage());
			throw new AnagrafeConfigException(e.getMessage());
		}finally {
			cleanup(connection, preparedStatement, resultSet);
		}
		return isAllowed;
	}

}
