package it.sella.anagrafe.dao;

import it.sella.anagrafe.poste.exception.PosteException;
import it.sella.anagrafe.view.PosteCustomerView;

import java.util.List;
/**
 * Interface for PosteDAOHandler
 * @author gbs03109
 *
 */
public interface IPosteDAOHandler {
	/**
	 * To get list of poste from DB which is in inserted status
	 * @return
	 * @throws PosteException
	 */
	public List<PosteCustomerView> getAllInsertedPosteListToProcess(final Long opId) throws  PosteException;
	
	/**
	 * To update the processed Poste status
	 * @param view
	 * @throws PosteException
	 */
	public void updateProcessedPosteStatus(final PosteCustomerView view) throws PosteException;

}
