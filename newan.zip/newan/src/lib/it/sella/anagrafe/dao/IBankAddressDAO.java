package it.sella.anagrafe.dao;

import it.sella.anagrafe.GestoreAnagrafeException;

import java.util.Collection;

/**
 * DAO Interface for Bank address
 *
 */
public interface IBankAddressDAO {
	
	/**
	 * Method to get list of all the bank address names
	 * @return
	 * @throws GestoreAnagrafeException 
	 */
	Collection<String> getListOfBankAddressNames() throws  GestoreAnagrafeException;
	
	
}
