package it.sella.anagrafe.dao.impl;

import it.sella.anagrafe.dao.IPrivacyCompatibilityAdminDAO;
import it.sella.anagrafe.dbaccess.DBAccessHelper;
import it.sella.anagrafe.implementation.PrivacyCompatibilityView;
import it.sella.anagrafe.util.PrivacyAdminHelperException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PrivacyCompatibleDAOImpl extends DBAccessHelper implements IPrivacyCompatibilityAdminDAO {

	final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(PrivacyCompatibleDAOImpl.class);
	
	public List<PrivacyCompatibilityView> getAllBanks() throws PrivacyAdminHelperException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		final List<PrivacyCompatibilityView> adminViewList = new ArrayList<PrivacyCompatibilityView>();
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("SELECT  PC_BANCA_ID, PC_PRIVACY_ALLOWED FROM AN_MA_CONFIG_PRIV_CHECK ");
			resultSet=preparedStatement.executeQuery();
			while ( resultSet.next() ) {
				final PrivacyCompatibilityView view = new PrivacyCompatibilityView  () ;
				view.setBankId(Long.valueOf(resultSet.getLong("PC_BANCA_ID")));
				view.setPrivacyAllowed(resultSet.getString("PC_PRIVACY_ALLOWED"));
				adminViewList.add(view);
			}
		} catch (final SQLException e) {
			log4Debug.debug(" Exception while getting the bank Id ", e.getMessage());
			throw new PrivacyAdminHelperException(e.getMessage());
		}finally {
			cleanup(connection, preparedStatement, resultSet);
		}
		return adminViewList;
	}
	
	public void updateDipctCompatibility(final PrivacyCompatibilityView view) throws PrivacyAdminHelperException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		final ResultSet resultSet = null;
		try {
				connection = getConnection();
				
				preparedStatement = connection.prepareStatement("UPDATE AN_MA_CONFIG_PRIV_CHECK SET PC_PRIVACY_ALLOWED = ? WHERE PC_BANCA_ID = ?");
				preparedStatement.setString(1, view.getPrivacyAllowed());
				 if (view.getBankId() != null) {
					preparedStatement.setLong(2, view.getBankId().longValue());
				}
				preparedStatement.executeUpdate();
			} catch (final SQLException e) {
				log4Debug.debug(" Exception while Updating with bank Id ", e.getMessage());
				throw new PrivacyAdminHelperException(e.getMessage());
			}finally {
				cleanup(connection, preparedStatement, resultSet);
			}
			
		
	}

}
