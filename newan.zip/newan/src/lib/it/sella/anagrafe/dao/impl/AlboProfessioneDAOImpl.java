package it.sella.anagrafe.dao.impl;

import it.sella.anagrafe.dao.IAlboProfessioneDAO;
import it.sella.anagrafe.util.AlboProfessioneException;
import it.sella.anagrafe.util.ConnectionHandler;
import it.sella.anagrafe.view.AlboProfessioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AlboProfessioneDAOImpl extends ConnectionHandler implements IAlboProfessioneDAO {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AlboProfessioneDAOImpl.class);

	public AlboProfessioneView getAlboProfDetails4alboProfCode(final String alboProfCode) throws AlboProfessioneException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		AlboProfessioneView alboProfView = null;
		try {
				connection = getConnection();
				preparedStatement = connection.prepareStatement("SELECT AP.AP_ID,AP.AP_CODE,AP.AP_DESCRIPTION FROM AN_MA_ALBO_PROFESSIONE AP WHERE AP.AP_CODE = ?");
				preparedStatement.setString(1, alboProfCode);
				resultSet = preparedStatement.executeQuery();
				while (resultSet.next()) {
					alboProfView = new AlboProfessioneView();
					alboProfView.setAlboProfessioneId(resultSet.getLong("AP_ID"));
					alboProfView.setAlboProfessioneCode(resultSet.getString("AP_CODE"));
					alboProfView.setAlboProfessioneDescription(resultSet.getString("AP_DESCRIPTION"));
				}
		}catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new AlboProfessioneException(sqlexception.getMessage());
		}
		finally {
			cleanup(connection, preparedStatement,resultSet);
		}		
		return alboProfView;
	}

	public void insertAlboProfessione(final AlboProfessioneView alboProAdminView) throws AlboProfessioneException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("INSERT INTO AN_MA_ALBO_PROFESSIONE (AP_ID,AP_CODE,AP_DESCRIPTION) VALUES (AN_SQ_AP.NEXTVAL,?,?)");
			preparedStatement.setString(1, alboProAdminView.getAlboProfessioneCode());
			preparedStatement.setString(2, alboProAdminView.getAlboProfessioneDescription());
			final int rowNum = preparedStatement.executeUpdate();
			
			if(rowNum == 0){
				throw new AlboProfessioneException("Zero Rows Inserted.");
			}
			
		}catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while Inserting details ",sqlexception.getMessage());
			throw new AlboProfessioneException(sqlexception.getMessage());
		} 
		finally {
			cleanup(connection, preparedStatement);
		}
		
	}

	public void modifyAlboProfDetails(final AlboProfessioneView alboProAdminView) throws AlboProfessioneException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("UPDATE AN_MA_ALBO_PROFESSIONE SET AP_DESCRIPTION = ?, AP_CODE = ? WHERE AP_ID = ? ");
			preparedStatement.setString(1, alboProAdminView.getAlboProfessioneDescription());
			preparedStatement.setString(2, alboProAdminView.getAlboProfessioneCode());
			preparedStatement.setLong(3, alboProAdminView.getAlboProfessioneId());
			final int rowNum = preparedStatement.executeUpdate();
			
			if(rowNum == 0){
				throw new AlboProfessioneException("Zero Rows Updated.");
			}
			
		}catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while Updating details ",sqlexception.getMessage());
			throw new AlboProfessioneException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}		
	}

	public boolean isAlboProfAlreadyExist(final String alboProfCode) throws AlboProfessioneException {
		Connection connection = null;
	     PreparedStatement preparedStatement = null;
	     ResultSet resultSet = null;
	     boolean isAlreadyExist = false;
	     try {
	            connection = getConnection();
	            preparedStatement = connection.prepareStatement("SELECT AP.AP_ID,AP.AP_CODE,AP.AP_DESCRIPTION FROM AN_MA_ALBO_PROFESSIONE AP WHERE AP.AP_CODE = ? ");
	            preparedStatement.setString(1, alboProfCode);
	            resultSet = preparedStatement.executeQuery();
	            isAlreadyExist = resultSet.next();
	     }catch (final SQLException sqlexception) {
				log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
				throw new AlboProfessioneException(sqlexception.getMessage());
		 } 
	     finally {
				cleanup(connection, preparedStatement,resultSet);
		 }
	     return isAlreadyExist;
	}
	
	public void deleteAlboProfessioneDetails(final Long alboProfId) throws AlboProfessioneException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(" DELETE FROM AN_MA_ALBO_PROFESSIONE WHERE AP_ID = ?");
			preparedStatement.setLong(1, alboProfId);
			preparedStatement.execute();
			
			if(preparedStatement.getUpdateCount() == 0){
				throw new AlboProfessioneException("Zero Rows Deleted.");
			}
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while Deleteing Albo Professione details ",
					sqlexception.getMessage());
			throw new AlboProfessioneException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}
	}
	public boolean isAlboMappedToTipoSoggetto(final Long alboId) throws AlboProfessioneException {
		
		 Connection connection = null;
	     PreparedStatement preparedStatement = null;
	     ResultSet resultSet = null;
	     boolean isAlboMapped = false;
	     try {
	            connection = getConnection();
	            preparedStatement = connection.prepareStatement(" SELECT CA_ID FROM AN_MA_COMP_ALBO_PROFESSIONE CAP WHERE CAP.CA_PROF_ID = ? ");
	            preparedStatement.setLong(1, alboId);
	            resultSet = preparedStatement.executeQuery();
	            isAlboMapped = resultSet.next();
	     }catch (final SQLException sqlexception) {
				log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
				throw new AlboProfessioneException(sqlexception.getMessage());
		 } 
	     finally {
				cleanup(connection, preparedStatement,resultSet);
		 }
	     return isAlboMapped;
	}
}
