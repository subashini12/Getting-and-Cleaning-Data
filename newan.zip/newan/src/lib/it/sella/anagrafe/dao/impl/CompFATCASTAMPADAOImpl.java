package it.sella.anagrafe.dao.impl;

import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.dao.ICompFATCASTAMPADAO;
import it.sella.anagrafe.dbaccess.DBAccessHelper;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.util.FatcaStampaException;
import it.sella.anagrafe.view.FatcaStampaView;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * DAO Class For Master AN_MA_COMPAT_FATCA_AZ_STAMPA 
 * @author gbs03109
 *
 */
public class CompFATCASTAMPADAOImpl extends DBAccessHelper implements ICompFATCASTAMPADAO{

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CompFATCASTAMPADAOImpl.class);


	/**
	 * To get classificazione view.
	 * @param resultSet
	 * @return
	 * @throws SQLException
	 * @throws RemoteException
	 * @throws SubSystemHandlerException
	 */
	private ClassificazioneView setCompFATCAAZ(final ResultSet resultSet,final String value) throws  RemoteException, SubSystemHandlerException, SQLException {
		ClassificazioneView classificazioneView = null;
		if(resultSet.getString(value) !=null){
			classificazioneView = ClassificazioneHandler.getClassificazioneView(Long.valueOf(resultSet.getString(value)));
		}
		return classificazioneView;
	}

	/**
	 * To retrive a particular record from AN_MA_COMPAT_FATCA_AZ_STAMPA for a particular classificazione id
	 */

	public FatcaStampaView getFATCAForClassId(final Long classId) throws FatcaStampaException {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		FatcaStampaView fatcaStampaView = null;
		query.append("SELECT FS_FATCA_CLASS_ID,FS_IS_BUSTA_STAMPA_ALLOWED,FS_IS_GIIN_MANDATE,FS_XML_TAG FROM AN_MA_COMPAT_FATCA_AZ_STAMPA WHERE FS_FATCA_CLASS_ID = ?");
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setLong(1, classId);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				fatcaStampaView = new FatcaStampaView();
				final ClassificazioneView classificazioneView = setCompFATCAAZ(resultSet,"FS_FATCA_CLASS_ID");
				if(classificazioneView !=null ){
					fatcaStampaView.setFatcaClassificazione(classificazioneView);
				}
				fatcaStampaView.setBustaStampaAllowed(resultSet.getString("FS_IS_BUSTA_STAMPA_ALLOWED"));
				fatcaStampaView.setgIINMandatory(resultSet.getString("FS_IS_GIIN_MANDATE"));
				fatcaStampaView.setXmlTag(resultSet.getString("FS_XML_TAG"));
			}
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new FatcaStampaException(se.getMessage());
		} catch (RemoteException se) {
			log4Debug.warnStackTrace(se);
			throw new FatcaStampaException(se.getMessage());
		} catch (SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new FatcaStampaException(e.getMessage());
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return fatcaStampaView;
	}

	/**
	 * To update a particular record for table AN_MA_COMPAT_FATCA_AZ_STAMPA
	 */

	public void updateFatcaStampa(final FatcaStampaView view) throws FatcaStampaException {
		Connection connection = null;
		PreparedStatement statement = null;
		final StringBuffer query = new StringBuffer();
		query.append("UPDATE AN_MA_COMPAT_FATCA_AZ_STAMPA SET FS_IS_BUSTA_STAMPA_ALLOWED = ? ,FS_IS_GIIN_MANDATE =? ,FS_XML_TAG =? WHERE FS_FATCA_CLASS_ID = ?");
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());

			int statementCount = 1;
			statement.setString(statementCount, view.getBustaStampaAllowed());
			statement.setString(++statementCount, view.getgIINMandatory());
			statement.setString(++statementCount, view.getXmlTag());
			statement.setLong(++statementCount, Long.valueOf(view.getFatcaClassificazione().getId()));
			statement.executeUpdate();
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new FatcaStampaException(se.getMessage());
		} finally {
			cleanup(connection, statement);
		}
	}

	/**
	 * To delete a particular record from table AN_MA_COMPAT_FATCA_AZ_STAMPA
	 */

	public void deleteFatcaStampaForClassId(final Long classId)
	throws FatcaStampaException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(" DELETE FROM AN_MA_COMPAT_FATCA_AZ_STAMPA WHERE FS_FATCA_CLASS_ID = ?");
			preparedStatement.setLong(1, classId);
			preparedStatement.execute();

		}
		catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new FatcaStampaException(e.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}
	}

	/**
	 * To insert a record in table AN_MA_COMPAT_FATCA_AZ_STAMPA
	 */

	public void insertFatcaStampa(final FatcaStampaView fatcaStampaView)
	throws FatcaStampaException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(" INSERT INTO AN_MA_COMPAT_FATCA_AZ_STAMPA (FS_FATCA_CLASS_ID,FS_IS_BUSTA_STAMPA_ALLOWED,FS_IS_GIIN_MANDATE,FS_XML_TAG) VALUES (?,?,?,?)");
			preparedStatement.setLong(1, fatcaStampaView.getFatcaClassificazione().getId());
			preparedStatement.setString(2, fatcaStampaView.getBustaStampaAllowed());
			preparedStatement.setString(3, fatcaStampaView.getgIINMandatory());
			preparedStatement.setString(4, fatcaStampaView.getXmlTag());
			preparedStatement.executeUpdate();

		}
		catch (final SQLException e) {
			log4Debug.warnStackTrace(e);
			throw new FatcaStampaException(e.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}

	}

	/**
	 * To check whether record already exixts in table AN_MA_COMPAT_FATCA_AZ_STAMPA
	 */

	public Boolean isRecordExists(final Long classId) throws FatcaStampaException {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		boolean isAlreadyExist = Boolean.FALSE;
		query.append("SELECT 1 FROM AN_MA_COMPAT_FATCA_AZ_STAMPA WHERE FS_FATCA_CLASS_ID = ?");
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setLong(1, classId);
			resultSet = statement.executeQuery();
			isAlreadyExist = resultSet.next();

		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new FatcaStampaException(se.getMessage());
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return isAlreadyExist;
	}


}
