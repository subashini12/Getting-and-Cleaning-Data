package it.sella.anagrafe.dao;

import it.sella.anagrafe.util.PartitivaEsteraException;
import it.sella.anagrafe.view.PartitivaEsteraValidationView;

import java.util.List;

public interface IPartitivaEsteraDAO {
	
	/**
	 * Method to get List of Partitiva validation list by passing NAzione ID	 
	 * @param nazioneId
	 * @return
	 * @throws PartitivaEsteraException
	 */
	public List<PartitivaEsteraValidationView> getPartitivaEsteraDetails(Long nazioneId) throws PartitivaEsteraException;
	/**
	 * To insert the values into the table AN_MA_PIVA_EST_VALIDATION from the input view
	 * @param partitivaEsteraValidationView
	 * @throws PartitivaEsteraException
	 */
	public void insertPartitivaEsteraDetails(PartitivaEsteraValidationView partitivaEsteraValidationView)throws PartitivaEsteraException;
	/**
	 * To modify already existing values into the table AN_MA_PIVA_EST_VALIDATION 
	 * @param partitivaEsteraValidationView
	 * @throws PartitivaEsteraException
	 */
	public void modifyPartitivaEsteraDetails(PartitivaEsteraValidationView partitivaEsteraValidationView)throws PartitivaEsteraException;
	/**
	 * To delete already existing values into the table AN_MA_PIVA_EST_VALIDATION 
	 * @param pivaValId
	 * @throws PartitivaEsteraException
	 */
	public void deletePartitivaEsteraDetails(Long pivaValId)throws PartitivaEsteraException;
	/**
	 * To get the values of the selected primary key for modification adn deletion
	 * @param pivaValId
	 * @return
	 * @throws PartitivaEsteraException
	 */
	public PartitivaEsteraValidationView getPartitivaEsteraDetails4Id(Long pivaValId)throws PartitivaEsteraException;
	/**
	 * Method to check format of partitivaEstera 
	 * @param nazioneId
	 * @return
	 * @throws PartitivaEsteraException
	 */
	public boolean isPartitivaEsteraValid(final Long nazioneId,final String partitivaEstera ) throws PartitivaEsteraException; 
}
