package it.sella.anagrafe.dao;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AnagrafeBeanUtil {
	private static final String[] XML_BEANS = new String[] { "it/sella/anagrafe/dao/AnagrafePersistence.xml" };

	private static final AnagrafeBeanUtil BEAN_MANAGER[] = { new AnagrafeBeanUtil(XML_BEANS)  };

	private ApplicationContext applicationContext = null;
	private final String[] xmlConfigBeans;

	/**
	 * @param xmlConfigBeans
	 */
	public AnagrafeBeanUtil(final String[] xmlConfigBeans) {
		this.xmlConfigBeans = xmlConfigBeans;
	}

	/**
	 * @return
	 */
	public static AnagrafeBeanUtil getInstance() {
		return BEAN_MANAGER[0];
	}

	/**
	 * @param beanName
	 * @param objArr
	 * @return
	 */
	public Object getBean(final String beanName, final Object[] objArr) {
		return getApplicationContext().getBean(beanName, objArr);
	}

	/**
	 * @param interfaceClass
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public <InstanceType> InstanceType getBean(final Class<InstanceType> interfaceClass) {
		return (InstanceType) getBean(interfaceClass.getSimpleName());
	}

	/**
	 * @param interfaceClass
	 * @param objArr
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public <InstanceType> InstanceType getBean(final Class<InstanceType> interfaceClass, final Object[] objArr) {
		return (InstanceType) getBean(interfaceClass.getSimpleName(), objArr);
	}

	private ApplicationContext getApplicationContext() {
		if (applicationContext == null) {
			applicationContext = new ClassPathXmlApplicationContext(xmlConfigBeans);
		}
		return applicationContext;
	}

	/**
	 * Getting the bean from the application context based on the bean name
	 */
	public Object getBean(final String beanName) {
		return getApplicationContext().getBean(beanName);
	}
}
