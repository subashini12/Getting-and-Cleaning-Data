package it.sella.anagrafe.dao;

import it.sella.anagrafe.util.SoggettiPromotoreException;
import it.sella.anagrafe.view.SoggettiPromtoreView;

import java.util.Collection;

public interface ISoggettiPromotoreDAO {
	/**
	 * To insert soggetti promtore datas into the table an_tr_soggetti_fol_proct
	 * @param soggettoPromotoreView
	 * @throws SoggettiPromotoreException
	 */
	public void insertSoggettiPromotore(final SoggettiPromtoreView soggettoPromotoreView,final String operationCode) throws SoggettiPromotoreException;
	/**
     * To update soggetti promtore datas into the table an_tr_soggetti_fol_proct
     * @param soggettoPromotoreView
     * @throws SoggettiPromotoreException
     */
	public void updateSoggettiPromotore(final SoggettiPromtoreView soggettoPromotoreView,final String operationCode) throws SoggettiPromotoreException;
	/**
     * To update the storic datas into the table anse_tr_soggetti_fol_proct
     * @param soggettoPromotoreView
     * @throws SoggettiPromotoreException
     */
	public void deleteSoggettiPromotore(final Long id) throws SoggettiPromotoreException;
	/**
     * To get soggetti promtore datas from the table an_tr_soggetti_fol_proct for the input soggetto id
     * @param soggettoPromotoreView
     * @throws SoggettiPromotoreException
     */
	public Collection<SoggettiPromtoreView> getSoggettiPromotore4SoggettoId(final Long soggettoId) throws SoggettiPromotoreException;
	/**
     * To get soggetti promtore datas from the table an_tr_soggetti_fol_proct for the input id primary key)
     * @param soggettoPromotoreView
     * @throws SoggettiPromotoreException
     */
	public SoggettiPromtoreView getSoggettiPromotore(final Long id) throws SoggettiPromotoreException;
	/**
	 * To insert Soggetti Promotore Storico datas into the table an_tr_soggetti_fol_proct
	 * @param soggettoPromotoreView
	 * @param operationCode
	 * @throws SoggettiPromotoreException
	 */
	public void insertSoggettiPromotoreStorico(final SoggettiPromtoreView soggettoPromotoreView,final String operationCode) throws SoggettiPromotoreException;
	
	/**
	 * To get the soggetto id for the soggetti promtore
	 * @param id
	 * @return
	 * @throws SoggettiPromotoreException
	 */
	public Long getSoggettoId(final Long id) throws SoggettiPromotoreException;
}
