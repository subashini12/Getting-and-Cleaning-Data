package it.sella.anagrafe.dao.impl;

import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.dao.IDuplicateSoggettoDAO;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class DuplicateSoggettoDAOImpl extends JdbcDaoSupport implements IDuplicateSoggettoDAO {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DuplicateSoggettoDAOImpl.class);
	
	@SuppressWarnings({ "rawtypes" })
	public Map<String,String> maintainTerminateSoggetto(final Long soggetoIdOne,final Long soggetoIdTwo,final String terminateCollegamentoSelected) {
		final String query = "{call AN_PR_MAIN_TERMI_UNUSED_SOG(?, ?, ? ,? ,? ,? )}";
		final Map<String,String> outputMap = new HashMap<String,String>();
        getJdbcTemplate().execute(query, new CallableStatementCallback() {
            @Override
            public Map<String,String> doInCallableStatement(final CallableStatement callableStatement) {
                try {
                    callableStatement.setLong(1, soggetoIdOne);
                    callableStatement.setLong(2, soggetoIdTwo);
                    callableStatement.setLong(3, new SecurityHandler().getLoginBancaId());
                    callableStatement.setString(4, terminateCollegamentoSelected);
                    callableStatement.registerOutParameter(5, java.sql.Types.VARCHAR);
                    callableStatement.registerOutParameter(6, java.sql.Types.VARCHAR);
                    callableStatement.execute();
                    outputMap.put("operationId", callableStatement.getString(5));
                    outputMap.put("status", callableStatement.getString(6));
                } catch (final SQLException sqlException) {
                	log4Debug.debug("<<GA>> Exception while updating details ",sqlException.getMessage());
                } catch (final SubSystemHandlerException subsystemEx) {
                	log4Debug.debug("<<GA>> Exception while updating details ",subsystemEx.getMessage());
				} 
                return outputMap;
            }
        });
		return outputMap;
    }
	

}
