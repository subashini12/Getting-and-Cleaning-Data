package it.sella.anagrafe.dao.impl;

import it.sella.anagrafe.dao.IDocumentiDAO;
import it.sella.anagrafe.dbaccess.CompDocumentDBAccessHelper;
import it.sella.anagrafe.util.ConnectionHandler;
import it.sella.anagrafe.util.DocumentiException;
import it.sella.anagrafe.view.CompDocumentView;
import it.sella.anagrafe.view.DocumentiMasterView;
import it.sella.anagrafe.view.IDocumentiMasterView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;


public class DocumentiDAOImpl extends ConnectionHandler implements IDocumentiDAO {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DocumentiDAOImpl.class);

	public List<CompDocumentView> getDocument4bankAndClassificazione( final Long bankId, final Long classificazioneId)
	throws DocumentiException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		final List<CompDocumentView> compDocumentList = new ArrayList<CompDocumentView>();
		CompDocumentView compDocumentAdminView = null;
		final StringBuffer sqlQuery = new StringBuffer("SELECT CD_ID,CD_DOC_CLASS_ID,CL.CL_CAUSALE,CL.CL_DESCRIZIONE,CD_ENTE_EMISSIONE,CD_BANK_ID,CD_DOC_CLASS,CD_DOC_TIPO,CD_STORICO,CC_ITALIANO_MAN,")
		.append("CC_ITALIANO_ADD,CC_COM_MAN,CC_COM_ADD,CC_EXTRA_COM_NORES_IT_MAN,CC_EXTRA_COM_NORES_IT_ADD,CC_EXTRA_COM_RES_IT_MAN,")
		.append("CC_EXTRA_COM_RES_IT_ADD,CC_MAGGIORENNE,CC_ALLOWED_FOR_MIN_FROM_MAJ,CD_RIF_DATE,CD_APPLICABLE_NAZIONE , CC_VALID_BUFFER_DAYS FROM AN_MA_COMP_DOCUMENTI , CL_VW_CLASSIFICAZIONE CL ")
		.append("WHERE CD_BANK_ID = ? AND CL.CL_ID = CD_DOC_CLASS_ID");
		try {
			connection = getConnection();
			if ( classificazioneId != null ) {
				sqlQuery.append(" AND CD_DOC_CLASS_ID = ?");
			}
			final String sqlQueryStr = sqlQuery.toString();
			preparedStatement = connection.prepareStatement(sqlQueryStr);
			log4Debug.debug("Query" ,sqlQueryStr);
			if(bankId !=null){
				preparedStatement.setLong(1, bankId);
			}else{
				preparedStatement.setNull(1, Types.NULL);
			}
			if ( classificazioneId != null ) {
				preparedStatement.setLong(2, classificazioneId);	
			}
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				compDocumentAdminView = new CompDocumentView();
				new CompDocumentDBAccessHelper().constructCompDocumentView(resultSet, compDocumentAdminView);
				compDocumentList.add(compDocumentAdminView);
			}
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new DocumentiException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement,resultSet);
		}
		return compDocumentList;
	}

	public void deleteCompDocumentView4Id( final Long documentId) throws DocumentiException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(" DELETE FROM AN_MA_COMP_DOCUMENTI where CD_ID = ? ");
			preparedStatement.setLong(1, documentId);
			preparedStatement.execute();
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new DocumentiException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}
	}

	public void modifyDocumentDetails(final CompDocumentView compDocumentAdminView)throws DocumentiException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = getConnection();
			final StringBuffer sqlQuery = new StringBuffer("UPDATE AN_MA_COMP_DOCUMENTI SET CD_DOC_CLASS_ID =?,CD_ENTE_EMISSIONE =?,CD_BANK_ID =?,CD_DOC_CLASS =?,CD_DOC_TIPO =?,CD_STORICO =?,CC_ITALIANO_MAN =?, ")
			.append(" CC_ITALIANO_ADD =?,CC_COM_MAN =?,CC_COM_ADD =?,CC_EXTRA_COM_NORES_IT_MAN =?,CC_EXTRA_COM_NORES_IT_ADD =?,CC_EXTRA_COM_RES_IT_MAN =?, ")
			.append(" CC_EXTRA_COM_RES_IT_ADD =?,CC_MAGGIORENNE =?,CC_ALLOWED_FOR_MIN_FROM_MAJ =?,CD_RIF_DATE =?,CD_APPLICABLE_NAZIONE =? , CC_VALID_BUFFER_DAYS =? WHERE CD_ID = ? ");
			preparedStatement = connection.prepareStatement(sqlQuery.toString());
			constructComDocView(compDocumentAdminView, preparedStatement);
			preparedStatement.setLong(20, Long.valueOf(compDocumentAdminView.getId()));
			preparedStatement.executeUpdate();
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",
					sqlexception.getMessage());
			throw new DocumentiException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}
	}

	/**
	 * 
	 * @param compDocumentAdminView
	 * @param preparedStatement
	 * @throws SQLException
	 */
	private void constructComDocView(final CompDocumentView compDocumentAdminView,final PreparedStatement preparedStatement) throws SQLException {
		preparedStatement.setLong(1, compDocumentAdminView.getClassificazioneId());
		preparedStatement.setString(2, compDocumentAdminView.getEnteEmissione());
		if(compDocumentAdminView.getIdBanca() !=null){
			preparedStatement.setLong(3, compDocumentAdminView.getIdBanca());	
		}else{
			preparedStatement.setNull(3, Types.NULL);
		}
		preparedStatement.setString(4, compDocumentAdminView.getDocClass());
		preparedStatement.setString(5, compDocumentAdminView.getTipoDocument());
		preparedStatement.setLong(6, compDocumentAdminView.getStorico());
		preparedStatement.setString(7,compDocumentAdminView.getItalianoMandatory());
		preparedStatement.setString(8,compDocumentAdminView.getItalianoAdditionaly());
		preparedStatement.setString(9,compDocumentAdminView.getComunitarioMandatory());
		preparedStatement.setString(10,compDocumentAdminView.getComunitarioAdditionaly());
		preparedStatement.setString(11, compDocumentAdminView.getExtraComunitarioNoResITMandatory());
		preparedStatement.setString(12, compDocumentAdminView.getExtraComunitarioNoresITAdditionaly());
		preparedStatement.setString(13, compDocumentAdminView.getExtraComunitarioResITMandatory());
		preparedStatement.setString(14, compDocumentAdminView.getExtraComunitarioResITAdditionaly());
		preparedStatement.setString(15, compDocumentAdminView.getMaggiorenne());
		preparedStatement.setString(16, compDocumentAdminView.getAllowedForMinorFromMajor());
		preparedStatement.setDate(17, compDocumentAdminView.getRifdate());

		if(compDocumentAdminView.getApplicableNazione() !=null){
			preparedStatement.setLong(18, compDocumentAdminView.getApplicableNazione());
		}else{
			preparedStatement.setNull(18, Types.NUMERIC);
		}

		if(compDocumentAdminView.getValidBufferDays() !=null){
			preparedStatement.setLong(19, Long.valueOf(compDocumentAdminView.getValidBufferDays()));
		}else{
			preparedStatement.setNull(19, Types.NUMERIC);
		}
	}

	public void insertDocumentDetails(final CompDocumentView compDocumentAdminView)throws DocumentiException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = getConnection();
			final StringBuffer sqlQuery = new StringBuffer("INSERT INTO AN_MA_COMP_DOCUMENTI(CD_ID,CD_DOC_CLASS_ID,CD_ENTE_EMISSIONE,CD_BANK_ID,CD_DOC_CLASS,CD_DOC_TIPO,CD_STORICO,CC_ITALIANO_MAN")
			.append(",CC_ITALIANO_ADD,CC_COM_MAN,CC_COM_ADD,CC_EXTRA_COM_NORES_IT_MAN,CC_EXTRA_COM_NORES_IT_ADD,CC_EXTRA_COM_RES_IT_MAN,CC_EXTRA_COM_RES_IT_ADD,CC_MAGGIORENNE,CC_ALLOWED_FOR_MIN_FROM_MAJ,CD_RIF_DATE,CD_APPLICABLE_NAZIONE,CC_VALID_BUFFER_DAYS)")
			.append(" VALUES(AN_SQ_COMP_DOC.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			preparedStatement = connection.prepareStatement(sqlQuery.toString());
			constructComDocView(compDocumentAdminView, preparedStatement);
			preparedStatement.executeUpdate();
		}
		catch (final SQLException sqlexception) {
			//			sqlexception.printStackTrace();
			log4Debug.debug("<<GA>> Exception while getting details ",
					sqlexception.getMessage());
			throw new DocumentiException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}
	}

	public List<IDocumentiMasterView> listDocumentMaster(final Long bankId,final Boolean isValid) throws DocumentiException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		DocumentiMasterView documentMasterView = null;
		ResultSet resultSet = null;
		final List<IDocumentiMasterView> listDocumentMaster = new ArrayList<IDocumentiMasterView>();
		try {
			connection = getConnection();
			final StringBuffer sqlQuery = new StringBuffer("SELECT CD_DOC_CLASS_ID,CD_ENTE_EMISSIONE,CD_BANK_ID,CD_DOC_CLASS,CD_DOC_TIPO,CD_STORICO,CC_ITALIANO_MAN,")
			.append("CC_ITALIANO_ADD,CC_COM_MAN,CC_COM_ADD,CC_EXTRA_COM_NORES_IT_MAN,CC_EXTRA_COM_NORES_IT_ADD,CC_EXTRA_COM_RES_IT_MAN,")
			.append("CC_EXTRA_COM_RES_IT_ADD,CC_MAGGIORENNE,CC_ALLOWED_FOR_MIN_FROM_MAJ,CD_RIF_DATE,CC_VALID_BUFFER_DAYS FROM AN_MA_COMP_DOCUMENTI WHERE CD_BANK_ID = ? AND CD_STORICO = ?");
			preparedStatement = connection.prepareStatement(sqlQuery.toString());
			preparedStatement.setLong(1, bankId);
			preparedStatement.setString(2, isValid ? "0":"1");
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				documentMasterView = new DocumentiMasterView();
				documentMasterView.setDocumentClass(String.valueOf(resultSet.getLong("CD_DOC_CLASS_ID")));
				documentMasterView.setEnteEmissione(resultSet.getString("CD_ENTE_EMISSIONE"));
				documentMasterView.setBankId(resultSet.getLong("CD_BANK_ID"));
				documentMasterView.setDocumentCategory(resultSet.getString("CD_DOC_CLASS"));
				documentMasterView.setDocumentTipo(resultSet.getString("CD_DOC_TIPO"));
				documentMasterView.setValid(isValid(resultSet.getString("CD_STORICO")));
				documentMasterView.setRiffDate(resultSet.getDate("CD_RIF_DATE"));
				documentMasterView.setValidBufferDays(resultSet.getLong("CC_VALID_BUFFER_DAYS"));
				listDocumentMaster.add(documentMasterView);
			}
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",
					sqlexception.getMessage());
			//			sqlexception.printStackTrace();
			throw new DocumentiException(sqlexception.getMessage());
		}  finally {
			cleanup(connection, preparedStatement,resultSet);
		}
		return listDocumentMaster;
	}

	private boolean isValid( final String value ) {
		return (value!= null && value.equals("true") ? true : false);
	}

	public CompDocumentView getCompDocumentView4Id(final Long documentId) throws DocumentiException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		CompDocumentView compDocumentAdminView = null;
		try {
			connection = getConnection();
			final StringBuffer sqlQuery = new StringBuffer("SELECT CD_ID,CD_DOC_CLASS_ID,CL.CL_CAUSALE,CL.CL_DESCRIZIONE,CD_ENTE_EMISSIONE,CD_BANK_ID,CD_DOC_CLASS,CD_DOC_TIPO,CD_STORICO,CC_ITALIANO_MAN,")
			.append("CC_ITALIANO_ADD,CC_COM_MAN,CC_COM_ADD,CC_EXTRA_COM_NORES_IT_MAN,CC_EXTRA_COM_NORES_IT_ADD,CC_EXTRA_COM_RES_IT_MAN,")
			.append("CC_EXTRA_COM_RES_IT_ADD,CC_MAGGIORENNE,CC_ALLOWED_FOR_MIN_FROM_MAJ,CD_RIF_DATE,CD_APPLICABLE_NAZIONE,CC_VALID_BUFFER_DAYS FROM AN_MA_COMP_DOCUMENTI ,CL_VW_CLASSIFICAZIONE CL WHERE CD_ID = ? AND CL.CL_ID = CD_DOC_CLASS_ID");
			preparedStatement = connection.prepareStatement(sqlQuery.toString());
			preparedStatement.setLong(1, documentId);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				compDocumentAdminView = new CompDocumentView();
				new CompDocumentDBAccessHelper().constructCompDocumentView(resultSet, compDocumentAdminView);

			}
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new DocumentiException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement,resultSet);
		}
		return compDocumentAdminView;
	}

	
}


