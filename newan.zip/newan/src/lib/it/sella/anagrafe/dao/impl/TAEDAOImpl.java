package it.sella.anagrafe.dao.impl;

import it.sella.anagrafe.dao.ITAEDAO;
import it.sella.anagrafe.util.ConnectionHandler;
import it.sella.anagrafe.util.TAEException;
import it.sella.anagrafe.view.TAEAdminView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TAEDAOImpl extends ConnectionHandler implements ITAEDAO{
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(TAEDAOImpl.class);


	 /**
     * The method returns TAE details based on TAE Code
     * @param taeCode
     * @return TAEAdminView
     * @throws TAEException
     */
	
	public TAEAdminView getTAEDetails4taeCode(final String taeCode) throws TAEException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		TAEAdminView taeAdminView = null;
		
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("SELECT TA.TA_ID,TA.TA_CODE,TA.TA_DESCRIPTION FROM AN_MA_TAE TA WHERE TA.TA_CODE = ?");
			preparedStatement.setString(1, taeCode);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				taeAdminView = new TAEAdminView();
				taeAdminView.setTaeId(resultSet.getLong("TA_ID"));
				taeAdminView.setTaeCode(resultSet.getString("TA_CODE"));
				taeAdminView.setTaeDescription(resultSet.getString("TA_DESCRIPTION"));
			}						
		}catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new TAEException(sqlexception.getMessage());
		}
		finally {
			cleanup(connection, preparedStatement,resultSet);
		}
		return taeAdminView;
	}

	/**
	 * To insert new TAE values into the table AN_MA_TAE
	 * @param TAEAdminView
	 * @throws TAEException
	 */
	public void insertTAE(final TAEAdminView taeAdminView) throws TAEException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("INSERT INTO AN_MA_TAE (TA_ID,TA_CODE,TA_DESCRIPTION) VALUES (AN_SQ_TA.NEXTVAL,?,?)");
			preparedStatement.setString(1, taeAdminView.getTaeCode());
			preparedStatement.setString(2, taeAdminView.getTaeDescription());
			final int rowNum = preparedStatement.executeUpdate();
			
			if(rowNum == 0){
				throw new TAEException("Zero Rows Inserted.");
			}
			
		}catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while Inserting details ",sqlexception.getMessage());
			throw new TAEException(sqlexception.getMessage());
		} 
		finally {
			cleanup(connection, preparedStatement);
		}
	}

	/**
	 * To modify the TAE values from the table AN_MA_TAE
	 * @param TAEAdminView
	 * @throws TAEException
	 */
	
	public void modifyTAEDetails(final TAEAdminView taeAdminView) throws TAEException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("UPDATE AN_MA_TAE SET TA_DESCRIPTION = ?, TA_CODE = ?  WHERE TA_ID = ?");
			preparedStatement.setString(1, taeAdminView.getTaeDescription());
			preparedStatement.setString(2, taeAdminView.getTaeCode());
			preparedStatement.setLong(3, taeAdminView.getTaeId());
			final int rowNum = preparedStatement.executeUpdate();
			if(rowNum == 0){
				throw new TAEException("Zero Rows Updated");
			}
			
		}catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while Updating details ",sqlexception.getMessage());
			throw new TAEException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}		
	}

	 /**
     * The method returns TAE is exist in AN_MA_TAE table
     * @param taeCode
     * @return boolean
     * @throws TAEException
     */
	public boolean isTAEAlreadyExist(final String taeCode) throws TAEException {
		 Connection connection = null;
	     PreparedStatement preparedStatement = null;
	     ResultSet resultSet = null;
	     boolean isAlreadyExist = false;
	     try {
	            connection = getConnection();
	            preparedStatement = connection.prepareStatement(" SELECT TA.TA_ID,TA.TA_CODE,TA.TA_DESCRIPTION FROM AN_MA_TAE TA WHERE TA.TA_CODE = ? ");
	            preparedStatement.setString(1, taeCode);
	            resultSet = preparedStatement.executeQuery();
	            isAlreadyExist = resultSet.next();
	     }catch (final SQLException sqlexception) {
				log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
				throw new TAEException(sqlexception.getMessage());
		 } 
	     finally {
				cleanup(connection, preparedStatement,resultSet);
		 }
	     return isAlreadyExist;
	}
	
	public void deleteTAEDetails(final Long taeID) throws TAEException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(" DELETE FROM AN_MA_TAE WHERE TA_ID = ?");
			preparedStatement.setLong(1, taeID);
			preparedStatement.execute();
			
			if(preparedStatement.getUpdateCount() == 0){
				throw new TAEException("Zero Rows Deleted.");
			}
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while Deleteing TAE details ",
					sqlexception.getMessage());
			throw new TAEException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}
	}
	
	public boolean isTAEMappedToCompProfessione(final Long taeID) throws TAEException{
		
		 Connection connection = null;
	     PreparedStatement preparedStatement = null;
	     ResultSet resultSet = null;
	     boolean isTAEMapped = false;
	     try {
	            connection = getConnection();
	            preparedStatement = connection.prepareStatement(" SELECT CT_ID FROM AN_MA_COMP_PROFESSIONE_TAE PT WHERE PT.CT_TAE_ID = ? ");
	            preparedStatement.setLong(1, taeID);
	            resultSet = preparedStatement.executeQuery();
	            isTAEMapped = resultSet.next();
	     }catch (final SQLException sqlexception) {
				log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
				throw new TAEException(sqlexception.getMessage());
		 } 
	     finally {
				cleanup(connection, preparedStatement,resultSet);
		 }
	     return isTAEMapped;
	}
}
