package it.sella.anagrafe.dao.impl;

import it.sella.anagrafe.dao.IMapperDAO;
import it.sella.anagrafe.dbaccess.DBAccessHelper;
import it.sella.anagrafe.util.MapperHelperException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class MapperDAOImpl extends DBAccessHelper implements IMapperDAO {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(MapperDAOImpl.class);

	public Map<Long, String> getAllBanks() throws MapperHelperException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		final Map<Long, String> bankDetailsMap = new HashMap<Long,String>();
		try {
			connection = getConnection();
			preparedStatement = connection
					.prepareStatement("select ATS.AT_SOGGETTO_ID, ATS.AT_DENOMINAZIONE,MC.MC_CLASS_NAME from AN_TR_ALTRITIPOSOGGETTO ATS, AN_MA_MAPPER_CLASS MC where ATS.AT_SOGGETTO_ID = MC.MC_BANK_ID order by MC.MC_BANK_ID");
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				bankDetailsMap.put(resultSet.getLong("AT_SOGGETTO_ID"),
						resultSet.getString("AT_DENOMINAZIONE")+"#"+resultSet.getString("MC_CLASS_NAME"));
			}
			log4Debug.debug("Query executed and Result set is ",bankDetailsMap.size());
			return bankDetailsMap;
		} catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting the citta ",
					sqlexception.getMessage());
			throw new MapperHelperException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement, resultSet);
		}
	}

	public void updateMapperByBank(final String[] mapperClassName)
			throws MapperHelperException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String[] classnameWithBankDescObj = null;
		try {
			connection = getConnection();
			preparedStatement = connection
			.prepareStatement("update AN_MA_MAPPER_CLASS MC set MC.MC_CLASS_NAME = ? where MC.MC_BANK_ID = ?");
			for (final String mapperClassNameWithBankId : mapperClassName) {
			classnameWithBankDescObj = mapperClassNameWithBankId.split(",");
			preparedStatement.setString(1, classnameWithBankDescObj[1]);
			preparedStatement.setLong(2, Long.valueOf(classnameWithBankDescObj[0]));
			preparedStatement.executeUpdate();
			}
		} catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting the citta ",
					sqlexception.getMessage());
			throw new MapperHelperException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}

	}

}
