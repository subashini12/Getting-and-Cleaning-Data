package it.sella.anagrafe.dao.impl;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.dbaccess.DBAccessHelper;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * This DAO class is used to retrieve Causale list from DB.
 * @author gbs03109
 *
 */
public class FATCACommonDBAccessHelper extends DBAccessHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(FATCACommonDBAccessHelper.class);


	/**
	 * Method to return all Fatca Classification for Tipo Azeinda
	 * @return
	 * @throws GestoreAnagrafeException
	 */

	public List<ClassificazioneView> getAllFatcaAziendaClassificaztion()
	throws GestoreAnagrafeException {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final List<ClassificazioneView> list = new ArrayList<ClassificazioneView>();
		final StringBuffer query = new StringBuffer();
		query.append("SELECT ST.FT_CLASS_ID FROM AN_MA_COMP_FATCA_STATUS_TIPO ST  WHERE FT_TIPO_SOGGETTO = 'AZIENDE'");
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				final ClassificazioneView classificazioneView = setCompFATCAAZ(resultSet,"FT_CLASS_ID");
				list.add(classificazioneView);
			}
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} catch (RemoteException e) {
			log4Debug.warnStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} catch (SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return list;
	}

	/**
	 * To get classificazione view by passsing FT_CLASS_ID
	 * @param resultSet
	 * @return
	 * @throws SQLException
	 * @throws RemoteException
	 * @throws SubSystemHandlerException
	 */
	private ClassificazioneView setCompFATCAAZ(final ResultSet resultSet,final String value) throws  RemoteException, SubSystemHandlerException, SQLException {
		ClassificazioneView classificazioneView = null;
		if(resultSet.getString(value) !=null){
			classificazioneView = ClassificazioneHandler.getClassificazioneView(Long.valueOf(resultSet.getString(value)));
		}
		return classificazioneView;
	}

}
