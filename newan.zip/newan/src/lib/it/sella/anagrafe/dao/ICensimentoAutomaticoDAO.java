package it.sella.anagrafe.dao;

//import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.anagrafe.implementation.ElencoAziendaView;
import it.sella.anagrafe.implementation.ElencoPersoneFisicheView;
import it.sella.anagrafe.implementation.ElencoPlurintestazioniView;
import it.sella.anagrafe.util.SoggettiPromotoreException;

import java.util.Collection;
import java.util.List;

public interface ICensimentoAutomaticoDAO {


	/**
	 * Method to list all PF details by passing Rif data as argument
	 * @param rifDate
	 * @return List of ElencoPersoneFisicheView
	 * @throws SoggettiPromotoreException
	 */
	public List<ElencoPersoneFisicheView> listPersonaFisicaDetails(String rifDate) throws SoggettiPromotoreException;

	/**
	 * Method to list all Azienda details by passing Rif data as argument
	 * @param rifDate
	 * @return List of ElencoAziendaView
	 * @throws SoggettiPromotoreException
	 */
	public List<ElencoAziendaView> listAziendaDetails(String rifDate) throws SoggettiPromotoreException;


	/**
	 * Method to list all Plurintestazione details by passing Rif data as argument
	 * @param rifDate
	 * @return List of ElencoPlurintestazioniView
	 * @throws SoggettiPromotoreException
	 */
	public List<ElencoPlurintestazioniView> listPlurintestazioniDetails(String rifDate) throws SoggettiPromotoreException;

	/**
	 * Method to get the collection of XML that is required for Automatic Censimento
	 * @param soggettoPromotoreId
	 * @return Collection of Soggetti XML
	 * @throws SoggettiPromotoreException
	 */
	public Collection<String> listSoggettiXMLForCensimento(final Long soggettoPromotoreId) throws SoggettiPromotoreException;

	/**
	 * Method to update Status of automatic censimento
	 * @param soggettoPromotoreId
	 * @param error
	 * @param stato
	 * @param rifDate
	 * @param opId
	 * @throws SoggettiPromotoreException
	 */
	public void updateAutoCensitoStatus(final Long soggettoPromotoreId,final String error, final String stato,final String rifDate,final Long opId) throws SoggettiPromotoreException;

}
