package it.sella.anagrafe.dao.impl;

import it.sella.anagrafe.common.TAE;
import it.sella.anagrafe.dao.ICompProfTAEDAO;
import it.sella.anagrafe.util.CompProfTAEException;
import it.sella.anagrafe.util.ConnectionHandler;
import it.sella.anagrafe.view.CompProfTAEAdminView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CompProfTAEDAOImpl extends ConnectionHandler implements ICompProfTAEDAO {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CompProfTAEDAOImpl.class);

	public List<CompProfTAEAdminView> getCompProfTAE4ProfId (final Long profClassficazioneId,final Long bankId) throws CompProfTAEException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		final List<CompProfTAEAdminView> compProfTAE = new ArrayList<CompProfTAEAdminView>();
		try {
			connection = getConnection();
			final StringBuffer queryBuffer = new StringBuffer();
			queryBuffer.append( "select ta.ta_id,ta.ta_description,ta.ta_code,cp_id from an_ma_comp_professione cp ,an_ma_tae ta ,an_ma_comp_professione_tae cpt where cp.cp_id = cpt.ct_prof_comp_id " )
			.append( "and ta.ta_id = cpt.ct_tae_id and cp.cp_prof_class_id = ? and cp.cp_bank_id = ? " );
			preparedStatement = connection.prepareStatement(queryBuffer.toString());
			preparedStatement.setLong(1, profClassficazioneId);
			preparedStatement.setLong(2, bankId);
			resultSet = preparedStatement.executeQuery();
			CompProfTAEAdminView compProfTAEAdminView = null;
			TAE taeView = null;
			while (resultSet.next()) {
				compProfTAEAdminView = new CompProfTAEAdminView();
				taeView = new TAE();
				taeView.setTaeId(resultSet.getLong("ta_id"));
				taeView.setTaeDesc(resultSet.getString("ta_description"));
				taeView.setTaeCode(resultSet.getString("ta_code"));
				compProfTAEAdminView.setProfCompClassificazione(resultSet.getLong("cp_id"));
				compProfTAEAdminView.setTae(taeView);
				compProfTAE.add(compProfTAEAdminView);
			}
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new CompProfTAEException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement,resultSet);
		}
		return compProfTAE;
	}

	public void createCompProfTAE4ProfId(final List<CompProfTAEAdminView> compProfTAEAdminViewList) throws CompProfTAEException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		final ResultSet resultSet = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("INSERT INTO an_ma_comp_professione_tae VALUES (AN_SQ_PROFES_TAE.NEXTVAL,?,?)");
			for (final CompProfTAEAdminView compProfTAEAdminView : compProfTAEAdminViewList) {
				log4Debug.debug("Professione Id.........." ,compProfTAEAdminView.getProfCompClassificazione());
				preparedStatement.setLong(1, compProfTAEAdminView.getProfCompClassificazione());
				log4Debug.debug("New Added TAE.........." ,compProfTAEAdminView.getTae().getTaeId());
				preparedStatement.setLong(2, compProfTAEAdminView.getTae().getTaeId());
				preparedStatement.addBatch();
			}
			final int i[] =preparedStatement.executeBatch();
			log4Debug.debug("Added..........",i.length);
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new CompProfTAEException(se.getMessage());
		} finally {
			cleanup(connection, preparedStatement, resultSet);
		}
	}

	public void deleteCompProfTAE4ProfId(final List<CompProfTAEAdminView> compProfTAEAdminViewList) throws CompProfTAEException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		final ResultSet resultSet = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("DELETE FROM an_ma_comp_professione_tae TAE where tae.ct_prof_comp_id = ? and tae.ct_tae_id = ?");
			for (final CompProfTAEAdminView compProfTAEAdminView : compProfTAEAdminViewList) {
				log4Debug.debug("ProfCompClassificazione Id for Delete.........." ,compProfTAEAdminView.getProfCompClassificazione());
				log4Debug.debug("TAE Id for Delete.........." ,compProfTAEAdminView.getTae().getTaeId());
				preparedStatement.setLong(1, compProfTAEAdminView.getProfCompClassificazione());
				preparedStatement.setLong(2, compProfTAEAdminView.getTae().getTaeId());
				preparedStatement.addBatch();
			}
			preparedStatement.executeBatch();
		} catch (final SQLException se) {
			log4Debug.warnStackTrace(se);
			throw new CompProfTAEException(se.getMessage());
		} finally {
			cleanup(connection, preparedStatement, resultSet);
		}
	}

	public List<CompProfTAEAdminView> getNonExitingTAE4Professione(final Long profClassficazioneId,final Long bankId) throws CompProfTAEException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		final List<CompProfTAEAdminView> compProfTAE = new ArrayList<CompProfTAEAdminView>();
		try {
			connection = getConnection();
			final StringBuffer queryBuffer = new StringBuffer();
			queryBuffer.append( "select tae.ta_id,tae.ta_code,tae.ta_description from an_ma_tae tae where tae.ta_id not in ( select ta.ct_tae_id from an_ma_comp_professione_tae ta ,an_ma_comp_professione cp where ta.ct_prof_comp_id = cp.cp_id " )
			.append( "and cp.cp_prof_class_id =? and cp.cp_bank_id =? )");
			preparedStatement = connection.prepareStatement(queryBuffer.toString());
			preparedStatement.setLong(1, profClassficazioneId);
			preparedStatement.setLong(2, bankId);
			resultSet = preparedStatement.executeQuery();
			CompProfTAEAdminView compProfTAEAdminView = null;
			TAE taeView = null;
			while (resultSet.next()) {
				compProfTAEAdminView = new CompProfTAEAdminView();
				taeView = new TAE();
				taeView.setTaeId(resultSet.getLong("ta_id"));
				taeView.setTaeDesc(resultSet.getString("ta_description"));
				taeView.setTaeCode(resultSet.getString("ta_code"));
				compProfTAEAdminView.setTae(taeView);
				compProfTAE.add(compProfTAEAdminView);
			}
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new CompProfTAEException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement,resultSet);
		}
		return compProfTAE;
	}

	public Long getProfessioneId (final Long profClassficazioneId,final Long bankId) throws CompProfTAEException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Long professioneId = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("select cp.cp_id from an_ma_comp_professione cp where cp.cp_prof_class_id=? and cp.cp_bank_id=?");
			preparedStatement.setLong(1, profClassficazioneId);
			preparedStatement.setLong(2, bankId);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				professioneId = resultSet.getLong("cp_id");
			}
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new CompProfTAEException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement,resultSet);
		}
		return professioneId;
	}
}
