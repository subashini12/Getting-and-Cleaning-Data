package it.sella.anagrafe.dao;

import it.sella.anagrafe.implementation.PortafogliazioneClientelaView;
import it.sella.anagrafe.util.PortafogliazioneClientelaException;

import java.util.List;

public interface IPortafogliazioneClientelaCompDAO {

	public List<PortafogliazioneClientelaView> getPortafogliazioneClientelaList() throws PortafogliazioneClientelaException ;

	public void updatePortafogliazioneClientela(PortafogliazioneClientelaView view)	throws PortafogliazioneClientelaException;
	
	public String getPortafogliazioneClientelaAllowed(final Long bankId) throws PortafogliazioneClientelaException ;


}
