package it.sella.anagrafe.dao;

import java.util.Map;

public interface IDuplicateSoggettoDAO {
	public Map<String,String> maintainTerminateSoggetto(final Long soggetoIdOne ,final Long soggetoIdTwo,final String terminateCollegamentoSelected );
}
