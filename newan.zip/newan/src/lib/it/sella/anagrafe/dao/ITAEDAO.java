package it.sella.anagrafe.dao;

import it.sella.anagrafe.util.TAEException;
import it.sella.anagrafe.view.TAEAdminView;

public interface ITAEDAO {
	
	
	/**The method returns TAE details based on TAE Code
	 * @param taeCode
	 * @return List
	 * @throws TAEException
	 */
	
	public TAEAdminView getTAEDetails4taeCode (final String taeCode) throws TAEException;
	
	/**
	 * To insert new TAE values into the table AN_MA_TAE.
	 * @param taeAdminView
	 * @throws TAEException
	 */
	public void insertTAE(final TAEAdminView taeAdminView) throws TAEException;
	
	/**
	 * To modify the TAE values from the table AN_MA_TAE.
	 * @param taeAdminView
	 * @throws TAEException
	 */
	public void modifyTAEDetails(final TAEAdminView taeAdminView) throws TAEException;
	
	/**
	 * This method added to check whether the entered TAE Code already exist.
	 * @param taeCode
	 * @return boolean
	 * @throws TAEException
	 */
	public boolean isTAEAlreadyExist(final String taeCode) throws TAEException;
	
	/**
	 * To Delete the TAE values from the table AN_MA_TAE.
	 * @param taeID
	 * @throws TAEException
	 */	
	public void deleteTAEDetails(final Long taeID) throws TAEException;
	
	/**
	 * This method added to check whether the entered TAE Code is already mapped to com professione
	 * @param taeCode
	 * @return boolean
	 * @throws TAEException
	 */
	
	public boolean isTAEMappedToCompProfessione(final Long taeID) throws TAEException;
	
}
