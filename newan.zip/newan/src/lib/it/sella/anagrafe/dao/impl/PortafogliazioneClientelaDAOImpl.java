package it.sella.anagrafe.dao.impl;

import it.sella.anagrafe.dao.IPortafogliazioneClientelaCompDAO;
import it.sella.anagrafe.dbaccess.DBAccessHelper;
import it.sella.anagrafe.implementation.PortafogliazioneClientelaView;
import it.sella.anagrafe.util.PortafogliazioneClientelaException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PortafogliazioneClientelaDAOImpl extends DBAccessHelper implements IPortafogliazioneClientelaCompDAO {

	final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(PortafogliazioneClientelaDAOImpl.class);
/**
 * To get list of PortafogliazioneClientela
 */
	public List<PortafogliazioneClientelaView> getPortafogliazioneClientelaList() throws PortafogliazioneClientelaException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		PortafogliazioneClientelaView view = null;
		
		final List<PortafogliazioneClientelaView> adminViewList = new ArrayList<PortafogliazioneClientelaView>();
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("SELECT  PC_BANCA_ID, PC_PORTFO_ALLOWED FROM AN_MA_PORTAFO_CLIENTELA_CHECK ");
			resultSet=preparedStatement.executeQuery();
			while ( resultSet.next() ) {
				view = new PortafogliazioneClientelaView  () ;
				view.setBankId(Long.valueOf(resultSet.getLong("PC_BANCA_ID")));
				view.setPortfoAllowed(resultSet.getString("PC_PORTFO_ALLOWED"));
				adminViewList.add(view);
			}
		} catch (final SQLException e) {
			log4Debug.debug(" Exception while getting the bank Id ", e.getMessage());
			throw new PortafogliazioneClientelaException(e.getMessage());
		}finally {
			cleanup(connection, preparedStatement, resultSet);
		}
		return adminViewList;
	}
/**
 * To update PortafogliazioneClientela
 */
	public void updatePortafogliazioneClientela(final PortafogliazioneClientelaView view) throws PortafogliazioneClientelaException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
				connection = getConnection();
				
				preparedStatement = connection.prepareStatement("UPDATE AN_MA_PORTAFO_CLIENTELA_CHECK SET PC_PORTFO_ALLOWED = ? WHERE PC_BANCA_ID = ?");
				preparedStatement.setString(1, view.getPortfoAllowed());
				 if (view.getBankId() != null) {
					preparedStatement.setLong(2, Long.valueOf(view.getBankId()));
				}
				preparedStatement.executeUpdate();
			} catch (final SQLException e) {
				log4Debug.debug(" Exception while Updating with bank Id ", e.getMessage());
				throw new PortafogliazioneClientelaException(e.getMessage());
			}finally {
				cleanup(connection, preparedStatement);
			}
			
		
	}

	  /**
     * The method is used to get whether PortafogliazioneClientela is allowed for the bank or not
     * @param bankId
     * @return
     * @throws DatiPrivacyDiscriminatorException
     */
    public String getPortafogliazioneClientelaAllowed(final Long bankId) throws PortafogliazioneClientelaException {
    	Connection connection = null;
    	PreparedStatement preparedStatement = null;
    	ResultSet resultSet = null;
    	String isPortFolioAllowed = "";
    	try {
    		connection = getConnection();
    		preparedStatement = connection.prepareStatement("SELECT  PC_PORTFO_ALLOWED FROM AN_MA_PORTAFO_CLIENTELA_CHECK WHERE PC_BANCA_ID = ?");
    		preparedStatement.setLong(1, bankId.longValue());
    		resultSet=preparedStatement.executeQuery();
    		if(resultSet.next()) {
    			isPortFolioAllowed = resultSet.getString("PC_PORTFO_ALLOWED");
    		}
    	} catch (final SQLException e) {
    		log4Debug.debug(" Exception while getting the bank Id ", e.getMessage());
    		throw new PortafogliazioneClientelaException(e.getMessage());
    	}finally {
    		cleanup(connection, preparedStatement, resultSet);
    	}
    	return isPortFolioAllowed;
    }

}
