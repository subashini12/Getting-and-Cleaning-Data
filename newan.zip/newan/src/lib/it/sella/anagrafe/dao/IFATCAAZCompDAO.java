package it.sella.anagrafe.dao;

import it.sella.anagrafe.util.FATCAAZCompException;
import it.sella.anagrafe.view.FATCAAZAdminView;

import java.util.Collection;
import java.util.List;

/**
 * Interface for AN_MA_COMPAT_FATCA_AZ
 * @author gbs03109
 *
 */
public interface IFATCAAZCompDAO {

	public List<FATCAAZAdminView> getDetailsForClassId(final Long id) throws FATCAAZCompException;

	public void updateForComId(final FATCAAZAdminView adminView )throws FATCAAZCompException;

	public void deleteRecordForCompId(final Long Id) throws FATCAAZCompException;

	public void insertFatcaStampa(FATCAAZAdminView view)throws FATCAAZCompException;

	public Collection<FATCAAZAdminView> getAllDetails()throws FATCAAZCompException;

	public FATCAAZAdminView getDetailsForCompId(final Long compId)throws FATCAAZCompException ;

}
