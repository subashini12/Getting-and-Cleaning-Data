package it.sella.anagrafe.dao.impl;

import it.sella.anagrafe.dao.IPartitivaEsteraDAO;
import it.sella.anagrafe.util.ConnectionHandler;
import it.sella.anagrafe.util.PartitivaEsteraException;
import it.sella.anagrafe.view.PartitivaEsteraValidationView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PartitivaEsteraDAOImpl extends ConnectionHandler implements IPartitivaEsteraDAO{

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(PartitivaEsteraDAOImpl.class);
	
	/* (non-Javadoc)
	 * @see it.sella.anagrafe.dao.IPartitivaEsteraDAO#getPartitivaEsteraDetails(java.lang.Long)
	 */
	public List<PartitivaEsteraValidationView> getPartitivaEsteraDetails(final Long nazioneId)throws PartitivaEsteraException{
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		PartitivaEsteraValidationView patitaivaEsteraValidationView = null;
		List<PartitivaEsteraValidationView> list=null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("select ATS.PIVA_NAZIONE_ID,ATS.PIVA_VAL_ID, ATS.PIVA_EST_LENGTH,ATS.PIVA_FORMAT,ATS.PIVA_REG_PAATERN,ATS.PIVA_DESCRIPTION  from AN_MA_PIVA_EST_VALIDATION ATS where PIVA_NAZIONE_ID = ?");
			preparedStatement.setLong(1, nazioneId);
			resultSet = preparedStatement.executeQuery();
			list = new ArrayList<PartitivaEsteraValidationView>(); 
			while (resultSet.next()) {
				patitaivaEsteraValidationView = new PartitivaEsteraValidationView();
				patitaivaEsteraValidationView.setPiva_nazione_id(getLongObjectFromPrimitive(resultSet.getString("PIVA_NAZIONE_ID")));
				patitaivaEsteraValidationView.setPiva_Description(resultSet.getString("PIVA_DESCRIPTION"));
				patitaivaEsteraValidationView.setPiva_est_length(getLongObjectFromPrimitive(resultSet.getString("PIVA_EST_LENGTH")));
				patitaivaEsteraValidationView.setPiva_val_id(getLongObjectFromPrimitive(resultSet.getString("PIVA_VAL_ID")));
				patitaivaEsteraValidationView.setPiva_format(resultSet.getString("PIVA_FORMAT"));
				patitaivaEsteraValidationView.setPiva_reg_pattern(resultSet.getString("PIVA_REG_PAATERN"));
				list.add(patitaivaEsteraValidationView);
			}
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",
					sqlexception.getMessage());
			throw new PartitivaEsteraException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement,resultSet);
		}
		return list;
	}
	
	protected Long getLongObjectFromPrimitive(final String value) {
    	return value != null ? Long.valueOf(value) : null;
    }
	/*
	 * To insert values into the table AN_MA_PIVA_EST_VALIDATION
	 * @see it.sella.anagrafe.dao.IPartitivaEsteraDAO#insertPartitivaEsteraDetails(it.sella.anagrafe.view.PartitivaEsteraValidationView)
	 */
	public void insertPartitivaEsteraDetails(final PartitivaEsteraValidationView partitivaEsteraValidationView)throws PartitivaEsteraException{

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("INSERT INTO AN_MA_PIVA_EST_VALIDATION (PIVA_VAL_ID,PIVA_NAZIONE_ID,PIVA_EST_LENGTH,PIVA_FORMAT,PIVA_REG_PAATERN,PIVA_DESCRIPTION) VALUES (AN_SQ_PIVA_EST_VAL.NEXTVAL,?,?,?,?,?)");
			preparedStatement.setLong(1, partitivaEsteraValidationView.getPiva_nazione_id());
			if ( partitivaEsteraValidationView.getPiva_est_length()!= null ) {
			preparedStatement.setLong(2, partitivaEsteraValidationView.getPiva_est_length());
			} else {
				preparedStatement.setNull(2, java.sql.Types.INTEGER);
			}
			preparedStatement.setString(3, partitivaEsteraValidationView.getPiva_format());
			preparedStatement.setString(4, partitivaEsteraValidationView.getPiva_reg_pattern());
			preparedStatement.setString(5, partitivaEsteraValidationView.getPiva_Description());

			preparedStatement.executeUpdate();
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",
					sqlexception.getMessage());
			throw new PartitivaEsteraException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}
	}
	
	/*
	 * To modify the already existing values of the selected PIVA_VAL_ID
	 * @see it.sella.anagrafe.dao.IPartitivaEsteraDAO#modifyPartitivaEsteraDetails(it.sella.anagrafe.view.PartitivaEsteraValidationView)
	 */
	public void modifyPartitivaEsteraDetails(final PartitivaEsteraValidationView partitivaEsteraValidationView)throws PartitivaEsteraException{

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("UPDATE AN_MA_PIVA_EST_VALIDATION SET PIVA_EST_LENGTH = ?, PIVA_FORMAT = ?, PIVA_REG_PAATERN= ?, PIVA_DESCRIPTION = ? WHERE PIVA_VAL_ID = ? AND PIVA_NAZIONE_ID = ? ");
			if ( partitivaEsteraValidationView.getPiva_est_length()!= null ) {
			preparedStatement.setLong(1, partitivaEsteraValidationView.getPiva_est_length());
			} else {
			  preparedStatement.setNull(1, java.sql.Types.INTEGER);
			}
			preparedStatement.setString(2, partitivaEsteraValidationView.getPiva_format());
			preparedStatement.setString(3, partitivaEsteraValidationView.getPiva_reg_pattern());
			preparedStatement.setString(4, partitivaEsteraValidationView.getPiva_Description());
			preparedStatement.setLong(5, partitivaEsteraValidationView.getPiva_val_id());
			preparedStatement.setLong(6, partitivaEsteraValidationView.getPiva_nazione_id());
			preparedStatement.executeUpdate();
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",
					sqlexception.getMessage());
			throw new PartitivaEsteraException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}
	}
	
	/*
	 * to delete the existing values from the table for the selected PIVA_VAL_ID
	 * @see it.sella.anagrafe.dao.IPartitivaEsteraDAO#deletePartitivaEsteraDetails(java.lang.Long)
	 */
	public void deletePartitivaEsteraDetails(final Long pivaValId)throws PartitivaEsteraException{

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("DELETE FROM AN_MA_PIVA_EST_VALIDATION WHERE PIVA_VAL_ID = ?");
			preparedStatement.setLong(1, pivaValId);
			preparedStatement.execute();
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",
					sqlexception.getMessage());
			throw new PartitivaEsteraException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}
	}

/*
 * To get the values for the selected PIVA_VAL_ID for deletion and modification
 * @see it.sella.anagrafe.dao.IPartitivaEsteraDAO#getPartitivaEsteraDetails4Id(java.lang.Long)
 */
public PartitivaEsteraValidationView getPartitivaEsteraDetails4Id(final Long pivaValId)throws PartitivaEsteraException{
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		PartitivaEsteraValidationView patitaivaEsteraValidationView = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("SELECT ATS.PIVA_NAZIONE_ID, ATS.PIVA_EST_LENGTH,ATS.PIVA_FORMAT,ATS.PIVA_REG_PAATERN,ATS.PIVA_DESCRIPTION  FROM AN_MA_PIVA_EST_VALIDATION ATS WHERE PIVA_VAL_ID = ? ");
			preparedStatement.setLong(1, pivaValId);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				patitaivaEsteraValidationView = new PartitivaEsteraValidationView();
				patitaivaEsteraValidationView.setPiva_val_id(pivaValId);
				patitaivaEsteraValidationView.setPiva_nazione_id(getLongObjectFromPrimitive(resultSet.getString("PIVA_NAZIONE_ID")));
				patitaivaEsteraValidationView.setPiva_Description(resultSet.getString("PIVA_DESCRIPTION"));
				patitaivaEsteraValidationView.setPiva_est_length(getLongObjectFromPrimitive(resultSet.getString("PIVA_EST_LENGTH")));
				patitaivaEsteraValidationView.setPiva_format(resultSet.getString("PIVA_FORMAT"));
				patitaivaEsteraValidationView.setPiva_reg_pattern(resultSet.getString("PIVA_REG_PAATERN"));
			}
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",
					sqlexception.getMessage());
			throw new PartitivaEsteraException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement,resultSet);
		}
		return patitaivaEsteraValidationView;
	}

	public boolean isPartitivaEsteraValid(final Long nazioneId, final String partitivaEstera)
	throws PartitivaEsteraException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("SELECT 1  FROM AN_MA_PIVA_EST_VALIDATION PI WHERE PI.PIVA_NAZIONE_ID = ? AND REGEXP_LIKE(?, PI.PIVA_REG_PAATERN)");
			preparedStatement.setLong(1, nazioneId);
			preparedStatement.setString(2, partitivaEstera);
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next()) {
				return true;
			}
		}
		catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new PartitivaEsteraException(sqlexception.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}
		return false;
	}
}




