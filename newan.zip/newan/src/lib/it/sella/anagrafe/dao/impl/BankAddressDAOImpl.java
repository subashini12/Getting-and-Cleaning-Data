package it.sella.anagrafe.dao.impl;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.dao.IBankAddressDAO;
import it.sella.anagrafe.dbaccess.BankAddressDBAccess;

import java.util.Collection;

/**
 * DAO Implementation class for Bank Address Names
 *
 */
public class BankAddressDAOImpl implements IBankAddressDAO {

	public Collection<String> getListOfBankAddressNames() throws  GestoreAnagrafeException {
		return new BankAddressDBAccess().getListOfBankAddressNames();
	}

}
