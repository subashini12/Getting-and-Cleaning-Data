package it.sella.anagrafe;

import it.sella.anagrafe.util.UtilHelper;

/**
 * @author GBS03447
 * 
 */
public class DAIRegoleDetailsView implements IDAIRegoleDetailsView {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;
	private Long soggettoId;
	private IDAIPesoView daiPeso; // pesso Id mapped to Table
	private IDAIWeightageView daiCodeId; // Weightage Table Id mapped
	private IDAIConfigView daiWeight; // config table id mapped (ok, ko, alert)
	private Long opId;

	public Long getId() {
		return id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public Long getSoggettoId() {
		return soggettoId;
	}

	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}

	public IDAIPesoView getDaiPeso() {
		return daiPeso;
	}

	public void setDaiPeso(final IDAIPesoView daiPeso) {
		this.daiPeso = daiPeso;
	}

	public IDAIWeightageView getDaiCodeId() {
		return daiCodeId;
	}

	public void setDaiCodeId(final IDAIWeightageView daiCodeId) {
		this.daiCodeId = daiCodeId;
	}

	public IDAIConfigView getDaiWeight() {
		return daiWeight;
	}

	public void setDaiWeight(final IDAIConfigView daiWeight) {
		this.daiWeight = daiWeight;
	}

	public Long getOpId() {
		return opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}
	
	public boolean equals(final Object obj){
		boolean result = false;
		if (obj instanceof DAIRegoleDetailsView) {
			final DAIRegoleDetailsView view = (DAIRegoleDetailsView) obj;
			result = checkPesoEquality(view.getDaiPeso()) && checkWeightCodeIdEquality(view.getDaiCodeId()) && checkWeightIdEquality(view.getDaiWeight());
		}
		return result;
	}
	
	public int hashCode() {
		int hashCode = 1;
		hashCode = hashCode * 10 + (this.getDaiPeso() != null ? this.getDaiPeso().getPesoId().hashCode() : 0);
		hashCode = hashCode * 10 + (this.getDaiCodeId() != null ? this.getDaiCodeId().getId().hashCode() : 0);		
		hashCode = hashCode * 10 + (this.getDaiWeight() != null ? this.getDaiWeight().getDaiConfigId().hashCode() : 0);
		return hashCode;
	}
	
	private boolean checkPesoEquality(final IDAIPesoView daiPeso) {
		return UtilHelper.checkEquality(daiPeso != null ? daiPeso.getPesoId() : null,
				this.getDaiPeso() != null ? this.getDaiPeso().getPesoId() : null);
	}
	
	private boolean checkWeightCodeIdEquality(final IDAIWeightageView daiWeightageView) {
		return UtilHelper.checkEquality(daiWeightageView != null ? daiWeightageView.getId() : null,
				this.getDaiCodeId() != null ? this.getDaiCodeId().getId(): null);
	}
	
	private boolean checkWeightIdEquality(final IDAIConfigView daiWeight) {
		return UtilHelper.checkEquality(daiWeight != null ? daiWeight.getDaiConfigId() : null,
				this.getDaiWeight() != null ? this.getDaiWeight().getDaiConfigId() : null);
	}
}