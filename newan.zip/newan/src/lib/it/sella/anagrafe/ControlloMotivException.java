package it.sella.anagrafe;

public class ControlloMotivException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ControlloMotivException() {
		// Explicit Empty Constructor
    }

	public ControlloMotivException( final String errorMessage) {
	       super(errorMessage);
	}
	
    public ControlloMotivException( final String errorMessage ,final Throwable throwable) {
       super(errorMessage, throwable);
    }

}
