package it.sella.anagrafe;

import java.sql.Timestamp;

/**
 * @author GBS03447
 *
 */
public class DAIStoricDataView implements IDAIStoricDataView { // API Purpose

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long soggettoId;
	private Boolean value;
	private Timestamp dateOfOperation;

	public Long getSoggettoId() {
		return soggettoId;
	}

	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}

	public Boolean getValue() {
		return value;
	}

	public void setValue(final Boolean value) {
		this.value = value;
	}

	public Timestamp getDateOfOperation() {
		return dateOfOperation;
	}

	public void setDateOfOperation(final Timestamp dateOfOperation) {
		this.dateOfOperation = dateOfOperation;
	}

}
