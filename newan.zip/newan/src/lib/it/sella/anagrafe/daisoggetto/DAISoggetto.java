package it.sella.anagrafe.daisoggetto;

import java.io.Serializable;

/**
 * @author GBS03447
 * 
 */
public interface DAISoggetto extends Serializable {

	Long getDaiId();
	Long getSoggettoId();
	Long getRegoleId();
	Long getDaiWeightId();
	Long getOpId();

	void setDaiId(final Long daiId);
	void setSoggettoId(final Long soggettoId);
	void setRegoleId(final Long regoleId);
	void setDaiWeightId(final Long daiWeightId);
	void setOpId(final Long opId);

}
