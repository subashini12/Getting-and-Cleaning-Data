package it.sella.anagrafe.daisoggetto;

import javax.ejb.FinderException;
import it.sella.anagrafe.GestoreAnagrafeException;

/**
 * @author GBS03447
 *
 */
public interface IDAISoggettoBeanManager {
	
	public DAISoggetto create(final DAISoggetto daiSoggetto) throws GestoreAnagrafeException;
	
	public DAISoggetto update(final DAISoggetto daiSoggetto);
	
	public void remove(final DAISoggetto daiSoggetto);
	
	public DAISoggetto findBySoggettoId(final Long soggettoId) throws FinderException;
	
	public DAISoggetto findByPrimaryKey(final Long primaryKey) throws FinderException;

}
