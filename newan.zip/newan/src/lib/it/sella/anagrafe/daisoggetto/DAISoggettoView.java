package it.sella.anagrafe.daisoggetto;

/**
 * @author GBS03447
 *
 */
public class DAISoggettoView implements DAISoggetto {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long daiId;
	private Long soggettoId;
	private Long regoleId;
	private Long daiWeightId;
	private Long opId;
	
	public Long getDaiId() {
		return daiId;
	}

	public void setDaiId(final Long daiId) {
		this.daiId = daiId;
	}

	public Long getSoggettoId() {
		return soggettoId;
	}

	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}

	public Long getRegoleId() {
		return regoleId;
	}

	public void setRegoleId(final Long regoleId) {
		this.regoleId = regoleId;
	}

	public Long getDaiWeightId() {
		return daiWeightId;
	}

	public void setDaiWeightId(final Long daiWeightId) {
		this.daiWeightId = daiWeightId;
	}

	public Long getOpId() {
		return opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}
}
