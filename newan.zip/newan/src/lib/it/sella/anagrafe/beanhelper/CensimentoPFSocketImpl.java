package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.BeanHelperException;
import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.anagrafe.OperazioneCensimentoException;
import it.sella.anagrafe.SocketHelperException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.factory.PersonaFisicaFactory;
import it.sella.anagrafe.factory.PersonaFisicaFactoryException;
import it.sella.anagrafe.factory.PersonaFisicaViewImpl;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.anagrafe.implementation.SistemiEsterni;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.GestoreAmministratoriBancaHelper;
import it.sella.anagrafe.util.MapperHelperException;
import it.sella.anagrafe.util.PFHelper;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.anagrafe.util.socket.SocketHelper;
import it.sella.anagrafe.view.PersonaFisicaView;
import it.sella.anagrafe.view.SoggettoView;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Hashtable;

public class CensimentoPFSocketImpl extends CensimentoPFImpl {

    public Long performCensimentoH2OandSOCKET( final SoggettoView soggettoView, final StringBuffer logMsg, final StringBuffer logForHost ) throws RemoteException, BeanHelperException {
        try {
            final PersonaFisicaFactory personaFisicaFactory = (PersonaFisicaFactory) getAnagrafeFactory(soggettoView.getClass());
            final PersonaFisicaView personaFisicaView = (PersonaFisicaView) soggettoView;
            personaFisicaView.setRecapitiPFView(getRecapitiAfterRemovingEmpty(personaFisicaView.getRecapitiPFView()));
            final Long soggettoId = personaFisicaFactory.createPersonaFisica(personaFisicaView);
            logMsg.append("<DataWrite>");
            logMsg.append(personaFisicaFactory.getLogData(personaFisicaView));
            // aligning acfw for collegati abilitati
            final Collection abilitatiIds = new PFHelper().getAllowedPFSoggettiForACFW(personaFisicaView);
            new SistemiEsterni().updateAccount(soggettoId, abilitatiIds);
            final Collection motivCollection = personaFisicaView.getMotiv();
            soggettoView.setId(soggettoId);
            if ( isAllowedHostCallForPF(motivCollection) && 
            		("OK".equals(CommonPropertiesHandler.getValueFromProperty(SecurityHandler.getLoginBancaId().toString())) || 
            		  checkForTestoMemo(personaFisicaView.getMemoView(), "HOST")) && 
            		  personaFisicaView.isHostToBeCalled() || personaFisicaView.isSocketToBeCalled()) {
            	final Hashtable socketTable = new SocketHelper().censimentoSocketPF(personaFisicaView, soggettoId);
            	buildSocketHostLog(socketTable, logForHost);
            	final String art136Value = new GestoreAmministratoriBancaHelper().alignAmministratoriBancaMotivBasedOnLinkedViewsForPF(soggettoId, 
            			personaFisicaView.getCollegateViews(),personaFisicaView.getCodiceSoggettoPFView() != null ? 
            					personaFisicaView.getCodiceSoggettoPFView().getCodiceHost() : null,
            					logForHost,personaFisicaView.getOpId(),personaFisicaView.isHostCodeFromSecurity());
                if( art136Value != null ) {
                	logMsg.append("<ART136_VALORE>").append(art136Value).append("</ART136_VALORE>");	
                }
            }
           logMsg.append("</DataWrite>");
           return soggettoId;
        } catch (final PersonaFisicaFactoryException e) {
        	handleException(e, logMsg);
        } catch (final OperazioneCensimentoException e) {
        	handleException(e, logMsg);
        } catch (final SocketHelperException e) {
        	handleException(e, logMsg);
        } catch (final SubSystemHandlerException e) {
        	handleException(e, logMsg);
		} catch (final ControlloDatiException e) {
        	handleException(e, logMsg);
		} 
		return null;
    }
	
    public void performCensimentoModificaH2OandSOCKET( final SoggettoView soggettoView, final StringBuffer logMsg, final StringBuffer logForHost ) throws RemoteException, BeanHelperException {
        try {
        	final PersonaFisicaView personaFisicaView = (PersonaFisicaView) soggettoView;
        	final PersonaFisicaFactory personaFisicaFactory = (PersonaFisicaFactory) getAnagrafeFactory(soggettoView.getClass());
        	final Long soggettoId = soggettoView.getId();
            logMsg.append("<DataView>");
            logMsg.append(personaFisicaFactory.getLogData(personaFisicaView.getPersonaFisicaView()));
            logMsg.append("</DataView>");
            personaFisicaFactory.setPersonaFisica(personaFisicaView);
            logMsg.append("<DataWrite>");
            logMsg.append(personaFisicaFactory.getLogData(personaFisicaView));
            final Collection modifiedAbilitatiIds = new PFHelper().getAllowedPFSoggettiForACFW(personaFisicaView);
            new SistemiEsterni().updateAccount(soggettoId, modifiedAbilitatiIds);
            if (isAllowedHostCallForPF(personaFisicaView.getMotiv()) && ("OK".equals(CommonPropertiesHandler.getValueFromProperty(SecurityHandler.getLoginBancaId().toString())) ||
                    checkForTestoMemo(personaFisicaView.getMemoView(), "HOST")) && personaFisicaView.isHostToBeCalled() || personaFisicaView.isSocketToBeCalled()) {
            	Hashtable socketTable = null;
                if (personaFisicaView.getCodiceSoggettoPFView().getCodiceHost() != null) {
                	final boolean isSocketCreateCalled = ((PersonaFisicaViewImpl)soggettoView).isSocketCreateToCalled();
                	socketTable = new SocketHelper().modificaSocketPF(personaFisicaView, soggettoId, isSocketCreateCalled, isSocketCreateCalled );
                	buildSocketHostLog(socketTable, logForHost);
                    logForHost.append("^").append(update610MessageForCifratiPF(personaFisicaView));
                } else {
                	socketTable = new SocketHelper().censimentoSocketPF(personaFisicaView, soggettoId);
                	buildSocketHostLog(socketTable, logForHost);
                }
                final String art136Value = new GestoreAmministratoriBancaHelper().alignAmministratoriBancaMotivBasedOnLinkedViewsForPF(soggettoId, 
                		personaFisicaView.getCollegateViews(),personaFisicaView.getCodiceSoggettoPFView() != null ? 
                				personaFisicaView.getCodiceSoggettoPFView().getCodiceHost() : null,
                				logForHost,personaFisicaView.getOpId(),personaFisicaView.isHostCodeFromSecurity());
                if( art136Value != null ) {
                	logMsg.append("<ART136_VALORE>").append(art136Value).append("</ART136_VALORE>");	
                }
                	
            }
            updateDai(soggettoId,personaFisicaView);
            logMsg.append("</DataWrite>");
        } catch (final PersonaFisicaFactoryException e) {
        	handleException(e, logMsg);
        } catch (final OperazioneCensimentoException e) {
        	handleException(e, logMsg);
        } catch (final OperazioneAnagrafeManagerException e) {
        	handleException(e, logMsg);
        } catch (final GestoreCodiciSoggettoException e) {
        	handleException(e, logMsg);
        } catch (final SocketHelperException e) {
        	handleException(e, logMsg);
        } catch (final MapperHelperException e) {
        	handleMapperException(e, logMsg, logForHost);
        } catch (final SubSystemHandlerException e) {
        	handleException(e, logMsg);
		} catch (final ControlloDatiException e) {
        	handleException(e, logMsg);
		}
    }
    
}
