package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.AnagrafeDAIException;
import it.sella.anagrafe.BeanHelperException;
import it.sella.anagrafe.GestoreAnagrafeFactory;
import it.sella.anagrafe.GestoreDatiFiscaliException;
import it.sella.anagrafe.GestoreSoggettoException;
import it.sella.anagrafe.IMapper;
import it.sella.anagrafe.MapperFactory;
import it.sella.anagrafe.OperazioneCensimentoException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.az.CollegateAZView;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.dai.DaiRegoleSoggettohelper;
import it.sella.anagrafe.factory.AziendaFactory;
import it.sella.anagrafe.factory.AziendaFactoryException;
import it.sella.anagrafe.factory.FactoryException;
import it.sella.anagrafe.factory.LogFactory;
import it.sella.anagrafe.implementation.SistemiEsterni;
import it.sella.anagrafe.ivaapplicazione.ApplicazioneIvaCalculator;
import it.sella.anagrafe.pf.DatiFiscaliPFView;
import it.sella.anagrafe.util.AZHelper;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.GestoreAmministratoriBancaHelper;
import it.sella.anagrafe.util.MapperHelperException;
import it.sella.anagrafe.util.PortafogliazioneClientelaAccessHelper;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.anagrafe.view.AziendaView;
import it.sella.anagrafe.view.SoggettoView;
import it.sella.prtc.PortfolioException;

import java.rmi.RemoteException;
import java.util.Collection;

public class CensimentoAZHostImpl extends CensimentoAZImpl {
	
	
	public Long performCensimentoH2OandHOST(final SoggettoView soggettoView,final StringBuffer logMsg,final StringBuffer logForHost) throws RemoteException, BeanHelperException {
		try {
            final AziendaFactory aziendaFactory = (AziendaFactory) getAnagrafeFactory(soggettoView.getClass());
            final AziendaView aziendaView = (AziendaView) soggettoView;
            aziendaView.setRecapitiView(getRecapitiAfterRemovingEmpty(aziendaView.getRecapitiView()));
            setRepalcedCittaWithSpaceForComma( aziendaView.getIndirizziView());
            // Logic to calcualte is VAT applicable
            calculateIVAForAZ(aziendaView);
            if( aziendaView.getCanalePreferitoDataview() !=null && aziendaView.getCanalePreferitoDataview().getCanale()!=null && "NessunaPreferenza".equals(aziendaView.getCanalePreferitoDataview().getCanale().getCausale())){
            	aziendaView.setCanalePreferitoDataview(null);
    		}
            // Set Codice Fiscali For Ditta Individuale With Titolare Case.
            setCFWhenDittaIndWithTitolare(aziendaView.getTipoSoggettoDesc(), aziendaView);
            // DAI Regole Calculation 
            new DaiRegoleSoggettohelper().setDaiRegoleData(aziendaView);
            final Long soggettoId = aziendaFactory.createAzienda(aziendaView);
            soggettoView.setId(soggettoId);
            buildLogAndHostAlignMent(logMsg, logForHost, aziendaFactory, aziendaView,soggettoId);
			 
           return soggettoId;
        } catch (final AziendaFactoryException e) {
        	handleException(e, logMsg);
        } catch (final GestoreSoggettoException e) {
        	handleException(e, logMsg);
        } catch (final OperazioneCensimentoException e) {
        	handleException(e, logMsg);
        } catch (final MapperHelperException e) {
        	handleMapperException(e, logMsg, logForHost);
        }  catch (final SubSystemHandlerException e) {
        	handleException(e, logMsg);
		} catch (final ControlloDatiException e) {
        	handleException(e, logMsg);
		} catch (final GestoreDatiFiscaliException e) {
			handleException(e, logMsg);
		} catch (final AnagrafeDAIException e) {
			handleException(e, logMsg);
		}
		return null;
    }

	/**Private method to caluclate IVA
	 * @param aziendaView
	 */
	private void calculateIVAForAZ(final AziendaView aziendaView) {
		final AnagrafeHelper helper = new AnagrafeHelper();
		final Collection motivCollection = aziendaView.getMotiv();
		if ( !(motivCollection.contains("ANTCI") &&
				! helper.isExistsuperiorMotivThanAntciWithString(motivCollection))) {
			new ApplicazioneIvaCalculator().setCalculatedIVAForAZ(aziendaView.getDatiFiscaliAZView());
		}
	}

	public void buildLogAndDoHostAlignMentForSellaLifeCust(final SoggettoView soggettoView,final StringBuffer logMsg,final StringBuffer logForHost) throws RemoteException, BeanHelperException {
        try {
        	 final AziendaFactory aziendaFactory = (AziendaFactory) getAnagrafeFactory(soggettoView.getClass());
            final AziendaView aziendaView = (AziendaView) soggettoView;
            buildLogAndHostAlignMent(logMsg, logForHost, aziendaFactory, aziendaView,soggettoView.getId());
            new LogFactory().createLog(soggettoView.getId(),"I");
        } catch (final GestoreSoggettoException e) {
        	handleException(e, logMsg);
        } catch (final OperazioneCensimentoException e) {
        	handleException(e, logMsg);
        } catch (final MapperHelperException e) {
        	handleMapperException(e, logMsg, logForHost);
        }  catch (final SubSystemHandlerException e) {
        	handleException(e, logMsg);
		} catch (final ControlloDatiException e) {
        	handleException(e, logMsg);
		} catch (final FactoryException e) {
			handleException(e, logMsg);
		} 
    }

	private void buildLogAndHostAlignMent(final StringBuffer logMsg,
			final StringBuffer logForHost, final AziendaFactory aziendaFactory,
			final AziendaView aziendaView, final Long soggettoId)
			throws GestoreSoggettoException, RemoteException,
			OperazioneCensimentoException, SubSystemHandlerException,
			MapperHelperException, ControlloDatiException {
		logMsg.append("<DataWrite>");
		logMsg.append(aziendaFactory.getLogData(aziendaView));
		final Collection abilitatiIds = new AZHelper().getAllowedAZSoggettiForACFW(aziendaView, aziendaView.getTipoSoggettoDesc());
		new SistemiEsterni().updateAccount(soggettoId, abilitatiIds);  // to align acfw for collegati abilitati
		final Collection collMemo = aziendaView.getMemoView();
		final Collection motivCollection = aziendaView.getMotiv();
		final IMapper mapperHelper = MapperFactory.getMapper();
		if (!aziendaView.isThruXml() && !"Ambasciate e Organismi esteri in Italia".equals(aziendaView.getTipoSoggettoDesc()) &&
				(motivCollection.contains("CLINT") || motivCollection.contains("ANTCI")) && !motivCollection.contains("FIDDI") && !motivCollection.contains("FIDST") &&
				!motivCollection.contains("DEPTI") && !motivCollection.contains("TRAM")) {
			if (("OK".equals(CommonPropertiesHandler.getValueFromProperty(SecurityHandler.getLoginBancaId().toString())) || checkForTestoMemo(collMemo, "HOST")) && aziendaView.isHostToBeCalled()) {
				logForHost.append(mapperHelper.censimentoMapperAZ(aziendaView, soggettoId));
				
				if(aziendaView.getPromotoreIds() !=null && !aziendaView.getPromotoreIds().isEmpty()){
					callToPortafogliazioneCliente(aziendaView);
				}
	                
				final String art136Value = new GestoreAmministratoriBancaHelper().alignAmministratoriBancaMotivBasedOnLinkedViewsForAz(soggettoId, aziendaView.getCollegateViews(),aziendaView.getCodiceSoggettoAZView() != null ? aziendaView.getCodiceSoggettoAZView().getCodiceHost() : null,
						logForHost,aziendaView.getOpId(),aziendaView.isHostCodeFromSecurity());
				if(art136Value != null) {
					logMsg.append("<ART136_VALORE>").append(art136Value).append("</ART136_VALORE>");
				}
			}
		}  else if((!aziendaView.isThruXml() && aziendaView.getCodiceSoggettoAZView() != null && ( !motivCollection.contains("DEPTI") && !motivCollection.contains("TRAM"))) &&
				(("OK".equals(CommonPropertiesHandler.getValueFromProperty(SecurityHandler.getLoginBancaId().toString())) || checkForTestoMemo(collMemo, "HOST")) && aziendaView.isHostToBeCalled())) {
			logForHost.append(mapperHelper.updateAS3AS4Message(aziendaView.getCodiceSoggettoAZView().getCodiceHost(),
					aziendaView.getIndirizziView(),aziendaView.isHostCodeFromSecurity(),aziendaView.getMotiv()));
		       final String art136Value = new GestoreAmministratoriBancaHelper().alignAmministratoriBancaMotivBasedOnLinkedViewsForAz(soggettoId,
		    		   aziendaView.getCollegateViews(),aziendaView.getCodiceSoggettoAZView() != null ?
		    				   aziendaView.getCodiceSoggettoAZView().getCodiceHost() : null,
		    				   logForHost,aziendaView.getOpId(),aziendaView.isHostCodeFromSecurity());
		       if(art136Value != null) {
				logMsg.append("<ART136_VALORE>").append(art136Value).append("</ART136_VALORE>");
			}
		      
		}
		
         logMsg.append("</DataWrite>");
	}
	
	 /**
     * To register in PortafogliazioneClientela in censimento via Creation
     * @param personaFisicaView
     * @throws PortfolioException
     */
	private void callToPortafogliazioneCliente(final AziendaView aziendaView)
	{
		final String ottoCifre = aziendaView.getCodiceSoggettoAZView().getCodiceHost();
		final String clientLabel = aziendaView.getDatiAnagraficiAZView().getDenominazione();
		new PortafogliazioneClientelaAccessHelper().registerClientWithPromoter(aziendaView.getId(), aziendaView.getPromotoreIds(), ottoCifre,clientLabel);

	}
    public void performCensimentoModificaH2OandHOST(final SoggettoView soggettoView,final StringBuffer logMsg,final StringBuffer logForHost) throws RemoteException, BeanHelperException {
        try {
            final AziendaView aziendaView = (AziendaView) soggettoView;
            final AziendaFactory aziendaFactory = (AziendaFactory) getAnagrafeFactory(soggettoView.getClass());
            final Long soggettoId = soggettoView.getId();
            validationForPolizzaSellaLife( aziendaView);
            logMsg.append("<DataView>");
            logMsg.append(aziendaFactory.getLogData(aziendaView.getOldAziendaView()));
            logMsg.append("</DataView>");
            //Removing empty recapiti values 
            aziendaView.setRecapitiView(getRecapitiAfterRemovingEmpty(aziendaView.getRecapitiView()));
            setRepalcedCittaWithSpaceForComma( aziendaView.getIndirizziView());
            calculateIVAForAZ(aziendaView);
            //Set Codice Fiscali For Ditta Individuale With Titolare Case.
            setCFWhenDittaIndWithTitolare(aziendaView.getTipoSoggettoDesc(), aziendaView);
            // DAI Regole Calculation
            new DaiRegoleSoggettohelper().setDaiRegoleData(aziendaView);
            aziendaFactory.setAzienda(aziendaView);
            logMsg.append("<DataWrite>");
            logMsg.append(aziendaFactory.getLogData(aziendaView));
            final Collection modifiedCollegatiAbilitati = new AZHelper().getAllowedAZSoggettiForACFW(aziendaView);
            new SistemiEsterni().updateAccount(soggettoId, modifiedCollegatiAbilitati);
            final Collection collMemo = aziendaView.getMemoView();
            final Collection motivCollection = aziendaView.getMotiv();
           /* if (("OK".equals(CommonPropertiesHandler.getValueFromProperty(SecurityHandler.getLoginBancaId().toString())) || checkForTestoMemo(collMemo, "HOST")) && aziendaView.isHostToBeCalled()) {
            	final IMapper mapperHelper = MapperFactory.getMapper();
				if (!"Ambasciate e Organismi esteri in Italia".equals(aziendaView.getTipoSoggettoDesc())
                        &&( motivCollection.contains("CLINT")|| motivCollection.contains("ANTCI")) && !motivCollection.contains("FIDDI") && !motivCollection.contains("FIDST") &&
                        !motivCollection.contains("DEPTI") && !motivCollection.contains("TRAM")) {
                    if (aziendaView.getCodiceSoggettoAZView().getCodiceHost() != null) {
                        logForHost.append(mapperHelper.modificaMapperAZ(aziendaView));
                        logForHost.append("^").append(update610MessageForCifratiAz(aziendaView));
                    } else {
						logForHost.append(mapperHelper.censimentoMapperAZ(aziendaView, soggettoId));
					}
                    final String art136Value = new GestoreAmministratoriBancaHelper().alignAmministratoriBancaMotivBasedOnLinkedViewsForAz(soggettoId,
                    		aziendaView.getCollegateViews(),aziendaView.getCodiceSoggettoAZView() != null ?
                    				aziendaView.getCodiceSoggettoAZView().getCodiceHost() : null,
                    				logForHost,aziendaView.getOpId(),aziendaView.isHostCodeFromSecurity());
                    if(art136Value != null) {
						logMsg.append("<ART136_VALORE>").append(art136Value).append("</ART136_VALORE>");
					}
                } else if (aziendaView.getCodiceSoggettoAZView() != null && (motivCollection.contains("DEPTI") || motivCollection.contains("TRAM"))) {
                	//BFWKAAE-502 :Host alignment AS3 and AS4 removed for TRAM and DEPTI.
                	logForHost.append(mapperHelper.updateAS3AS4Message(aziendaView.getCodiceSoggettoAZView().getCodiceHost(),
                    		aziendaView.getIndirizziView(),aziendaView.isHostCodeFromSecurity(),aziendaView.getMotiv()));
                    final String art136Value = new GestoreAmministratoriBancaHelper().alignAmministratoriBancaMotivBasedOnLinkedViewsForAz(soggettoId,
                    		aziendaView.getCollegateViews(),aziendaView.getCodiceSoggettoAZView() != null ?
                    				aziendaView.getCodiceSoggettoAZView().getCodiceHost() : null,logForHost,
                    				aziendaView.getOpId(),aziendaView.isHostCodeFromSecurity());
                    if(art136Value != null) {
						logMsg.append("<ART136_VALORE>").append(art136Value).append("</ART136_VALORE>");
					}
                }
            }*/
            logMsg.append("</DataWrite>");
        } catch (final AziendaFactoryException e) {
        	handleException(e, logMsg);
        } catch (final GestoreSoggettoException e) {
        	handleException(e, logMsg);
        } catch (final OperazioneCensimentoException e) {
        	handleException(e, logMsg);
        } /*catch (final GestoreCodiciSoggettoException e) {
        	handleException(e, logMsg);
        } catch (final MapperHelperException e) {
        	handleMapperException(e, logMsg, logForHost);
        } catch (final SubSystemHandlerException e) {
        	handleException(e, logMsg);
		} */catch (final ControlloDatiException e) {
        	handleException(e, logMsg);
		} catch (final GestoreDatiFiscaliException e) {
			handleException(e, logMsg);
		} catch (final AnagrafeDAIException e) {
			handleException(e, logMsg);
		}
    }

	    
    /**
     * If The Tipo soggetto is of DittaInd and if it has any Titolare then get the Titolare subjects CF and persist for AZ DI subject.
     * @param tipoSoggettoDesc
     * @param aziendaView
     * @throws RemoteException
     * @throws GestoreDatiFiscaliException
     */
    private void setCFWhenDittaIndWithTitolare(final String tipoSoggettoDesc, final AziendaView aziendaView) throws RemoteException, GestoreDatiFiscaliException {
		final Collection collegateCollection = aziendaView.getCollegateViews();
		final DatiFiscaliPFView datiFiscaliAZView = aziendaView.getDatiFiscaliAZView();
		Long titolSoggettoId = null;
		boolean isTitolareExist =false;
		if ("Ditta individuale".equals(tipoSoggettoDesc)) {
			if (collegateCollection != null && !collegateCollection.isEmpty()){
				for (final Object object : collegateCollection) {
					final CollegateAZView collegateAZView = (CollegateAZView) object;
					if ("TITOL".equals(collegateAZView.getTypeOfCollegate())) {
						titolSoggettoId = collegateAZView.getId();
						isTitolareExist = true;
						break;
					}
				}
				if (titolSoggettoId != null) {
					final String codiceFiscali = GestoreAnagrafeFactory.getInstance().getGestoreAnagrafe().getDatiFiscali(titolSoggettoId, "codiceFiscali");
					if(datiFiscaliAZView != null && (datiFiscaliAZView.getCodiceFiscali() == null || !datiFiscaliAZView.getCodiceFiscali().equals(codiceFiscali))) {
						datiFiscaliAZView.setCodiceFiscali(codiceFiscali);
					}
				}
			} 
			if(!isTitolareExist && datiFiscaliAZView.getCodiceFiscali() != null){
				datiFiscaliAZView.setCodiceFiscali(null);
			}
		}
	}

}
