package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.BeanHelperException;
import it.sella.anagrafe.OperazioneAnagrafeFactory;
import it.sella.anagrafe.OperazioneAnagrafeManager;
import it.sella.anagrafe.SocketHelperException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.az.AttributiEsterniAZView;
import it.sella.anagrafe.common.MotivoDiCensimento;
import it.sella.anagrafe.documento.Documento;
import it.sella.anagrafe.factory.AnagrafeFactory;
import it.sella.anagrafe.hostlog.SocketRBLogOperationDataView;
import it.sella.anagrafe.implementation.NazioneView;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.anagrafe.pf.DatiFiscaliPFView;
import it.sella.anagrafe.pf.DocumentoPFView;
import it.sella.anagrafe.pf.IndirizzoPFView;
import it.sella.anagrafe.pf.SoggettoRecapitiView;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.ExecuterHelper;
import it.sella.anagrafe.util.ISocketConstants;
import it.sella.anagrafe.util.IntestatazioneHandler;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.anagrafe.util.StringHandler;
import it.sella.anagrafe.util.socket.SocketRollBackHelper;
import it.sella.anagrafe.validator.ValidatorBase;
import it.sella.anagrafe.view.AziendaView;
import it.sella.anagrafe.view.CompDocumentView;
import it.sella.anagrafe.view.PersonaFisicaView;
import it.sella.anagrafe.view.SoggettoView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

public class AMBBaseHelper extends ValidatorBase {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AMBBaseHelper.class);

    protected boolean checkBankData( final String inputBankDenominazione ) throws RemoteException {
        if ( inputBankDenominazione != null && !"".equals(inputBankDenominazione) ) {
            try {
                final String loginBankDenominazione = new IntestatazioneHandler().getIntestatazioneString(SecurityHandler.getLoginBancaId());
                return inputBankDenominazione.trim().equals(loginBankDenominazione);
            } catch (final SubSystemHandlerException e) {
                log4Debug.warnStackTrace(e);
            } 
        }
        return false;
    }

    protected AnagrafeFactory getAnagrafeFactory( final Class classObj ) {
        return AnagrafeFactory.getFactory(classObj);
    }
    
    
    protected Collection getMotivoDiCensimento( final Collection motivoDiCensCollection ) {
        Collection motivoCollection = null;
        if( motivoDiCensCollection != null ) {
            motivoCollection = new ArrayList();
            final int size = motivoDiCensCollection.size();
            final Iterator iterator = motivoDiCensCollection.iterator();
            for( int i=0; i<size; i++ ) {
            	motivoCollection.add(((MotivoDiCensimento) iterator.next()).getMotivoCausale());	
            }
        }
        return motivoCollection;
    }

    public boolean checkForTestoMemo( final Collection memoCollection, final String toBeChecked ) {
        if( memoCollection != null ) {
        	final int sizeMemo = memoCollection.size();
        	final Iterator iterator = memoCollection.iterator();
            String memoTesto = null;
            for( int i = 0; i < sizeMemo; i++ ) {
                memoTesto = ((it.sella.anagrafe.implementation.MemoView) iterator.next()).getMemoTesto();
                if( memoTesto != null && memoTesto.equals(toBeChecked) ) {
                	return true;
                }
            }
        }
        return false;
    }
	
    public void buildSocketHostLog ( final Hashtable socketTable, final StringBuffer logHostBuffer ) throws SocketHelperException, RemoteException {
    	try {
    		buildSocketAllMessage(socketTable, logHostBuffer);
	    	if( socketTable == null || socketTable.get(ISocketConstants.SOCKETERRORMESSAGE) != null) {
	    		final List socketRBLogList = (List) socketTable.get(ISocketConstants.FAILURESOCKETMESCOL);
	    		SocketRBLogOperationDataView socketRBLogOperationDataView = null;
	    		if( socketRBLogList != null && !socketRBLogList.isEmpty() ) {
	    			final int size = socketRBLogList.size();
	    			final OperazioneAnagrafeManager operazioneAnagrafeManager = OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager();
	    			final SocketRollBackHelper socketRollBackHelper = new SocketRollBackHelper();
	    			for(int i=0; i<size; i++ ) {
	    				socketRBLogOperationDataView = (SocketRBLogOperationDataView) socketRBLogList.get(i);
	    				if( socketRBLogOperationDataView != null ) {
	    					socketRollBackHelper.setSocketLogOperationDetails(socketRBLogOperationDataView);
							operazioneAnagrafeManager.setSocketRollBackLog(socketRBLogOperationDataView);
	    				}
	    			}
	    		}
	    		throw new SocketHelperException((String)socketTable.get(ISocketConstants.SOCKETERRORMESSAGE));
	    	}
		} catch (final OperazioneAnagrafeManagerException e) {
			log4Debug.warnStackTrace(e);
			throw new SocketHelperException(e.getMessage());
		}
    }
    
    public void buildSocketAllMessage( final Hashtable socketTable, final StringBuffer logHostBuffer ) {
    	if( socketTable != null && !socketTable.isEmpty()) {
    		final List successSocketMesCol = (List)socketTable.get(ISocketConstants.SUCESSSOCKETMESCOL);
    		final List failureSocketMesCol = (List)socketTable.get(ISocketConstants.FAILURESOCKETMESCOL);
    		buildSocketMessage( successSocketMesCol, logHostBuffer);
    		buildSocketMessage( failureSocketMesCol, logHostBuffer);
    	}
    }
    
    private void buildSocketMessage( final List socketList, final StringBuffer logHostBuffer) {
    	if( socketList != null && !socketList.isEmpty() ) {
    		final int size = socketList.size();
    		SocketRBLogOperationDataView socketRBLogOperationDataView = null;
    		for( int i=0; i<size; i++) {
    			socketRBLogOperationDataView = (SocketRBLogOperationDataView) socketList.get(i);
    			if( socketRBLogOperationDataView != null ) {
    				logHostBuffer.append(socketRBLogOperationDataView.getOriginalSocketMessage());
    				logHostBuffer.append("^");
    			}
    		}
    	}
    }
    
 	protected boolean isAllowedHostCallForPF( final Collection motivCollection ) {
        return !((motivCollection.contains("CENST") || motivCollection.contains("UTBOL") || 
        		  motivCollection.contains("FORNT") || motivCollection.contains("IMELB") ||
        		  motivCollection.contains("MINML"))
                && ! ExecuterHelper.isExistsSuperiorMotivThanCenst(motivCollection));
    }
        
    protected Collection getRecapitiAfterRemovingEmpty( final Collection recapitiCollection ) {
    	if ( recapitiCollection != null && !recapitiCollection.isEmpty() ) {
    		final int size = recapitiCollection.size();
    		final Iterator recatpitiIterator = recapitiCollection.iterator();
    		SoggettoRecapitiView soggettoRecapitiView = null;
    		Collection originalRecapitiColl = null;
    		for ( int i=0; i<size; i++ ) {
    			soggettoRecapitiView = ( SoggettoRecapitiView ) recatpitiIterator.next();
    			if ( originalRecapitiColl == null ) {
    				originalRecapitiColl = new ArrayList(1);
    			}
    			if ( soggettoRecapitiView != null && soggettoRecapitiView.getValoreRecapiti() != null && 
    					soggettoRecapitiView.getValoreRecapiti().trim().length() > 0  ) {
    				originalRecapitiColl.add(soggettoRecapitiView);
    			}
    		}
    		return originalRecapitiColl;
    	}
    	return null;
    }
    public void setRepalcedCittaWithSpaceForComma( final Collection <IndirizzoPFView>indirizzoViewColl ) {
    	if ( indirizzoViewColl != null && !indirizzoViewColl.isEmpty() ) {
    		for(final IndirizzoPFView indirizziView : indirizzoViewColl){
    			final String cittaCommune = indirizziView.getCittaCommune();
    			final NazioneView nazione = (NazioneView) indirizziView.getNazione();
    			if(!"ITALIA".equals(nazione.getNome().trim())){
    				indirizziView.setCittaCommune(new StringHandler().replaceCommaWithSpace(cittaCommune));
    			}
    		}
    	}

    }
    public void  setIsSTARTUPNullAsFalse(final SoggettoView soggettoView){
    	final AziendaView azView = ( AziendaView )soggettoView;
    	if(azView != null && azView.getAttributiEsterniAZView()!=null){
    		if(azView.getTipoSoggettoDesc() != null && checkIsTipoSoggettoAllowedForStartUP(azView.getTipoSoggettoDesc())){
    	final AttributiEsterniAZView attributiEsterniAZView = azView.getAttributiEsterniAZView();
    		if(attributiEsterniAZView.getSTARTUP() == null){
    			attributiEsterniAZView.setSTARTUP(Boolean.FALSE);
    		}
    		if(attributiEsterniAZView.getSTARTUP_SOC() == null){
    			attributiEsterniAZView.setSTARTUP_SOC(Boolean.FALSE);
    		}
    		if(attributiEsterniAZView.getINC_STARTUP() == null){
    			attributiEsterniAZView.setINC_STARTUP(Boolean.FALSE);
    		}
    	}		
    	}
    }  
    
    
    /**
     * Method to Set Dati Fiscali VIEs and CVies as Null for ANTCI motive only , if exists with Cliente , it would not set
     * @param aziendaView
     */
    public void setDatifiscaliValuesAsNullForANTCI(final AziendaView aziendaView) {
    	if(aziendaView !=null){
    		final AnagrafeHelper helper = new AnagrafeHelper();
    		final Collection motivCollection = ((AziendaView)aziendaView).getMotiv();
    		if ( (motivCollection.contains("ANTCI") &&
    				! helper.isExistsuperiorMotivThanAntciWithString(motivCollection))){
    			final DatiFiscaliPFView datiFiscaliView= aziendaView.getDatiFiscaliAZView();
    			if(datiFiscaliView !=null){
    				datiFiscaliView.setC_VIES(null);
    				datiFiscaliView.setVIES(null);
    			}
    		}
    	}
    }
    
    
    /**
     * Method to Set Attributi esterni unwanted data as Null for ANTCI , if exists with Cliente , it would not set
     * @param aziendaView
     */
    public void setAttributiesterniValuesAsNullForANTCI(final AziendaView aziendaView) {
    	if(aziendaView !=null){
    		final AnagrafeHelper helper = new AnagrafeHelper();
    		final Collection motivCollection = ((AziendaView)aziendaView).getMotiv();
    		if ( (motivCollection.contains("ANTCI") &&
    				! helper.isExistsuperiorMotivThanAntciWithString(motivCollection))){
    			final AttributiEsterniAZView esterniAZView= aziendaView.getAttributiEsterniAZView();
    			if(esterniAZView !=null){
    				esterniAZView.setOnlus(null);
    				esterniAZView.setFinv(null);
    				esterniAZView.setFpens(null);
    				esterniAZView.setTredieci(null);
    				esterniAZView.setEcomm(null);
    			}
    		}
    	}
    }
    
    private boolean checkIsTipoSoggettoAllowedForStartUP(final String tipoSoggetto) {
		return tipoSoggetto.equals("Societ� di capitali")||tipoSoggetto.equals("Societ� cooperativa")||tipoSoggetto.equals("Societ� estera");
	}
    
    public void setDocudmentRilasciatoDa( final SoggettoView soggettoView ) throws SubSystemHandlerException  {
    	final PersonaFisicaView personaFisicaView = ( PersonaFisicaView )soggettoView;
    	if ( personaFisicaView != null ) {
            final Collection  documentoCollection = personaFisicaView.getDocumentiView();
            final Collection  documentoNewCollection = new ArrayList(1);
            DocumentoPFView documentoView = null;
            int size = 0;
            if ( documentoCollection != null && (size = documentoCollection.size()) > 0 ) {
            	final Iterator iterator = documentoCollection.iterator();
            	for ( int i=0; i<size; i++ ) {
        			documentoView = (DocumentoPFView)iterator.next();
        			documentoNewCollection.add( setRilasciatoDa(documentoView,personaFisicaView.getCompDocumentMasterView()) );
        		}
            }
            personaFisicaView.setDocumentiView(documentoNewCollection);
    	}
    }
    
    protected void handleException(final Exception e, final StringBuffer logMsg) throws BeanHelperException {
    	if(logMsg.toString().indexOf("<DataWrite>") != -1){
    		logMsg.append("</DataWrite>");
    	}
        log4Debug.warnStackTrace(e);
        throw new BeanHelperException(e.getMessage());
	}
	
    protected void handleMapperException(final Exception e, final StringBuffer logMsg, final StringBuffer logForHost) throws BeanHelperException {
        log4Debug.warnStackTrace(e);
        if(logMsg.toString().indexOf("<DataWrite>") != -1){
    		logMsg.append("</DataWrite>");
    	}
        final String temp = e.getMessage();
        final StringTokenizer tokenizer = new StringTokenizer(temp, "�");
        tokenizer.nextToken();
        if (tokenizer.hasMoreTokens()) {
			logForHost.append(tokenizer.nextToken());
		}
        throw new BeanHelperException(temp + " From Mapper");
	}
    
    private DocumentoPFView setRilasciatoDa( final DocumentoPFView documentoView ,final Map compDocMap) throws SubSystemHandlerException {
    	//Added abicode check for the Issue BFWKAAE-473 to avoid causale display for Carta Lista S.P.A bank
    	final String abiBanca = CommonPropertiesHandler.getValueFromProperty("CARTA_LISTA_BANK_ABI");
    	if ( documentoView != null && documentoView.getTipoDocumento() != null && !abiBanca.equals(SecurityHandler.getCodiceAbiBanca()) && compDocMap != null) {
    		String rilasciatoDa = documentoView.getEnteEmissione();
    		final CompDocumentView compDocumentView = (CompDocumentView)compDocMap.get(documentoView.getTipoDocumento().getCausale());
    		rilasciatoDa = compDocumentView != null && compDocumentView.getEnteEmissione() != null ? compDocumentView.getEnteEmissione() : rilasciatoDa;
    		/*log4Debug.debug("AMBBaseHelper : setRilasciatoDa :  rilasciatoDa : before =====>>>" , rilasciatoDa);
			if ( "Carta d'identita".equals( documentoView.getTipoDocumento().getCausale())){
				rilasciatoDa = ICensimentoPFConstants.DOC_PREFILL_RILASCIATO_CARATA;
			} else 	if ( "Passaporto".equals(documentoView.getTipoDocumento().getCausale()) ){
				rilasciatoDa = ICensimentoPFConstants.DOC_PREFILL_RILASCIATO_PASSPORT;
			} else if ( "Patente di guida".equals(documentoView.getTipoDocumento().getCausale())){
				rilasciatoDa = ICensimentoPFConstants.DOC_PREFILL_RILASCIATO_PATENTE;
			}*/
	    	log4Debug.debug("AMBBaseHelper : setRilasciatoDa :  rilasciatoDa =====>>>" , rilasciatoDa);
	    	documentoView.setEnteEmissione(rilasciatoDa);
		}
	    return documentoView;
    }
    
    
    /**
     * "Public method to calculate document ID based on document primary key at the time of document creation
     * @param documento
     * @return
     */
    public String calculateIdDocForPF(final Documento documento) {
    	String appendedStringWithZeros =null;
    	String appendingCalculatedCIN = null;
    	if(documento !=null){
    		if(documento.getDocumentoId()!=null){
    		final String convertedToString = String.valueOf(documento.getDocumentoId());
    		final int maximumDocIDLength = Integer.parseInt(CommonPropertiesHandler.getValueFromProperty("DOCUMENTOID_MAX_LENGTH"));
    		if( convertedToString.length() < maximumDocIDLength ){
    			appendedStringWithZeros =convertedToString.format("%08d", Integer.parseInt(convertedToString));

    		}else{
    			appendedStringWithZeros =convertedToString;
    		}
    		final int claculatedCIN = calculationOfCINCharacter(appendedStringWithZeros);
    		appendingCalculatedCIN = appendedStringWithZeros + claculatedCIN;
    		documento.setIdDoc(appendingCalculatedCIN);
    	}
    	}
		
		return appendingCalculatedCIN;
    }


	
    /**
     * 
     * Method to calculate CIN
     * @param appendedStringWithZeros
     * @return
     */
    private int calculationOfCINCharacter(final String appendedStringWithZeros) {
		int sumOfDigitaAtOddPositions =0;
		int sumOfDigitsAtEvenPositions =0;
		int totalSum=0;
		int nextNearestTen=0;
		final int[] number = new int[appendedStringWithZeros.length()];
		for(int i=0;i<number.length;i++){
			if(i %2 ==0){
				 sumOfDigitaAtOddPositions += Integer.parseInt(String.valueOf(appendedStringWithZeros.charAt(i)));
			}
			else{
				  sumOfDigitsAtEvenPositions += Integer.parseInt(String.valueOf(appendedStringWithZeros.charAt(i)));
			}
		}
		sumOfDigitsAtEvenPositions *= 3;
		totalSum = sumOfDigitaAtOddPositions+sumOfDigitsAtEvenPositions;
		if(totalSum % 10 > 0)
		{
			nextNearestTen = (totalSum + (10 - totalSum % 10));
		}
		else
		{
			nextNearestTen = totalSum;
		}
		return nextNearestTen-totalSum;
	}

	

}
