package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.BeanHelperException;
import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.anagrafe.GestoreSoggettoException;
import it.sella.anagrafe.MapperFactory;
import it.sella.anagrafe.OperazioneCensimentoException;
import it.sella.anagrafe.SocketHelperException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.factory.AziendaFactory;
import it.sella.anagrafe.factory.AziendaFactoryException;
import it.sella.anagrafe.factory.AziendaViewImpl;
import it.sella.anagrafe.implementation.SistemiEsterni;
import it.sella.anagrafe.util.AZHelper;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.GestoreAmministratoriBancaHelper;
import it.sella.anagrafe.util.MapperHelperException;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.anagrafe.util.socket.SocketHelper;
import it.sella.anagrafe.view.AziendaView;
import it.sella.anagrafe.view.SoggettoView;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Hashtable;

public class CensimentoAZSocketImpl extends CensimentoAZImpl {

	public Long performCensimentoH2OandHOST(final SoggettoView soggettoView,final StringBuffer logMsg,final StringBuffer logForHost) throws RemoteException, BeanHelperException {
        try {
            final AziendaFactory aziendaFactory = (AziendaFactory) getAnagrafeFactory(soggettoView.getClass());
            final AziendaView aziendaView = (AziendaView) soggettoView;
            aziendaView.setRecapitiView(getRecapitiAfterRemovingEmpty(aziendaView.getRecapitiView()));
            final Long soggettoId = aziendaFactory.createAzienda(aziendaView);
            soggettoView.setId(soggettoId);
            logMsg.append("<DataWrite>");
            logMsg.append(aziendaFactory.getLogData(aziendaView));
            final Collection abilitatiIds = new AZHelper().getAllowedAZSoggettiForACFW(aziendaView, aziendaView.getTipoSoggettoDesc());
            new SistemiEsterni().updateAccount(soggettoId, abilitatiIds);  // to align acfw for collegati abilitati
            final Collection collMemo = aziendaView.getMemoView();
            final Collection motivCollection = aziendaView.getMotiv();
           if (!aziendaView.isThruXml() && !"Ambasciate e Organismi esteri in Italia".equals(aziendaView.getTipoSoggettoDesc()) &&
                    motivCollection.contains("CLINT") && /* !motivCollection.contains("FIDDI") && !motivCollection.contains("FIDST") && */
                    !motivCollection.contains("DEPTI") && !motivCollection.contains("TRAM")) {
                if (("OK".equals(CommonPropertiesHandler.getValueFromProperty(SecurityHandler.getLoginBancaId().toString())) || checkForTestoMemo(collMemo, "HOST")) && aziendaView.isHostToBeCalled() || aziendaView.isSocketToBeCalled()) {
                	final Hashtable socketTable = new SocketHelper().censimentoSocketAZ(aziendaView, soggettoId);
                	buildSocketHostLog(socketTable, logForHost);
                    final String art136Value = new GestoreAmministratoriBancaHelper().alignAmministratoriBancaMotivBasedOnLinkedViewsForAz(soggettoId, 
                    		aziendaView.getCollegateViews(),aziendaView.getCodiceSoggettoAZView() != null ? 
                    				aziendaView.getCodiceSoggettoAZView().getCodiceHost() : null,
                    				logForHost,aziendaView.getOpId(),aziendaView.isHostCodeFromSecurity());
                    if(art136Value != null) {
						logMsg.append("<ART136_VALORE>").append(art136Value).append("</ART136_VALORE>");
					}
                }
            }  else if((!aziendaView.isThruXml() && aziendaView.getCodiceSoggettoAZView() != null && ( !motivCollection.contains("DEPTI") && !motivCollection.contains("TRAM"))) &&
					(("OK".equals(CommonPropertiesHandler.getValueFromProperty(SecurityHandler.getLoginBancaId().toString())) || checkForTestoMemo(collMemo, "HOST")) && aziendaView.isHostToBeCalled() || aziendaView.isSocketToBeCalled())) {
				   logForHost.append(MapperFactory.getMapper().updateAS3AS4Message(aziendaView.getCodiceSoggettoAZView().getCodiceHost(), 
						   aziendaView.getIndirizziView(),aziendaView.isHostCodeFromSecurity(),aziendaView.getMotiv()));
		           final String art136Value = new GestoreAmministratoriBancaHelper().alignAmministratoriBancaMotivBasedOnLinkedViewsForAz(soggettoId, 
		        		   aziendaView.getCollegateViews(),aziendaView.getCodiceSoggettoAZView() != null ? 
		        				   aziendaView.getCodiceSoggettoAZView().getCodiceHost() : null,
		        				   logForHost,aziendaView.getOpId(),aziendaView.isHostCodeFromSecurity());
		           if(art136Value != null) {
					logMsg.append("<ART136_VALORE>").append(art136Value).append("</ART136_VALORE>");
				}
            }
           logMsg.append("</DataWrite>");
           return soggettoId;
        } catch (final AziendaFactoryException e) {
        	handleException(e, logMsg);
        } catch (final GestoreSoggettoException e) {
        	handleException(e, logMsg);
        } catch (final OperazioneCensimentoException e) {
        	handleException(e, logMsg);
        } catch (final SocketHelperException e) {
        	handleException(e, logMsg);
        } catch (final MapperHelperException e) {
        	handleMapperException(e, logMsg, logForHost);
        } catch (final SubSystemHandlerException e) {
        	handleException(e, logMsg);
		} catch (final ControlloDatiException e) {
        	handleException(e, logMsg);
		}
		return null;
    }

    public void performCensimentoModificaH2OandHOST(final SoggettoView soggettoView,final StringBuffer logMsg,final StringBuffer logForHost) throws RemoteException, BeanHelperException {
        try {
            final AziendaView aziendaView = (AziendaView) soggettoView;
            final AziendaFactory aziendaFactory = (AziendaFactory) getAnagrafeFactory(soggettoView.getClass());
            final Long soggettoId = soggettoView.getId();
            logMsg.append("<DataView>");
            logMsg.append(aziendaFactory.getLogData(aziendaView.getOldAziendaView()));
            logMsg.append("</DataView>");
            aziendaFactory.setAzienda(aziendaView);
            logMsg.append("<DataWrite>");
            logMsg.append(aziendaFactory.getLogData(aziendaView));
            final Collection modifiedCollegatiAbilitati = new AZHelper().getAllowedAZSoggettiForACFW(aziendaView);
            new SistemiEsterni().updateAccount(soggettoId, modifiedCollegatiAbilitati);
            final Collection collMemo = aziendaView.getMemoView();
            final Collection motivCollection = aziendaView.getMotiv();
            if (("OK".equals(CommonPropertiesHandler.getValueFromProperty(SecurityHandler.getLoginBancaId().toString())) || checkForTestoMemo(collMemo, "HOST")) && aziendaView.isHostToBeCalled() || aziendaView.isSocketToBeCalled()) {
                if (!aziendaView.isThruXml() && !"Ambasciate e Organismi esteri in Italia".equals(aziendaView.getTipoSoggettoDesc())
                        && motivCollection.contains("CLINT") && /* !motivCollection.contains("FIDDI") && !motivCollection.contains("FIDST") && */
                        !motivCollection.contains("DEPTI") && !motivCollection.contains("TRAM")) {
                	Hashtable socketTable = null;
                    if (aziendaView.getCodiceSoggettoAZView().getCodiceHost() != null) {
                    	final boolean isSocketCreateCalled = ((AziendaViewImpl)aziendaView).isSocketCreateToCalled();
                    	socketTable = new SocketHelper().modificaSocketAZ(aziendaView, aziendaView.getId(), isSocketCreateCalled, isSocketCreateCalled);
                    	buildSocketHostLog(socketTable, logForHost);
                        logForHost.append("^").append(update610MessageForCifratiAz(aziendaView));
                    } else {
                    	socketTable = new SocketHelper().censimentoSocketAZ(aziendaView, soggettoId);
                    	buildSocketHostLog(socketTable, logForHost);
                    }
                    final String art136Value = new GestoreAmministratoriBancaHelper().alignAmministratoriBancaMotivBasedOnLinkedViewsForAz(soggettoId, 
                    		aziendaView.getCollegateViews(),aziendaView.getCodiceSoggettoAZView() != null ? 
                    				aziendaView.getCodiceSoggettoAZView().getCodiceHost() : null,
                    				logForHost,aziendaView.getOpId(),aziendaView.isHostCodeFromSecurity());
                    if(art136Value != null) {
						logMsg.append("<ART136_VALORE>").append(art136Value).append("</ART136_VALORE>");
					}
                } else if (!aziendaView.isThruXml() && aziendaView.getCodiceSoggettoAZView() != null && (motivCollection.contains("DEPTI") || motivCollection.contains("TRAM"))) {
                    //logForHost.append(new MapperHelper().updateAS3AS4Message(aziendaView.getCodiceSoggettoAZView().getCodiceHost(), aziendaView.getIndirizziView()));
                    final String art136Value = new GestoreAmministratoriBancaHelper().alignAmministratoriBancaMotivBasedOnLinkedViewsForAz(soggettoId, 
                    		aziendaView.getCollegateViews(),aziendaView.getCodiceSoggettoAZView() != null ? 
                    				aziendaView.getCodiceSoggettoAZView().getCodiceHost() : null,
                    				logForHost,aziendaView.getOpId(),aziendaView.isHostCodeFromSecurity());
                    if(art136Value != null) {
						logMsg.append("<ART136_VALORE>").append(art136Value).append("</ART136_VALORE>");
					}
                }
            }
            logMsg.append("</DataWrite>");
        } catch (final AziendaFactoryException e) {
        	handleException(e, logMsg);
        } catch (final GestoreSoggettoException e) {
        	handleException(e, logMsg);
        } catch (final OperazioneCensimentoException e) {
        	handleException(e, logMsg);
        } catch (final GestoreCodiciSoggettoException e) {
        	handleException(e, logMsg);
        } catch (final SocketHelperException e) {
        	handleException(e, logMsg);
        } catch (final MapperHelperException e) {
        	handleMapperException(e, logMsg, logForHost);
        } catch (final SubSystemHandlerException e) {
        	handleException(e, logMsg);
		} catch (final ControlloDatiException e) {
        	handleException(e, logMsg);
		}
    }
	
}
