package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.BeanHelperException;
import it.sella.anagrafe.OperazioneAnagrafeFactory;
import it.sella.anagrafe.discriminator.CollegamentoException;
import it.sella.anagrafe.factory.PlurintestazioneFactory;
import it.sella.anagrafe.factory.PlurintestazioneFactoryException;
import it.sella.anagrafe.implementation.PlurintestazioneParser;
import it.sella.anagrafe.util.AnagrafeLoggerHelper;
import it.sella.anagrafe.validator.RecapitiNonDisponibileHelper;
/*import it.sella.anagrafe.validator.RecapitiNonDisponibileHelper;*/
import it.sella.anagrafe.validator.SoggettoValidator;
import it.sella.anagrafe.view.PlurintestazioneView;
import it.sella.anagrafe.view.SoggettoView;
import it.sella.logserver.LoggerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.IOException;
import java.io.StringReader;
import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Properties;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

public class AnagrafeManagerBeanPLHelper extends AnagrafeManagerBeanHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AnagrafeManagerBeanPLHelper.class);
    private static final String RECAPITI_ERROR_MESSAGE = "RecapitiErrorMessage";
    
    public static PlurintestazioneParser plurintestazioneParser = null;

    public AnagrafeManagerBeanPLHelper() {
        logMsg = new StringBuffer();
        logForHost = new StringBuffer();
    }

    public String createSoggetto( final SoggettoView soggettoView, final String parserError, final String banca, final String operationeCode ) throws RemoteException, BeanHelperException {
        return createSoggettoPrivacyFiveAndSixLevel(soggettoView, parserError, banca, operationeCode);
    }

    public String createSoggettoWithHost( final SoggettoView soggettoView, final String parserError, final String banca, final String operationeCode ) throws RemoteException, BeanHelperException {
        return createSoggettoPrivacyFiveAndSixLevelWithHost(soggettoView, parserError, banca, operationeCode);    
    }
    
    private String createPlurintestazione( final String errorMessage, final PlurintestazioneView plurintestazioneView, final String operationcode ) throws BeanHelperException, RemoteException {
        try {
	        Long soggettoId = null;
	        if (errorMessage.trim().length() < 1) {
	            soggettoId = getPLSoggettoIdIfAlreadyExists(plurintestazioneView);
	            if ( soggettoId == null ) {
	                plurintestazioneView.setMotiv(getMotivoDiCensimento(plurintestazioneView.getMotiv()));
					plurintestazioneView.setOpId(new AnagrafeLoggerHelper().logAnagrafeOperation(plurintestazioneView.getMotivazioneNoHost(), plurintestazioneView.isHostToBeCalled(), operationcode, plurintestazioneView.getId(),null));
					setRecapitiNonDispList(plurintestazioneView);
	                soggettoId = performCensimento(plurintestazioneView);
	            } else {
	            	plurintestazioneView.setSoggettoAlreadyExist(true);
	            }
	            
	            plurintestazioneView.setId(soggettoId);
	        }
	        return new CommonHelper().getOutputXMLMessage(errorMessage,soggettoId);
		} catch (final LoggerException e) {
			log4Debug.warnStackTrace(e);
			throw new BeanHelperException(e.getMessage());
		}
    }

    public Long performCensimento( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException {
    	if( soggettoView != null && soggettoView.isSocketToBeCalled()) {
    		return performCensimentoSH(soggettoView);
    	} else {
    		return new CensimentoPLHostImpl().performCensimentoH2OandHOST(soggettoView,logMsg,logForHost);	
    	}
    }

    public void performCensimentoModifica( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException {
    	if( soggettoView != null && soggettoView.isSocketToBeCalled()) {
    		performCensimentoModificaSH(soggettoView);
    	} else {
    		new CensimentoPLHostImpl().performCensimentoModificaH2OandHOST(soggettoView,logMsg,logForHost);	
    	}
    }

    public Long performCensimentoSH( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException {
    	return new CensimentoPLSocketImpl().performCensimentoH2OandSocket(soggettoView,logMsg,logForHost);
    }

    public void performCensimentoModificaSH( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException {
    	new CensimentoPLSocketImpl().performCensimentoModificaH2OandSocket(soggettoView,logMsg,logForHost);
    }
    
    public Hashtable validateSoggettoXML( final SoggettoView soggettoView ) throws BeanHelperException, RemoteException {
        final PlurintestazioneView plurintestazioneView = (PlurintestazioneView) soggettoView;
        return new SoggettoValidator().validateSoggettoXML(plurintestazioneView);
    }

    public SoggettoView getSoggetto( final Long soggettoId, final Properties properties ) throws RemoteException, BeanHelperException {
        try {
        	final PlurintestazioneFactory plurintestazioneFactory = (PlurintestazioneFactory) getAnagrafeFactory(PlurintestazioneView.class);
        	final SoggettoView soggettoView = plurintestazioneFactory.getPlurintestazione(soggettoId);
            logMsg.append(plurintestazioneFactory.getLogData((PlurintestazioneView) soggettoView));
            return soggettoView;
        } catch (final PlurintestazioneFactoryException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    public Long getPLSoggettoIdIfAlreadyExists( final PlurintestazioneView plurintestazioneView ) throws BeanHelperException, RemoteException {
        try {
            return OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager().getPrincipaleForSoggettiColleganti(plurintestazioneView.getSoggettoIds(), "INTST");
        } catch (final CollegamentoException e) {
            log4Debug.severeStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }
    
    public SoggettoView getViewAfterParsing( final String xmlSoggetto ) throws BeanHelperException {
    	return getPlurintestazioneView(xmlSoggetto);
    }
    
    public SoggettoView getViewAfterParsingPrivacyFiveLevelXML( final String xmlSoggetto ) throws BeanHelperException {
    	return getPlurintestazioneView(xmlSoggetto);
    }

    private SoggettoView getPlurintestazioneView( final String xmlSoggetto ) throws BeanHelperException {
        try {
        	final XMLReader xmlReader = XMLReaderFactory.createXMLReader();
            plurintestazioneParser = new PlurintestazioneParser();
            xmlReader.setContentHandler(plurintestazioneParser);
            xmlReader.parse(new InputSource(new StringReader(xmlSoggetto)));
            return  plurintestazioneParser.getPlurintestazioneView();
        } catch (final SAXException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        } catch (final IOException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }
    
    private String createSoggettoPrivacyFiveAndSixLevel( final SoggettoView soggettoView, final String parserError, final String banca, final String operationcode ) throws RemoteException, BeanHelperException {
    	final PlurintestazioneView plurintestazioneView = (PlurintestazioneView)soggettoView;
    	final Hashtable plHash = new SoggettoValidator().validateSoggetto(plurintestazioneView);
        String errorMessage = parserError + (plHash.get(RECAPITI_ERROR_MESSAGE) != null ? (String)plHash.get(RECAPITI_ERROR_MESSAGE) : "") + (plHash.get("INTERMEDIARI_ERROR") != null ? (String) plHash.get("INTERMEDIARI_ERROR") : "")+(plHash.get("DATIFISCALI_PL_ERROR") != null ? (String) plHash.get("DATIFISCALI_PL_ERROR") : "");
        errorMessage = errorMessage.length() == 0 && !checkBankData(banca) ? errorMessage + "Soggetto does not belong to the login bank ^" : errorMessage;
        plurintestazioneView.setHostToBeCalled(false);
        return createPlurintestazione(errorMessage, plurintestazioneView, operationcode);
    }

    private String createSoggettoPrivacyFiveAndSixLevelWithHost( final SoggettoView soggettoView, final String parserError, final String banca, final String operationcode ) throws RemoteException, BeanHelperException {
    	final PlurintestazioneView plurintestazioneView = (PlurintestazioneView)soggettoView;
    	final Hashtable plHash = new SoggettoValidator().validateSoggetto(plurintestazioneView);
        String errorMessage = parserError + (plHash.get(RECAPITI_ERROR_MESSAGE) != null ? (String)plHash.get(RECAPITI_ERROR_MESSAGE) : "") + (plHash.get("INTERMEDIARI_ERROR") != null ? (String) plHash.get("INTERMEDIARI_ERROR") : "")+(plHash.get("DATIFISCALI_PL_ERROR") != null ? (String) plHash.get("DATIFISCALI_PL_ERROR") : "");
        errorMessage = errorMessage.length() == 0 && !checkBankData(banca) ? errorMessage + "Soggetto does not belong to the login bank ^" : errorMessage;
        return createPlurintestazione(errorMessage,plurintestazioneView, operationcode);
    }
    
    /**
     * @param plurintestazioneView
     */
    private void setRecapitiNonDispList(final PlurintestazioneView plurintestazioneView) {
		final Boolean recapNonDispAllowedForLoginBank = RecapitiNonDisponibileHelper.isRecapNonDispAllowedForLoginBank();
		plurintestazioneView.setRecapNonDispAllowed(recapNonDispAllowedForLoginBank);
		if(recapNonDispAllowedForLoginBank) {
			plurintestazioneView.setNonDispDetailView(new RecapitiNonDisponibileHelper().getRecapitiNonDispListForXML(plurintestazioneView.getRecapitiPLView(), "Plurintestazione"));
		}
	}
}
