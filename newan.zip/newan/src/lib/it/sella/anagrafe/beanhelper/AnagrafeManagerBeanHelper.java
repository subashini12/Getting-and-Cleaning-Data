package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.BeanHelperException;
import it.sella.anagrafe.view.SoggettoView;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.util.regex.Pattern;

public abstract class AnagrafeManagerBeanHelper extends AMBBaseHelper {

    protected StringBuffer logMsg = null;
    protected StringBuffer logForHost = null;

    public String getLogMsg() {
        return logMsg != null ? logMsg.toString() : "";
    }

    public String getLogForHost() {
        return logForHost != null ? logForHost.toString() : "";
    }

    public static String handleXMLMetaCharecter( String xmlData ) {
        if ( xmlData != null && xmlData.indexOf("SOGGETTO_COLLEGANTE") != -1) {
	        final int startIndex = xmlData.indexOf('>',xmlData.indexOf("SOGGETTO_COLLEGANTE"))+1;
	        final int endIndex = xmlData.indexOf('<',xmlData.indexOf("SOGGETTO_COLLEGANTE"));
	        final String bankName = xmlData.substring(startIndex, endIndex);
	        xmlData = xmlData.replaceAll(bankName, "<![CDATA["+bankName+"]]>");
        }
        return xmlData;
    }

	public static String handleXMLMetaCharecterInFiveLevelXML(String xmlData) {
		if( xmlData != null && xmlData.trim().length() > 0) {
			final Pattern pattern = Pattern.compile("<[^<^>]+>");
		    final List matchString = new ArrayList();
		    final String[] split = pattern.split(xmlData);
		    for( int k=0; k < split.length; k++) {
	 			if ( (split[k].indexOf('&') != -1 || split[k].indexOf('\'') != -1) && 
	 					!matchString.contains(split[k])){
	 				matchString.add(split[k]);
	 			}
		    }
	   		for(int i = 0; i < matchString.size(); i++){
	     		xmlData = xmlData.replaceAll(">"+(String)matchString.get(i)+"</", "><![CDATA["+matchString.get(i)+"]]></");
	   		}
		}
     	return xmlData;
    }

	public static String addOperationTagInFiveLevelXML( String xmlData ) {
		if( xmlData != null && xmlData.trim().length() > 0) {
			final StringBuffer xmlBuffer = new StringBuffer(xmlData);
			final String tag = "<OPERATION>ONLYVALIDATEXML</OPERATION>";
			final int index = xmlBuffer.indexOf("</COLLEGAMENTI>");
			if( index != -1 ) {
				xmlData = xmlBuffer.insert(index, tag).toString();
			}
		}
     	return xmlData;
    }

	
    public abstract Long performCensimento( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException ;

    public abstract void performCensimentoModifica( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException;

    public abstract Long performCensimentoSH( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException ;

    public abstract void performCensimentoModificaSH( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException;
    
    public abstract SoggettoView getSoggetto( final Long soggettoId, final Properties properties ) throws RemoteException, BeanHelperException ;

    public abstract String createSoggetto( final SoggettoView soggettoView, final String parserError, final String banca, final String operationCode ) throws RemoteException,BeanHelperException;

    public abstract String createSoggettoWithHost( final SoggettoView soggettoView, final String parserError, final String banca, final String operationCode ) throws RemoteException,BeanHelperException;
    
    public abstract SoggettoView getViewAfterParsing( final String xmlSoggetto ) throws BeanHelperException ;  
    
    public abstract SoggettoView getViewAfterParsingPrivacyFiveLevelXML( final String xmlSoggetto ) throws BeanHelperException ;
    
    public abstract Hashtable validateSoggettoXML( final SoggettoView soggettoView ) throws BeanHelperException, RemoteException;
}

