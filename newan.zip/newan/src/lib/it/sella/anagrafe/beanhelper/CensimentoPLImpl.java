package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.anagrafe.GestoreCollegamentoException;
import it.sella.anagrafe.MapperFactory;
import it.sella.anagrafe.dbaccess.CSCifratiGetterHelper;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.MapperHelperException;
import it.sella.anagrafe.util.PLHelper;
import it.sella.anagrafe.view.PlurintestazioneView;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.StringTokenizer;

public class CensimentoPLImpl extends AMBBaseHelper {
    
    protected Collection getCollegatiAbilitati(final PlurintestazioneView plurintestazioneView) throws RemoteException, GestoreCollegamentoException {
        final Collection modifiedCollegatiAbilitati = new PLHelper().getAllowedPLSoggettiForACFW(plurintestazioneView);
        final ArrayList idsToAcfw = modifiedCollegatiAbilitati != null ? new ArrayList(modifiedCollegatiAbilitati) : new ArrayList();
        if (plurintestazioneView.getAbili8CifreColl() == null && plurintestazioneView.getOldPlurintestazioneView().getAbili8CifreColl() != null) {
            final Collection abil8Ids = plurintestazioneView.getOldPlurintestazioneView().getAbili8CifreColl();
            final Iterator iterator = abil8Ids.iterator();
            final int size = abil8Ids.size();
            for (int i = 0; i < size; i++) {
                idsToAcfw.add(iterator.next());
            }
        }
        return idsToAcfw;
    }

    protected String update610MessageForCifratiPL(final PlurintestazioneView plurintestazioneView) throws RemoteException, GestoreCodiciSoggettoException, MapperHelperException {
    	if(CommonPropertiesHandler.isHostAllowedForLoginBank()) {
	        final String codiceHost = new CSCifratiGetterHelper().getCodiceHostCifrati(plurintestazioneView.getId());
	        if(codiceHost != null) {
	            final StringTokenizer tokenizer = new StringTokenizer(codiceHost, ";");
	            final StringBuffer hostMessage = new StringBuffer();
	            while(tokenizer.hasMoreTokens()) {
	        		hostMessage.append(MapperFactory.getMapper().update610For8cifreCifratiPL(tokenizer.nextToken(),plurintestazioneView));
	            }
	            return hostMessage.toString();
	        }
    	}
        return "";
    }
}
