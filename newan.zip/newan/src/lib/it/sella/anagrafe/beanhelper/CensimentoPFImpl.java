package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.anagrafe.MapperFactory;
import it.sella.anagrafe.OperazioneAnagrafeFactory;
import it.sella.anagrafe.OperazioneAnagrafeManager;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.dbaccess.CSCifratiGetterHelper;
import it.sella.anagrafe.dbaccess.StoricDataUpdateHelper;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.anagrafe.pf.AttributiEsterniPFView;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.MapperHelperException;
import it.sella.anagrafe.view.DocEventiView;
import it.sella.anagrafe.view.PersonaFisicaView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.StringTokenizer;

public class CensimentoPFImpl extends AMBBaseHelper {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CensimentoPFHostImpl.class);

    protected String update610MessageForCifratiPF( final PersonaFisicaView personaFisicaView ) throws RemoteException, GestoreCodiciSoggettoException, MapperHelperException {
    	if ( CommonPropertiesHandler.isHostAllowedForLoginBank() ) {
	    	final String codiceHost = new CSCifratiGetterHelper().getCodiceHostCifrati(personaFisicaView.getId());
	        if ( codiceHost != null ) {
	        	final StringBuffer hostMessage = new StringBuffer();
	            final StringTokenizer tokenizer = new StringTokenizer(codiceHost, ";");
	            while ( tokenizer.hasMoreTokens() ) {
	        		hostMessage.append(MapperFactory.getMapper().update610For8cifreCifratiPF(tokenizer.nextToken(), personaFisicaView));
	            }
	            return hostMessage.toString();
	        }
    	}
        return "";
    }

    protected void updateDai( final Long soggettoId, final PersonaFisicaView personaFisicaView ) throws RemoteException, OperazioneAnagrafeManagerException {
    	final Boolean oldDai = personaFisicaView.getPersonaFisicaView() != null && personaFisicaView.getPersonaFisicaView().getAttributiEsterniPFView() != null ?
                personaFisicaView.getPersonaFisicaView().getAttributiEsterniPFView().getDai() : null;
        final Boolean newDai = personaFisicaView.getAttributiEsterniPFView() != null ? personaFisicaView.getAttributiEsterniPFView().getDai() : null;
        if ( oldDai != null ) {
            if ( !oldDai.equals(newDai) ) {
            	getOperazioneAnagrafeManager().updateDaiForPrincipalIds(soggettoId, oldDai.booleanValue(), newDai.booleanValue(),personaFisicaView.getOpId());
            }
        } else if ( newDai != null ) {
        	getOperazioneAnagrafeManager().updateDaiForPrincipalIds(soggettoId, false, newDai.booleanValue(),personaFisicaView.getOpId());
        }
    }

    private OperazioneAnagrafeManager getOperazioneAnagrafeManager() {
    	return OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager();
    }

    /**
     * To delete the records from an_tr_doc_eventi table for Non italian when the Cittadinanza or Second  Cittadinanza changed to ITALIA
     * @param personaFisicaView
     * @throws RemoteException
     * @throws ControlloDatiException
     * @throws SubSystemHandlerException
     */
    protected void deleteDocEventi4ExtraCommuntario( final PersonaFisicaView personaFisicaView )
    throws RemoteException, ControlloDatiException,SubSystemHandlerException {
    	if ( isCittadinanzaItaly(personaFisicaView.getAttributiEsterniPFView()) ) {
    		final Collection docEventi = getOperazioneAnagrafeManager().getDocEventi( personaFisicaView.getId() );
    		if (docEventi!= null ) {
    			log4Debug.debug("docEventi ...........",docEventi.size());
    			for (final Object docEventiObj : docEventi) {
    				final DocEventiView docEventiView = ( DocEventiView ) docEventiObj;
    				log4Debug.debug("docEventiView ...........",docEventiView.getId());
    				new StoricDataUpdateHelper().updateStorciDocEventi(docEventiView,personaFisicaView.getOpId());
    				log4Debug.debug("Removing Doc Eventi...........",docEventiView.getId());
    				getOperazioneAnagrafeManager().removeDocEventi( docEventiView );
    			}
    		}
    	}
    }

    /**
     * Method to check whether the Cittadinanza or SecondaCittadinanza is ITALIA
     * @param attributiEsterniPFView
     * @return
     */
    private boolean isCittadinanzaItaly( final AttributiEsterniPFView attributiEsterniPFView ) {
    	boolean isCittadinanzaItaly = false;
    	log4Debug.debug("Cittadinanza ...........",attributiEsterniPFView.getCittadinanza());
    	log4Debug.debug("SecondaCittadinanza ...........",attributiEsterniPFView.getSecondaCittadinanza());
    	if ( (attributiEsterniPFView.getCittadinanza() != null && "ITALIA".equals(attributiEsterniPFView.getCittadinanza().getNome()))
    			||(attributiEsterniPFView.getSecondaCittadinanza() != null && "ITALIA".equals(attributiEsterniPFView.getSecondaCittadinanza().getNome())) ){
    		isCittadinanzaItaly = true;
    	}
    	log4Debug.debug("isNonUEResItaly ...........",isCittadinanzaItaly);
    	return isCittadinanzaItaly;
    }
}
