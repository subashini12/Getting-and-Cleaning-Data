package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.AnagrafeManagerFactory;
import it.sella.anagrafe.BeanHelperException;
import it.sella.anagrafe.CanalePreferitoDataView;
import it.sella.anagrafe.GestoreSoggettoException;
import it.sella.anagrafe.OperazioneAnagrafeFactory;
import it.sella.anagrafe.OperazioneAnagrafeManager;
import it.sella.anagrafe.az.AttributiEsterniAZView;
import it.sella.anagrafe.az.CodiceSoggettoAZView;
import it.sella.anagrafe.az.DatiAnagraficiAZView;
import it.sella.anagrafe.common.MotivoDiCensimento;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.dbaccess.SoggettoDBAccessHelper;
import it.sella.anagrafe.discriminator.AttributiEsterniDiscriminatorException;
import it.sella.anagrafe.discriminator.DatiAnagraficiDiscriminatorException;
import it.sella.anagrafe.discriminator.DatiFiscaliDiscriminatorException;
import it.sella.anagrafe.pf.AttributiEsterniPFView;
import it.sella.anagrafe.pf.CodiceSoggettoPFView;
import it.sella.anagrafe.pf.DatiAnagraficiPFView;
import it.sella.anagrafe.pf.DatiFiscaliPFView;
import it.sella.anagrafe.pf.DatiPrivacyPFFiveLevelView;
import it.sella.anagrafe.pf.SoggettoRecapitiView;
import it.sella.anagrafe.sm.censimentopf.RPFExecuterHelper;
import it.sella.anagrafe.util.AnagConfigurationHandler;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.ControlloDaiException;
import it.sella.anagrafe.util.DAIHelper;
import it.sella.anagrafe.util.UtilHelper;
import it.sella.anagrafe.validator.RecapitiNonDisponibileHelper;
import it.sella.anagrafe.view.AziendaView;
import it.sella.anagrafe.view.PersonaFisicaView;
import it.sella.anagrafe.view.PlurintestazioneView;
import it.sella.anagrafe.view.SettorePLView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

public class XMLSoggettiHandler {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(XMLSoggettiHandler.class);
	private OperazioneAnagrafeManager operazioneAnagrafeManager = null;
	
	public String variaSoggettoXML(final String xmlSoggetto, 
			final Long soggettoId, final Long operationId,
			final AnagrafeManagerBeanPFHelper anagrafeManagerBeanHelper) 
			throws RemoteException, BeanHelperException {
		final PersonaFisicaView personaFisicaView = (PersonaFisicaView) anagrafeManagerBeanHelper.getViewAfterParsingPrivacyFiveLevelXML(xmlSoggetto);
		try {
	  		    final Properties properties = new Properties();
	  		    validateDatiAnagrafici(personaFisicaView.getDatiAnagraficiPFView(), soggettoId);
	  		    validateCodiceFiscali(personaFisicaView.getDatiFiscaliPFView(), soggettoId);
				final AttributiEsterniPFView attributiEsterniPFView = personaFisicaView.getAttributiEsterniPFView();
				validateSesso(attributiEsterniPFView, soggettoId);
	  		    final PersonaFisicaView personaFisicaDBView = (PersonaFisicaView) AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().getSoggetto(soggettoId, properties);
	  		    personaFisicaView.setRecapitiPFView(setRecapiti(personaFisicaView.getRecapitiPFView() ,personaFisicaDBView.getRecapitiPFView()));
			    //Set Document Id through XML has been handled in DatiDocumentiValidator Class.
				final CodiceSoggettoPFView oldCodiceSoggettoPFView = personaFisicaDBView.getCodiceSoggettoPFView();
				final String codiceHostDB = oldCodiceSoggettoPFView == null ? null : oldCodiceSoggettoPFView.getCodiceHost();
				personaFisicaView.setOpId(operationId);
				personaFisicaView.setId(soggettoId);
				
				final Boolean newDAIConfigAllowed = AnagConfigurationHandler.isConfigurationAllowed("NewDaiAllowed");
				final Boolean daiSwitchAllowed = AnagConfigurationHandler.isConfigurationAllowed("DAISwitch");
				final Boolean arDAIAllowed = AnagConfigurationHandler.isConfigurationAllowed("ARDaiAllowed");
				personaFisicaView.setNewDAIConfigAllowed(newDAIConfigAllowed);
				personaFisicaView.setDaiSwitchAllowed(daiSwitchAllowed);
				personaFisicaView.setArDAIConfigAllowed(arDAIAllowed);
				if(!newDAIConfigAllowed || !daiSwitchAllowed) {
					log4Debug.debug("XMLSoggettiHandler  ======= variaSoggettoXML  =====  Setting DAI (old Calculation) ========= ");
					attributiEsterniPFView.setDai(getDaiValue(personaFisicaView));
		    	}
				// Retain Attributi details - Segnalatore, Sconf values & SBJ_ELIGIBLE, Firma data di riferimento, Firma grafometrica
				retainAttributiPFData(attributiEsterniPFView, personaFisicaDBView.getAttributiEsterniPFView());
				//Retain Profil privacy information
				retainPrivacyProfil(personaFisicaView.getDatiPrivacyPFFiveLevelView(),personaFisicaDBView.getDatiPrivacyPFFiveLevelView(),"Semplice");
				personaFisicaView.setPersonaFisicaView(personaFisicaDBView);
				personaFisicaView.setHostToBeCalled(true);
				copyCodiceSoggettoValues(personaFisicaView,oldCodiceSoggettoPFView);
				if (codiceHostDB != null && (codiceHostDB.startsWith("1") || codiceHostDB.startsWith("2") ||
						codiceHostDB.indexOf(";1") != -1 || codiceHostDB.indexOf(";2") != -1) ) {
	        		personaFisicaView.setUpdateDiretto(true);
	        	} else {
	        		personaFisicaView.setUpdateDiretto(false);
	        	}
	        	if ( personaFisicaView.getDatiFiscaliPFView().getIndicatoreA96() == null ) {
	        		personaFisicaView.getDatiFiscaliPFView().setIndicatoreA96(Boolean.FALSE);
	            }
	            if ( personaFisicaView.getDatiFiscaliPFView().getIndicatoreA97() == null ) {
	            	personaFisicaView.getDatiFiscaliPFView().setIndicatoreA97(Boolean.FALSE);
	            }
	            personaFisicaView.setMotiv(getMotiv(personaFisicaView.getMotiv() , personaFisicaDBView.getMotiv()));
	            
	            // Retain Regime, W9,W9NoCertificate,W8,W8I,Fatca,CerficateRV
	            retainDatiFiscaliDetails(personaFisicaView.getDatiFiscaliPFView(), personaFisicaDBView.getDatiFiscaliPFView(),true, personaFisicaView.isAltreResidenzaTagExist());
	           
	            //Set Settore Value for PL associate with the PF 
	            RPFExecuterHelper rpfhelper=new RPFExecuterHelper();
	            SettorePLView settorePLView=rpfhelper.setSettoreForPFCollegate(soggettoId, personaFisicaView.getDatiFiscaliPFView(), personaFisicaDBView.getDatiFiscaliPFView(), attributiEsterniPFView);
	            personaFisicaView.setSettorePLView(settorePLView);
	            //Set Eventi
	            final Collection oldEventiCollection = personaFisicaDBView.getEventiView();
	            if(oldEventiCollection != null && !oldEventiCollection.isEmpty()){
	            	personaFisicaView.setEventiView(oldEventiCollection);
	            }
	          //Reatining canale prefereto value
	            personaFisicaView.setCanalePreferitoDataview(retainCanalePreferito(personaFisicaView.getCanalePreferitoDataview(),personaFisicaDBView.getCanalePreferitoDataview()));
	            personaFisicaView.setRecapNonDispAllowed(RecapitiNonDisponibileHelper.isRecapNonDispAllowedForLoginBank());
				return anagrafeManagerBeanHelper.variaSoggettoXML(personaFisicaView, soggettoId);
		} catch (final DatiAnagraficiDiscriminatorException e) {
			log4Debug.warnStackTrace(e);
			throw new BeanHelperException(e.getMessage());
		} catch (final DatiFiscaliDiscriminatorException e) {
			log4Debug.warnStackTrace(e);
			throw new BeanHelperException(e.getMessage());
		} catch (final ClassNotFoundException e) {
			log4Debug.warnStackTrace(e);
			throw new BeanHelperException(e.getMessage());
		} catch (final AttributiEsterniDiscriminatorException e) {
			log4Debug.warnStackTrace(e);
			throw new BeanHelperException(e.getMessage());
		} catch (ControlloDatiException e) {
			log4Debug.warnStackTrace(e);
			throw new BeanHelperException(e.getMessage());
		}
	}

	public String variaSoggettoXMLCompleto( final String xmlSoggetto,
			final Long soggettoId, final Long operationId ,final AnagrafeManagerBeanPFHelper anagrafeManagerBeanHelper )throws BeanHelperException, RemoteException {
		try {
			final PersonaFisicaView personaFisicaView = (PersonaFisicaView) anagrafeManagerBeanHelper.getViewAfterParsingPrivacyFiveLevelXML(xmlSoggetto);
		    final Properties properties = new Properties();
		    validateAnagraficiDetails(soggettoId, personaFisicaView.getDatiAnagraficiPFView(),
		    		personaFisicaView.getAttributiEsterniPFView());
		    final PersonaFisicaView personaFisicaDBView = (PersonaFisicaView) AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().getSoggetto(soggettoId, properties);
		    personaFisicaView.setRecapitiPFView(setRecapiti(personaFisicaView.getRecapitiPFView() ,personaFisicaDBView.getRecapitiPFView()));
		    //Set Document Id through XML has been handled in DatiDocumentiValidator Class.
			final CodiceSoggettoPFView oldCodiceSoggettoPFView = personaFisicaDBView.getCodiceSoggettoPFView();
			final String codiceHostDB = oldCodiceSoggettoPFView == null ? null : oldCodiceSoggettoPFView.getCodiceHost();
			personaFisicaView.setOpId(operationId);
			personaFisicaView.setId(soggettoId);
			
			final Boolean newDAIConfigAllowed = AnagConfigurationHandler.isConfigurationAllowed("NewDaiAllowed");
			final Boolean daiSwitchAllowed = AnagConfigurationHandler.isConfigurationAllowed("DAISwitch");
			final Boolean arDAIAllowed = AnagConfigurationHandler.isConfigurationAllowed("ARDaiAllowed");
			personaFisicaView.setNewDAIConfigAllowed(newDAIConfigAllowed);
			personaFisicaView.setDaiSwitchAllowed(daiSwitchAllowed);
			personaFisicaView.setArDAIConfigAllowed(arDAIAllowed);
			if(!newDAIConfigAllowed || !daiSwitchAllowed) {
				log4Debug.debug("XMLSoggettiHandler  ======= variaSoggettoXMLCompleto  =====  Setting DAI (old Calculation) ========= ");
				personaFisicaView.getAttributiEsterniPFView().setDai(getDaiValue(personaFisicaView));
			}
			
			// Retain Attributi details - Segnalatore & Sconf values
			retainAttributiPFData(personaFisicaView.getAttributiEsterniPFView(), personaFisicaDBView.getAttributiEsterniPFView());
			personaFisicaView.setPersonaFisicaView(personaFisicaDBView);
			personaFisicaView.setHostToBeCalled(true);
			copyCodiceSoggettoValues(personaFisicaView,oldCodiceSoggettoPFView);
			if (codiceHostDB != null && (codiceHostDB.startsWith("1") || codiceHostDB.startsWith("2") ||
					codiceHostDB.indexOf(";1") != -1 || codiceHostDB.indexOf(";2") != -1) ) {
	    		personaFisicaView.setUpdateDiretto(true);
	    	} else {
	    		personaFisicaView.setUpdateDiretto(false);
	    	}
	    	if ( personaFisicaView.getDatiFiscaliPFView().getIndicatoreA96() == null ) {
	    		personaFisicaView.getDatiFiscaliPFView().setIndicatoreA96(Boolean.FALSE);
	        }
	        if ( personaFisicaView.getDatiFiscaliPFView().getIndicatoreA97() == null ) {
	        	personaFisicaView.getDatiFiscaliPFView().setIndicatoreA97(Boolean.FALSE);
	        }
	        // Retain Regime, W9,W9NoCertificate,W8,W8I, Fatca
            retainDatiFiscaliDetails(personaFisicaView.getDatiFiscaliPFView(), personaFisicaDBView.getDatiFiscaliPFView(), true, personaFisicaView.isAltreResidenzaTagExist());
	        personaFisicaView.setMotiv(getMotiv( personaFisicaView.getMotiv() , personaFisicaDBView.getMotiv()));
	        //Set Eventi
            final Collection oldEventiCollection = personaFisicaDBView.getEventiView();
            if(oldEventiCollection != null && !oldEventiCollection.isEmpty()){
            	personaFisicaView.setEventiView(oldEventiCollection);
            }
          //Reatining canale prefereto value
            personaFisicaView.setCanalePreferitoDataview(retainCanalePreferito(personaFisicaView.getCanalePreferitoDataview(),personaFisicaDBView.getCanalePreferitoDataview()));
            personaFisicaView.setRecapNonDispAllowed(RecapitiNonDisponibileHelper.isRecapNonDispAllowedForLoginBank());
	        return anagrafeManagerBeanHelper.variaSoggettoXML(personaFisicaView, soggettoId);
		} catch (final DatiAnagraficiDiscriminatorException e) {
			log4Debug.warnStackTrace(e);
			throw new BeanHelperException(e.getMessage());
		} catch (final ClassNotFoundException e) {
			log4Debug.warnStackTrace(e);
			throw new BeanHelperException(e.getMessage());
		} catch (final AttributiEsterniDiscriminatorException e) {
			log4Debug.warnStackTrace(e);
			throw new BeanHelperException(e.getMessage());
		}
	}
	
		private void copyCodiceSoggettoValues( final PersonaFisicaView personaFisicaView, final CodiceSoggettoPFView oldCodiceSoggettoPFView ) {
		final Collection motivcol = personaFisicaView.getMotiv();
		final CodiceSoggettoPFView codiceSoggettoPFView = personaFisicaView.getCodiceSoggettoPFView();
		if (oldCodiceSoggettoPFView != null ) {
			final AnagrafeHelper anagrafeHelper = new AnagrafeHelper();
			if (!anagrafeHelper.checkForMotiv(motivcol, "DIPEN")){
				codiceSoggettoPFView.setCoddp(oldCodiceSoggettoPFView.getCoddp());
				codiceSoggettoPFView.setCodlm(oldCodiceSoggettoPFView.getCodlm());
			}
			if (!anagrafeHelper.checkForMotiv(motivcol, "SVILP")){
				codiceSoggettoPFView.setCodsv(oldCodiceSoggettoPFView.getCodsv());
			}
			if (!anagrafeHelper.checkForMotiv(motivcol, "PROMT")){
				codiceSoggettoPFView.setCodpr(oldCodiceSoggettoPFView.getCodpr());
			}
			if (!anagrafeHelper.checkForMotiv(motivcol, "FORNT")){
				codiceSoggettoPFView.setCodfo(oldCodiceSoggettoPFView.getCodfo());
			}
			codiceSoggettoPFView.setNdg(oldCodiceSoggettoPFView.getNdg());
			codiceSoggettoPFView.setCodiceHost(oldCodiceSoggettoPFView.getCodiceHost());
		}
	}

	public boolean isValidSoggetto( final Long soggettoId , final String descrizione ) throws BeanHelperException, RemoteException  {
		try {
			return new SoggettoDBAccessHelper().isValidSoggetto(soggettoId, descrizione);
		} catch (final GestoreSoggettoException e) {
			log4Debug.warnStackTrace(e);
			throw new BeanHelperException(e.getMessage());
		}
	}

	private void checkForNull( final Object object, final String errorCode ) throws BeanHelperException {
		if ( object == null ) {
			throw new BeanHelperException( new AnagrafeHelper().getMessage(errorCode));
		}
	}

	private boolean checkIsEqual( final Object one, final Object two ) {
		boolean isEqual = true;
		if (one != null) {
			if (!one.equals(two)) {
				isEqual = false;
			}
		} else if (two != null) {
			isEqual = false;
		}
		return isEqual;
	}

	private void checkIsNotEqualThrowException( final Object one, final Object two, final String errMsgKey ) throws BeanHelperException {
		if (one != null) {
			if (!one.equals(two)) {
				throw new BeanHelperException(new AnagrafeHelper().getMessage(errMsgKey));
			}
		} else if (two != null) {
			throw new BeanHelperException(new AnagrafeHelper().getMessage(errMsgKey));
		}
	}

	private void validateAnagraficiDetails(final Long soggetoId,
			final DatiAnagraficiPFView datiAnagraficiPFXMLView,
			final AttributiEsterniPFView attributiEsterniPFXMLView) throws BeanHelperException,
		RemoteException, DatiAnagraficiDiscriminatorException,AttributiEsterniDiscriminatorException, ClassNotFoundException {

		final DatiAnagraficiPFView datiAnagraficiPFDBView = getOperazioneAnagrafeManager().getDatiAnagraficiPF(soggetoId);
		int count = 0;
		if (datiAnagraficiPFDBView == null && datiAnagraficiPFXMLView != null) {
			if (datiAnagraficiPFXMLView.getNome() != null) {
				count++;
			}
			if (datiAnagraficiPFXMLView.getCognome() != null) {
				count++;
			}
			if (datiAnagraficiPFXMLView.getDataDiNascita() != null) {
				count++;
			}
			if (datiAnagraficiPFXMLView.getLuogoDiNascitaCitta() != null) {
				count++;
			}
		} else {
			if (!checkIsEqual(datiAnagraficiPFXMLView.getNome(), datiAnagraficiPFDBView.getNome())) {
				count++;
			}
			if (!checkIsEqual(datiAnagraficiPFXMLView.getCognome(), datiAnagraficiPFDBView.getCognome())) {
				count++;
			}
			if (!checkIsEqual(datiAnagraficiPFXMLView.getDataDiNascita(), datiAnagraficiPFDBView.getDataDiNascita())) {
				count++;
			}
			if (!checkIsEqual(datiAnagraficiPFXMLView.getLuogoDiNascitaCitta(), datiAnagraficiPFDBView.getLuogoDiNascitaCitta())) {
				count++;
			}
		}
		final AttributiEsterniPFView attributiEsterniPFDBView = (AttributiEsterniPFView)getOperazioneAnagrafeManager().getAttributiEsterniPF(soggetoId);
		if ( attributiEsterniPFDBView == null && attributiEsterniPFXMLView!= null &&
				attributiEsterniPFXMLView.getSesso() != null) {
			count++;
		} else {
			if (!checkIsEqual(attributiEsterniPFXMLView.getSesso(), attributiEsterniPFDBView.getSesso())) {
				count++;
			}
		}
		log4Debug.debug(" XMLSoggettiHandler: validateAnagraficiDetails: count:===>>",count);
		if (count > 3) {
			throw new BeanHelperException(new AnagrafeHelper().getMessage("ANAG-1580"));
		}
	}

	private void validateDatiAnagrafici( final DatiAnagraficiPFView datiAnagraficiPFXMLView, final Long soggetoId ) throws BeanHelperException, RemoteException, DatiAnagraficiDiscriminatorException {
		final DatiAnagraficiPFView datiAnagraficiPFDBView = getOperazioneAnagrafeManager().getDatiAnagraficiPF(soggetoId);
		checkForNull(datiAnagraficiPFDBView,"ANAG-1423");
		checkIsNotEqualThrowException(datiAnagraficiPFXMLView.getNome(), datiAnagraficiPFDBView.getNome(),"ANAG-1522");
		checkIsNotEqualThrowException(datiAnagraficiPFXMLView.getCognome(), datiAnagraficiPFDBView.getCognome(),"ANAG-1523");
		checkIsNotEqualThrowException(datiAnagraficiPFXMLView.getDataDiNascita(), datiAnagraficiPFDBView.getDataDiNascita(),"ANAG-1524");
		checkIsNotEqualThrowException(datiAnagraficiPFXMLView.getLuogoDiNascitaNazione(), datiAnagraficiPFDBView.getLuogoDiNascitaNazione(),"ANAG-1525");
		checkIsNotEqualThrowException(datiAnagraficiPFXMLView.getLuogoDiNascitaCitta(), datiAnagraficiPFDBView.getLuogoDiNascitaCitta(),"ANAG-1526");
	}

	private void validateCodiceFiscali( final DatiFiscaliPFView datiFiscaliPFXMLView, final Long soggettoId ) throws BeanHelperException, RemoteException, DatiFiscaliDiscriminatorException, ClassNotFoundException {
		final DatiFiscaliPFView datiFiscaliPFDBView = (DatiFiscaliPFView)getOperazioneAnagrafeManager().getDatiFiscaliPF(soggettoId);
		checkForNull(datiFiscaliPFDBView,"ANAG-1521");
		checkIsNotEqualThrowException(datiFiscaliPFDBView.getCodiceFiscali(), datiFiscaliPFXMLView.getCodiceFiscali(),"ANAG-1527");
	}

	private void validateSesso( final AttributiEsterniPFView attributiEsterniPFXMLView, final Long soggettoId ) throws BeanHelperException, RemoteException, AttributiEsterniDiscriminatorException, ClassNotFoundException {
		final AttributiEsterniPFView attributiEsterniPFDBView = (AttributiEsterniPFView)getOperazioneAnagrafeManager().getAttributiEsterniPF(soggettoId);
		checkForNull(attributiEsterniPFDBView, "ANAG-1528");
		checkIsNotEqualThrowException(attributiEsterniPFDBView.getSesso(), attributiEsterniPFXMLView.getSesso(),"ANAG-1528");
	}

	public Boolean getDaiValue( final PersonaFisicaView personaFisicaView ) throws RemoteException {
		try {
			new DAIHelper().calculateDaiForPF(personaFisicaView);
			return Boolean.FALSE;
		} catch (final ControlloDaiException e) {
			return Boolean.TRUE;
		}
	}

	public Boolean getDaiValue( final PlurintestazioneView plurintestazioneView ) throws RemoteException {
		try {
			new DAIHelper().calculateDaiForPL(plurintestazioneView);
			return Boolean.FALSE;
		} catch (final ControlloDaiException e) {
			return Boolean.TRUE;
		}
	}
	
	public Boolean getDaiValue( final AziendaView aziendaView ) throws RemoteException {
		try {
			new DAIHelper().calculateDaiForAZ(aziendaView);
			return Boolean.FALSE;
		} catch (final ControlloDaiException e) {
			return Boolean.TRUE;
		}
	}

	private Set getMotiv( final Collection motivXMLNew , final Collection motivDBOld  ) {
		final Set motiviAll = new HashSet();
		// PersonaFisicaView old view getMotiv() returns String motivCausale list
		// PersonaFisicaView new view getMotiv() returns MotivoDiCensimento view list
		motiviAll.addAll(motivXMLNew);
		motiviAll.addAll(getMotivObjList(motivDBOld));
		return motiviAll;
	}

	private Collection getMotivObjList( final Collection motivColl ) {
		 final List motivList = new ArrayList<MotivoDiCensimento>(1);
	     if ( motivColl != null ) {
	        final Iterator iterator = motivColl.iterator();
	        final int size = motivColl.size();
	        MotivoDiCensimento motivoDiCensimento = null;
	        for( int i = 0; i<size; i++ ) {
	        	motivoDiCensimento = new MotivoDiCensimento();
	        	motivoDiCensimento.setMotivoCausale((String)iterator.next());
	            motivList.add(motivoDiCensimento);
	        }
	     }
	    return motivList;
	}

	private Collection setRecapiti(Collection recapitiNew , final Collection recapitiOld  ) {
		final UtilHelper helper = new UtilHelper();
		if(recapitiNew == null){
			recapitiNew = new ArrayList();
		}
		if (recapitiOld!= null && !recapitiNew.containsAll(recapitiOld)) {
			final Iterator iteratorold = recapitiOld.iterator();
			for (int i = 0; i < recapitiOld.size(); i++) {
				final SoggettoRecapitiView soggettoRecapitiViewOld = (SoggettoRecapitiView) iteratorold.next();
				if ("Posta Elettronica".equals(soggettoRecapitiViewOld.getTipoRecapiti().getCausale())) {
					if (helper.isEightDigitNumericRiferimento(soggettoRecapitiViewOld.getRiferimento())) {
						log4Debug.debug("Posta Elettronica  ============ * digit Riferimento ============= ");
						if (recapitiNew.contains(soggettoRecapitiViewOld)) {
							recapitiNew.remove(soggettoRecapitiViewOld);
							recapitiNew.add(soggettoRecapitiViewOld);
						}else {
							recapitiNew.add(soggettoRecapitiViewOld);
						}
					}
				}

			}
		}
		return recapitiNew;
	}
	// this for retain Segnalatore old data in AttributiEsterni table .. bcoz Segnalatore field tag not availble in Attributi section
	/**Retains Segnalatore & Sconf values, Firma data di riferimento, Firma grafometrica, Titolo1, Titolo2, RegimePatrimoniale, Tds
	 * @param attributiEsterniXmlView
	 * @param attributiEsterniDBView
	 * void
	 */
	private void retainAttributiPFData(
			final AttributiEsterniPFView attributiEsterniXmlView,
			final AttributiEsterniPFView attributiEsterniDBView) {
		if(attributiEsterniDBView != null){
			attributiEsterniXmlView.setCosg(attributiEsterniDBView.getCosg());
			attributiEsterniXmlView.setSusg(attributiEsterniDBView.getSusg());
			attributiEsterniXmlView.setDisg(attributiEsterniDBView.getDisg());
			attributiEsterniXmlView.setDfsg(attributiEsterniDBView.getDfsg());
			attributiEsterniXmlView.setSegdp(attributiEsterniDBView.getSegdp());
			attributiEsterniXmlView.setSconf(attributiEsterniDBView.getSconf());
			attributiEsterniXmlView.setSBJ_ELIGIBLE(attributiEsterniDBView.getSBJ_ELIGIBLE());
			// Recently Added To retain in Varia XML.
			attributiEsterniXmlView.setFirmagraf(attributiEsterniDBView.getFirmagraf());
			attributiEsterniXmlView.setFirmadata(attributiEsterniDBView.getFirmadata());
			attributiEsterniXmlView.setTitolo1(attributiEsterniDBView.getTitolo1());
			attributiEsterniXmlView.setTitolo2(attributiEsterniDBView.getTitolo2());
			attributiEsterniXmlView.setRegimePatrimoniale(attributiEsterniDBView.getRegimePatrimoniale());
			attributiEsterniXmlView.setTds(attributiEsterniDBView.getTds());
			attributiEsterniXmlView.setSettorediattivita(attributiEsterniDBView.getSettorediattivita());
			// To retian Identification Data in XML
			attributiEsterniXmlView.setIDENT(attributiEsterniDBView.getIDENT());
			// To retain socio bse and socioshb
			log4Debug.debug(">>>>> retainAttributiPFData >>>> SocioBSE :::::::",attributiEsterniDBView.getSocioBSE());
			log4Debug.debug(">>>>> retainAttributiPFData >>>> SocioSHB :::::::",attributiEsterniDBView.getSocioSHB());
			attributiEsterniXmlView.setSocioBSE(attributiEsterniDBView.getSocioBSE());
			attributiEsterniXmlView.setSocioSHB(attributiEsterniDBView.getSocioSHB());
		}
	}
	
	private void setRegime( final DatiFiscaliPFView datiFiscaliPFNewView , final DatiFiscaliPFView datiFiscaliPFOldView  ) {
 		if(datiFiscaliPFOldView != null ){
 			if(datiFiscaliPFOldView.getRegimeDeiMinimi() != null && datiFiscaliPFOldView.getRegimeDeiMinimi()){
 				datiFiscaliPFNewView.setRegimeDeiMinimi(datiFiscaliPFOldView.getRegimeDeiMinimi());
 			}
 			if(datiFiscaliPFOldView.getRegimeDataAttivazione() != null){
 				datiFiscaliPFNewView.setRegimeDataAttivazione(datiFiscaliPFOldView.getRegimeDataAttivazione());
 			}
 			if(datiFiscaliPFOldView.getRegimeDataRevoca() != null){
 				datiFiscaliPFNewView.setRegimeDataRevoca(datiFiscaliPFOldView.getRegimeDataRevoca());
 			}
 			if(datiFiscaliPFOldView.getRegimeDataScadenza() != null){
 				datiFiscaliPFNewView.setRegimeDataScadenza(datiFiscaliPFOldView.getRegimeDataScadenza());
 			}
 		}
	}
	private OperazioneAnagrafeManager getOperazioneAnagrafeManager() {
		if ( operazioneAnagrafeManager == null ) {
			operazioneAnagrafeManager = OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager();
		}
		return operazioneAnagrafeManager;
	}
	
	public String variaSoggettoAZXML(final String xmlSoggetto, final Long soggettoId, final Long operationId, final AnagrafeManagerBeanAZHelper anagrafeManagerBeanHelper) throws RemoteException, BeanHelperException {
		final AziendaView aziendaXMLView = (AziendaView)anagrafeManagerBeanHelper.getViewAfterParsingPrivacyFiveLevelXML(xmlSoggetto);
		final Properties properties = new Properties();
		final AziendaView aziendaDBView = (AziendaView) AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().getSoggetto(soggettoId, properties);
		validateDatiAnagraficiAZ(aziendaXMLView.getDatiAnagraficiAZView(), aziendaDBView.getDatiAnagraficiAZView());
		validateTipoSoggettoAZ(aziendaXMLView.getTipoSoggettoDesc(),aziendaDBView.getTipoSoggettoDesc());
		validateCodiceFiscaliAndPartitaIVA(aziendaXMLView, aziendaDBView.getDatiFiscaliAZView(),aziendaXMLView.getTipoSoggettoDesc());
		aziendaXMLView.setRecapitiView(setRecapiti(aziendaXMLView.getRecapitiView(),aziendaDBView.getRecapitiView()));
		aziendaXMLView.setOpId(operationId);
		aziendaXMLView.setId(soggettoId);
		final AttributiEsterniAZView attributiEsterniAZXMLView = aziendaXMLView.getAttributiEsterniAZView();
		
		final Boolean newDAIConfigAllowed = AnagConfigurationHandler.isConfigurationAllowed("NewDaiAllowed");
		final Boolean daiSwitchAllowed = AnagConfigurationHandler.isConfigurationAllowed("DAISwitch");
		final Boolean arDAIAllowed = AnagConfigurationHandler.isConfigurationAllowed("ARDaiAllowed");
		aziendaXMLView.setNewDAIConfigAllowed(newDAIConfigAllowed);
		aziendaXMLView.setDaiSwitchAllowed(daiSwitchAllowed);
		aziendaXMLView.setArDAIConfigAllowed(arDAIAllowed);
		if(!newDAIConfigAllowed || !daiSwitchAllowed) {
			log4Debug.debug("XMLSoggettiHandler  ======= variaSoggettoAZXML  =====  setting DAI (old Calculation) ========= ");
			attributiEsterniAZXMLView.setDai(getDaiValue(aziendaXMLView));
		}
		aziendaXMLView.setMotiv(getMotiv(aziendaXMLView.getMotiv(), aziendaDBView.getMotiv()));
		
		aziendaXMLView.setOldAziendaView(aziendaDBView);
		aziendaXMLView.setHostToBeCalled(true);
		
		if(aziendaXMLView.getDatiFiscaliAZView().getIndicatoreA96() == null){
			aziendaXMLView.getDatiFiscaliAZView().setIndicatoreA96(Boolean.FALSE);
		}
		if(aziendaXMLView.getDatiFiscaliAZView().getIndicatoreA97() == null){
			aziendaXMLView.getDatiFiscaliAZView().setIndicatoreA97(Boolean.FALSE);
		}
		
		// Retaining Attributi Details - Segnalatore, Sconf
		retainAttributiDetailsOfAZ(attributiEsterniAZXMLView, aziendaDBView.getAttributiEsterniAZView());
		//Retain Ditta Individuale Privacy Details- Profil Level Privacy
		retainPrivacyProfil(aziendaXMLView.getDatiPrivacyAZFiveLevelView(),aziendaDBView.getDatiPrivacyAZFiveLevelView(),aziendaXMLView.getTipoSoggettoDesc());
		// Retaing DatiFiscali Section Details - Regime Data, W9, W8, W8I, Fatca
		retainDatiFiscaliDetails(aziendaXMLView.getDatiFiscaliAZView(), aziendaDBView.getDatiFiscaliAZView(),false, aziendaXMLView.isAltreResidenzaTagExist());
		
		// Eventi Data Setting
		final Collection oldEventiCollection = aziendaDBView.getEventiView();
		log4Debug.debug("aziendaXMLView.getEventiView() ============  ",aziendaXMLView.getEventiView() != null ? aziendaXMLView.getEventiView().size() : "NULL");
		if(oldEventiCollection != null && !oldEventiCollection.isEmpty()){
			aziendaXMLView.setEventiView(oldEventiCollection);
		}
		
		//Codice Soggetto Data Setting
		setCodiceSoggettoValues(aziendaXMLView,aziendaDBView.getCodiceSoggettoAZView());
		
		//Reatining canale prefereto value
		aziendaXMLView.setCanalePreferitoDataview(retainCanalePreferito(aziendaXMLView.getCanalePreferitoDataview(),aziendaXMLView.getCanalePreferitoDataview()));
		aziendaXMLView.setRecapNDAllowed(RecapitiNonDisponibileHelper.isRecapNonDispAllowedForLoginBank());
		return anagrafeManagerBeanHelper.variaSoggettoXML(aziendaXMLView, soggettoId);
	}
	
	/**
	 * To retain value for canale preferito
	 * @param newCanalePreferitoDataview
	 * @param oldCanalePreferitoDataview
	 */
	private CanalePreferitoDataView retainCanalePreferito(CanalePreferitoDataView newCanalePreferitoDataview,final CanalePreferitoDataView oldCanalePreferitoDataview) {
		if(oldCanalePreferitoDataview != null && newCanalePreferitoDataview == null){
			newCanalePreferitoDataview = new CanalePreferitoDataView();
			newCanalePreferitoDataview.setCanaleValue(oldCanalePreferitoDataview.getCanaleValue());
			newCanalePreferitoDataview.setTipoRecapiti(oldCanalePreferitoDataview.getTipoRecapiti());
			newCanalePreferitoDataview.setCanale(oldCanalePreferitoDataview.getCanale());
		}  
		if(newCanalePreferitoDataview !=null && newCanalePreferitoDataview.getCanale()!=null && "NessunaPreferenza".equals(newCanalePreferitoDataview.getCanale().getCausale())){
			newCanalePreferitoDataview =null;
		}
		return newCanalePreferitoDataview;
	}

	private void validateDatiAnagraficiAZ(final DatiAnagraficiAZView datiAnagraficiAZViewNew, final DatiAnagraficiAZView datiAnagraficiAZDBView) throws BeanHelperException {
		checkForNull(datiAnagraficiAZDBView,"ANAG-1423");
		checkIsNotEqualThrowException(datiAnagraficiAZViewNew.getDenominazione(), datiAnagraficiAZDBView.getDenominazione(),"ANAG-1709");
		checkIsNotEqualThrowException(datiAnagraficiAZViewNew.getDataDiCostituzione(), datiAnagraficiAZDBView.getDataDiCostituzione(),"ANAG-1711");
		if(datiAnagraficiAZViewNew.getNazioneCostituzione() != null){
			checkIsNotEqualThrowException(datiAnagraficiAZViewNew.getNazioneCostituzione(), datiAnagraficiAZDBView.getNazioneCostituzione(),"ANAG-1712");
		}else if(datiAnagraficiAZDBView.getNazioneCostituzione() != null){
			datiAnagraficiAZViewNew.setNazioneCostituzione(datiAnagraficiAZDBView.getNazioneCostituzione());
		}
		if(datiAnagraficiAZViewNew.getCittaCostituzione() != null){
			checkIsNotEqualThrowException(datiAnagraficiAZViewNew.getCittaCostituzione(), datiAnagraficiAZDBView.getCittaCostituzione(),"ANAG-1712");
		}else if(datiAnagraficiAZDBView.getCittaCostituzione() != null){
			datiAnagraficiAZViewNew.setCittaCostituzione(datiAnagraficiAZDBView.getCittaCostituzione());
		}
	}
	
	private void validateCodiceFiscaliAndPartitaIVA(final AziendaView aziendaXMLView, final DatiFiscaliPFView datiFiscaliAZDBView,final String tipoSoggetto) throws BeanHelperException{
		checkForNull(datiFiscaliAZDBView,"ANAG-1714");
		final DatiFiscaliPFView datiFiscaliAZXMLView = aziendaXMLView.getDatiFiscaliAZView();
		if(!"Ditta individuale".equals(tipoSoggetto)){
			checkIsNotEqualThrowException(datiFiscaliAZXMLView.getCodiceFiscali() , datiFiscaliAZDBView.getCodiceFiscali(),"ANAG-1715");
		}
		final boolean eComm = aziendaXMLView.getAttributiEsterniAZView() != null && aziendaXMLView.getAttributiEsterniAZView().getEcomm() != null ? aziendaXMLView.getAttributiEsterniAZView().getEcomm().booleanValue() : false;
		// if tipoSoggetto is Ente privato and eComm is true and partitaIVA in DB is null and partitaIVA from xml is not null .. validation need to skip
		// if tipoSoggetto is Ente privato and eComm is flase and partitaIVA in DB is not null and partitaIVA from xml is null .. validation need to skip
		// if tipoSoggetto is Ente privato and eComm is flase and partitaIVA in DB is null and partitaIVA from xml is not null .. validation need to skip 
		if(!tipoSoggetto.equals("Ente privato")) {
			checkIsNotEqualThrowException(datiFiscaliAZXMLView.getPartitaIva(), datiFiscaliAZDBView.getPartitaIva(),"ANAG-1716");
		} else if((eComm && datiFiscaliAZDBView.getPartitaIva()  != null) || (!eComm && datiFiscaliAZDBView.getPartitaIva() != null && datiFiscaliAZXMLView.getPartitaIva() != null)) {
			checkIsNotEqualThrowException(datiFiscaliAZXMLView.getPartitaIva(), datiFiscaliAZDBView.getPartitaIva(),"ANAG-1716");
		}
	}
	
	
	/**
	 * Setting Segnalatore and Sconf from AZ DB view to XMl az view
	 * @param attributiEsterniAZXMLView
	 * @param attributiEsterniAZDBView
	 * void
	 */
	private void retainAttributiDetailsOfAZ(final AttributiEsterniAZView attributiEsterniAZXMLView, final AttributiEsterniAZView attributiEsterniAZDBView){
		if(attributiEsterniAZDBView != null){
			// Retain Segnalatore
			attributiEsterniAZXMLView.setCosg(attributiEsterniAZDBView.getCosg());
			attributiEsterniAZXMLView.setSusg(attributiEsterniAZDBView.getSusg());
			attributiEsterniAZXMLView.setDisg(attributiEsterniAZDBView.getDisg());
			attributiEsterniAZXMLView.setDfsg(attributiEsterniAZDBView.getDfsg());
			attributiEsterniAZXMLView.setSegdp(attributiEsterniAZDBView.getSegdp());
			attributiEsterniAZXMLView.setPOLIZZA_SELLA_LIFE(attributiEsterniAZDBView.getPOLIZZA_SELLA_LIFE());
			// Retain Sconf
			log4Debug.debug("=========sconfFromDB value setting to new xml view  ===============",attributiEsterniAZDBView.getSconf());
			attributiEsterniAZXMLView.setSconf(attributiEsterniAZDBView.getSconf());   //attributiEsterniAZDBView.getSconf() != null && !"true".equals(attributiEsterniAZDBView.getSconf())
			log4Debug.debug(">>>>> retainAttributiDetailsOfAZ >>>> SocioBSE :::::::",attributiEsterniAZDBView.getSocioBSE());
			log4Debug.debug(">>>>> retainAttributiDetailsOfAZ >>>> SocioSHB :::::::",attributiEsterniAZDBView.getSocioSHB());
			attributiEsterniAZXMLView.setSocioBSE(attributiEsterniAZDBView.getSocioBSE());
			attributiEsterniAZXMLView.setSocioSHB(attributiEsterniAZDBView.getSocioSHB());
		}
	}
	
	private void setCodiceSoggettoValues(final AziendaView aziendaView, final CodiceSoggettoAZView oldCodiceSoggettoAZView){
		final CodiceSoggettoAZView codiceSoggettoAZView = aziendaView.getCodiceSoggettoAZView();
		if(oldCodiceSoggettoAZView != null){
			codiceSoggettoAZView.setCodiceHost(oldCodiceSoggettoAZView.getCodiceHost());
			codiceSoggettoAZView.setNdg(oldCodiceSoggettoAZView.getNdg());
			codiceSoggettoAZView.setCab(oldCodiceSoggettoAZView.getCab());
			codiceSoggettoAZView.setCedb(oldCodiceSoggettoAZView.getCedb());
			codiceSoggettoAZView.setBK_CODE(oldCodiceSoggettoAZView.getBK_CODE());
		}
	}
	
	private void validateTipoSoggettoAZ(final String xmlTipoSoggetto, final String dbTipoSoggetto) throws BeanHelperException{
		checkForNull(dbTipoSoggetto,"ANAG-1713");
		checkIsNotEqualThrowException(xmlTipoSoggetto, dbTipoSoggetto, "ANAG-1713");
	}
	
	/**
	 * Retaing DatiFiscali Section Details - Regime Data, W9, W8, W8I, Fatca
	 * @param datiFiscaliPFNewView
	 * @param datiFiscaliPFOldView
	 * void
	 */
	private void retainDatiFiscaliDetails( final DatiFiscaliPFView datiFiscaliPFNewView , final DatiFiscaliPFView datiFiscaliPFOldView, final boolean isPFDetails, final boolean isAltreTagPresent  ) {
		if(datiFiscaliPFOldView != null){
			// Retain Regime Data
			setRegime(datiFiscaliPFNewView, datiFiscaliPFOldView);
			// Retain W9 Data
			datiFiscaliPFNewView.setW9(datiFiscaliPFOldView.getW9());
			datiFiscaliPFNewView.setW8(datiFiscaliPFOldView.getW8());
			datiFiscaliPFNewView.setW8i(datiFiscaliPFOldView.getW8i());
			datiFiscaliPFNewView.setW9NoReasonCertificate(datiFiscaliPFOldView.getW9NoReasonCertificate());
			// Retain Fatca
			datiFiscaliPFNewView.setFatca_soggetto_usa(datiFiscaliPFOldView.getFatca_soggetto_usa());
			datiFiscaliPFNewView.setFatca_status(datiFiscaliPFOldView.getFatca_status());
			datiFiscaliPFNewView.setFatca_status_calculato(datiFiscaliPFOldView.getFatca_status_calculato());// Varia XML To retain Fatca status calculato
			datiFiscaliPFNewView.setPresenza_indizi(datiFiscaliPFOldView.getPresenza_indizi());
			// RetainCertificate RV (Mainly for PF case - bcz we dont have the tag for PF)
			if(isPFDetails && datiFiscaliPFNewView.getCertRV() == null) {
				datiFiscaliPFNewView.setCertRV(datiFiscaliPFOldView.getCertRV());
			}
			// Retaining the altre residenza fiscali data when none of the altre residenzafiscale tag not send in varia
			if(!isAltreTagPresent) {
				datiFiscaliPFNewView.setResidenteFiscali2(datiFiscaliPFOldView.getResidenteFiscali2());
				datiFiscaliPFNewView.setResidenteFiscali3(datiFiscaliPFOldView.getResidenteFiscali3());
				datiFiscaliPFNewView.setCdEst2(datiFiscaliPFOldView.getCdEst2());
				datiFiscaliPFNewView.setCdEst3(datiFiscaliPFOldView.getCdEst3());
			}
		}
	}
	//Retain value if null is passed during varia- PF & AZ(Ditta Individuale)
	private void retainPrivacyProfil(final DatiPrivacyPFFiveLevelView datiPrivacyFiveLevelView,final DatiPrivacyPFFiveLevelView datiPrivacyFiveLevelViewDB,String tipoSoggetto)
	{
		final AnagrafeHelper anagrafeHelper = new AnagrafeHelper();
		final boolean isApplicable = anagrafeHelper.datiPrivacyProfilIsApplicable(tipoSoggetto);
		if(isApplicable)
		{
			if(datiPrivacyFiveLevelViewDB!=null && datiPrivacyFiveLevelView!=null && datiPrivacyFiveLevelView.getProfil()==null)
			{
				datiPrivacyFiveLevelView.setProfil(datiPrivacyFiveLevelViewDB.getProfil());
			}
		}
	}
}
