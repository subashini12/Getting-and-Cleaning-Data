package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.DateHandler;
import it.sella.gestione_flussi.Flusso;
import it.sella.gestione_flussi.GestioneFlussoException;
import it.sella.gestione_flussi.GestoreFlussoHelper;
import it.sella.gestione_flussi.GestoreFlussoHelperFactory;
import it.sella.net.ftp.FTPReader;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Vector;

import javax.naming.NamingException;

public class ISE_Impl {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(ISE_Impl.class);

    public void updateEventiEDipct() throws OperazioneAnagrafeManagerException {
        String ftpConnectionPool = null;
        String path = null;
        String fileName = null;
        String jndiName = null;
        FTPReader ftpReader = null;
        BufferedReader bufferedReader = null;
        try {
            ftpConnectionPool = CommonPropertiesHandler.getValueFromProperty("ANAG_FTP_POOL");
            path = CommonPropertiesHandler.getValueFromProperty("FLUSSO_FILE_PATH");
            fileName = new DateHandler().formatDate(new Timestamp(System.currentTimeMillis()), "ddMMyyyy") + "eventi.txt";
            jndiName = CommonPropertiesHandler.getValueFromProperty("ANAGRAFEHOMENAME");
            ftpReader = new FTPReader(ftpConnectionPool, path, fileName);
            bufferedReader = new BufferedReader(ftpReader);
            final Vector inputsToFlusso = new Vector();
            String readLine = bufferedReader.readLine();
            while (readLine != null) {
                inputsToFlusso.add(readLine);
                readLine = bufferedReader.readLine();
            }
            final Date currentDate = new Date();
            final String flussoName = "ANAGEVENTI" + currentDate;
            final GestoreFlussoHelper gestoreFlussoHelper = GestoreFlussoHelperFactory.getInstance().getGestoreFlussoHelper();
            final Flusso flusso = gestoreFlussoHelper.creaFlusso(flussoName, inputsToFlusso, jndiName);
            flusso.getFlussoInfo().setFlussoReadCommitted(true);
            log4Debug.info(">>>>>>>>>>>>>>>> FLUSSO " , flussoName , " STARTED AT " , currentDate);
            gestoreFlussoHelper.gestisciFlusso(flusso);
        } catch (final IOException e) {
            log4Debug.severeStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage());
        } catch (final NamingException e) {
            log4Debug.severeStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage());
        } catch (final GestioneFlussoException e) {
            log4Debug.severeStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage());
        } finally {
            try {
                if (ftpReader != null) {
					ftpReader.close();
				}
                if (bufferedReader != null) {
					bufferedReader.close();
				}
            } catch (final IOException e) {
                log4Debug.severeStackTrace(e);
            }
        }
    }
    
}
