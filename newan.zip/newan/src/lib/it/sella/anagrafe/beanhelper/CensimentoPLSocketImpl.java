package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.BeanHelperException;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.OperazioneCensimentoException;
import it.sella.anagrafe.SocketHelperException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.factory.AttributiEsterniFactory;
import it.sella.anagrafe.factory.FactoryException;
import it.sella.anagrafe.factory.PlurintestazioneFactory;
import it.sella.anagrafe.factory.PlurintestazioneFactoryException;
import it.sella.anagrafe.factory.PlurintestazioneViewImpl;
import it.sella.anagrafe.implementation.SistemiEsterni;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.GestoreAmministratoriBancaHelper;
import it.sella.anagrafe.util.MapperHelperException;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.anagrafe.util.socket.SocketHelper;
import it.sella.anagrafe.view.PlurintestazioneView;
import it.sella.anagrafe.view.SoggettoView;

import java.rmi.RemoteException;
import java.util.Hashtable;

public class CensimentoPLSocketImpl extends CensimentoPLImpl {

    public Long performCensimentoH2OandSocket(final SoggettoView soggettoView,final StringBuffer logMsg,final StringBuffer logForHost) throws RemoteException, BeanHelperException {
        try {
            final PlurintestazioneFactory plurintestazioneFactory = (PlurintestazioneFactory) getAnagrafeFactory(soggettoView.getClass());
            final PlurintestazioneView plurintestazioneView = (PlurintestazioneView) soggettoView;
            plurintestazioneView.setRecapitiPLView(getRecapitiAfterRemovingEmpty(plurintestazioneView.getRecapitiPLView()));
            final Long soggettoId = plurintestazioneFactory.createPlurintestazione(plurintestazioneView);
            logMsg.append("<DataWrite>");
            logMsg.append(plurintestazioneFactory.getLogData(plurintestazioneView));
            soggettoView.setId(soggettoId);
            new SistemiEsterni().updateAccount(soggettoId, plurintestazioneView.getSoggettoIds()); // to align collegatiabilitati in acfw
            if (("OK".equals(CommonPropertiesHandler.getValueFromProperty(SecurityHandler.getLoginBancaId().toString())) || checkForTestoMemo(plurintestazioneView.getMemoView(), "HOST")) && plurintestazioneView.isHostToBeCalled() || plurintestazioneView.isSocketToBeCalled()) {
            	final Hashtable socketTable = new SocketHelper().censimentoSocketPL(plurintestazioneView, soggettoId);
            	buildSocketHostLog(socketTable, logForHost);
                final String art136Value = new GestoreAmministratoriBancaHelper().alignAmministratoriBancaMotivForPL(soggettoId, 
                		plurintestazioneView.getSoggettoIds(),plurintestazioneView.getCodiceSoggettoPLView() != null ? 
                				plurintestazioneView.getCodiceSoggettoPLView().getCodiceHost() : null,
                				logForHost,plurintestazioneView.getOpId(),plurintestazioneView.isHostCodeFromSecurity());
                if( art136Value != null ) {
                	logMsg.append("<ART136_VALORE>").append(art136Value).append("</ART136_VALORE>");	
                }
                final String bollinoBluValue = new AttributiEsterniFactory().updateBollinoBluForPl(plurintestazioneView.getSoggettoIds(),
                		plurintestazioneView.getId(), plurintestazioneView.getOpId(),
                		plurintestazioneView.getCodiceSoggettoPLView() != null ? 
                				plurintestazioneView.getCodiceSoggettoPLView().getCodiceHost() : null,plurintestazioneView.isHostCodeFromSecurity());                
                if( bollinoBluValue != null ) {
                	logMsg.append("<BBLU_VALORE>").append(bollinoBluValue).append("</BBLU_VALORE>");	
                }
            }
            logMsg.append("</DataWrite>");
            return soggettoId;
        } catch (final PlurintestazioneFactoryException e) {
        	handleException(e, logMsg);
        } catch (final OperazioneCensimentoException e) {
        	handleException(e, logMsg);
        } catch (final FactoryException e) {
        	handleException(e, logMsg);
        } catch (final SocketHelperException e) {
        	handleException(e, logMsg);
        } catch (final MapperHelperException e) {
        	handleMapperException(e, logMsg, logForHost);
        } catch (final SubSystemHandlerException e) {
        	handleException(e, logMsg);
		} catch (final ControlloDatiException e) {
        	handleException(e, logMsg);
		}
		return null;
    }

    public void performCensimentoModificaH2OandSocket(final SoggettoView soggettoView,final StringBuffer logMsg,final StringBuffer logForHost) throws RemoteException, BeanHelperException {
        try {
            final PlurintestazioneView plurintestazioneView = (PlurintestazioneView) soggettoView;
            final PlurintestazioneFactory plurintestazioneFactory = (PlurintestazioneFactory) getAnagrafeFactory(soggettoView.getClass());
            logMsg.append("<DataView>");
            logMsg.append(plurintestazioneFactory.getLogData(plurintestazioneView.getOldPlurintestazioneView()));
            logMsg.append("</DataView>");
            plurintestazioneFactory.setPlurintestazione(plurintestazioneView);
            logMsg.append("<DataWrite>");
            logMsg.append(plurintestazioneFactory.getLogData(plurintestazioneView));
            new SistemiEsterni().updateAccount(soggettoView.getId(), getCollegatiAbilitati(plurintestazioneView)); //to align acfw for abilitati
            if (("OK".equals(CommonPropertiesHandler.getValueFromProperty(SecurityHandler.getLoginBancaId().toString())) || checkForTestoMemo(plurintestazioneView.getMemoView(), "HOST")) && plurintestazioneView.isHostToBeCalled() || plurintestazioneView.isSocketToBeCalled()) {
            	Hashtable socketTable = null;
                if (plurintestazioneView.getCodiceSoggettoPLView() != null && plurintestazioneView.getCodiceSoggettoPLView().getCodiceHost() != null) {
                	final boolean isSocketCreateCalled = ((PlurintestazioneViewImpl)soggettoView).isSocketCreateToCalled();
                	socketTable = new SocketHelper().modificaSocketPL((PlurintestazioneView)soggettoView, soggettoView.getId(), isSocketCreateCalled, isSocketCreateCalled );
                	buildSocketHostLog(socketTable, logForHost);
                    logForHost.append("^").append(update610MessageForCifratiPL(plurintestazioneView));
                } else {
                	socketTable = new SocketHelper().censimentoSocketPL(plurintestazioneView, plurintestazioneView.getId());
                	buildSocketHostLog(socketTable, logForHost);
                }
                final String art136Value = new GestoreAmministratoriBancaHelper().alignAmministratoriBancaMotivForPL(plurintestazioneView.getId(), 
                		plurintestazioneView.getSoggettoIds(),plurintestazioneView.getCodiceSoggettoPLView() != null ? 
                				plurintestazioneView.getCodiceSoggettoPLView().getCodiceHost() : null,
                				logForHost,plurintestazioneView.getOpId(),plurintestazioneView.isHostCodeFromSecurity());
                if(art136Value != null) {
					logMsg.append("<ART136_VALORE>").append(art136Value).append("</ART136_VALORE>");
				}
                final String bollinoBluValue = new AttributiEsterniFactory().updateBollinoBluForPl(plurintestazioneView.getSoggettoIds(),
                		plurintestazioneView.getId(), plurintestazioneView.getOpId(),
                		plurintestazioneView.getCodiceSoggettoPLView() != null ? 
                				plurintestazioneView.getCodiceSoggettoPLView().getCodiceHost() : null,plurintestazioneView.isHostCodeFromSecurity());                
                if(bollinoBluValue != null) {
					logMsg.append("<BBLU_VALORE>").append(bollinoBluValue).append("</BBLU_VALORE>");
				}
            }
            logMsg.append("</DataWrite>");
        } catch (final PlurintestazioneFactoryException e) {
        	handleException(e, logMsg);
        } catch (final GestoreAnagrafeException e) {
        	handleException(e, logMsg);
        } catch (final OperazioneCensimentoException e) {
        	handleException(e, logMsg);
        } catch (final FactoryException e) {
        	handleException(e, logMsg);
        } catch (final SocketHelperException e) {
        	handleException(e, logMsg);
        } catch (final MapperHelperException e) {
        	handleMapperException(e, logMsg, logForHost);
        } catch (final ControlloDatiException e) {
        	handleException(e, logMsg);
		}
    }
	
}
