package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.AnagrafeDAIException;
import it.sella.anagrafe.BeanHelperException;
import it.sella.anagrafe.GestoreCollegamentoException;
import it.sella.anagrafe.MapperFactory;
import it.sella.anagrafe.OperazioneCensimentoException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.dai.DaiRegoleSoggettohelper;
import it.sella.anagrafe.dai.GestoreAPIDAICalculatorHelper;
import it.sella.anagrafe.dbaccess.CollegamentoDBAccessHelper;
import it.sella.anagrafe.discriminator.CollegamentoException;
import it.sella.anagrafe.factory.PersonaFisicaFactory;
import it.sella.anagrafe.factory.PersonaFisicaFactoryException;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.anagrafe.implementation.SistemiEsterni;
import it.sella.anagrafe.ivaapplicazione.ApplicazioneIvaCalculator;
import it.sella.anagrafe.pf.DatiFiscaliPFView;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.FATCACalculatorHelperForTitolare;
import it.sella.anagrafe.util.GestoreAmministratoriBancaHelper;
import it.sella.anagrafe.util.MapperHelperException;
import it.sella.anagrafe.util.PFHelper;
import it.sella.anagrafe.util.PortafogliazioneClientelaAccessHelper;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.anagrafe.util.StringHandler;
import it.sella.anagrafe.view.PersonaFisicaView;
import it.sella.anagrafe.view.SoggettoView;
import it.sella.prtc.PortfolioException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;

public class CensimentoPFHostImpl extends CensimentoPFImpl {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CensimentoPFHostImpl.class);
	
    public Long performCensimentoH2OandHOST( final SoggettoView soggettoView, final StringBuffer logMsg, final StringBuffer logForHost ) throws RemoteException, BeanHelperException {
        try {
        	final PersonaFisicaFactory personaFisicaFactory = (PersonaFisicaFactory) getAnagrafeFactory(soggettoView.getClass());
        	final PersonaFisicaView personaFisicaView = (PersonaFisicaView) soggettoView;
        	personaFisicaView.setRecapitiPFView(getRecapitiAfterRemovingEmpty(personaFisicaView.getRecapitiPFView()));
        	setRepalcedCittaWithSpaceForComma(personaFisicaView.getIndirizziView());
        	//To calcualte VAT if applicable
        	new ApplicazioneIvaCalculator().calculateVATForPF(personaFisicaView.getDatiFiscaliPFView());
        	if(personaFisicaView.getCanalePreferitoDataview() !=null && personaFisicaView.getCanalePreferitoDataview().getCanale()!=null && "NessunaPreferenza".equals(personaFisicaView.getCanalePreferitoDataview().getCanale().getCausale())){
        		personaFisicaView.setCanalePreferitoDataview(null);
    		}
        	// DAI Regole Calculation
        	new DaiRegoleSoggettohelper().setDaiRegoleData(personaFisicaView);
        	final Long soggettoId = personaFisicaFactory.createPersonaFisica(personaFisicaView);
            logMsg.append("<DataWrite>");
            logMsg.append(personaFisicaFactory.getLogData(personaFisicaView));
            // aligning acfw for collegati abilitati
            final Collection abilitatiIds = new PFHelper().getAllowedPFSoggettiForACFW(personaFisicaView);
            new SistemiEsterni().updateAccount(soggettoId, abilitatiIds);
            final Collection motivCollection = personaFisicaView.getMotiv();
            soggettoView.setId(soggettoId);
           if ( isAllowedHostCallForPF(motivCollection) &&
        		   ("OK".equals(CommonPropertiesHandler.getValueFromProperty(SecurityHandler.getLoginBancaId().toString())) ||
        		     checkForTestoMemo(personaFisicaView.getMemoView(), "HOST")) && personaFisicaView.isHostToBeCalled()) {
                logForHost.append(MapperFactory.getMapper().censimentoMapperPF(personaFisicaView, soggettoId));
                
				
                final String art136Value = new GestoreAmministratoriBancaHelper().alignAmministratoriBancaMotivBasedOnLinkedViewsForPF(soggettoId,
                		personaFisicaView.getCollegateViews(),personaFisicaView.getCodiceSoggettoPFView() != null ?
                				personaFisicaView.getCodiceSoggettoPFView().getCodiceHost() : null,
                				logForHost,personaFisicaView.getOpId(),personaFisicaView.isHostCodeFromSecurity());
                if ( art136Value != null ) {
                	logMsg.append("<ART136_VALORE>").append(art136Value).append("</ART136_VALORE>");
                }
                
                if(personaFisicaView.getPromotoreIds() !=null && !personaFisicaView.getPromotoreIds().isEmpty()){
                	callToPortafogliazioneCliente(personaFisicaView);
                }
           }
           logMsg.append("</DataWrite>");
           return soggettoId;
        } catch (final PersonaFisicaFactoryException e) {
        	handleException(e, logMsg);
        } catch (final OperazioneCensimentoException e) {
        	handleException(e, logMsg);
        } catch (final MapperHelperException e) {
        	handleMapperException(e, logMsg, logForHost);
        } catch (final SubSystemHandlerException e) {
        	handleException(e, logMsg);
		} catch (final ControlloDatiException e) {
        	handleException(e, logMsg);
		} catch (final AnagrafeDAIException e) {
			handleException(e, logMsg);
		} 
		return null;
    }

    /**
     *To register in PortafogliazioneClientela in censimento via Creation
     * @param personaFisicaView
     * @throws PortfolioException
     */
    private void callToPortafogliazioneCliente(final PersonaFisicaView personaFisicaView)
    {
    		final String ottoCifre = personaFisicaView.getCodiceSoggettoPFView().getCodiceHost();
    		final String clientLabel = personaFisicaView.getDatiAnagraficiPFView().getCognome().concat(" ").concat(personaFisicaView.getDatiAnagraficiPFView().getNome());
    		new PortafogliazioneClientelaAccessHelper().registerClientWithPromoter(personaFisicaView.getId(), personaFisicaView.getPromotoreIds(), ottoCifre,clientLabel);
    }

    public void performCensimentoModificaH2OandHOST( final SoggettoView soggettoView, final StringBuffer logMsg, final StringBuffer logForHost ) throws RemoteException, BeanHelperException {
        try {
        	final PersonaFisicaView personaFisicaView = (PersonaFisicaView) soggettoView;
        	final PersonaFisicaFactory personaFisicaFactory = (PersonaFisicaFactory) getAnagrafeFactory(soggettoView.getClass());
        	final Long soggettoId = soggettoView.getId();
        	//Removing Tipo_Recapiti with valore as "empty" 
        	personaFisicaView.setRecapitiPFView(getRecapitiAfterRemovingEmpty(personaFisicaView.getRecapitiPFView()));
        	logMsg.append("<DataView>");
            logMsg.append(personaFisicaFactory.getLogData(personaFisicaView.getPersonaFisicaView()));
            logMsg.append("</DataView>");
            setRepalcedCittaWithSpaceForComma(personaFisicaView.getIndirizziView());
        	//To calcualte VAT if applicable
            new ApplicazioneIvaCalculator().calculateVATForPF(personaFisicaView.getDatiFiscaliPFView());
            // DAI Regole Calculation
            new DaiRegoleSoggettohelper().setDaiRegoleData(personaFisicaView);
            personaFisicaFactory.setPersonaFisica(personaFisicaView);
            logMsg.append("<DataWrite>");
            logMsg.append(personaFisicaFactory.getLogData(personaFisicaView));
            FATCACalculatorHelperForTitolare.setTitolareDetailsToLinkedAZ(personaFisicaView);
            final Collection modifiedAbilitatiIds = new PFHelper().getAllowedPFSoggettiForACFW(personaFisicaView);
            new SistemiEsterni().updateAccount(soggettoId, modifiedAbilitatiIds);
            
            boolean mapperCall = false;
           /* if ( isAllowedHostCallForPF(personaFisicaView.getMotiv()) &&
            		("OK".equals(CommonPropertiesHandler.getValueFromProperty(SecurityHandler.getLoginBancaId().toString())) ||
                    checkForTestoMemo(personaFisicaView.getMemoView(), "HOST")) && personaFisicaView.isHostToBeCalled()) {
            	mapperCall = true;
                if ( personaFisicaView.getCodiceSoggettoPFView().getCodiceHost() != null ) {
                    logForHost.append(MapperFactory.getMapper().modificaMapperPF(personaFisicaView));
                    logForHost.append("^").append(update610MessageForCifratiPF(personaFisicaView));
                } else {
                    logForHost.append(MapperFactory.getMapper().censimentoMapperPF(personaFisicaView, soggettoView.getId()));
                }
                final String art136Value = new GestoreAmministratoriBancaHelper().alignAmministratoriBancaMotivBasedOnLinkedViewsForPF(soggettoId,
                		personaFisicaView.getCollegateViews(),personaFisicaView.getCodiceSoggettoPFView() != null ?
                				personaFisicaView.getCodiceSoggettoPFView().getCodiceHost() : null,
                				logForHost,personaFisicaView.getOpId(),personaFisicaView.isHostCodeFromSecurity());
                if ( art136Value != null ) {
                	logMsg.append("<ART136_VALORE>").append(art136Value).append("</ART136_VALORE>");
                }
              
            }*/
            if(personaFisicaView.isNewDAIConfigAllowed() == null || !personaFisicaView.isNewDAIConfigAllowed()) {
            	updateDai(soggettoId,personaFisicaView);
            }
			if (mapperCall) {
            	doHostCallForPrincipleSoggetto(personaFisicaView); // DAI Updated PricipleSoggetto's (PL's)
            }
            //Method to delete from an_tr_doc_eventi and insert into anse_tr_doc_eventi for extracommuntario
            deleteDocEventi4ExtraCommuntario( personaFisicaView );
            
            // If the CodiceFiscali Changed and the Subject is acting as Titolare .. Update the DittaIndividule Subject's Codice Fiscali.
            processTitolareCFToDittaIndSubjects(personaFisicaView); // Oracle procedure
            
            logMsg.append("</DataWrite>");
        } catch (final PersonaFisicaFactoryException e) {
        	handleException(e, logMsg);
        } catch (final OperazioneCensimentoException e) {
        	handleException(e, logMsg);
        } /*catch (final GestoreCodiciSoggettoException e) {
        	handleException(e, logMsg);
        } catch (final MapperHelperException e) {
        	handleMapperException(e, logMsg, logForHost);
        }*/ catch (final OperazioneAnagrafeManagerException e) {
        	handleException(e, logMsg);
        }  catch (final SubSystemHandlerException e) {
        	handleException(e, logMsg);
		} catch (final ControlloDatiException e) {
        	handleException(e, logMsg);
		} catch (final AnagrafeDAIException e) {
			handleException(e, logMsg);
		} 
    }
    
	/**
	 * While Updating CodiceFisacli For PF, and PF is acting as Titolare to any DittaInd AZ subject.. then Updating the new CodiceFiscali of to the AZ DI Subjects.
	 * @param personaFisicaView
	 * @throws RemoteException 
	 * @throws GestoreCollegamentoException 
	 * @throws CollegamentoException 
	 */
	private void processTitolareCFToDittaIndSubjects(final PersonaFisicaView personaFisicaView) throws RemoteException {
		try {
			if (personaFisicaView.getId() != null) {
				final DatiFiscaliPFView datiFiscaliPFViewNew = personaFisicaView.getDatiFiscaliPFView();
				final DatiFiscaliPFView datiFiscaliPFViewOld = personaFisicaView.getPersonaFisicaView().getDatiFiscaliPFView();
				if (datiFiscaliPFViewNew != null && datiFiscaliPFViewOld != null) {
					if (!new StringHandler().checkForEquality(datiFiscaliPFViewOld.getCodiceFiscali(), datiFiscaliPFViewNew.getCodiceFiscali())) {
						final Collection principleIdOfTitolareMotiv = new CollegamentoDBAccessHelper().getSoggettoPrincipale(personaFisicaView.getId(), "TITOL");
						if(principleIdOfTitolareMotiv != null && !principleIdOfTitolareMotiv.isEmpty()) {
							final Long [] soggettoIds = (Long[]) principleIdOfTitolareMotiv.toArray(new Long[principleIdOfTitolareMotiv.size()]);
							new CollegamentoDBAccessHelper().updateCodiceFiscaliForSoggetto(soggettoIds, datiFiscaliPFViewNew.getCodiceFiscali(), personaFisicaView.getOpId());
						}
					}
				}
			}
		} catch (final GestoreCollegamentoException e) {
			log4Debug.debugStackTrace(e);
		} catch (final CollegamentoException e) {
			log4Debug.debugStackTrace(e);
		}
	}
	
	/**
	 * This Method to Update DAI For PricipleSoggettos's of PF.
	 * @param personaFisicaView
	 * @throws RemoteException
	 * @throws AnagrafeDAIException
	 */
	private void doHostCallForPrincipleSoggetto(final PersonaFisicaView personaFisicaView) throws RemoteException, AnagrafeDAIException {
		log4Debug.debug("updateDAIForPrinciplesoggetto  ===================  CALL");
		if (personaFisicaView.isNewDAIConfigAllowed() != null && personaFisicaView.isNewDAIConfigAllowed()) {
			final Collection<Long> principleSoggettoPL = personaFisicaView.getDaiPrincipleSoggettoPL();
			log4Debug.debug("updateDAIForPrinciplesoggetto  ===================  principleSoggettoPL ========== ", principleSoggettoPL);
			if (principleSoggettoPL != null && !principleSoggettoPL.isEmpty()) {
				for (final Long plSoggettoId : principleSoggettoPL) {
					new GestoreAPIDAICalculatorHelper().updateDAIWithHost(plSoggettoId, Boolean.FALSE, true);
				}
			}
		}
	}
}

