package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.BeanHelperException;
import it.sella.anagrafe.az.DatiAnagraficiAZView;
import it.sella.anagrafe.factory.AltriSoggettoFactory;
import it.sella.anagrafe.factory.AltriTipiSoggettoFactoryException;
import it.sella.anagrafe.factory.AziendaFactory;
import it.sella.anagrafe.factory.AziendaFactoryException;
import it.sella.anagrafe.factory.DipendenteFactory;
import it.sella.anagrafe.factory.DipendenteFactoryException;
import it.sella.anagrafe.factory.PersonaFisicaFactory;
import it.sella.anagrafe.factory.PersonaFisicaFactoryException;
import it.sella.anagrafe.factory.PlurintestazioneFactory;
import it.sella.anagrafe.factory.PlurintestazioneFactoryException;
import it.sella.anagrafe.factory.PromotoreFactory;
import it.sella.anagrafe.factory.PromotoreFactoryException;
import it.sella.anagrafe.factory.SviluppatoreFactory;
import it.sella.anagrafe.factory.SviluppatoreFactoryException;
import it.sella.anagrafe.pf.CodiceSoggettoPFView;
import it.sella.anagrafe.util.StringHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Properties;

public class AnagrafeManagerBeanRicercaHelper extends AnagrafeManagerBeanPFRicercaHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AnagrafeManagerBeanRicercaHelper.class);

    public AnagrafeManagerBeanRicercaHelper() {
        logMsg = new StringBuffer();
        logForHost = new StringBuffer();
    }

    public Collection ricercaAltriSoggetto(final Properties properties) throws RemoteException, BeanHelperException {
        try {
            return new AltriSoggettoFactory().listAltriSoggetto(properties);
        } catch (final AltriTipiSoggettoFactoryException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    public Collection ricercaCodiceSoggettoPF(final Properties properties) throws RemoteException, BeanHelperException {
        try {
            final CodiceSoggettoPFView codiceSoggettoPFView = (CodiceSoggettoPFView) properties.get("View");
            return new PersonaFisicaFactory().findByNDG(codiceSoggettoPFView) ;
        } catch (final PersonaFisicaFactoryException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    public Collection ricercaDipendente(final Properties properties) throws RemoteException, BeanHelperException {
        try {
            return new DipendenteFactory().listDipendente(properties);
        } catch (final DipendenteFactoryException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    public Collection ricercaPromotore(final Properties properties) throws RemoteException, BeanHelperException {
        try {
            return  new PromotoreFactory().listPromotore(properties) ;
        } catch (final PromotoreFactoryException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    public Collection ricercaSviluppatore(final Properties properties) throws RemoteException, BeanHelperException {
        try {
            return new SviluppatoreFactory().listSviluppatore(properties);
        } catch (final SviluppatoreFactoryException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    public Collection ricercaCodiceSoggettoPL(final Properties properties) throws RemoteException, BeanHelperException {
        try {
            return new PlurintestazioneFactory().listPlurintestazione(properties);
        } catch (final PlurintestazioneFactoryException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    public Collection ricercaAZ(final Properties properties) throws RemoteException, BeanHelperException {
        try {
        	final StringHandler stringHandler = new StringHandler();
            final AziendaFactory aziendaFactory = new AziendaFactory();
            final DatiAnagraficiAZView datiView = (DatiAnagraficiAZView) properties.get("View");
            datiView.setNormalizedName(stringHandler.getNormalisedString(datiView.getDenominazione()));
            final Collection ricercaColl = aziendaFactory.listAzienda(properties);
            logMsg.append("<NormalizedNome>" + StringHandler.encodeXMLTagValue(datiView.getNormalizedName()) + "%" + "</NormalizedNome>");
            logMsg.append(datiView.getDataDiCostituzione());
            return ricercaColl;
        } catch (final AziendaFactoryException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }

    }
}
