package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.BeanHelperException;
import it.sella.anagrafe.GestoreSoggettoException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.bpaautomaticcens.PFCensimentoXMLGenerator;
import it.sella.anagrafe.common.MotivoDiCensimento;
import it.sella.anagrafe.dbaccess.DBAccessHelper;
import it.sella.anagrafe.dbaccess.TipoSoggettoHandler;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.Vector;

public class CommonHelper extends DBAccessHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CommonHelper.class);

    protected String getOutputXMLMessage( final String errorMessage, final Long soggettoId ) {
    	final StringBuffer soggettoBuffer = new StringBuffer();
    	soggettoBuffer.append("\n<RISPOSTA>\n");
        if ( soggettoId != null ) {
            soggettoBuffer.append("<ESITO>0</ESITO>\n");
            soggettoBuffer.append("<SOGGETTO_ID>").append(soggettoId.toString()).append("</SOGGETTO_ID>\n");
        } else {
            buildErrroTag(errorMessage, soggettoBuffer,"1");
        }
        soggettoBuffer.append("</RISPOSTA>\n");
        log4Debug.debug("CommonHelper: getOutputXMLMessage: soggettoBuffer:===>>",soggettoBuffer);
        return soggettoBuffer.toString();
    }
    /**
     * @param errorMessage
     * @param soggettoId
     * @param documentiColl
     * @return String
     * 
     */
    protected String getOutputXMLMessageForPF( final String errorMessage, final Long soggettoId, final Collection documentiColl) {
    	final StringBuffer soggettoBuffer = new StringBuffer();
    	soggettoBuffer.append("\n<RISPOSTA>\n");
        if ( soggettoId != null ) {
            soggettoBuffer.append("<ESITO>0</ESITO>\n");
            soggettoBuffer.append("<SOGGETTO_ID>").append(soggettoId.toString()).append("</SOGGETTO_ID>\n");
            if(documentiColl != null && !documentiColl.isEmpty()){
            	final String outputXMLDocumenti = new PFCensimentoXMLGenerator().getOutputXMLMessageForDocumenti(documentiColl);
            	soggettoBuffer.append(outputXMLDocumenti);
            }
        } else {
            buildErrroTag(errorMessage, soggettoBuffer,"1");
        }
        soggettoBuffer.append("</RISPOSTA>\n");
        log4Debug.debug("CommonHelper: getOutputXMLMessage: soggettoBuffer:===>>",soggettoBuffer);
        return soggettoBuffer.toString();
    }
    
    public String getOutputXMLForValidateXML( final String errorMessage, final String esitoNumber ) {
    	final StringBuffer soggettoBuffer = new StringBuffer();
    	soggettoBuffer.append("\n<RISPOSTA>\n");

        if ( errorMessage == null ) {
            soggettoBuffer.append("<ESITO>").append(esitoNumber).append("</ESITO>\n");
        } else {
            buildErrroTag(errorMessage, soggettoBuffer,esitoNumber);
        }
        soggettoBuffer.append("</RISPOSTA>\n");
        log4Debug.debug("CommonHelper: getOutputXMLMessage: soggettoBuffer:===>>",soggettoBuffer);
        return soggettoBuffer.toString();
    }

	private void buildErrroTag(final String errorMessage,
			final StringBuffer soggettoBuffer, final String esitoNumber) {
		String[] errorCodeMsg;
		soggettoBuffer.append("<ESITO>").append(esitoNumber).append("</ESITO>\n");
		final StringTokenizer errorMsgs = new StringTokenizer(errorMessage, "^");
		for ( int i = errorMsgs.countTokens(); i > 0; i-- ) {
			errorCodeMsg = errorMsgs.nextToken().split("\\$");
			if(errorCodeMsg.length >1){
				soggettoBuffer.append("<ERRORCODE>").append(errorCodeMsg[0]).append("</ERRORCODE>\n");
				soggettoBuffer.append("<ERRORMSG>").append(errorCodeMsg[1]).append("</ERRORMSG>\n");
			}else{
				soggettoBuffer.append("<ERRORMSG>").append(errorCodeMsg[0]).append("</ERRORMSG>\n");
			}
		}
	}

    protected Collection getAllBanks() throws RemoteException,SQLException {
        Connection connection = null;
        PreparedStatement preparedstatement = null;
        ResultSet resultset = null;
        final ArrayList output = new ArrayList(1);
        try {
            connection = getConnection();
            preparedstatement = connection.prepareStatement("select SO_SOGGETTO_ID from AN_MA_SOGGETTO where SO_TIPO_SOGGETTO_ID = ?");
            final long bancaTipoSoggettoId = new TipoSoggettoHandler().getTipoSoggetto("Banca proprietaria del sistema").longValue();
            preparedstatement.setLong(1, bancaTipoSoggettoId);
            for( resultset = preparedstatement.executeQuery(); resultset.next(); output.add(Long.valueOf(resultset.getLong("SO_SOGGETTO_ID"))) ) {
				;
			}
        } catch (final GestoreSoggettoException gestoresoggettoexception) {
            log4Debug.severeStackTrace(gestoresoggettoexception);
        } finally {
            cleanup(connection, preparedstatement, resultset);
        }
        return output;
    }
    
    protected Long getClassificazioneId( final String causale, final String parentCausale ) throws RemoteException,BeanHelperException {
    	try {
			return ClassificazioneHandler.getClassificazioneView(causale,parentCausale).getId();
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new BeanHelperException(e.getMessage());
		}    
    }

    protected Collection removeUTBOLFromMotivCollection( final Collection motivCollection ) {
    	final Collection returnCollection = new Vector(1);
    	final Iterator motivIterator = motivCollection.iterator();
    	final int size = motivCollection.size();
    	MotivoDiCensimento motivoDiCensimento = null;
        for( int i = 0; i < size; i++ ) {
            motivoDiCensimento = (MotivoDiCensimento) motivIterator.next();
            if ( !"UTBOL".equals(motivoDiCensimento.getMotivoCausale()) ) {
            	returnCollection.add(motivoDiCensimento);
            }
        }
        return returnCollection;
    }
}
