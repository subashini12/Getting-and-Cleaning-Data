package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.BeanHelperException;
import it.sella.anagrafe.factory.DipendenteFactory;
import it.sella.anagrafe.factory.DipendenteFactoryException;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.view.DipendenteView;
import it.sella.anagrafe.view.SoggettoView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Properties;

public class AnagrafeManagerBeanDipendenteHelper extends AnagrafeManagerBeanHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AnagrafeManagerBeanDipendenteHelper.class);

    public AnagrafeManagerBeanDipendenteHelper() {
        logMsg = new StringBuffer();
        logForHost = new StringBuffer();
    }

    public Long performCensimento( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException {
        try {
        	final DipendenteFactory dipendenteFactory = (DipendenteFactory) getAnagrafeFactory(soggettoView.getClass());
            return dipendenteFactory.createDipendente((DipendenteView) soggettoView);
        } catch (final DipendenteFactoryException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    public void performCensimentoModifica( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException{
        throw new UnsupportedOperationException(new AnagrafeHelper().getMessage("ANAG-1304"));
    }


    public Long performCensimentoSH( final SoggettoView soggettoView) throws RemoteException, BeanHelperException {
        try {
            final DipendenteFactory dipendenteFactory = (DipendenteFactory) getAnagrafeFactory(soggettoView.getClass());
            return dipendenteFactory.createDipendente((DipendenteView) soggettoView);
        } catch (final DipendenteFactoryException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    public void performCensimentoModificaSH(final SoggettoView soggettoView) throws RemoteException, BeanHelperException{
        throw new UnsupportedOperationException(new AnagrafeHelper().getMessage("ANAG-1304"));
    }

    public SoggettoView getSoggetto(final Long soggettoId, final Properties properties) throws RemoteException, BeanHelperException {
        try {
            final DipendenteFactory dipendenteFactory = (DipendenteFactory) getAnagrafeFactory(DipendenteView.class);
            return dipendenteFactory.getDipendente(soggettoId);
        } catch (final DipendenteFactoryException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    public String createSoggetto(final SoggettoView soggettoView, final String parserError, final String banca, final String operationCode) throws RemoteException, BeanHelperException {
        throw new UnsupportedOperationException(new AnagrafeHelper().getMessage("ANAG-1304"));
    }

    public String createSoggettoWithHost( final SoggettoView soggettoView, final String parserError, final String banca, final String operationCode ) throws RemoteException, BeanHelperException {
        throw new UnsupportedOperationException(new AnagrafeHelper().getMessage("ANAG-1304"));
    }
    
    public SoggettoView getViewAfterParsing(final String xmlSoggetto) throws BeanHelperException {
    	throw new UnsupportedOperationException(new AnagrafeHelper().getMessage("ANAG-1304"));
    }
    
    public SoggettoView getViewAfterParsingPrivacyFiveLevelXML(final String xmlSoggetto) throws BeanHelperException {
    	throw new UnsupportedOperationException(new AnagrafeHelper().getMessage("ANAG-1304"));
    }

	public Hashtable validateSoggettoXML( final SoggettoView soggettoView ) throws BeanHelperException, RemoteException {
		throw new UnsupportedOperationException(new AnagrafeHelper().getMessage("ANAG-1304"));
	}
}
