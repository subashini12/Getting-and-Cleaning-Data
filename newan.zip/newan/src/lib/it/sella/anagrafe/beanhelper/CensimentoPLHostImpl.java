package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.BeanHelperException;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.MapperFactory;
import it.sella.anagrafe.OperazioneCensimentoException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.dai.DaiRegoleSoggettohelper;
import it.sella.anagrafe.discriminator.DatiFiscaliDiscriminatorException;
import it.sella.anagrafe.factory.AttributiEsterniFactory;
import it.sella.anagrafe.factory.FactoryException;
import it.sella.anagrafe.factory.PlurintestazioneFactory;
import it.sella.anagrafe.factory.PlurintestazioneFactoryException;
import it.sella.anagrafe.implementation.SistemiEsterni;
import it.sella.anagrafe.ivaapplicazione.ApplicazioneIvaCalculator;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.GestoreAmministratoriBancaHelper;
import it.sella.anagrafe.util.MapperHelperException;
import it.sella.anagrafe.util.PortafogliazioneClientelaAccessHelper;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.anagrafe.view.PlurintestazioneView;
import it.sella.anagrafe.view.SoggettoView;
import it.sella.prtc.PortfolioException;

import java.rmi.RemoteException;

public class CensimentoPLHostImpl extends CensimentoPLImpl {
	

    /**
     * @param soggettoView
     * @param logMsg
     * @param logForHost
     * @return
     * @throws RemoteException
     * @throws BeanHelperException
     */
    public Long performCensimentoH2OandHOST(final SoggettoView soggettoView,final StringBuffer logMsg,
    		final StringBuffer logForHost) throws RemoteException, BeanHelperException {
        try {
            final PlurintestazioneFactory plurintestazioneFactory = (PlurintestazioneFactory) getAnagrafeFactory(soggettoView.getClass());
            final PlurintestazioneView plurintestazioneView = (PlurintestazioneView) soggettoView;
            plurintestazioneView.setRecapitiPLView(getRecapitiAfterRemovingEmpty(plurintestazioneView.getRecapitiPLView()));
        	//To calcualte VAT if applicable
            new ApplicazioneIvaCalculator().calcVATForPL(plurintestazioneView);
            if( plurintestazioneView.getCanalePreferitoDataview() !=null && plurintestazioneView.getCanalePreferitoDataview().getCanale()!=null && "NessunaPreferenza".equals(plurintestazioneView.getCanalePreferitoDataview().getCanale().getCausale())){
            	plurintestazioneView.setCanalePreferitoDataview(null);
    		}
            
            // NEW DAI CALCULATION
            new DaiRegoleSoggettohelper().calculateNewAttributiDAIForPL(plurintestazioneView);

            final Long soggettoId = plurintestazioneFactory.createPlurintestazione(plurintestazioneView);
            logMsg.append("<DataWrite>");
            logMsg.append(plurintestazioneFactory.getLogData(plurintestazioneView));
            soggettoView.setId(soggettoId);
            new SistemiEsterni().updateAccount(soggettoId, plurintestazioneView.getSoggettoIds()); // to align collegatiabilitati in acfw
            if (("OK".equals(CommonPropertiesHandler.getValueFromProperty(SecurityHandler.getLoginBancaId().toString())) || 
            		checkForTestoMemo(plurintestazioneView.getMemoView(), "HOST")) && plurintestazioneView.isHostToBeCalled()) {
                logForHost.append(MapperFactory.getMapper().censimentoMapperPL(plurintestazioneView, soggettoId));
                
                
                final String art136Value = new GestoreAmministratoriBancaHelper().alignAmministratoriBancaMotivForPL(soggettoId, 
                		plurintestazioneView.getSoggettoIds(),plurintestazioneView.getCodiceSoggettoPLView() != null ? 
                				plurintestazioneView.getCodiceSoggettoPLView().getCodiceHost() : null,
                				logForHost,plurintestazioneView.getOpId(),plurintestazioneView.isHostCodeFromSecurity());
                if(art136Value != null) {
					logMsg.append("<ART136_VALORE>").append(art136Value).append("</ART136_VALORE>");
				}
                final String bollinoBluValue = new AttributiEsterniFactory().updateBollinoBluForPl(plurintestazioneView.getSoggettoIds(),
                		plurintestazioneView.getId(), plurintestazioneView.getOpId(),plurintestazioneView.getCodiceSoggettoPLView() != null ? 
                				plurintestazioneView.getCodiceSoggettoPLView().getCodiceHost() : null,
                				plurintestazioneView.isHostCodeFromSecurity());                
                if(bollinoBluValue != null) {
					logMsg.append("<BBLU_VALORE>").append(bollinoBluValue).append("</BBLU_VALORE>");
				}
                if(plurintestazioneView.getPromotoreIds() !=null && !plurintestazioneView.getPromotoreIds().isEmpty()){
                	callToPortafogliazioneCliente(plurintestazioneView);
                }
            }
           
            logMsg.append("</DataWrite>");
            return soggettoId;
        } catch (final PlurintestazioneFactoryException e) {
        	handleException(e, logMsg);
        } catch (final OperazioneCensimentoException e) {
        	handleException(e, logMsg);
        } catch (final FactoryException e) {
        	handleException(e, logMsg);
        } catch (final MapperHelperException e) {
        	handleMapperException(e, logMsg, logForHost);
        }  catch (final SubSystemHandlerException e) {
        	handleException(e, logMsg);
		} catch (final ControlloDatiException e) {
        	handleException(e, logMsg);
		} catch (final DatiFiscaliDiscriminatorException e) {
			handleException(e, logMsg);
		} 
		return null;
    }
    
        
    public void performCensimentoModificaH2OandHOST(final SoggettoView soggettoView,final StringBuffer logMsg,
    		final StringBuffer logForHost) throws RemoteException, BeanHelperException {
        try {
            final PlurintestazioneView plurintestazioneView = (PlurintestazioneView) soggettoView;
            final PlurintestazioneFactory plurintestazioneFactory = (PlurintestazioneFactory) getAnagrafeFactory(soggettoView.getClass());
            //Removing empty recapiti values
            plurintestazioneView.setRecapitiPLView(getRecapitiAfterRemovingEmpty(plurintestazioneView.getRecapitiPLView()));
            logMsg.append("<DataView>");
            logMsg.append(plurintestazioneFactory.getLogData(plurintestazioneView.getOldPlurintestazioneView()));
            logMsg.append("</DataView>");
        	//To calcualte VAT if applicable
            new ApplicazioneIvaCalculator().calcVATForPL(plurintestazioneView);
            
            // NEW DAI Calculation
            new DaiRegoleSoggettohelper().calculateNewAttributiDAIForPL(plurintestazioneView);
            
            plurintestazioneFactory.setPlurintestazione(plurintestazioneView);
            logMsg.append("<DataWrite>");
            logMsg.append(plurintestazioneFactory.getLogData(plurintestazioneView));
            new SistemiEsterni().updateAccount(soggettoView.getId(), getCollegatiAbilitati(plurintestazioneView)); //to align acfw for abilitati
            if (("OK".equals(CommonPropertiesHandler.getValueFromProperty(SecurityHandler.getLoginBancaId().toString())) || 
            		checkForTestoMemo(plurintestazioneView.getMemoView(), "HOST")) && plurintestazioneView.isHostToBeCalled()) {
                if (plurintestazioneView.getCodiceSoggettoPLView() != null && 
                		plurintestazioneView.getCodiceSoggettoPLView().getCodiceHost() != null) {
                    logForHost.append(MapperFactory.getMapper().modificaMapperPL((PlurintestazioneView) soggettoView));
                    logForHost.append("^").append(update610MessageForCifratiPL(plurintestazioneView));
                } else {
                    logForHost.append(MapperFactory.getMapper().censimentoMapperPL(plurintestazioneView, plurintestazioneView.getId()));
                }
                
                final String art136Value = new GestoreAmministratoriBancaHelper().alignAmministratoriBancaMotivForPL(plurintestazioneView.getId(), 
                		plurintestazioneView.getSoggettoIds(),plurintestazioneView.getCodiceSoggettoPLView() != null ? 
                				plurintestazioneView.getCodiceSoggettoPLView().getCodiceHost() : null,
                				logForHost,plurintestazioneView.getOpId(),plurintestazioneView.isHostCodeFromSecurity());
                if( art136Value != null ) {
                	logMsg.append("<ART136_VALORE>").append(art136Value).append("</ART136_VALORE>");	
                }
                final String bollinoBluValue = new AttributiEsterniFactory().updateBollinoBluForPl(plurintestazioneView.getSoggettoIds(),
                		plurintestazioneView.getId(), plurintestazioneView.getOpId(),
                		plurintestazioneView.getCodiceSoggettoPLView() != null ? 
                				plurintestazioneView.getCodiceSoggettoPLView().getCodiceHost() : null,
                				plurintestazioneView.isHostCodeFromSecurity());                
                if( bollinoBluValue != null ) {
                	logMsg.append("<BBLU_VALORE>").append(bollinoBluValue).append("</BBLU_VALORE>");	
                }
            }
            logMsg.append("</DataWrite>");
        } catch (final PlurintestazioneFactoryException e) {
        	handleException(e, logMsg);
        } catch (final GestoreAnagrafeException e) {
        	handleException(e, logMsg);
        } catch (final OperazioneCensimentoException e) {
        	handleException(e, logMsg);
        } catch (final FactoryException e) {
        	handleException(e, logMsg);
        } catch (final MapperHelperException e) {
        	handleMapperException(e, logMsg, logForHost);
        } catch (final ControlloDatiException e) {
        	handleException(e, logMsg);
		} catch (final DatiFiscaliDiscriminatorException e) {
			handleException(e, logMsg);
		}
    }
    /**
     * To register in PortafogliazioneClientela in censimento via Creation
     * @param personaFisicaView
     * @throws PortfolioException
     */
    private void callToPortafogliazioneCliente(final PlurintestazioneView plurintestazioneView)
     {
         	final String ottoCifre = plurintestazioneView.getCodiceSoggettoPLView().getCodiceHost();
         	final String clientLabel = plurintestazioneView.getAttributiEsterniPLView().getInstr();
         	new PortafogliazioneClientelaAccessHelper().registerClientWithPromoter(plurintestazioneView.getId(), plurintestazioneView.getPromotoreIds(), ottoCifre,clientLabel);
    }
    
}
