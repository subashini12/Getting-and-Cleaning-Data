package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.BeanHelperException;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.controllo.ControlloDatiPFException;
import it.sella.anagrafe.dbaccess.DatiFiscaliUtil;
import it.sella.anagrafe.factory.AziendaFactory;
import it.sella.anagrafe.factory.AziendaFactoryException;
import it.sella.anagrafe.implementation.CensimentoAZFiveLevelParser;
import it.sella.anagrafe.implementation.CensimentoAziendaParser;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.AnagrafeLoggerHelper;
import it.sella.anagrafe.util.CSSEHandler;
import it.sella.anagrafe.util.ClienteClassificazioneUtilHelper;
import it.sella.anagrafe.util.IHelperConstants;
import it.sella.anagrafe.util.UtilHelper;
import it.sella.anagrafe.validator.RecapitiNonDisponibileHelper;
import it.sella.anagrafe.validator.SoggettoValidator;
import it.sella.anagrafe.view.AziendaView;
import it.sella.anagrafe.view.ClienteClassificazioneView;
import it.sella.anagrafe.view.FatturatoView;
import it.sella.anagrafe.view.SoggettoView;
import it.sella.logserver.LoggerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.IOException;
import java.io.StringReader;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Map;
import java.util.Properties;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

public class AnagrafeManagerBeanAZHelper extends AnagrafeManagerBeanHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AnagrafeManagerBeanAZHelper.class);
    private static final String RATING_SS = "RatingSS";

    public AnagrafeManagerBeanAZHelper() {
        logMsg = new StringBuffer();
        logForHost = new StringBuffer();
    }

    public String createSoggetto( final SoggettoView aziendaView, final String parserError, final String banca, final String operationCode ) throws RemoteException, BeanHelperException {
    	return createSoggettoPrivacyFiveAndSixLevel(aziendaView, parserError, operationCode);
    }

    public String createSoggettoWithHost( final SoggettoView soggettView, final String parserError, final String banca, final String operationCode ) throws RemoteException, BeanHelperException {
    	return createSoggettoPrivacyFiveAndSixLevelWithHost(soggettView, parserError, operationCode);
    }

    public Long performCensimento( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException {
    	if( soggettoView != null && soggettoView.isSocketToBeCalled()) {
    		return performCensimentoSH(soggettoView);
    	} else {
    		return new CensimentoAZHostImpl().performCensimentoH2OandHOST(soggettoView,logMsg,logForHost);
    	}
    }

    public void performCensimentoModifica( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException {
    	if( soggettoView != null && soggettoView.isSocketToBeCalled()) {
    		performCensimentoModificaSH(soggettoView);
    	}  else {
    		new CensimentoAZHostImpl().performCensimentoModificaH2OandHOST(soggettoView,logMsg,logForHost);
    	}
    }

    public Long performCensimentoSH( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException {
    	return new CensimentoAZSocketImpl().performCensimentoH2OandHOST(soggettoView,logMsg,logForHost);
    }

    public void performCensimentoModificaSH( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException {
    	new CensimentoAZSocketImpl().performCensimentoModificaH2OandHOST(soggettoView,logMsg,logForHost);
    }

    public Hashtable validateSoggettoXML( final SoggettoView aziendaView ) throws BeanHelperException, RemoteException {
        final Hashtable azHash = new SoggettoValidator().validateSoggettoXML(aziendaView);
        if( azHash != null && azHash.get(IHelperConstants.VALIDATE_XML_STATUS_KO) == null ) {
        	try {
        		checkEmbargoAZ( (AziendaView) aziendaView );
        		if( azHash.get(IHelperConstants.VALIDATE_XML_STATUS_OKKO) == null ) {
        			azHash.put(IHelperConstants.VALIDATE_XML_STATUS_OK, "OK");
        		}
        	} catch ( final BeanHelperException e ) {
        		log4Debug.warnStackTrace(e);
        		azHash.put(IHelperConstants.VALIDATE_XML_STATUS_KO, "OK");
            	setValue( azHash, IHelperConstants.VALIDATE_XML_STATUS_VALUES, IHelperConstants.VALIDATE_XML_STATUS_VALUES, new AnagrafeHelper().getMessage("ANAG-1285"));
        	}
        }
        return azHash;
    }

    public SoggettoView getSoggetto( final Long soggettoId, final Properties properties ) throws RemoteException, BeanHelperException {
        try {
        	final AziendaFactory aziendaFactory = (AziendaFactory) getAnagrafeFactory(AziendaView.class);
        	final SoggettoView soggettoView = aziendaFactory.getAzienda(soggettoId);
       		logMsg.append(aziendaFactory.getLogData((AziendaView) soggettoView));
            return soggettoView;
        } catch (final AziendaFactoryException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    public SoggettoView getViewAfterParsing( final String xmlSoggetto ) throws BeanHelperException {
        try {
        	final XMLReader xmlReader = XMLReaderFactory.createXMLReader();
        	final CensimentoAziendaParser censimentoAziendaParser = new CensimentoAziendaParser();
            xmlReader.setContentHandler(censimentoAziendaParser);
            xmlReader.parse(new InputSource(new StringReader(xmlSoggetto)));
            return censimentoAziendaParser.getAziendaView();
        } catch (final SAXException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        } catch (final IOException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    public SoggettoView getViewAfterParsingPrivacyFiveLevelXML(
    		final String xmlSoggetto ) throws BeanHelperException {
        try {
            final XMLReader xmlReader = XMLReaderFactory.createXMLReader();
            final CensimentoAZFiveLevelParser censimentoAZFiveLevelParser =
            	new CensimentoAZFiveLevelParser();
            xmlReader.setContentHandler(censimentoAZFiveLevelParser);
            xmlReader.parse(new InputSource(new StringReader(xmlSoggetto)));
            return censimentoAZFiveLevelParser.getAziendaView();
        } catch (final SAXException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        } catch (final IOException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    private void checkEmbargoAZ( final AziendaView aziendaView ) throws BeanHelperException, RemoteException {
    	try {
    		final String denominazione = aziendaView.getDatiAnagraficiAZView().getDenominazione();
    		final String valoreOrgcl = aziendaView.getOrgcl() != null ? aziendaView.getOrgcl().getCampagnaDesc() : null;
			final Map map = new CSSEHandler().getEmbargoAZCount(denominazione, valoreOrgcl);
			if( map == null || ((Long)map.get("INSTITUTIONAL")).longValue() != 0 ) {
				throw new BeanHelperException(new AnagrafeHelper().getMessage("ANAG-1285"));
			}
		} catch (final SubSystemHandlerException e) {
			throw new BeanHelperException(e.getMessage());
		}
    }

    private String createSoggettoPrivacyFiveAndSixLevel( final SoggettoView aziendaView, final String parserError, final String operationCode) throws RemoteException, BeanHelperException {
    	try {
	        Long soggettoId = null;
	        log4Debug.debug(" AnagrafeManagerBeanAZHelper: createSoggettoPrivacyFiveAndSixLevel : aziendaView :===>>>",aziendaView);
	        final Hashtable azHash = new SoggettoValidator().validateSoggetto(aziendaView);
	        log4Debug.debug(" AnagrafeManagerBeanAZHelper: createSoggettoPrivacyFiveAndSixLevel : azHash :===>>>",azHash);
	        String errorMessage = (String) azHash.get("ERROR_MSG");
	        log4Debug.debug(" AnagrafeManagerBeanAZHelper: createSoggettoPrivacyFiveAndSixLevel : errorMessage :===>>>",errorMessage);
	        final String bankName = ((AziendaView)aziendaView).getBanca();
	        log4Debug.debug(" AnagrafeManagerBeanAZHelper: createSoggettoPrivacyFiveAndSixLevel : getBanca :===>>>",bankName);
	        errorMessage = errorMessage.length() == 0 && !checkBankData(bankName) ? "Soggetto does not belong to the login bank ^" : errorMessage;
	        if (errorMessage.length() == 0) {
	        	aziendaView.setHostToBeCalled(false);
	        	if(azHash.get("SOGGETTO_EXISTS") != null) {
	        		soggettoId = (Long) azHash.get("SOGGETTO_EXISTS");
	        		aziendaView.setSoggettoAlreadyExist(true);
	        	} else {
	        		final DatiFiscaliUtil datiFiscaliUtil = new DatiFiscaliUtil();
	        		checkEmbargoAZ((AziendaView)aziendaView);
	        		datiFiscaliUtil.setRzValAndResidenzaFiscaliInANTICI(aziendaView, ((AziendaView) aziendaView).getMotiv());
	        		datiFiscaliUtil.setRegimeDataScadenzaForAZ((AziendaView)aziendaView);
					soggettoId = creaOrGetSoggetto(aziendaView, operationCode);
	        	}
	            aziendaView.setId(soggettoId);
	        }
	        return new CommonHelper().getOutputXMLMessage(errorMessage,soggettoId);
		} catch (final LoggerException e) {
			log4Debug.warnStackTrace(e);
			throw new BeanHelperException(e.getMessage());
		} catch (final ControlloDatiPFException e) {
			log4Debug.warnStackTrace(e);
			throw new BeanHelperException(e.getMessage());
		}
    }

	/**
	 * @param aziendaView
	 * @param operationCode
	 * @return
	 * @throws LoggerException
	 * @throws RemoteException
	 * @throws BeanHelperException
	 */
    private synchronized Long creaOrGetSoggetto(final SoggettoView aziendaView,
    		final String operationCode) throws LoggerException,
    		RemoteException, BeanHelperException {
    	Long soggettoId = null;
    	log4Debug.debug("In Synchronized block of Crea or Get Soggetto : " , soggettoId);
    	final Map<String, Long> cfMap = new SoggettoValidator().validateSoggettoForCF(aziendaView);
    	if(cfMap.get("SOGGETTO_EXISTS") != null) {
    		soggettoId = cfMap.get("SOGGETTO_EXISTS");
    		aziendaView.setSoggettoAlreadyExist(true);
    	} else {
    		aziendaView.setOpId(new AnagrafeLoggerHelper().logAnagrafeOperation(aziendaView.getMotivazioneNoHost(), aziendaView.isHostToBeCalled(), operationCode, aziendaView.getId(),null));
    		((AziendaView)aziendaView).setFatturatoView(getFatturatoView(aziendaView));
    		((AziendaView)aziendaView).setClientClassificazioneView(getClassificazioneDetails(aziendaView));
    		setRecapitiNonDispList((AziendaView)aziendaView);
    		soggettoId = performCensimento(aziendaView);
    	}
    	log4Debug.debug("Out of Synchronized block of Crea or Get Soggetto : " , soggettoId);
    	return soggettoId;
    }

    private FatturatoView getFatturatoView( final SoggettoView soggettoView ) {
    	final AziendaView aziendaView = (AziendaView) soggettoView;
    	final FatturatoView fatturatoView = aziendaView.getFatturatoView();
    	log4Debug.debug(" AnagrafeManagerBeanAZHelper: getFatturatoView: fatturatoView:===>>",fatturatoView);
    	if (fatturatoView != null) {
    		log4Debug.debug(" AnagrafeManagerBeanAZHelper: getFatturatoView: fatturatoView.getBilancioStr():===>>",fatturatoView.getBilancioStr());
    		log4Debug.debug(" AnagrafeManagerBeanAZHelper: getFatturatoView: fatturatoView.getFatturatoStr():===>>",fatturatoView.getFatturatoStr());
    		log4Debug.debug(" AnagrafeManagerBeanAZHelper: getFatturatoView: fatturatoView.getNumeroDependentiStr():===>>",fatturatoView.getNumeroDependentiStr());
    		log4Debug.debug(" AnagrafeManagerBeanAZHelper: getMicroimpresaView: fatturatoView.getMicroimpresaStr():===>>",fatturatoView.getMicroimpresa());

    		fatturatoView.setBilancio(UtilHelper.getBigDecimalValue(fatturatoView.getBilancioStr()));
    		fatturatoView.setFatturato(UtilHelper.getBigDecimalValue(fatturatoView.getFatturatoStr()));
    		fatturatoView.setNumeroDependenti(UtilHelper.getLongValue(fatturatoView.getNumeroDependentiStr()));
    		fatturatoView.setMicroimpresa(fatturatoView.getMicroimpresa());

    		log4Debug.debug(" AnagrafeManagerBeanAZHelper: getFatturatoView: fatturatoView.getBilancio():===>>",fatturatoView.getBilancio());
    		log4Debug.debug(" AnagrafeManagerBeanAZHelper: getFatturatoView: fatturatoView.getFatturato():===>>",fatturatoView.getFatturato());
    		log4Debug.debug(" AnagrafeManagerBeanAZHelper: getFatturatoView: fatturatoView.getNumeroDependenti():===>>",fatturatoView.getNumeroDependenti());
    		log4Debug.debug(" AnagrafeManagerBeanAZHelper: getMicroimpresaView: fatturatoView.getMicroimpresa():===>>",fatturatoView.getMicroimpresa());

    	}
    	return fatturatoView;
    }

    private ClienteClassificazioneView getClassificazioneDetails( final SoggettoView soggettoView ) {
    	final AziendaView aziendaView = (AziendaView) soggettoView;
    	final FatturatoView fatturatoView = aziendaView.getFatturatoView();
    	final Collection motivCollection = aziendaView.getMotiv();
    	if ( motivCollection.contains("CLINT") || motivCollection.contains("IMELB")) {
        	try {
				return new ClienteClassificazioneUtilHelper().getClienteClassificazioneViewAZForDB(
								aziendaView.getAttributiEsterniAZView(), fatturatoView);
			} catch (final GestoreAnagrafeException e) {
				log4Debug.severeStackTrace(e);
				log4Debug.severe("$$$$$$$$$$$$$ Exception got during Cliente Al Dettaglio calculation is suppressed not to affect main Transactions");
			}
    	}
    	return null;
    }

    public void buildLogAndDoHostAlignMentForSellaLifeCust( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException {
    		new CensimentoAZHostImpl().buildLogAndDoHostAlignMentForSellaLifeCust(soggettoView,logMsg,logForHost);
    }

    private String createSoggettoPrivacyFiveAndSixLevelWithHost( final SoggettoView soggettView, final String parserError, final String operationCode) throws RemoteException, BeanHelperException {
		try {
	        Long soggettoId = null;
	        final AziendaView aziendaView = (AziendaView)soggettView;
	        aziendaView.setIfXmlWithHost(true);
	        final Hashtable azHash = new SoggettoValidator().validateSoggetto(aziendaView);
	        String errorMessage = (String) azHash.get("ERROR_MSG");
	        log4Debug.debug(" AnagrafeManagerBeanAZHelper: createSoggettoPrivacyFiveAndSixLevelWithHost : getBanca :===>>>",aziendaView.getBanca());
	        errorMessage = errorMessage.length() == 0 && !checkBankData(aziendaView.getBanca()) ? "Soggetto does not belong to the login bank ^" : errorMessage;
	       // aziendaView.setIfXml(false); to call host, so the xml value is set false
	        aziendaView.setIfXml(false);
	        if (errorMessage.length() == 0) {
	        	if(azHash.get("SOGGETTO_EXISTS") != null) {
	        		soggettoId = (Long) azHash.get("SOGGETTO_EXISTS");
	        		aziendaView.setSoggettoAlreadyExist(true);
	        	} else {
	        		log4Debug.debug("AnagrafeManagerBeanAZHelper : createSoggettoPrivacyFiveAndSixLevelWithHost : isCSSECheckAllowed ==>",aziendaView.isCSSECheckAllowed());
	        		if(aziendaView.isCSSECheckAllowed()){
	        			checkEmbargoAZ(aziendaView);
	        		}
	        		final DatiFiscaliUtil datiFiscaliUtil = new DatiFiscaliUtil();
					datiFiscaliUtil.setRzValAndResidenzaFiscaliInANTICI(aziendaView, aziendaView.getMotiv());
					datiFiscaliUtil.setRegimeDataScadenzaForAZ(aziendaView);
	        		soggettoId = creaOrGetSoggetto(aziendaView, operationCode);
	        	}
	            aziendaView.setId(soggettoId);
	        }
	        return new CommonHelper().getOutputXMLMessage(errorMessage,soggettoId);
		} catch (final LoggerException e) {
			log4Debug.warnStackTrace(e);
			throw new BeanHelperException(e.getMessage());
		} catch (final ControlloDatiPFException e) {
			log4Debug.warnStackTrace(e);
			throw new BeanHelperException(e.getMessage());
		}
    }
    
    public String variaSoggettoXML(final AziendaView aziendaView, final Long soggettoId) throws RemoteException, BeanHelperException{
    	String outputXML = null;
    	final Map output = new SoggettoValidator().validateSoggetto(aziendaView);
    	final String errorMessage = (String) output.get("ERROR_MSG");
    	if ( errorMessage != null && errorMessage.length() > 0 ) {
    		outputXML = new CommonHelper().getOutputXMLMessage(errorMessage , null);
        }else {
        	log4Debug.debug(" AnagrafeManagerBeanAZHelper: variaSoggettoXML : aziendaView.getMotiv() :===>>",aziendaView.getMotiv());
            log4Debug.debug(" AnagrafeManagerBeanAZHelper: variaSoggettoXML : aziendaView.getOldAziendaView().getMotiv() :===>>",aziendaView.getOldAziendaView().getMotiv());
            final DatiFiscaliUtil datiFiscaliUtil = new DatiFiscaliUtil();
            datiFiscaliUtil.setRzValAndResidenzaFiscaliInANTICI(aziendaView, aziendaView.getMotiv());
            try {
				datiFiscaliUtil.setRegimeDataScadenzaForAZ(aziendaView);
			} catch (ControlloDatiPFException e) {
				log4Debug.warnStackTrace(e);
				throw new BeanHelperException(e.getMessage());
			}
            final FatturatoView fatturatoViewFinal = buildFatturatoViewForDBOperation(aziendaView.getFatturatoView(), aziendaView.getOldAziendaView().getFatturatoView());
            aziendaView.setFatturatoView(fatturatoViewFinal);
            aziendaView.setClientClassificazioneView(getClassificazioneDetails(aziendaView));
            performCensimentoModifica(aziendaView);
            outputXML = new CommonHelper().getOutputXMLMessage(errorMessage, soggettoId);
        }
		return outputXML;
    }
    private FatturatoView buildFatturatoViewForDBOperation(final FatturatoView fatturatoNewXMLView, final FatturatoView fatturatOldDBView){
		FatturatoView fatturatoView = null;
		log4Debug.debug("fatturatoDataExistDetails fatturatOldDBView =============================  ",fatturatOldDBView);
		if(fatturatOldDBView != null){
			final Hashtable<String, String> fatturatoDataExistDetails = new ClienteClassificazioneUtilHelper().getFatturatoExistDeatail(fatturatOldDBView);
			log4Debug.debug("fatturatoDataExistDetails  =============================  ",fatturatoDataExistDetails);
			if(fatturatoDataExistDetails != null && fatturatoNewXMLView != null){
				fatturatoView = new FatturatoView();
				if(isFatturatoExistAtANAG(fatturatoDataExistDetails, "numeroDipendentiExistAt")){
					log4Debug.debug("numeroDipendentiExistAt  =================== setting ==========",fatturatoNewXMLView.getNumeroDependenti());
					fatturatoView.setNumeroDependenti(fatturatoNewXMLView.getNumeroDependenti());
				}
				if(isFatturatoExistAtANAG(fatturatoDataExistDetails, "fatturatoExistAt")){
					log4Debug.debug("fatturatoExistAt  =================== setting ==========",fatturatoNewXMLView.getFatturato());
					fatturatoView.setFatturato(fatturatoNewXMLView.getFatturato());
				}
				if(isFatturatoExistAtANAG(fatturatoDataExistDetails, "bilancioExistAt")){
					log4Debug.debug("bilancioExistAt  =================== setting ==========",fatturatoNewXMLView.getBilancio());
					fatturatoView.setBilancio(fatturatoNewXMLView.getBilancio());
				}
				fatturatoView.setDataExistAt(fatturatoDataExistDetails);
				fatturatoView.setMicroimpresa(fatturatoNewXMLView.getMicroimpresa());
			}
		}
		return fatturatoView;
	}
    private boolean isFatturatoExistAtANAG(final Hashtable<String, String> fatturatoDataExistDetails,
			final String key) {
		return !RATING_SS.equals(fatturatoDataExistDetails.get(key));
	}
    
    /**
     * @param aziendaView
     */
    private void setRecapitiNonDispList(final AziendaView aziendaView) {
		final Boolean recapNonDispAllowedForLoginBank = RecapitiNonDisponibileHelper.isRecapNonDispAllowedForLoginBank();
		aziendaView.setRecapNDAllowed(recapNonDispAllowedForLoginBank);
		if(recapNonDispAllowedForLoginBank) {
			aziendaView.setRecapNonDispDetailList(new RecapitiNonDisponibileHelper().getRecapitiNonDispListForXML(aziendaView.getRecapitiView(), "AZIENDA"));
		}
	}
}
