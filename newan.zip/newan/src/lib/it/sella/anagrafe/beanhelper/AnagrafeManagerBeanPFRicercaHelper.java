package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.BeanHelperException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.dbaccess.DBAccessHelper;
import it.sella.anagrafe.pf.DatiAnagraficiPFView;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.anagrafe.util.SmartRicercaResultPFViewCollection;
import it.sella.anagrafe.util.StringHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Properties;
import java.util.StringTokenizer;

public class AnagrafeManagerBeanPFRicercaHelper extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AnagrafeManagerBeanPFRicercaHelper.class);
    
    protected StringBuffer logMsg = null;
    protected StringBuffer logForHost = null;

    public String getLogMsg() {
        return logMsg != null ? logMsg.toString() : "";
    }

    public String getLogForHost() {
        return logForHost != null ? logForHost.toString() : "";
    }
    
    public Collection ricercaPF(final Properties properties) throws RemoteException, BeanHelperException {
        Connection connection = null;
        CallableStatement datiAnagraficiCallStatement = null;
        Collection ricercaColl = null;
        String toBeNormalisedString = null;
        final StringHandler stringHandler = new StringHandler();
        try {
            final DatiAnagraficiPFView datiAnagraficiPFView = (DatiAnagraficiPFView) properties.get("View");
            if (datiAnagraficiPFView.getNome() != null && datiAnagraficiPFView.getNome().length() > 0) {
                toBeNormalisedString = stringHandler.getNormalisedString(datiAnagraficiPFView.getCognome()+datiAnagraficiPFView.getNome());
            } else {
                toBeNormalisedString = stringHandler.getNormalisedString(datiAnagraficiPFView.getCognome().trim());
            }
            datiAnagraficiPFView.setNormalisedNome(stringHandler.removeSingleQuote(toBeNormalisedString));
            connection = getConnection();
            datiAnagraficiCallStatement = connection.prepareCall("{call an_pr_ricerca( ?, ?, ?, ?, ?, ?, ?, ?)}");
            datiAnagraficiCallStatement.setString(1, datiAnagraficiPFView.getNormalisedNome() + "%");
            logMsg.append("<NormalisedString>" + StringHandler.encodeXMLTagValue(datiAnagraficiPFView.getNormalisedNome()) + "</NormalisedString>");
            if (datiAnagraficiPFView.getDataDiNascita() != null) {
                datiAnagraficiCallStatement.setString(2, new DateHandler().formatDate(datiAnagraficiPFView.getDataDiNascita(), "yyyy-MM-dd"));
                logMsg.append("<DataDiNascita>" + StringHandler.encodeXMLTagValue(datiAnagraficiPFView.getDataDiNascita().toString()) + "</DataDiNascita>");
            } else {
                datiAnagraficiCallStatement.setString(2, "%");
                logMsg.append("<DataDiNascita>" + "%" + "</DataDiNascita>");
            }
            datiAnagraficiCallStatement.setString(3, "%");
            logMsg.append("<DataDiNascitaCitta>" + "%" + "</DataDiNascitaCitta>");
            datiAnagraficiCallStatement.setString(4, "%");
            logMsg.append("<DataDiNascitaNazione>" + "%" + "</DataDiNascitaNazione>");
            datiAnagraficiCallStatement.setString(5, (String) properties.get("Stato"));
            final String motiv = properties.get("MOTIV") != null ? (String)properties.get("MOTIV") : "CENST";
            final CommonHelper commonHelper = new CommonHelper();
            datiAnagraficiCallStatement.setLong(7, commonHelper.getClassificazioneId(motiv, "MOTIV").longValue());
            datiAnagraficiCallStatement.registerOutParameter(8, java.sql.Types.VARCHAR);
            String soggettoIds = "";
            if (properties.get("ALL_RICERCA") != null) {
				final Collection collection = commonHelper.getAllBanks();
                if (collection != null && !collection.isEmpty()) {
                    final int size = collection.size();
                    final Iterator iterator = collection.iterator();
                    for (int j = 0; j < size; j++) {
                        datiAnagraficiCallStatement.setLong(6, ((Long) iterator.next()).longValue());
                        datiAnagraficiCallStatement.executeUpdate();
                        final String soggettoIdsPerBank = datiAnagraficiCallStatement.getString(8);
                        if (soggettoIdsPerBank != null) {
                            soggettoIds = soggettoIds + soggettoIdsPerBank + "^";
                        }
                    }
                }
            } else {
                datiAnagraficiCallStatement.setString(6, SecurityHandler.getLoginBancaId().toString());
                datiAnagraficiCallStatement.executeUpdate();
                soggettoIds = datiAnagraficiCallStatement.getString(8);
            }

            if (soggettoIds != null && soggettoIds.length() > 0) {
                if (properties.get("ONLY_SOGGETTOIDS") != null) {
                    final ArrayList soggettoIdList = new ArrayList();
                    final StringTokenizer tokenizer = new StringTokenizer(soggettoIds, "^");
                    for (; tokenizer.hasMoreTokens(); soggettoIdList.add(Long.valueOf(tokenizer.nextToken()))) {
						;
					}
                    ricercaColl = soggettoIdList;
                } else {
                    final SmartRicercaResultPFViewCollection smartColl = new SmartRicercaResultPFViewCollection();
                    smartColl.add(soggettoIds);
                    ricercaColl = smartColl;
                }
            }
        } catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            if (se.getMessage().indexOf("ORA-06502") != -1 || se.getMessage().indexOf("ORA-20101") != -1) {
				throw new BeanHelperException(new AnagrafeHelper().getMessage("ANAG-1308"));
			} else {
                log4Debug.debug(se);
                throw new BeanHelperException(se.getMessage());
            }
        } catch (final SubSystemHandlerException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        } catch (final NumberFormatException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        } finally {
            cleanup(connection, datiAnagraficiCallStatement);
        }
        return ricercaColl;

    }

}
