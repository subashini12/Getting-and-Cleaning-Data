package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.dbaccess.CollegamentoDBAccessHelper;
import it.sella.anagrafe.dbaccess.DBAccessHelper;
import it.sella.anagrafe.discriminator.CollegamentoException;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.gestione_flussi.GestioneElementoFlussoException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

public class AnagrafeFlussoImplHelpher extends DBAccessHelper  {
    
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AnagrafeFlussoImplHelpher.class);

    
    protected  String getSconfino(final String input) {
        String output = null;
        if ("1".equals(input)) {
			output = "false";
		} else if ("2".equals(input)) {
			output = "SottoOsservazione";
		} else if ("N".equals(input)) {
			output = "NOSCONF_NOUPDATE";
		} else {
			output = "true";
		}
        return output;
    }
    
    protected  Long getSoggettoIdCS(final String causale, String valoreCodiceSoggetto, final Long bancaId) throws GestoreAnagrafeException, RemoteException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet codiciSoggettoResultSet = null;
        Long soggettoID = null;
        try {
            final long causaleId = getClassificazioneIdFromCausale(causale, "CSDPF").longValue();
            connection = getConnection();
            if ("codiceHost".equals(causale)) {
                if (valoreCodiceSoggetto != null && valoreCodiceSoggetto.length() == 8) {
					valoreCodiceSoggetto = new StringBuffer("0").append(valoreCodiceSoggetto).toString();
				}
                final StringBuffer query = new StringBuffer();
                query.append("SELECT CO_SOGGETTO_ID FROM AN_TR_CODICIHOST CH WHERE EXISTS ( ");
                query.append("SELECT 1 FROM AN_TR_COLLAGAMENTO_SOGGETTO WHERE CL_SOGGETTO_PRINCIPALE = ? AND ");
                query.append("CL_MOTIVO = ? AND CL_LINKED_SOGGETTO = CH.CO_SOGGETTO_ID AND CL_DATA_FINE IS NULL) ");
                query.append("AND CO_CODICIHOST = ?");
                final long censtId = getClassificazioneIdFromCausale("CENST", "MOTIV").longValue();
                selectStatement = connection.prepareStatement(query.toString());
                selectStatement.setLong(1, bancaId.longValue());
                selectStatement.setLong(2, censtId);
                selectStatement.setString(3, valoreCodiceSoggetto);
                codiciSoggettoResultSet = selectStatement.executeQuery();
                if (codiciSoggettoResultSet.next()) {
                    soggettoID = Long.valueOf(codiciSoggettoResultSet.getLong("CO_SOGGETTO_ID"));
                }
            } else {
                final StringBuffer query = new StringBuffer();
                query.append("SELECT  CS_SOGGETTO_ID FROM an_tr_codicisoggetto ac WHERE CS_VALUE = ? AND  CS_RIGHT_PK = ?");
                query.append(" and exists (select 1 from an_tr_collagamento_soggetto where CL_SOGGETTO_PRINCIPALE = ? AND");
                query.append(" CL_MOTIVO = ? and  CL_LINKED_SOGGETTO = ac.CS_SOGGETTO_ID AND cl_Data_fine is null)");
                final long motivId = ClassificazioneHandler.getClassificazioneView("DIPEN", "MOTIV").getId().longValue();
                selectStatement = connection.prepareStatement(query.toString());
                selectStatement.setString(1, valoreCodiceSoggetto);
                selectStatement.setLong(2, causaleId);
                selectStatement.setLong(3, bancaId.longValue());
                selectStatement.setLong(4, motivId);
                codiciSoggettoResultSet = selectStatement.executeQuery();
                if (codiciSoggettoResultSet.next()) {
					soggettoID = Long.valueOf(codiciSoggettoResultSet.getLong("CS_SOGGETTO_ID"));
				}
            }
        } catch (final SQLException sqlEx) {
            log4Debug.severeStackTrace(sqlEx);
            throw new GestoreCodiciSoggettoException(sqlEx.getMessage());
        } catch (final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            throw new GestoreCodiciSoggettoException(e.getMessage());
        } finally {
            cleanup(connection, selectStatement, codiciSoggettoResultSet);
        }
        return soggettoID;
    }
    
    
    protected String getDateString(final String input) {
        final StringBuffer strDate = new StringBuffer(input);
        strDate.insert(2, '/');
        strDate.insert(5, '/');
        return strDate.toString();
    }
    
    protected Long getBancaId(final String bancaCode) throws GestoreAnagrafeException {
        return Long.valueOf(CommonPropertiesHandler.getValueFromProperty(bancaCode.substring(0,5)));	
    }

    protected  void updateDipct(final Long soggettoId, final Long dipctSoggId, final Long opId) throws GestioneElementoFlussoException, RemoteException {
    	try {
			final Collection dipctIds = new ArrayList(1);
			dipctIds.add(dipctSoggId);
			new CollegamentoDBAccessHelper().gestoreCollegamento(soggettoId,dipctIds,"DIPCT",opId);
		}  catch (final CollegamentoException e) {
			log4Debug.warnStackTrace(e);
            throw new GestioneElementoFlussoException(e.getMessage(), e);
		}
    }

}
