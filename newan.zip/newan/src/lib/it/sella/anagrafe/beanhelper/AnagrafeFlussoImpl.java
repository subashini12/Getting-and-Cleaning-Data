package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.OperazioneCensimentoException;
import it.sella.anagrafe.dbaccess.AttributiEsterniDBAccessHelper;
import it.sella.anagrafe.dbaccess.BancaDettagliGetterHelper;
import it.sella.anagrafe.discriminator.AttributiEsterniDiscriminatorException;
import it.sella.anagrafe.util.AnagrafeLoggerHelper;
import it.sella.anagrafe.util.BeanHelper;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.HelperException;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.gestione_flussi.GestioneElementoFlussoException;
import it.sella.logserver.LoggerException;
import it.sella.net.ftp.FTPWriter;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.Date;

public class AnagrafeFlussoImpl {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AnagrafeFlussoImpl.class);

    public  void gestisciElementoFlusso(final Object elementoFlusso, final String nomeFlusso) throws GestioneElementoFlussoException, RemoteException {
        Long bancaId = null;
        Long soggettoId = null;
        Long dipctSoggId = null;
    	final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
    	Long opId = null;
    	String errorMessage = null;
        final String input = (String) elementoFlusso;
        final String banca = input.substring(0, 6);
        final String codicehost = "0" + input.substring(6, 14);
        final AnagrafeFlussoImplHelpher flussoHandler = new AnagrafeFlussoImplHelpher();
        final String strDate = flussoHandler.getDateString(input.substring(14, 22));
        String tipoEventi = input.substring(22, 26);
        final String dipctCode = input.substring(26, 29);
        final String sconfino = flussoHandler.getSconfino(input.substring(29, 30));
        // This trim() to the tipoEventi is perticularly for "FPE" causale. This Tipo Eventi Exactly have 3 chars. In input it comes with space in last character.
        // InFuture If Any New Tipo Eventi Introduced with 3 chars or lessthan 3 chars .. Need to handle here (trim)
        if(tipoEventi != null && tipoEventi.startsWith("FPE")){
        	tipoEventi = tipoEventi.trim();
        }
        try {
			opId = anagrafeLoggerHelper.logAnagrafeOperation(null,false,"ANAG-ISE-DIPCTEVENTI",null,null);
            bancaId = flussoHandler.getBancaId(banca);
            soggettoId = flussoHandler.getSoggettoIdCS("codiceHost", codicehost, bancaId);
            new BeanHelper().updateEventi(soggettoId, tipoEventi, strDate, "dd/MM/yyyy", opId, null, null);
            //  dipct updation
            if("Y".equals(new BancaDettagliGetterHelper().getCheckDipct(SecurityHandler.getLoginBancaId()))){
            	if (dipctCode.trim().length() > 0) {
            		dipctSoggId = flussoHandler.getSoggettoIdCS("coddp", dipctCode, bancaId);
            		if (dipctSoggId != null) {
            			flussoHandler.updateDipct(soggettoId, dipctSoggId, opId);
            		}
            	}
            }
            // updation of sconfino
            if (!"NOSCONF_NOUPDATE".equals(sconfino)) {
            	new AttributiEsterniDBAccessHelper().setAttributiEsterniValues(soggettoId,sconfino,"sconf",opId);
            }
            anagrafeLoggerHelper.logAnagrafeOpDetails(opId,"","");
        } catch (final LoggerException e) {
        	errorMessage = e.getMessage();
            log4Debug.warnStackTrace(e);
            throw new GestioneElementoFlussoException(errorMessage, e);
        } catch (final GestoreAnagrafeException e) {
        	errorMessage = e.getMessage();
            log4Debug.warnStackTrace(e);
            throw new GestioneElementoFlussoException(errorMessage, e);
        } catch (final HelperException e) {
        	errorMessage = e.getMessage();
            log4Debug.warnStackTrace(e);
            throw new GestioneElementoFlussoException(errorMessage, e);
        } catch (final AttributiEsterniDiscriminatorException e) {
        	errorMessage = e.getMessage();
            log4Debug.warnStackTrace(e);
            throw new GestioneElementoFlussoException(errorMessage, e);
		} finally {
        	try {
				anagrafeLoggerHelper.updateAnagrafeLog(opId,soggettoId,errorMessage);
			} catch (final OperazioneCensimentoException e) {
	            log4Debug.warnStackTrace(e);
			}
        }
    }

    // Flusso Producer Methods
    public  void gestisciScarto(final Object elementoFlussoScartato, final Throwable motivoScarto, final String nomeFlusso) throws GestioneElementoFlussoException {
        try {
            final String ftpConnectionPool = CommonPropertiesHandler.getValueFromProperty("ANAG_FTP_POOL");
            final String path = CommonPropertiesHandler.getValueFromProperty("FLUSSO_FILE_PATH");
            final String fileName = new DateHandler().formatDate(new Timestamp(System.currentTimeMillis()), "ddMMyyyy") + "eventierror.txt";
            final FTPWriter ftpWriter = new FTPWriter(ftpConnectionPool, path, fileName, true);
            final String message = elementoFlussoScartato.toString() + "   " + motivoScarto.getMessage() + "   " + nomeFlusso + "\n";
            ftpWriter.write(message);
            ftpWriter.close();
        } catch (final IOException e) {
            log4Debug.severeStackTrace(e);
            throw new GestioneElementoFlussoException(e.getMessage(), e);
        }
    }

    public  void notifcaFlussoTerminato(final java.lang.String nomeFlusso)  {
        log4Debug.info(">>>>>>>>>>>>>>> FLUSSO " , nomeFlusso , " FINISHED AT " , new Date());
    }

}
