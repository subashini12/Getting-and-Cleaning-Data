package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.anagrafe.MapperFactory;
import it.sella.anagrafe.controllo.ControlloDatiPFException;
import it.sella.anagrafe.dbaccess.CSCifratiGetterHelper;
import it.sella.anagrafe.util.AnagConfigurationHandler;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.MapperHelperException;
import it.sella.anagrafe.view.AziendaView;

import java.rmi.RemoteException;
import java.util.StringTokenizer;

public class CensimentoAZImpl extends AMBBaseHelper {

	protected String update610MessageForCifratiAz(final AziendaView aziendaView) throws RemoteException, GestoreCodiciSoggettoException, MapperHelperException {
		if(CommonPropertiesHandler.isHostAllowedForLoginBank()) {
			final String codiceHost = new CSCifratiGetterHelper().getCodiceHostCifrati(aziendaView.getId());
			if(codiceHost != null) {
				final StringBuffer hostMessage = new StringBuffer();
				final StringTokenizer tokenizer = new StringTokenizer(codiceHost, ";");
				while(tokenizer.hasMoreTokens()) {
					hostMessage.append(MapperFactory.getMapper().update610For8cifreCifratiAZ(tokenizer.nextToken(), aziendaView));
				}
				return hostMessage.toString();
			}
		}
		return "";
	}

	/**
	 * To stop variation for soggettos via policy
	 * @param aziendaView
	 * @param soggettoId 
	 * @throws ControlloDatiPFException
	 * @throws RemoteException 
	 */
	protected void validationForPolizzaSellaLife(final AziendaView aziendaView)
	throws ControlloDatiPFException, RemoteException {
		if(aziendaView!=null && AnagConfigurationHandler.isConfigurationAllowed("PolizzaSellaLife")&& aziendaView.getAttributiEsterniAZView() !=null){
			final boolean isPolizza = "true".equalsIgnoreCase(aziendaView.getAttributiEsterniAZView().getPOLIZZA_SELLA_LIFE());
			if(isPolizza ){
				throw new ControlloDatiPFException(new AnagrafeHelper().getMessage("ANAG-1779" ,aziendaView.isThruXml()));
			}
				
		}
	}


}
