package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.BeanHelperException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.controllo.ControlloDatiPFException;
import it.sella.anagrafe.dbaccess.DatiFiscaliUtil;
import it.sella.anagrafe.factory.PersonaFisicaFactory;
import it.sella.anagrafe.factory.PersonaFisicaFactoryException;
import it.sella.anagrafe.implementation.CensimentoPFFiveLevelParser;
import it.sella.anagrafe.implementation.SoggettoParser;
import it.sella.anagrafe.pf.DatiFiscaliPFView;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.AnagrafeLoggerHelper;
import it.sella.anagrafe.util.CSSEHandler;
import it.sella.anagrafe.util.IHelperConstants;
import it.sella.anagrafe.validator.RecapitiNonDisponibileHelper;
import it.sella.anagrafe.validator.SoggettoValidator;
import it.sella.anagrafe.validator.documentvalidator.DocumentDataFineSetterHelper;
import it.sella.anagrafe.view.PersonaFisicaView;
import it.sella.anagrafe.view.SoggettoView;
import it.sella.logserver.LoggerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.IOException;
import java.io.StringReader;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Map;
import java.util.Properties;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;


public class AnagrafeManagerBeanPFHelper extends AnagrafeManagerBeanHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AnagrafeManagerBeanPFHelper.class);

    public AnagrafeManagerBeanPFHelper () {
        logMsg = new StringBuffer();
        logForHost = new StringBuffer();
    }

    public String createSoggetto( final SoggettoView personaFisicaView, final String parserError, final String banca, final String operationeCode ) throws RemoteException, BeanHelperException  {
   		return createSoggettoPrivacyFiveAndSixLevel(personaFisicaView, parserError, banca, operationeCode);
    }

    public String createSoggettoWithHost( final SoggettoView soggettoView, final String parserError, final String banca, final String operationeCode ) throws RemoteException, BeanHelperException {
    	return createSoggettoPrivacyFiveAndSixLevelWithHost(soggettoView, parserError, banca, operationeCode);
    }

    public Long performCensimento( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException {
    	if( soggettoView != null && soggettoView.isSocketToBeCalled()) {
    		return performCensimentoSH(soggettoView);
    	} else {
    		return new CensimentoPFHostImpl().performCensimentoH2OandHOST(soggettoView,logMsg,logForHost);
    	}
    }

    public void performCensimentoModifica( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException {
    	if( soggettoView != null && soggettoView.isSocketToBeCalled()) {
    		performCensimentoModificaSH(soggettoView);
    	} else {
    		new CensimentoPFHostImpl().performCensimentoModificaH2OandHOST(soggettoView,logMsg,logForHost);
    	}
    }

    public Long performCensimentoSH( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException {
    	return new CensimentoPFSocketImpl().performCensimentoH2OandSOCKET(soggettoView,logMsg,logForHost);
    }

    public void performCensimentoModificaSH( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException {
    	new CensimentoPFSocketImpl().performCensimentoModificaH2OandSOCKET(soggettoView,logMsg,logForHost);
    }

    public Hashtable validateSoggettoXML( final SoggettoView personaFisicaView ) throws BeanHelperException, RemoteException {
        final Hashtable pfHash = new SoggettoValidator().validateSoggettoXML(personaFisicaView);
        if( pfHash != null && pfHash.get(IHelperConstants.VALIDATE_XML_STATUS_KO) == null ) {
        	try {
        		checkCSSE((PersonaFisicaView)personaFisicaView);
        		if( pfHash.get(IHelperConstants.VALIDATE_XML_STATUS_OKKO) == null ) {
        			pfHash.put(IHelperConstants.VALIDATE_XML_STATUS_OK, "OK");
        		}
        	} catch ( final BeanHelperException e ) {
        		log4Debug.warnStackTrace(e);
            	pfHash.put(IHelperConstants.VALIDATE_XML_STATUS_KO, "OK");
            	setValue( pfHash, IHelperConstants.VALIDATE_XML_STATUS_VALUES, IHelperConstants.VALIDATE_XML_STATUS_VALUES, new AnagrafeHelper().getMessage("ANAG-1285"));
        	}
        }
        return pfHash;
    }

    public SoggettoView getSoggetto( final Long soggettoId, final Properties properties ) throws RemoteException, BeanHelperException {
        try {
        	final PersonaFisicaFactory personaFisicaFactory = (PersonaFisicaFactory) getAnagrafeFactory(PersonaFisicaView.class);
        	final SoggettoView soggettoView = personaFisicaFactory.getPersonaFisica(soggettoId, properties);
            logMsg.append(personaFisicaFactory.getLogData((PersonaFisicaView) soggettoView));
            return soggettoView;
        } catch (final PersonaFisicaFactoryException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    public SoggettoView getViewAfterParsing( final String xmlSoggetto ) throws BeanHelperException {
        try {
        	final XMLReader xmlReader = XMLReaderFactory.createXMLReader();
        	final SoggettoParser soggettoParser = new SoggettoParser();
            xmlReader.setContentHandler(soggettoParser);
            xmlReader.parse(new InputSource(new StringReader(xmlSoggetto)));
            final PersonaFisicaView personaFisicaView = soggettoParser.getPersonaFisicaView();
            if ( personaFisicaView != null &&
            		new AnagrafeHelper().checkForMotiv(personaFisicaView.getMotiv() , "MINML")&&
            		personaFisicaView.getDatiPrivacyPFView() != null) {
            	 if ( personaFisicaView.getDatiPrivacyPFView().getLivello1() == null &&
            			 personaFisicaView.getDatiPrivacyPFView().getLivello2() == null &&
            			 personaFisicaView.getDatiPrivacyPFView().getLivello3() == null &&
            			 personaFisicaView.getDatiPrivacyPFView().getLivello4() == null &&
            			 personaFisicaView.getDatiPrivacyPFView().getLivello5() == null  &&
            			 personaFisicaView.getDatiPrivacyPFView().getLivello6() == null
            			 ) {
            		 personaFisicaView.setDatiPrivacyPFView(null);
            	 }

            	 log4Debug.debug(" AnagrafeManagerBeanPFHelper : getViewAfterParsing : personaFisicaView.getDatiPrivacyPFView  >>>>>>>>>>>>",  personaFisicaView.getDatiPrivacyPFView());
            }
            return personaFisicaView;
        } catch (final SAXException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        } catch (final IOException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    public SoggettoView getViewAfterParsingPrivacyFiveLevelXML( final String xmlSoggetto ) throws BeanHelperException {
        try {
            final XMLReader xmlReader = XMLReaderFactory.createXMLReader();
            final CensimentoPFFiveLevelParser censimentoPFFiveLevelParser = new CensimentoPFFiveLevelParser();
            xmlReader.setContentHandler(censimentoPFFiveLevelParser);
            xmlReader.parse(new InputSource(new StringReader(xmlSoggetto)));
            final PersonaFisicaView personaFisicaView = censimentoPFFiveLevelParser.getPersonaFisicaView();
            if ( personaFisicaView != null &&
            		new AnagrafeHelper().checkForMotiv(personaFisicaView.getMotiv() , "MINML")&&
            		personaFisicaView.getDatiPrivacyPFFiveLevelView() != null) {
            	 if ( personaFisicaView.getDatiPrivacyPFFiveLevelView().getLivello1() == null &&
            			 personaFisicaView.getDatiPrivacyPFFiveLevelView().getLivello2() == null &&
            			 personaFisicaView.getDatiPrivacyPFFiveLevelView().getLivello3() == null &&
            			 personaFisicaView.getDatiPrivacyPFFiveLevelView().getLivello4() == null &&
            			 personaFisicaView.getDatiPrivacyPFFiveLevelView().getLivello5() == null &&
            			 personaFisicaView.getDatiPrivacyPFFiveLevelView().getProfil() == null
            			 ) {
            		 personaFisicaView.setDatiPrivacyPFFiveLevelView(null);
            	 }

            	 log4Debug.debug(" AnagrafeManagerBeanPFHelper : getViewAfterParsingPrivacyFiveLevelXML : personaFisicaView.getDatiPrivacyPFFiveLevelView  >>>>>>>>>>>>",  personaFisicaView.getDatiPrivacyPFFiveLevelView());
            }

            return personaFisicaView;

        } catch (final SAXException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        } catch (final IOException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    public String variaSoggettoXML( final PersonaFisicaView personaFisicaView , final Long soggettoId ) throws RemoteException, BeanHelperException {
        final Hashtable output = new SoggettoValidator().validateSoggetto(personaFisicaView);
        final String errorMessage = (String) output.get("ERROR_MSG");
        if ( errorMessage != null && errorMessage.length() > 0 ) {
        	return new CommonHelper().getOutputXMLMessage(errorMessage , null);
        }
        log4Debug.debug(" AnagrafeManagerBeanPFHelper: variaSoggettoXML : personaFisicaView.getPersonaFisicaView() :===>>",personaFisicaView.getPersonaFisicaView());
        log4Debug.debug(" AnagrafeManagerBeanPFHelper: variaSoggettoXML : personaFisicaView.getPersonaFisicaView().getMotiv :===>>",personaFisicaView.getPersonaFisicaView().getMotiv());
        log4Debug.debug(" AnagrafeManagerBeanPFHelper: variaSoggettoXML : personaFisicaView.getMotiv() :===>>",personaFisicaView.getMotiv());
        // Old personaFisicaView contains motivCausale String list but new personaFisicaView contains motivView List
        if ( personaFisicaView.getPersonaFisicaView().getMotiv().contains("MINML") &&
        	 personaFisicaView.getMotiv().size() > 2 ) {
        	log4Debug.debug(" AnagrafeManagerBeanPFHelper : variaSoggettoXML : CSSE Calling  >>>>>>>>>>>>");
        	checkCSSE(personaFisicaView);
        }
    	final DatiFiscaliUtil datiFiscaliUtil = new DatiFiscaliUtil();
		datiFiscaliUtil.setRzValAndResidenzaFiscaliInANTICI(personaFisicaView, personaFisicaView.getMotiv());
    	final Timestamp dateOfBirth = (personaFisicaView).getDatiAnagraficiPFView() != null ? (personaFisicaView).getDatiAnagraficiPFView().getDataDiNascita() : null;
		try {
			datiFiscaliUtil.setRegimeDataScadenza(dateOfBirth , (personaFisicaView).getDatiFiscaliPFView());
		} catch (final ControlloDatiPFException e) {
			log4Debug.warnStackTrace(e);
    		throw new BeanHelperException(e.getMessage());
		}
		// After Documenti Validation in Varia PF XML .. If no validation error then apply the Data Fine Update (New Logic)
		final DocumentDataFineSetterHelper documentDataFineHelper = new DocumentDataFineSetterHelper();
		
		documentDataFineHelper.checkIfAnyDocumentSwapNeeded(personaFisicaView.getDocumentiView(), soggettoId);
		final Collection documentiCollectionOld = personaFisicaView.getPersonaFisicaView() != null ? personaFisicaView.getPersonaFisicaView().getDocumentiView() : null;
		documentDataFineHelper.retainExistingDocumentsOfLogicallyValid(personaFisicaView.getDocumentiView(), documentiCollectionOld);
		documentDataFineHelper.setDataFineForInValidDocsInXML( personaFisicaView.getDocumentiView(), personaFisicaView.getAttributiEsterniPFView());	

    	performCensimentoModifica(personaFisicaView);
    	return new CommonHelper().getOutputXMLMessageForPF("", soggettoId, personaFisicaView.getDocumentiView());
    }

    private String createSoggettoPrivacyFiveAndSixLevel( final SoggettoView personaFisicaView, final String parserError, final String banca, final String operationCode ) throws RemoteException, BeanHelperException {
    	try {
            Long soggettoId = null;
            final Hashtable azHash = new SoggettoValidator().validateSoggetto(personaFisicaView);
            final String errorMessage = (String) azHash.get("ERROR_MSG");
            Collection documentoDatiCollection = null;
            if (errorMessage.length() < 1) {
            	personaFisicaView.setHostToBeCalled(false);
            	if(azHash.get("SOGGETTO_EXISTS") != null) {
            		soggettoId = (Long) azHash.get("SOGGETTO_EXISTS");
            		personaFisicaView.setSoggettoAlreadyExist(true);
            	} else {
            		checkCSSE((PersonaFisicaView)personaFisicaView);
            		final DatiFiscaliUtil datiFiscaliUtil = new DatiFiscaliUtil();
					datiFiscaliUtil.setRzValAndResidenzaFiscaliInANTICI(personaFisicaView, ((PersonaFisicaView)personaFisicaView).getMotiv());
					final Timestamp dateOfBirth = ((PersonaFisicaView)personaFisicaView).getDatiAnagraficiPFView() != null ? ((PersonaFisicaView)personaFisicaView).getDatiAnagraficiPFView().getDataDiNascita() : null;
					datiFiscaliUtil.setRegimeDataScadenza(dateOfBirth , ((PersonaFisicaView)personaFisicaView).getDatiFiscaliPFView());
            		soggettoId = creaOrGetSoggetto(personaFisicaView,
							operationCode);
            		documentoDatiCollection = ((PersonaFisicaView) personaFisicaView).getDocumentiView();
            	}
                personaFisicaView.setId(soggettoId);
            }
            return new CommonHelper().getOutputXMLMessageForPF(errorMessage,soggettoId,documentoDatiCollection);
    	} catch( final LoggerException e ) {
    		log4Debug.warnStackTrace(e);
    		throw new BeanHelperException(e.getMessage());
    	} catch (final ControlloDatiPFException e) {
    		log4Debug.warnStackTrace(e);
    		throw new BeanHelperException(e.getMessage());
		}
    }

	/**
	 * @param personaFisicaView
	 * @param operationCode
	 * @return
	 * @throws LoggerException
	 * @throws RemoteException
	 * @throws BeanHelperException
	 */
    private synchronized Long creaOrGetSoggetto(final SoggettoView personaFisicaView,
    		final String operationCode) throws LoggerException,
    		RemoteException, BeanHelperException {
    	Long soggettoId = null;
    	log4Debug.debug("In Synchronized block of Crea or Get Soggetto : " , soggettoId);
    	final Map<String, Long> cfMap = new SoggettoValidator().validateSoggettoForCF(personaFisicaView);
    	if(cfMap.get("SOGGETTO_EXISTS") != null) {
    		soggettoId = cfMap.get("SOGGETTO_EXISTS");
    		personaFisicaView.setSoggettoAlreadyExist(true);
    	} else {
    		personaFisicaView.setOpId(new AnagrafeLoggerHelper().logAnagrafeOperation(personaFisicaView.getMotivazioneNoHost(), personaFisicaView.isHostToBeCalled(), operationCode, personaFisicaView.getId(),null));
    		// After Documenti Validation in Varia PF Soggetto XML .. If no validation error then apply the Data Fine Update (New Logic)
    		if (personaFisicaView instanceof PersonaFisicaView ) {
    			final PersonaFisicaView pfView = (PersonaFisicaView) personaFisicaView ;
    			new DocumentDataFineSetterHelper().setDataFineForInValidDocsInXML( pfView.getDocumentiView(), pfView.getAttributiEsterniPFView());	
    			setRecapitiNonDispList(pfView);
    		}
    		soggettoId = performCensimento(personaFisicaView);
    	}
    	log4Debug.debug("Out of Synchronized block of Crea or Get Soggetto : " , soggettoId);
    	return soggettoId;
    }

    private String createSoggettoPrivacyFiveAndSixLevelWithHost( final SoggettoView soggettoView, final String parserError, final String banca, final String operationCode ) throws RemoteException, BeanHelperException {
    	try {
	        Long soggettoId = null;
	        final PersonaFisicaView personaFisicaView = (PersonaFisicaView)soggettoView;
	        personaFisicaView.setMotiv(new CommonHelper().removeUTBOLFromMotivCollection(personaFisicaView.getMotiv()));
	        final DatiFiscaliPFView datiFiscaliPFView = personaFisicaView.getDatiFiscaliPFView();
	        if ( datiFiscaliPFView.getIndicatoreA96() == null ) {
	        	datiFiscaliPFView.setIndicatoreA96(Boolean.FALSE);
	        }
	        if ( datiFiscaliPFView.getIndicatoreA97() == null ) {
	        	datiFiscaliPFView.setIndicatoreA97(Boolean.FALSE);
	        }
	        personaFisicaView.setIntermediariDati(true); // to force the validation for intermediari details.
	        personaFisicaView.setOrigineClienteDati(true); // to force the validation for originecliente details.
	        final Hashtable azHash = new SoggettoValidator().validateSoggetto(personaFisicaView);
	        final String errorMessage = (String) azHash.get("ERROR_MSG");
	        Collection documentiColl = null;
	        if (errorMessage.length() < 1) {
	        	if(azHash.get("SOGGETTO_EXISTS") != null) {
	        		soggettoId = (Long) azHash.get("SOGGETTO_EXISTS");
	        		personaFisicaView.setSoggettoAlreadyExist(true);
	        	} else {
	        		log4Debug.debug("AnagrafeManagerBeanPFHelper : createSoggettoPrivacyFiveAndSixLevelWithHost : isCSSECheckAllowed ==>",personaFisicaView.isCSSECheckAllowed());
	        		if(personaFisicaView.isCSSECheckAllowed()){
	        			checkCSSE(personaFisicaView);
	        		}
	        		final DatiFiscaliUtil datiFiscaliUtil = new DatiFiscaliUtil();
					datiFiscaliUtil.setRzValAndResidenzaFiscaliInANTICI(personaFisicaView, personaFisicaView.getMotiv());
	        		final Timestamp dateOfBirth = (personaFisicaView).getDatiAnagraficiPFView() != null ? (personaFisicaView).getDatiAnagraficiPFView().getDataDiNascita() : null;
					datiFiscaliUtil.setRegimeDataScadenza(dateOfBirth , (personaFisicaView).getDatiFiscaliPFView());
	        		soggettoId = creaOrGetSoggetto(personaFisicaView,
							operationCode);
	        		documentiColl = personaFisicaView.getDocumentiView();
	        	}
	            personaFisicaView.setId(soggettoId);
	        }
	        return new CommonHelper().getOutputXMLMessageForPF(errorMessage, soggettoId, documentiColl);
    	} catch( final LoggerException e ) {
    		log4Debug.warnStackTrace(e);
    		throw new BeanHelperException(e.getMessage());
    	} catch (final ControlloDatiPFException e) {
    		log4Debug.warnStackTrace(e);
    		throw new BeanHelperException(e.getMessage());
		}
    }

    private void checkCSSE( final PersonaFisicaView personaFisicaView ) throws RemoteException, BeanHelperException {
		if ( personaFisicaView != null && (personaFisicaView).getMotiv() != null
				&& !(personaFisicaView).getMotiv().contains("MINML") ) {
			log4Debug.debug(" AnagrafeManagerBeanPFHelper : checkCSSEAndSetRZVAL : CSSE Calling  >>>>>>>>>>>>");
	    	try {
	    		final String nome = personaFisicaView.getDatiAnagraficiPFView().getNome();
	    		final String cognome = personaFisicaView.getDatiAnagraficiPFView().getCognome();
	    		final String valoreOrgcl = personaFisicaView.getOrgcl() != null ? personaFisicaView.getOrgcl().getCampagnaDesc() : null;
	    		final Map map = new CSSEHandler().getEmbargoPFCount(nome, cognome, valoreOrgcl);
				if( map == null || map.get("INSTITUTIONAL") == null || ((Long)map.get("INSTITUTIONAL")).longValue() != 0 ) {
					throw new BeanHelperException(new AnagrafeHelper().getMessage("ANAG-1285"));
				}
			} catch (final SubSystemHandlerException e) {
				log4Debug.debugStackTrace(e);
				throw new BeanHelperException(e.getMessage());
			}
		}
    }
    
    /**
     * @param pfView
     */
    private void setRecapitiNonDispList(final PersonaFisicaView pfView) {
		final Boolean recapNonDispAllowedForLoginBank = RecapitiNonDisponibileHelper.isRecapNonDispAllowedForLoginBank();
		pfView.setRecapNonDispAllowed(recapNonDispAllowedForLoginBank);
		if(recapNonDispAllowedForLoginBank) {
			pfView.setRecapNonDispDetailList(new RecapitiNonDisponibileHelper().getRecapitiNonDispListForXML(pfView.getRecapitiPFView(), "Semplice"));
		}
	}
}
