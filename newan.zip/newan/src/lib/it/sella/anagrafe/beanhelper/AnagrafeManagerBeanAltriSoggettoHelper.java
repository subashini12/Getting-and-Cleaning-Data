package it.sella.anagrafe.beanhelper;

import it.sella.anagrafe.AltriSoggettoView;
import it.sella.anagrafe.BeanHelperException;
import it.sella.anagrafe.factory.AltriSoggettoFactory;
import it.sella.anagrafe.factory.AltriTipiSoggettoFactoryException;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.view.SoggettoView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Properties;

public class AnagrafeManagerBeanAltriSoggettoHelper extends AnagrafeManagerBeanHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AnagrafeManagerBeanAltriSoggettoHelper.class);

    public AnagrafeManagerBeanAltriSoggettoHelper() {
        logMsg = new StringBuffer();
        logForHost = new StringBuffer();
    }

    public Long performCensimento( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException {
        try {
        	final AltriSoggettoFactory altriTipiSoggettoFactory = (AltriSoggettoFactory) getAnagrafeFactory(soggettoView.getClass());
        	final Long soggettoId = altriTipiSoggettoFactory.createAltriTipoSoggetto((AltriSoggettoView) soggettoView);
            logMsg.append("<DataWrite>");
            logMsg.append(altriTipiSoggettoFactory.getLogData((AltriSoggettoView) soggettoView));
            logMsg.append("</DataWrite>");
            return soggettoId;
        } catch (final AltriTipiSoggettoFactoryException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    public void performCensimentoModifica( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException {
        try {
        	final AltriSoggettoFactory altriTipiSoggettoFactory =  (AltriSoggettoFactory) getAnagrafeFactory(soggettoView.getClass());
            // To log the old data
            final String oldData = altriTipiSoggettoFactory.getLogData(altriTipiSoggettoFactory.getAltriTipoSoggetto(soggettoView.getId()));
            logMsg.append("<DataView>");
			logMsg.append(oldData); // single usage of variable to avoid improper xml document construction, as there is possibility for exception in get method
            logMsg.append("</DataView>");
            altriTipiSoggettoFactory.setAltriTipoSoggetto((AltriSoggettoView) soggettoView);
            logMsg.append("<DataWrite>");
            logMsg.append(altriTipiSoggettoFactory.getLogData((AltriSoggettoView) soggettoView));
            logMsg.append("</DataWrite>");
        } catch (final AltriTipiSoggettoFactoryException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    public Long performCensimentoSH( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException {
        try {
        	final AltriSoggettoFactory altriTipiSoggettoFactory = (AltriSoggettoFactory) getAnagrafeFactory(soggettoView.getClass());
        	final Long soggettoId = altriTipiSoggettoFactory.createAltriTipoSoggetto((AltriSoggettoView) soggettoView);
            logMsg.append("<DataWrite>");
            logMsg.append(altriTipiSoggettoFactory.getLogData((AltriSoggettoView) soggettoView));
            logMsg.append("</DataWrite>");
            return soggettoId;
        } catch (final AltriTipiSoggettoFactoryException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    public void performCensimentoModificaSH( final SoggettoView soggettoView ) throws RemoteException, BeanHelperException {
        try {
        	final AltriSoggettoFactory altriTipiSoggettoFactory =  (AltriSoggettoFactory) getAnagrafeFactory(soggettoView.getClass());
            // To log the old data
            final String oldData = altriTipiSoggettoFactory.getLogData(altriTipiSoggettoFactory.getAltriTipoSoggetto(soggettoView.getId()));
            logMsg.append("<DataView>");
			logMsg.append(oldData); // single usage of variable to avoid improper xml document construction, as there is possibility for exception in get method
            logMsg.append("</DataView>");
            altriTipiSoggettoFactory.setAltriTipoSoggetto((AltriSoggettoView) soggettoView);
            logMsg.append("<DataWrite>");
            logMsg.append(altriTipiSoggettoFactory.getLogData((AltriSoggettoView) soggettoView));
            logMsg.append("</DataWrite>");
        } catch (final AltriTipiSoggettoFactoryException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    public SoggettoView getSoggetto( final Long soggettoId, final Properties properties ) throws RemoteException, BeanHelperException {
        try {
        	final AltriSoggettoFactory altriSoggettoFactory = (AltriSoggettoFactory) getAnagrafeFactory(AltriSoggettoView.class);
        	final SoggettoView soggettoView = altriSoggettoFactory.getAltriTipoSoggetto(soggettoId);
            logMsg.append(altriSoggettoFactory.getLogData((AltriSoggettoView) soggettoView));
            return soggettoView;
        } catch (final AltriTipiSoggettoFactoryException e) {
            log4Debug.warnStackTrace(e);
            throw new BeanHelperException(e.getMessage());
        }
    }

    public String createSoggetto( final SoggettoView soggettoView, final String parserError, final String banca, final String operationeCode ) throws RemoteException, BeanHelperException {
        throw new UnsupportedOperationException(new AnagrafeHelper().getMessage("ANAG-1304"));
    }

    public String createSoggettoWithHost( final SoggettoView soggettoView, final String parserError, final String banca, final String operationeCode ) throws RemoteException, BeanHelperException {
        throw new UnsupportedOperationException(new AnagrafeHelper().getMessage("ANAG-1304"));
    }
    
    public SoggettoView getViewAfterParsing( final String xmlSoggetto ) throws BeanHelperException {
    	throw new UnsupportedOperationException(new AnagrafeHelper().getMessage("ANAG-1304"));
    }

    public SoggettoView getViewAfterParsingPrivacyFiveLevelXML( final String xmlSoggetto ) throws BeanHelperException {
    	throw new UnsupportedOperationException(new AnagrafeHelper().getMessage("ANAG-1304"));
    }

	public Hashtable validateSoggettoXML( final SoggettoView soggettoView ) throws BeanHelperException, RemoteException {
		throw new UnsupportedOperationException(new AnagrafeHelper().getMessage("ANAG-1304"));
	}
}
