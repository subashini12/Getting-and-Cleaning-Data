package it.sella.anagrafe;

/* this is a singleton factory for getting an instance of the factory and the impl class */

public class AnagrafeManagerFactory {

    private static AnagrafeManagerFactory factory;
    private AnagrafeManagerClientImpl anagrafeManagerClientImpl;

    private AnagrafeManagerFactory() {
    }

    /**
     * This method gets an Instance of the AnagrafeManagerFactory
     * @return AnagrafeManagerFactory
     */

    public static AnagrafeManagerFactory getInstance() {
        if( factory == null ) {
        	factory = new AnagrafeManagerFactory();
        }
        return factory;
    }

    /**
     * This method gets an Instance of the AnagrafeManagerClientImpl
     * @return AnagrafeManagerClientImpl
     * @see AnagrafeManagerClientImpl
     */

    public AnagrafeManagerClientImpl getAnagrafeManagerClientImpl() {
        if( anagrafeManagerClientImpl == null ) {
        	anagrafeManagerClientImpl = new AnagrafeManagerClientImpl();
        }
        return anagrafeManagerClientImpl;
    }
}

