package it.sella.anagrafe;

import it.sella.anagrafe.factory.IMFactory;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Vector;

public class ASView implements IASView, Serializable {

    /**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(ASView.class);

    private Long opId = null;

    public Long getOpId() {
		return opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}

	public Collection getCausaleListFromViewProperties() {
        final Class viewClass = this.getClass();
        Collection propNames = null;

        final Field[] viewProps = viewClass.getDeclaredFields();
        propNames = new Vector(viewProps.length);
        for(int i = 0; i < viewProps.length; i++) {
        	if(!"AUTHOR".equals(viewProps[i].getName()) &&
            		!"REVISION".equals(viewProps[i].getName()) &&
            		!"DATE".equals(viewProps[i].getName()) &&
            		!"opId".equals(viewProps[i].getName()) &&
            		!"$VRc".equals(viewProps[i].getName()) &&
            		!"serialVersionUID".equals(viewProps[i].getName())) {
				propNames.add(viewProps[i].getName());
			}
        }
        return propNames;
    }

    public Object getValueForThisProperty(final String currentProperty) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        final Class viewClass = this.getClass();
        Object resultObject = null;
        final StringBuffer getMethodName = new StringBuffer("get").append(currentProperty);
        getMethodName.setCharAt(3, Character.toUpperCase(getMethodName.charAt(3)));
        final Class[] parameterType = new Class[0];
        final Method propertyMethod = viewClass.getMethod(getMethodName.toString(), parameterType);
        resultObject = propertyMethod.invoke(this, null);
        return resultObject;
    }

    public void setValueForThisProperty(final String currentProperty, final String value) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException {
        final Class viewClass = this.getClass();
        final StringBuffer setMethodName = new StringBuffer("set").append(currentProperty);
        setMethodName.setCharAt(3, Character.toUpperCase(setMethodName.charAt(3)));
        final Method[] methods = viewClass.getDeclaredMethods();
        for(int i = 0; i < methods.length; i++) {
            if(methods[i].getName().equalsIgnoreCase(setMethodName.toString())) {
                final Class[] parameterType = methods[i].getParameterTypes();
                if(parameterType[0] == java.lang.String.class) {
                    final Object[] obj = new String[1];
                    obj[0] = value;
                    methods[i].invoke(this, obj);
                } else if(parameterType[0] == java.lang.Boolean.class) {
                    final Object[] obj = new Boolean[1];
                    obj[0] = Boolean.valueOf(value);
                    methods[i].invoke(this, obj);
                } else if(parameterType[0] == it.sella.anagrafe.common.Nazione.class) {
                    final Object[] obj = new it.sella.anagrafe.common.Nazione[1];
                    try {
						obj[0] = IMFactory.getInstance().getNazione(Long.valueOf(value));
					} catch (final Exception e) {
						log4Debug.warnStackTrace(e);
                        obj[0] = null;
					}
                    methods[i].invoke(this, obj);
                } else if(parameterType[0] == it.sella.classificazione.ClassificazioneView.class) {
                    final Object[] obj = new it.sella.classificazione.ClassificazioneView[1];
                    try {
                        obj[0] = ClassificazioneHandler.getClassificazioneView(Long.valueOf(value));
					} catch (final Exception e) {
						log4Debug.warnStackTrace(e);
                        obj[0] = null;
					}
                    methods[i].invoke(this, obj);
                }
                break;
            }
        }
    }

}
