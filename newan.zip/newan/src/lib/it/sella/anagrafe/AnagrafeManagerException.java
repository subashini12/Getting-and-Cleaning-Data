package it.sella.anagrafe;

public class AnagrafeManagerException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	AnagrafeManagerException() {

    }

    AnagrafeManagerException(final String errMessage) {
        super(errMessage);
    }
}

