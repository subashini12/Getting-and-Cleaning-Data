package it.sella.anagrafe;

/**
 * @author GBS03447
 *
 */
public class DAIConfigException extends AnagrafeDAIException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public DAIConfigException() {
		// Explicit Empty Constructor
	}
	
	public DAIConfigException(final String errMessage) {
		super(errMessage);
	}
	
	public DAIConfigException (final String errMessage, final Throwable cause) {
		super(errMessage, cause);
	}

}
