package it.sella.anagrafe.altritiposoggetto;

public class AltriTipoSoggettoView implements AltriTipoSoggetto{ // extends EJBViewAdapter implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;
	
    private Long soggettoId;
    private Long opId;

    private String value;

    public AltriTipoSoggettoView() {
    }

    public AltriTipoSoggettoView(final Long soggettoId, final String value) {
        this.setSoggettoId(soggettoId);
        this.setDenominazione(value);

    }

//public getter methods
    public Long getSoggettoId() {
        return this.soggettoId;
    }

    public String getDenominazione() {
        return this.value;
    }

//public setter methods
    public void setSoggettoId(final Long soggettoId) {
        this.soggettoId = soggettoId;
    }

    public void setDenominazione(final String value) {
        this.value = value;
    }

//protected parameterlist methods
    protected String getParameterList() {
        return "Soggetto Id" + this.getSoggettoId() + "Value=" + this.getDenominazione();
    }

    protected String getShortParameterList() {
        return getParameterList();
    }

	public Long getOpId() {
		return opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}

	public Long getId() {
		return id;
	}

	public void setId(final Long id) {
		this.id = id;
		
	}

}

