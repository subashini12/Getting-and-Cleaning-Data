package it.sella.anagrafe.altritiposoggetto;

import it.sella.anagrafe.GestoreAnagrafeException;

import javax.ejb.FinderException;

public interface IAltriTipoSoggettoBeanManager {
	
	
	/**
	 * Method to create AltriTipoSoggetto
	 * @param altrisoggetto
	 * @return
	 * @throws GestoreAnagrafeException
	 */
	AltriTipoSoggetto create (AltriTipoSoggetto altrisoggetto) throws GestoreAnagrafeException;
	
	
	/**
	 * Method to update AltriTipoSoggetto
	 * @param altrisoggetto
	 * @return
	 */
	AltriTipoSoggetto update(AltriTipoSoggetto altrisoggetto);
	
	
	/**
	 * Method to Find data passing Primary 
	 * Key
	 * @param primaryKey
	 * @return
	 * @throws FinderException
	 */
	AltriTipoSoggetto findByPrimaryKey (Long primaryKey)throws FinderException;
	
	
	/**
	 * Method to Find data by passing Description
	 * @param Denominazione
	 * @return
	 * @throws FinderException
	 */
	AltriTipoSoggetto findByDenominazione (String Denominazione)throws FinderException;
	
	
	/**
	 * Method to find data by passing SoggettoId
	 * @param soggId
	 * @return
	 * @throws FinderException
	 */
	AltriTipoSoggetto findBySoggettoId (Long soggId) throws FinderException;
	
}
