package it.sella.anagrafe.altritiposoggetto;

import java.io.Serializable;

public interface AltriTipoSoggetto extends Serializable { //extends IEJBEntityObject {
	
	Long getId();
	
    Long getSoggettoId ();

    String getDenominazione ();
    
    Long getOpId();
    
    void setId(Long id);

    void setSoggettoId (Long soggettoId);

    void setDenominazione (String value);

	void setOpId(Long opId);
}
