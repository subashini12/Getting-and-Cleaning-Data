package it.sella.anagrafe;

public class AnagrafeDAIException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AnagrafeDAIException() {
		// Explicit Empty Constructor
	}

	public AnagrafeDAIException(final String errMessage) {
		super(errMessage);
	}

	public AnagrafeDAIException(final String errMessage, final Throwable cause) {
		super(errMessage, cause);
	}

}
