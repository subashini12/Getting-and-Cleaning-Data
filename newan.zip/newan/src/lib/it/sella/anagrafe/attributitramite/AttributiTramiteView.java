package it.sella.anagrafe.attributitramite;

public class AttributiTramiteView implements AttributiTramite { //extends EJBViewAdapter implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public void setAttributitramiteId(final Long attributitramiteId) {
		this.attributitramiteId = attributitramiteId;
	}

	public Long getAttributitramiteId() {
		return attributitramiteId;
	}

	public Long getAROB() {
		return aROB;
	}

	public void setAROB(final Long arob) {
		aROB = arob;
	}
	
	public Long getEROB() {
		return eROB;
	}
	
	public void setEROB(final Long erob) {
		eROB = erob;
	}
	
	public Long getNazione() {
		return nazione;
	}
	
	public void setNazione(final Long nazione) {
		this.nazione = nazione;
	}
	
	public Long getOpId() {
		return opId;
	}
	
	public void setOpId(final Long opId) {
		this.opId = opId;
	}
	
	public String getSettore() {
		return settore;
	}
	
	public void setSettore(final String settore) {
		this.settore = settore;
	}
	
	public Long getSoggettoId() {
		return soggettoId;
	}
	
	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}
	
	protected String getParameterList() {
        return "Soggetto Id" + this.getSoggettoId();
    }

    protected String getShortParameterList() {
        return getParameterList();
    }

    private Long attributitramiteId;
    private Long soggettoId;
	private Long nazione;
	private String settore;
	private Long aROB;
	private Long eROB;
	private Long opId;
	
}
