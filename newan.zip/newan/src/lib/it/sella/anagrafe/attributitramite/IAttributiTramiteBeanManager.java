package it.sella.anagrafe.attributitramite;

import it.sella.anagrafe.GestoreAnagrafeException;

import javax.ejb.FinderException;

public interface IAttributiTramiteBeanManager {
	
	/**
	 * Method to create Attribute Tramite
	 * @param AttributiTramiteView
	 * @return
	 * @throws GestoreAnagrafeException
	 */
	AttributiTramite create(AttributiTramite AttributiTramiteView) throws GestoreAnagrafeException;
	
	/**
	 * Method to update Attribute Tramite
	 * @param AttributiTramiteView
	 * @return
	 */
	AttributiTramite update(AttributiTramite AttributiTramiteView);
	
	
	/**
	 * Method to find data using primary key
	 * @param primaryKey
	 * @return
	 * @throws FinderException
	 */
	AttributiTramite findByPrimaryKey(Long primaryKey) throws FinderException;
	
	
	/**
	 * Method to find data using SoggettoId
	 * @param soggettoId
	 * @return
	 * @throws FinderException
	 */
	AttributiTramite findBySoggettoId(Long soggettoId) throws FinderException;
}
