package it.sella.anagrafe.attributitramite;

import java.io.Serializable;

public interface AttributiTramite extends Serializable {
	
	public void setAttributitramiteId(Long attributitramiteId);
	public Long getAttributitramiteId();
	public Long getAROB();
	public void setAROB(Long arob);
	public Long getEROB();
	public void setEROB(Long erob);
	public Long getNazione();
	public void setNazione(Long nazione);
	public Long getOpId();
	public void setOpId(Long opId);
	public String getSettore();
	public void setSettore(String settore);
	public Long getSoggettoId();
	public void setSoggettoId(Long soggettoId);

}