package it.sella.anagrafe.controllo;

public class ControlloDatiException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ControlloDatiException() {
    	
    }

    public ControlloDatiException( final String errorMessage ) {
        super(errorMessage);
    }
}
