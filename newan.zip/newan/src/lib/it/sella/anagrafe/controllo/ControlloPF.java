package it.sella.anagrafe.controllo;

import it.sella.anagrafe.GestoreNazioneException;
import it.sella.anagrafe.common.Citta;
import it.sella.anagrafe.common.Nazione;
import it.sella.anagrafe.dbaccess.NazioneDBAccessHelper;
import it.sella.anagrafe.pf.AttributiEsterniPFView;
import it.sella.anagrafe.pf.DatiAnagraficiPFView;
import it.sella.anagrafe.pf.DatiFiscaliPFView;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.DateHandler;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.Collection;

public class ControlloPF extends ControlloFiscalDetailsBase {


    private static final String[] month = {"A", "B", "C", "D", "E", "H", "L", "M", "P", "R", "S", "T"};

    public static String controlloCodiceFiscale(final DatiAnagraficiPFView pfView,
			final AttributiEsterniPFView aeView, final String inputCodiceFiscali , final boolean isThruXml)
			throws ControlloDatiPFException, RemoteException {
        if( pfView != null && aeView != null && inputCodiceFiscali != null && pfView.getNome() != null && pfView.getCognome() != null &&
        		aeView.getSesso() != null && pfView.getDataDiNascita() != null && pfView.getLuogoDiNascitaNazione() != null ) {
        	return isValidCodiceFiscale(pfView.getCognome(), pfView.getNome(), pfView.getDataDiNascita(), pfView.getLuogoDiNascitaCitta(), pfView.getLuogoDiNascitaNazione().getNome(), aeView.getSesso().getDescrizione(), isThruXml, inputCodiceFiscali) ? "OK" : "KO";
        } else {
            return ("KO");
        }
    }

    public static String creaCodiceFiscale(final String cogNome, final String Nome,
			final Timestamp dataNascita, final Citta luogoNascitaCitta,
			final Nazione luogoNascitaNazione, final String sesso, final boolean isThruXml)
			throws ControlloDatiPFException {
    	final StringBuffer codiceFiscaliGenerated = new StringBuffer();
        String luogoNascitaF = null;
        final AnagrafeHelper helper = new AnagrafeHelper();
        final String cogNomeF = getFilteredCogNome(cogNome);
        final String nomeF = getFilteredNome(Nome);
        if(cogNomeF == null || cogNomeF.trim().length() == 0 || nomeF == null || nomeF.trim().length() == 0 ||
        		dataNascita == null || luogoNascitaNazione == null) {
            throw new ControlloDatiPFException(helper.getMessage("ANAG-1193" ,isThruXml));
        }
        final DateHandler dateHandler = new DateHandler();
        final StringBuffer dataNascitaF = new StringBuffer(dateHandler.formatDate(dataNascita,"yy"));
        final String date = dateHandler.formatDate(dataNascita,"dd");
        dataNascitaF.append(month[(Integer.parseInt(dateHandler.formatDate(dataNascita,"MM")))-1]);
        dataNascitaF.append("F".equals(sesso) ? String.valueOf(Integer.parseInt(date) + 40) : date);
        if(luogoNascitaNazione.getNome().equalsIgnoreCase("ITALIA")) {
            if(luogoNascitaCitta == null) {
				final String errorMessage = "luogoNascitaCitta ";
				throw new ControlloDatiPFException(errorMessage + helper.getMessage("ANAG-1264" ,isThruXml));
			}
            luogoNascitaF = luogoNascitaCitta.getCncf();
        } else {
            luogoNascitaF = luogoNascitaNazione.getCncf();
        }
        codiceFiscaliGenerated.append(cogNomeF).append(nomeF).append(dataNascitaF).append(luogoNascitaF);
        final String cin = getCIN(codiceFiscaliGenerated.toString());
        if(cin.equals("")) {
            throw new ControlloDatiPFException(helper.getMessage("ANAG-1193" ,isThruXml));
        }
        codiceFiscaliGenerated.append(cin);
        return codiceFiscaliGenerated.toString();
    }

    public static void controlloPartitaIva(final DatiFiscaliPFView datiFiscaliPFView , final boolean isThruXML) throws ControlloDatiPFException {
    	try {
			Long.parseLong(datiFiscaliPFView.getPartitaIva());
    	} catch (final NumberFormatException e) {
    		throw new ControlloDatiPFException(new AnagrafeHelper().getMessage("ANAG-1417" ,isThruXML));
		}
        String partitaIva = "00000" + datiFiscaliPFView.getPartitaIva();
        final AnagrafeHelper helper = new AnagrafeHelper();
        final String cinInput = partitaIva.substring(partitaIva.length() - 1);
        partitaIva = partitaIva.substring(0, partitaIva.length() - 1);
        int total = 0;
        for (int i = 0; i < partitaIva.length(); i++) {
        	int number = Integer.parseInt(String.valueOf(partitaIva.charAt(i)));
            if (i % 2 == 0) {
                number = number * 2;
                final String strNumber = String.valueOf(number);
                if (strNumber.length() > 1) {
                    number = Integer.parseInt(String.valueOf(strNumber.charAt(0)));
                    number += Integer.parseInt(String.valueOf(strNumber.charAt(1)));
                }
            }
            total += number;
        }
        final int sChar = total > 9 ? total % 10 : total;
        final String cinCalculated = sChar == 0 ? "0" : String.valueOf(10 - sChar);
        if(!cinInput.equals(cinCalculated)) {
            throw new ControlloDatiPFException(helper.getMessage("ANAG-1194" ,isThruXML));
        }
    }

    public static boolean isValidCodiceFiscale(final String cogNome, final String nome, final Timestamp dataNascita, final Citta luogoNascitaCitta, final String nazioneNome, final String sesso, final boolean isThruXml, final String inputCodiceFiscali) throws RemoteException, ControlloDatiPFException{
    	boolean flag = false;
    	try {
    		final Collection<Nazione> nazioneList = new NazioneDBAccessHelper().nazioneList(nazioneNome);
    		String calculatedCodiceFiscali = null;
    		for(final Nazione nazione : nazioneList) {
    			calculatedCodiceFiscali = creaCodiceFiscale(cogNome, nome, dataNascita, luogoNascitaCitta, nazione, sesso, isThruXml);
    			if(inputCodiceFiscali.equalsIgnoreCase(calculatedCodiceFiscali)) {
    				flag = true;
    				break;
    			}else if("OK".equals(ControlloPF.controlloOmonimiaCF(inputCodiceFiscali,calculatedCodiceFiscali))){
    				flag = true;
    				break;
    			}
    		}
    	} catch (final GestoreNazioneException gestoreNazioneException) {
    		throw new ControlloDatiPFException(gestoreNazioneException.getMessage());
    	}
    	return flag;
    }

}
