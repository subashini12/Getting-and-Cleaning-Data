package it.sella.anagrafe.controllo;

public class ControlloDatiPLException extends ControlloDatiException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ControlloDatiPLException() {
    }

    /** @param errorMessage    String */
    public ControlloDatiPLException(final String errorMessage) {
        super(errorMessage);
    }
}
