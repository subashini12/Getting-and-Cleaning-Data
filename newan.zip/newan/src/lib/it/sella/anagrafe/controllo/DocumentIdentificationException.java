package it.sella.anagrafe.controllo;

/**
 * Exception class to manage the DocumentIdentificationCheck
 */
public class DocumentIdentificationException extends Exception{
	

	private static final long serialVersionUID = 1L;

	public DocumentIdentificationException() {
		// Explicit Empty Constructor
    }

    public DocumentIdentificationException( final String errorMessage ) {
        super(errorMessage);
    }
	
    public DocumentIdentificationException(final String errMessage, final Throwable paramThrowable)
	{
		super(errMessage, paramThrowable);
	}    

}
