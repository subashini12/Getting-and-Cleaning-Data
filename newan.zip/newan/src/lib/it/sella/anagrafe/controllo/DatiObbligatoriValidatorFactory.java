package it.sella.anagrafe.controllo;

public abstract class DatiObbligatoriValidatorFactory {

    static final String SEMPLICE = "Semplice";

    public abstract DatiObbligatoriValidator getDatiObbligatoriValidator(Class tipoDatiClass);

    public static DatiObbligatoriValidatorFactory getFactory(final String tipoSoggettoNome) {
        DatiObbligatoriValidatorFactory datiObbligatoriValidatorFactory = null;
//       if(SEMPLICE.equals(tipoSoggettoNome)){ // simple persona fisica
        datiObbligatoriValidatorFactory = new DatiObbligatoriValidatorPFFactory();
//       }
        return datiObbligatoriValidatorFactory;
    }

}
