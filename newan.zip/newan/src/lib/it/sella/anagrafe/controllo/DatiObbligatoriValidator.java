package it.sella.anagrafe.controllo;

import it.sella.anagrafe.implementation.IView;

import java.util.List;

public interface DatiObbligatoriValidator {

    /*
     * This method takes the view object that is of type IView. That is
     * view that is composed of related properties that are inturn
     * stored and collected from classificazione.
     */

    void ControlloDatiObbligatori( final IView viewObject, final String motiv, final Long soggettoId , final Boolean  isUSOrigin, final List allMotivColl, boolean isThruXml,final Boolean isPartitaIvaNotMandatory ) throws ControlloObbligatoriPFException;
}
