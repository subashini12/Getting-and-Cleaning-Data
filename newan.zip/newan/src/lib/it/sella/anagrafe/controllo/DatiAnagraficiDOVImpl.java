package it.sella.anagrafe.controllo;

import it.sella.anagrafe.implementation.IView;
import it.sella.anagrafe.pf.DatiAnagraficiPFView;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.StringHandler;

import java.sql.Timestamp;
import java.util.List;

public class DatiAnagraficiDOVImpl implements DatiObbligatoriValidator {

    public DatiAnagraficiDOVImpl() {
    }

    public void ControlloDatiObbligatori( final IView pfViewObject, final String motiv, final Long soggettoId , final Boolean isUSorgin, final List allMotivColl, final boolean isThruXml,final Boolean isPartitaIvaNotMandatory ) throws ControlloObbligatoriPFException {
    	final AnagrafeHelper helper = new AnagrafeHelper();
    	final DatiAnagraficiPFView viewObject = (DatiAnagraficiPFView) pfViewObject;
        if("CENST".equals(motiv) || "FORNT".equals(motiv) ) {
            if (viewObject != null) {
                if(viewObject.getNome() == null) {
                    throw new ControlloObbligatoriPFException(helper.getMessage("ANAG-1195" ,isThruXml));
                }
                if(viewObject.getCognome() == null) {
                    throw new ControlloObbligatoriPFException(helper.getMessage("ANAG-1196" ,isThruXml));
                }
            } else {
                throw new ControlloObbligatoriPFException(helper.getMessage("ANAG-1195" ,isThruXml));
            } 
            //validateCitta( pfViewObject );//  -- 1 -- To add new Motive in IMELB by thiru 
        } else if("CLINT".equalsIgnoreCase(motiv) ||"ANTCI".equals(motiv) || "DIPEN".equals(motiv) ||
        		  "PROMT".equals(motiv) || "SVILP".equals(motiv) || "IMELB".equals(motiv) ||
        		  "MINML".equals(motiv) || "POSTE".equals(motiv)) {	// POSTE (Post Office-POS Machine Owners) : DatiAnagrafica Validations.
            if(viewObject.getNome() == null) {
                throw new ControlloObbligatoriPFException(helper.getMessage("ANAG-1195" ,isThruXml));
            }
            if(viewObject.getCognome() == null) {
                throw new ControlloObbligatoriPFException(helper.getMessage("ANAG-1196" ,isThruXml));
            }
            if(viewObject.getDataDiNascita() == null) {
                throw new ControlloObbligatoriPFException(helper.getMessage("ANAG-1197" ,isThruXml));
            } else if(viewObject.getDataDiNascita() != null) {
            	final DateHandler dateHandler = new DateHandler();
            	final int dataDiNacitaYear = Integer.parseInt(dateHandler.formatDate(viewObject.getDataDiNascita(),"yyyy"));
            	final int todayYear = Integer.parseInt(dateHandler.formatDate(new Timestamp(System.currentTimeMillis()),"yyyy"));
                if( (todayYear - dataDiNacitaYear) >= 120 ) {
                	throw new ControlloObbligatoriPFException(helper.getMessage("ANAG-1198" ,isThruXml));
                }
            }
            if(viewObject.getLuogoDiNascitaNazione() == null) {
                throw new ControlloObbligatoriPFException(helper.getMessage("ANAG-1147" ,isThruXml));
            }
            if("ITALIA".equals(viewObject.getLuogoDiNascitaNazione().getNome()) && (viewObject.getLuogoDiNascitaCitta() == null || viewObject.getLuogoDiNascitaCitta().getCommune() == null)) {
                throw new ControlloObbligatoriPFException(helper.getMessage("ANAG-1199" ,isThruXml));
            }
            validateCitta( pfViewObject, soggettoId ,isThruXml);
           
        } else if("DELEG".equalsIgnoreCase(motiv) && (viewObject.getDataDiNascita() != null)) {
        	final DateHandler dateHandler = new DateHandler();
        	final int dataDiNacitaYear = Integer.parseInt(dateHandler.formatDate(viewObject.getDataDiNascita(),"yyyy"));
        	final int todayYear = Integer.parseInt(dateHandler.formatDate(new Timestamp(System.currentTimeMillis()),"yyyy"));
            if( (todayYear - dataDiNacitaYear) <= 18 ) {
            	throw new ControlloObbligatoriPFException(helper.getMessage("ANAG-1200" ,isThruXml));
            }
        }
        
    }
    
    private void validateCitta(final IView pfViewObject, final Long soggettoId,
			final boolean isThruXml) throws ControlloObbligatoriPFException {
    	final DatiAnagraficiPFView viewObject = (DatiAnagraficiPFView) pfViewObject;
    	final AnagrafeHelper helper = new AnagrafeHelper();
        if( soggettoId == null && viewObject != null && viewObject.getLuogoDiNascitaNazione() != null && 
        		!"ITALIA".equalsIgnoreCase( viewObject.getLuogoDiNascitaNazione().getNome())) {
        	if( viewObject.getLuogoDiNascitaCitta() == null || 
            		viewObject.getLuogoDiNascitaCitta().getCommune() == null || viewObject.getLuogoDiNascitaCitta().getCommune().trim().length() == 0 ) {
            	throw new ControlloObbligatoriPFException(helper.getMessage("ANAG-1210" ,isThruXml));
            }
            final StringHandler stringHandler = new StringHandler();            
			if( stringHandler.isLengthLessThanSpecifiedMinLength(viewObject.getLuogoDiNascitaCitta().getCommune(), 3) ) {
            	throw new ControlloObbligatoriPFException(helper.getMessage("ANAG-1503" ,isThruXml));
            }
            if( stringHandler.isNumericCharExistMoreThanSpecifiedLength(viewObject.getLuogoDiNascitaCitta().getCommune(), 2) || 
            		stringHandler.isConsequentCharsSame(viewObject.getLuogoDiNascitaCitta().getCommune()) ) {
            	throw new ControlloObbligatoriPFException(helper.getMessage("ANAG-1502" ,isThruXml));
            }
        }     
    }
}