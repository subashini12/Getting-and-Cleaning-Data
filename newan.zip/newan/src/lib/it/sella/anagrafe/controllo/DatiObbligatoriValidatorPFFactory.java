package it.sella.anagrafe.controllo;

import it.sella.anagrafe.pf.DatiPrivacyPFFiveLevelView;

public class DatiObbligatoriValidatorPFFactory extends DatiObbligatoriValidatorFactory {

    /** @link dependency */
    /*#DatiObbligatoriValidator lnkDatiObbligatoriValidator;*/

    public DatiObbligatoriValidator getDatiObbligatoriValidator(final Class tipoDatiClass) {
        DatiObbligatoriValidator datiObbligatoriValidator = null;
        if(tipoDatiClass == it.sella.anagrafe.pf.DatiAnagraficiPFView.class) {
            datiObbligatoriValidator = new DatiAnagraficiDOVImpl();
        } else if(tipoDatiClass == it.sella.anagrafe.pf.DatiPrivacyPFView.class) {
            datiObbligatoriValidator = new DatiPrivacyDOVImpl();
        } else if(tipoDatiClass == it.sella.anagrafe.pf.DatiFiscaliPFView.class) {
            datiObbligatoriValidator = new DatiFiscaliDOVImpl();
        } else if(tipoDatiClass == DatiPrivacyPFFiveLevelView.class) {
            datiObbligatoriValidator = new DatiPrivacyDOVImpl();
        } 
        return datiObbligatoriValidator;
    }
}
