package it.sella.anagrafe.controllo;

import it.sella.anagrafe.implementation.IView;
import it.sella.anagrafe.pf.DatiFiscaliPFView;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.validator.ValidatorHelper;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.List;

public class DatiFiscaliDOVImpl implements DatiObbligatoriValidator {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DatiFiscaliDOVImpl.class);

    public DatiFiscaliDOVImpl() {
    }

    public void ControlloDatiObbligatori(final IView viewObject,
			final String motiv, final Long soggettoId, final Boolean isUSOrigin,
			final List allMotivColl, final boolean isThruXml,final Boolean isPartitaIvaNotMandatory) throws ControlloObbligatoriPFException {
    	final DatiFiscaliPFView datiFiscaliPFView = (DatiFiscaliPFView) viewObject;
    	final String tipoSoggetto = datiFiscaliPFView.getTipoSoggetto();
    	boolean isW9NoCertMandatory = false;
    	if(tipoSoggetto != null && "Semplice".equals(tipoSoggetto)){
    		isW9NoCertMandatory = true;
    	}
    	final AnagrafeHelper helper = new AnagrafeHelper();
    	log4Debug.debug(" DatiFiscaliDOVImpl : ControlloDatiObbligatori : motiv :==>>>",motiv);
    	if ( "CLINT".equalsIgnoreCase(motiv) ) {	
    		checkForNullAndThrowException(datiFiscaliPFView.getRzVal(),"ANAG-1252", isThruXml);
    		checkForNullAndThrowException(datiFiscaliPFView.getResidenteFiscali(),"ANAG-1252", isThruXml);
    		if(datiFiscaliPFView.getRzVal() != null && !"ITALIA".equals(datiFiscaliPFView.getRzVal().getNome()) &&
    				datiFiscaliPFView.getCertRV() != null && !datiFiscaliPFView.getCertRV().booleanValue()) {
    			throw new ControlloObbligatoriPFException(helper.getMessage("ANAG-1201" ,isThruXml));
    		}
    		// If None of the ResidenzaFiscali1, ResidenzaFiscali2, ResidenzaFiscali3 is "ITALIA" .. then A97 Value should be true.
			if(!helper.isItaliaNazione(datiFiscaliPFView.getResidenteFiscali()) && !helper.isItaliaNazione(datiFiscaliPFView.getResidenteFiscali2()) && !helper.isItaliaNazione(datiFiscaliPFView.getResidenteFiscali3())) {
				if( datiFiscaliPFView.getIndicatoreA97() != null && datiFiscaliPFView.getIndicatoreA97().booleanValue() == false ) {
					throw new ControlloObbligatoriPFException(helper.getMessage("ANAG-1202" ,isThruXml));
				}
				ValidatorHelper.validateCodiceFiscaleEstero(isUSOrigin,  datiFiscaliPFView, false ,isThruXml, isW9NoCertMandatory);// CodiceFiscaleEstero is not mandatory for non italian and non US so that isCFEMandatory passed as false.
			}
        } else if("DIPEN".equalsIgnoreCase(motiv) || "PROMT".equalsIgnoreCase(motiv) || "SVILP".equalsIgnoreCase(motiv)) {
        	ValidatorHelper.checkForNullOrDummyAndThrowException(datiFiscaliPFView.getCodiceFiscali(),"ANAG-1204", isThruXml);
			ValidatorHelper.validateCodiceFiscaleEstero(isUSOrigin,  datiFiscaliPFView, false ,isThruXml, isW9NoCertMandatory);
        } else if( "POSTE".equalsIgnoreCase(motiv)) {	// POSTE (Post Office-POS Machine Owners) 
        	// Removed Check for ANTCI as the A97 check is not required for ANTCI
        	 if(datiFiscaliPFView.getResidenteFiscali() != null && !"ITALIA".equals(datiFiscaliPFView.getResidenteFiscali().getNome()) &&
					datiFiscaliPFView.getIndicatoreA97() != null && !datiFiscaliPFView.getIndicatoreA97().booleanValue() &&
					soggettoId == null) {
				throw new ControlloObbligatoriPFException(helper.getMessage("ANAG-1202" ,isThruXml));
            }
        } else if("TRAM".equalsIgnoreCase(motiv) || "DEPTI".equalsIgnoreCase(motiv)) {
        	ValidatorHelper.checkForNullOrDummyAndThrowException(datiFiscaliPFView.getCodiceFiscali(),"ANAG-1007", isThruXml);
        	if(!isPartitaIvaNotMandatory){
        		ValidatorHelper.checkForNullOrDummyAndThrowException(datiFiscaliPFView.getPartitaIva(),"ANAG-1058", isThruXml);
        	}
			checkForNullAndThrowException(datiFiscaliPFView.getResidenteFiscali(),"ANAG-1103", isThruXml);
			checkForNullAndThrowException(datiFiscaliPFView.getRzVal(),"ANAG-1104", isThruXml);
			ValidatorHelper.validateCodiceFiscaleEstero(isUSOrigin,  datiFiscaliPFView , false ,isThruXml, isW9NoCertMandatory);
        } else if( "IMELB".equalsIgnoreCase(motiv)) {
        	if ( datiFiscaliPFView.getResidenteFiscali() != null && 
        		  !"ITALIA".equals(datiFiscaliPFView.getResidenteFiscali().getNome())) { // -- 1 -- New motiv IMELB added by thiru
        		ValidatorHelper.validateCodiceFiscaleEstero(isUSOrigin,  datiFiscaliPFView , false ,isThruXml, isW9NoCertMandatory); // CodiceFiscaleEstero is not mandatory for non italian and non US so that isCFEMandatory passed as false.
        	}	
        } else if( "MINML".equalsIgnoreCase(motiv) ) {
        	ValidatorHelper.checkForNullOrDummyAndThrowException(datiFiscaliPFView.getCodiceFiscali(),"ANAG-1007", isThruXml);
        	if ( datiFiscaliPFView != null && datiFiscaliPFView.getResidenteFiscali() != null && 
          		  !"ITALIA".equals(datiFiscaliPFView.getResidenteFiscali().getNome())) { 
        		ValidatorHelper.validateCodiceFiscaleEstero(isUSOrigin,  datiFiscaliPFView, false ,isThruXml, isW9NoCertMandatory); // CodiceFiscaleEstero is not mandatory for non italian and non US so that isCFEMandatory passed as false.       		
        	}
        } else if( allMotivColl != null && !allMotivColl.isEmpty() && !allMotivColl.contains("ANTCI") && !allMotivColl.contains("POSTE")) {  // POSTE (Post Office-POS Machine Owners) : avoid CodiceFiscaliEstero validations.
        	ValidatorHelper.validateCodiceFiscaleEstero(isUSOrigin,  datiFiscaliPFView, false ,isThruXml, isW9NoCertMandatory);
        }
        if ( datiFiscaliPFView != null && !ValidatorHelper.isNullOrDummy(datiFiscaliPFView.getCodQI()) ) {
        	ValidatorHelper.validateIsNumeric(datiFiscaliPFView.getCodQI(), "ANAG-1514" ,isThruXml);
        }
        //For PF and AZ, If UsOrigin true & W9 is true then any one of the ResidenteFiscale should be STATI UNITI (If none of the RF is STATI UNITI .. Error will raised).
        ValidatorHelper.validateResidenteFiscaliBasedOnW9(isUSOrigin, datiFiscaliPFView.getW9(), datiFiscaliPFView.getResidenteFiscali(), datiFiscaliPFView.getResidenteFiscali2(), datiFiscaliPFView.getResidenteFiscali3(), isThruXml);
    }

    /**
 * To check whether the object is null or not
 * @param object
 * @param errorMessageCode
 * @param isThruXml
 * @throws ControlloObbligatoriPFException
 */
	private void checkForNullAndThrowException( final Object object, final String errorMessageCode, final boolean isThruXml ) throws ControlloObbligatoriPFException {
		if ( object == null ) {
			throw new ControlloObbligatoriPFException(new AnagrafeHelper().getMessage(errorMessageCode ,isThruXml));
		}
	}
	
}