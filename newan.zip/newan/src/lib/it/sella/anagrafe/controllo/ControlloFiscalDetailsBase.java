package it.sella.anagrafe.controllo;

import java.util.Arrays;
import java.util.Collection;
import java.util.Hashtable;

public class ControlloFiscalDetailsBase {

    private static final String[] consonants = {"B", "C", "D", "F", "G", "H", "J", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "V", "W", "X", "Y", "Z"};
    private static final String[] vowels = {"A", "E", "I", "O", "U"};
    private static Hashtable omonimiaChars = null;
    
    private static void initializeOmonimiaChars() {
    	if(omonimiaChars == null){
	    	omonimiaChars = new Hashtable();
	        omonimiaChars.put("0","L");
	        omonimiaChars.put("1","M");
	        omonimiaChars.put("2","N");
	        omonimiaChars.put("3","P");
	        omonimiaChars.put("4","Q");
	        omonimiaChars.put("5","R");
	        omonimiaChars.put("6","S");
	        omonimiaChars.put("7","T");
	        omonimiaChars.put("8","U");
	        omonimiaChars.put("9","V");
    	}
    }

  public static String controlloOmonimiaCF(final String inputCodiceFiscale, final String calculatedCodiceFiscale) {
        final String inputCF = inputCodiceFiscale.substring(0, inputCodiceFiscale.length() - 1);
        final String calculatedCF = calculatedCodiceFiscale.substring(0, calculatedCodiceFiscale.length() - 1);
        initializeOmonimiaChars();
        for(int k = 14; k >= 0; k--) {
            final String inputChar = String.valueOf(inputCF.charAt(k));
            final String calculatedChar = String.valueOf(calculatedCF.charAt(k));
            if(!inputChar.equalsIgnoreCase(calculatedChar)) {
                if(k ==14 || k == 13 || k == 12 || k == 10 || k == 9 || k ==7 || k == 6) {
                    final String omonimiaChar = (String)omonimiaChars.get(calculatedChar);
                    if(!inputChar.equalsIgnoreCase(omonimiaChar)) {
                        return ("KO");
                    }
                } else {
                    return ("KO");
                }
            }
        }
        final String calculatedCin = getCIN(inputCF); // again cin calculated for the input codice fiscale
        final String inputCinChar = String.valueOf(inputCodiceFiscale.charAt(15));
        return !inputCinChar.equals(calculatedCin) ? "KO" : "OK"; 
    }

    static String getCIN(final String totalePF) {
        final String general [] = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
                             "A", "B", "C", "D", "E", "F", "G", "H", "I", "J",
                             "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T",
                             "U", "V", "W", "X", "Y", "Z"};
        final String odd [] = {"01", "00", "05", "07", "09", "13", "15", "17", "19", "21",
                         "01", "00", "05", "07", "09", "13", "15", "17", "19", "21",
                         "02", "04", "18", "20", "11", "03", "06", "08", "12", "14",
                         "16", "10", "22", "25", "24", "23"};
        final String even [] = {"00", "01", "02", "03", "04", "05", "06", "07", "08", "09",
                          "00", "01", "02", "03", "04", "05", "06", "07", "08", "09",
                          "10", "11", "12", "13", "14", "15", "16", "17", "18", "19",
                          "20", "21", "22", "23", "24", "25"};
        int total = 0;
        outer:
        for(int i = 0; i < totalePF.length(); i++) {
            for(int j = 0; j < general.length; j++) {
                if(String.valueOf(totalePF.charAt(i)).equalsIgnoreCase(general[j])) {
                	total += i % 2 == 0 ? Integer.parseInt(odd[j]) : Integer.parseInt(even[j]); 
                    continue outer;
                }
            }
        }
        final int remainder = total % 26;
        final String alphabets [] = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J",
                               "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T",
                               "U", "V", "W", "X", "Y", "Z"};
        return alphabets[remainder];
    }

    static String getFilteredCogNome( final String cognome ) {
    	final String consonantsFromCognome = getConsonant(cognome);
    	if(consonantsFromCognome.length() == 0) {
    		return cognome.length() < 3 ? cognome + "X" : cognome.substring(0, 3);
    	} else if(consonantsFromCognome.length() >= 3) {
    		return consonantsFromCognome.substring(0,3);
    	} else {
        	final StringBuffer output = new StringBuffer(consonantsFromCognome);
        	output.append(getVowels(cognome));
    		return output.length() >= 3 ? output.toString().substring(0,3) : output.append("X").toString();
    	}
    }
    
    static String getFilteredNome(final String nome) {
    	final StringBuffer output = new StringBuffer();
    	final String consonantsFromNome = getConsonant(nome);
    	if(consonantsFromNome.length() == 0) {
    		return nome.length() < 3 ? nome + "X" : nome.substring(0, 3);
    	} else if(consonantsFromNome.length() >= 4) {
    		return output.append(consonantsFromNome.charAt(0)).append(consonantsFromNome.charAt(2)).append(consonantsFromNome.charAt(3)).toString();
    	} else {
    		output.append(consonantsFromNome).append(getVowels(nome));
    		return output.length() >= 3 ? output.toString().substring(0,3) : output.append("X").toString();
    	}
    }

    static String getConsonant(final String input) {
    	final StringBuffer output = new StringBuffer();
    	final int size = input.length();
    	final Collection consonant = Arrays.asList(consonants);
    	for(int i=0; i<size; i++) {
    		final String letter = String.valueOf(input.charAt(i));
    		if(consonant.contains(letter)) {
				output.append(String.valueOf(letter));
			}
    	}
    	return output.toString();
    }

    static String getVowels(final String input) {
    	final StringBuffer output = new StringBuffer();
    	final int size = input.length();
    	final Collection vowel = Arrays.asList(vowels);
    	for(int i=0; i<size; i++) {
    		final String letter = String.valueOf(input.charAt(i));
    		if(vowel.contains(letter)) {
				output.append(String.valueOf(letter));
			}
    	}
    	return output.toString();
    }
    
}
