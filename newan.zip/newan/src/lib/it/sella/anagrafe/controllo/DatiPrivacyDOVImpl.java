package it.sella.anagrafe.controllo;


import it.sella.anagrafe.implementation.IView;
import it.sella.anagrafe.pf.DatiPrivacyPFFiveLevelView;
import it.sella.anagrafe.pf.DatiPrivacyPFView;
import it.sella.anagrafe.util.AnagrafeHelper;

import java.util.List;

public class DatiPrivacyDOVImpl implements DatiObbligatoriValidator {

    public DatiPrivacyDOVImpl() {
    	
    }

    public void ControlloDatiObbligatori( final IView viewObject, final String motiv, final Long soggettoId , final Boolean isUSOrigin, final List allMotivColl, final boolean isThruXml,final Boolean isPartitaIvaNotMandatory ) throws ControlloObbligatoriPFException {
    	String livello1Value = null;
    	if ( viewObject instanceof DatiPrivacyPFView ) {
    		livello1Value = ((DatiPrivacyPFView) viewObject).getLivello1();
		} else if ( viewObject instanceof DatiPrivacyPFFiveLevelView ) {
			livello1Value = ((DatiPrivacyPFFiveLevelView) viewObject).getLivello1();
		} 
    	// Since the validation is same for all motivs no check for particular motiv
        // --1-- New Motiv added IMELB added by thiru 
        if (("CLINT".equals(motiv) || "DIPEN".equals(motiv) || "PROMT".equals(motiv) || 
        		"SVILP".equals(motiv) || "IMELB".equals(motiv)) && 
        		(!"true".equals(livello1Value))) {
                throw new ControlloObbligatoriPFException(new AnagrafeHelper().getMessage("ANAG-1206" ,isThruXml));
        }
    }
}