package it.sella.anagrafe;

/**
 * @author GBS03447
 *
 */
public class DAIRegoleException extends AnagrafeDAIException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DAIRegoleException() {
		// Explicit Empty Constructor
	}

	public DAIRegoleException(final String errMessage) {
		super(errMessage);
	}

	public DAIRegoleException(final String errMessage, final Throwable cause) {
		super(errMessage, cause);
	}

}
