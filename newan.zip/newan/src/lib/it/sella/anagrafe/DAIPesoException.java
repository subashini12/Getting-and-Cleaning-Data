package it.sella.anagrafe;

/**
 * @author gbs03447
 *
 */
public class DAIPesoException extends AnagrafeDAIException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DAIPesoException() {
		// Explicit Empty Constructor
	}

	public DAIPesoException(final String errMessage) {
		super(errMessage);
	}

	public DAIPesoException(final String errMessage, final Throwable cause) {
		super(errMessage, cause);
	}

}
