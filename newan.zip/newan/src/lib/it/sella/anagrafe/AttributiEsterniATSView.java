package it.sella.anagrafe;

public class AttributiEsterniATSView extends ASView {
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String sed ;
    private String dist ;
    private String stru ;

    public String getSed() {
        return sed;
    }

    public void setSed(final String sed) {
        this.sed = sed;
    }

    public String getDist() {
        return dist;
    }

    public void setDist(final String dist) {
        this.dist = dist;
    }

    public String getStru() {
        return stru;
    }

    public void setStru(final String stru) {
        this.stru = stru;
    }

}
