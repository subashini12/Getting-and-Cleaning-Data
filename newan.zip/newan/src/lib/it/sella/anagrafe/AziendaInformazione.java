package it.sella.anagrafe;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Hashtable;

/** This class used for retrieving information
 * about azienda */

public interface AziendaInformazione {

    Hashtable getCompatibleTipoSoggetto() throws InformazioneManagerException, RemoteException;

    Collection getCompatibleMotivi(Long tipoSoggettoId, Long tipoSocietaId) throws InformazioneManagerException, RemoteException;

}