package it.sella.anagrafe;

/**
 * @author GBS03447
 *
 */
public class DAIRegoleDetail implements IDAIRegoleDetail { // API Purpose

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long soggettoId;
	private String daiCode;
	private String daiCodeDesc;
	private String daiGroup;
	private String daiWeightage;

	public Long getSoggettoId() {
		return soggettoId;
	}

	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}

	public String getDaiCode() {
		return daiCode;
	}

	public void setDaiCode(final String daiCode) {
		this.daiCode = daiCode;
	}

	public String getDaiCodeDesc() {
		return daiCodeDesc;
	}

	public void setDaiCodeDesc(final String daiCodeDesc) {
		this.daiCodeDesc = daiCodeDesc;
	}

	public String getDaiGroup() {
		return daiGroup;
	}

	public void setDaiGroup(final String daiGroup) {
		this.daiGroup = daiGroup;
	}

	public String getDaiWeightage() {
		return daiWeightage;
	}

	public void setDaiWeightage(final String daiWeightage) {
		this.daiWeightage = daiWeightage;
	}
}
