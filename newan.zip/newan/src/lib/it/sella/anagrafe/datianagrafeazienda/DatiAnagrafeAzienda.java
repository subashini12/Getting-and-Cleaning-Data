package it.sella.anagrafe.datianagrafeazienda;

import java.io.Serializable;
import java.sql.Date;

public interface DatiAnagrafeAzienda  extends Serializable {
	
	Long getAziendaId();
	Long getSoggettoId();
	String getDenominazione();
	Date getDataDiCostituzione();
	String getNormalisedName();
	Long getOpId();
	String getNazioneCostituzione();
	String getCittaCostituzione();

	void setAziendaId(Long aziendaId);
	void setSoggettoId(Long soggettoId);
	void setDenominazione(String denominazione);
	void setDataDiCostituzione(Date dataDiCostituzione);
	void setNormalisedName(String normalisedName);
	void setOpId(Long opId);
	void setNazioneCostituzione(String nazioneCostituzione);
	void setCittaCostituzione(String nazioneCostituzione);
}