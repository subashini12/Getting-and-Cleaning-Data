package it.sella.anagrafe.datianagrafeazienda;

import it.sella.anagrafe.GestoreAnagrafeException;

import java.sql.Date;
import java.util.Collection;

import javax.ejb.FinderException;

public interface IDatiAnagrafeAziendaBeanManager {

	/**
	 * Method to create DatiAnagrafeAzienda
	 * @param datiAnagrafeAzienda
	 * @return
	 * @throws GestoreAnagrafeException
	 */
	DatiAnagrafeAzienda create(DatiAnagrafeAzienda datiAnagrafeAzienda) throws GestoreAnagrafeException;
	
	/**
	 * Method to update DatiAnagrafeAzienda
	 * @param datiAnagrafeAzienda
	 * @return
	 */
	DatiAnagrafeAzienda update(DatiAnagrafeAzienda datiAnagrafeAzienda);
	
	/**
	 * Method to find data using primary key
	 * @param primaryKey
	 * @return
	 * @throws FinderException
	 */
	DatiAnagrafeAzienda findByPrimaryKey(Long primaryKey) throws FinderException;
	
	/**
	 * Method to find data using SoggettoId
	 * @param soggettoId
	 * @return
	 * @throws FinderException
	 */
	DatiAnagrafeAzienda findBySoggettoId(Long soggettoId) throws FinderException;
	
	/**
	 * Method to find data using normalisedName and dataDiCostituzione
	 * @param normalisedName
	 * @param dataDiCostituzione
	 * @return
	 * @throws FinderException
	 */
	Collection<DatiAnagrafeAzienda> findByDatiAnagrafeAzienda(String normalisedName,Date dataDiCostituzione)throws FinderException;
	
	/**
	 * ethod to find data using description
	 * @param denominazione
	 * @return
	 * @throws FinderException
	 */
	Collection<DatiAnagrafeAzienda> findByNormalisedName(String denominazione)throws FinderException;
	
	/**
	 * Method to find data using dataDiCostituzione
	 * @param dataDiCostituzione 
	 * @return
	 * @throws FinderException
	 */
	Collection<DatiAnagrafeAzienda> findByDataDiCostituzione(Date dataDiCostituzione)throws FinderException;
}
