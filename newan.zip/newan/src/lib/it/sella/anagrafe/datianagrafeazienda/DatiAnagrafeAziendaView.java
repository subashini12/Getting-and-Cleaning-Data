package it.sella.anagrafe.datianagrafeazienda;

import java.sql.Date;

public class DatiAnagrafeAziendaView implements DatiAnagrafeAzienda /*extends EJBViewAdapter*/ {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Long getAziendaId() {
		return aziendaId;
	}

    public Long getSoggettoId() {
        return this.soggettoId;
    }

    public String getDenominazione() {
        return this.denominazione;
    }

    public Date getDataDiCostituzione() {
        return this.dataDiCostituzione;
    }

    public String getNormalisedName() {
        return this.normalisedName;
    }

	public Long getOpId() {
		return this.opId;
	}

    public void setSoggettoId(final Long soggettoId) {
        this.soggettoId = soggettoId;
    }

    public void setDenominazione(final String denominazione) {
        this.denominazione = denominazione;
    }

    public void setDataDiCostituzione(final Date dataDiCostituzione) {
        this.dataDiCostituzione = dataDiCostituzione;
    }

    public void setNormalisedName(final String normalisedName) {
        this.normalisedName = normalisedName;
    }

	public void setOpId(final Long opId) {
		this.opId = opId;
	}
	public void setAziendaId(final Long aziendaId) {
		this.aziendaId=aziendaId;

	}	

    public String getCittaCostituzione() {
		return cittaCostituzione;
	}

	public void setCittaCostituzione(final String cittaCostituzione) {
		this.cittaCostituzione = cittaCostituzione;
	}

	public String getNazioneCostituzione() {
		return nazioneCostituzione;
	}

	public void setNazioneCostituzione(final String nazioneCostituzione) {
		this.nazioneCostituzione = nazioneCostituzione;
	}

	/*protected String getParameterList() {
        return "LinkedSoggettoId  = " + this.getSoggettoId();
    }

    protected String getShortParameterList() {
        return getParameterList();
    }
*/
    private Long soggettoId;
    private String denominazione;
    private Date dataDiCostituzione;
    private String normalisedName;
    private Long opId;
    private Long aziendaId;
    private String cittaCostituzione;
    private String nazioneCostituzione;

}