package it.sella.anagrafe;

import java.sql.Timestamp;

public class CollegamentoView implements ICollegamentoView {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String getMotivoCollegamento() {
        return motivoCollegamento;
    }

    public void setMotivoCollegamento( final String motivoCollegamento ) {
        this.motivoCollegamento = motivoCollegamento;
    }

    public Long getLinkedSoggettoId() {
        return linkedSoggettoId;
    }

    public void setLinkedSoggettoId( final Long linkedSoggettoId ) {
        this.linkedSoggettoId = linkedSoggettoId;
    }

    public Long getSoggettoPrincipaleId() {
        return soggettoPrincipaleId;
    }

    public void setSoggettoPrincipaleId( final Long soggettoPrincipaleId ) {
        this.soggettoPrincipaleId = soggettoPrincipaleId;
    }

    public Long getCollegamentoId() {
        return collegamentoId;
    }

    public void setCollegamentoId( final Long collegamentoId ) {
        this.collegamentoId = collegamentoId;
    }

    public Timestamp getDataInizio() {
        return this.dataInizio;
    }

    public Timestamp getDataFine() {
        return this.dataFine;
    }

    public void setDataInizio( final java.sql.Timestamp dataInizio ) {
        this.dataInizio = dataInizio;
    }

    public void setDataFine( final java.sql.Timestamp dataFine ) {
        this.dataFine = dataFine;
    }

    public String getMotivoCausale() {
        return motivoCausale;
    }

    public void setMotivoCausale( final String motivoCausale ) {
        this.motivoCausale = motivoCausale;
    }

    public String getNote() {
        return note;
    }

    public void setNote( final String note ) {
        this.note = note;
    }

	public Long getOpId() {
		return opId;
	}

	public void setOpId( final Long opId ) {
		this.opId = opId;
	}

	private String motivoCollegamento;
    private String note;
    private String motivoCausale;
    private Long linkedSoggettoId;
    private Long soggettoPrincipaleId;
    private Long collegamentoId;
    private Timestamp dataInizio;
    private Timestamp dataFine;
    private Long opId;
}
