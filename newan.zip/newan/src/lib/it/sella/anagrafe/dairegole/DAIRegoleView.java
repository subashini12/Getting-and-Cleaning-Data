package it.sella.anagrafe.dairegole;

public class DAIRegoleView implements DAIRegole {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long daiRegoleId;
	private Long soggettoId;
	private Long pesoId;
	private Long daiCodeId;
	private Long daiWeightId;
	private Long opId;

	public Long getDaiRegoleId() {
		return daiRegoleId;
	}

	public void setDaiRegoleId(final Long daiRegoleId) {
		this.daiRegoleId = daiRegoleId;
	}

	public Long getSoggettoId() {
		return soggettoId;
	}

	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}

	public Long getPesoId() {
		return pesoId;
	}

	public void setPesoId(final Long pesoId) {
		this.pesoId = pesoId;
	}

	public Long getDaiCodeId() {
		return daiCodeId;
	}

	public void setDaiCodeId(final Long daiCodeId) {
		this.daiCodeId = daiCodeId;
	}

	public Long getDaiWeightId() {
		return daiWeightId;
	}

	public void setDaiWeightId(final Long daiWeightId) {
		this.daiWeightId = daiWeightId;
	}

	public Long getOpId() {
		return opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}

}
