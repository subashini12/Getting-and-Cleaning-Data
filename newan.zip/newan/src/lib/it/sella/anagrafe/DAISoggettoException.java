package it.sella.anagrafe;

/**
 * @author gbs03447
 *
 */
public class DAISoggettoException extends AnagrafeDAIException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DAISoggettoException() {
		// Explicit Empty Constructor
	}

	public DAISoggettoException(final String errMessage) {
		super(errMessage);
	}

	public DAISoggettoException(final String errMessage, final Throwable cause) {
		super(errMessage, cause);
	}

}
