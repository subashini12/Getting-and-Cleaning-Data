package it.sella.anagrafe.datifiscali;

import java.io.Serializable;

public interface DatiFiscali extends Serializable {
	
	Long getId();
	Long getSoggettoId();
	Long getRightPk();
	String getValue();
	Long getOpId();
	
	void setId(Long id);
	void setSoggettoId(Long soggettoId);
	void setRightPk(Long typeId);
	void setValue(String value);
	void setOpId(Long opId);
}
