package it.sella.anagrafe.datifiscali;


public class DatiFiscaliView implements DatiFiscali {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private Long soggettoId;
    private Long rightPk;
    private String value;
    private Long opId;
    
    public DatiFiscaliView() {
    }

    public DatiFiscaliView(final Long soggettoId, final String value, final Long rightPk, final Long opId) {
        this.setSoggettoId(soggettoId);
        this.setValue(value);
        this.setRightPk(rightPk);
        this.setOpId(opId);
    }

    //public getter methods
    public Long getSoggettoId() {
        return this.soggettoId;
    }

    public Long getRightPk() {
        return this.rightPk;
    }

    public String getValue() {
        return this.value;
    }

	public Long getOpId() {
		return this.opId;
	}

    //public setter methods
    public void setSoggettoId(final Long soggettoId) {
        this.soggettoId = soggettoId;
    }

    public void setRightPk(final Long rightPk) {
        this.rightPk = rightPk;
    }

    public void setValue(final String value) {
        this.value = value;
    }

	public void setOpId(final Long opId) {
		this.opId = opId;
	}

    //protected parameterlist methods
    protected String getParameterList() {
        return "Soggetto Id" + this.getSoggettoId();
    }

    protected String getShortParameterList() {
        return getParameterList();
    }

	public Long getId() {
		return id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

}

