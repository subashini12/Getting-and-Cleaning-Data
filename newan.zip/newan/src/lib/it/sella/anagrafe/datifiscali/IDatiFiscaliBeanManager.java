package it.sella.anagrafe.datifiscali;

import it.sella.anagrafe.GestoreAnagrafeException;

import java.util.Collection;

import javax.ejb.FinderException;

public interface IDatiFiscaliBeanManager {
	
	/**
	 * Method to create DatiFiscali
	 * @param datiFiscali
	 * @return
	 * @throws GestoreAnagrafeException
	 */
	DatiFiscali create(DatiFiscali datiFiscali) throws GestoreAnagrafeException;
	
	/**
	 * Method to update DatiFiscali
	 * @param datiFiscali
	 * @return
	 */
	DatiFiscali update(DatiFiscali datiFiscali);
	
	/**
	 * Method to find data using PrimaryKey
	 * @param primaryKey
	 * @return
	 * @throws FinderException
	 */
	DatiFiscali findByPrimaryKey(Long primaryKey) throws FinderException;
	
	/**
	 * Method to find data using SoggettoId
	 * @param soggId
	 * @return
	 * @throws FinderException
	 */
	Collection<DatiFiscali> findBySoggettoId(Long soggId) throws FinderException;
	
	/**
	 * Method to find data using SoggettoId and RightPK
	 * @param soggId
	 * @param rightPk
	 * @return
	 * @throws FinderException
	 */
	DatiFiscali findBySoggettoIdAndRightPk(Long soggId, Long rightPk) throws FinderException;
	
	/**
	 * Method to remove DatiFiscali
	 * @param datiFiscali
	 */
	void remove(DatiFiscali datiFiscali);
}
