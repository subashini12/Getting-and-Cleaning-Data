package it.sella.anagrafe.sm.censimentopf;

import it.sella.anagrafe.OperazioneAnagrafeFactory;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.bpaautomaticcens.PFRootXMLGenerator;
import it.sella.anagrafe.common.MotivoDiCensimento;
import it.sella.anagrafe.common.Nazione;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.dbaccess.DatiFiscaliUtil;
import it.sella.anagrafe.dbaccess.USorigin_Util;
import it.sella.anagrafe.factory.PersonaFisicaViewImpl;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.anagrafe.pf.DatiFiscaliPFView;
import it.sella.anagrafe.pf.IntermediariPFView;
import it.sella.anagrafe.sm.AnagrafeTransactionHelper;
import it.sella.anagrafe.sm.EventiHelper;
import it.sella.anagrafe.usasoggetto.FATCACalculator;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.IMELH2OHandler;
import it.sella.anagrafe.util.Log;
import it.sella.anagrafe.util.MotivHandler;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.anagrafe.util.SoggettiPromotoreException;
import it.sella.anagrafe.validator.DatiCodiceSoggettoPFValidator;
import it.sella.anagrafe.validator.SoggettoValidator;
import it.sella.anagrafe.validator.ValidatorHelper;
import it.sella.anagrafe.view.PersonaFisicaView;
import it.sella.anagrafe.view.SettorePLView;
import it.sella.anagrafe.view.SoggettiPromtoreView;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;

public class RiepilogoPersonaFisicaPFExecuter extends CensimentoPFExecuter {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(RiepilogoPersonaFisicaPFExecuter.class);

    public ExecuteResult execute( final RequestEvent requestevent ) {

    	Collection motivCollection = null;
        ExecuteResult executeResult = null;
        boolean callStampa = false;
        Hashtable output = null;
        Long soggetto_id = null;
        DatiFiscaliPFView datiFiscaliPFOldView =new DatiFiscaliPFView();
        final String updateDiretto = (String) requestevent.getAttribute("updateDiretto");
        final StateMachineSession session = requestevent.getStateMachineSession();
        final RPFExecuterHelper rpfHelper = new RPFExecuterHelper();
        final Hashtable stampaTable = new Hashtable(1);
        final Hashtable viewsTable = (Hashtable) session.get(CENSIMENTO_PF);
        final Boolean isModified = (Boolean) session.get(IS_MODIFIED_SESSION);
        final Boolean isNewMotiv = (Boolean) viewsTable.get("IS_NEW_MOTIV");
        final String newMotivoCausale = (String) viewsTable.get("NEW_MOTIV");
        final Long idForModifica = session.get("CENSIMENTOPF_FOR_COLLEGATE") != null ?
        		(Long) session.get(SOGGETTO_ID) : (Long) session.get("SOGGETTO_FOR_MODIFICATION");

        log4Debug.debug("###########################SOGGETTO_ID:",session.get(SOGGETTO_ID));
        log4Debug.debug("###########################CENSIMENTOPF_FOR_COLLEGATE:",session.get("CENSIMENTOPF_FOR_COLLEGATE"));
        log4Debug.debug("###########################SOGGETTO_FOR_MODIFICATION:",session.get("SOGGETTO_FOR_MODIFICATION"));
        log4Debug.debug("###########################idForModifica:",idForModifica);
        boolean isCartaLisBank = false;
        try {
            final PersonaFisicaView personaFisicaView = new PersonaFisicaViewImpl();
            // DOC_MASTER_VIEW for validation and ente emissione loading
            personaFisicaView.setCompDocumentMasterView((Map)session.get(COMP_DOC_MASTER_VIEW_MAP));
            rpfHelper.setIfEventConfermaSocket(requestevent, personaFisicaView);
        	rpfHelper.validateIfEventConfermaNoHost(requestevent, personaFisicaView);
	        motivCollection = (Collection) session.get("MOTIVI");
	        rpfHelper.setPersonaFisicaView(personaFisicaView,viewsTable,updateDiretto,idForModifica,session);
			new EventiHelper().validateEventiCollectionForRiepilogo(personaFisicaView.getEventiView(),viewsTable.get("SCONF_MODIFIED"),(Boolean) viewsTable.get("NOSCONF_EVENT_ALLOWED"));
	        final Collection strMotivi = rpfHelper.getMotivList(motivCollection);
	        if(strMotivi != null){
	        	strMotivi.remove("INTST");
	        }
	        personaFisicaView.setMotiv(strMotivi);
	        if ( session.get("SKIPBUSTA") != null ) {
	        	stampaTable.put("SKIPBUSTA",session.get("SKIPBUSTA"));
	        }
	        checkIsUSOrigin(personaFisicaView);
            final DatiFiscaliUtil datiFiscaliUtil = new DatiFiscaliUtil();
            final String clsAbiBanca = CommonPropertiesHandler.getValueFromProperty("CARTA_LISTA_BANK_ABI");
        	if(clsAbiBanca.equals(SecurityHandler.getCodiceAbiBanca())){
        		isCartaLisBank = true;
        	}
			if ( idForModifica == null ) {
                if ( personaFisicaView.getCodiceSoggettoPFView() != null &&
                		personaFisicaView.getCodiceSoggettoPFView().getCodiceHost() != null &&
                		!"".equals(personaFisicaView.getCodiceSoggettoPFView().getCodiceHost()) ) {
                	throw new ControlloDatiException(new AnagrafeHelper().getMessage("ANAG-1411"));
                }
                stampaTable.put("OPERATION","Censimento");
                if (personaFisicaView.getDatiFiscaliPFView() != null && !isCartaLisBank) {// isCartaLisBank check added : To avoid the Stampe & Busta & PDF For CLS Bank
                	if (personaFisicaView.getDatiFiscaliPFView().getW9()) {
                		stampaTable.put("W9_XML","TRUE");
                		stampaTable.put("CALLW8W9STAMPA", "TRUE");
                	}else if(personaFisicaView.getDatiFiscaliPFView().getW9NoReasonCertificate() != null) {
                		stampaTable.put("W9_XML","TRUE");
                		stampaTable.put("CALLW8W9STAMPA", "TRUE");
                		stampaTable.put("ANAG-W9NO_CERTI", personaFisicaView.getDatiFiscaliPFView().getW9NoReasonCertificate().getCausale());
                	}
                	if (personaFisicaView.getDatiFiscaliPFView().getW8()) {
                		stampaTable.put("W8_XML","TRUE");
                		stampaTable.put("CALLW8W9STAMPA", "TRUE");
                	}
                }
                setSkipBustaAndPDFForCartaLisBank(stampaTable, isCartaLisBank);// isCartaLisBank check added : To avoid the Stampe & Busta & PDF For CLS Bank
                log4Debug.debug("RiepilogoPersonaFisicaPFExecuter : execute : W9_XML :==>>>",stampaTable.get("W9_XML"));
                log4Debug.debug("RiepilogoPersonaFisicaPFExecuter : execute : W8_XML :==>>>",stampaTable.get("W8_XML"));

                datiFiscaliUtil.setRzValAndResidenzaFiscaliInANTICI(personaFisicaView, personaFisicaView.getMotiv());
                /*Validation Added for to mandate w9 flow with customer is identified as USA in collegate during censimento*/
                final Boolean isUSOrigin =  new USorigin_Util().isPF_USOrigin(personaFisicaView);
                FATCACalculator.calculateFATCA(personaFisicaView.getDatiFiscaliPFView(), "Semplice", isUSOrigin, false);
                /*ANTCI,POSTE check added to avoid W9 mandatory. POSTE (Post Office-POS Machine Owners)*/
                if(isUSOrigin && personaFisicaView.getMotiv()!=null && personaFisicaView.getDatiFiscaliPFView() != null && strMotivi != null && !strMotivi.contains("ANTCI") && !strMotivi.contains("POSTE")){
                	ValidatorHelper.validateCodiceFiscaleEstero(isUSOrigin,  personaFisicaView.getDatiFiscaliPFView(), false ,false, true);
                }
                datiFiscaliUtil.setRegimeDataScadenza(personaFisicaView.getDatiAnagraficiPFView().getDataDiNascita() , personaFisicaView.getDatiFiscaliPFView());
                buildCensimentoXMLForBPAIfPromotoreExist(personaFisicaView, null);
                //new DaiRegoleSoggettohelper().setDaiRegoleData(personaFisicaView);
                soggetto_id = OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager().performCensimentoAndBusta(personaFisicaView, stampaTable);
                session.put("SOGGETTO_ID", soggetto_id);// used for the other appliction to get the ID what is created

                // Calling SSRIMELOnLine - sottoponiAnagrafeCrif service Soggetto .. To get FAEStatus for the subject ... Only on Censimento
                if(strMotivi != null && strMotivi.contains("CLINT") && (personaFisicaView.getDatiFiscaliPFView() != null && personaFisicaView.getDatiFiscaliPFView().getCodiceFiscali() != null)){
                	log4Debug.debug("RiepilogoPersonaFisicaPFExecuter :: Execute :::  CLINTE MOTIV :::: ");
                	final String descrizioneStatoFae = new IMELH2OHandler().invokeSottoponiAnagrafeCrif(personaFisicaView.getDatiFiscaliPFView().getCodiceFiscali(), soggetto_id);
                	log4Debug.debug("RiepilogoPersonaFisicaPFExecuter :: Execute :::  descrizioneStatoFae :::: ",descrizioneStatoFae);
                }else { // This Logger call is to Identify why the FAE call Not Happend in Censimento PF.. (bcz of Motiv / codice Fiscale Null and so on ..)
                	final String codiceFiscale = personaFisicaView.getDatiFiscaliPFView() != null ? personaFisicaView.getDatiFiscaliPFView().getCodiceFiscali() : null;
                	final String logMotivAsString = new AnagrafeHelper().extractMotivAsString(strMotivi);
                	final String erroMsg = codiceFiscale != null ? logMotivAsString + " is Not Aligned." : "CodiceFiscali is Null.";
                	Log.logMessageWithErrorMsg(soggetto_id, "FAE_CALL" , getLogXMLDetailsForFAENoCall(codiceFiscale, logMotivAsString) ,"ANAG-FAECALL-CRIF", false ,erroMsg);
                }
			} else {
				try {
					new DatiCodiceSoggettoPFValidator().validateDetails(personaFisicaView.getCodiceSoggettoPFView(),motivCollection,personaFisicaView.getUpdateDiretto(),idForModifica ,false);
				} catch (final ControlloDatiException e) {
					executeResult = AnagrafeHelper.getExecuteResult("TrCodiceSoggetto");
					setInExecuteResultAfterNullCheck("codiceLibroMatricola",personaFisicaView.getCodiceSoggettoPFView().getCodlm(),executeResult);
					setInExecuteResultAfterNullCheck("codiceDipendente",personaFisicaView.getCodiceSoggettoPFView().getCoddp(),executeResult);
					setInExecuteResultAfterNullCheck("codicePromotore",personaFisicaView.getCodiceSoggettoPFView().getCodpr(),executeResult);
					setInExecuteResultAfterNullCheck("codiceSviluppatore",personaFisicaView.getCodiceSoggettoPFView().getCodsv(),executeResult);
					setInExecuteResultAfterNullCheck("CodiceFornitore",personaFisicaView.getCodiceSoggettoPFView().getCodfo(),executeResult);
					setInExecuteResultAfterNullCheck( SOGGETTO_ID, idForModifica, executeResult);
					return executeResult;
				}
				personaFisicaView.setId(idForModifica);
				personaFisicaView.setMotiv(motivCollection);
				personaFisicaView.setDatiAnagrafici(true);
				personaFisicaView.setIndirriziDati(true);
				personaFisicaView.setRecapitiDati(true);
				if ( "CLINT".equals(newMotivoCausale) || "DIPEN".equals(newMotivoCausale) ||
						"PROMT".equals(newMotivoCausale) || "SVILP".equals(newMotivoCausale) ) {
					personaFisicaView.setPrivacyDati(true);
				}
				personaFisicaView.setAttributiDati(true);
				personaFisicaView.setFiscaliDati(true);
				personaFisicaView.setDocumentiDati(true);
				personaFisicaView.setDatiCollegate(true);
				personaFisicaView.setIntermediariDati(true);
				personaFisicaView.setOrigineClienteDati(true);
				personaFisicaView.setEventiDati(true);
				personaFisicaView.setMemoDati(true);
				personaFisicaView.setSegnalatoreSet(true);
				personaFisicaView.setIfFromExecuter(true);
				personaFisicaView.setDatiPoteriFirma(true);
				personaFisicaView.setDatiCanalePreferito(true);
				final MotivHandler motivHandler=new MotivHandler();
				if(strMotivi.contains("ANTCI") && !motivHandler.isExistsuperiorMotivThanAntci(motivCollection))
				{
					Nazione resVal = viewsTable.get(RESI_FISICALI_PF_VIEW_FORANTCI_SESSION) != null ? ((Nazione)viewsTable.get(RESI_FISICALI_PF_VIEW_FORANTCI_SESSION)) : null;
					datiFiscaliPFOldView.setRzVal(resVal);
				}
				else
				{
					datiFiscaliPFOldView= viewsTable.get("OLD_PERSONA_FISICA_VIEWFORLOG") != null ? ((PersonaFisicaView)viewsTable.get("OLD_PERSONA_FISICA_VIEWFORLOG")).getDatiFiscaliPFView() : null;
				}
				log4Debug.debug("<====Old DF Object Before PFView Setting=======>",(datiFiscaliPFOldView != null && datiFiscaliPFOldView.getRzVal() != null) ? datiFiscaliPFOldView.getRzVal().getNome() : null);
				log4Debug.debug("###########################personaFisicaView|soggettoId:",personaFisicaView.getId());
				datiFiscaliUtil.setRzValAndResidenzaFiscaliInANTICI(personaFisicaView, getMotivObjtoString(personaFisicaView.getMotiv()));
				//Setting the Settore Value of PL associated with the PF soggetto
				SettorePLView settorePLView=rpfHelper.setSettoreForPFCollegate(idForModifica, personaFisicaView.getDatiFiscaliPFView(),datiFiscaliPFOldView, personaFisicaView.getAttributiEsterniPFView());
				personaFisicaView.setSettorePLView(settorePLView);
				final SoggettoValidator soggettoValidator = new SoggettoValidator();


					personaFisicaView.setPersonaFisicaView((PersonaFisicaView) viewsTable.get("OLD_PERSONA_FISICA_VIEWFORLOG"));
					output = soggettoValidator.validateSoggetto(personaFisicaView);
					if( output.size() > 0 ) {
						throw new ControlloDatiException();
					}
					if ( isModified.booleanValue() || isNewMotiv.booleanValue() ||
							"checked".equals(updateDiretto) || session.get("CODICE_SOGGETTO_CHECK") != null ||
							session.get("CLINT_MOTIV_ADDED_FOR_COLLEGATE") != null)  {
						personaFisicaView.setMotiv(strMotivi);
						stampaTable.put("OPERATION","Varia");
						checkNeedBusttaAndPdf( viewsTable, ICensimentoPFConstants.NO_BUSSTA_NO_PDF, stampaTable );
						setSkipBustaAndPDFForCartaLisBank(stampaTable, isCartaLisBank); // isCartaLisBank check added : To avoid the Stampe & Busta & PDF For CLS Bank
						buildCensimentoXMLForBPAIfPromotoreExist(personaFisicaView, idForModifica);
						datiFiscaliUtil.setRegimeDataScadenza(personaFisicaView.getDatiAnagraficiPFView().getDataDiNascita() , personaFisicaView.getDatiFiscaliPFView());
						//new DaiRegoleSoggettohelper().setDaiRegoleData(personaFisicaView);
						AnagrafeTransactionHelper.getInstance().performCensimentoModificaAndBustaInPF(personaFisicaView, stampaTable);
						//OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager().performCensimentoModificaAndBusta(personaFisicaView, stampaTable);
						//Right now not going to set profile while adding collegate.
						//                    sendMailIfColProfileBExists(personaFisicaView);
					}
					if ( session.get("CENSIMENTOPF_FOR_COLLEGATE") == null ) {
						removeFromSession(session, "SOGGETTO_FOR_MODIFICATION");
					}
					session.put("SOGGETTO_ID", idForModifica);
			}
            removeFromSession( session, "SKIPBUSTA");
            callStampa = stampaTable != null
					&& ((stampaTable.get("SKIPCALLSTAMPA") == null && "TRUE".equals(stampaTable.get("CALLSTAMPAPRIVACYONLUS")))
							|| "TRUE".equals(stampaTable.get("CALLW8W9STAMPA"))) ? true : false;
         
            if( callStampa && stampaTable != null ) {
            	setDetailsForStampa( (Hashtable) stampaTable.get("PDFTABLE") , session );
            }
        	executeResult = AnagrafeHelper.getExecuteResult( callStampa ? "TrStampa" : "TrConferma" );
            //clearSession(requestevent);
        } catch (final RemoteException e) {
        	final String cause = (e.getCause() != null && e.getCause().getMessage() != null) ? e.getCause().getMessage() : "";
        	String remoteErrMsg = "errore tecnico sconosciuto contattare l'assistenza !!";
			if(cause.contains("ORA-00001: unique constraint (WEBLOGIC_DBA.AN_TR_CODICE_FIS_CHECK_UQ)") || e.getMessage().contains("CODICE FISCALE EXISTS ALREADY")) {
				remoteErrMsg = new AnagrafeHelper().getMessage("ANAG-1780"); // codice fiscale � gi� esistente
			}
        	log4Debug.severeStackTrace(e);
            executeResult = getNonConfermaExecuteResult(remoteErrMsg,session,output);
        } catch ( final OperazioneAnagrafeManagerException e ) {
        	log4Debug.warnStackTrace(e);
        	if( stampaTable != null && stampaTable.get("MAPPER_ERROR") != null ) {
        		executeResult = getNonConfermaExecuteResult(e.getMessage(),session,output);
        	}
        	//Added e.getCause() to avoid throwing throw SoggettiPromotoreException as Busta Exception
        	else if (e.getCause() instanceof SoggettiPromotoreException)  {
        		executeResult = getNonConfermaExecuteResult(new AnagrafeHelper().getMessage("ANAG-1692"),session,output);
        	} else {
	        	session.put("SKIPBUSTA","TRUE");
	        	executeResult = getNonConfermaExecuteResult(new AnagrafeHelper().getMessage("ANAG-1499"),session,output);
        	} 
        } catch (final Exception e) {
        	log4Debug.severeStackTrace(e);
            executeResult = getNonConfermaExecuteResult(e.getMessage(),session,output);
        }
        setInExecuteResultAfterNullCheck("Modifica",requestevent.getAttribute("Modifica"),executeResult);
        if ( session.get("CENSIMENTOPF_ISFORPL") != null ) {
        	executeResult.setAttribute("CENSIMENTOPF_ISFORPL", "TRUE");
        }
        removeFromSession( session, "RICERCA_FOR_PFCOLLEGATE_DETAILS");
        return executeResult;
    }

    private ExecuteResult getNonConfermaExecuteResult( final String strErrorMsg, final StateMachineSession session, final Hashtable output) {
    	final ExecuteResult executeResult = AnagrafeHelper.getExecuteResult("TrNonConferma");
        getViewsFromSession(session, executeResult);
        new RPFExecuterHelper().setErrorMessages(output,executeResult,strErrorMsg);
        return executeResult;
    }

    private void removeFromSession( final StateMachineSession session, final String key) {
    	if( session != null && key != null ) {
    		session.remove(key);
    	}
    }

    private static void checkNeedBusttaAndPdf( final Hashtable pfHashtable, final String key, final Hashtable stampaTable ) {
    	if( pfHashtable != null && key != null && stampaTable != null &&
    		"TRUE".equals(pfHashtable.get(key)))  {
    		log4Debug.warn(" RiepilogoPersonaFisicaPFExecuter : NO_BUSSTA_NO_PDF ====>>");
    		stampaTable.put(ICensimentoPFConstants.NO_BUSSTA_NO_PDF, "TRUE");
    	}
    }

    private Collection getMotivObjtoString( final Collection motivCollection ) {
    	final Collection strMotivi = new ArrayList();
    	final Iterator mdcIterator = motivCollection.iterator();
    	final int mdcSize = motivCollection.size();
        for( int i = 0; i < mdcSize; i++ ) {
        	strMotivi.add(((MotivoDiCensimento) mdcIterator.next()).getMotivoCausale());
        }
        return strMotivi;
    }

//    private void sendMailIfColProfileBExists(final PersonaFisicaView personaFisicaView){
//    	final Long soggettoId   = personaFisicaView.getId();
//    	final String codiceHost = personaFisicaView.getCodiceSoggettoPFView() != null && personaFisicaView.getCodiceSoggettoPFView().getCodiceHost() != null ? personaFisicaView.getCodiceSoggettoPFView().getCodiceHost() : "";
//    	final DatiAnagraficiPFView datiAnagraficiPFView = personaFisicaView.getDatiAnagraficiPFView();
//    	final String intestatazione = datiAnagraficiPFView.getNome() + " " + datiAnagraficiPFView.getCognome();
//    	new QuestionarioMailHandler().sendMailIfColProfileBExists(soggettoId, codiceHost, intestatazione, personaFisicaView.getCollegateViews());
//    }

    private void buildCensimentoXMLForBPAIfPromotoreExist(final PersonaFisicaView personaFisicaView , final Long soggettoId ) throws SubSystemHandlerException, SoggettiPromotoreException,RemoteException {
    	final String xmlPrepationAllowed = CommonPropertiesHandler.getValueFromProperty("PREPARE_XML_FOR_BPA_CENS_"+SecurityHandler.getLoginBancaId());
    	log4Debug.debug("RiepilogoPersonaFisicaPFExecuter : buildCensimentoXMLForBPAIfPromotoreExist : xmlPrepationAllowed :==>>>",xmlPrepationAllowed);
    	if("Y".equals(xmlPrepationAllowed)){
	    	final Collection<Long> promotoreIds = personaFisicaView.getPromotoreIds();
	    	boolean isViewNeedToBuild = false;
	    	if(promotoreIds != null && !promotoreIds.isEmpty()){
	    		if(soggettoId == null){
	    			isViewNeedToBuild = true;
	    		}else{
	    			final Collection<Long> promotoreOldIds = getPromotoreIdList(personaFisicaView);
	    			if(promotoreOldIds != null && !promotoreOldIds.isEmpty()){
	    				for (final Long promotoreId : promotoreIds) {
							if(!promotoreOldIds.contains(promotoreId)){
								isViewNeedToBuild = true;
								break;
							}
						}
	    			}else{
	    				isViewNeedToBuild = true;
	    			}

	    		}
	    	}
	    	log4Debug.debug("RiepilogoPersonaFisicaPFExecuter : buildCensimentoXMLForBPAIfPromotoreExist : isViewNeedToBuild :==>>>",isViewNeedToBuild);
	    	if(isViewNeedToBuild){
	    		final SoggettiPromtoreView soggettiPromtoreView = new SoggettiPromtoreView();
	    		soggettiPromtoreView.setSoggettoId(soggettoId);
	    		soggettiPromtoreView.setTipoSoggetto("PF");
	    		soggettiPromtoreView.setDataRiff(new Date(new DateHandler().getCurrentDateInTimeStampFormat().getTime()));
	    		final String censimentoRootXML = new PFRootXMLGenerator().getXMLForBPAAutomaticCens(personaFisicaView, soggettoId);
	    		log4Debug.debug("RiepilogoPersonaFisicaPFExecuter : buildCensimentoXMLForBPAIfPromotoreExist : censimentoRootXML :==>>>",censimentoRootXML);
	    		soggettiPromtoreView.setCensimentoXML(new StringBuffer(censimentoRootXML));
	    		personaFisicaView.setSoggettiPromtoreView(soggettiPromtoreView);
	    	}
    	}
    }

    private Collection<Long> getPromotoreIdList( final PersonaFisicaView personaFisicaView)  {
    	final Collection ricercaIntermediariPFColl = personaFisicaView.getPersonaFisicaView() != null ? personaFisicaView.getPersonaFisicaView().getIntermediariViews() : null;
    	log4Debug.debug("RiepilogoPersonaFisicaPFExecuter : getPromotoreIdList : ricercaIntermediariPFColl :==>>>",ricercaIntermediariPFColl);
    	final Collection<Long> promotoreIdColl = new ArrayList<Long>();
		if ( ricercaIntermediariPFColl != null ) {
            final Iterator iterator = ricercaIntermediariPFColl.iterator();
            final int size = ricercaIntermediariPFColl.size();
            IntermediariPFView ricerca = null;
            for (int i = 0; i < size; i++) {
                ricerca = (IntermediariPFView) iterator.next();
                if (ricerca.getTypeOfIntermediari().equalsIgnoreCase("PROCT")) {
                	promotoreIdColl.add(ricerca.getId());
                }
            }
        }
		return promotoreIdColl;
    }
    
    private void checkIsUSOrigin(final PersonaFisicaView personaFisicaView){
    	final Boolean isUSOrigin =  new USorigin_Util().isPF_USOrigin(personaFisicaView);
    	log4Debug.debug("checkIsUSOrigin  ========================   ",isUSOrigin);
    	final DatiFiscaliPFView datiFiscaliPFView = personaFisicaView.getDatiFiscaliPFView();
    	if(!isUSOrigin.booleanValue()){
    		if(datiFiscaliPFView != null) {
    			log4Debug.debug("W9 value not null  ========================   ");
    			if(datiFiscaliPFView.getW9()){
    				datiFiscaliPFView.setW9(Boolean.FALSE);
    				log4Debug.debug("Setting W9 value As False  ========================   ");
    			}else if(datiFiscaliPFView.getW9NoReasonCertificate() != null){
    				datiFiscaliPFView.setW9NoReasonCertificate(null);
    				log4Debug.debug("Setting W9 Certificate value As False  ========================   ");
    			}
    		}
    	}
    }
    
    private String getLogXMLDetailsForFAENoCall(final String codiceFiscale, final String motiv) throws SubSystemHandlerException{
    	final Map<String, String> loggerDetails = new HashMap<String, String>();
    	AnagrafeHelper.isNotNullPutInMap(loggerDetails,"CODICE_FISCALE", codiceFiscale);
		AnagrafeHelper.isNotNullPutInMap(loggerDetails,"CODICE_ABI", SecurityHandler.getCodiceAbiBanca());
		AnagrafeHelper.isNotNullPutInMap(loggerDetails,"MOTIV", motiv);
		AnagrafeHelper.isNotNullPutInMap(loggerDetails,"TIPO_SOGGETTO", "Semplice");                	
    	return new IMELH2OHandler().xmlForFAECallLog(loggerDetails, false);
    }
}
