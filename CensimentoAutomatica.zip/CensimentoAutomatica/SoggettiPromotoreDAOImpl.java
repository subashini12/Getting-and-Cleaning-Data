package it.sella.anagrafe.dao.impl;

import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.dao.ISoggettiPromotoreDAO;
import it.sella.anagrafe.util.AnagrafeLoggerHelper;
import it.sella.anagrafe.util.ConnectionHandler;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.anagrafe.util.SoggettiPromotoreException;
import it.sella.anagrafe.view.SoggettiPromtoreView;
import it.sella.logserver.LoggerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.IOException;
import java.io.Reader;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;

import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleResultSet;
import oracle.xdb.XMLType;


public class SoggettiPromotoreDAOImpl extends ConnectionHandler implements ISoggettiPromotoreDAO {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(SoggettiPromotoreDAOImpl.class);

	public void insertSoggettiPromotore(final SoggettiPromtoreView soggettoPromotoreView,final String operationCode) throws SoggettiPromotoreException {
		Connection connection = null;
		OraclePreparedStatement preparedStatement = null;
		Long opId = null;
		try {
			connection = getConnection();
			if (soggettoPromotoreView.getOpId()!= null) {
				opId = soggettoPromotoreView.getOpId();
			} else {
				opId = getOpId(soggettoPromotoreView.getSoggettoId(),operationCode);
			}
			preparedStatement = (OraclePreparedStatement) connection.prepareStatement("INSERT INTO AN_TR_SOGGETTI_FOL_PROCT (SP_ID,SP_BANK_ID,SP_SOGGETTO_ID,SP_TIPO_SOGGETTO,SP_XML,SP_STATO,SP_ERRORE,SP_DATA_RIF,SP_OP_ID) VALUES (AN_SQ_SOGG_FOL_PROCT.NEXTVAL,?,?,?,?,?,?,?,?)");
			preparedStatement.setLong(1, SecurityHandler.getLoginBancaId());
			preparedStatement.setLong(2, soggettoPromotoreView.getSoggettoId());
			preparedStatement.setString(3, soggettoPromotoreView.getTipoSoggetto());
			final XMLType censimentoXML = XMLType.createXML(connection,soggettoPromotoreView.getCensimentoXML().toString());
			preparedStatement.setObject(4, censimentoXML);
			preparedStatement.setString(5, soggettoPromotoreView.getStato());
			if (soggettoPromotoreView.getErrorMsg()!= null) {
				preparedStatement.setString(6, soggettoPromotoreView.getErrorMsg().toString());
			} else {
				preparedStatement.setNull(6, java.sql.Types.VARCHAR);
			}
			if(soggettoPromotoreView.getDataRiff() != null){
				preparedStatement.setTimestamp(7,new Timestamp(soggettoPromotoreView.getDataRiff().getTime()));
			}else{
				preparedStatement.setNull(7, java.sql.Types.DATE);
			}
			preparedStatement.setLong(8,opId);
			preparedStatement.executeUpdate();
		} catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new SoggettiPromotoreException(sqlexception.getMessage());
		} catch (final SubSystemHandlerException subSystemException) {
			log4Debug.debug("<<GA>> Exception while getting details ",subSystemException.getMessage());
			throw new SoggettiPromotoreException(subSystemException.getMessage());
		} catch (final RemoteException remoteException) {
			log4Debug.debug("<<GA>> Exception while getting details ",remoteException.getMessage());
			throw new SoggettiPromotoreException(remoteException.getMessage());
		} catch (final LoggerException loggerException) {
			log4Debug.debug("<<GA>> Exception while getting details ",loggerException.getMessage());
			throw new SoggettiPromotoreException(loggerException.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}

	}
	private Long getOpId(final Long soggettoId,final String operationCode) throws LoggerException, RemoteException {
		final AnagrafeLoggerHelper anagrafeLoggerHelper = new AnagrafeLoggerHelper();
		return anagrafeLoggerHelper.logAnagrafeOperation(null,false,operationCode,soggettoId,null);
	}
	public void updateSoggettiPromotore(final SoggettiPromtoreView soggettoPromotoreView,final String operationCode) throws SoggettiPromotoreException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		Long opId = null;
		try {
			connection = getConnection();
			if (soggettoPromotoreView.getOpId()!= null) {
				opId = soggettoPromotoreView.getOpId();
			} else {
				opId = getOpId(soggettoPromotoreView.getSoggettoId(),operationCode);
			}
			preparedStatement = connection.prepareStatement("UPDATE AN_TR_SOGGETTI_FOL_PROCT SET SP_XML=?,SP_STATO=?,SP_ERRORE=?,SP_DATA_RIF=?,SP_OP_ID=? WHERE SP_ID=?");
			final XMLType censimentoXML = XMLType.createXML(connection,soggettoPromotoreView.getCensimentoXML().toString());
			preparedStatement.setObject(1, censimentoXML);
			preparedStatement.setString(2, soggettoPromotoreView.getStato());
			if (soggettoPromotoreView.getErrorMsg()!= null) {
				preparedStatement.setString(3, soggettoPromotoreView.getErrorMsg().toString());
			} else {
				preparedStatement.setNull(3, java.sql.Types.VARCHAR);
			}
			if(soggettoPromotoreView.getDataRiff() != null){
				preparedStatement.setTimestamp(4,new Timestamp(soggettoPromotoreView.getDataRiff().getTime()));
			}else{
				preparedStatement.setNull(4, java.sql.Types.DATE);
			}
			preparedStatement.setLong(5,opId);
			preparedStatement.setLong(6,soggettoPromotoreView.getId());
			preparedStatement.executeUpdate();
		}  catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new SoggettiPromotoreException(sqlexception.getMessage());
		}  catch (final RemoteException remoteException) {
			log4Debug.debug("<<GA>> Exception while getting details ",remoteException.getMessage());
			throw new SoggettiPromotoreException(remoteException.getMessage());
		} catch (final LoggerException loggerException) {
			log4Debug.debug("<<GA>> Exception while getting details ",loggerException.getMessage());
			throw new SoggettiPromotoreException(loggerException.getMessage());
		} finally {
			cleanup(connection, preparedStatement);
		}
	}

	public void deleteSoggettiPromotore(final Long id) throws SoggettiPromotoreException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement("DELETE FROM AN_TR_SOGGETTI_FOL_PROCT WHERE SP_ID=?");
			preparedStatement.setLong(1, id);
			preparedStatement.executeUpdate();
		}  catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new SoggettiPromotoreException(sqlexception.getMessage());
		}  finally {
			cleanup(connection, preparedStatement);
		}
	}
	public Collection<SoggettiPromtoreView> getSoggettiPromotore4SoggettoId(final Long soggettoId) throws SoggettiPromotoreException {
		Connection connection = null;
		OraclePreparedStatement preparedStatement = null;
		Collection<SoggettiPromtoreView> soggettiPromtore = null;
		ResultSet resultSet = null;
		try {
			connection = getConnection();
			preparedStatement = (OraclePreparedStatement) connection.prepareStatement("SELECT SP_ID,SP_BANK_ID,SP_TIPO_SOGGETTO, XMLSerialize(DOCUMENT SP_XML AS CLOB) as XML_DATA,SP_STATO,SP_ERRORE,SP_DATA_RIF FROM AN_TR_SOGGETTI_FOL_PROCT WHERE SP_SOGGETTO_ID = ?");
			preparedStatement.setLong(1, soggettoId);
			resultSet = preparedStatement.executeQuery();
			final weblogic.jdbc.wrapper.ResultSet wlsResultSet = (weblogic.jdbc.wrapper.ResultSet)resultSet;
			final OracleResultSet oracleResultSet = (OracleResultSet)wlsResultSet.getVendorObj();
			soggettiPromtore = new ArrayList<SoggettiPromtoreView>();
			while (oracleResultSet.next()) {
				final SoggettiPromtoreView soggettiPromtoreView = new SoggettiPromtoreView();
				soggettiPromtoreView.setId(resultSet.getLong("SP_ID"));
				soggettiPromtoreView.setBankId(resultSet.getLong("SP_BANK_ID"));
				soggettiPromtoreView.setSoggettoId(soggettoId);
				soggettiPromtoreView.setTipoSoggetto(resultSet.getString("SP_TIPO_SOGGETTO"));
				soggettiPromtoreView.setCensimentoXML(getStringFromClob(oracleResultSet.getCLOB("XML_DATA")));
				soggettiPromtoreView.setStato(resultSet.getString("SP_STATO"));
				if (resultSet.getString("SP_ERRORE")!= null ) {
					soggettiPromtoreView.setErrorMsg(new StringBuffer(resultSet.getString("SP_ERRORE")));
				}
				soggettiPromtoreView.setDataRiff(resultSet.getDate("SP_DATA_RIF"));
				soggettiPromtore.add(soggettiPromtoreView);
			}
		}  catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new SoggettiPromotoreException(sqlexception.getMessage());
		}  finally {
			cleanup(connection, preparedStatement, resultSet);
		}
		return soggettiPromtore;

	}
	public SoggettiPromtoreView getSoggettiPromotore(final Long id) throws SoggettiPromotoreException {
		Connection connection = null;
		OraclePreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		SoggettiPromtoreView soggettiPromtoreView = null;
		try {
			connection = getConnection();
			preparedStatement = (OraclePreparedStatement) connection.prepareStatement("SELECT SP_SOGGETTO_ID,SP_BANK_ID,SP_TIPO_SOGGETTO, XMLSerialize(DOCUMENT SP_XML AS CLOB) as XML_DATA ,SP_STATO,SP_ERRORE,SP_DATA_RIF,SP_OP_ID FROM AN_TR_SOGGETTI_FOL_PROCT WHERE SP_ID = ?");
			preparedStatement.setLong(1, id);
			resultSet = preparedStatement.executeQuery();
			final weblogic.jdbc.wrapper.ResultSet wlsResultSet = (weblogic.jdbc.wrapper.ResultSet)resultSet;
			final OracleResultSet oracleResultSet = (OracleResultSet)wlsResultSet.getVendorObj();
			while (resultSet.next()) {
				soggettiPromtoreView = new SoggettiPromtoreView();
				soggettiPromtoreView.setId(id);
				soggettiPromtoreView.setSoggettoId(resultSet.getLong("SP_SOGGETTO_ID"));
				soggettiPromtoreView.setBankId(resultSet.getLong("SP_BANK_ID"));
				soggettiPromtoreView.setTipoSoggetto(resultSet.getString("SP_TIPO_SOGGETTO"));
				soggettiPromtoreView.setCensimentoXML(getStringFromClob(oracleResultSet.getCLOB("XML_DATA")));
				soggettiPromtoreView.setStato(resultSet.getString("SP_STATO"));
				if (resultSet.getString("SP_ERRORE")!= null ) {
					soggettiPromtoreView.setErrorMsg(new StringBuffer().append(resultSet.getString("SP_ERRORE")));
				}
				soggettiPromtoreView.setDataRiff(resultSet.getDate("SP_DATA_RIF"));
				soggettiPromtoreView.setOpId(resultSet.getLong("SP_OP_ID"));
			}
		}  catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new SoggettiPromotoreException(sqlexception.getMessage());
		}  finally {
			cleanup(connection, preparedStatement, resultSet);
		}
		return soggettiPromtoreView;
	}


	public void insertSoggettiPromotoreStorico(final SoggettiPromtoreView soggettoPromotoreView,final String operationCode) throws SoggettiPromotoreException {
		Connection connection = null;
		OraclePreparedStatement preparedStatement = null;
		Long opId = null;
		try {
			connection = getConnection();
			opId = getOpId(soggettoPromotoreView.getSoggettoId(),operationCode);
			preparedStatement = (OraclePreparedStatement) connection.prepareStatement(" INSERT INTO ANSE_TR_SOGGETTI_FOL_PROCT (SP_ID,SP_BANK_ID,SP_SOGGETTO_ID,SP_TIPO_SOGGETTO,SP_XML,SP_STATO,SP_ERRORE,SP_DATA_RIF,SP_OP_ID,SP_OLD_OP_ID,SP_OP_DATE) VALUES (?,?,?,?,?,?,?,?,?,?,TRUNC(SYSDATE))");
			preparedStatement.setLong(1, soggettoPromotoreView.getId());
			preparedStatement.setLong(2, SecurityHandler.getLoginBancaId());
			preparedStatement.setLong(3, soggettoPromotoreView.getSoggettoId());
			preparedStatement.setString(4, soggettoPromotoreView.getTipoSoggetto());
			final XMLType censimentoXML = XMLType.createXML(connection,soggettoPromotoreView.getCensimentoXML().toString());
			preparedStatement.setObject(5, censimentoXML);
			preparedStatement.setString(6, soggettoPromotoreView.getStato());
			if (soggettoPromotoreView.getErrorMsg()!= null) {
				preparedStatement.setString(7, soggettoPromotoreView.getErrorMsg().toString());
			} else {
				preparedStatement.setNull(7, java.sql.Types.VARCHAR);
			}
			if(soggettoPromotoreView.getDataRiff() != null){
				preparedStatement.setTimestamp(8,new Timestamp(soggettoPromotoreView.getDataRiff().getTime()));
			}else{
				preparedStatement.setNull(8, java.sql.Types.DATE);
			}
			preparedStatement.setLong(9,opId);
			preparedStatement.setLong(10,soggettoPromotoreView.getOpId());
			preparedStatement.executeUpdate();
		} catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new SoggettiPromotoreException(sqlexception.getMessage());
		} catch (final SubSystemHandlerException subSystemException) {
			log4Debug.debug("<<GA>> Exception while getting details ",subSystemException.getMessage());
			throw new SoggettiPromotoreException(subSystemException.getMessage());
		} catch (final RemoteException remoteException) {
			log4Debug.debug("<<GA>> Exception while getting details ",remoteException.getMessage());
			throw new SoggettiPromotoreException(remoteException.getMessage());
		} catch (final LoggerException loggerException) {
			log4Debug.debug("<<GA>> Exception while getting details ",loggerException.getMessage());
			throw new SoggettiPromotoreException(loggerException.getMessage());
		}  finally {
			cleanup(connection, preparedStatement);
		}

	}

	private StringBuffer getStringFromClob(final oracle.sql.CLOB clob) throws SoggettiPromotoreException {
		final StringBuffer data = new StringBuffer();
		try {
			if (clob != null) {
				final Reader reader = clob.getCharacterStream();
				int ch;
				while ((ch = reader.read()) != -1) {
					{
						data.append((char) ch);
					}
				}
			}
		} catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new SoggettiPromotoreException(sqlexception.getMessage());
		} catch(final IOException ioException) {
			log4Debug.debug("<<GA>> Exception while getting clob data ",ioException.getMessage());
			throw new SoggettiPromotoreException(ioException.getMessage());
		}
		return data;
	}
	/**
	 * Method to get the Soggettoid of bs bank for the SoggettiPromotore id
	 */
	public Long getSoggettoId(final Long id) throws SoggettiPromotoreException {
		Connection connection = null;
		OraclePreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Long soggettoId = null;
		try {
			connection = getConnection();
			preparedStatement = (OraclePreparedStatement) connection.prepareStatement("SELECT SP_SOGGETTO_ID FROM AN_TR_SOGGETTI_FOL_PROCT WHERE SP_ID = ?");
			preparedStatement.setLong(1, id);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				soggettoId = resultSet.getLong("SP_SOGGETTO_ID");
			}
		}  catch (final SQLException sqlexception) {
			log4Debug.debug("<<GA>> Exception while getting details ",sqlexception.getMessage());
			throw new SoggettiPromotoreException(sqlexception.getMessage());
		}  finally {
			cleanup(connection, preparedStatement, resultSet);
		}
		return soggettoId;
	}
}
