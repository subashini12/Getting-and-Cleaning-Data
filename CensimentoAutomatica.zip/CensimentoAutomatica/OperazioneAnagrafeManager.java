package it.sella.anagrafe;

import it.sella.anagrafe.az.AttributiTramiteAZView;
import it.sella.anagrafe.az.DatiAnagraficiAZView;
import it.sella.anagrafe.collegamento.Collegamento;
import it.sella.anagrafe.collegamento.CollegamentoView;
import it.sella.anagrafe.common.CAP;
import it.sella.anagrafe.common.Citta;
import it.sella.anagrafe.common.Ramo;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.discriminator.AttributiEsterniDiscriminatorException;
import it.sella.anagrafe.discriminator.CodiceSoggettoDiscriminatorException;
import it.sella.anagrafe.discriminator.CollegamentoException;
import it.sella.anagrafe.discriminator.DatiAnagraficiDiscriminatorException;
import it.sella.anagrafe.discriminator.DatiFiscaliDiscriminatorException;
import it.sella.anagrafe.discriminator.DatiPrivacyDiscriminatorException;
import it.sella.anagrafe.discriminator.DocumentoDiscriminatorException;
import it.sella.anagrafe.discriminator.EventoDiscriminatorException;
import it.sella.anagrafe.discriminator.RecapitiDiscriminatorException;
import it.sella.anagrafe.hostlog.LogHostCallView;
import it.sella.anagrafe.hostlog.LogOperationDataView;
import it.sella.anagrafe.hostlog.SocketRBLogOperationDataView;
import it.sella.anagrafe.implementation.IView;
import it.sella.anagrafe.implementation.NazioneView;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.anagrafe.implementation.operazioneanagrafe.OperazioneAnagrafeSession;
import it.sella.anagrafe.implementation.operazioneanagrafe.OperazioneAnagrafeSessionHome;
import it.sella.anagrafe.logView.LogView;
import it.sella.anagrafe.pf.DatiAnagraficiPFView;
import it.sella.anagrafe.pf.DocumentoPFView;
import it.sella.anagrafe.pf.SoggettoEventoView;
import it.sella.anagrafe.pf.SoggettoRecapitiView;
import it.sella.anagrafe.poste.exception.PosteException;
import it.sella.anagrafe.tiposoggetto.TipoSoggetto;
import it.sella.anagrafe.tiposoggetto.TipoSoggettoView;
import it.sella.anagrafe.util.CanalePreferitoException;
import it.sella.anagrafe.util.SoggettiPromotoreException;
import it.sella.anagrafe.view.ClienteClassificazioneView;
import it.sella.anagrafe.view.CompDocumentView;
import it.sella.anagrafe.view.DipctAlignDetailsView;
import it.sella.anagrafe.view.DocEventiView;
import it.sella.anagrafe.view.FatturatoView;
import it.sella.anagrafe.view.PosteCustomerView;
import it.sella.anagrafe.view.SoggettoView;
import it.sella.anagrafe.view.TransferContoView;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.rmi.PortableRemoteObject;

public class OperazioneAnagrafeManager implements Serializable {

    /**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private OperazioneAnagrafeSession operazione_anagrafe_session = null;

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(OperazioneAnagrafeManager.class);

    public OperazioneAnagrafeManager() {
        getOperazioneAnagrafeSession();
    }
    public void setDocumenti(final Long soggettoId,Collection documentiCollection,ClassificazioneView modalita) throws RemoteException,GestoreAnagrafeException
    {
    	getOperazioneAnagrafeSession().setDocumenti(soggettoId, documentiCollection,modalita);
    }
    /* TipoAttributiEsterniSession*/
    public void createAttributiEsterniPF(final Long soggettoId, final IView datiAnagraficiView) throws AttributiEsterniDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().createAttributiEsterniPF(soggettoId, datiAnagraficiView);
    }

    public IView getAttributiEsterniPF(final Long soggettoId) throws AttributiEsterniDiscriminatorException, ClassNotFoundException, RemoteException {
        return getOperazioneAnagrafeSession().getAttributiEsterniPF(soggettoId);
    }

    public void setAttributiEsterniPF(final Long soggettoId, final IView datiAnagraficiView) throws AttributiEsterniDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().setAttributiEsterniPF(soggettoId, datiAnagraficiView);
    }

    public Collection findByStato(final Collection datiAnagraficiView, final String stato) throws AttributiEsterniDiscriminatorException, RemoteException {
        return getOperazioneAnagrafeSession().findByStato(datiAnagraficiView, stato);
    }

    public void setAttributiEsterniValues(final Long soggettoId, final String value, final String causale, final Long opId) throws AttributiEsterniDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().setAttributiEsterniValues(soggettoId, value, causale, opId);
    }

    public void updateBollinoBluWithHost(final Long soggettoId, final String bollinoValue, final String codiceHost, final Long opId) throws AttributiEsterniDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().updateBollinoBluWithHost(soggettoId,bollinoValue,codiceHost,opId);
    }

    /* CodiciSoggettoSession */

    public void createCodiciSoggetto(final Long soggettoId, final IView datiAnagraficiView) throws CodiceSoggettoDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().createCodiciSoggetto(soggettoId, datiAnagraficiView);
    }

    public void setCodiciSoggetto(final Long soggettoId, final IView datiAnagraficiView) throws CodiceSoggettoDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().setCodiciSoggetto(soggettoId, datiAnagraficiView);
    }

    public IView getCodiciSoggetto(final Long soggettoId) throws CodiceSoggettoDiscriminatorException, ClassNotFoundException, RemoteException {
        return getOperazioneAnagrafeSession().getCodiciSoggetto(soggettoId);
    }

    public Long findByNDGNonOperativa(final IView iView) throws CodiceSoggettoDiscriminatorException, RemoteException {
        return getOperazioneAnagrafeSession().findByNDGNonOperativa(iView);
    }

    public void setCodiceValues(final Long soggettoId, final String value, final String causale, final Long opId) throws CodiceSoggettoDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().setCodiceValues(soggettoId, value, causale, opId);
    }

    /* DatiFiscaliSession */
    public void createDatiFiscaliPF(final Long soggettoId, final IView datiFiscaliView) throws DatiFiscaliDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().createDatiFiscaliPF(soggettoId, datiFiscaliView);
    }

    public IView getDatiFiscaliPF(final Long soggettoId) throws DatiFiscaliDiscriminatorException, ClassNotFoundException, RemoteException {
        return getOperazioneAnagrafeSession().getDatiFiscaliPF(soggettoId);
    }

    public void setDatiFiscaliPF(final Long soggettoId, final IView datiAnagraficiView) throws DatiFiscaliDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().setDatiFiscaliPF(soggettoId, datiAnagraficiView);
    }

    public void setDatiFiscaliPFWithBussta( final Long soggettoId, final IView datiFiscaliView, final Hashtable pdfTable ) throws DatiFiscaliDiscriminatorException, RemoteException {
    	getOperazioneAnagrafeSession().setDatiFiscaliPFWithBussta(soggettoId,datiFiscaliView,pdfTable);
    }

    /* DatiPrivacySession */

    public void createDatiPrivacyPF(final Long soggettoId, final IView datiPrivacyView) throws DatiPrivacyDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().createDatiPrivacyPF(soggettoId, datiPrivacyView);
    }

    public IView getDatiPrivacyPF(final Long soggettoId) throws DatiPrivacyDiscriminatorException, RemoteException {
        return getOperazioneAnagrafeSession().getDatiPrivacyPF(soggettoId);
    }

    public void setDatiPrivacyPF(final Long soggettoId, final IView datiAnagraficiView) throws DatiPrivacyDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().setDatiPrivacyPF(soggettoId, datiAnagraficiView);
    }

    /* Added for 5 level by Lalitha */

    public void createDatiPrivacyPFFiveLevel(final Long soggettoId, final IView datiPrivacyFiveLevelView) throws DatiPrivacyDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().createDatiPrivacyPFFiveLevel(soggettoId, datiPrivacyFiveLevelView);
    }

    public IView getDatiPrivacyPFFiveLevel(final Long soggettoId) throws DatiPrivacyDiscriminatorException, RemoteException {
        return getOperazioneAnagrafeSession().getDatiPrivacyPFFiveLevel(soggettoId);
    }

    public void setDatiPrivacyPFFiveLevel(final Long soggettoId, final IView datiAnagraficiView) throws DatiPrivacyDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().setDatiPrivacyPFFiveLevel(soggettoId, datiAnagraficiView);
    }

    /* AttributiTramite */

    public void createAttributiTramite(final Long soggettoId, final IView iView) throws AttributiEsterniDiscriminatorException, RemoteException  {
    	getOperazioneAnagrafeSession().createAttributiTramite(soggettoId, iView);
    }

    public void setAttributiTramite(final Long soggettoId, final AttributiTramiteAZView iView) throws AttributiEsterniDiscriminatorException, RemoteException {
    	getOperazioneAnagrafeSession().setAttributiTramite(soggettoId, iView);
    }

    public IView getAttributiTramiteAZView(final Long soggettoId) throws AttributiEsterniDiscriminatorException, RemoteException {
        return getOperazioneAnagrafeSession().getAttributiTramiteAZView(soggettoId);
    }

    /*RecapitiSession*/

    public void createRecapiti(final Long soggettoId, final SoggettoRecapitiView recapitiView) throws RecapitiDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().createRecapiti(soggettoId, recapitiView);
    }

    public Collection getRecapiti(final Long soggettoId) throws RecapitiDiscriminatorException, RemoteException {
        return getOperazioneAnagrafeSession().getRecapiti(soggettoId);
    }

    public void setRecapiti(final Long soggettoId, final SoggettoRecapitiView recapitiView) throws RecapitiDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().setRecapiti(soggettoId, recapitiView);
    }

    public void deleteRecapiti(final Long soggettoId, final Collection recapitiIds, final Long opId) throws RecapitiDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().deleteRecapiti(soggettoId, recapitiIds, opId);
    }

    /* EventoSession*/

    public void createEvento(final Long soggettoId, final SoggettoEventoView eventoView) throws EventoDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().createEvento(soggettoId, eventoView);
    }

    public Collection getEvento(final Long soggettoId) throws EventoDiscriminatorException, RemoteException {
        return getOperazioneAnagrafeSession().getEvento(soggettoId);
    }

    public void setEvento(final Long soggettoId, final SoggettoEventoView eventoView) throws EventoDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().setEvento(soggettoId, eventoView);
    }

    public void deleteEvento(final Long soggettoId, final Collection eventIds) throws EventoDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().deleteEvento(soggettoId, eventIds);
    }
    /*public Collection getEventiForSoggetto(Long soggettoId, String tipoEvento,Timestamp dataInizio,Timestamp dataFine) throws EventoDiscriminatorException,RemoteException
    {
        return getOperazioneAnagrafeSession().getEventiForSoggetto( soggettoId , tipoEvento , dataInizio , dataFine );
    }
    public Collection getEventiForSoggetto(Long soggettoId , Timestamp dataInizio,Timestamp dataFine) throws EventoDiscriminatorException,RemoteException
    {
        return getOperazioneAnagrafeSession().getEventiForSoggetto( soggettoId , dataInizio , dataFine );
    }
    public Collection getSoggettiIds(String tipoEventi,Timestamp dataInizio,Timestamp dataFine) throws EventoDiscriminatorException,RemoteException
    {
        return getOperazioneAnagrafeSession().getSoggettiIds( tipoEventi , dataInizio , dataFine );
    } */

    // o TipoSoggettoSession

    public Collection getCompatibleTipoRecapiti(final String tipoSoggettoSecondLevelName) throws RemoteException {
        return getOperazioneAnagrafeSession().getCompatibleTipoRecapiti(tipoSoggettoSecondLevelName);
    }

    public Collection getCompatibleTipoEventi(final String tipoSoggettoSecondLevelName) throws RemoteException {
        return getOperazioneAnagrafeSession().getCompatibleTipoEventi(tipoSoggettoSecondLevelName);
    }

    public Collection getCompatibleTipoDocumeni(final String tipoSoggettoSecondLevelName) throws RemoteException {
        return getOperazioneAnagrafeSession().getCompatibleTipoDocumeni(tipoSoggettoSecondLevelName);
    }

    public Collection getCompatibleAttributiEsterni(final String tipoSoggetto) throws RemoteException {
        return getOperazioneAnagrafeSession().getCompatibleAttributiEsterni(tipoSoggetto);
    }

    public Collection getCompatibleTipoSocieta(final Long tipoSoggettoId) throws RemoteException {
        return getOperazioneAnagrafeSession().getCompatibleTipoSocieta(tipoSoggettoId);
    }

    // o TipoDatiAnagraficiSession

    public void createDatiAnagraficiPF(final Long soggettoId, final IView datiAnagraficiView) throws DatiAnagraficiDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().createDatiAnagraficiPF(soggettoId, datiAnagraficiView);
    }

    public void setDatiAnagraficiPF(final Long soggettoId, final IView datiAnagraficiView) throws DatiAnagraficiDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().setDatiAnagraficiPF(soggettoId, datiAnagraficiView);
    }

    //the following method returns a smart PF collection
    public Collection findByDatiAnagraficiPF(final DatiAnagraficiPFView datiAnagraficiPFView) throws DatiAnagraficiDiscriminatorException, RemoteException {
        return getOperazioneAnagrafeSession().findByDatiAnagraficiPF(datiAnagraficiPFView);
    }

    public DatiAnagraficiPFView getDatiAnagraficiPF(final Long soggettoId) throws DatiAnagraficiDiscriminatorException, RemoteException {
        return getOperazioneAnagrafeSession().getDatiAnagraficiPF(soggettoId);
    }


    // o AltriTipoSoggettoSession

    public void createAltriTipoSoggetto(final Long soggettoId, final AltriSoggettoView altriSoggettoView) throws CreateException, RemoteException {
        getOperazioneAnagrafeSession().createAltriTipoSoggetto(soggettoId, altriSoggettoView);
    }

    public AltriSoggettoView getAltriTipoSoggetto(final Long id) throws FinderException, RemoteException {
        return getOperazioneAnagrafeSession().getAltriTipoSoggetto(id);
    }

    public void setAltriTipoSoggetto(final AltriSoggettoView altriSoggettoView) throws FinderException, RemoteException {
        getOperazioneAnagrafeSession().setAltriTipoSoggetto(altriSoggettoView);
    }

    public AltriSoggettoView findByDenominazione(final String Denominazione) throws FinderException, RemoteException {
        return getOperazioneAnagrafeSession().findByDenominazione(Denominazione);
    }

    //o CollegamentoSession
    public void gestoreCollegamento(final Long principaleSoggettoId, final Collection existCollIds, final String motiv, final Long opId) throws CollegamentoException, RemoteException {
        getOperazioneAnagrafeSession().gestoreCollegamento(principaleSoggettoId, existCollIds, motiv, opId);
    }

    public Long createCollegamento(final CollegamentoView collegamentoView) throws CollegamentoException, RemoteException {
        return getOperazioneAnagrafeSession().createCollegamento(collegamentoView);
    }

    public Collection listCollegamento(final Long soggettoId) throws CollegamentoException, RemoteException {
        return getOperazioneAnagrafeSession().listCollegamento(soggettoId);
    }

    public Collection listForPrincipalAndLinked(final Long principalId, final Long linkedId) throws CollegamentoException, RemoteException {
        return getOperazioneAnagrafeSession().listForPrincipalAndLinked(principalId, linkedId);
    }

    public Collection listCollegamento(final Long soggettoId, final Long motivoCollegamento) throws CollegamentoException, RemoteException {
        return getOperazioneAnagrafeSession().listCollegamento(soggettoId, motivoCollegamento);
    }

    public List listCollegamento( final Long linkedSoggettoId, final String motivoCollegamento ) throws CollegamentoException, RemoteException {
    	return getOperazioneAnagrafeSession().listCollegamento( linkedSoggettoId, motivoCollegamento );
    }

    public void updateAmministratoriBancaInHost( final UpdateAMMBAScanView updateAMMBScanView, final String hostUserCode) throws OperazioneAnagrafeManagerException, RemoteException {
    	getOperazioneAnagrafeSession().updateAmministratoriBancaInHost( updateAMMBScanView, hostUserCode);
    }

    public List getAllExtendArt136Scan() throws OperazioneAnagrafeManagerException, RemoteException {
    	return getOperazioneAnagrafeSession().getAllExtendArt136Scan();
    }

    public void createExtendArt136Scan() throws OperazioneAnagrafeManagerException, RemoteException {
    	getOperazioneAnagrafeSession().createExtendArt136Scan();
    }

    public void updateExtendArt136ScanStatus( final UpdateAMMBAScanView updateAMMBAScanView ) throws OperazioneAnagrafeManagerException, RemoteException {
    	getOperazioneAnagrafeSession().updateExtendArt136ScanStatus( updateAMMBAScanView );
    }

    public void setCollegamento(final Long id, final Timestamp dataFine, final Long opId) throws CollegamentoException, RemoteException {
        getOperazioneAnagrafeSession().setCollegamento(id, dataFine, opId);
    }

    public void setCollegamento(final Long id, final Timestamp dataFine, final Collection motiv, final Long opId) throws CollegamentoException, RemoteException {
        getOperazioneAnagrafeSession().setCollegamento(id, dataFine, motiv, opId);
    }

    public void setCollegamento(final Long principaleId, final Long linkedSoggettoId, final Timestamp dataFine, final String motiv, final Long opId, final String note) throws CollegamentoException, RemoteException {
        getOperazioneAnagrafeSession().setCollegamento(principaleId, linkedSoggettoId, dataFine, motiv, opId, note);
    }

    public void modifyCollegamento(final Long id, final it.sella.anagrafe.CollegamentoView collegamentoView) throws CollegamentoException, RemoteException {
        getOperazioneAnagrafeSession().modifyCollegamento(id, collegamentoView);
    }

    public Collegamento getColleganteMotivoAndLinked(final Long principaleId, final String motivo, final Long linkedSoggettoId) throws CollegamentoException, RemoteException {
        return getOperazioneAnagrafeSession().getColleganteMotivoAndLinked(principaleId, motivo, linkedSoggettoId);
    }

    public Collection getSoggettiColleganti(final Long linkedSoggettoId) throws CollegamentoException, RemoteException {
        return getOperazioneAnagrafeSession().getSoggettiColleganti(linkedSoggettoId);
    }

    public Collection getSoggettoCollegante(final Long linkedSoggettoId, final String motivoCollegamento) throws CollegamentoException, RemoteException {
        return getOperazioneAnagrafeSession().getSoggettoCollegante(linkedSoggettoId, motivoCollegamento);
    }

    public Long getPrincipaleForSoggettiColleganti(final Collection linkedSoggettoIds, final String motivoCollegamento) throws CollegamentoException, RemoteException {
        return getOperazioneAnagrafeSession().getPrincipaleForSoggettiColleganti(linkedSoggettoIds, motivoCollegamento);
    }

    //DocumentSession

    public void createDocumentoPF(final Long soggettoId, final IView documentoView) throws DocumentoDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().createDocumentoPF(soggettoId, documentoView);
    }

    public Collection getDocumentoPF(final Long soggettoId) throws DocumentoDiscriminatorException, RemoteException {
        return getOperazioneAnagrafeSession().getDocumentoPF(soggettoId);
    }

    public void setDocumentoPF(final Long soggettoId, final IView documentoView) throws DocumentoDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().setDocumentoPF(soggettoId, documentoView);
    }

    public void deleteDocumentoPF(final Long soggettoId, final Collection documentoIds, final Long opId) throws DocumentoDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().deleteDocumentoPF(soggettoId, documentoIds, opId);
    }

    public void setCap(final CAP cap) throws OperazioneAnagrafeManagerException, RemoteException {
        getOperazioneAnagrafeSession().setCap(cap);
    }

    public void setCitta(final Citta citta) throws OperazioneAnagrafeManagerException, RemoteException {
        getOperazioneAnagrafeSession().setCitta(citta);
    }

    public void createLog(final LogView logView) throws OperazioneAnagrafeManagerException, RemoteException {
        getOperazioneAnagrafeSession().createLog(logView);
    }

    public Collection getLog(final Long soggettoId) throws OperazioneAnagrafeManagerException, RemoteException {
        return getOperazioneAnagrafeSession().getLog(soggettoId);
    }

    public void updateEvento(final Long soggettoId, final Hashtable eventiHash, final Collection eventiIds, final Long opId) throws EventoDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().updateEvento(soggettoId, eventiHash, eventiIds, opId);
    }

    public void createCitta(final Citta citta) throws OperazioneAnagrafeManagerException, RemoteException {
        getOperazioneAnagrafeSession().createCitta(citta);
    }
    //added by pals
    public void createRamo(final Ramo ramo) throws OperazioneAnagrafeManagerException, RemoteException {
        getOperazioneAnagrafeSession().createRamo(ramo);
    }

    public void setRamo(final Ramo ramo) throws OperazioneAnagrafeManagerException, RemoteException {
        getOperazioneAnagrafeSession().setRamo(ramo);
    }

    public void removeRamo(final Long ramoPKID) throws OperazioneAnagrafeManagerException, RemoteException {
        getOperazioneAnagrafeSession().removeRamo(ramoPKID);
    }

    public void setNazione(final NazioneView nazioneView) throws OperazioneAnagrafeManagerException, RemoteException {
        getOperazioneAnagrafeSession().setNazione(nazioneView);
    }

    public void createNazione(final NazioneView nazioneView) throws OperazioneAnagrafeManagerException, RemoteException {
        getOperazioneAnagrafeSession().createNazione(nazioneView);
    }

    public void deleteCollegamento(final Collection collegamentoIds,final String action,final Long opId) throws CollegamentoException, RemoteException{
        getOperazioneAnagrafeSession().deleteCollegamento(collegamentoIds,action,opId);
    }

    public void updateSconfWithHost(final Long soggettoId, final String newSconfValue, final String codiceHost, final Long opId) throws OperazioneAnagrafeManagerException,RemoteException {
        getOperazioneAnagrafeSession().updateSconfWithHost(soggettoId,newSconfValue,codiceHost,opId);
    }
    public String mergeAnagraficDetails(final Long soggettoIdExisting,final Long soggettoIdDuplicate) throws RemoteException,OperazioneAnagrafeManagerException {
        return getOperazioneAnagrafeSession().mergeAnagraficDetails(soggettoIdExisting, soggettoIdDuplicate);
    }

    public void updateDaiForPrincipalIds(final Long pfSoggettoId, final boolean oldDai, final boolean newDai, final Long opId) throws OperazioneAnagrafeManagerException,RemoteException {
        getOperazioneAnagrafeSession().updateDaiForPrincipalIds(pfSoggettoId, oldDai, newDai, opId);
    }

    public Collection isExistsDocumento(final DocumentoPFView documentoPFView) throws DocumentoDiscriminatorException, RemoteException {
        return getOperazioneAnagrafeSession().isExistsDocumento(documentoPFView);
    }

    // Added by Karthik to get Ultima Modifica details in Address Page
    public Collection getLogForSoggettoAndProductID(final Long soggettoId) throws OperazioneAnagrafeManagerException, RemoteException {
        return getOperazioneAnagrafeSession().getLogForSoggettoAndProductID(soggettoId);
    }

    // Added by Durai to get Ultima Modifica DOMKO in Address Page
    public Collection getLogForDOMKO(final Long soggettoId) throws OperazioneAnagrafeManagerException, RemoteException {
        return getOperazioneAnagrafeSession().getLogForDOMKO(soggettoId);
    }

    // Added by Karthik to terminate existing motivs and to insert the newly selected motiv
    public String updateAmministratoriBanca(final Long soggettoId, final ClassificazioneView classificazioneView, final String codiceHost, final Collection existingCausales, final Long opId) throws OperazioneAnagrafeManagerException, RemoteException {
        return getOperazioneAnagrafeSession().updateAmministratoriBanca(soggettoId, classificazioneView, codiceHost, existingCausales, opId);
    }

    // UpdateAMMBALink Handling

    public List getExtractArt136() throws OperazioneAnagrafeManagerException, RemoteException {
        return getOperazioneAnagrafeSession().getExtractArt136();
    }

    public void createExtractArt136( final List ammbaLinkList ) throws OperazioneAnagrafeManagerException, RemoteException {
    	 getOperazioneAnagrafeSession().createExtractArt136(ammbaLinkList);
    }

    public void deleteAllExtractArt136() throws OperazioneAnagrafeManagerException, RemoteException {
    	getOperazioneAnagrafeSession().deleteAllExtractArt136();
    }

	public Long createLogHOSTCall(final LogHostCallView logHostCallView) throws OperazioneAnagrafeManagerException, RemoteException {
		return getOperazioneAnagrafeSession().createLogHOSTCall(logHostCallView);
	}

	public void createLogHOSTOperationData(final LogOperationDataView logOperationDataView) throws OperazioneAnagrafeManagerException, RemoteException {
		getOperazioneAnagrafeSession().createLogHOSTOperationData(logOperationDataView);
	}

    public void updateAnagrafeLog(final Long operationId, final Long soggettoId, final String errorMessage) throws OperazioneAnagrafeManagerException, RemoteException {
    	getOperazioneAnagrafeSession().updateAnagrafeLog(operationId, soggettoId, errorMessage);
    }

    public void updateAnagrafeLog(final Long operationId, final Long soggettoId) throws OperazioneAnagrafeManagerException, RemoteException {
    	getOperazioneAnagrafeSession().updateAnagrafeLog(operationId, soggettoId);
    }

    public List getAllOperationCode() throws OperazioneAnagrafeManagerException, RemoteException {
    	return getOperazioneAnagrafeSession().getAllOperationCode();
    }

	// Added by durai for codicesoggettoCifrati

    public void createCodiciSoggettoCifrati(final Long soggettoId, final String valoreCodiceHost, final Long opId) throws CodiceSoggettoDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().createCodiciSoggettoCifrati(soggettoId,valoreCodiceHost,opId);
    }

    public void setCodiceSoggettoCifratiValues(final Long soggettoId, final String newValoreCodiceHost, final Long opId) throws CodiceSoggettoDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().setCodiceSoggettoCifratiValues(soggettoId,newValoreCodiceHost,opId);
    }

    public void removeCodiceSoggettoCifrati(final Long soggettoId, final Long opId) throws CodiceSoggettoDiscriminatorException, RemoteException {
        getOperazioneAnagrafeSession().removeCodiceSoggettoCifrati(soggettoId, opId);
    }

    // Added by Durai for DocEventiAdmin
    public Collection getDocEventi(final Long soggettoId) throws ControlloDatiException , RemoteException {
        return getOperazioneAnagrafeSession().getDocEventi(soggettoId);
    }

    public void insertDocEventi(final DocEventiView docEventiView) throws ControlloDatiException , RemoteException {
        getOperazioneAnagrafeSession().insertDocEventi(docEventiView);
    }

    public void modifiyDocEventi(final DocEventiView docEventiView) throws ControlloDatiException , RemoteException {
        getOperazioneAnagrafeSession().modifiyDocEventi(docEventiView);
    }

    public void removeDocEventi(final DocEventiView docEventiView) throws ControlloDatiException ,RemoteException {
        getOperazioneAnagrafeSession().removeDocEventi(docEventiView);
    }

    public void createDipctAlignDetails(final DipctAlignDetailsView dipctAlignDetailsView) throws DIPCTAlignFailException, RemoteException {
        getOperazioneAnagrafeSession().createDipctAlignDetails(dipctAlignDetailsView);
    }

    public Collection getDipctAlignDetails(final String fromCoddp) throws DIPCTAlignFailException, RemoteException {
        return getOperazioneAnagrafeSession().getDipctAlignDetails(fromCoddp);
    }

    public void updateDipctAlignDetails(final DipctAlignDetailsView dipctAlignDetailsView) throws DIPCTAlignFailException, RemoteException {
        getOperazioneAnagrafeSession().updateDipctAlignDetails(dipctAlignDetailsView);
    }

    public void removeDipctAlignDetails(final DipctAlignDetailsView dipctAlignDetailsView) throws DIPCTAlignFailException, RemoteException {
        getOperazioneAnagrafeSession().removeDipctAlignDetails(dipctAlignDetailsView);
    }

    public void transferConto(final TransferContoView transferContoView, final Long opId) throws OperazioneAnagrafeManagerException, RemoteException {
        getOperazioneAnagrafeSession().transferConto(transferContoView, opId);
    }

    // SocketRollBackLog operations

    public void setSocketRollBackLog( final SocketRBLogOperationDataView socketRBLogOperationDataView) throws OperazioneAnagrafeManagerException, RemoteException {
        getOperazioneAnagrafeSession().setSocketRollBackLog(socketRBLogOperationDataView);
    }

    public List getSocketRollBackLog( final Hashtable searchCriteria) throws OperazioneAnagrafeManagerException, RemoteException {
    	return getOperazioneAnagrafeSession().getSocketRollBackLog(searchCriteria);
    }

    public void updateSocketRollBackLog( final SocketRBLogOperationDataView socketRBLogOperationDataView) throws OperazioneAnagrafeManagerException, RemoteException {
    	getOperazioneAnagrafeSession().updateSocketRollBackLog(socketRBLogOperationDataView);
    }

    public List getAllSocketRollBackLogStatus() throws OperazioneAnagrafeManagerException, RemoteException {
    	return getOperazioneAnagrafeSession().getAllSocketRollBackLogStatus();
    }

    public SocketRBLogOperationDataView getSocketRollBackLog( final Long socketRBPKId) throws OperazioneAnagrafeManagerException, RemoteException {
    	return getOperazioneAnagrafeSession().getSocketRollBackLog(socketRBPKId);
    }

    public void removeSocketRBLog( final Long socketRBPKId)  throws OperazioneAnagrafeManagerException, RemoteException {
    	getOperazioneAnagrafeSession().removeSocketRBLog(socketRBPKId);
    }

    public void writeSocketRBLogMessage( final Long rollBackPKId, final Long bankSoggettoId, final Long opId, final String socketMessage) throws OperazioneAnagrafeManagerException, RemoteException  {
    	getOperazioneAnagrafeSession().writeSocketRBLogMessage(rollBackPKId, bankSoggettoId, opId, socketMessage);
    }

    // Censimento Methods

    public Long performCensimentoAndBusta( final SoggettoView soggettoView, final Hashtable stampaTable ) throws OperazioneAnagrafeManagerException, RemoteException {
    	 return getOperazioneAnagrafeSession().performCensimentoAndBusta(soggettoView, stampaTable);
    }

    public void performCensimentoModificaAndBusta( final SoggettoView soggettoView, final Hashtable stampaTable ) throws OperazioneAnagrafeManagerException, RemoteException {
    	getOperazioneAnagrafeSession().performCensimentoModificaAndBusta(soggettoView, stampaTable);
    }

    public String getMessage( final String errorCode ) throws OperazioneAnagrafeManagerException, RemoteException {
    	return getOperazioneAnagrafeSession().getMessage( errorCode );
    }

    public Long getLoginSoggettoId() throws OperazioneAnagrafeManagerException, RemoteException {
    	return getOperazioneAnagrafeSession().getLoginSoggettoId();
    }

    public void logMessageForAnagrafeManager( final Long soggettoId, final String operation, final String data, final String operationCode, final boolean operationSuccess ) throws OperazioneAnagrafeManagerException, RemoteException {
   		getOperazioneAnagrafeSession().logMessageForAnagrafeManager(soggettoId, operation, data, operationCode, operationSuccess);
    }

    public List getAllMigrationPKId() throws OperazioneAnagrafeManagerException, RemoteException {
    	return getOperazioneAnagrafeSession().getAllMigrationPKId();
    }

    public String getMigrationInputData( final Long pkId ) throws OperazioneAnagrafeManagerException, RemoteException {
    	return getOperazioneAnagrafeSession().getMigrationInputData(pkId);
    }

    public void setMigrationStatus( final Long pkId, final String statusValue, final String errorMessage, final Long soggettoId, final String outputData ) throws OperazioneAnagrafeManagerException, RemoteException {
    	getOperazioneAnagrafeSession().setMigrationStatus(pkId, statusValue, errorMessage, soggettoId, outputData);
    }

    public void addMigrationData( final Long bankSoggettoId,  final List migrationData , final String  errorDesc) throws OperazioneAnagrafeManagerException ,RemoteException {
    	getOperazioneAnagrafeSession().addMigrationData(bankSoggettoId, migrationData , errorDesc);
    }

    public String getMigratedData( final String tipoSoggetto ) throws OperazioneAnagrafeManagerException ,RemoteException {
    	return getOperazioneAnagrafeSession().getMigratedData(tipoSoggetto);
    }

    public void clearMigrationData(final String deleteType ) throws OperazioneAnagrafeManagerException ,RemoteException {
    	getOperazioneAnagrafeSession().clearMigrationData(deleteType);
    }

    public String getExistSoggettoOutputData( final Long soggettoId, final Long bankId ) throws OperazioneAnagrafeManagerException, RemoteException {
    	return getOperazioneAnagrafeSession().getExistSoggettoOutputData(soggettoId, bankId);
    }

    public void setClienteClassificazione(final ClienteClassificazioneView clienteClassificazioneView,
			final FatturatoView fatturatoView, final Hashtable detailsTable)
    throws RemoteException, OperazioneAnagrafeManagerException {
    	getOperazioneAnagrafeSession().setClienteClassificazione(
				clienteClassificazioneView, fatturatoView, detailsTable);
	}

    public void logMessageWithErrorMsg( final Long soggettoId, final String operation, final String data, final String operationCode, final boolean operationSuccess ,final String errorMessage ) throws OperazioneAnagrafeManagerException, RemoteException {
   		getOperazioneAnagrafeSession().logMessageWithErrorMsg(soggettoId, operation, data, operationCode, operationSuccess ,errorMessage);
    }

    public List<CompDocumentView> getPFCompDocumentList(final Long bankId, final boolean isValid) throws OperazioneAnagrafeManagerException, RemoteException {
   		return getOperazioneAnagrafeSession().getPFCompDocumentList(bankId,isValid);
    }


    /**
     * Method to create Soggetto by passing ID which contains XML data for persisting in a particular bank (BPA)
     * @param soggettoPromotoreId
     * @param operationCode
     * @return
     * @throws OperazioneAnagrafeManagerException
     * @throws RemoteException
     */
    public String createSoggettoFromXMLForBPA(final Long soggettoPromotoreId, final String operationCode) throws OperazioneAnagrafeManagerException, RemoteException{
    	return getOperazioneAnagrafeSession().createSoggettoFromXMLForBPA(soggettoPromotoreId, operationCode);
    }
    public void updateAutoCensitoStatus(final Long soggettoPromotoreId,final String error, final String stato,final String rifDate,final Long opId) throws SoggettiPromotoreException,RemoteException{
    	getOperazioneAnagrafeSession().updateAutoCensitoStatus(soggettoPromotoreId, error, stato, rifDate, opId);
    }

    /**
     * Method to call OperazioneAnagrafeSession to create TipoSoggetto
     * @param tipoSoggettoView
     * @throws GestoreAnagrafeException
     */
    public void createTipoSoggetto(final TipoSoggettoView tipoView) throws GestoreAnagrafeException,RemoteException {
    	getOperazioneAnagrafeSession().createTipoSoggetto(tipoView);
    }

    /**
     * Method to call OperazioneAnagrafeSession to update TipoSoggetto
     * @param tipoSoggettoView
     * @throws GestoreAnagrafeException
     */
    public TipoSoggetto setTipoSoggetto(final TipoSoggettoView tipoView) throws GestoreAnagrafeException,RemoteException {
    	return getOperazioneAnagrafeSession().setTipoSoggetto(tipoView);
    }

    public Long createSellaLifeCustomer(final Long mainSoggettoId,final DatiAnagraficiAZView datiAnagraficiAZView,final Long operationId) throws OperazioneAnagrafeManagerException, RemoteException{
    	return getOperazioneAnagrafeSession().createSellaLifeCustomer(mainSoggettoId, datiAnagraficiAZView,operationId);
    }


    /**
     * Method to get EntityManager by JNDI look up
     * @return EntityManager
     */

    public EntityManager getPersistenceEntityManager() throws NamingException,RemoteException {
    	return getOperazioneAnagrafeSession().getPersistenceEntityManager();
    }

    private OperazioneAnagrafeSession getOperazioneAnagrafeSession() {
        try {
            if(operazione_anagrafe_session == null) {
                operazione_anagrafe_session = getOperazioneAnagrafeSessionHome().create();
            }
        } catch(final NamingException ne) {
            log4Debug.severeStackTrace(ne);
        } catch(final CreateException ce) {
            log4Debug.severeStackTrace(ce);
        } catch(final RemoteException re) {
            log4Debug.severeStackTrace(re);
        }
        return operazione_anagrafe_session;
    }

    private OperazioneAnagrafeSessionHome getOperazioneAnagrafeSessionHome() throws NamingException {
        final Context context = getContext();
        return (OperazioneAnagrafeSessionHome) PortableRemoteObject.narrow(context.lookup("it.sella.anagrafe.implementation.operazioneanagrafe.OperazioneAnagrafeSessionHome"), OperazioneAnagrafeSessionHome.class);
    }

    private Context getContext() throws NamingException {
        return new InitialContext();
    }

    public String maintainTerminateSoggetto(final Long soggetoIdOne,final Long soggetoIdTwo,final String terminateCollegamentoLinks) throws OperazioneAnagrafeManagerException, RemoteException {
    	return getOperazioneAnagrafeSession().maintainTerminateSoggetto(soggetoIdOne, soggetoIdTwo,terminateCollegamentoLinks);
    }
    
    public Map<String, String> terminateSoggetto(final Long soggetoIdOne,final Long soggetoIdTwo,final String terminateCollegamentoLinks) throws OperazioneAnagrafeManagerException, RemoteException {
    	return getOperazioneAnagrafeSession().terminateSoggetto(soggetoIdOne, soggetoIdTwo,terminateCollegamentoLinks);
    }
    
    public void logMessageToSecurity(final IAnagrafeLoggerView loggerView) throws RemoteException {
   		getOperazioneAnagrafeSession().logMessageToSecurity(loggerView);
    }
    
    /**
     * To update the Poste Status
     * @param view
     * @throws PosteException
     * @throws RemoteException
     */
    public void updateProcessedPosteStatus(final PosteCustomerView view) throws PosteException,RemoteException {
    	getOperazioneAnagrafeSession().updateProcessedPosteStatus(view);
    }
    
    /**
     * 
     * @param soggettoId
     * @param preferitoDataView
     * @param opId
     * @throws CanalePreferitoException
     * @throws RemoteException
     */
    public void createCanalePreferito(final Long soggettoId,final CanalePreferitoDataView preferitoDataView, final Long opId) throws CanalePreferitoException, RemoteException {
        getOperazioneAnagrafeSession().createCanalePreferito(soggettoId, preferitoDataView, opId);
    }

    /**
     * 
     * @param newView
     * @param oldView
     * @param soggettoId
     * @param opId
     * @throws CanalePreferitoException
     * @throws RemoteException
     */
    public void setCanalePreferito(final CanalePreferitoDataView newView, final Long soggettoId, final Long opId) throws CanalePreferitoException, RemoteException {
        getOperazioneAnagrafeSession().setCanalePreferito(newView, soggettoId, opId);
    }
    
    /**
     * @param soggettoId
     * @return
     * @throws CanalePreferitoException
     * @throws RemoteException
     */
    public CanalePreferitoDataView getValidCanalePreferitoForSoggettoId (final Long soggettoId) throws CanalePreferitoException, RemoteException {
		return getOperazioneAnagrafeSession().getValidCanalePreferitoForSoggettoId(soggettoId);
    }
    
    /**
     * @param soggettoId
     * @return
     * @throws CanalePreferitoException
     * @throws RemoteException
     */
    public ICanaleUtilizzatoView getValidCanaleUtilizzatoView (final Long soggettoId) throws CanalePreferitoException, RemoteException {
    	return getOperazioneAnagrafeSession().getValidCanaleUtilizzatoView(soggettoId);
    }
    
    /**
     * @param regoleDetailsView
     * @param soggettoId
     * @param opId
     * @throws AnagrafeDAIException
     * @throws RemoteException
     */
    public void createDAIRegole (final IDAIRegoleDetailsView regoleDetailsView, final Long soggettoId, final Long opId) throws AnagrafeDAIException, RemoteException {
    	getOperazioneAnagrafeSession().createDAIRegole(regoleDetailsView, soggettoId, opId);
	}
    
    /**
     * @param regoleDetailView
     * @param soggettoId
     * @param opId
     * @throws RemoteException
     * @throws AnagrafeDAIException
     */
    public void setDAIRegole(final IDAIRegoleDetailsView regoleDetailView, final Long soggettoId, final Long opId) throws RemoteException, AnagrafeDAIException {
    	getOperazioneAnagrafeSession().setDAIRegole(regoleDetailView, soggettoId, opId);
    }
    
    /**
     * @param daiSoggettoView
     * @param soggettoId
     * @param opId
     * @throws DAISoggettoException
     * @throws RemoteException
     */
    public void createDAISoggetto (final SoggettoDAIDataView daiSoggettoView, final Long soggettoId, final Long opId) throws DAISoggettoException, RemoteException {
    	getOperazioneAnagrafeSession().createDAISoggetto(daiSoggettoView, soggettoId, opId);
    }
    
    /**
     * @param daiSoggettoViewNew
     * @param daiSoggettoViewOld
     * @param soggettoId
     * @param opId
     * @throws DAISoggettoException
     * @throws RemoteException
     */
    public void setDAISoggetto(final SoggettoDAIDataView daiSoggettoView, final Long soggettoId, final Long opId) throws DAISoggettoException, RemoteException {
    	getOperazioneAnagrafeSession().setDAISoggetto(daiSoggettoView, soggettoId, opId);
    }
}