package it.sella.anagrafe.schema_validation;

import it.sella.anagrafe.XMLSchemaValidationException;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.IOException;
import java.io.StringReader;
import java.net.URL;

import javax.xml.XMLConstants;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

public class SchemaValidator {
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(SchemaValidator.class);
	
	public void validate(final String xmlSoggetto, final String soggettoXsdUrlKey) throws XMLSchemaValidationException {
		final SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		Schema schema;
		try {
			final URL url = getClass().getResource(CommonPropertiesHandler
					.getValueFromProperty(soggettoXsdUrlKey));
			schema = schemaFactory.newSchema(url);
			final SAXParserFactory saxFactory = SAXParserFactory.newInstance();
			saxFactory.setSchema(schema);
			final SAXParser parser = saxFactory.newSAXParser();
			parser.parse(new InputSource(new StringReader(xmlSoggetto)),new DefaultHandler() {
				@Override
				public void error(final SAXParseException e)
				throws SAXException {
					throw e;
				}
			});
		} catch (final ParserConfigurationException e) {
			log4Debug.debugStackTrace(e);
			throw new XMLSchemaValidationException(e);
		} catch (final SAXException e) {
			log4Debug.debugStackTrace(e);
			throw new XMLSchemaValidationException(e);
		} catch (final IOException e) {
			log4Debug.debugStackTrace(e);
			throw new XMLSchemaValidationException(e);
		}
	}
}
