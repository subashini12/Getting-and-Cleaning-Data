package it.sella.anagrafe.bpaautomaticcens;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.anagrafe.GestoreDatiFiscaliException;
import it.sella.anagrafe.dbaccess.DatiFiscaliDBAccessHelper;
import it.sella.anagrafe.pf.AttributiEsterniPFView;
import it.sella.anagrafe.pf.CodiceSoggettoPFView;
import it.sella.anagrafe.pf.CollegatePFView;
import it.sella.anagrafe.pf.DatiAnagraficiPFView;
import it.sella.anagrafe.pf.DatiFiscaliPFView;
import it.sella.anagrafe.pf.DocumentoPFView;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.SoggettiPromotoreException;
import it.sella.anagrafe.view.PersonaFisicaView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;

public class PFCensimentoXMLGenerator extends CensimentoXMLGenerator{
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(PFCensimentoXMLGenerator.class);
	
	public String getCensimentoXML(final PersonaFisicaView personaFisicaView,final Long soggettoId, final boolean isForGollegate) throws SoggettiPromotoreException, RemoteException{
		try {
			final StringBuilder censimentoXML = new StringBuilder("<SOGGETTI>");
			censimentoXML.append("<SOGGETTO TipoSoggetto=\"Semplice\">");
			setDatiAnagrafiData(censimentoXML,personaFisicaView.getDatiAnagraficiPFView());
			setAttributiEsterniData(censimentoXML,personaFisicaView.getAttributiEsterniPFView());
			setDatiFiscaliData(censimentoXML,personaFisicaView.getDatiFiscaliPFView());
			setIndirizzoData(censimentoXML,personaFisicaView.getIndirizziView());
			setRecapitiData(censimentoXML, personaFisicaView.getRecapitiPFView());
			setCanalePreferitoData(censimentoXML, personaFisicaView.getCanalePreferitoDataview());
			setDocumentData(censimentoXML, personaFisicaView.getDocumentiView(),soggettoId);
			setDatiPrivacyData(censimentoXML, personaFisicaView.getDatiPrivacyPFFiveLevelView());
			setCodiciSoggettoData(censimentoXML, personaFisicaView.getCodiceSoggettoPFView());
			setBankCollegamentiData(censimentoXML, personaFisicaView.getMotiv(),CommonPropertiesHandler.getValueFromProperty("BPA_BANK_NAME"));
			setPromotoreData(censimentoXML, personaFisicaView.getPromotoreIds(),personaFisicaView.getIntermediariViews(),isForGollegate);
			setOrgineClinteData(censimentoXML, personaFisicaView.getOrgcl());
			setLinkedSoggettoData(censimentoXML, personaFisicaView.getCollegateViews());
			censimentoXML.append("</SOGGETTO></SOGGETTI>");
			log4Debug.debug("PFCensimentoXMLGenerator : getCensimentoXML : censimentoXML==>",censimentoXML);
		return censimentoXML.toString();
		} catch (final GestoreCodiciSoggettoException e) {
			log4Debug.debugStackTrace(e);
			throw new SoggettiPromotoreException(e);
		} catch (final GestoreAnagrafeException e) {
			log4Debug.debugStackTrace(e);
			throw new SoggettiPromotoreException(e);
		} 
		
	}
	
	private void setDatiAnagrafiData(final StringBuilder censimentoXML,final DatiAnagraficiPFView datiAnagraficiPFView){
	
		if(datiAnagraficiPFView != null){
			censimentoXML.append("<DATI_ANAGRAFICI>");
			censimentoXML.append(getTagWithValueCheckWithCDATATag("NOME", datiAnagraficiPFView.getNome()));
			censimentoXML.append(getTagWithValueCheckWithCDATATag("COGNOME", datiAnagraficiPFView.getCognome()));
			censimentoXML.append( getDateTag(datiAnagraficiPFView.getDataDiNascita(),"DATA_NASCITA"));
			censimentoXML.append(getTagWithValueCheckWithCDATATag("CITTA_NASCITA", datiAnagraficiPFView.getLuogoDiNascitaCitta() != null ? datiAnagraficiPFView.getLuogoDiNascitaCitta().getCommune() : "" ));
			censimentoXML.append(getTagWithValueCheck("PROVINCIA_NASCITA", datiAnagraficiPFView.getLuogoDiNascitaCitta() != null && datiAnagraficiPFView.getLuogoDiNascitaCitta().getProvincia() != null  ? 
					datiAnagraficiPFView.getLuogoDiNascitaCitta().getProvincia().getSigla() : ""  ));
			censimentoXML.append(getTagWithValueCheck("NAZIONE_NASCITA", datiAnagraficiPFView.getLuogoDiNascitaNazione() != null ? datiAnagraficiPFView.getLuogoDiNascitaNazione().getNome() : ""));
			censimentoXML.append("</DATI_ANAGRAFICI>");
		}
	}

	private void setAttributiEsterniData(final StringBuilder censimentoXML,final AttributiEsterniPFView attributiEsterniPFView){
		if(attributiEsterniPFView != null){
			censimentoXML.append("<ATTRIBUTI_ESTERNI>");
			censimentoXML.append(getTagIfValueIsNotNull("SESSO", attributiEsterniPFView.getSesso() != null ? attributiEsterniPFView.getSesso().getCausale() : null ));
			censimentoXML.append(getTagIfValueIsNotNull("STATO", attributiEsterniPFView.getStato()));
			censimentoXML.append(getTagIfValueIsNotNull("LINGUA", attributiEsterniPFView.getLingua() != null ? attributiEsterniPFView.getLingua().getCausale() : null ));
			censimentoXML.append(getTagWithValueCheckWithCDATATag("PROFESSIONE", attributiEsterniPFView.getProfessione() != null ? attributiEsterniPFView.getProfessione().getCausale() : null ));
			censimentoXML.append(getTagIfValueIsNotNull("CITTADINANZA", attributiEsterniPFView.getCittadinanza() != null ? attributiEsterniPFView.getCittadinanza().getNome() : null));
			censimentoXML.append(getTagIfValueIsNotNull("SECONDA_CITTADINANZA", attributiEsterniPFView.getSecondaCittadinanza() != null ? attributiEsterniPFView.getSecondaCittadinanza().getNome() : null));
			censimentoXML.append(getTagIfValueIsNotNull("ATTIVITA", attributiEsterniPFView.getAtt()));
			censimentoXML.append(getTagIfValueIsNotNull("STATO_CIVILE", attributiEsterniPFView.getStatoCivile() != null ? attributiEsterniPFView.getStatoCivile().getCausale() : null ));
			censimentoXML.append(getTagIfValueIsNotNull("PARENTE_PROMOTORE_BPA", attributiEsterniPFView.getParpr()));
			censimentoXML.append(getTagIfValueIsNotNull("PROMOTORE_ALTRE_BANCHE", attributiEsterniPFView.getAtrpr()));
			censimentoXML.append(getTagIfValueIsNotNull("MODALITA_ACQ", attributiEsterniPFView.getModalita() != null ? attributiEsterniPFView.getModalita().getCausale() : null));
			censimentoXML.append(getTagWithValueCheckWithCDATATag("TAE",	attributiEsterniPFView.getTae() != null ? attributiEsterniPFView.getTae().getTaeDesc() : null));
			censimentoXML.append(getTagWithValueCheckWithCDATATag("ALBO_PROF",	attributiEsterniPFView.getAlbo_prof() != null ? attributiEsterniPFView.getAlbo_prof().getAlboDesc() : null));
			censimentoXML.append(getTagIfValueIsNotNull("NUMERO_ISCR_ALBO",	attributiEsterniPFView.getNumero_di_albo() != null ? attributiEsterniPFView.getNumero_di_albo() : null));
			censimentoXML.append(getTagWithValueCheckWithCDATATag("ULT_INFO_ALBO",	attributiEsterniPFView.getUlteriori_annotazioni() != null ? attributiEsterniPFView.getUlteriori_annotazioni() : null));
			censimentoXML.append(getTagIfValueIsNotNull("SOGG_APICALE",	attributiEsterniPFView.getSoggetto_apicale() != null ? attributiEsterniPFView.getSoggetto_apicale().toString() : null));
			censimentoXML.append("</ATTRIBUTI_ESTERNI>");
		}
	}
	
	private void setDatiFiscaliData(final StringBuilder censimentoXML,final DatiFiscaliPFView datiFiscaliPFView){
		if(datiFiscaliPFView != null){
			censimentoXML.append("<DATI_FISCALI>");
			censimentoXML.append(getTagIfValueIsNotNull("INDICATORE_A96", datiFiscaliPFView.getIndicatoreA96() != null ? datiFiscaliPFView.getIndicatoreA96().toString() : null));
			censimentoXML.append(getTagIfValueIsNotNull("INDICATORE_A97", datiFiscaliPFView.getIndicatoreA97()!= null ? datiFiscaliPFView.getIndicatoreA97().toString() : null));
			censimentoXML.append(getTagWithValueCheckWithCDATATag("CODICE_FISCALE_ESTERO", datiFiscaliPFView.getCdEst()));
			censimentoXML.append(getTagIfValueIsNotNull("RESIDENZA_FISCALE_2", datiFiscaliPFView.getResidenteFiscali2()!=null?datiFiscaliPFView.getResidenteFiscali2().getNome():null));
			censimentoXML.append(getTagWithValueCheckWithCDATATag("CODICE_FISCALE_ESTERO_2", datiFiscaliPFView.getCdEst2()));
			censimentoXML.append(getTagIfValueIsNotNull("RESIDENZA_FISCALE_3", datiFiscaliPFView.getResidenteFiscali3()!=null?datiFiscaliPFView.getResidenteFiscali3().getNome():null));
			censimentoXML.append(getTagWithValueCheckWithCDATATag("CODICE_FISCALE_ESTERO_3", datiFiscaliPFView.getCdEst3()));
			censimentoXML.append(getTagIfValueIsNotNull("CODICE_FISCALE", datiFiscaliPFView.getCodiceFiscali()));
			censimentoXML.append(getTagIfValueIsNotNull("NUMERO_SICUREZZA_SOCIALE", datiFiscaliPFView.getNumSic()));
			censimentoXML.append(getTagIfValueIsNotNull("REGIME_MINIMI", datiFiscaliPFView.getRegimeDeiMinimi() != null ? datiFiscaliPFView.getRegimeDeiMinimi().toString() : null));
			censimentoXML.append(getDateTag(datiFiscaliPFView.getRegimeDataAttivazione(),"DATA_ATTIVAZIONE"));
			censimentoXML.append(getDateTag(datiFiscaliPFView.getRegimeDataRevoca(),"DATA_REVOCA"));
			censimentoXML.append("</DATI_FISCALI>");
		}
	}
	
	
	private void setCodiciSoggettoData(final StringBuilder censimentoXML,final CodiceSoggettoPFView codiceSoggettoPFView){
		if(codiceSoggettoPFView != null){
			setCodiciSoggettoValue(censimentoXML,"min",codiceSoggettoPFView.getMin());
			setCodiciSoggettoValue(censimentoXML,"codpr",codiceSoggettoPFView.getCodpr());
			setCodiciSoggettoValue(censimentoXML,"codlm",codiceSoggettoPFView.getCodlm());
			setCodiciSoggettoValue(censimentoXML,"codsv",codiceSoggettoPFView.getCodsv());
		}
	}
	
	
	private void setBankCollegamentiData(final StringBuilder censimentoXML , final Collection<String> motivCollection,final String bankName){
		if(motivCollection != null){
			if(motivCollection.contains("CLINT")){
				censimentoXML.append("<COLLEGAMENTI>");
				censimentoXML.append(getTagWithValueCheck("TIPO_COLLEGAMENTO", "CLINT"));
				censimentoXML.append(getTagWithValueCheckWithCDATATag("SOGGETTO_COLLEGANTE", bankName));
				censimentoXML.append("</COLLEGAMENTI>");
			}	
		}
	}
	private void setLinkedSoggettoData(final StringBuilder censimentoXML , final Collection<CollegatePFView> collegatePFViews) throws GestoreDatiFiscaliException, RemoteException{
		
		if(collegatePFViews != null){
			final DatiFiscaliDBAccessHelper datiFiscaliDBAccessHelper = new DatiFiscaliDBAccessHelper();
			for (final CollegatePFView collegatePFView : collegatePFViews) {
				if(collegatePFView != null){
					if(!"ABIL8CIFRE".equals(collegatePFView.getTypeOfCollegate())){
						censimentoXML.append("<SOGGETTO_COLLEGAMENTI>");
						censimentoXML.append(getTagWithValueCheck("TIPO_COLLEGAMENTO", collegatePFView.getTypeOfCollegate()));
						censimentoXML.append(getTagWithValueCheck("CODICE_FISCALE_COLLEGATE", datiFiscaliDBAccessHelper.getDatiFiscali(collegatePFView.getId(), "codiceFiscali")));
						censimentoXML.append("</SOGGETTO_COLLEGAMENTI>");
					}
				}
			}	
		}
	}
	
	/**
	 * This method returns the Documenti xml for all the Documents as List if <DOC> tag value (docFlag) is 1
	 * and this will be added to output xml
	 * @param documentiColl
	 * @return String
	 * 
	 */
	public String getOutputXMLMessageForDocumenti(final Collection documentiColl) {
		boolean addListTag = true;
		final StringBuffer soggettoBuffer = new StringBuffer();		
		for (Object obj : documentiColl) {
			final DocumentoPFView docView = (DocumentoPFView)obj;
			final String docFlag = docView.getDocFlag();
			
			log4Debug.debug("Document ID : ",docView.getDocumentoId()," Doc Flag ::",docFlag, "ID DOC : ",docView.getIdDoc());
			if(docFlag !=null && "1".equals(docFlag) && docView.getDocumentoId() == null){
				if(addListTag){
					soggettoBuffer.append("<DOCUMENTI_LIST>");
				}				
				soggettoBuffer.append("<DOCUMENTI>");
				soggettoBuffer.append(getTagIfValueIsNotNullWithCDATATag("TIPO_DOCUMENTO", docView.getTipoDocumento().getCausale()));
				soggettoBuffer.append(getTagIfValueIsNotNullWithCDATATag("NUMERO_DOCUMENTO", docView.getDocumentoNumero()));
				soggettoBuffer.append(getTagWithValueCheckWithCDATATag("ENTE_EMISSIONE", docView.getEnteEmissione()));
				soggettoBuffer.append(getTagWithValueCheckWithCDATATag("LUOGO_EMISSIONE", docView.getLuogoEmissione()));				
				soggettoBuffer.append( getDateTag(docView.getDataEmissione(),"DATA_EMISSIONE"));
				soggettoBuffer.append( getDateTag(docView.getDataScadenza(),"DATA_SCADENZA"));				
				soggettoBuffer.append(getTagIfValueIsNotNull("BARCODE",docView.getBarcode()));
				soggettoBuffer.append(getTagIfValueIsNotNull("ID_DOC",docView.getIdDoc()));
				soggettoBuffer.append("</DOCUMENTI>");
				addListTag = false;
			}
			
		}
		if(!addListTag){
			soggettoBuffer.append("</DOCUMENTI_LIST>");
		}
		return soggettoBuffer.toString();		
	}
}
