package it.sella.training.assignment;

import java.text.ParseException;

import java.util.Collections;

import java.util.List;

public class EmployeeCodeAscending {
	public static void main(String[] args) throws ParseException {
		List<Employee> allEmployeeList = EmployeeRegister
				.getEmployeeDetails();

		for (Employee tmp : allEmployeeList) {
			Collections.sort(allEmployeeList, new CodeAscendingComparator());
			System.out.println(tmp.toString());
		}
	}

}
