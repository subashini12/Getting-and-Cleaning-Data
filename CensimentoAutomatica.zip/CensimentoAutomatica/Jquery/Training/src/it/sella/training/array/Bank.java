package it.sella.training.array;

public interface Bank {
	
	public void intersetRates();

}


class RBI implements Bank{

	public void intersetRates() {
		// TODO Auto-generated method stub
		
	}
	
}
