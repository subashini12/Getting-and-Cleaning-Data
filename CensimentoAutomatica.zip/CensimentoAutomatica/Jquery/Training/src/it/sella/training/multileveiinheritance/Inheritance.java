package it.sella.training.multileveiinheritance;

public class Inheritance  {
public static void main(String args[]){
	C c=new C();
	c.abc();
	
}
}

