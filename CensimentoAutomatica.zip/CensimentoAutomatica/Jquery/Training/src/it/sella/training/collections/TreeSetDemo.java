package it.sella.training.collections;
import java.util.*;
public class TreeSetDemo {
public static void main(String args[]){
	TreeSet<String> t=new TreeSet<String>();
	t.add("one");
	t.add("two");
	t.add("two");
	t.add("four");
	t.add("five");
	t.add("six");
	System.out.println("collection element is:" +t);
}
}
