package it.sella.training.multileveiinheritance;

public class C extends B{

}
