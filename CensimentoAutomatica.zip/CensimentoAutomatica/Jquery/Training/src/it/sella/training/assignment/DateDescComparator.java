package it.sella.training.assignment;

import java.util.Comparator;

public class DateDescComparator implements Comparator<Employee> {
	public int compare(Employee o1, Employee o2) {

		return -1 * ((o1.getDate()).compareTo(o2.getDate()));
	}

}
