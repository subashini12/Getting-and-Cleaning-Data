package it.sella.training.polymorphism;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;



public class Mammal extends Animal {
	 public void eat(String name){
	      System.out.println("Mammal eats");
	   }

	   public void travel(){
	      System.out.println("Mammal travels");
	   } 

	   public static void main(String[] args) {
			String input ="<PayLoad><SoggettoID>7091613</SoggettoID><RecapitiDetails><TipoRecapiti>TEC</TipoRecapiti><TipoRecapitiDescription>Tel.Cellulare</TipoRecapitiDescription><RecapitiValue>754745845784</RecapitiValue><Riferimento>xcbxcbxc&amp;cxbxc</Riferimento><Prefisso>001 - CANADA</Prefisso></RecapitiDetails><RecapitiDetails><TipoRecapiti>TEC</TipoRecapiti><TipoRecapitiDescription>Tel.Cellulare</TipoRecapitiDescription><RecapitiValue>343654756</RecapitiValue><Riferimento>346&amp;57</Riferimento><Prefisso>001 - CANADA</Prefisso></RecapitiDetails><RecapitiDetails><TipoRecapiti>TEC</TipoRecapiti><TipoRecapitiDescription>Tel.Cellulare</TipoRecapitiDescription><RecapitiValue>9243654</RecapitiValue><Riferimento>34654745757</Riferimento><Prefisso>001 - CANADA</Prefisso></RecapitiDetails><CANALE_PREFERITO><TIPO_CANALE_PREFERITO></TIPO_CANALE_PREFERITO><VALORE_CANALE_PREFERITO></VALORE_CANALE_PREFERITO><TIPO_RECAPITI></TIPO_RECAPITI></CANALE_PREFERITO></PayLoad>";
				try {
					final DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
					 Document doc = dbf.newDocumentBuilder().parse(new ByteArrayInputStream(input.getBytes()));
					 System.out.println(doc.getElementsByTagName("Riferimento"));
				} catch (SAXException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParserConfigurationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}
/*
	   public static String getRefirementoWithCDATA(String inputXML){
			String[] result = inputXML.split("</Riferimento>");
			for (String string : result) {
					if(string !=null && string.contains("<Riferimento>")){
						inputXML=inputXML.replaceAll(string.substring(string .indexOf("<Riferimento>")+13),SetXMLHandler.getTagWithValueCheckWithCDATATag( string.substring(string .indexOf("<Riferimento>")+13) !=null? string.substring(string .indexOf("<Riferimento>")+13):""));
					}
			}
			System.out.println(inputXML);
			return inputXML;
		}
		
		public static void main(String[] args) {
			getRefirementoWithCDATA("<AnagrafeSetRecapitiListRequest><SoggettoID>7032226</SoggettoID><RecapitiList><RecapitiDetails><TipoRecapiti>TEC</TipoRecapiti><TipoRecapitiDescription>Tel.Cellulare</TipoRecapitiDescription><RecapitiValue>789469599</RecapitiValue><Riferimento>xcvxc&xcxc</Riferimento><Prefisso>001-CANADA</Prefisso></RecapitiDetails><RecapitiDetails><TipoRecapiti>TEA</TipoRecapiti><TipoRecapitiDescription>Tel.Fisso</TipoRecapitiDescription><RecapitiValue>789469599</RecapitiValue><Riferimento>35435&57657</Riferimento><Prefisso>001-CANADA</Prefisso></RecapitiDetails><CANALE_PREFERITO><TIPO_CANALE_PREFERITO>TEL_FISSO</TIPO_CANALE_PREFERITO><VALORE_CANALE_PREFERITO>789469599</VALORE_CANALE_PREFERITO><TIPO_RECAPITI>TEA</TIPO_RECAPITI></CANALE_PREFERITO></RecapitiList></AnagrafeSetRecapitiListRequest>");
		}	*/


}
