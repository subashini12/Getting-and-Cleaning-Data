package it.sella.training.Super;

public class SuperExample extends Super{
	public static void main(String args[]){
		SuperExample s=new SuperExample();
		s.printMethod();
	}
		public void printMethod(){
			super.printMethod();
			System.out.println("Overidden By Subclass");
			
		}
	

}
