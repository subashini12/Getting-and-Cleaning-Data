package it.sella.training.assignment;

import java.util.Comparator;

public class SalaryDescComparator implements Comparator<Employee> {
	public int compare(Employee o1, Employee o2) {

		return -1 * ((o1.getSalary()).compareTo(o2.getSalary()));
	}

}
