package it.sella.training.array;

import java.util.List;

public class UserListerDB implements UserLister {
    public List<User> getUsers() {
		return null;
        // DB access code here
    }
    
    public static void main(String[] args) {
    	UserLister userLister;

            List<User> users = userLister.getUsers();
	}
}
