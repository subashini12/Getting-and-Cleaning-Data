package it.sella.training.Instanceof;

public class Child extends Parent{

}
