package it.sella.training.Instanceof;

public class InstanceDemo {
	public static void main(String args[]){
		Parent obj=new Parent();
		Child obj1=new Child();
		if(obj instanceof Parent)
			System.out.println("obj is instance of parent");
		if (obj1 instanceof Child)
			System.out.println("obj1 is instance of child");
	}

}
