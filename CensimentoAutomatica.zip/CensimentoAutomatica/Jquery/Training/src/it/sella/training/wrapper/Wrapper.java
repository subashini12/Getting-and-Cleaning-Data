package it.sella.training.wrapper;
import java.math.BigDecimal;

public class Wrapper {
	public static void main(String args[]){
		String str1="140.456789345234567";
		Double obj1=Double.valueOf(str1);
		System.out.println(obj1);
		
		String str2="135";
		Integer obj2=Integer.valueOf(str2);
		System.out.println(obj2);
		
		String str3="126.8976434";
		Float obj3=Float.valueOf(str3);
		System.out.println(obj3);
		
		String str4="1567.5432567";
		BigDecimal obj4= new BigDecimal(str4);
		System.out.println(obj4);
		
		String str5="true";
		Boolean obj5 =Boolean.valueOf(str5);
		System.out.println(obj5);
	}

}
