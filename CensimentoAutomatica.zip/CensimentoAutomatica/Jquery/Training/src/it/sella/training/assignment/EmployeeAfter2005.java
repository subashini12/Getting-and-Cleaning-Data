package it.sella.training.assignment;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

public class EmployeeAfter2005 {

	// private final Date date = null;
	// private final Date Date = date;

	public static void main(String[] args) throws ParseException {

		Collection<Employee> allEmployeeList = EmployeeRegister
				.getEmployeeDetails();
		String expectedPattern = "dd/MM/yyyy";
		SimpleDateFormat formatter = new SimpleDateFormat(expectedPattern);
		Date date = formatter.parse("31/12/2005");
		final Date Date = date;
		System.out.println("-----Employees Joined After 2005-------");
		for (Employee employee : allEmployeeList) {

			if (employee.getDate().after(Date)) {
				System.out.println(employee.toString());
			}

		}
	}
}
