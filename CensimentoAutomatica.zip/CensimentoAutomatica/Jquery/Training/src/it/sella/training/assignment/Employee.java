package it.sella.training.assignment;

import java.math.BigDecimal;
import java.util.Date;

/**
 * This Class Consists Of accessors and mutators
 * 
 * @author INSTAGE20
 * 
 */
public class Employee {
	// Private fields
	private String code;
	private String name;
	private Date date;
	private BigDecimal salary;
	private String department;
	private String manager;

	// Constructor method
	public Employee(String string, String string2, Date date2, BigDecimal b,
			String string4, String string5) {

		setCode(string);
		setName(string2);
		setDate(date2);
		setSalary(b);
		setDepartment(string4);
		setManager(string5);
	}

	public String toString() {
		return " EmpCode :: " + getCode() + ", Name :: " + getName()
		+ " ,JoinDate::" + getDate() + " ,Salary::" + getSalary()
		+ ", Department::" + getDepartment() + ", Manager::"
		+ getManager();
	}
	public void setCode(String code) {
		this.code = code;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public void setDate(Date date) {
		this.date = date;
	}
	//Mutator for all Private fields

	public String getCode() {
		return code;
	}

	public String getName() {
		return name;
	}

	public BigDecimal getSalary() {
		return salary;
	}

	public String getDepartment() {
		return department;
	}

	public String getManager() {
		return manager;
	}

	public Date getDate() {
		return date;
	}

	public int compareTo(Employee o) {
		return 0;
	}

}
