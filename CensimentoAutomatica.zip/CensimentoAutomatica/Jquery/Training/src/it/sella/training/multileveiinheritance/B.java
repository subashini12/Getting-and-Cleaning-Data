package it.sella.training.multileveiinheritance;

public class B extends A {
int c=30;
void abc()
        {
               System.out.println(a+b+c);
               lmn();
       }

}
