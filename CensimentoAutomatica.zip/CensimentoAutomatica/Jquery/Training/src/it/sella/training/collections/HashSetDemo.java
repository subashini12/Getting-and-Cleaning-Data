package it.sella.training.collections;
import java.util.*;
public class HashSetDemo {
public static void main(String args[]){
	HashSet<String> s=new HashSet<String>();
	s.add("one");
	s.add("two");
	s.add("six");
	s.add("three");
	s.add("nine");
	s.add("nine");
	for ( String iter : s )
	   {
	   
	   System.out.println(  iter);
	   }
	//System.out.println("collectio is:" +s);
}
}
