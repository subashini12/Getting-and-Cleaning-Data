//  Simple example which I found for cloneable and improve just to practise Java  

// If you have some notes on my implementation I will be happy to hear them.

package it.sella.training.clone;

// Refered object from class for cloning

class Department implements Cloneable {

public Department(String departmentName){
this.departmentName = departmentName;
}

protected Object clone() throws CloneNotSupportedException {
Department dep = new Department(this.departmentName);
return dep;
}

private String departmentName;
}

public class CloneDemo implements Cloneable {

/**
* @param args
*/
public static void main(String[] args) {
	CloneDemo ce = new CloneDemo("PACO", 33, new Department("IT"));

try{
	CloneDemo cloned = (CloneDemo)ce.clone();
	System.out.println("Clone : " + cloned.depart);
}catch (CloneNotSupportedException e) {
e.printStackTrace();
}

}

public CloneDemo(String aName, int aAge, Department aDepart){
this.name = aName;
this.age = aAge;
this.depart = aDepart;

}

protected Object clone() throws CloneNotSupportedException {
	CloneDemo clone = (CloneDemo)super.clone();
clone.depart = (Department)depart.clone();

return clone;
}

private String name;
private String address;
private int age;
private Department depart;

}

