package it.sella.training.assignment;

import java.text.ParseException;
import java.util.Collections;
import java.util.List;

public class EmployeeSalaryDescending {
	public static void main(String[] args) throws ParseException {

		List<Employee> allEmployeeList = EmployeeRegister
				.getEmployeeDetails();

		System.out.println("-----Salary Desc-------");
		Collections.sort(allEmployeeList, new SalaryDescComparator());
		for (Employee tmp : allEmployeeList) {
			System.out.println("Salary::" + tmp.getSalary());

		}
	}

}
