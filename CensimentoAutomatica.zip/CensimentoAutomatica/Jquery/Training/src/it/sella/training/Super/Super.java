package it.sella.training.Super;

public class Super {
	public void printMethod(){
		for(int i=0;i<10;i++)
			System.out.println(+i);
		System.out.println("Super Class Method");
	}

}
