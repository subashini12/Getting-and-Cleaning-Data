package it.sella.training.Instanceof;

public class Parent  {

}
