package it.sella.training.assignment;
import java.text.ParseException;
import java.util.Collections;
import java.util.List;

public class EmployeeReverseOrder {
	public static void main(String[] args) throws ParseException {
		List<Employee> allEmployeeList = EmployeeRegister.getEmployeeDetails();  
		
		System.out.println("----- Employee Rev-------");
		  Collections.reverse(allEmployeeList);
		  for(Employee employee:allEmployeeList)
		  {
			  System.out.println("Name::"+employee.getName());
		}
		  
		  
	}

}
