package it.sella.training.ascii;

public class Ascii {
public static void main(String args[]){
	String ss="java course";
	for(int i=0;i<ss.length();i++)
		System.out.println("ASCII value of: "+ss.charAt(i)+ " is:"+ ss.charAt(i) );

		
}		
}

