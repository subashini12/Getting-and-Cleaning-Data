package it.sella.training.exception;

public class Example2 {
	public static void main(String args[]){
		String str=null;
		System.out.println(str.toString());
	}

}
