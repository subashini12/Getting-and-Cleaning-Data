package it.sella.training.assignment;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Collection;

public class EmployeeTotalSalary {
	public static void main(String[] args) throws ParseException {
		BigDecimal Total=new BigDecimal("0");
		
		Collection<Employee> allEmployeeList = EmployeeRegister.getEmployeeDetails();  
		

		System.out.println("---------------Sum Of Salary ----------------");
		for(Employee employee:allEmployeeList){
			 if (employee.getDepartment().equals("IT")) {

					BigDecimal b1 = employee.getSalary();
					Total = Total.add(b1);
					
				}
			 if (employee.getDepartment().equals("Admin")) {

					BigDecimal b2 = employee.getSalary();
					Total = Total.add(b2);
				}
			 if (employee.getDepartment().equals("Executive")) {

					BigDecimal b3 = employee.getSalary();
					Total = Total.add(b3);
				}

			 
		}
		
	System.out.println("Total Salary :"+Total);	
	}

}
