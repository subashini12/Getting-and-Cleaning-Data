package it.sella.training.exception;

import java.util.Vector;

public class CastExecption {
	public static void main(String[] args) {
        Vector<Integer> v = new Vector<Integer>();
        int i = 10;
        Object obj = v.add(i);
       
		//String s=(String)obj;
    System.out.println(String.valueOf(obj));
        
      
	}

}
