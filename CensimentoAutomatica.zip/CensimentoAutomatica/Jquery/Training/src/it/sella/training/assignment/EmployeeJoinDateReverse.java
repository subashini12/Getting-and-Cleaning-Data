package it.sella.training.assignment;

import java.text.ParseException;
import java.util.Collections;
import java.util.List;

public class EmployeeJoinDateReverse {

	public static void main(String[] args) throws ParseException {

		List<Employee> allEmployeeList = EmployeeRegister
				.getEmployeeDetails();

		System.out.println("------Date Desc-------");
		Collections.sort(allEmployeeList, new DateDescComparator());
		for (Employee tmp : allEmployeeList) {
			System.out.println("Date::" + tmp.getDate());

		}
	}

}
