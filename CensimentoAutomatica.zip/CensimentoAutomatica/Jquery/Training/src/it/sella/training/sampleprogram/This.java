package it.sella.training.sampleprogram;

public class This {
public static void main(String args[]){
	Rectangle r=new Rectangle();
	r.show(8,9);
	int area=r.calculate();
	System.out.println("The Area Of Rectangle Is:"+ area);
	
}

}
