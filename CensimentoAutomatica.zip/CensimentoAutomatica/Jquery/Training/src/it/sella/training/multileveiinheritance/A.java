package it.sella.training.multileveiinheritance;

public class A {
int a=10,b=20;
void xyz()
       {
               System.out.println(a+b);
       }
        void lmn()
        {
               System.out.println("lmn");
        }

}
