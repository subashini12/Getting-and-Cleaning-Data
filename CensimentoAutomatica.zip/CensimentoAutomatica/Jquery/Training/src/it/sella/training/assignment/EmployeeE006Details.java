package it.sella.training.assignment;

import java.text.ParseException;
import java.util.Collection;

public class EmployeeE006Details {
	public static void main(String[] args) throws ParseException {
		Collection<Employee> allEmployeeList = EmployeeRegister
				.getEmployeeDetails();

		System.out
				.println("---------------Employee With Code E006----------------");

		for (Employee employee : allEmployeeList) {
			if (employee.getCode().compareTo("E006") == 0) {
				System.out.println(employee.toString()+"\n");
			}

		}

	}

}
