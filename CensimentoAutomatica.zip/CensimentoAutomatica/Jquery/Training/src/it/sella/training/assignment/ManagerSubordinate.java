package it.sella.training.assignment;

import java.text.ParseException;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class ManagerSubordinate {
	public static void main(String[] args) throws ParseException {
		Collection<Employee> allEmployeeList = EmployeeRegister
				.getEmployeeDetails();
		Set<String> set = new HashSet<String>();
		for (Employee emp : allEmployeeList) {
			if (emp.getManager() != null)
				set.add(emp.getManager());
		}
		for (String manager : set) 
		{
			System.out.println("Under Manager " + manager
					+ " available Employee Listed Below :");
			for (Employee emp : allEmployeeList)
			{
				String empManager = emp.getManager();
				if (empManager != null) 
				{
					if ((manager.compareTo(empManager)) == 0) 
					{
						System.out.print(emp.getName() + "  "+"\n");
					}
				}
			}
			System.out.println();
		}

	}

}
