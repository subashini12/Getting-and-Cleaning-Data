package it.sella.training.collections;
import java.util.*;
public class VectorDemo {
	public static void main(String args[]){
	Vector<String> v=new Vector<String>(5);
	v.add("one");
	v.add("two");
	v.add("three");
	v.add("four");
	v.add("five");
	v.add("six");

System.out.println(v.get(0));
System.out.println(v.get(1));
System.out.println(v.get(2));
System.out.println(v.get(3));
System.out.println(v.get(4));
System.out.println(v.get(5));
	
	}	
	

}
