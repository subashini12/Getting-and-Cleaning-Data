package it.sella.training.collections;
import java.util.*;
public class ArrayListexample {
public static void main(String args[]){
	ArrayList<String> al = new ArrayList<String>(); 
	al.add("A");
	al.add("d");
	al.add("b");
	al.add("j");
	al.add("j");
	al.add("l");
	for ( String coll: al )
	   {
	  System.out.println( coll);
	   }
}
}
