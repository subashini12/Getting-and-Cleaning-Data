package it.sella.training.array;

import java.util.List;

public interface UserLister {
	List<User> getUsers();
}
