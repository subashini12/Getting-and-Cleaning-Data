package it.sella.training.sampleprogram;

public class Rectangle {
	int length;
	int breadth;
	void show(int length,int breadth){
	this.length=length;
	this.breadth=breadth;
	}
	int calculate(){
		return(length*breadth);
	}

}
