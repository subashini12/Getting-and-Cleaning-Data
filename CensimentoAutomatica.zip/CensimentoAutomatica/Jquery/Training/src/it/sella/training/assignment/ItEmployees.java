package it.sella.training.assignment;

import java.text.ParseException;
import java.util.Collection;

public class ItEmployees {

	public static void main(String[] args) throws ParseException {

		Collection<Employee> allEmployeeList = EmployeeRegister
				.getEmployeeDetails();

		System.out.println("-----Employee Working In IT-------");
		for (Employee employee : allEmployeeList) {
			if (employee.getDepartment().compareTo("IT") == 0) {
				System.out.println(employee.toString());
			}

		}
	}
}
