package it.sella.training.collections;

import java.util.*;

public class HashMapExamp {
	public static void main(String args[]){
		HashMap<String, String> h=new HashMap<String, String>();
		 h.put("1","One");
		 h.put("2","Two");
		 h.put("4","Three");
		 h.put("5","Three");
		 h.put("6","Two");
		/* get Collection of values contained in HashMap using
		 Collection values() method of HashMap class*/
		 Collection<String> c=h.values();
		 
		 Iterator<String> itr = c.iterator();
		 while(itr.hasNext())
			 System.out.println(itr.next());
		 
		
	}

}
