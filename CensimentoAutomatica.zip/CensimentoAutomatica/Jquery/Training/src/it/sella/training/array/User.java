package it.sella.training.array;

public class User {

}
