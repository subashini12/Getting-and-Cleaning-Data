package it.sella.training.assignment;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.List;
import java.util.Date;
import java.text.ParseException;
/**
 * This class consists of all Employee Records
 * @author INSTAGE20
 *
 */
public class EmployeeRegister {


	public static List<Employee> getEmployeeDetails() 
	{
		String expectedPattern = "dd/MM/yyyy";
		SimpleDateFormat formatter = new SimpleDateFormat(expectedPattern);
		List<Employee> listEmployees=new ArrayList<Employee>();
		try {
			Date e001date = formatter.parse("12/05/2010");
			Date e002date = formatter.parse("12/04/2010");
			Date e003date = formatter.parse("02/5/2007");
			Date e004date = formatter.parse("12/5/2009");
			Date e005date = formatter.parse("12/5/2000");
			Date e006date = formatter.parse("08/5/2010");
			Date e007date = formatter.parse("12/5/2001");
			Date e008date = formatter.parse("12/5/2003");
			Date e009date = formatter.parse("24/3/2005");
			Date e010date = formatter.parse("29/5/2009");
			listEmployees.add(new Employee("E001","ABC",e001date,new BigDecimal("10000"),"IT","E004" ));
			listEmployees.add(new Employee("E002","ABC1",e002date,new BigDecimal("3000"),"Admin","E004" ));
			listEmployees.add(new Employee("E003","ABC2",e003date,new BigDecimal("6000"),"Admin","E007" ));
			listEmployees.add(new Employee("E004","ABC9",e010date,new BigDecimal("10000"),"IT","E004" ));
			listEmployees.add(new Employee("E005","ABC4",e005date,new BigDecimal("44444"),"IT","E007" ));
			listEmployees.add(new Employee("E006","ABC5",e006date,new BigDecimal("22000"),"IT","E007" ));
			listEmployees.add(new Employee("E007","ABC6",e007date,new BigDecimal("36000"),"Executive",null ));
			listEmployees.add(new Employee("E008","ABC7",e008date,new BigDecimal("5000"),"Admin","E004" ));
			listEmployees.add(new Employee("E009","ABC8",e009date,new BigDecimal("9000"),"IT","E004" ));
			listEmployees.add(new Employee("E0010","ABC3",e004date,new BigDecimal("70000"),"Executive",null));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return listEmployees;
	}

}
