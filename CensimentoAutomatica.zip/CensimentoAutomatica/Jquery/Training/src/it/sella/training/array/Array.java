package it.sella.training.array;

public class Array {
 /*public static void main(String args[]){
	
String[] names=new String[] {"Amir","Priya","Ranjith","Ashok"};
System.out.println("The List Of Names Are");
for (int i=0;i<=3;i++)

	System.out.println(names[i]);
	
System.out.println("outof loop");
}*/
	
	
 public static void main(String args[]){
	 int array[]={1,2,3,45,45};
	 for(int i=0;i<=array.length;i++){
		 System.out.println(array[ i]);
		 
	 }
 }
}
