package it.sella.training.exception;

public class Example {
	public static void main(String args[]){
		String s=(String)"sella";
		try{
		int i=Integer.parseInt(s);
		System.out.println(i);
		}catch (Exception e) {
		e.fillInStackTrace();
		
		}
		
	}

}
