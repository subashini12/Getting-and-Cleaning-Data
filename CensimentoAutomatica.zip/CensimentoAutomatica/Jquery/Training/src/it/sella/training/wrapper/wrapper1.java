package it.sella.training.wrapper;
import java.math.BigDecimal;
public class wrapper1 {
	public static void main(String args[]){
		// Form double to String
		double a = 12245.1243;
	    String str = Double.toString(a);
	    System.out.println("string:=" + str);
	    
	    //Form String to double
	    String text = "12.34"; // example String
	    double value = Double.parseDouble(text);
	    System.out.println("value:=" + value);
	    
	    int b = (int) a;
	    String str1 = Integer.toString(b);
	    System.out.println("string:=" + str1);
	    
	    boolean c = true;
	    String str2 = Boolean.toString(c);
	    System.out.println("string:=" + str2);
	    
	    float d = 1678.097f;
	    String str3 = Float.toString(d);
	    System.out.println("string:=" + str3);
	    
	    BigDecimal obj1=new BigDecimal("3456.78654232");
	    System.out.println("string:="+obj1.toPlainString());
	    
	    char e='w';
	    String str4 = Character.toString(e);
	    System.out.println(str4);
	    
	    String g = "line";
	    char c1 = g.charAt(0);  // returns 'l'
	    char[] c_arr = g.toCharArray(); 
	    System.out.println(c1);
	    System.out.println(c_arr);
	  
	}

}
