package it.sella.training.assignment;

import it.sella.training.assignment.Employee;

import java.util.Comparator;

/**
 * This class is a comparator for Employee code in ascending order
 * 
 * @author INSTAGE20
 * 
 */
public class CodeAscendingComparator implements Comparator<Employee> {

	public int compare(Employee o1, Employee o2) {
		return (o1.getCode().compareTo(o2.getCode()));

	}

}
