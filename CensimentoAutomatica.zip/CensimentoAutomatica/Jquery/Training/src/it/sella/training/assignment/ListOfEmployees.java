package it.sella.training.assignment;

import java.text.ParseException;
import java.util.Collection;

public class ListOfEmployees {

	public static void main(String[] args) throws ParseException {

		Collection<Employee> allEmployeeList = EmployeeRegister.getEmployeeDetails();

		System.out.println("------------------All Employee Details----------------");
		for (Employee employee : allEmployeeList) {
			System.out.println(employee);
		}

	}
}
