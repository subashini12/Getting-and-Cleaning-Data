package it.sella.training.conversion;

public class Conversios {
public static void main(String aregs[]){
	String str=new String("10");
	 byte b = Byte.parseByte(str);   
	 System.out.println(b);
	 
	 String str1=new String("123");
	 short s = Short.parseShort(str1);    
	 System.out.println(s);
	 
	 String str2=new String("134");
	 int i = Integer.parseInt(str2);
	 System.out.println(i);
	 
	 String str3=new String("146");
	 long  l = Long.parseLong(str3);    
	 System.out.println(l);
	 
	 String str4=new String("12345.6574");
	 double d = Double.parseDouble(str4);    
	 System.out.println(d);
	 
	 String str5=new String("1223");
	 float f = Short.parseShort(str5);    
	 System.out.println(f);
	 
	
	 
}
}
