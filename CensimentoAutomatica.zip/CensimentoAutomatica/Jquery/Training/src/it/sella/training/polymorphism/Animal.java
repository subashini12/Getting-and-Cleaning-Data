package it.sella.training.polymorphism;

public class Animal {
	public void eat(){
		System.out.println("==========Animal Method================");
	}
	
}
