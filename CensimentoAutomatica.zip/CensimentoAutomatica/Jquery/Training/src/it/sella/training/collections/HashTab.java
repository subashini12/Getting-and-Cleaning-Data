package it.sella.training.collections;
import java.util.*;
public class HashTab {
	public static void main(String args[]){
		Hashtable<String, Integer> ha = new Hashtable<String, Integer>();
		 ha.put("i", new Integer(1)); //adding value to Hashtable
		 ha.put("x", new Integer(2));
		 ha.put("a", new Integer(3));
		 
		 System.out.println(ha);
		        




		
	}

}
