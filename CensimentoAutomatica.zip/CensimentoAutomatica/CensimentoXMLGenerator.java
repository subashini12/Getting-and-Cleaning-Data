package it.sella.anagrafe.bpaautomaticcens;

import it.sella.anagrafe.CanalePreferitoDataView;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreCodiciSoggettoException;
import it.sella.anagrafe.IDocumentiView;
import it.sella.anagrafe.dbaccess.CSSoggettoIdGetter;
import it.sella.anagrafe.dbaccess.CS_valoreGetter;
import it.sella.anagrafe.dbaccess.DocumentiDBAccessHelper;
import it.sella.anagrafe.originecliente.OrigineClienteView;
import it.sella.anagrafe.pf.DatiPrivacyPFFiveLevelView;
import it.sella.anagrafe.pf.DocumentoPFView;
import it.sella.anagrafe.pf.IndirizzoPFView;
import it.sella.anagrafe.pf.IntermediariPFView;
import it.sella.anagrafe.pf.SoggettoRecapitiView;
import it.sella.anagrafe.util.CommonPropertiesHandler;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.UtilHelper;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class CensimentoXMLGenerator {
	
	final DateHandler dateHandler = new DateHandler();
	
	public void setIndirizzoData(final StringBuilder censimentoXML,final Collection<IndirizzoPFView> indirizzoPFViewCollection){
		if(indirizzoPFViewCollection != null){
			for (final IndirizzoPFView indirizzoPFView : indirizzoPFViewCollection) {
				if(indirizzoPFView != null){
					censimentoXML.append("<INDIRIZZI>");
					censimentoXML.append(getTagIfValueIsNotNull("TIPO_INDIRIZZO", indirizzoPFView.getTipoIndirrizo() != null ? indirizzoPFView.getTipoIndirrizo().getCausale() : null ));
					censimentoXML.append(getTagWithValueCheckWithCDATATag("INDIRIZZO", indirizzoPFView.getIndirizzo()));
					censimentoXML.append(getTagWithValueCheckWithCDATATag("CITTA", indirizzoPFView.getCitta() != null ? indirizzoPFView.getCitta().getCommune() : indirizzoPFView.getCittaCommune() ));
					censimentoXML.append(getTagIfValueIsNotNull("CAP", indirizzoPFView.getCap() != null ? indirizzoPFView.getCap().getCap() : indirizzoPFView.getCapCode()));
					censimentoXML.append(getTagIfValueIsNotNull("PROVINCIA", indirizzoPFView.getProvincia() != null ? indirizzoPFView.getProvincia().getSigla() : indirizzoPFView.getProvinciaSigla()));
					censimentoXML.append(getTagIfValueIsNotNull("NAZIONE", indirizzoPFView.getNazione() != null ? indirizzoPFView.getNazione().getNome() : null));
					censimentoXML.append(getTagWithValueCheckWithCDATATag("EDIFICIO", indirizzoPFView.getEdificio()));
					censimentoXML.append(getTagWithValueCheckWithCDATATag("PRESSO", indirizzoPFView.getPresso()));
					censimentoXML.append("</INDIRIZZI>");
				}
			}
		}
		
	}
	
	public void setRecapitiData(final StringBuilder censimentoXML,final Collection<SoggettoRecapitiView> soggettoRecapitiViews){
		if(soggettoRecapitiViews != null){
			for (final SoggettoRecapitiView soggettoRecapitiView : soggettoRecapitiViews) {
				final boolean isEightDigitNumericRiferimento = "Posta Elettronica".equals(soggettoRecapitiView.getTipoRecapiti().getCausale()) && new UtilHelper().isEightDigitNumericRiferimento(soggettoRecapitiView.getRiferimento());
				if(!isEightDigitNumericRiferimento){
					censimentoXML.append("<RECAPITI>");
					censimentoXML.append(getTagIfValueIsNotNull("TIPO_RECAPITO", soggettoRecapitiView.getTipoRecapiti() != null ? soggettoRecapitiView.getTipoRecapiti().getCausale() : null ));
					censimentoXML.append(getTagIfValueIsNotNull("PREFISSO_INT", soggettoRecapitiView.getPrefissoCode() != null ? soggettoRecapitiView.getPrefissoCode() : null ));
					censimentoXML.append(getTagIfValueIsNotNull("VALORE", soggettoRecapitiView.getValoreRecapiti()));
					censimentoXML.append(getTagWithValueCheckWithCDATATag("NOTE", soggettoRecapitiView.getRiferimento()));
					censimentoXML.append("</RECAPITI>");
				}
			}	
		}
		
	}
	
	public void setDatiPrivacyData(final StringBuilder censimentoXML,final DatiPrivacyPFFiveLevelView datiPrivacyPFFiveLevelView){
		if(datiPrivacyPFFiveLevelView != null){
			censimentoXML.append("<DATI_PRIVACY><CODICE>livello1</CODICE><VALORE>").append(datiPrivacyPFFiveLevelView.getLivello1()).append("</VALORE></DATI_PRIVACY>");
			censimentoXML.append("<DATI_PRIVACY><CODICE>livello2</CODICE><VALORE>").append(datiPrivacyPFFiveLevelView.getLivello2()).append("</VALORE></DATI_PRIVACY>");
			censimentoXML.append("<DATI_PRIVACY><CODICE>livello3</CODICE><VALORE>").append(datiPrivacyPFFiveLevelView.getLivello3()).append("</VALORE></DATI_PRIVACY>");
			censimentoXML.append("<DATI_PRIVACY><CODICE>livello4</CODICE><VALORE>").append(datiPrivacyPFFiveLevelView.getLivello4()).append("</VALORE></DATI_PRIVACY>");
			censimentoXML.append("<DATI_PRIVACY><CODICE>livello5</CODICE><VALORE>").append(datiPrivacyPFFiveLevelView.getLivello5()).append("</VALORE></DATI_PRIVACY>");
			if(datiPrivacyPFFiveLevelView.getProfil() != null) {
				censimentoXML.append("<DATI_PRIVACY><CODICE>profil</CODICE><VALORE>").append(datiPrivacyPFFiveLevelView.getProfil()).append("</VALORE></DATI_PRIVACY>");
			}
		}
	}
	
	public void setDocumentData(final StringBuilder censimentoXML,final Collection<DocumentoPFView> documentoPFViews,final Long soggettoId) throws RemoteException, GestoreAnagrafeException{
		if(soggettoId == null){
			if(documentoPFViews != null){
				for (final DocumentoPFView documentoPFView : documentoPFViews) {
					buildDocumentTag(censimentoXML, documentoPFView);
				}
			}
		}else{
			
			final List<IDocumentiView> documentoViewList = new DocumentiDBAccessHelper().getValidDocumentByOrder(soggettoId);
				for (final IDocumentiView documentoView : documentoViewList) {
					censimentoXML.append("<DOCUMENTI>");
					censimentoXML.append(getTagIfValueIsNotNullWithCDATATag("TIPO_DOCUMENTO", documentoView.getCausaleTipoDocumento()));
					censimentoXML.append(getTagWithValueCheckWithCDATATag("NUMERO_DOCUMENTO", documentoView.getDocumentoNumero()));
					censimentoXML.append(getTagWithValueCheckWithCDATATag("ENTE_EMISSIONE", documentoView.getEnteEmissione()));
					censimentoXML.append(getTagWithValueCheckWithCDATATag("LUOGO_EMISSIONE", documentoView.getLuogoEmissione()));
					censimentoXML.append( getDateTag(documentoView.getDataEmissione(),"DATA_EMISSIONE"));
					censimentoXML.append( getDateTag(documentoView.getDataScadenza(),"DATA_SCADENZA"));
					final String provincia  = documentoView.getProvincia();
					if(provincia != null) {
						censimentoXML.append(getTagWithValueCheckWithCDATATag("NAZIONE_EMISSIONE", "ITALIA"));
						censimentoXML.append(getTagWithValueCheckWithCDATATag("CITTA_EMISSIONE", documentoView.getLuogoEmissione()));
						censimentoXML.append(getTagWithValueCheckWithCDATATag("PROVINCIA_EMISSIONE", provincia));
					}
					censimentoXML.append("</DOCUMENTI>");
				}
				if(documentoPFViews != null){
					for (final DocumentoPFView documentoPFView : documentoPFViews) {
						if(documentoPFView.getDocumentoId() == null){
							buildDocumentTag(censimentoXML, documentoPFView);
						}
					}
				}
		}
	}
	public void setOrgineClinteData(final StringBuilder censimentoXML,final OrigineClienteView origineClienteView) throws GestoreCodiciSoggettoException, RemoteException{
		if(origineClienteView != null){
			censimentoXML.append("<ORIGINE_CLIENTE>");
			String type = origineClienteView.getTipoId();
			final String value = origineClienteView.getCampagnaDesc();
			
			if("INTERMEDIARI".equals(type)){
				final CSSoggettoIdGetter csHandler = new CSSoggettoIdGetter();
				final Long soggettoId = csHandler.getSoggettoIdCS("codpr",value);
				if(soggettoId == null){
					type = "ALTRI";
				}
				
			}else if("SEGNALATORE".equals(type)){
				type = "ALTRI";
			}
			censimentoXML.append(getTagIfValueIsNotNull("TIPO_ORIGINE_CLIENTE", type));
			censimentoXML.append(getTagWithValueCheckWithCDATATag("VALORE_ORIGINE_CLIENTE", value));
			
			censimentoXML.append("</ORIGINE_CLIENTE>");
		}
	}
	
	public void setPromotoreData(final StringBuilder censimentoXML , final Collection<Long> promotoreIds,final Collection ricercaIntermediariPFColl,final boolean isForGollegate) throws GestoreCodiciSoggettoException, RemoteException{
		if(promotoreIds != null && !promotoreIds.isEmpty()){
			final CS_valoreGetter cs_valoreGetter = new CS_valoreGetter();
			String codpr = null;
			for (final Long promotoreId : promotoreIds) {
					codpr = cs_valoreGetter.getValoreCodiciSoggetto(promotoreId, "codpr");
					if(codpr != null){
						censimentoXML.append("<INTERMEDIARI>");
						censimentoXML.append(getTagWithValueCheck("CODICE_PROMOTORE", codpr));
						censimentoXML.append("</INTERMEDIARI>");
					}
			}	
		}else {//if(isForGollegate){
			final List<IntermediariPFView> promotoreList = getPromotoreList(ricercaIntermediariPFColl);
			String codpr = null;
			if(!promotoreList.isEmpty()){
				for (final IntermediariPFView intermediariPFView : promotoreList) {
					codpr = intermediariPFView.getCodiceIntermediari();
					if(codpr != null){
						censimentoXML.append("<INTERMEDIARI>");
						censimentoXML.append(getTagWithValueCheck("CODICE_PROMOTORE", codpr));
						censimentoXML.append("</INTERMEDIARI>");
					}
				}
			}else{
				final String bpaDipcode = CommonPropertiesHandler.getValueFromProperty("BPA_DEFAULT_DIP_CODE");
				if(bpaDipcode != null){
					censimentoXML.append("<INTERMEDIARI>");
					censimentoXML.append(getTagWithValueCheck("CODICE_DIPENDENTE", bpaDipcode));
					censimentoXML.append("</INTERMEDIARI>");
				}
			}
		}
	}
	
	private List<IntermediariPFView> getPromotoreList( final Collection ricercaIntermediariPFColl)  {
        final List<IntermediariPFView> promotoreList = new ArrayList<IntermediariPFView>(); 
		if ( ricercaIntermediariPFColl != null ) {
            final Iterator iterator = ricercaIntermediariPFColl.iterator();
            final int size = ricercaIntermediariPFColl.size();
            IntermediariPFView ricerca = null;
            for (int i = 0; i < size; i++) {
                ricerca = (IntermediariPFView) iterator.next();
                if (ricerca.getTypeOfIntermediari().equalsIgnoreCase("PROCT")) {
                	promotoreList.add(ricerca);
                } 
            }
        }
		return promotoreList;
    }
	
	private void buildDocumentTag(final StringBuilder censimentoXML,final DocumentoPFView documentoPFView) {
		censimentoXML.append("<DOCUMENTI>");
		censimentoXML.append(getTagIfValueIsNotNullWithCDATATag("TIPO_DOCUMENTO", documentoPFView.getTipoDocumento() != null ? documentoPFView.getTipoDocumento().getCausale() : null ));
		censimentoXML.append(getTagWithValueCheckWithCDATATag("NUMERO_DOCUMENTO", documentoPFView.getDocumentoNumero()));
		censimentoXML.append(getTagWithValueCheckWithCDATATag("ENTE_EMISSIONE", documentoPFView.getEnteEmissione()));
		censimentoXML.append(getTagWithValueCheckWithCDATATag("LUOGO_EMISSIONE", documentoPFView.getLuogoEmissione()));
		censimentoXML.append( getDateTag(documentoPFView.getDataEmissione(),"DATA_EMISSIONE"));
		censimentoXML.append( getDateTag(documentoPFView.getDataScadenza(),"DATA_SCADENZA"));
		final Map<String, Object> luogoEmissioneMap = documentoPFView.getLuogoEmissioneMap(); 
		if(luogoEmissioneMap != null) {
			censimentoXML.append(getTagWithValueCheckWithCDATATag("NAZIONE_EMISSIONE", (String) luogoEmissioneMap.get("nazione")));
			censimentoXML.append(getTagWithValueCheckWithCDATATag("CITTA_EMISSIONE", (String) luogoEmissioneMap.get("citta")));
			censimentoXML.append(getTagWithValueCheckWithCDATATag("PROVINCIA_EMISSIONE", (String) luogoEmissioneMap.get("provincia")));
		}
		censimentoXML.append("</DOCUMENTI>");
	}
	
	public void setCodiciSoggettoValue(final StringBuilder censimentoXML , final String causale , final String value){
		if(value != null){
			censimentoXML.append("<CODICI_SOGGETTO>");
			censimentoXML.append(getTagWithValueCheck("CODICE",causale));
			censimentoXML.append(getTagWithValueCheck("VALORE",value));
			censimentoXML.append("</CODICI_SOGGETTO>");	
		}
		
	}
	
	public String getDateTag(final Timestamp date,final String rootTagName) {
		final StringBuilder dateBuilder = new StringBuilder();
		if (date != null) {
			final String dateStrings[] = dateHandler.formatDate(date, "dd/MM/yyyy").split("/");
			dateBuilder.append("<").append(rootTagName).append(">");
			dateBuilder.append(getTagWithValueCheck("GIORNO", dateStrings[0]));
			dateBuilder.append(getTagWithValueCheck("MESE", dateStrings[1]));
			dateBuilder.append(getTagWithValueCheck("ANNO", dateStrings[2]));
			dateBuilder.append("</").append(rootTagName).append(">");
			return dateBuilder.toString();
		}
		return dateBuilder.toString();
		
	}
	
	public static String getTagIfValueIsNotNull( final String tagName, final String value) {
		final StringBuffer output = new StringBuffer();
		if(value != null){
			output.append("<").append(tagName).append(">").append(value).append("</").append(tagName).append(">").toString();	
		}
		return output.toString();
	}
	
	public static String getTagIfValueIsNotNullWithCDATATag( final String tagName, final String value) {
		final StringBuffer output = new StringBuffer();
		if(value != null){
			output.append("<").append(tagName).append(">").append( "<![CDATA["+value+"]]>").append("</").append(tagName).append(">").toString();	
		}
		return output.toString();
	}
	
	public static String getTagWithValueCheck( final String tagName, final String value) {
    	final StringBuffer output = new StringBuffer();
        return output.append("<").append(tagName).append(">").append((value != null ? value : "")).append("</").append(tagName).append(">").toString();
    }
	
	public static String getTagWithValueCheckWithCDATATag( final String tagName, final String value) {
    	final StringBuffer output = new StringBuffer();
        return output.append("<").append(tagName).append(">").append((value != null ? "<![CDATA["+value+"]]>" : "")).append("</").append(tagName).append(">").toString();
    }
	
	public void setCanalePreferitoData(final StringBuilder censimentoXML, final CanalePreferitoDataView canalePreferitoDataView){
		if(canalePreferitoDataView != null && canalePreferitoDataView.getCanale() != null){
			censimentoXML.append("<CANALE_PREFERITO>");
			censimentoXML.append(getTagIfValueIsNotNull("TIPO_CANALE_PREFERITO", canalePreferitoDataView.getCanale().getCausale()));
			censimentoXML.append(getTagIfValueIsNotNull("VALORE_CANALE_PREFERITO", canalePreferitoDataView.getCanaleValue()));
			censimentoXML.append(getTagIfValueIsNotNull("TIPO_RECAPITI", canalePreferitoDataView.getTipoRecapiti() != null ? canalePreferitoDataView.getTipoRecapiti().getCausale() : ""));
			censimentoXML.append("</CANALE_PREFERITO>");
		}
	}			
}

