package it.sella.anagrafe.view;

import java.io.Serializable;
import java.sql.Date;

public class SoggettiPromtoreView implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	private Long bankId;
	private Long soggettoId;
	private String tipoSoggetto;
	private StringBuffer censimentoXML;
	private String stato;
	private StringBuffer errorMsg;
	private Date dataRiff;
	private Long opId;

	public Long getId() {
		return id;
	}
	public void setId(final Long id) {
		this.id = id;
	}
	public Long getSoggettoId() {
		return soggettoId;
	}
	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}
	public Long getBankId() {
		return bankId;
	}
	public void setBankId(final Long bankId) {
		this.bankId = bankId;
	}
	public String getTipoSoggetto() {
		return tipoSoggetto;
	}
	public void setTipoSoggetto(final String tipoSoggetto) {
		this.tipoSoggetto = tipoSoggetto;
	}
	public StringBuffer getCensimentoXML() {
		return censimentoXML;
	}
	public void setCensimentoXML(final StringBuffer censimentoXML) {
		this.censimentoXML = censimentoXML;
	}
	public String getStato() {
		return stato;
	}
	public void setStato(final String stato) {
		this.stato = stato;
	}
	public StringBuffer getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(final StringBuffer errorMsg) {
		this.errorMsg = errorMsg;
	}
	public Date getDataRiff() {
		return dataRiff;
	}
	public void setDataRiff(final Date dataRiff) {
		this.dataRiff = dataRiff;
	}
	public Long getOpId() {
		return opId;
	}
	public void setOpId(final Long opId) {
		this.opId = opId;
	}

	public String toString() {
		final StringBuffer soggettoPromotoreView = new StringBuffer();
		soggettoPromotoreView.append("SoggettoPromotoreView values is ").append("id=").append(id)
		.append(", bankId=").append(bankId).append(", soggettoId").append(soggettoId)
		.append( ", tipoSoggetto=").append(tipoSoggetto).append(", censimentoXML=")
		.append(censimentoXML).append( ", stato=").append(stato).append(", errorMsg=")
		.append(errorMsg).append(", dataRiff=").append(dataRiff).append( ", opId=").append(opId);
		return soggettoPromotoreView.toString();
	}


}
