package it.sella.anagrafe;

/** Factory is being designed as Singleton */

public class OperazioneAnagrafeFactory {

    private OperazioneAnagrafeManager operazioneAnagrafeManager;
    private static OperazioneAnagrafeFactory anagrafeFactory;

    private OperazioneAnagrafeFactory() {
    }

    /** This method  is used for getting the instance of factory */
    public static OperazioneAnagrafeFactory getInstance() {
        if(anagrafeFactory == null) {
        	anagrafeFactory = new OperazioneAnagrafeFactory();
		}
        return anagrafeFactory;
    }

    /** This method  is used for getting the OperazioneAnagrafeManager
     * instance */
    public OperazioneAnagrafeManager getOperazioneAnagrafeManager() {
        if(operazioneAnagrafeManager == null) {
			operazioneAnagrafeManager = new OperazioneAnagrafeManager();
		}
        return operazioneAnagrafeManager;
    }

}