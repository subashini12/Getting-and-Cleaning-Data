package it.sella.anagrafe.bpaautomaticcens;

import it.sella.anagrafe.AnagrafeManagerFactory;
import it.sella.anagrafe.pf.CollegatePFView;
import it.sella.anagrafe.pf.DatiAnagraficiPFView;
import it.sella.anagrafe.pf.DatiFiscaliPFView;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.SoggettiPromotoreException;
import it.sella.anagrafe.view.PersonaFisicaView;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Properties;

public class PFRootXMLGenerator extends CensimentoXMLGenerator{
	
	final DateHandler dateHandler = new DateHandler();
	
	public String getXMLForBPAAutomaticCens(final PersonaFisicaView personaFisicaView,final Long sogeetoId) throws RemoteException, SoggettiPromotoreException{
		final StringBuilder censimentoRootXML = new StringBuilder("<SOGGETTO_BPA>");
		setUserDeatails(censimentoRootXML, personaFisicaView);
		censimentoRootXML.append("<SOGGETTO_XML_LIST>");
		setCollegateSoggettoData(censimentoRootXML, personaFisicaView.getCollegateViews());
		setMainSoggettoData(censimentoRootXML, personaFisicaView);
		censimentoRootXML.append("</SOGGETTO_XML_LIST>");
		censimentoRootXML.append("</SOGGETTO_BPA>");
		return censimentoRootXML.toString();
	}
	
	private void setUserDeatails(final StringBuilder censimentoRootXML,final PersonaFisicaView personaFisicaView){
		censimentoRootXML.append(getTagWithValueCheck("TipoSoggetto", "PF"));
		final DatiAnagraficiPFView datiAnagraficiPFView = personaFisicaView.getDatiAnagraficiPFView();
		censimentoRootXML.append("<PERSONA_FISICA>");
		if(datiAnagraficiPFView != null){
			censimentoRootXML.append(getTagWithValueCheckWithCDATATag("NOME", datiAnagraficiPFView.getNome()));
			censimentoRootXML.append(getTagWithValueCheckWithCDATATag("COGNOME", datiAnagraficiPFView.getCognome()));
			censimentoRootXML.append(getTagWithValueCheck("DATA_DI_NASCITA", dateHandler.formatDate(datiAnagraficiPFView.getDataDiNascita(), "dd/MM/yyyy")));
			censimentoRootXML.append(getTagWithValueCheckWithCDATATag("LUOGO_DI_NASCITA", datiAnagraficiPFView.getLuogoDiNascitaCitta() != null ? datiAnagraficiPFView.getLuogoDiNascitaCitta().getCommune() : "" ));
		}
		final DatiFiscaliPFView datiFiscaliPFView = personaFisicaView.getDatiFiscaliPFView();
		if(datiFiscaliPFView != null){
			censimentoRootXML.append(getTagWithValueCheck("CODICEFISCALE", datiFiscaliPFView.getCodiceFiscali()));
		}
		censimentoRootXML.append("</PERSONA_FISICA>");
	}
	
	private void setCollegateSoggettoData(final StringBuilder censimentoRootXML,final Collection<CollegatePFView> collegatePFViews) throws RemoteException, SoggettiPromotoreException{
		PersonaFisicaView personaFisicaView= null;
		if(collegatePFViews!= null && !collegatePFViews.isEmpty()){
			final Properties properties = new Properties();
			for (final CollegatePFView collegatePFView : collegatePFViews) {
				censimentoRootXML.append("<SOGGETTO_XML>");
				personaFisicaView = (PersonaFisicaView)AnagrafeManagerFactory.getInstance().getAnagrafeManagerClientImpl().getSoggetto(collegatePFView.getId(), properties);
				censimentoRootXML.append(new PFCensimentoXMLGenerator().getCensimentoXML(personaFisicaView, collegatePFView.getId(),true));
				censimentoRootXML.append("</SOGGETTO_XML>");
			}
		}
		
	}
	private void setMainSoggettoData(final StringBuilder censimentoRootXML,final PersonaFisicaView personaFisicaView) throws RemoteException, SoggettiPromotoreException{
				censimentoRootXML.append("<SOGGETTO_XML>");
				censimentoRootXML.append(new PFCensimentoXMLGenerator().getCensimentoXML(personaFisicaView, personaFisicaView.getId(),false));
				censimentoRootXML.append("</SOGGETTO_XML>");
	}
	
	/*private String getDateTag(final Timestamp date) {
		final StringBuilder dateBuilder = new StringBuilder();
		if (date != null) {
			final String dateStrings[] = dateHandler.formatDate(date, "dd/MM/yyyy").split("/");
			dateBuilder.append(getTagWithValueCheck("GIORNO", dateStrings[0]));
			dateBuilder.append(getTagWithValueCheck("MESE", dateStrings[1]));
			dateBuilder.append(getTagWithValueCheck("ANNO", dateStrings[2]));
		}
		return dateBuilder.toString();
	}*/
}
