package it.sella.training.samples;

public class ReplaceAll {

	public static void main(String[] args) {

		String s="BA@NC%^A SELL&A";
		System.out.println("Replacing Any Special Characters In Java : "+s.replaceAll("[^a-z A-Z 0-9]",""));//BANCA SELLA
		System.out.println(s.replaceAll("[^a-zA-Z0-9]",""));//BANCASELLA


		String test = "Hello(how-are.you ?)";
		String outputText = test.replaceAll("[()-. ]+", " ");

		System.out.println(outputText);

		String sample = "Javas";
		System.out.println("==========To Check Which Digit Is Numeric============");
		for (int i = 0; i < sample.length(); i++) {
			Boolean flag = Character.isDigit(sample.charAt(i));
			if(flag){
				System.out.println(sample.charAt(i) +" is a number");
			}else{
				System.out.println(sample.charAt(i) +" is not a number");
			}
		}

		System.out.println("========To Check Whether A String Contains Numeric============");
		String myString = "qwbdfgdfg34534534erty";
		
		System.out.println(myString.matches("^[0-9a-zA-Z]+$"));

	}
	
	public boolean isAlphaNumeric(String s){
	    String pattern= "^[0-9a-zA-Z]+$";
	        if(s.matches(pattern)){
	            return true;
	        }
	        return false;   
	}

}
