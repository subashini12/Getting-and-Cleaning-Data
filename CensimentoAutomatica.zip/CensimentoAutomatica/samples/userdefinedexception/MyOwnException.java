package it.sella.training.samples.userdefinedexception;

public class MyOwnException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public MyOwnException(final String errorMessage){
		super(errorMessage);
	}

}

