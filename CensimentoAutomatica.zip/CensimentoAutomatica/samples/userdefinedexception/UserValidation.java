package it.sella.training.samples.userdefinedexception;

public class UserValidation {

	@SuppressWarnings("unused")
	public static void main(String[] args) throws MyOwnException {

		final int age=-10;

		if(age < 0){
			throw new MyOwnException("The age "+age+" you have enterd is wrong");
		}else{
			System.out.println("The name has been entered");
		}
	}


}
