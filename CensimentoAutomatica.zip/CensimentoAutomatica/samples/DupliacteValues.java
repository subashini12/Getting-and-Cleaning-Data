package it.sella.training.samples;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DupliacteValues {

	public static void main(String[] args) {
		
		List<String> values = new ArrayList<String>();
		values.add("Rose");
		values.add("Lily");
		values.add("Jasmine");
		values.add("Jasmine");
		values.add("Hibiscus");
		values.add("Rose");

		System.out.println("Before Removing Duplicates From List========="+values);
		List<String> removeDuplicate= new ArrayList<String>(new HashSet<String>(values));
		System.out.println("After Removing Duplicates From List=========="+removeDuplicate);

		Set<String> usingSetDirectlyRemovingDuplicates = new HashSet<String>(values);
		System.out.println("After Removing Duplicates From List By Using Set=========="+usingSetDirectlyRemovingDuplicates);
	}

}
