package it.sella.anagrafe.sm.censimentoautomatico;

import it.sella.anagrafe.dao.ICensimentoAutomaticoDAO;
import it.sella.anagrafe.dao.impl.CensimentoAutomaticoImpl;
import it.sella.anagrafe.implementation.ElencoAziendaView;
import it.sella.anagrafe.implementation.ElencoPersoneFisicheView;
import it.sella.anagrafe.implementation.ElencoPlurintestazioniView;
import it.sella.anagrafe.sm.AnagrafeBaseExecuter;
import it.sella.anagrafe.sm.admin.AdminConstants;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.HelperException;
import it.sella.anagrafe.util.SoggettiPromotoreException;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineException;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.io.Serializable;
import java.util.List;

public class CensimentoAutomaticoSearchExecuter extends AnagrafeBaseExecuter{

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CensimentoAutomaticoSearchExecuter.class);

	public ExecuteResult execute(final RequestEvent requestEvent)
	throws StateMachineException {
		
		ExecuteResult executeResult = AnagrafeHelper.getExecuteResult("TrConferma");
		final StateMachineSession session = requestEvent.getStateMachineSession();
		String rif_date = null;
		try {
			final ICensimentoAutomaticoDAO censAutomaticDao = new CensimentoAutomaticoImpl();
			session.remove(AdminConstants.elencoPF);
			session.remove(AdminConstants.elencoAZ);
			session.remove(AdminConstants.elencoPL);
			String isFromConformaOrCancella =(String) session.remove("isFromConformaOrCancella");
			log4Debug.info("isFromConformaOrCancella .........",isFromConformaOrCancella);
			String rifDay = null;
			String rifMonth = null;
			String rifYear =  null;
			Boolean isRecordExists = Boolean.FALSE;
			log4Debug.info("rifDay .........",requestEvent.getAttribute("rifDay"));
			log4Debug.info("rifMonth .........",requestEvent.getAttribute("rifMonth"));
			log4Debug.info("rifYear .........",requestEvent.getAttribute("rifYear"));
			if (requestEvent.getAttribute("rifDay") == null
					&& requestEvent.getAttribute("rifMonth") == null
					&& requestEvent.getAttribute("rifYear") == null) {
				isFromConformaOrCancella =  "true";
			}
			if(isFromConformaOrCancella != null){
				final String rifdate[] =new AutomaticCensimentoHandler().currentDate().split("/");
				rifDay = rifdate[0];
				rifMonth = rifdate[1];
				rifYear =rifdate[2];
			}else{
				rifDay = (String) requestEvent.getAttribute("rifDay")!= null ? ((String) requestEvent.getAttribute("rifDay")).trim() : "" ;
				rifMonth = (String) requestEvent.getAttribute("rifMonth") != null ? ((String) requestEvent.getAttribute("rifMonth")).trim() : "" ;
				rifYear = (String) requestEvent.getAttribute("rifYear") != null ? ((String) requestEvent.getAttribute("rifYear")).trim() : "";
			}
			log4Debug.info("rifDay=============", rifDay);
			log4Debug.info("rifMonth=============", rifMonth);
			log4Debug.info("rifYear=============", rifYear);

			rif_date = rifDay + "/" + rifMonth + "/" + rifYear ;
			log4Debug.info("rif_date=============", rif_date);

			new DateHandler().getDateFromDateString(rif_date, "dd/MM/yyyy");

			final List<ElencoPersoneFisicheView> elencoPF = censAutomaticDao.listPersonaFisicaDetails(rif_date);
			log4Debug.info("elencoPF=============", elencoPF.size());
			final List<ElencoAziendaView> elencoAZ = censAutomaticDao.listAziendaDetails(rif_date);
			log4Debug.info("elencoAZ=============", elencoAZ.size());
			final List<ElencoPlurintestazioniView> elencoPL = censAutomaticDao.listPlurintestazioniDetails(rif_date);
			log4Debug.info("elencoPL=============", elencoPL.size());


			if (!elencoPF.isEmpty()){
				//executeResult.setAttribute(AdminConstants.elencoPF,(Serializable)elencoPF);
				session.put(AdminConstants.elencoPF,(Serializable)elencoPF);
				isRecordExists = Boolean.TRUE;
			}
			if(!elencoAZ.isEmpty()){
				//executeResult.setAttribute(AdminConstants.elencoAZ,(Serializable)elencoAZ);
				session.put(AdminConstants.elencoAZ,(Serializable)elencoAZ);
				isRecordExists = Boolean.TRUE;
			}
			if (!elencoPL.isEmpty()){
				//executeResult.setAttribute(AdminConstants.elencoPL,(Serializable)elencoPL);
				session.put(AdminConstants.elencoPL,(Serializable)elencoPL);
				isRecordExists = Boolean.TRUE;
			}
			if(!isRecordExists ){
				
				throw new SoggettiPromotoreException(new AnagrafeHelper().getMessage("ANAG-1356"));
				
			}
			
		} catch (final SoggettiPromotoreException e) {
			log4Debug.warnStackTrace(e);
			executeResult = getNonConfermaExecuteResult("errorMessage",e.getMessage());
		} catch (final HelperException e) {
			log4Debug.warnStackTrace(e);
			executeResult = getNonConfermaExecuteResult("errorMessage",e.getMessage());
		}
		//executeResult.setAttribute(AdminConstants.rif_date,rif_date);
		if(rif_date!= null){
			session.put(AdminConstants.rif_date,rif_date);
		}
		
		return executeResult;
	}

}
