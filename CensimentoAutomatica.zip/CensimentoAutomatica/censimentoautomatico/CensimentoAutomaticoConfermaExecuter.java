package it.sella.anagrafe.sm.censimentoautomatico;

import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.sm.AnagrafeBaseExecuter;
import it.sella.anagrafe.sm.admin.AdminConstants;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.SoggettiPromotoreException;
import it.sella.classificazione.ClassificazioneView;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineException;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class CensimentoAutomaticoConfermaExecuter extends AnagrafeBaseExecuter{

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CensimentoAutomaticoConfermaExecuter.class);

	public ExecuteResult execute(final RequestEvent reqEvent)
	throws StateMachineException {
		
		ExecuteResult executeResult = AnagrafeHelper.getExecuteResult("TrConferma");
		final StateMachineSession session = reqEvent.getStateMachineSession();

		try {
			final String[] listOfPFIndex = checkInstance(reqEvent.getAttribute("pfindex"));
			final String[] listOfAZIndex = checkInstance(reqEvent.getAttribute("azindex"));
			final String[] listOfPLIndex = checkInstance(reqEvent.getAttribute("plindex"));

			final Collection<String>autoCensIDList = new ArrayList<String> ();
			if(listOfPFIndex != null){
				Collections.addAll(autoCensIDList,listOfPFIndex);
			}
			if(listOfAZIndex != null){
				Collections.addAll(autoCensIDList,listOfAZIndex);
			}
			if(listOfPLIndex != null){
				Collections.addAll(autoCensIDList,listOfPLIndex);
			}
			log4Debug.info("Size Of All Index In Executer===================",autoCensIDList.size());

			if(!autoCensIDList.isEmpty()){
				final ClassificazioneView classificazioneView = new ClassificazioneHandler().getClassificazioneViewFromDescription("ANAG_PARAMETER", "AUTO_CENS_MAX_COUNT");
		    	Long maxCenzAllowedCount = null;
				if(classificazioneView != null){
					maxCenzAllowedCount = Long.valueOf(classificazioneView.getCausale());
		    	}
				log4Debug.debug("CensimentoAutomaticoConfermaExecuter : maxCenzAllowedCount ==>",maxCenzAllowedCount);
				if(maxCenzAllowedCount != null && autoCensIDList.size() > maxCenzAllowedCount){
					String errorMsg = new AnagrafeHelper().getMessage("ANAG-1651");
					errorMsg = errorMsg.replaceFirst("\\?", maxCenzAllowedCount.toString());
					throw new SoggettiPromotoreException(errorMsg);
				}
				new AutomaticCensimentoHandler().autoCensimento(autoCensIDList);
			}
			else{
				throw new SoggettiPromotoreException(new AnagrafeHelper().getMessage("ANAG-1366"));
			}
			
			session.put("isFromConformaOrCancella", "true");
			session.remove(AdminConstants.elencoPF);
			session.remove(AdminConstants.elencoAZ);
			session.remove(AdminConstants.elencoPL);
			session.remove(AdminConstants.rif_date);
			
		} catch (final SoggettiPromotoreException e) {
			log4Debug.severeStackTrace(e);
			executeResult = getNonConfermaExecuteResult("errorMessage",e.getMessage());
		} catch (final SubSystemHandlerException e) {
			log4Debug.severeStackTrace(e);
			executeResult = getNonConfermaExecuteResult("errorMessage",e.getMessage());
		}
		return executeResult;
	}


	private String[]checkInstance(final Object object){
		String [] returnArray = null;
		if(object != null){
			if( object instanceof String){
				final String s= (String) object;
				returnArray = new String[ 1];
				returnArray[0] = s;
			}else if(object instanceof String[]){
				returnArray =(String[]) object ;
			}
		}
		return returnArray;
	}


}





