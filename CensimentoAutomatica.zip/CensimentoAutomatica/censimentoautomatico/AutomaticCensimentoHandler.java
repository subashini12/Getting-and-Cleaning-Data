/**
 * 
 */
package it.sella.anagrafe.sm.censimentoautomatico;

import it.sella.anagrafe.OperazioneAnagrafeFactory;
import it.sella.anagrafe.OperazioneAnagrafeManager;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.anagrafe.util.DateHandler;
import it.sella.anagrafe.util.HelperException;
import it.sella.anagrafe.util.SoggettiPromotoreException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collection;

/**
 * @author gbs03109
 *
 */
public class AutomaticCensimentoHandler {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AutomaticCensimentoHandler.class);


	
	/**
	 * Method to handle Auto Censimento
	 * @param autoCensIDList
	 * @return
	 * @throws SoggettiPromotoreException
	 */
	public String autoCensimento(final Collection<String> autoCensIDList) throws SoggettiPromotoreException{
		final OperazioneAnagrafeManager operazioneAnagrafeManager = OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager();
		final StringBuffer outputMessage = new StringBuffer();
		try {
			for(final String autoCensID : autoCensIDList){

				final Long soggettoPromotoreId = Long.valueOf(autoCensID);
				log4Debug.info("soggettoPromotoreId In Executer===================",soggettoPromotoreId);

				final String outputSuccessErrorMsg = operazioneAnagrafeManager.createSoggettoFromXMLForBPA(soggettoPromotoreId,"ANAG-BPA-AUTO-CRE");
				outputMessage.append(outputSuccessErrorMsg);
			}
		} catch (final RemoteException e) {
			log4Debug.warnStackTrace(e);
			throw new SoggettiPromotoreException(e.getMessage());
		} catch (final OperazioneAnagrafeManagerException e) {
			log4Debug.warnStackTrace(e);
			throw new SoggettiPromotoreException(e.getMessage());
		}
		log4Debug.info("Status In Executer===================",outputMessage);
		return outputMessage.toString();
	}
	
	public String currentDate() {
		final Timestamp rifDate = new DateHandler().getTruncCurrentDateInTimeStampFormat();
		return new DateHandler ().formatDate(rifDate, "dd/MM/yyyy");
	}
	
	public Date rifDate() throws HelperException{
		final String date =	new AutomaticCensimentoHandler().currentDate();
		return new DateHandler().getDateFromDateString(date, "dd/MM/yyyy");

	}


}
