package it.sella.anagrafe.sm.censimentoautomatico;

import it.sella.anagrafe.dao.ICensimentoAutomaticoDAO;
import it.sella.anagrafe.dao.impl.CensimentoAutomaticoImpl;
import it.sella.anagrafe.sm.AnagrafeBaseExecuter;
import it.sella.anagrafe.sm.admin.AdminConstants;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.AnagrafeLoggerHelper;
import it.sella.anagrafe.util.SoggettiPromotoreException;
import it.sella.logserver.LoggerException;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineException;
import it.sella.statemachine.StateMachineSession;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class CensimentoAutomaticoCancellaExecuter extends AnagrafeBaseExecuter{
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CensimentoAutomaticoCancellaExecuter.class);
	public ExecuteResult execute(final RequestEvent reqEvent)	throws StateMachineException {

		
		final ICensimentoAutomaticoDAO daoImpl = new CensimentoAutomaticoImpl();
		final StateMachineSession session = reqEvent.getStateMachineSession();
		ExecuteResult executeResult = AnagrafeHelper.getExecuteResult("TrConferma");
		log4Debug.info("From ReqEvent In Conferma Executer",reqEvent.getAttribute("pfindex"));
		

		try{
			final String[]  listOfPFIndex = checkInstance(reqEvent.getAttribute("pfindex"));
			final String[] listOfAZIndex = checkInstance(reqEvent.getAttribute("azindex"));
			final String[] listOfPLIndex = checkInstance( reqEvent.getAttribute("plindex"));
			final Collection<String>collOfAllIndex = new ArrayList<String> ();
			if(listOfPFIndex != null){
				Collections.addAll(collOfAllIndex,listOfPFIndex);
			}
			if(listOfAZIndex != null){
				Collections.addAll(collOfAllIndex,listOfAZIndex);
			}
			if(listOfPLIndex != null){
				Collections.addAll(collOfAllIndex,listOfPLIndex);
			}
			log4Debug.info("list Total Index Conferma Executer",collOfAllIndex.size());

			cancellCensimento(daoImpl, collOfAllIndex);
			session.put("isFromConformaOrCancella", "true");
			session.remove(AdminConstants.elencoPF);
			session.remove(AdminConstants.elencoAZ);
			session.remove(AdminConstants.elencoPL);
			session.remove(AdminConstants.rif_date);
		}catch(final SoggettiPromotoreException e){
			log4Debug.warnStackTrace(e);
			executeResult = getNonConfermaExecuteResult("errorMessage",e.getMessage());
		} catch (final RemoteException e) {
			log4Debug.warnStackTrace(e);
			executeResult = getNonConfermaExecuteResult("errorMessage",e.getMessage());
		}
		return executeResult;

	}

	
	/**
	 * Method to Cancel Censimento
	 * @param daoImpl
	 * @param collOfAllIndex
	 * @throws SoggettiPromotoreException
	 * @throws RemoteException 
	 */
	private void cancellCensimento(final ICensimentoAutomaticoDAO daoImpl,final Collection<String> collOfAllIndex) throws SoggettiPromotoreException, RemoteException {
		try {
			if(!collOfAllIndex.isEmpty()){
				final Long opId = new AnagrafeLoggerHelper().logAnagrafeOperation(null,false,"ANAG-BPA-AUTO-CAN",null,null);
				for(final String collOfID : collOfAllIndex){
					final Long soggettoPromotoreId = Long.valueOf(collOfID);
					daoImpl.updateAutoCensitoStatus(soggettoPromotoreId, null, "CANCELLATO", null, opId);
				}
			}
			else{
				throw new SoggettiPromotoreException(new AnagrafeHelper().getMessage("ANAG-1366"));
			}
		} catch (final LoggerException e) {
			log4Debug.warnStackTrace(e);
			throw new SoggettiPromotoreException(e);
		}
	}

	
	/**
	 * Method to check Input object
	 * @param object
	 * @return
	 */
	private String[]checkInstance(final Object object){
		String [] returnArray = null;
		if(object != null){
			if( object instanceof String){
				final String s= (String) object;
				returnArray = new String[ 1];
				returnArray[0] = s;
			}else if(object instanceof String[]){
				returnArray =(String[]) object ;
			}
		}
		return returnArray;
	}
}